package com.svb.gateway.migration.accountbalance.batch.config;

import com.svb.gateway.migration.accountbalance.batch.dto.source.AccBalanceTrend;
import com.svb.gateway.migration.accountbalance.batch.dto.target.AcBalTrend;
import com.svb.gateway.migration.accountbalance.batch.mapper.AccBalTrendRowMapper;
import com.svb.gateway.migration.accountbalance.batch.processors.AccBalTrendProcessor;
import com.svb.gateway.migration.common.config.ConfigBase;
import com.svb.gateway.migration.common.listeners.MigrationItemListener;
import com.svb.gateway.migration.common.utility.MigrationConstants;
import com.svb.gateway.migration.transaction.batch.utils.Queries;
import io.micrometer.core.instrument.util.StringUtils;
import org.springframework.batch.core.ItemProcessListener;
import org.springframework.batch.core.ItemReadListener;
import org.springframework.batch.core.ItemWriteListener;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.core.step.builder.SimpleStepBuilder;
import org.springframework.batch.item.database.BeanPropertyItemSqlParameterSourceProvider;
import org.springframework.batch.item.database.JdbcBatchItemWriter;
import org.springframework.batch.item.database.JdbcCursorItemReader;
import org.springframework.batch.item.database.builder.JdbcBatchItemWriterBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.PreparedStatementSetter;

import javax.sql.DataSource;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Date;

import static com.svb.gateway.migration.common.utility.MigrationConstants.*;

@Configuration
public class AccBalTrendConfig extends ConfigBase {

    @Autowired
    public MigrationItemListener<AccBalanceTrend, AccBalanceTrend> migrationItemListener;

    @Qualifier("eConnectDataSource")
    @Autowired
    public DataSource eConnectDataSource;

    @Qualifier("migrationDataSource")
    @Autowired
    public DataSource migrationDataSource;

    private static final int ACCOUNT_INFO_SOURCE_ID = 1;
    private static final int APPL_NUM = 20;

    @Bean
    public Step stepAccBalTrend() {
        return ((SimpleStepBuilder<AccBalanceTrend, AcBalTrend>) stepBuilderFactory.get(AC_BALANCE_TREND_ENTITY)
                .<AccBalanceTrend, AccBalanceTrend>chunk(chunkSize).faultTolerant().skipLimit(skipLimit).skipPolicy(exceptionSkipPolicy)
                .listener(migrationSkipListener).listener(migrationStepListener)).reader(accBalTrendReader(EMPTY_STRING, EMPTY_STRING, new Date(), new Date()))
                .listener((ItemReadListener) migrationItemListener).processor(accBalTrendProcessor())
                .listener((ItemProcessListener) migrationItemListener).writer(accBalTrendWriter())
                .listener((ItemWriteListener) migrationItemListener).build();
    }

    @Bean(destroyMethod="")
    @StepScope
    public JdbcCursorItemReader<AccBalanceTrend> accBalTrendReader(@Value("#{jobParameters['cifIds']}") String cif,
                                                                   @Value("#{jobParameters['datefilterrequired']}") String dateFilterRequired,
                                                                   @Value("#{jobParameters['fromdate']}") Date fromDate,
                                                                   @Value("#{jobParameters['todate']}") Date toDate) {
        StringBuilder query =
                new StringBuilder(Queries.ACC_BAL_MIGRATION_QUERY);
        if(StringUtils.isNotBlank(dateFilterRequired))
            if (dateFilterRequired == DATE_FILTER_REQUIRED) {
                query.append(Queries.AND_DT_AS_OF_DT_BETWEEN_AND);
            }
        if(StringUtils.isNotBlank(cif)) { query.append(" AND CC.CUST_NUM IN (" ); query.append(cif); query.append(")"); }

        JdbcCursorItemReader<AccBalanceTrend> reader = new JdbcCursorItemReader<AccBalanceTrend>();
        reader.setDataSource(eConnectDataSource);
        reader.setSql(query.toString());
        getPreparedStatement(dateFilterRequired, fromDate, toDate, reader);
        reader.setRowMapper(new AccBalTrendRowMapper());
        return reader;
    }

    @Bean
    @StepScope
    public AccBalTrendProcessor accBalTrendProcessor() {
        return new AccBalTrendProcessor();
    }

    @Bean
    public JdbcBatchItemWriter<AcBalTrend> accBalTrendWriter() {
        return new JdbcBatchItemWriterBuilder<AcBalTrend>()
                .itemSqlParameterSourceProvider(new BeanPropertyItemSqlParameterSourceProvider<>())
                .sql(Queries.ACC_BAL_TREND_INSERT_QUERY)
                .dataSource(migrationDataSource).build();
    }

    private void getPreparedStatement(String dateFilterRequired, Date fromDate, Date toDate, JdbcCursorItemReader<AccBalanceTrend> reader) {
        reader.setPreparedStatementSetter(new PreparedStatementSetter() {
            @Override
            public void setValues(PreparedStatement psv) throws SQLException {
                psv.setInt(1, ACCOUNT_INFO_SOURCE_ID);
                psv.setInt(2, APPL_NUM);
                if(StringUtils.isNotBlank(dateFilterRequired))
                    if (dateFilterRequired == DATE_FILTER_REQUIRED) {
                        psv.setDate(3, new java.sql.Date(fromDate.getTime()));
                        psv.setDate(4, new java.sql.Date(toDate.getTime()));
                    }
            }
        });
    }
}
