package com.svb.gateway.migration.accountbalance.batch.mapper;

import com.svb.gateway.migration.accountbalance.batch.dto.source.AccBalanceTrend;
import org.springframework.jdbc.core.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;

public class AccBalTrendRowMapper implements RowMapper<AccBalanceTrend> {
    /**
     * Implementations must implement this method to map each row of data
     * in the ResultSet. This method should not call {@code next()} on
     * the ResultSet; it is only supposed to map values of the current row.
     *
     * @param rs     the ResultSet to map (pre-initialized for the current row)
     * @param rowNum the number of the current row
     * @return the result object for the current row (may be {@code null})
     * @throws SQLException if an SQLException is encountered getting
     *                      column values (that is, there's no need to catch SQLException)
     */
    @Override
    public AccBalanceTrend mapRow(ResultSet rs, int rowNum) throws SQLException {
        AccBalanceTrend accBalanceTrend = new AccBalanceTrend();
        accBalanceTrend.setAccNum(rs.getString("ACC_NUM"));
        accBalanceTrend.setCustNum(rs.getLong("CUST_NUM"));
        if (rs.getString("LEDG_BK_BAL") != null) {
            accBalanceTrend.setLedgBkBal(rs.getDouble("LEDG_BK_BAL"));
        }
        if (rs.getString("COLLECTED_BAL") != null) {
            accBalanceTrend.setCollectedBal(rs.getDouble("COLLECTED_BAL"));
        }
        if (rs.getString("OPENING_AVL_BAL") != null) {

            accBalanceTrend.setOpeningAvlBal(rs.getDouble("OPENING_AVL_BAL"));
        }
        if (rs.getString("AVAILABLE_AMOUNT_OF_LINE_TCY") != null) {
            accBalanceTrend.setAvailableAmountOfLineTcy(rs.getDouble("AVAILABLE_AMOUNT_OF_LINE_TCY"));
        }
        if (rs.getString("ONE_DY_FLT") != null) {
            accBalanceTrend.setOneDyFlt(rs.getDouble("ONE_DY_FLT"));
        }
        if (rs.getString("TWO_PLS_DY_FLT") != null) {
            accBalanceTrend.setTwoPlsDyFlt(rs.getDouble("TWO_PLS_DY_FLT"));
        }
        if (rs.getString("TOTAL_AMT_CR") != null) {
            accBalanceTrend.setTotalAmtCr(rs.getDouble("TOTAL_AMT_CR"));
        }
        if (rs.getString("TOTAL_AMT_DB") != null) {
            accBalanceTrend.setTotalAmtDb(rs.getDouble("TOTAL_AMT_DB"));
        }
        if (rs.getString("TOTEL_NUM_CR") != null) {
            accBalanceTrend.setTotalNumCr(rs.getInt("TOTEL_NUM_CR"));
        }
        if (rs.getString("TOTEL_NUM_DB") != null) {
            accBalanceTrend.setTotalNumDb(rs.getInt("TOTEL_NUM_DB"));
        }
        accBalanceTrend.setAsOfDt(rs.getTimestamp("AS_OF_DT"));
        if (rs.getString("LINE_AMOUNT_TCY") != null) {
            accBalanceTrend.setLineAmtTcy(rs.getDouble("LINE_AMOUNT_TCY"));
        }
        return accBalanceTrend;
    }
}
