package com.svb.gateway.migration.accountbalance.batch.processors;

import com.svb.gateway.migration.accountbalance.batch.dto.source.AccBalanceTrend;
import com.svb.gateway.migration.accountbalance.batch.dto.target.AcBalTrend;
import com.svb.gateway.migration.common.utility.MigrationConstants;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.beans.factory.annotation.Value;

@Slf4j
public class AccBalTrendProcessor implements ItemProcessor<AccBalanceTrend, AcBalTrend> {

    @Value("#{jobParameters['jobid']}")
    private long jobid;

    @Value("${serviceUser}")
    private String serviceUser;

    @Value("${globalBankId}")
    private String globalBankId;

    @Value("${globalBranchId}")
    private String globalBranchId;

    @Value("${insertDbTs}")
    private int insertDbTs;

    @Override
    public AcBalTrend process(final AccBalanceTrend accBalanceTrend) throws Exception {
        AcBalTrend acBalTrend = new AcBalTrend();

        acBalTrend.setDbTs(insertDbTs);
        acBalTrend.setBankId(globalBankId);
        acBalTrend.setBranchId(globalBranchId);
        acBalTrend.setDelFlg(MigrationConstants.N);
        acBalTrend.setRModId(serviceUser);
        acBalTrend.setRCreId(serviceUser);
        acBalTrend.setAcid(accBalanceTrend.getAccNum());
        acBalTrend.setLedgBkBal(accBalanceTrend.getLedgBkBal());
        acBalTrend.setCollectedBal(accBalanceTrend.getCollectedBal());
        acBalTrend.setOpeningAvlBal(accBalanceTrend.getOpeningAvlBal());
        acBalTrend.setAvailableAmtOfLineTcy(accBalanceTrend.getAvailableAmountOfLineTcy());
        acBalTrend.setOneDyFlt(accBalanceTrend.getOneDyFlt());
        acBalTrend.setTwoPlsDyFlt(accBalanceTrend.getTwoPlsDyFlt());
        acBalTrend.setTotelNumCr(accBalanceTrend.getTotalNumCr());
        acBalTrend.setTotalAmtCr(accBalanceTrend.getTotalAmtCr());
        acBalTrend.setTotelNumDb(accBalanceTrend.getTotalNumDb());
        acBalTrend.setTotalAmtDb(accBalanceTrend.getTotalAmtDb());
        acBalTrend.setAsOfDt(accBalanceTrend.getAsOfDt());
        acBalTrend.setLineAmtTcy(accBalanceTrend.getLineAmtTcy());
        acBalTrend.setCustNum(accBalanceTrend.getCustNum());
        return acBalTrend;
    }
}
