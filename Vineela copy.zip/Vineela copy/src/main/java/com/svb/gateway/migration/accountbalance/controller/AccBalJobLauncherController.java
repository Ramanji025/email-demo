package com.svb.gateway.migration.accountbalance.controller;

import com.svb.gateway.migration.accountbalance.api.AccBalJobLauncherApi;
import com.svb.gateway.migration.accountbalance.service.AccBalService;
import com.svb.gateway.migration.job.model.CreateJobResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;
import springfox.documentation.annotations.ApiIgnore;

import java.util.ArrayList;
import java.util.Date;

@ApiIgnore
@RestController
public class AccBalJobLauncherController implements AccBalJobLauncherApi {

    private Logger LOGGER = LoggerFactory.getLogger(AccBalJobLauncherController.class);

    @Autowired
    private AccBalService accBalService;

    @Override
    public ResponseEntity migrateAccBalTrend(Date fromDate, Date toDate, ArrayList<Long> cifIds) throws Exception {
        LOGGER.info("migrateAccBalTrend() started CIF ID's Count --> {}" , cifIds.size());
        CreateJobResponse result = accBalService.accBalJobLauncher(fromDate, toDate, cifIds);
        LOGGER.info("migrateAccBalTrend() Completed");
        return ResponseEntity.accepted().body(result);
    }

}
