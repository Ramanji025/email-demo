package com.svb.gateway.migration.accountbalance.service;

import com.svb.gateway.migration.job.model.CreateJobResponse;

import java.util.Date;
import java.util.List;

public interface AccBalService {

    CreateJobResponse accBalJobLauncher(final Date fromDate, final Date toDate, List<Long> cifIds) throws Exception ;
}
