package com.svb.gateway.migration.accountbalance.service;


import com.svb.gateway.migration.common.exception.InvalidInputException;
import com.svb.gateway.migration.job.model.CreateJobResponse;
import com.svb.gateway.migration.job.model.CreateJobResponseData;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;
import static com.svb.gateway.migration.common.utility.MigrationConstants.*;

@Service
public class AccBalServiceImpl implements AccBalService{

    private Logger LOGGER = LoggerFactory.getLogger(AccBalServiceImpl.class);

    @Autowired
    @Qualifier("migJobLauncher")
    private JobLauncher jobLauncher;

    @Autowired
    private Job moveAccBalTrendData;

    @Override
    public CreateJobResponse accBalJobLauncher(Date fromDate, Date toDate, List<Long> cifIds) throws Exception {

        long jobid = new Date().getTime();
        JobParametersBuilder builder = new JobParametersBuilder();
        builder.addLong(JOB_ID_KEY, jobid);
        if(fromDate != null && toDate != null){
            if (toDate.before(fromDate))
                throw new InvalidInputException(INVALID_DATE_RANGE);
            builder.addString(DATE_FILTER_REQUIRED_KEY, ONE);
            builder.addDate(FROM_DATE_KEY, fromDate);
            builder.addDate(TO_DATE_KEY, toDate);
        }
        else{
            builder.addString(DATE_FILTER_REQUIRED_KEY, ZERO);
        }
        if (cifIds.size() > 0) {
            builder.addString(CIF_ID, cifIds.stream().map(String::valueOf).collect(Collectors.joining(",")));
        } else {
            throw new InvalidInputException(MINIMUM_ONE_CIF_ID_IS_REQUIRED);
        }
        JobExecution jobExecution = jobLauncher.run(moveAccBalTrendData, builder.toJobParameters());
        String status = jobExecution.getStatus().name();
        LOGGER.info("accBalJobLauncher() - COMPLETE!.");
        return new CreateJobResponse(new CreateJobResponseData(jobid,status));
    }
}
