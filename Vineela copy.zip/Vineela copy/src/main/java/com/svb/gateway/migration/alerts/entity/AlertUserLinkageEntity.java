package com.svb.gateway.migration.alerts.entity;
import lombok.*;

import java.time.LocalDateTime;


@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode
@ToString
@Setter
@Getter
public class AlertUserLinkageEntity {

    private Integer dbTs;
    private String bankId;
    private String alertId;
    private String corpId;
    private String custId;
    private String alrtAcctId;
    private String relatedPartyId;
    private String hostId;
    private String userCategoryName;
    private String channel1;
    private String channel2;
    private String channel3;
    private String channel4;
    private String channel5;
    private String channel6;
    private String channel7;
    private String channel8;
    private String channel9;
    private String channel10;
    private String channel11;
    private String channel12;
    private Integer amount1;
    private Integer amount2;
    private Integer amount3;
    private Integer amount4;
    private Integer amount5;
    private Integer number1;
    private Integer number2;
    private Integer number3;
    private Integer number4;
    private Integer number5;
    private String entityCreFlg;
    private String delFlg;
    private String RModUserId;
    private LocalDateTime RModTime;
    private String RCreUserId;
    private LocalDateTime RCreTime;
    private String subscriptionType;
    private String freqId;
    private LocalDateTime alertStartDate;
    private LocalDateTime alertEndDate;
    private LocalDateTime nextGenDate;
    private String subscriptionNature;
    private String string1;
    private String string2;
    private String string3;
    private String string4;

}
