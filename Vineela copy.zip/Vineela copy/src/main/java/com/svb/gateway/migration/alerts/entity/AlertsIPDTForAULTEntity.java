package com.svb.gateway.migration.alerts.entity;
import lombok.*;


@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode
@ToString
@Setter
@Getter
public class AlertsIPDTForAULTEntity {

    private String alertId;
    private String fieldName;
    private String defaultValue;

}
