package com.svb.gateway.migration.alerts.entity;


import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.time.LocalDateTime;

@Getter
@Setter
@Entity
@Table(schema = "GWDMG", name = "MIG_ALERTS")
public class MigrationAlerts {

    @GeneratedValue(strategy=GenerationType.IDENTITY)
    @Id
    @Column(name = "ID")
    private Long id;

    @Column(name = "JOBID")
    private Long jobId;

    @Column(name = "EC_CLIENT_ID")
    private String ecClientId;

    @Column(name = "GW_CLIENT_ID")
    private String gwClientId;

    @Column(name = "EC_USERLOGIN_ID")
    private String ecUserLoginId;

    @Column(name ="CIF_NUMBER")
    private String cifNumber;

    @Column(name = "GW_UUID")
    private String gwUuid;

    @Column(name ="GW_ALERT_ID")
    private String gwAlertId;

    @Column(name ="GW_ALERT_ACCOUNT_ID")
    private String gwAlertAccountId;

    @Column(name = "STATUS")
    private String status;

    @Column(name = "COMMENTS")
    private String comments;

    @Column(name = "UPDATEDBY")
    private String updatedBy;

    @Column(name = "UPDATEDDATE")
    private LocalDateTime updatedDate;

}
