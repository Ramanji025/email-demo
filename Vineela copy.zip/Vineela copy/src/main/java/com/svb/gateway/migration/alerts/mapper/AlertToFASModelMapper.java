package com.svb.gateway.migration.alerts.mapper;

import com.svb.gateway.migration.alerts.entity.AlertUserLinkageEntity;
import com.svb.gateway.migration.alerts.entity.Alerts;
import com.svb.gateway.migration.alerts.entity.MigRefAlertMapping;
import com.svb.gateway.migration.alerts.model.MigAlertUser;
import com.svb.gateway.migration.common.utility.DateUtility;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import java.time.LocalDateTime;

@Mapper(componentModel="spring")
public interface AlertToFASModelMapper {
    AlertToFASModelMapper INSTANCE = Mappers.getMapper(AlertToFASModelMapper.class);

    public static String ZERO="0";
    public static String BANK_ID="SVB";
    public static String HOST_ID="EBNK";
    public static String USER_CATEGORY_NAME_DEFAULT="DEFAULT";
    public static String USER_CATEGORY_NAME_ACC_CAT="ACC_CAT";
    public static String CHANNEL1="D";
    public static String REGISTERED="D";
    public static String NOT_REGISTERED="A";
    public static String NOT_USED="X";
    public static String ENTITY_CRE_FLG="Y";
    public static String DEL_FLG="N";
    public static String R_USER_ID="FIVUSR";
    public static String SUBSCRIPTION_TYPE="R";
    public static String SUBSCRIPTION_NATURE="S";

    public static final String PST_TIME_ZONE="America/Los_Angeles";

    @Mapping(constant = "1",target="dbTs")
    @Mapping(constant=BANK_ID, target="bankId")
    @Mapping(source="migRefAlertMapping.gwAlertId", target="alertId")
    @Mapping(source="migrationUser.gwClientId", target="corpId")
    @Mapping(source="migrationUser.primaryCifUbs", target="custId")
    @Mapping(source="alert.ecAlertAccountId", target="alrtAcctId")
    @Mapping(source="migrationUser.gwUid", target="relatedPartyId")
    @Mapping(constant=HOST_ID, target="hostId")
    @Mapping(source="migRefAlertMapping.gwAlertType", target="userCategoryName")
    @Mapping(constant=CHANNEL1, target="channel1")
    @Mapping(expression="java(setChannel2(alert))", target="channel2")
    @Mapping(constant=NOT_USED, target="channel3")
    @Mapping(constant=NOT_USED, target="channel4")
    @Mapping(expression="java(setChannel5(alert))", target="channel5")
    @Mapping(constant=NOT_USED, target="channel6")
    @Mapping(constant=NOT_USED, target="channel7")
    @Mapping(constant=NOT_USED, target="channel8")
    @Mapping(constant=NOT_USED, target="channel9")
    @Mapping(constant=NOT_USED, target="channel10")
    @Mapping(constant=NOT_USED, target="channel11")
    @Mapping(constant=NOT_USED, target="channel12")
    @Mapping(expression="java(setAmount1(alert))", target="amount1")
    @Mapping(constant=ZERO, target="amount2")
    @Mapping(constant=ZERO, target="amount3")
    @Mapping(constant=ZERO, target="amount4")
    @Mapping(constant=ZERO, target="amount5")
    @Mapping(constant=ZERO, target="number1")
    @Mapping(constant=ZERO, target="number2")
    @Mapping(constant=ZERO, target="number3")
    @Mapping(constant=ZERO, target="number4")
    @Mapping(constant=ZERO, target="number5")
    @Mapping(constant=ENTITY_CRE_FLG, target="entityCreFlg")
    @Mapping(constant=DEL_FLG, target="delFlg")
    @Mapping(constant=R_USER_ID, target="RModUserId")
    @Mapping(expression="java(getPSTDate())", target="RModTime")
    @Mapping(constant=R_USER_ID, target="RCreUserId")
    @Mapping(expression="java(getPSTDate())", target="RCreTime")
    @Mapping(constant=SUBSCRIPTION_TYPE, target="subscriptionType")
    @Mapping(constant=ZERO, target="freqId")
    @Mapping(expression="java(getPSTDate())", target="alertStartDate")
    @Mapping(expression="java(getPSTDate())", target="nextGenDate")
    @Mapping(constant=SUBSCRIPTION_NATURE, target="subscriptionNature")
    AlertUserLinkageEntity convertSingleAlertToAULTData(Alerts alert, MigAlertUser migrationUser, MigRefAlertMapping migRefAlertMapping);


    default Integer setAmount1(Alerts alert){
        return alert.getThresholdAmount()==null? 0:alert.getThresholdAmount();
    }

    default String setChannel2(Alerts alert){
        return alert.getEcAlertDeliveryType()==1||alert.getEcAlertDeliveryType()==3 ? REGISTERED:NOT_REGISTERED;
    }

    default String setChannel5(Alerts alert){
        return alert.getEcAlertDeliveryType()==2||alert.getEcAlertDeliveryType()==3 ? REGISTERED:NOT_REGISTERED;
    }

    default LocalDateTime getPSTDate(){
        return DateUtility.getTimeZoneDate("America/Los_Angeles");
    }
}

