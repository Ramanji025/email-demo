package com.svb.gateway.migration.alerts.mapper;

import com.svb.gateway.migration.alerts.entity.MigratedAlertsEntity;
import com.svb.gateway.migration.alerts.entity.MigrationAlerts;
import com.svb.gateway.migration.common.constants.MigrationConstants;
import org.apache.ibatis.annotations.*;
import org.springframework.stereotype.Repository;

import java.util.List;


@Mapper
@Repository
public interface MigrationAlertsMapper {

    @Select(value = {
            "SELECT",
            "ID,JOBID,EC_CLIENT_ID,GW_CLIENT_ID,EC_USERLOGIN_ID,CIF_NUMBER,GW_UUID,GW_ALERT_ID,GW_ALERT_ACCOUNT_ID,COMMENTS,STATUS,UPDATEDBY,UPDATEDDATE",
            "FROM",
            "GWDMG.MIG_ALERTS",
            "WHERE",
            "JOBID=#{jobId} AND EC_CLIENT_ID=#{ecClientId} AND EC_USERLOGIN_ID=#{ecUserLoginId} AND GW_ALERT_ID=#{gwAlertId} ORDER BY UPDATEDDATE DESC FETCH FIRST 1 ROWS ONLY"
    })
    MigratedAlertsEntity checkIfMigratedIgnoredOrRolledBack(@Param("jobId") Long jobId,@Param("gwAlertId") String gwAlertId,@Param("ecClientId") String ecClientId,@Param("ecUserLoginId") String ecUserLoginId);

    @Insert(value = {
            "INSERT INTO",
            "GWDMG.MIG_ALERTS",
            "(JOBID,EC_CLIENT_ID,GW_CLIENT_ID,EC_USERLOGIN_ID,CIF_NUMBER,GW_UUID,GW_ALERT_ID,GW_ALERT_ACCOUNT_ID,COMMENTS,STATUS,UPDATEDBY,UPDATEDDATE)",
            "VALUES",
            "(#{jobId}, #{ecClientId}, #{gwClientId}, #{ecUserLoginId}, #{cifNumber}, #{gwUuid}, #{gwAlertId}, #{gwAlertAccountId}, #{comments}, #{status}, #{updatedBy}, #{updatedDate})"
    })
    @Options(useGeneratedKeys = true, keyProperty = "id", keyColumn = "ID")
    Integer insertSignedUpAlerts(MigrationAlerts migrationAlerts);

    @Update(value = {
            "UPDATE MIG_ALERTS set status='"+ MigrationConstants.STATUS_ROLLED_BACK+"'",
            "WHERE EC_CLIENT_ID=#{ecClientId} "
    })
    boolean rollback(@Param("ecClientId") String ecClientId);

    @Select(value = {
            "SELECT",
            "ID,JOBID,EC_CLIENT_ID,GW_CLIENT_ID,EC_USERLOGIN_ID,CIF_NUMBER,GW_UUID,GW_ALERT_ID,GW_ALERT_ACCOUNT_ID,COMMENTS,STATUS,UPDATEDBY,UPDATEDDATE",
            "FROM",
            "GWDMG.MIG_ALERTS",
            "WHERE",
            "JOBID=#{jobId} AND EC_CLIENT_ID=#{ecClientId} AND STATUS IN ('"+MigrationConstants.STATUS_FAILURE+"','"+MigrationConstants.STATUS_IGNORE+"')"
    })
    List<MigratedAlertsEntity> findByEcClientIdAndJobIdAndStatus(@Param("jobId") Long jobId,@Param("ecClientId") String ecClientId);

}
