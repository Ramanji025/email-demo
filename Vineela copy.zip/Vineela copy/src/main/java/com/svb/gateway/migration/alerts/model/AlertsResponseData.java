package com.svb.gateway.migration.alerts.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Builder;
import lombok.Getter;

import java.util.HashMap;
import java.util.Map;

@Builder
@Getter
public class AlertsResponseData {
    @JsonProperty("GWClientId")
    private String gwClientId;

    @JsonProperty("ECClientId")
    private String ecClientId;

    @JsonProperty("GWUuid")
    private String gwUuid;

    @JsonProperty("Cif_Number")
    private String cifNumber;

    @JsonProperty("Status")
    private String status;

    @JsonProperty("jobId")
    private Integer jobId;

    @JsonIgnore
    @Builder.Default
    private Map<String, Object> additionalProperties = new HashMap<>();

    @JsonProperty("recordCount")
    private RecordCount recordCount;
}
