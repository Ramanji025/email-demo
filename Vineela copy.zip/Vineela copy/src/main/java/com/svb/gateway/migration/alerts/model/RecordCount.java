package com.svb.gateway.migration.alerts.model;

import lombok.Getter;
import lombok.Setter;

import java.sql.Timestamp;

@Getter
@Setter
public class RecordCount {
    Integer total = 0;
    Integer success = 0;
    Integer failure = 0;
    private Timestamp startTime;
    private Timestamp endTime;
    private Long totalStepTime;

    public Long getTotalStepTime(){
        return (endTime.getTime()-startTime.getTime())/1000;
    }

}
