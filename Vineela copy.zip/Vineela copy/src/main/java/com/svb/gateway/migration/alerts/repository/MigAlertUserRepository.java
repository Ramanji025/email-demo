package com.svb.gateway.migration.alerts.repository;


import com.svb.gateway.migration.alerts.model.MigAlertUser;
import com.svb.gateway.migration.user.entity.MigUser;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;


public interface MigAlertUserRepository extends JpaRepository<MigUser, String> {

    @Query(value = "select mc.ecclientid as ecClientId, upper(mc.gwClientId) as gwClientId, mc.primarycifubs as primaryCifUbs, mu.ecUserLoginId as ecUserLoginId, upper(mu.gwuuid) as gwUid, mu.status as userStatus, " +
            "mc.status as clientStatus from mig_user mu inner join mig_client mc " +
            "on mc.ecclientid = mu.ecclientid and mc.gwClientId = mu.gwclientid " +
            "where mc.ecclientid=?1 and mu.ecUserLoginId=?2 and lower(mu.status)='success'", nativeQuery = true)
    MigAlertUser getMigratedAlertUser(String ecClientId,String ecUserLoginId);
}
