package com.svb.gateway.migration.alerts.repository;

import com.svb.gateway.migration.alerts.entity.MigRefAlertMapping;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface MigRefAlertMappingRepository extends JpaRepository<MigRefAlertMapping, String> {

    @Query(value = "SELECT * FROM MIG_REF_ALERT_MAPPING WHERE GW_ALERT_TYPE IN ('ACC_CAT','DEFAULT')", nativeQuery = true)
    List<MigRefAlertMapping> findGWMappingDetails();

}
