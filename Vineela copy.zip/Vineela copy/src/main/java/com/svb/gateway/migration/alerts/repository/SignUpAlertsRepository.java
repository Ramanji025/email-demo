package com.svb.gateway.migration.alerts.repository;

import com.svb.gateway.migration.alerts.entity.Alerts;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface SignUpAlertsRepository extends JpaRepository<Alerts, String> {

    @Query(value = "SELECT * FROM MIG_STG_USER_SIGNUP_ALERTS where EC_CLIENT_ID= ?1 and lower(EC_ALERT_TYPE)='signup'", nativeQuery = true)
    List<Alerts> findByEcClientId(String ecClientId);

}
