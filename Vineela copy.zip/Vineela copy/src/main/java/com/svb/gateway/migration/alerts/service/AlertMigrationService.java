package com.svb.gateway.migration.alerts.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.svb.gateway.migration.alerts.entity.*;
import com.svb.gateway.migration.alerts.mapper.AlertToFASModelMapper;
import com.svb.gateway.migration.alerts.mapper.AlertsToFASMapper;
import com.svb.gateway.migration.alerts.mapper.MigrationAlertsModelMapper;
import com.svb.gateway.migration.alerts.model.MigAlertUser;
import com.svb.gateway.migration.alerts.repository.MigAlertUserRepository;
import com.svb.gateway.migration.alerts.utils.Queries;
import com.svb.gateway.migration.cards.entity.MigCardProgram;
import com.svb.gateway.migration.cards.repository.MigCardProgramRepository;
import com.svb.gateway.migration.common.constants.MigrationConstants;
import com.svb.gateway.migration.common.exception.ServiceException;

import com.svb.gateway.migration.common.logging.Message;
import com.svb.gateway.migration.common.utility.DateUtility;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;


import java.time.LocalDateTime;
import java.util.Collection;
import java.util.Map;

@Log4j2
@Service
@Transactional(rollbackFor = Exception.class)
public class AlertMigrationService {

    private static final String UNIQUE_CONSTRAINT_FAILURE = "Unique Constraint Violated in Target";
    private static final String DATA_INTEGRITY_FAILURE = "Data Integrity Failure in Target";

    @Autowired
    AlertsToFASMapper alertsToFASMapper;

    @Autowired
    private MigAlertUserRepository migAlertUserRepository;

    @Autowired
    private MigCardProgramRepository migCardProgramRepository;

    @Qualifier("alertsFASNamedParameterJdbcTemplate")
    @Autowired
    private NamedParameterJdbcTemplate alertsFASJdbcTemplate;

    @Value(value="${alertSubscription.end.date.after.years}")
    Integer alertEndDateToAfterNYears;

    public MigrationAlerts insert(Alerts alert, MigRefAlertMapping migRefAlertMapping, Collection<AlertsIPDTForAULTEntity> inputDetailStringsToInsert) throws ServiceException {
        log.info(Message.create().clientId(alert.getEcClientId()).descr("Registering alert for client id : "+ alert.getEcClientId()+" GWAlertId : "+migRefAlertMapping.getGwAlertId()).entityName(Message.Entity.alert));
        MigrationAlerts migrationAlerts;
        MigAlertUser migAlertUser=migAlertUserRepository.getMigratedAlertUser(alert.getEcClientId(),alert.getEcUserLoginId());
        if (migAlertUser == null) {
            throw new ServiceException("User is not migrated for client Id having EcUserLoginId: ", alert.getEcUserLoginId());
        }

        try{
            validateClientCardProgramEnrollment(migAlertUser,alert);

            AlertUserLinkageEntity alertUserLinkageEntity= AlertToFASModelMapper.INSTANCE.convertSingleAlertToAULTData(alert, migAlertUser, migRefAlertMapping);
            alertUserLinkageEntity=setStringValues(alertUserLinkageEntity,inputDetailStringsToInsert);
            alertUserLinkageEntity.setAlertEndDate(setEndDateToAfterNYears());

            alertsFASJdbcTemplate.update(Queries.FAS_AULT_INSERT,retrieveInsertParameters(alertUserLinkageEntity));

            log.info(Message.create().clientId(alert.getEcClientId()).descr("Alert registered in FAS completed successfully for alert Id: "+ migRefAlertMapping.getGwAlertId()));
            migrationAlerts=setResponse(alert, migAlertUser, migRefAlertMapping, MigrationConstants.STATUS_SUCCESS,MigrationConstants.MIGRATED_SUCCESS);

        }
        catch(DuplicateKeyException duplicateKeyException){
            log.error(Message.create().clientId(alert.getEcClientId()).descr(duplicateKeyException.getMessage()));
            migrationAlerts=setResponse(alert, migAlertUser, migRefAlertMapping,  MigrationConstants.STATUS_FAILURE, UNIQUE_CONSTRAINT_FAILURE);
        }
        catch(DataIntegrityViolationException dataIntegrityViolationException){
            log.error(Message.create().clientId(alert.getEcClientId()).descr(dataIntegrityViolationException.getMessage()));
            migrationAlerts=setResponse(alert, migAlertUser, migRefAlertMapping, MigrationConstants.STATUS_FAILURE, DATA_INTEGRITY_FAILURE);
        }
        catch(Exception e){
            log.error(Message.create().clientId(alert.getEcClientId()).descr(e.getMessage()));
            migrationAlerts=setResponse(alert, migAlertUser, migRefAlertMapping, MigrationConstants.STATUS_FAILURE, e.getMessage());
        }
        return migrationAlerts;
    }

    private MigrationAlerts setResponse(Alerts alert, MigAlertUser migrationUser, MigRefAlertMapping migRefAlertMapping, String status, String message) {
        MigrationAlerts migrationAlerts= MigrationAlertsModelMapper.INSTANCE.mapSignedUpAlertToEntity(alert, migrationUser);
        migrationAlerts.setGwAlertId(migRefAlertMapping.getGwAlertId());
        if(null != migrationUser.getPrimaryCifUbs()){
            migrationAlerts.setCifNumber(migrationUser.getPrimaryCifUbs());
        }
        migrationAlerts.setStatus(status);
        migrationAlerts.setComments(message);
        return migrationAlerts;
    }

    private AlertUserLinkageEntity setStringValues(AlertUserLinkageEntity alertUserLinkageEntity,Collection<AlertsIPDTForAULTEntity> inputDetailStringsToInsert){
        inputDetailStringsToInsert.forEach(inputDetailsEntity -> {
            if(inputDetailsEntity.getFieldName().equalsIgnoreCase("STRING1")){
                alertUserLinkageEntity.setString1(inputDetailsEntity.getDefaultValue());
            }
            else if(inputDetailsEntity.getFieldName().equalsIgnoreCase("STRING2")){
                alertUserLinkageEntity.setString2(inputDetailsEntity.getDefaultValue());
            }
            else if(inputDetailsEntity.getFieldName().equalsIgnoreCase("STRING3")){
                alertUserLinkageEntity.setString3(inputDetailsEntity.getDefaultValue());
            }
            else if(inputDetailsEntity.getFieldName().equalsIgnoreCase("STRING4")){
                alertUserLinkageEntity.setString4(inputDetailsEntity.getDefaultValue());
            }
        });
        return alertUserLinkageEntity;
    }

    private void validateClientCardProgramEnrollment(MigAlertUser migrationUser, Alerts alert) throws ServiceException {
        if(alert.getAlertTypeName().startsWith("CAM_")){
            MigCardProgram migCardProgram=migCardProgramRepository.findByOlbIdAndCardProgram(migrationUser.getGwClientId(),alert.getEcAlertAccountId());
            if(migCardProgram==null){
                throw new ServiceException("Client is not associated with the card program", "Client is not associated with the card program: "+alert.getEcAlertAccountId());
            }
        }
    }

    private LocalDateTime setEndDateToAfterNYears(){
        LocalDateTime endDate= DateUtility.getTimeZoneDate("America/Los_Angeles");
        return endDate.plusYears(alertEndDateToAfterNYears);
    }

    private Map<String, Object> retrieveInsertParameters(AlertUserLinkageEntity alertUserLinkageEntity){
        ObjectMapper objectMapper = new ObjectMapper();
        return objectMapper.convertValue(alertUserLinkageEntity,Map.class);
    }

}
