package com.svb.gateway.migration.alerts.service;

import com.svb.gateway.migration.alerts.entity.*;
import com.svb.gateway.migration.alerts.mapper.InputDetailsRowMapper;
import com.svb.gateway.migration.alerts.mapper.MigrationAlertsMapper;
import com.svb.gateway.migration.alerts.mapper.MigrationAlertsModelMapper;
import com.svb.gateway.migration.alerts.model.AlertsResponse;
import com.svb.gateway.migration.alerts.model.AlertsResponseData;
import com.svb.gateway.migration.alerts.repository.MigRefAlertMappingRepository;
import com.svb.gateway.migration.alerts.repository.SignUpAlertsRepository;
import com.svb.gateway.migration.alerts.utils.Queries;
import com.svb.gateway.migration.client.entity.MigClient;
import com.svb.gateway.migration.common.constants.MigrationConstants;
import com.svb.gateway.migration.common.exception.ServiceException;
import com.svb.gateway.migration.common.logging.Message;
import com.svb.gateway.migration.common.mapper.MigrationEntityMapper;
import com.svb.gateway.migration.alerts.model.RecordCount;
import com.svb.gateway.migration.common.utility.EntityLogUtility;
import lombok.extern.log4j.Log4j2;
import org.apache.commons.collections4.MultiValuedMap;
import org.apache.commons.collections4.multimap.ArrayListValuedHashMap;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Service;

import java.sql.Timestamp;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicReference;


@Log4j2
@Service
public class AlertsService {

    public static final String NO_DATA_TO_MIGRATE = "No alerts to migrate for provided client Id";
    public static final String NO_ALERTS_TO_MIGRATE = "No alerts to migrate";
    public static final String ENTITY_NAME = "Alert Subscription";


    @Autowired
    private SignUpAlertsRepository signUpAlertsRepository;

    @Autowired
    private MigRefAlertMappingRepository migRefAlertMappingRepository;

    @Autowired
    private MigrationAlertsMapper migrationAlertsMapper;

    @Autowired
    private AlertMigrationService alertMigrationService;

    @Qualifier("alertsFASNamedParameterJdbcTemplate")
    @Autowired
    private NamedParameterJdbcTemplate alertsFASJdbcTemplate;

    @Autowired
    EntityLogUtility entityLogUtility;

    public AlertsResponse registerAlerts(Long jobId,MigClient migClient) throws ServiceException {
        return process(migClient,jobId);
    }

    protected AlertsResponse process(MigClient migClient,Long jobId)  throws ServiceException {
        AlertsResponse alertsResponse = new AlertsResponse();
        Message logMessage = Message.create().jobId(jobId).clientId(migClient.getEcClientId()).gwClientId(migClient.getGwClientId()).entityName(Message.Entity.alert);
        log.info(logMessage.descr("Entry: Registering alerts into Gateway"));
        final RecordCount recordCount=new RecordCount();
        recordCount.setStartTime(new Timestamp(System.currentTimeMillis()));

        final MigClient migratedClient = migClient;

        List<MigRefAlertMapping> migRefAlertMappingList = migRefAlertMappingRepository.findGWMappingDetails();
        MultiValuedMap<Integer, MigRefAlertMapping> eCtoGwReferenceMap = new ArrayListValuedHashMap<>();
        migRefAlertMappingList.forEach(migReference -> eCtoGwReferenceMap.put(migReference.getEcAlertTypeId(),migReference));

        List<AlertsIPDTForAULTEntity> alertsIPDTForAULTEntityList =alertsFASJdbcTemplate.query(Queries.FAS_IPDT_SELECT, new InputDetailsRowMapper());
        MultiValuedMap<String, AlertsIPDTForAULTEntity> inputDetailsReferenceMap = new ArrayListValuedHashMap<>();
        alertsIPDTForAULTEntityList.forEach(inputDetailsReference -> inputDetailsReferenceMap.put(inputDetailsReference.getAlertId(),inputDetailsReference));

        List<Alerts> alertsList = signUpAlertsRepository.findByEcClientId(migClient.getEcClientId());
        log.debug(logMessage.descr("AlertsService signUp alerts : " + alertsList));
        if (alertsList.isEmpty()) {
            recordCount.setEndTime(new Timestamp(System.currentTimeMillis()));
            entityLogUtility.saveEntityCountAndTimeLog(MigrationEntityMapper.INSTANCE.convertNoAlertsToMigEntity(migratedClient, recordCount, ENTITY_NAME));
            throw new ServiceException(NO_DATA_TO_MIGRATE, NO_ALERTS_TO_MIGRATE);
        }

        alertsList.stream().forEach(alert -> {

            log.debug(logMessage.descr("Registering alert : " + alert.toString()));

            Collection<MigRefAlertMapping> noOfGwAlertsToBeMapped=eCtoGwReferenceMap.get(alert.getAlertTypeId());
            noOfGwAlertsToBeMapped.stream().forEach(migReference -> {
                recordCount.setTotal(recordCount.getTotal()+1);
                AtomicReference<MigrationAlerts> newAlert= new AtomicReference<>(new MigrationAlerts());

                MigratedAlertsEntity migratedAlert= migrationAlertsMapper.checkIfMigratedIgnoredOrRolledBack(jobId,migReference.getGwAlertId(),alert.getEcClientId(),alert.getEcUserLoginId());
                if (migratedAlert!=null && !migratedAlert.canRunAgain()){
                    recordCount.setTotal(recordCount.getTotal()-1);
                    MigrationAlerts signedUpAlert= MigrationAlertsModelMapper.INSTANCE.mapAlreadySignedUpAlertToEntity(alert, migratedAlert);
                    createResponse(alertsResponse, recordCount, signedUpAlert, MigrationConstants.STATUS_SUCCESS);
                }
                else {
                    try{
                        Collection<AlertsIPDTForAULTEntity> inputDetailStringsToInsert=inputDetailsReferenceMap.get(migReference.getGwAlertId());
                        newAlert.set(alertMigrationService.insert(alert,migReference,inputDetailStringsToInsert));
                        updateCounter(recordCount, newAlert.get());
                        migrationAlertsMapper.insertSignedUpAlerts(newAlert.get());
                        createResponse(alertsResponse, recordCount, newAlert.get(), MigrationConstants.STATUS_SUCCESS);
                    }
                    catch (ServiceException e) {
                        log.error(logMessage.descr("Error occurred while processing alert "+ alert.getAlertsClientConfigId() +" reason : "+ e.getMessage()));
                        createResponse(alertsResponse, recordCount, newAlert.get(), MigrationConstants.STATUS_FAILURE);
                        alertsResponse.setAdditionalProperty(e.getErrorCode(), e.getErrorMessage());
                    }
                }
            });
        });
        recordCount.setEndTime(new Timestamp(System.currentTimeMillis()));
        if(recordCount.getTotal()>0){
            entityLogUtility.saveEntityCountAndTimeLog(MigrationEntityMapper.INSTANCE.convertAlertsToMigEntity(alertsResponse, recordCount));
        }

        log.info(logMessage.descr("Exit: Response for clientId "+ migClient.getEcClientId() + "is "+ alertsResponse.toString()));

        return alertsResponse;
    }

    private void updateCounter(RecordCount recordCount, MigrationAlerts newAlert) {
        if (MigrationConstants.STATUS_SUCCESS.equalsIgnoreCase(newAlert.getStatus())) {
            recordCount.setSuccess(recordCount.getSuccess() + 1);
        } else {
            recordCount.setFailure(recordCount.getFailure() + 1);
        }
    }

    private void createResponse(AlertsResponse alertsResponse, RecordCount recordCount, MigrationAlerts newAlert, String status) {
        alertsResponse.setAlertsResponseData(AlertsResponseData.builder()
                .gwClientId(newAlert.getGwClientId())
                .ecClientId(newAlert.getEcClientId())
                .gwUuid(newAlert.getGwUuid())
                .cifNumber(newAlert.getCifNumber())
                .jobId(newAlert.getJobId()==null?0:newAlert.getJobId().intValue())
                .status(status).recordCount(recordCount).build());
        alertsResponse.setAdditionalProperty("Total Records for client: " + newAlert.getEcClientId() + " is: ", recordCount.getTotal());
        alertsResponse.setAdditionalProperty("Total Successfully registered alert Records: ", recordCount.getSuccess());
        alertsResponse.setAdditionalProperty("Total Failed alert Records :", recordCount.getFailure());
    }

    public void rollBackAlerts(String ecClientId, String gwClientId) {
        Map<String, Object> paramMap = new HashMap<>();
        paramMap.put("id", gwClientId.toUpperCase());

        int deletedNoOfRecords = alertsFASJdbcTemplate.update(Queries.FAS_AULT_DELETE, paramMap);
        if (deletedNoOfRecords == 0) {
            log.info(Message.create().clientId(ecClientId).descr("No records were present in target to delete for GWClientId : "+gwClientId));
        } else {
            log.info(Message.create().clientId(ecClientId).descr(deletedNoOfRecords+" records deleted from target for GWClientId : "+gwClientId));
        }
        migrationAlertsMapper.rollback(ecClientId);
    }
}
