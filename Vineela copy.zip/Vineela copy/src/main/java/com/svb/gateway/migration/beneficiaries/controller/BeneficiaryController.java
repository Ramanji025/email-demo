package com.svb.gateway.migration.beneficiaries.controller;

import static com.svb.gateway.migration.beneficiaries.entity.StgToTargetBeneEntity.PAYEE_TYPE;
import com.svb.gateway.migration.beneficiaries.api.BeneficiaryApi;
import com.svb.gateway.migration.beneficiaries.model.MigBeneResponse;
import com.svb.gateway.migration.beneficiaries.service.BeneficiariesService;
import com.svb.gateway.migration.client.entity.MigClient;
import com.svb.gateway.migration.client.service.ClientService;
import org.apache.commons.text.StringEscapeUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import springfox.documentation.annotations.ApiIgnore;

@ApiIgnore
@RestController
public class BeneficiaryController implements BeneficiaryApi {
    private static final String LOG_API_REQUEST = "BeneficiaryController.addBeneficiaries, clientId: {} payeeType: {}";
    private static final Logger logger = LoggerFactory.getLogger(BeneficiaryController.class);

    private final BeneficiariesService beneficiariesService;
    private  final ClientService clientService;

    @Autowired
    public BeneficiaryController(BeneficiariesService beneficiariesService, ClientService clientService){
        this.beneficiariesService = beneficiariesService;
        this.clientService = clientService;
    }

    @Override
    public ResponseEntity<MigBeneResponse> addBeneficiaries(@PathVariable Long jobId, @PathVariable String clientId, @PathVariable String payeeType){
        logger.info(LOG_API_REQUEST,clientId, payeeType);
        try{
            MigClient migClient = clientService.getMigClient(StringEscapeUtils.escapeHtml4(clientId), jobId);
            return new ResponseEntity<>(beneficiariesService.addBeneficiaries(jobId, migClient, PAYEE_TYPE.fromString(StringEscapeUtils.escapeHtml4(payeeType))), HttpStatus.OK);
        }
        catch(Exception e){
            return new ResponseEntity<>(toErrorMessage(clientId, e.getMessage()), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    private MigBeneResponse toErrorMessage(String benfClientId, String message) {
        MigBeneResponse migBeneResponse = new MigBeneResponse();
        migBeneResponse.setGwClientId(benfClientId);
        migBeneResponse.setMessage(message);
        return migBeneResponse;
    }
}
