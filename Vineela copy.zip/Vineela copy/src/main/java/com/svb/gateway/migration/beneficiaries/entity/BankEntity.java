package com.svb.gateway.migration.beneficiaries.entity;

import lombok.*;

@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode
@ToString
@Setter
@Getter
public class BankEntity {

    private String BANK_REF_NO;
    private String NETWORK_TYPE;
    private String ROUTING_NO;
    private String ROUTING_NUMBER_SOURCE;
    private String INSTITUTION_NAME;
    private String ADDRESS;
    private String CITY_ZIPCODE;
    private String CITY;
    private String COUNTRY_CODE;
    private String BRANCH_NAME;
    private String ROUTING_TYPE;
    private String ROUTING_CODE;
    private String CLEARING_SYSTEM;
    private String ROUTING_CODE_STATUS;

}
