package com.svb.gateway.migration.beneficiaries.entity;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Getter
@Setter
@ToString
@Entity
@Table(schema = "OCHADM", name = "BANK_ROUTING_TABLE")
public class MigBeneBank {

    @Id
    @Column(name = "BANK_REF_NO")
    private String bankRefNo;

    @Column(name = "NETWORK_TYPE")
    private String networkType;

    @Column(name = "ROUTING_NUMBER_SOURCE")
    private String routingNumberSource;

    @Column(name = "SEQ_NO")
    private Integer seqNo;
    
}
