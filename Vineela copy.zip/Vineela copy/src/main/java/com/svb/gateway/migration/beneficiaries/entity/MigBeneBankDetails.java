package com.svb.gateway.migration.beneficiaries.entity;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Getter
@Setter
@ToString
@Entity
@Table(schema = "OCHADM", name = "BANK_DETAILS")
public class MigBeneBankDetails {

    @Id
    @Column(name = "BANK_REF_NO")
    private String bankRefNo;

    @Column(name = "COUNTRY_CODE")
    private String countryCode;

    @Column(name = "BRANCH_NAME")
    private String branchName;

    @Column(name = "ADDRESS")
    private String address;

    @Column(name = "ADDRESS2")
    private String address2;

    @Column(name = "ADDRESS3")
    private String address3;

    @Column(name = "CITY_ZIPCODE")
    private String cityZipCode;

}
