package com.svb.gateway.migration.beneficiaries.entity;

import lombok.*;
import java.util.Date;

@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode
@ToString
@Setter
@Getter
public class MigratedBeneficiaryEntity {

    private Integer clientMigId;
    private Long jobId;
    private String ecClientId;
    private String gwClientId;
    private String beneficiaryId;
    private String groupId;
    private String beneSourceType;
    private String beneSourceId;
    private Integer retried;
    private String comments;
    private String status;
    private String createdBy;
    private Date created_Dt;
    private Date modified_Dt;
}
