package com.svb.gateway.migration.beneficiaries.entity;

import lombok.*;

@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode
@ToString
@Setter
@Getter
public class SwiftBicPairEntity {

    private String BANK_REF_NO;
    private String SWIFT_BIC_PAIRING;
    private String ROUTING_NO;
    private String NETWORK_TYPE;
}
