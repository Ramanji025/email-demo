package com.svb.gateway.migration.beneficiaries.mapper;

import com.svb.gateway.migration.beneficiaries.entity.BankEntity;
import com.svb.gateway.migration.beneficiaries.entity.SwiftBicPairEntity;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;
import org.springframework.stereotype.Repository;

import java.util.List;

@Mapper
@Repository
public interface BankMapper {

    @Select(value = {
            "SELECT",
            "RT.BANK_REF_NO,RT.NETWORK_TYPE,RT.ROUTING_NO,RT.ROUTING_NUMBER_SOURCE,BD.INSTITUTION_NAME,BD.ADDRESS,BD.CITY_ZIPCODE,SUBSTR(BD.CITY_ZIPCODE,0,INSTR(BD.CITY_ZIPCODE,'|')-1) AS CITY,BD.COUNTRY_CODE,BD.BRANCH_NAME,NR.ROUTING_TYPE,NR.ROUTING_CODE,NR.CLEARING_SYSTEM,NR.ROUTING_CODE_STATUS",
            "FROM",
            "OCHADM.BANK_ROUTING_TABLE RT, OCHADM.BANK_DETAILS BD, OCHADM.BANK_ROUTING_ATTRIB_TABLE NR",
            "WHERE",
            "(RT.ROUTING_NO = #{bankIdentifier} OR RT.ROUTING_NUMBER_SOURCE = #{bankIdentifier}) AND RT.BANK_REF_NO=BD.BANK_REF_NO AND RT.ROUTING_NO=NR.ROUTING_CODE AND UPPER(NR.CLEARING_SYSTEM)='FEDWIRE'"
    })
    List<BankEntity> getBankBranchInfoWithNetworkReach(String bankIdentifier);

    @Select(value = {
            "SELECT",
            "RT.BANK_REF_NO,RT.NETWORK_TYPE,RT.ROUTING_NO,RT.ROUTING_NUMBER_SOURCE,BD.INSTITUTION_NAME,BD.ADDRESS,BD.CITY_ZIPCODE,SUBSTR(BD.CITY_ZIPCODE,0,INSTR(BD.CITY_ZIPCODE,'|')-1) AS CITY,BD.COUNTRY_CODE,BD.BRANCH_NAME",
            "FROM",
            "OCHADM.BANK_ROUTING_TABLE RT, OCHADM.BANK_DETAILS BD",
            "WHERE",
            "(RT.ROUTING_NO = #{bankIdentifier} OR RT.ROUTING_NUMBER_SOURCE = #{bankIdentifier}) AND RT.BANK_REF_NO=BD.BANK_REF_NO"
    })
    List<BankEntity> getBankBranchInfoWithOutNetworkReach(String bankIdentifier);

    @Select(value = {
            "SELECT",
            "BANK_REF_NO,SWIFT_BIC_PAIRING,ROUTING_NO,NETWORK_TYPE",
            "FROM",
            "OCHADM.CUSTOM_BANK_ROUTING_TABLE",
            "WHERE",
            "ROUTING_NO = #{bankIdentifier} AND DEL_FLG='N' AND SWIFT_BIC_PAIRING IS NOT NULL"
    })
    SwiftBicPairEntity getSwiftBicPairingRecord(String bankIdentifier);

    @Select(value = {
            "SELECT",
            "RT.BANK_REF_NO,RT.NETWORK_TYPE,RT.ROUTING_NO,RT.ROUTING_NUMBER_SOURCE,BD.INSTITUTION_NAME,BD.ADDRESS,BD.CITY_ZIPCODE,SUBSTR(BD.CITY_ZIPCODE,0,INSTR(BD.CITY_ZIPCODE,'|')-1) AS CITY,BD.COUNTRY_CODE,BD.BRANCH_NAME",
            "FROM",
            "OCHADM.BANK_ROUTING_TABLE RT, OCHADM.BANK_DETAILS BD",
            "WHERE",
            "(RT.ROUTING_NO = #{bankIdentifier} OR RT.ROUTING_NUMBER_SOURCE = #{bankIdentifier}) AND RT.BANK_REF_NO=BD.BANK_REF_NO"
    })
    List<BankEntity> getBankBranchInfoWithOutNetworkReachForSwiftBic(String bankIdentifier);

}