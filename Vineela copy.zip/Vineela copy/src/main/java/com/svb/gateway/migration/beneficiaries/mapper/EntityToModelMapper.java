package com.svb.gateway.migration.beneficiaries.mapper;

import com.svb.gateway.migration.beneficiaries.entity.StgToTargetBeneEntity;
import com.svb.gateway.migration.beneficiaries.model.EconnectSourceData;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

@Mapper(componentModel = "spring")
public interface EntityToModelMapper {

    EntityToModelMapper INSTANCE = Mappers.getMapper(EntityToModelMapper.class);

    @Mapping(expression="java(e.getSourceType(payeeType))", target = "sourceType")
    @Mapping(expression="java(e.getSourceBeneId(payeeType))", target = "sourceId")
    @Mapping(source = "e.OLB_CLIENT_ID", target = "clientId")
    @Mapping(source = "e.TEMPLATE_NAME", target = "templateName")
    @Mapping(source = "e.PAYMENT_TYPE", target = "paymentType")
    @Mapping(source = "e.ENTRYOP_NAME", target = "entryopName")
    @Mapping(source = "e.ENTRY_DATE", target = "entryDate")
    @Mapping(source = "e.APPROVE_LVL1_DATE", target = "approveLvl1Date")
    @Mapping(source = "e.CURRENT_STATE", target = "currentState")
    @Mapping(source = "e.APPROVE_LVL1OP_NAME", target = "approveLvl1OpName")
    @Mapping(source = "e.NEXT_STATE", target = "nextState")
    @Mapping(source = "e.APPROVE_LVL2OP_NAME", target = "approveLvl2OpName")
    @Mapping(source = "e.CANCELOP_NAME", target = "cancelopName")
    @Mapping(source = "e.CURRENCY_CODE", target = "currencyCode")
    @Mapping(source = "e.FOREX_AMOUNT", target = "forexAmount")
    @Mapping(source = "e.BENEFICIARY_BANK_IDENTIFIER", target = "beneficiaryBankIdentifier")
    @Mapping(source = "e.APPROVE_LVL2_DATE", target = "approveLvl2Date")
    @Mapping(source = "e.BENEFICIARY_ACCOUNT", target = "beneficiaryAccount")
    @Mapping(source = "e.CANCEL_DATE", target = "cancelDate")
    @Mapping(source = "e.BENEFICIARY_NAME", target = "beneficiaryName")
    @Mapping(source = "e.BENEFICIARY_ADDRESS_1", target = "beneficiaryAddress1")
    @Mapping(source = "e.BENEFICIARY_ADDRESS_2", target = "beneficiaryAddress2")
    @Mapping(source = "e.BENEFICIARY_ADDRESS_3", target = "beneficiaryAddress3")
    @Mapping(source = "e.BENEFICIARY_INSTRUCTIONS", target = "beneficiaryInstructions")
    @Mapping(source = "e.FURTHER_APPROVALS", target = "furtherApprovals")
    @Mapping(source = "e.TOTAL_APPROVALS", target = "totalApprovals")
    @Mapping(source = "e.BENEFICIARY_BANK_NAME", target = "beneficiaryBankName")
    @Mapping(source = "e.BENEFICIARY_BANK_ADDRESS", target = "beneficiaryBankAddress")
    @Mapping(source = "e.BENEFICIARY_BANK_CITY", target = "beneficiaryBankCity")
    @Mapping(source = "e.BENEFICIARY_BANK_CITY_ZIP", target = "beneficiaryBankCityZip")
    @Mapping(source = "e.BENEFICIARY_BANK_STATE", target = "beneficiaryBankState")
    @Mapping(source = "e.BENEFICIARY_BANK_COUNTRY", target = "beneficiaryBankCountry")
    @Mapping(source = "e.ENTRYOP_ID", target = "entryopId")
    @Mapping(source = "e.APPROVE_LVL1OP_ID", target = "approveLvl1OpId")
    @Mapping(source = "e.APPROVE_LVL2OP_ID", target = "approveLvl2OpId")
    @Mapping(source = "e.CANCELOP_ID", target = "cancelopId")
    @Mapping(source = "e.BANK_TO_BANK_INSTRUCTIONS", target = "bankToBankInstructions")
    @Mapping(source = "e.BENEFICIARY_BANK_SEARCH_MODE", target = "beneficiaryBankSearchMode")
    @Mapping(source = "e.IS_TEMPLATE_IMPORTED", target = "isTemplateImported")
    @Mapping(source = "e.ACCOUNT_IDENTIFIER", target = "fromAccountNumber")
    @Mapping(source = "e.ENTERED_AMT_IN_DEBIT_CURRENCY", target = "enteredAmtInDebitCurrency")
    @Mapping(source = "e.DEBITING_AMOUNT", target = "debitingAmount")
    @Mapping(source = "e.DEBITING_CURRENCY_CODE", target = "debitingCurrencyCode")
    @Mapping(source = "e.IS_DELETED", target = "isDeleted")
    @Mapping(source = "e.DELETEOP_NAME", target = "deleteopName")
    @Mapping(source = "e.DELETE_DATE", target = "deleteDate")
    @Mapping(source = "e.DELETEOP_ID", target = "deleteopId")
    @Mapping(source = "e.TEMPLATE_CODE", target = "templateCode")
    @Mapping(source = "e.IMPORT_FILE_INFO_ID", target = "importFileInfoId")
    @Mapping(source = "e.CHARGE_CODE_ID", target = "chargeCodeId")
    @Mapping(source = "e.BENEFICIARY_BANK_REGION", target = "beneficiaryBankRegion")
    @Mapping(source = "e.INTERMEDIARY_ID", target = "intermediaryId")
    @Mapping(source = "e.INTERMEDIARY_NAME", target = "intermediaryName")
    @Mapping(source = "e.INTERMEDIARY_ADDRESS", target = "intermediaryAddress")
    @Mapping(source = "e.IS_BENEFICIARY_ACC_SVB", target = "isBeneficiaryAccSvb")
    @Mapping(source = "e.IS_BENEFICIARY_ACC_SVB_DDA", target = "isBeneficiaryAccSvbDda")
    @Mapping(source = "e.PAYMENT_URGENCY", target = "paymentUrgency")
    @Mapping(source = "e.ROUTING_CODE", target = "routingCode")
    EconnectSourceData convertPaymentToMigEntity(StgToTargetBeneEntity e, StgToTargetBeneEntity.PAYEE_TYPE payeeType);

}
