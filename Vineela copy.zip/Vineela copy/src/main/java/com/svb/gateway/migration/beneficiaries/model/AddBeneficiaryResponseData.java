package com.svb.gateway.migration.beneficiaries.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModelProperty;

import javax.validation.constraints.NotNull;
import java.util.List;

public class AddBeneficiaryResponseData {

    @JsonProperty("counterpartyName")
    private String counterpartyName;

    @JsonProperty("groupId")
    private String groupId;

    @JsonProperty("status")
    private Status status;

    public String getCounterpartyName() {
        return counterpartyName;
    }

    public void setCounterpartyName(String counterpartyName) {
        this.counterpartyName = counterpartyName;
    }

    @JsonProperty("paymentDetails")
    private List<ResponsePaymentDetail> paymentDetails;

    public String getGroupId() {
        return groupId;
    }

    public void setGroupId(String groupId) {
        this.groupId = groupId;
    }

    @ApiModelProperty(required = true, value = ".")
    @NotNull
    public Status getStatus() {
        return status;
    }

    public void setStatus(Status status) {
        this.status = status;
    }

    public List<ResponsePaymentDetail> getPaymentDetails() {
        return paymentDetails;
    }

    public void setPaymentDetails(List<ResponsePaymentDetail> paymentDetails) {
        this.paymentDetails = paymentDetails;
    }
}
