package com.svb.gateway.migration.beneficiaries.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@JsonInclude(JsonInclude.Include.NON_NULL)
public class BankBranchResponseData {

    @JsonProperty("bankName")
    private String bankName;

    @JsonProperty("branchName")
    private String branchName;

    @JsonProperty("bankClearingCode")
    private String bankClearingCode;

    @JsonProperty("bankRefNo")
    private String bankRefNo;

    @JsonProperty("routingCodeAlt")
    private String routingCodeAlt;

    @JsonProperty("branchAddress")
    private BranchAddress branchAddress;

    @JsonProperty("network")
    private Network network;
}
