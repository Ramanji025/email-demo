package com.svb.gateway.migration.beneficiaries.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@JsonInclude(JsonInclude.Include.NON_NULL)
public class BeneIbanAccountRule {

    @JsonProperty("ibanRequired")
    private String ibanRequired;

    @JsonProperty("accountNumberType")
    private String accountNumberType;

    @JsonProperty("accountNumberRegex")
    private String accountNumberRegex;

    @JsonProperty("iban")
    private IbanFormatRule iban;

}
