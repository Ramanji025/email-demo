package com.svb.gateway.migration.beneficiaries.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "addressLine1",
        "addressLine2",
        "addressLine3",
        "city",
        "zipCode",
        "state",
        "country"
})
public class BeneficiaryAddress {

    @JsonProperty("addressLine1")
    private String addressLine1="";

    @JsonProperty("addressLine2")
    private String addressLine2="";

    @JsonProperty("addressLine3")
    private String addressLine3;

    @JsonProperty("city")
    private String city="";

    @JsonProperty("zipCode")
    private String zipCode="";

    @JsonProperty("state")
    private String state="";

    @JsonProperty("country")
    private String country="";


    @Override
    public String toString() {
        return "BeneficiaryAddress{" +
                "addressLine1='" + addressLine1 + '\'' +
                ", addressLine2='" + addressLine2 + '\'' +
                ", addressLine3='" + addressLine3 + '\'' +
                ", city='" + city + '\'' +
                ", zipCode='" + zipCode + '\'' +
                ", state='" + state + '\'' +
                ", country='" + country + '\'' +
                '}';
    }
}
