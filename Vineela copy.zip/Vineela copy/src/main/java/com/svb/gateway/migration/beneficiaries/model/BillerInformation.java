package com.svb.gateway.migration.beneficiaries.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "largeBillerId",
        "billeraddressId",
        "billerType"
})
public class BillerInformation {
    @JsonProperty("largeBillerId")
    private String largeBillerId;

    @JsonProperty("billeraddressId")
    private String billeraddressId;

    @JsonProperty("billerType")
    private String billerType;
}
