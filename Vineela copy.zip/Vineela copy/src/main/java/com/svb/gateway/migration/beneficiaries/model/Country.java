package com.svb.gateway.migration.beneficiaries.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Country {

    @JsonProperty("codeType")
    private String codeType;

    @JsonProperty("cmCode")
    private String cmCode;

    @JsonProperty("codeDescription")
    private String codeDescription;

    @Override
    public String toString() {
        return "Country{" +
                "codeType='" + codeType + '\'' +
                ", cmCode='" + cmCode + '\'' +
                ", codeDescription='" + codeDescription + '\'' +
                '}';
    }
}
