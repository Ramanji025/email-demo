package com.svb.gateway.migration.beneficiaries.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "migrationJobId",
        "pendingRecipientId",
        "status",
        "message",
})
public class ErrorQueueResponse {
    private Long migrationJobId;
    private Long pendingRecipientId;
    private String status;
    private String message;

    @Override
    public String toString() {
        return "ErrorQueueResponse{" +
                "migrationJobId='" + migrationJobId + '\'' +
                ", pendingRecipientId='" + pendingRecipientId + '\'' +
                ", status='" + status + '\'' +
                ", message='" + message + '\'' +
                '}';
    }
}
