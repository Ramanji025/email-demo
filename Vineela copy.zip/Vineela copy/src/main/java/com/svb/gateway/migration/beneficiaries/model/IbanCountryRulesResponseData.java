package com.svb.gateway.migration.beneficiaries.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@JsonInclude(JsonInclude.Include.NON_NULL)
public class IbanCountryRulesResponseData {

    @JsonProperty("iso2CountryCode")
    private String iso2CountryCode;

    @JsonProperty("iso3CountryCode")
    private String iso3CountryCode;

    @JsonProperty("currency")
    private String currency;

    @JsonProperty("countryCodeinSWIFTCode")
    private String countryCodeinSWIFTCode;

    @JsonProperty("beneficaryAccount")
    private BeneIbanAccountRule beneficaryAccount;

    @JsonProperty("beneficiaryBankInfo")
    private BeneBankInfoRule beneficiaryBankInfo;

}
