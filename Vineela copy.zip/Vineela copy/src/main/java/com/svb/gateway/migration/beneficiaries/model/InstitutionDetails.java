package com.svb.gateway.migration.beneficiaries.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@JsonInclude(JsonInclude.Include.NON_NULL)
public class InstitutionDetails {

    @JsonProperty("bban")
    private String bban;

    @JsonProperty("branchCode")
    private String branchCode;

    @JsonProperty("branchName")
    private String branchName;

    @JsonProperty("countryCode")
    private String countryCode;

    @JsonProperty("iban")
    private String iban;

    @JsonProperty("instName")
    private String instName;

    @JsonProperty("instNameOverride")
    private String instNameOverride;

    @JsonProperty("routingNo")
    private String routingNo;

    @JsonProperty("street")
    private String street;

    @JsonProperty("swiftBIC")
    private String swiftBIC;

    @JsonProperty("swiftOverride")
    private String swiftOverride;

    @JsonProperty("postal")
    private String postal;

}
