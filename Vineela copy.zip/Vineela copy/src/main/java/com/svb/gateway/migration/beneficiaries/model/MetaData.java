package com.svb.gateway.migration.beneficiaries.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class MetaData {
    @JsonProperty("sourceType")
    private String sourceType;

    @JsonProperty("migrationJobId")
    private Long migrationJobId;
}
