package com.svb.gateway.migration.beneficiaries.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "gwClientId", "resultRecords"
})
public class MigBeneResponse {

    @JsonProperty("gwClientId")
    private String gwClientId;

    @JsonProperty("noOfSuccessRecords")
    private Integer noOfSuccessRecords;

    @JsonProperty("noOfFailedRecords")
    private Integer noOfFailedRecords;

    @JsonProperty("noOfAlreadyMigratedRecords")
    private Integer noOfAlreadyMigratedRecords;

    @JsonProperty("resultRecords")
    private List<ResultRecords> resultRecords;

    @JsonProperty("message")
    private String message;

    @Override
    public String toString() {
        return "MigBeneResponse{" +
                "gwClientId='" + gwClientId + '\'' +
                ", noOfSuccessRecords=" + noOfSuccessRecords +
                ", noOfFailedRecords=" + noOfFailedRecords +
                ", noOfAlreadyMigratedRecords=" + noOfAlreadyMigratedRecords +
                ", resultRecords=" + resultRecords +
                '}';
    }
}
