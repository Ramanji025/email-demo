package com.svb.gateway.migration.beneficiaries.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ResponseBankDetails {

    @JsonProperty("isExistingBank")
    private String isExistingBank;

    @JsonProperty("counterpartyBank")
    private String counterpartyBank;

    @JsonProperty("bankIdentifier")
    private String bankIdentifier;

    @JsonProperty("localRoutingCode")
    private String localRoutingCode;

    @JsonProperty("bankRefNum")
    private String bankRefNum;

    @JsonProperty("networkType")
    private String networkType;

    @JsonProperty("bankName")
    private String bankName;

    @JsonProperty("branchName")
    private String branchName;

    @JsonProperty("address")
    private String address;

    @JsonProperty("city")
    private String city;

    @JsonProperty("zipCode")
    private String zipCode;

    @JsonProperty("state")
    private State state;

    @JsonProperty("country")
    private Country country;

    @Override
    public String toString() {
        return "ResponseBankDetails{" +
                "isExistingBank='" + isExistingBank + '\'' +
                ", counterpartyBank='" + counterpartyBank + '\'' +
                ", bankIdentifier='" + bankIdentifier + '\'' +
                ", localRoutingCode='" + localRoutingCode + '\'' +
                ", bankRefNum='" + bankRefNum + '\'' +
                ", networkType='" + networkType + '\'' +
                ", bankName='" + bankName + '\'' +
                ", branchName='" + branchName + '\'' +
                ", address='" + address + '\'' +
                ", city='" + city + '\'' +
                ", zipCode='" + zipCode + '\'' +
                ", state=" + state +
                ", country=" + country +
                '}';
    }
}
