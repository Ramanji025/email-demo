package com.svb.gateway.migration.beneficiaries.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Status {

    @JsonProperty("codeType")
    private String codeType;

    @JsonProperty("cmCode")
    private String cmCode;

    @JsonProperty("codeDescription")
    private String codeDescription;

    @Override
    public String toString() {
        return "Status{" +
                "codeType='" + codeType + '\'' +
                ", cmCode='" + cmCode + '\'' +
                ", codeDescription='" + codeDescription + '\'' +
                '}';
    }
}
