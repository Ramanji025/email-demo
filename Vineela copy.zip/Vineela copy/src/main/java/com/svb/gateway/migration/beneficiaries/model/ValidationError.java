package com.svb.gateway.migration.beneficiaries.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ValidationError {

    //Validation Failure       Fields impacted                     Exception type          Exception message (Description)                 Code        Field
//    Address doctor validation failed Street Address          Error               Recipient address incorrect or incomplete.  ERR1001 streetAddress
//    Address doctor validation not available  Street Address  Warning             Recipient address to be reviewed.           WAR1001 streetAddress
//    Length of the field      Street Address                      Error                   Field length exceeded.                          ERR1002     streetAddress
//    City     streetAddress
//    State/Province   streetAddress
//    Account number   accountNumber
//    Routing number/ SWIFT BIC        routingNumber
//    Bank Name        bankName
//    Bank location    bankLocation
//    IBAN validation  Account number                          Error               Invalid Recipient IBAN.                         ERR1003     accountNumber
//    Account number Regex     Account number                      Error                   Account number incorrect.                   ERR1004 accountNumber
//    ABA/ SWIFT BIC failure   ABA/ SWIFT BIC                  Error               Routing number incorrect.                   ERR1005 routingNumber
//    ABA Fed Reachability failure     Routing number              Error                   Routing number incorrect.                   ERR1006 routingNumber
//    Local Routing code required      Local Routing code              Error               Local Routing code required.                    ERR1007     localRoutingCode

    public static final String ERR1001 = "ERR1001";
    public static final String RECIPIENT_ADDRESS_INCORRECT = "Recipient address incorrect or incomplete.";
    public static final String ADDRESS_FIELD = "streetAddress";

    public static final String WAR1001 = "WAR1001";
    public static final String RECIPIENT_ADDRESS_TO_BE_REVIEWED = "Recipient address to be reviewed.";

    public static final String ERR1002 = "ERR1002";
    public static final String FIELD_LENGTH_EXCEEDED = "Field length exceeded.";

    public static final String ERR1003 = "ERR1003";
    public static final String INVALID_IBAN = "Invalid Recipient IBAN.";
    public static final String ACCOUNT_NUMBER_FIELD = "accountNumber";

    public static final String ERR1004 = "ERR1004";
    public static final String ACCOUNT_NUMBER_INCORRECT = "Account number incorrect.";

    public static final String ERR1005 = "ERR1005";
    public static final String ERR1006 = "ERR1006";
    public static final String ROUTING_NUMBER_INCORRECT = "Routing number incorrect.";
    public static final String ROUTING_NUMBER_FIELD = "routingNumber";

    public static final String ERR1007 = "ERR1007";
    public static final String LOCAL_ROUTING_CODE_REQUIRED = "Local Routing code required.";
    public static final String LOCAL_ROUTING_CODE_FIELD = "localRoutingCode";

    public ValidationError(){}

    public ValidationError(String code, String description, String fieldName) {
        this.code = code;
        this.description = description;
        this.fieldName = fieldName;
    }

    @JsonProperty("code")
    private String code;

    @JsonProperty("description")
    private String description;//will change to fieldValue

    @JsonProperty("fieldName")
    private String fieldName;

    private String rawError;
}