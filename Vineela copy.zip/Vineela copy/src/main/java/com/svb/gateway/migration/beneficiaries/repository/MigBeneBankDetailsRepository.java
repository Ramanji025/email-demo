package com.svb.gateway.migration.beneficiaries.repository;

import com.svb.gateway.migration.beneficiaries.entity.MigBeneBankDetails;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;


@Repository
public interface MigBeneBankDetailsRepository extends JpaRepository<MigBeneBankDetails, String> {

    @Query(value = "SELECT * FROM OCHADM.BANK_DETAILS  WHERE BANK_REF_NO = ?1 AND DEL_FLG='N' FETCH FIRST 1 ROWS ONLY",nativeQuery=true)
    MigBeneBankDetails findByBankRefNo(String bankRefNo);
}
