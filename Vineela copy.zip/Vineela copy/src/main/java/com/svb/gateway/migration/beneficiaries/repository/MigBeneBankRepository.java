package com.svb.gateway.migration.beneficiaries.repository;

import com.svb.gateway.migration.beneficiaries.entity.MigBeneBank;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;


@Repository
public interface MigBeneBankRepository extends JpaRepository<MigBeneBank, String> {

    @Query(value = "SELECT * FROM OCHADM.BANK_ROUTING_TABLE  WHERE DEL_FLG='N' AND (ROUTING_NO = ?1 OR ROUTING_NUMBER_SOURCE = ?1) FETCH FIRST 1 ROWS ONLY",nativeQuery=true)
    MigBeneBank findByBankIdentifier(String bankIdentifier);
}