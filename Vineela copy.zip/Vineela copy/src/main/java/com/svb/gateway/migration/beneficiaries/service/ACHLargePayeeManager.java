package com.svb.gateway.migration.beneficiaries.service;

import static com.svb.gateway.migration.beneficiaries.entity.StgToTargetBeneEntity.PAYEE_TYPE.ACH_LARGE;
import static com.svb.gateway.migration.common.constants.MigrationConstants.*;
import com.svb.gateway.migration.beneficiaries.entity.MigBeneficiary;
import com.svb.gateway.migration.beneficiaries.entity.StgToTargetBeneEntity;
import com.svb.gateway.migration.beneficiaries.mapper.MigBeneficiaryMapper;
import com.svb.gateway.migration.beneficiaries.mapper.SelectConditions;
import com.svb.gateway.migration.beneficiaries.model.*;
import com.svb.gateway.migration.beneficiaries.repository.BeneficiaryRepository;
import com.svb.gateway.migration.beneficiaries.repository.MigBeneficiaryRepository;
import com.svb.gateway.migration.client.entity.MigClient;
import com.svb.gateway.migration.common.exception.ServiceException;
import com.svb.gateway.migration.common.logging.Message;
import com.svb.gateway.migration.common.model.AddressResponse;
import com.svb.gateway.migration.common.utility.AddressDoctor;
import com.svb.gateway.migration.common.utility.CacheManagerUtility;
import com.svb.gateway.migration.common.service.RetryService;
import org.springframework.core.ParameterizedTypeReference;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
@Log4j2
@Service
public class ACHLargePayeeManager extends BeneficiaryBaseManager {
    private static final String IS_LARGEBILLER_Y = "Y";
    private static final String OLB_CLIENT_ID = "olbClientId";
    private static final String ADDRESS_ZIP = "addressZip";
    private static final String SEARCH_STRING = "searchString";
    private static final String ADDRESSES = "addresses";

    @Value(value = "Fetch Biller Info API CorrelationId")
    String migLargeBillerCorrelationId;

    @Value("${header.service.token}")
    String token;

    @Value("${mig.largebillerNetworkFetch.url}")
    String fetchBillerNetworkUrl;

    public ACHLargePayeeManager(MigBeneficiaryMapper migBeneficiaryMapper, MigBeneficiaryRepository migBeneficiaryRepository, BeneficiaryRepository beneficiaryRepository, CacheManagerUtility cacheManagerUtility, BeneficiaryValidationUtility beneficiaryValidationUtility, AddressDoctor addressDoctor, RetryService retryService) {
        super(migBeneficiaryMapper, migBeneficiaryRepository, beneficiaryRepository, cacheManagerUtility, beneficiaryValidationUtility, addressDoctor, retryService);
    }

    @Override
    protected StgToTargetBeneEntity.PAYEE_TYPE payeeType(){return ACH_LARGE;}

    @Override
    public boolean hasCounterPartyNickName() { return true; }

    @Override
    public boolean hasPayeePhoneNumber() { return true; }

    @Autowired
    public void setRetryService( RetryService retryService){
        super.retryService = retryService;
    }

    public RetryService getRetryService(){
        return super.retryService;
    }

    @Override
    protected void validateAddressResponseAndSetAddressInRequest(BeneficiaryAddress beneficiaryAddress, AddressResponse addressResponse, EntityWrapper entityWrapper) {
        if (addressResponse==null || !VALID_ADDRESS_RESPONSE.equalsIgnoreCase(addressResponse.getValidationscore())) {
            // No validation required for ACH Large
            beneficiaryAddress.setAddressLine1("");
            beneficiaryAddress.setAddressLine2("");
            beneficiaryAddress.setCity("");
            beneficiaryAddress.setZipCode("");
            beneficiaryAddress.setState("");
        }
        else{
            beneficiaryAddress.setAddressLine1(addressResponse.getCleansedaddrln1());
            beneficiaryAddress.setAddressLine2(addressResponse.getCleansedaddrln2()+" "+addressResponse.getCleansedaddrln3());
            beneficiaryAddress.setCity(addressResponse.getCleansedcitynm());
            beneficiaryAddress.setZipCode(addressResponse.getCleansedzipcd());
            beneficiaryAddress.setState(addressResponse.getCleansedstatecd());
        }
    }

    @Override
    protected BeneficiaryAddress getAddress(EntityWrapper entityWrapper, MigClient migClient, BankBranchResponse bankBranchResponse, AccountDetails accountDetails, Long jobId) {
        BeneficiaryAddress beneficiaryAddress=new BeneficiaryAddress();
        String completeAddr = getCompleteAddr(entityWrapper.getEntity());
        AddressResponse addressResponse = addressDoctor.validateAddress(DEFAULT_COUNTRY_CODE, completeAddr, entityWrapper);
        validateAddressResponseAndSetAddressInRequest(beneficiaryAddress, addressResponse, entityWrapper);
        beneficiaryAddress.setCountry(DEFAULT_COUNTRY_CODE);
        return beneficiaryAddress;
    }

    /**
     * This method intentionally returns null because we do not validate the bank branch for ACH Large.
     * @param entityWrapper
     * @return
     */
    @Override
    public BankBranchResponse validateBankBranch(EntityWrapper entityWrapper, AccountDetails a, MigClient m) {
        // do not validate for ACH Large
        return null;
    }

    @Override
    public List<PaymentDetail> getPaymentDetails(EntityWrapper entityWrapper, MigClient migClient, AccountDetails accountDetails, BankDetails bankDetails)
    {

        LargeBillerInformationResponse largeBillerInformationResponse;
        PaymentDetail paymentDetail=new PaymentDetail();
        paymentDetail.setRequestType(REQUEST_TYPE);
        paymentDetail.setPreferredFlag(PREFERRED_FLAG);
        accountDetails.setAccountId(entityWrapper.getEntity().getBENEFICIARY_ACCOUNT());
        largeBillerInformationResponse = fetchLargeBillerInfo(entityWrapper, migClient);
        BillerInformation billerInformation = new BillerInformation();
        if(largeBillerInformationResponse!=null && largeBillerInformationResponse.getData()!=null
                && largeBillerInformationResponse.getData().get(0)!=null) {
            billerInformation.setBilleraddressId(largeBillerInformationResponse.getData().get(0).getAddressId());
            billerInformation.setLargeBillerId(largeBillerInformationResponse.getData().get(0).getLargeBillerId());
            billerInformation.setBillerType(largeBillerInformationResponse.getBillerType());
        }
        paymentDetail.setPaymentMethod(PAYMENT_METHOD_ACH);
        paymentDetail.setAccountDetails(accountDetails);
        paymentDetail.setCustomerAccountNumber(entityWrapper.getEntity().getBENEFICIARY_ACCOUNT());
        paymentDetail.setBillerInformation(billerInformation);
        paymentDetail.setIsLargeBiller(IS_LARGEBILLER_Y);
        List<PaymentDetail> paymentDetails = new ArrayList<>();
        paymentDetails.add(paymentDetail);
        return paymentDetails;
    }

    private LargeBillerInformationResponse fetchLargeBillerInfo(EntityWrapper entityWrapper, MigClient migClient) {
        Message message = Message.create().clientId(entityWrapper.getEntity().getOLB_CLIENT_ID()).jobId(entityWrapper.getEntity().getJOB_ID()).operation("largeBiller");
        //Fetch Largebiller network id
        try{
            ResponseEntity<LargeBillerResponse> largeBillerResponseEntity;
            LargeBillerResponse largeBillerResponse = new LargeBillerResponse();

            ResponseEntity<LargeBillerInformationResponse> largeBillerInformationResponseEntity;
            LargeBillerInformationResponse largeBillerInformationResponse = new LargeBillerInformationResponse();

            HttpHeaders billerNetworkheaders = new HttpHeaders();
            billerNetworkheaders.add(CONTENT_TYPE, APPLICATION_HEADER_JSON);

            HttpEntity<?> requestEntity = new HttpEntity<>(billerNetworkheaders);

            String queryPart = "?" + OLB_CLIENT_ID + "="
                    + migClient.getGwClientId()+ "&" + ADDRESS_ZIP + "=" +entityWrapper.getEntity().getPAYEE_ZIP_CODE()
                    + "&" + SEARCH_STRING + "=" +entityWrapper.getEntity().getBENEFICIARY_NAME();
            String finalFetchBillerNetworkInfoUrl = fetchBillerNetworkUrl + queryPart;
            message.url(finalFetchBillerNetworkInfoUrl);
            log.info(message);
            largeBillerResponseEntity = retryService.exchange(finalFetchBillerNetworkInfoUrl, HttpMethod.GET, requestEntity, new ParameterizedTypeReference<LargeBillerResponse>() {});
            LargeBillerResponse largeBillerBody = largeBillerResponseEntity.getBody();
            if(largeBillerBody!=null) {
                List<LargeBillerResponseData> data = largeBillerBody.getData();
                String finalFetchBillerInformationUrl = fetchBillerNetworkUrl + SLASH + data.get(0).getNetworkId()
                        + SLASH + ADDRESSES + queryPart;
                log.info(message.url(finalFetchBillerInformationUrl).descr("largeBillerInformation"));
                if (HttpStatus.OK.equals(largeBillerResponseEntity.getStatusCode())) {
                    largeBillerResponse.setData(data);
                    if (null != largeBillerResponse.getData() && null != largeBillerResponse.getData().get(0).getNetworkId()) {
                        //FetchBillerAddress Information

                        largeBillerInformationResponseEntity = retryService.exchange(finalFetchBillerInformationUrl, HttpMethod.GET, requestEntity, new ParameterizedTypeReference<LargeBillerInformationResponse>() {});
                        if (HttpStatus.OK.equals(largeBillerInformationResponseEntity.getStatusCode())) {
                            List<LargeBillerInformationResponseData> largeBillerInformationResponseDataList = largeBillerInformationResponseEntity.getBody().getData();
                            largeBillerInformationResponse.setData(largeBillerInformationResponseDataList);
                            largeBillerInformationResponse.setBillerType(largeBillerResponse.getData().get(0).getType());
                        } else {
                            entityWrapper.addUnexpectedError("fethcing information for large biller", "error code "+largeBillerInformationResponseEntity.getStatusCode());
                        }
                    }
                } else {
                    entityWrapper.addUnexpectedError("fethcing large biller", "error code "+largeBillerResponseEntity.getStatusCode());
                }
            }
            return largeBillerInformationResponse;
        }
        catch(Exception e){
            String source = "fetching large biller";
            log.error(message.errorSource(source).descr(e.getMessage()));
            entityWrapper.addUnexpectedError(source, e.getMessage());
        }
        return null;
    }

    @Override
    public void setPaymentMethodAndIsPersonalAccount(PaymentDetail paymentDetail) {
        paymentDetail.setPaymentMethod(PAYMENT_METHOD_ACH);
        paymentDetail.setIsLargeBiller(IS_LARGEBILLER_Y);
    }

    protected void setBeneSourceIdAndTypeForEntityLogging(MigBeneficiary migBeneficiary, StgToTargetBeneEntity stgBeneficiary) {
        migBeneficiary.setBeneSourceId(stgBeneficiary.getIPAYEE_BENE_ID().toString());
        migBeneficiary.setBeneSourceType(BENE_SOURCE_TYPE_IPAY_ACH);
    }

    @Override
    public void setBeneSourceIdInResponse(ResultRecords resultRecords, EntityWrapper entityWrapper) {
        resultRecords.setIPayBeneId(entityWrapper.getEntity().getSourceBeneId(ACH_LARGE));
    }

    @Override
    public EntityWrapper fetchListIfAlreadyMigratedBene(EntityWrapper entityWrapper, ProcessingContext processingContext) {
        entityWrapper.migratedRecords = migBeneficiaryRepository.findByIpayBeneIDMigratedOrIgnored( processingContext.getJobId(), entityWrapper.getEntity().getSourceBeneId(ACH_LARGE));
        return entityWrapper;
    }

    @Override
    public List<StgToTargetBeneEntity> getDataFromStaging(MigClient migClient, StgToTargetBeneEntity.PAYEE_TYPE type) throws ServiceException {
        if(migClient==null){
            log.error(Message.create().descr(NOT_MIGRATED_CLIENT));
            throw new ServiceException(MIGRATION_PENDING, NOT_MIGRATED_CLIENT);
        }
        List<StgToTargetBeneEntity> stgToTargetBeneEntities = beneficiaryMapper.findByOlbClientIdIpayPayees(new SelectConditions(migClient.getEcClientId(), "Y", false));
        if (stgToTargetBeneEntities == null || stgToTargetBeneEntities.isEmpty()) {
            log.error(Message.create().descr(NO_BENES_PRESENT_FOR_PROVIDED_CLIENT_ID).clientId(migClient.getEcClientId()).payeeType(ACH_LARGE));
            throw new ServiceException(NO_BENES_CODE, NO_BENES_PRESENT_FOR_PROVIDED_CLIENT_ID);
        }
        return stgToTargetBeneEntities;
    }
}
