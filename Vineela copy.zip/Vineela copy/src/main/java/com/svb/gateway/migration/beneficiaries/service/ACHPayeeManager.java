package com.svb.gateway.migration.beneficiaries.service;

import com.svb.gateway.migration.beneficiaries.entity.MigBeneficiary;
import com.svb.gateway.migration.beneficiaries.entity.StgToTargetBeneEntity;
import com.svb.gateway.migration.beneficiaries.mapper.MigBeneficiaryMapper;
import com.svb.gateway.migration.beneficiaries.mapper.SelectConditions;
import com.svb.gateway.migration.beneficiaries.model.*;
import com.svb.gateway.migration.beneficiaries.repository.BeneficiaryRepository;
import com.svb.gateway.migration.beneficiaries.repository.MigBeneficiaryRepository;
import com.svb.gateway.migration.client.entity.MigClient;
import com.svb.gateway.migration.common.exception.ServiceException;
import com.svb.gateway.migration.common.logging.Message;
import com.svb.gateway.migration.common.model.AddressResponse;
import com.svb.gateway.migration.common.service.RetryService;
import com.svb.gateway.migration.common.utility.AddressDoctor;
import com.svb.gateway.migration.common.utility.CacheManagerUtility;
import lombok.extern.log4j.Log4j2;
import org.springframework.stereotype.Service;

import java.util.List;

import static com.svb.gateway.migration.beneficiaries.entity.StgToTargetBeneEntity.PAYEE_TYPE.*;
@Log4j2
@Service
public class ACHPayeeManager extends BeneficiaryBaseManager {
    private static final String IS_LARGEBILLER_N = "N";

    public ACHPayeeManager(MigBeneficiaryMapper migBeneficiaryMapper, MigBeneficiaryRepository migBeneficiaryRepository,
                           BeneficiaryRepository beneficiaryRepository, CacheManagerUtility cacheManagerUtility,
                            BeneficiaryValidationUtility beneficiaryValidationUtility,
                           AddressDoctor addressDoctor, RetryService retryService) {
        super(migBeneficiaryMapper, migBeneficiaryRepository, beneficiaryRepository, cacheManagerUtility,
                beneficiaryValidationUtility, addressDoctor, retryService);
    }


    @Override
    protected void validateAddressResponseAndSetAddressInRequest(BeneficiaryAddress beneficiaryAddress, AddressResponse addressResponse, EntityWrapper entityWrapper) {
        // No validation for ACH
        beneficiaryAddress.setAddressLine1("");
        beneficiaryAddress.setAddressLine2("");
        beneficiaryAddress.setCity("");
        beneficiaryAddress.setZipCode("");
        beneficiaryAddress.setState("");
    }

    @Override
    protected StgToTargetBeneEntity.PAYEE_TYPE payeeType(){return ACH;}

    @Override
    public boolean hasCounterPartyNickName() { return true; }

    @Override
    public boolean hasPayeePhoneNumber() { return true; }

    @Override
    public void setPaymentMethodAndIsPersonalAccount(PaymentDetail paymentDetail) {
        paymentDetail.setPaymentMethod(PAYMENT_METHOD_ACH);
        paymentDetail.setIsLargeBiller(IS_LARGEBILLER_N);
    }

    protected void setBeneSourceIdAndTypeForEntityLogging(MigBeneficiary migBeneficiary, StgToTargetBeneEntity stgBeneficiary) {
        migBeneficiary.setBeneSourceId(stgBeneficiary.getIPAYEE_BENE_ID().toString());
        migBeneficiary.setBeneSourceType(BENE_SOURCE_TYPE_IPAY_ACH);
    }

    @Override
    public void setBeneSourceIdInResponse(ResultRecords resultRecords, EntityWrapper entityWrapper) {
        resultRecords.setIPayBeneId(entityWrapper.getEntity().getSourceBeneId(ACH));
    }

    @Override
    public EntityWrapper fetchListIfAlreadyMigratedBene(EntityWrapper entityWrapper, ProcessingContext processingContext) {
        entityWrapper.migratedRecords = migBeneficiaryRepository.findByIpayBeneIDMigratedOrIgnored(processingContext.getJobId(), entityWrapper.getEntity().getSourceBeneId(ACH));
        return entityWrapper;
    }

    /**
     * Updating BankRefNum. Matches the first bank in the list of banks in bankBranchResponse with the PAYEE_CITY and uses that BankRefNo
     * @param stgBeneficiary the beneficiary entity
     * @param bankDetails the bank details to update
     * @param bankBranchResponse the input data from the bankBranchResponse
     */
    @Override
    protected void setBankRefNum(StgToTargetBeneEntity stgBeneficiary, BankDetails bankDetails, BankBranchResponse bankBranchResponse) {
        if(bankBranchResponse==null || bankBranchResponse.getData()==null || bankBranchResponse.getData().isEmpty()){
            bankDetails.setBankRefNum("");
        }
        else if(bankBranchResponse.getData().size()>1 && null!=stgBeneficiary.getBENEFICIARY_BANK_CITY()){
            // match the first bank in the list with the PAYEE_CITY and use that BankRefNo
            for(BankBranchResponseData bankBranchResponseData : bankBranchResponse.getData()){
                // for ACH use getPAYEE_CITY()
                if(stgBeneficiary.getPAYEE_CITY().equalsIgnoreCase(bankBranchResponseData.getBranchAddress().getCity())){
                    bankDetails.setBankRefNum(bankBranchResponseData.getBankRefNo());
                }
            }
            if(bankDetails.getBankRefNum()==null || bankDetails.getBankRefNum().isEmpty()){
                bankDetails.setBankRefNum("");
            }
        }
        else if (bankBranchResponse.getData().size()==1){
            bankDetails.setBankRefNum("");
        }
    }

    @Override
    public List<StgToTargetBeneEntity> getDataFromStaging(MigClient migClient, StgToTargetBeneEntity.PAYEE_TYPE type) throws ServiceException {
        if(migClient==null){
            log.error(Message.create().descr(MIGRATION_PENDING).payeeType(ACH));
            throw new ServiceException(MIGRATION_PENDING, NOT_MIGRATED_CLIENT);
        }
        return beneficiaryMapper.findByOlbClientIdIpayPayees(new SelectConditions(migClient.getEcClientId(), "Y", true));
    }
}
