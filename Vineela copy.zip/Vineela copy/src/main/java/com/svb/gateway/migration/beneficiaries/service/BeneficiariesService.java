package com.svb.gateway.migration.beneficiaries.service;
import static com.svb.gateway.migration.beneficiaries.entity.StgToTargetBeneEntity.PAYEE_TYPE;
import static com.svb.gateway.migration.beneficiaries.entity.StgToTargetBeneEntity.PAYEE_TYPE.FUTURE;
import static com.svb.gateway.migration.beneficiaries.entity.StgToTargetBeneEntity.PAYEE_TYPE.PAST;
import static com.svb.gateway.migration.common.constants.MigrationConstants.*;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.svb.gateway.migration.beneficiaries.entity.MigBeneficiary;
import com.svb.gateway.migration.beneficiaries.entity.StgToTargetBeneEntity;
import com.svb.gateway.migration.beneficiaries.mapper.BeneficiaryMapper;
import com.svb.gateway.migration.beneficiaries.model.MigBeneResponse;
import com.svb.gateway.migration.beneficiaries.model.ResultRecords;
import com.svb.gateway.migration.beneficiaries.repository.BeneficiaryRepository;
import com.svb.gateway.migration.beneficiaries.repository.MigBeneficiaryRepository;
import com.svb.gateway.migration.client.entity.MigClient;
import com.svb.gateway.migration.client.repository.MigClientRepository;
import com.svb.gateway.migration.client.service.ClientService;
import com.svb.gateway.migration.common.constants.MigrationConstants;
import com.svb.gateway.migration.common.exception.ServiceException;
import com.svb.gateway.migration.common.logging.Message;
import com.svb.gateway.migration.common.model.EntityRecordCount;
import com.svb.gateway.migration.common.repository.GatewayOAuthRepository;
import com.svb.gateway.migration.common.utility.*;
import com.svb.gateway.migration.user.entity.MigUser;
import com.svb.gateway.migration.user.repository.MigUserRepository;
import lombok.NonNull;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.validation.annotation.Validated;

import java.sql.Timestamp;
import java.util.*;
import java.util.stream.Collectors;


@Log4j2
@Service
@Validated
public class BeneficiariesService {

    private static final String CREATED_EARLY = "Created during previous Job executions. Job Id: ";
    private static final String FINISHED = "add beneficiaries is finished";
    public static final String MIGRATION_IS_PENDING = "Client migration is pending for which this beneficiary would be created.";
    public static final String NOT_MIGRATED_YET = "benfClientId is not migrated yet";
    public static final String PRIMARY_USER_IS_NOT_CREATED_IN_GATEWAY = "Primary user is not created for the clientId in Gateway";
    public static final String HAS_NO_PRIMARY_USER = "benfClientId has no primary user";
    public static final String NO_BENES_PRESENT_FOR_PROVIDED_CLIENT_ID = "No Benes present for provided client Id";

    @Autowired
    MigClientRepository migClientRepository;

    @Autowired
    MigUserRepository migUserRepository;

    @Autowired
    GatewayOAuthRepository gatewayOAuthRepository;

    @Autowired
    BeneficiaryRepository beneficiaryRepository;

    @Autowired
    MigBeneficiaryRepository migBeneficiaryRepository;

    @Autowired
    ClientService clientService;

    @Value(value = "${mig.addBeneficiary.url}")
    String migAddBeneficiaryUrl;

    @Value(value = "${mig.user.principal}")
    String migUserPrincipal;

    @Value(value = "${mig.alerts.suppress}")
    String alertsSuppressFlag;

    @Autowired
    BeneficiaryMapper beneficiaryMapper;

    @Autowired
    EntityLogUtility entityLogUtility;

    @Autowired
    ACHPayeeManager achPayeeManager;

    @Autowired
    ACHLargePayeeManager achLargePayeeManager;

    @Autowired
    CheckPayeeManager checkPayeeManager;

    @Autowired
    TemplatePayeeManager templatePayeeManager;

    @Autowired
    WirePayeeManager pastPayeeManager;

    @Autowired
    WirePayeeManager futurePayeeManager;


    IBeneficiaryManager getBeneficiaryManager(PAYEE_TYPE benfType){
        if(benfType==null)throw new IllegalArgumentException("Illegal payee type");
        switch(benfType){
            case PAST: pastPayeeManager.type=PAST; return pastPayeeManager;
            case FUTURE: futurePayeeManager.type=FUTURE; return futurePayeeManager;
            case TEMPLATE: return templatePayeeManager;
            case CHECK: return checkPayeeManager;
            case ACH: return achPayeeManager;
            case ACH_LARGE: return achLargePayeeManager;
            default: throw new IllegalArgumentException("Illegal payee type");
        }
    }

    /**
     *
     *
     * @param jobId
     * @param benfClientId
     * @param payeeType is currently needed until we have a way to know it from the data itself. When it is not needed we would be able to process all payees
     * @return
     * @throws ServiceException
     * @throws JsonProcessingException
     */
    public MigBeneResponse addBeneficiaries(Long jobId, @NonNull MigClient migratedClient, PAYEE_TYPE payeeType)  {
        Message logMessage = Message.create().jobId(jobId).clientId(migratedClient.getEcClientId());
        List<StgToTargetBeneEntity> stgToTargetBeneEntities=null;
        List<ResultRecords> resultList=null;
        IBeneficiaryManager beneManager = getBeneficiaryManager(payeeType);
        MigUser primaryUserMigrated = null;
        try {
            primaryUserMigrated = getMigratedPrimaryUser(migratedClient.getEcClientId());
            stgToTargetBeneEntities = getDataFromStaging(payeeType, migratedClient, beneManager);
        }
        catch(Exception e){
            ProcessingContext errorContext = new ProcessingContext(jobId, beneManager, null, migratedClient, null, payeeType);
            log.error(logMessage.descr(e.getMessage()).payeeType(payeeType));
            errorContext.setMessage(e.getMessage());
            saveEntityCountAndTimeInfo(migratedClient, errorContext);
            return toMigBeneResponse(null, errorContext);
        }

        final MigClient client = migratedClient;
        final MigUser primaryUser = primaryUserMigrated;

        // ProcessingContext is a request context keeping track of the overall results
        final ProcessingContext processingContext = new ProcessingContext(jobId, beneManager, getOCHCounterpartiesUrl(client, primaryUser), client, primaryUser, payeeType);


        // if any of the steps below return null or returns a AddBeneficiaryResponse with null data it is an error for that entity.
        // In this case the entity should be skipped and the error should be recorded.

        resultList = stgToTargetBeneEntities.stream()
                .filter(Objects::nonNull)
                .filter(entity -> !processingContext.uniqNonMigBene.containsKey(entity.getSourceBeneId(payeeType))) //filter out duplicates already transferred

                .map(entity -> initProcessingContext(entity, processingContext, payeeType))

                // processingContext.migratedRecords can be null but the entity is still returned
                .map(entityWrapper -> beneManager.fetchListIfAlreadyMigratedBene(entityWrapper, processingContext))

                // filter out previous runs except if they were failures
                .filter(entityWrapper -> canBeProcessed(entityWrapper, processingContext))

                // if  processingContext.migratedRecords!=null this step will return null.
                .map(entityWrapper -> beneManager.prepareRequest(entityWrapper, processingContext))

                // if  processingContext.migratedRecords!=null this step will return null. EntityWrapper keeps track of the current entity being processed
                .map(entityWrapper -> beneManager.migrateBeneficiaryToGateway(entityWrapper, processingContext))

                // passes along the response from earlier, potentially updated
                .map(entityWrapper -> beneManager.updateBeneficiaryDBRecord(entityWrapper, processingContext))

                // maps to result record for success, failure or already created
                .map(entityWrapper -> setResultRecords(entityWrapper, processingContext))

                .collect(Collectors.toList());
        try {
            saveEntityCountAndTimeInfo(client, processingContext);
        }
        catch(Exception e){
            log.error(logMessage.payeeType(payeeType).descr(e.getMessage()));
            processingContext.setMessage(e.getMessage());
            saveEntityCountAndTimeInfo(client, processingContext);
            return toMigBeneResponse(null, processingContext);
        }
        return toMigBeneResponse(resultList, processingContext);
    }

    private boolean canBeProcessed(EntityWrapper entityWrapper, ProcessingContext processingContext) {
        if (entityWrapper.migratedRecords==null || entityWrapper.migratedRecords.isEmpty()){
            return true;
        }
        for(MigBeneficiary migratedEntity: entityWrapper.migratedRecords){
            String currentEntitySourceId = String.valueOf(entityWrapper.getEntity().getSourceBeneId(processingContext.getPayeeType()));
            if( currentEntitySourceId.equals(migratedEntity.getBeneSourceId()) && ! migratedEntity.canRunAgain()){
                return false;
            }
        }
        return true;
    }

    private List<StgToTargetBeneEntity> getDataFromStaging(PAYEE_TYPE payeeType, MigClient migratedClient, IBeneficiaryManager beneManager) throws ServiceException {
        List<StgToTargetBeneEntity> beneEntities = beneManager.getDataFromStaging(migratedClient, payeeType);
        if(beneEntities==null || beneEntities.isEmpty()){
            throw new ServiceException(NO_BENES_PRESENT_FOR_PROVIDED_CLIENT_ID);
        }
        else{
            return beneEntities;
        }
    }

    private EntityWrapper initProcessingContext(StgToTargetBeneEntity entity, ProcessingContext processingContext, PAYEE_TYPE payeeType){
        processingContext.payeeType = payeeType;
        return new EntityWrapper(entity);
    }

    ResultRecords setResultRecords( EntityWrapper entityWrapper, ProcessingContext processingContext){
        ResultRecords resultRecords = new ResultRecords();

        if(entityWrapper.hasUnexpectedErrors()){ // FAILURE
            processingContext.cntFailure.incrementAndGet();
            resultRecords.setBeneId("");
            resultRecords.setStatus(MigrationConstants.STATUS_FAILURE);
            resultRecords.setComments(entityWrapper.getFirstUnexpectedErrorMessage());
        }
        else if(entityWrapper.hasErrorApiResponse()) {// SUCCESSFULLY REPORTED ERRORS
            if(STATUS_SUCCESS.equals(entityWrapper.getStatus())){
                processingContext.cntSuccess.incrementAndGet();
            }
            else{
                processingContext.cntFailure.incrementAndGet();
            }
            resultRecords.setStatus(entityWrapper.getStatus());
            resultRecords.setComments(MIGRATED_ERROR_SUCCESS);
            resultRecords.setBeneId("");
        }
        else if(entityWrapper.hasValidationErrors()){// IGNORED DATA ERRORS
            resultRecords.setComments(MIGRATED_ERROR_IGNORED);
            resultRecords.setStatus(entityWrapper.getStatus());
            processingContext.cntFailure.incrementAndGet();
            resultRecords.setBeneId("");
        }
        else if(entityWrapper.hasMigrationResponse()){ // SUCCESSFUL
            processingContext.cntSuccess.incrementAndGet();
            resultRecords.setBeneId(entityWrapper.gatewayMigrationResponse.getData().getPaymentDetails().get(0).getCounterpartyId());
            resultRecords.setStatus(entityWrapper.gatewayMigrationResponse.getData().getStatus().getCodeDescription());
            resultRecords.setComments(MIGRATED_SUCCESS);
        }
        else { // ALREADY_CREATED
            processingContext.cntAlready.incrementAndGet();
            resultRecords.setBeneId(entityWrapper.migratedRecords.get(0).getBeneficiaryId());
            resultRecords.setStatus(STATUS_CREATED);
            resultRecords.setComments(CREATED_EARLY+entityWrapper.migratedRecords.get(0).getJobId());
        }
        processingContext.beneManager.setBeneSourceIdInResponse(resultRecords, entityWrapper);
        return resultRecords;
    }

    private MigBeneResponse toMigBeneResponse(List<ResultRecords> resultList, ProcessingContext metadata) {
        MigBeneResponse migBeneResponse = new MigBeneResponse();
        migBeneResponse.setGwClientId(metadata.migClient!=null?metadata.migClient.getGwClientId():null);
        migBeneResponse.setNoOfSuccessRecords(metadata.cntSuccess.get());
        migBeneResponse.setNoOfFailedRecords(metadata.cntFailure.get());
        migBeneResponse.setNoOfAlreadyMigratedRecords(metadata.cntAlready.get());
        migBeneResponse.setResultRecords(resultList);
        migBeneResponse.setMessage(metadata.getMessage());
        return migBeneResponse;
    }

    private MigUser getMigratedPrimaryUser(String benfClientId) throws ServiceException{
        MigUser primaryUserMigrated = migUserRepository.getMigratedPrimaryUser(benfClientId);
        if(primaryUserMigrated==null){
            throw new ServiceException(PRIMARY_USER_IS_NOT_CREATED_IN_GATEWAY, HAS_NO_PRIMARY_USER);
        }
        return primaryUserMigrated;
    }

    private String getOCHCounterpartiesUrl(MigClient migClient, MigUser primaryUserMigrated) {
        return migAddBeneficiaryUrl +SLASH + migUserPrincipal.toUpperCase() + SLASH + CORPORATES
                + SLASH + migClient.getGwClientId().toUpperCase() +SLASH + MigrationConstants.PRIMARYUSER + SLASH
                + primaryUserMigrated.getGwUuid().toUpperCase() +SLASH + NOALERTSFLAG + SLASH
                + alertsSuppressFlag + SLASH + COUNTERPARTIES;
    }

    private void saveEntityCountAndTimeInfo(MigClient migClient, ProcessingContext metadata) {
        long endTime = System.currentTimeMillis();
        long durationMillis = endTime - metadata.startTime;
        long durationSec = durationMillis / 1000;
        EntityRecordCount entityRecordCount = new EntityRecordCount();
        entityRecordCount.setMIG_ENTITY_ID("");
        entityRecordCount.setENTITY_NAME(MigrationConstants.BENE_CREATION + " " + metadata.payeeType.name());
        if(migClient!=null && migClient.getPrimaryCifUbs()!=null){
            entityRecordCount.setCIF_NUMBER(migClient.getPrimaryCifUbs().toString());
        }
        else{
            entityRecordCount.setCIF_NUMBER("");
        }
        entityRecordCount.setECCLIENT_ID(migClient!=null?migClient.getEcClientId():"");
        entityRecordCount.setGWCLIENT_ID(migClient!=null?migClient.getGwClientId():"");
        entityRecordCount.setJOB_ID(migClient!=null&&migClient.getJobId()!=null?migClient.getJobId().toString():"");
        int total = metadata.cntSuccess.get() + metadata.cntFailure.get();
        entityRecordCount.setREADCOUNT(total);// not including all from the beginning, stgToTargetBeneEntities.size(), only the ones in this round
        entityRecordCount.setWRITECOUNT(metadata.cntSuccess.get());
        entityRecordCount.setSKIPCOUNT(metadata.cntFailure.get() );// not including what we already have done, metadata.cntAlready.get()
        entityRecordCount.setSTART_TIME(new Timestamp(metadata.startTime));
        entityRecordCount.setEND_TIME(new Timestamp(endTime));
        entityRecordCount.setTOTAL_STEP_TIME(durationSec);
        if(total>0) {
            entityLogUtility.saveEntityCountAndTimeLog(entityRecordCount);
            log.info(Message.create().descr(FINISHED).payeeType(metadata.payeeType).timeTaken(durationMillis));
        }
    }
}