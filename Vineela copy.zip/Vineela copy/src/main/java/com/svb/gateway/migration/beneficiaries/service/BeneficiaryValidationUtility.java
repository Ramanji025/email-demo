package com.svb.gateway.migration.beneficiaries.service;

import com.svb.gateway.migration.beneficiaries.model.*;
import com.svb.gateway.migration.common.constants.MigrationConstants;
import com.svb.gateway.migration.common.exception.ServiceException;
import com.svb.gateway.migration.common.logging.Message;
import com.svb.gateway.migration.common.service.RetryService;
import com.svb.gateway.migration.common.utility.CacheManagerUtility;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.*;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestClientResponseException;
import org.springframework.web.client.RestTemplate;

import java.util.ArrayList;
import java.util.List;

import static com.svb.gateway.migration.beneficiaries.model.ValidationError.*;

@Log4j2
@Component
public class BeneficiaryValidationUtility {
    public static final int SWIFT_MIN_LENGTH = 8;
    public static final String SUCCESSFULLY_VALIDATED_IBAN = "0";
    public static final String WARNING_VALIDATING_IBAN = "2";
    @Autowired
    RetryService retryService;

    @Autowired
    RestTemplate restTemplate;

    @Value(value ="${mig.bankBranchFetch.url}")
    String bankBranchUrl;

    @Value(value ="${mig.ibanCountrySpecificRule.url}")
    String ibanRuleUrl;

    @Value(value ="${mig.ibanValidation.url}")
    String ibanValidationUrl;

    @Value(value ="${mig.reachabilityCheck.url}")
    String reachabilityUrl;

    @Value("${header.service.token}")
    String token;


    @Autowired
    CacheManagerUtility cacheManagerUtility;

    public static final String MANDATORY = "M";
    public static final String OPTIONAL = "O";
    public static final String NOT_APPLICABLE = "NA";
    private static final String VALIDATION_ERROR_CODE = "\"103627\"";//The bank details do not exist.


    public  BankBranchResponse validateBankBranchAndFetchList(EntityWrapper entityWrapper)  {

        ResponseEntity<List<BankBranchResponseData>> bankBranchResponseEntity = null;

        BankBranchResponse bankBranchResponse = new BankBranchResponse();

        Message logMessage = Message.create().jobId(entityWrapper.getEntity().getJOB_ID()).clientId(entityWrapper.getEntity().getOLB_CLIENT_ID()).bankId(entityWrapper.getEntity().getBENEFICIARY_BANK_IDENTIFIER());

        try{
            HttpHeaders headers = new HttpHeaders();
            headers.add(MigrationConstants.AUTHORIZATION_HEADER_NAME, cacheManagerUtility.getOauthToken());
            headers.add(MigrationConstants.CONTENT_TYPE, MigrationConstants.APPLICATION_HEADER_JSON);

            HttpEntity<?> requestEntity = new HttpEntity<>(headers);
            String finalBankBranchUrl = bankBranchUrl+entityWrapper.getEntity().getBENEFICIARY_BANK_IDENTIFIER();

            log.info(logMessage.descr("Bank branch list fetch call for bank identifier").url(finalBankBranchUrl));

            bankBranchResponseEntity = retryService.exchange(finalBankBranchUrl, HttpMethod.GET, requestEntity, new ParameterizedTypeReference<List<BankBranchResponseData>>() {});

        }
        catch (RestClientResponseException restClientResponseException) {
            // If we get a special response including validationErrorCode, we treat it as a validation error for "The bank details do not exist."
            if (restClientResponseException.getResponseBodyAsString().contains(VALIDATION_ERROR_CODE)){
                log.warn(logMessage.descr("The bank details do not exist."));
            }
            else{
                entityWrapper.addUnexpectedError("get bank branch endpoint", restClientResponseException.getMessage());
                log.error(logMessage.descr("rest client exception occurred while fetching bank branch list : "+restClientResponseException.getMessage()));
            }
            return new BankBranchResponse();
        }
        catch (ServiceException e){
            // treating ServiceException as unexpected FAILURE
            log.warn(logMessage.descr("Exception occurred while fetching bank branch list : "+e.getMessage()));
            entityWrapper.addUnexpectedError("get bank branch endpoint", e.getMessage());
            return new BankBranchResponse();
        }

        if(HttpStatus.OK.equals(bankBranchResponseEntity.getStatusCode())) {
            bankBranchResponse.setData(bankBranchResponseEntity.getBody());
            List<BankBranchResponseData> filteredBankBranchResponseData = new ArrayList<>();
            for(BankBranchResponseData bankBranchResponseData : bankBranchResponse.getData()){
                if(bankBranchResponseData.getBankClearingCode().equalsIgnoreCase(entityWrapper.getEntity().getBENEFICIARY_BANK_IDENTIFIER())){
                    filteredBankBranchResponseData.add(bankBranchResponseData);
                }
            }
            bankBranchResponse.setData(filteredBankBranchResponseData);
            bankBranchResponse.setValidated(true);

        } else {
            bankBranchResponse = new BankBranchResponse();
            bankBranchResponse.setValidated(false);
        }
        return bankBranchResponse;
    }

    public  IbanCountryRulesResponse validateIbanCountrySpecificRulesAndValidation(EntityWrapper entityWrapper, String countryCode, Long jobId, String ecClientId) {

        ResponseEntity<IbanCountryRulesResponse> ibanResponseEntity = null;

        IbanCountryRulesResponse ibanCountryRulesResponse = new IbanCountryRulesResponse();

        Message logMessage = Message.create().jobId(jobId).clientId(ecClientId).accountNumber(entityWrapper.getEntity().getBENEFICIARY_ACCOUNT());

        HttpHeaders headers = new HttpHeaders();
        headers.add(MigrationConstants.CONTENT_TYPE, MigrationConstants.APPLICATION_HEADER_JSON);

        HttpEntity<?> requestEntity = new HttpEntity<>(headers);

        String finalIbanRuleUrl = ibanRuleUrl+countryCode;

        log.info(logMessage.descr("Iban country rules fetch call for "+countryCode).url(finalIbanRuleUrl));
        try {
            ibanResponseEntity = retryService.exchange(finalIbanRuleUrl, HttpMethod.GET, requestEntity, new ParameterizedTypeReference<IbanCountryRulesResponse>(){});
        }
        catch(RestClientException e){
            log.error(logMessage.descr("Iban country rules fetch call "+e.getMessage()));
            entityWrapper.addUnexpectedError("Payment validation rules endpoint for IBAN country", e.getMessage());
        }
        if(ibanResponseEntity != null && ibanResponseEntity.getBody() !=null && HttpStatus.OK.equals(ibanResponseEntity.getStatusCode())) {
            ibanCountryRulesResponse.setData(ibanResponseEntity.getBody().getData());
            String accountPrefix = entityWrapper.getEntity().getBENEFICIARY_ACCOUNT().substring(0,2);
            if(!(ibanCountryRulesResponse.getData().getBeneficaryAccount().getIbanRequired().equalsIgnoreCase(NOT_APPLICABLE)) && ibanCountryRulesResponse.getData().getBeneficaryAccount().getIban().getIbanISOCountryCode().equalsIgnoreCase(accountPrefix)){
                IbanValidationResponse ibanValidationResponse = validateIBAN(entityWrapper, ecClientId);
                if(ibanValidationResponse.isValidated()){
                    ibanCountryRulesResponse.setValidated(true);
                }
            }
            //Optional and user has provided some account number
            else if(ibanCountryRulesResponse.getData().getBeneficaryAccount().getIbanRequired().equalsIgnoreCase(OPTIONAL) && !(ibanCountryRulesResponse.getData().getBeneficaryAccount().getIban().getIbanISOCountryCode().equalsIgnoreCase(accountPrefix))){
                ibanCountryRulesResponse.setValidated(true);
            }
            //For Iban countries those which do not require Iban as mandate, setting the flag true to proceed with bene creation
            else if(ibanCountryRulesResponse.getData().getBeneficiaryBankInfo()!=null &&
                    ibanCountryRulesResponse.getData().getBeneficiaryBankInfo().getLocalRoutingCodeRequired()!=null &&
                    ibanCountryRulesResponse.getData().getBeneficiaryBankInfo().getLocalRoutingCodeRequired().equalsIgnoreCase(MANDATORY) && ibanCountryRulesResponse.getData().getBeneficaryAccount().getIbanRequired().equalsIgnoreCase(NOT_APPLICABLE)){
                // no action, it is already invalid by default
            }
            else if(ibanCountryRulesResponse.getData().getBeneficaryAccount().getIbanRequired().equalsIgnoreCase(NOT_APPLICABLE)){
                ibanCountryRulesResponse.setValidated(true);
            }
        }
        return ibanCountryRulesResponse;
    }

    public IbanValidationResponse validateIBAN(EntityWrapper entityWrapper, String ecClientId){

        IbanValidationRequest ibanValidationRequest = new IbanValidationRequest();
        ibanValidationRequest.setIbanToValidate(entityWrapper.getEntity().getBENEFICIARY_ACCOUNT());

        Message logMessage = Message.create().jobId(entityWrapper.getEntity().getJOB_ID()).clientId(ecClientId).accountNumber(entityWrapper.getEntity().getBENEFICIARY_ACCOUNT());

        ResponseEntity<IbanValidationResponse> ibanValidationResponseEntity = null;
        IbanValidationResponse ibanValidationResponse = new IbanValidationResponse();


        HttpHeaders headers = new HttpHeaders();
        headers.add(MigrationConstants.CONTENT_TYPE, MigrationConstants.APPLICATION_HEADER_JSON);
        headers.add(MigrationConstants.HEADER_SERVICE_TOKEN, token);
        HttpEntity<?> requestEntity = new HttpEntity<>(ibanValidationRequest, headers);

        log.info(logMessage.descr("Iban validation call"));
        try{
            ibanValidationResponseEntity = retryService.exchange(ibanValidationUrl, HttpMethod.POST, requestEntity, new ParameterizedTypeReference<IbanValidationResponse>(){});
        }
        catch(RestClientException e){
            log.error(logMessage.descr("Iban validation call "+e.getMessage()));
            entityWrapper.addUnexpectedError("Payment validation rules endpoint for IBAN country", e.getMessage());
        }
        if(ibanValidationResponseEntity!=null && ibanValidationResponseEntity.getBody() != null && HttpStatus.OK.equals(ibanValidationResponseEntity.getStatusCode())
                && null != ibanValidationResponseEntity.getBody().getData()){
            ibanValidationResponse.setData(ibanValidationResponseEntity.getBody().getData());
            String validationCode = ibanValidationResponse.getData().getResponseCode().getCode();
            if((SUCCESSFULLY_VALIDATED_IBAN.equalsIgnoreCase(validationCode) || WARNING_VALIDATING_IBAN.equalsIgnoreCase(validationCode))
                    && isBicEqualToBeneBankId(entityWrapper, ibanValidationResponse)){
                ibanValidationResponse.setValidated(true);
            }
        }

        return ibanValidationResponse;
    }

    private boolean isBicEqualToBeneBankId(EntityWrapper entityWrapper, IbanValidationResponse ibanValidationResponse) {
        return ibanValidationResponse.getData().getInstitutionDetails().getSwiftBIC().length() >= SWIFT_MIN_LENGTH
                && entityWrapper.getEntity().getBENEFICIARY_BANK_IDENTIFIER().length() >= SWIFT_MIN_LENGTH
                && ibanValidationResponse.getData().getInstitutionDetails().getSwiftBIC().substring(0, SWIFT_MIN_LENGTH).equalsIgnoreCase(entityWrapper.getEntity().getBENEFICIARY_BANK_IDENTIFIER().substring(0, SWIFT_MIN_LENGTH));
    }

    ReachabilityCheckResponse reachabilityCheck(EntityWrapper entityWrapper, String gwClientId) {

        ResponseEntity<ReachabilityCheckResponseData> reachabilityCheckResponseEntity = null;
        Message logMessage = Message.create().jobId(entityWrapper.getEntity().getJOB_ID()).clientId(entityWrapper.getEntity().getOLB_CLIENT_ID()).gwClientId(gwClientId);

        ReachabilityCheckResponse reachabilityCheckResponse = new ReachabilityCheckResponse();

        try{
            HttpHeaders headers = new HttpHeaders();
            headers.add(MigrationConstants.AUTHORIZATION_HEADER_NAME, cacheManagerUtility.getOauthToken());
            headers.add(MigrationConstants.CONTENT_TYPE, MigrationConstants.APPLICATION_HEADER_JSON);

            HttpEntity<?> requestEntity = new HttpEntity<>(headers);
            String finalReachabilityUrl = reachabilityUrl+ gwClientId + MigrationConstants.FETCH_CLEARING_SYSTEM_DETAILS +entityWrapper.getEntity().getBENEFICIARY_BANK_IDENTIFIER();

            log.info(logMessage.descr("Network reachability for ABA :: "+entityWrapper.getEntity().getBENEFICIARY_BANK_IDENTIFIER()).url(finalReachabilityUrl));

            reachabilityCheckResponseEntity = /*don't retry for this call:*/restTemplate.exchange(finalReachabilityUrl, HttpMethod.GET, requestEntity, new ParameterizedTypeReference<ReachabilityCheckResponseData>(){});

        }
        catch (Exception exception){
            //treat all exceptions as validation error because of a bug in the called endpoint that always throws 500 errors even for validation issues
            log.warn(logMessage.descr("Currently treating all exceptions to this Network reachability endpoint as a data validation error for incorrect routing number "+exception.getMessage()));
            entityWrapper.addValidationError(ERR1006, ROUTING_NUMBER_INCORRECT, ROUTING_NUMBER_FIELD);
            return reachabilityCheckResponse;
        }

        if(HttpStatus.OK.equals(reachabilityCheckResponseEntity.getStatusCode())) {
            reachabilityCheckResponse.setData(reachabilityCheckResponseEntity.getBody());
            if(!reachabilityCheckResponse.getData().getClearingSystemDetails().isEmpty()){
                reachabilityCheckResponse.setValidated(true);
            }
        }

        if(!reachabilityCheckResponse.isValidated()){
            entityWrapper.addValidationError(ERR1006, ROUTING_NUMBER_INCORRECT, ROUTING_NUMBER_FIELD);
        }
        return reachabilityCheckResponse;
    }

}
