package com.svb.gateway.migration.beneficiaries.service;

import com.svb.gateway.migration.beneficiaries.entity.MigBeneficiary;
import com.svb.gateway.migration.beneficiaries.entity.StgToTargetBeneEntity;
import com.svb.gateway.migration.beneficiaries.mapper.MigBeneficiaryMapper;
import com.svb.gateway.migration.beneficiaries.mapper.SelectConditions;
import com.svb.gateway.migration.beneficiaries.model.*;
import com.svb.gateway.migration.beneficiaries.repository.BeneficiaryRepository;
import com.svb.gateway.migration.beneficiaries.repository.MigBeneficiaryRepository;
import com.svb.gateway.migration.client.entity.MigClient;
import com.svb.gateway.migration.common.exception.ServiceException;
import com.svb.gateway.migration.common.logging.Message;
import com.svb.gateway.migration.common.model.AddressResponse;
import com.svb.gateway.migration.common.service.RetryService;
import com.svb.gateway.migration.common.utility.AddressDoctor;
import com.svb.gateway.migration.common.utility.CacheManagerUtility;
import lombok.extern.log4j.Log4j2;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

import static com.svb.gateway.migration.beneficiaries.entity.StgToTargetBeneEntity.PAYEE_TYPE.*;
@Log4j2
@Service
public class CheckPayeeManager extends BeneficiaryBaseManager  {
    private static final String BENE_SOURCE_TYPE_IPAY_CHK = "IPAY Check";
    private static final String PAYMENT_METHOD_CHK = "CHK";

    public CheckPayeeManager(MigBeneficiaryMapper migBeneficiaryMapper, MigBeneficiaryRepository migBeneficiaryRepository, BeneficiaryRepository beneficiaryRepository, CacheManagerUtility cacheManagerUtility, BeneficiaryValidationUtility beneficiaryValidationUtility, AddressDoctor addressDoctor, RetryService retryService) {
        super(migBeneficiaryMapper, migBeneficiaryRepository, beneficiaryRepository, cacheManagerUtility, beneficiaryValidationUtility, addressDoctor, retryService);
    }

    @Override
    protected StgToTargetBeneEntity.PAYEE_TYPE payeeType(){return CHECK;}

    @Override
    protected BeneficiaryAddress getAddress(EntityWrapper entityWrapper, MigClient migClient, BankBranchResponse bankBranchResponse, AccountDetails accountDetails, Long jobId) {
        BeneficiaryAddress beneficiaryAddress = new BeneficiaryAddress();
        String completeAddr = getCompleteAddr(entityWrapper.getEntity());
        AddressResponse addressResponse = addressDoctor.validateAddress(DEFAULT_COUNTRY_CODE,completeAddr, entityWrapper);
        validateAddressResponseAndSetAddressInRequest(beneficiaryAddress, addressResponse, entityWrapper);
        beneficiaryAddress.setCountry(DEFAULT_COUNTRY_CODE);
        return beneficiaryAddress;
    }

    @Override
    public List<PaymentDetail> getPaymentDetails(EntityWrapper entityWrapper, MigClient migClient, AccountDetails accountDetails, BankDetails bankDetails) {
        PaymentDetail paymentDetail = new PaymentDetail();
        paymentDetail.setRequestType(REQUEST_TYPE);
        paymentDetail.setPreferredFlag(PREFERRED_FLAG);
        paymentDetail.setPaymentMethod(PAYMENT_METHOD_CHK);
        paymentDetail.setCustomerAccountNumber(entityWrapper.getEntity().getBENEFICIARY_ACCOUNT());
        List<PaymentDetail> paymentDetails = new ArrayList<>();
        paymentDetails.add(paymentDetail);
        return paymentDetails;
    }

    /**
     * This method intentionally returns null because we do not validate the bank branch for checks.
     * @param entityWrapper
     * @return
     */
    @Override
    public BankBranchResponse validateBankBranch(EntityWrapper entityWrapper, AccountDetails a, MigClient m) {
        // do not validate for Checks
        return null;
    }

    /**
     * This method makes sure we don't perform cityMatchAndSetBankRefNum for checks
     * @param stgBeneficiary
     * @param bankDetails
     * @param bankBranchResponse
     */
    @Override
    protected void setBankRefNum(StgToTargetBeneEntity stgBeneficiary, BankDetails bankDetails, BankBranchResponse bankBranchResponse) {
        // do not perform for Checks
    }

    @Override
    public boolean hasCounterPartyNickName() { return true; }

    @Override
    public boolean hasPayeePhoneNumber() { return true; }

    @Override
    protected void setBeneSourceIdAndTypeForEntityLogging(MigBeneficiary migBeneficiary, StgToTargetBeneEntity stgBeneficiary) {
        migBeneficiary.setBeneSourceId(stgBeneficiary.getIPAYEE_BENE_ID().toString());
        migBeneficiary.setBeneSourceType(BENE_SOURCE_TYPE_IPAY_CHK);
    }

    @Override
    public void setBeneSourceIdInResponse(ResultRecords resultRecords, EntityWrapper entityWrapper) {
        resultRecords.setIPayBeneId(entityWrapper.getEntity().getSourceBeneId(CHECK));
    }

    @Override
    protected void setPaymentMethodAndIsPersonalAccount(PaymentDetail paymentDetail){
        // Default is Wire
        paymentDetail.setPaymentMethod(PAYMENT_METHOD_CHK);
    }

    @Override
    public EntityWrapper fetchListIfAlreadyMigratedBene(EntityWrapper entityWrapper, ProcessingContext processingContext) {
        entityWrapper.migratedRecords = migBeneficiaryRepository.findByIpayBeneIDMigratedOrIgnored(processingContext.getJobId(), entityWrapper.getEntity().getSourceBeneId(CHECK));
        return entityWrapper;
    }

    @Override
    public List<StgToTargetBeneEntity> getDataFromStaging(MigClient migClient, StgToTargetBeneEntity.PAYEE_TYPE type) throws ServiceException {
        if(migClient==null){
            log.error(Message.create().descr(NOT_MIGRATED_CLIENT));
            throw new ServiceException(NO_BENES_CODE, NOT_MIGRATED_CLIENT);
        }
        List<StgToTargetBeneEntity> stgToTargetBeneEntities = beneficiaryMapper.findByOlbClientIdIpayPayees(new SelectConditions(migClient.getEcClientId(), "N", false));
        if (stgToTargetBeneEntities == null || stgToTargetBeneEntities.isEmpty()) {
            log.error(Message.create().descr(NO_BENES_PRESENT_FOR_PROVIDED_CLIENT_ID).payeeType(CHECK));
            throw new ServiceException(NO_BENES_PRESENT_FOR_PROVIDED_CLIENT_ID, NO_BENES_PRESENT_FOR_PROVIDED_CLIENT_ID);
        }
        return stgToTargetBeneEntities;
    }
}
