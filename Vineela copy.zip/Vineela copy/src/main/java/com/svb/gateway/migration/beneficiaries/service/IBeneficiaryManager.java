package com.svb.gateway.migration.beneficiaries.service;

import com.svb.gateway.migration.beneficiaries.entity.StgToTargetBeneEntity;
import com.svb.gateway.migration.beneficiaries.entity.StgToTargetBeneEntity.PAYEE_TYPE;
import com.svb.gateway.migration.beneficiaries.model.*;
import com.svb.gateway.migration.client.entity.MigClient;
import com.svb.gateway.migration.common.exception.ServiceException;

import java.util.List;

public interface IBeneficiaryManager {

    /**
     * Step 1: Populate request object for counterparties api call
     */
    EntityWrapper prepareRequest(EntityWrapper entity, ProcessingContext processingContext);

    /**
     * Step 2: Check for Routing No in Target, also fetch Network_type info
     */
    List<PaymentDetail> getPaymentDetails(EntityWrapper entityWrapper, MigClient migClient, AccountDetails accountDetails, BankDetails bankDetails);

    boolean hasCounterPartyNickName();

    boolean hasPayeePhoneNumber();

    List<StgToTargetBeneEntity> getDataFromStaging(MigClient migClient, PAYEE_TYPE type) throws ServiceException;

    EntityWrapper fetchListIfAlreadyMigratedBene(EntityWrapper entityWrapper, ProcessingContext processingContext);

    void setBeneSourceIdInResponse(ResultRecords resultRecords, EntityWrapper entityWrapper);

    /**
     * Step 3: Invoke AddBeneficiary API to create Beneficiary
     */
    EntityWrapper migrateBeneficiaryToGateway(EntityWrapper addBeneficiaryRequest, ProcessingContext processingContext) ;

    /**
     * Step 4: Update Staging Beneficiary with the target information. Inserts or updates mig_beneficiary table
     */
    EntityWrapper updateBeneficiaryDBRecord(EntityWrapper entityWrapper, ProcessingContext processingContext);

}
