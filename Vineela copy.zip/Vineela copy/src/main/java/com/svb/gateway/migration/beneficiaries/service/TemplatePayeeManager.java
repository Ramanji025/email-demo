package com.svb.gateway.migration.beneficiaries.service;

import com.svb.gateway.migration.beneficiaries.entity.MigBeneficiary;
import com.svb.gateway.migration.beneficiaries.entity.StgToTargetBeneEntity;
import com.svb.gateway.migration.beneficiaries.mapper.MigBeneficiaryMapper;
import com.svb.gateway.migration.beneficiaries.model.ResultRecords;
import com.svb.gateway.migration.beneficiaries.repository.BeneficiaryRepository;
import com.svb.gateway.migration.beneficiaries.repository.MigBeneficiaryRepository;
import com.svb.gateway.migration.client.entity.MigClient;
import com.svb.gateway.migration.common.exception.ServiceException;
import com.svb.gateway.migration.common.logging.Message;
import com.svb.gateway.migration.common.service.RetryService;
import com.svb.gateway.migration.common.utility.AddressDoctor;
import com.svb.gateway.migration.common.utility.CacheManagerUtility;
import lombok.extern.log4j.Log4j2;
import org.springframework.stereotype.Service;

import java.util.List;

import static com.svb.gateway.migration.beneficiaries.entity.StgToTargetBeneEntity.PAYEE_TYPE.*;
@Log4j2
@Service
public class TemplatePayeeManager extends BeneficiaryBaseManager {
    private static final String BENE_SOURCE_TYPE_TEMPLATE = "eConnectTemplate";

    public TemplatePayeeManager(MigBeneficiaryMapper migBeneficiaryMapper, MigBeneficiaryRepository migBeneficiaryRepository, BeneficiaryRepository beneficiaryRepository, CacheManagerUtility cacheManagerUtility, BeneficiaryValidationUtility beneficiaryValidationUtility, AddressDoctor addressDoctor, RetryService retryService) {
        super(migBeneficiaryMapper, migBeneficiaryRepository, beneficiaryRepository, cacheManagerUtility, beneficiaryValidationUtility, addressDoctor, retryService);
    }

    @Override
    protected StgToTargetBeneEntity.PAYEE_TYPE payeeType(){return TEMPLATE;}

    @Override
    protected void setBeneSourceIdAndTypeForEntityLogging(MigBeneficiary migBeneficiary, StgToTargetBeneEntity stgBeneficiary) {
        migBeneficiary.setBeneSourceId(stgBeneficiary.getTEMPLATE_ID().toString());
        migBeneficiary.setBeneSourceType(BENE_SOURCE_TYPE_TEMPLATE);
    }

    @Override
    public boolean hasCounterPartyNickName() { return false; }

    @Override
    public boolean hasPayeePhoneNumber() { return false; }

    @Override
    public void setBeneSourceIdInResponse(ResultRecords resultRecords, EntityWrapper entityWrapper) {
        resultRecords.setTemplateId(entityWrapper.getEntity().getSourceBeneId(TEMPLATE));
    }

    @Override
    public EntityWrapper fetchListIfAlreadyMigratedBene(EntityWrapper entityWrapper, ProcessingContext processingContext) {
        entityWrapper.migratedRecords = migBeneficiaryRepository.findByTemplateIdMigratedOrIgnored(processingContext.getJobId(), entityWrapper.getEntity().getSourceBeneId(TEMPLATE));
        return entityWrapper;
    }

    @Override
    public List<StgToTargetBeneEntity> getDataFromStaging(MigClient migClient, StgToTargetBeneEntity.PAYEE_TYPE type) throws ServiceException {
        if(migClient==null){
            log.error(Message.create().descr(NOT_MIGRATED_CLIENT));
            throw new ServiceException(MIGRATION_PENDING, NOT_MIGRATED_CLIENT);
        }
        List<StgToTargetBeneEntity> stgToTargetBeneEntities = beneficiaryMapper.findByOlbClientIdTemplates(migClient.getEcClientId());
        if (stgToTargetBeneEntities == null || stgToTargetBeneEntities.isEmpty()) {
            log.error(Message.create().descr(NO_BENES_PRESENT_FOR_PROVIDED_CLIENT_ID));
            throw new ServiceException(NO_BENES_CODE, NO_BENES_PRESENT_FOR_PROVIDED_CLIENT_ID);
        }
        return stgToTargetBeneEntities;
    }
}
