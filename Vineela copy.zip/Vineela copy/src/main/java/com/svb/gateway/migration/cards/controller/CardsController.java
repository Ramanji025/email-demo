package com.svb.gateway.migration.cards.controller;

import com.svb.gateway.migration.cards.api.CardsApi;
import com.svb.gateway.migration.cards.model.CardProgramInformationResponse;
import com.svb.gateway.migration.cards.service.CardsService;
import com.svb.gateway.migration.client.entity.MigClient;
import com.svb.gateway.migration.client.service.ClientService;
import com.svb.gateway.migration.common.exception.InvalidInputException;
import com.svb.gateway.migration.common.exception.ServiceException;
import com.svb.gateway.migration.common.logging.Message;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import springfox.documentation.annotations.ApiIgnore;

/**
 * @author bmourya
 */

@ApiIgnore
@RestController
@Log4j2
public class CardsController implements CardsApi {

    private final CardsService cardsService;
    private  final ClientService clientService;

    @Autowired
    public CardsController(CardsService cardsService, ClientService clientService) {
        this.cardsService = cardsService;
        this.clientService = clientService;
    }

    @Override
    public ResponseEntity<Object> addCardProgram(@PathVariable Long jobId, @PathVariable String clientId) {

        log.info(Message.create().descr("In CardsController.addCardProgramToClient, enrolling card Programs").clientId(clientId).jobId(jobId));
        try {
            MigClient migClient = clientService.getMigClient(clientId, jobId);
            CardProgramInformationResponse clientResponse = cardsService.addCardProgramToClient(jobId, migClient);
            if (clientResponse != null) {
                return new ResponseEntity<>(clientResponse, HttpStatus.OK);
            } else {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body("enroll card failed");
            }

        } catch (InvalidInputException e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Invalid Input or Invalid Format");

        } catch (ServiceException e) {
            return ResponseEntity.status(HttpStatus.NOT_MODIFIED).body(e.getMessage());

        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Internal server error from cardsService");
        }
    }
}