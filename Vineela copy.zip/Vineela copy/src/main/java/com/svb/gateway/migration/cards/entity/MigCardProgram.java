package com.svb.gateway.migration.cards.entity;

import com.svb.gateway.migration.common.processors.IRetry;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.util.Date;

@Entity
@Getter
@Setter
@Table(name = "MIG_CARD_PROGRAM")
public class MigCardProgram implements IRetry {

    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(name = "ID")
    private Integer id;

    @Column(name = "AGENT")
    private String agent;

    @Column(name = "billing_Type")
    private String billingType;

    @Column(name = "cif")
    private String cif;

    @Column(name = "client_Profile_Name")
    private String clientProfileName;

    @Column(name = "credit_Line")
    private String creditLine;

    @Column(name = "olb_Client_Id")
    private String olbClientId;

    @Column(name = "prn")
    private String prn;

    @Column(name = "program_Id")
    private String programId;

    @Column(name = "program_Type")
    private String programType;

    @Column(name = "ecClientId")
    private String ecClientId;

    @Column(name = "status")
    private String status;

    @Column(name = "sys")
    private String sys;

    @Column(name = "UPDATEDDATE")
    private Date updatedDate;

    @Column(name = "JOBID")
    private Long jobId;

    @Column(name = "COMMENTS")
    private String comments;

    @Column(name = "EC_STATUS_CODE")
    private String ecStatusCode;

    @Column(name = "UPDATEDBY")
    private String updatedBy;

    @Column(name = "CREATEDBY")
    private String createdBy;

    @Column(name = "CREATEDDATE")
    private Date createdDate;

}
