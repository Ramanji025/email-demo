package com.svb.gateway.migration.cards.entity;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.sql.Date;

/**
 * @author bmourya
 *
 */

@Getter
@Setter
@ToString
@Entity
@Table(name = "MIG_STG_CARD_PROGRAM")
public class MigStgCardProgram {

    @Column(name = "CIF")
    private String cif;

    @Column(name = "OLB_CLIENT_ID")
    private String olbClientId;

    @Id
    @Column(name = "COMPANY_ID")
    private String companyId;

    @Column(name = "AGENT_ID")
    private String agentId;

    @Column(name = "PRINCIPAL_ID")
    private String principalId;

    @Column(name = "SYSTEM_ID")
    private String systemId;

    @Column(name = "BILLING_TYPE")
    private String billingType;

    @Column(name = "LOAN_ACCOUNT_NUMBER")
    private String loanAccountNumber;

    @Column(name = "PROD_CD")
    private String prodCd;

    @Column(name = "MANAGE_AUTO_PAYMENT")
    private String manageAutoPayment;

    @Column(name = "ACCOUNT_AUTOPAY")
    private Integer accountAutoPay;

    @Column(name = "ACCOUNT_PAYMENT")
    private String accountPayment;

    @Column(name = "STATUS_CD")
    private String statusCd;

    @Column(name = "JOB_ID ")
    private Integer jobId;

    @Column(name = "CREATED_BY")
    private String createdBy;

    @Column(name = "CREATED_DT")
    private Date createdDt;

    @Column(name = "MODIFIED_DT ")
    private Date modifiedDt;

}
