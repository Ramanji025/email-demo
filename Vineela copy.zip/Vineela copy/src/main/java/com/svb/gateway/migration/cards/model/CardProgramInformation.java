package com.svb.gateway.migration.cards.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonPropertyOrder({
        "agent",
        "billingType",
        "cif",
        "clientProfileName",
        "creditLine",
        "olbClientId",
        "prn",
        "programId",
        "programType",
        "status",
        "sys"
})
public class CardProgramInformation {

    @JsonProperty("agent")
    private String agent;

    @JsonProperty("billingType")
    private String billingType;

    @JsonProperty("cif")
    private String cif;

    @JsonProperty("clientProfileName")
    private String clientProfileName;

    @JsonProperty("creditLine")
    private String creditLine;

    @JsonProperty("olbClientId")
    private String olbClientId;

    @JsonProperty("prn")
    private String prn;

    @JsonProperty("programId")
    private String programId;

    @JsonProperty("programType")
    private String programType;

    @JsonProperty("status")
    private String status;

    @JsonProperty("sys")
    private String sys;

    public String getAgent() {
        return agent;
    }

    public void setAgent(String agent) {
        this.agent = agent;
    }

    public String getBillingType() {
        return billingType;
    }

    public void setBillingType(String billingType) {
        this.billingType = billingType;
    }

    public String getCif() {
        return cif;
    }

    public void setCif(String cif) {
        this.cif = cif;
    }

    public String getClientProfileName() {
        return clientProfileName;
    }

    public void setClientProfileName(String clientProfileName) {
        this.clientProfileName = clientProfileName;
    }

    public String getCreditLine() {
        return creditLine;
    }

    public void setCreditLine(String creditLine) {
        this.creditLine = creditLine;
    }

    public String getOlbClientId() {
        return olbClientId;
    }

    public void setOlbClientId(String olbClientId) {
        this.olbClientId = olbClientId;
    }

    public String getPrn() {
        return prn;
    }

    public void setPrn(String prn) {
        this.prn = prn;
    }

    public String getProgramId() {
        return programId;
    }

    public void setProgramId(String programId) {
        this.programId = programId;
    }

    public String getProgramType() {
        return programType;
    }

    public void setProgramType(String programType) {
        this.programType = programType;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getSys() {
        return sys;
    }

    public void setSys(String sys) {
        this.sys = sys;
    }
}
