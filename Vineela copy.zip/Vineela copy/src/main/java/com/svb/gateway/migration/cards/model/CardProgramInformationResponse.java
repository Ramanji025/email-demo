package com.svb.gateway.migration.cards.model;

import java.util.List;

public class CardProgramInformationResponse {
    List<CardProgramInformation> cardProgramInformationList;

    public List<CardProgramInformation> getCardProgramInformationList() {
        return cardProgramInformationList;
    }

    public void setCardProgramInformationList(List<CardProgramInformation> cardProgramInformationList) {
        this.cardProgramInformationList = cardProgramInformationList;
    }
}
