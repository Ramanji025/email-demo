package com.svb.gateway.migration.cards.service;

import com.svb.gateway.migration.cards.entity.MigCardProgram;
import com.svb.gateway.migration.cards.entity.MigStgCardProgram;
import com.svb.gateway.migration.cards.model.CardProgramInformation;
import com.svb.gateway.migration.cards.model.CardProgramInformationResponse;
import com.svb.gateway.migration.cards.model.EnrollCardRequest;
import com.svb.gateway.migration.cards.repository.CardProgramRepository;
import com.svb.gateway.migration.cards.repository.MigCardProgramRepository;
import com.svb.gateway.migration.cards.repository.MigStgClientRepository;
import com.svb.gateway.migration.client.entity.MigClient;
import com.svb.gateway.migration.client.entity.StgClient;
import com.svb.gateway.migration.client.repository.MigClientRepository;
import com.svb.gateway.migration.common.constants.MigrationConstants;
import com.svb.gateway.migration.common.exception.ServiceException;
import com.svb.gateway.migration.common.logging.Message;
import com.svb.gateway.migration.common.service.RetryService;
import com.svb.gateway.migration.common.utility.CacheManagerUtility;
import com.svb.gateway.migration.common.utility.RecordCount;
import com.svb.gateway.migration.common.entity.MigEntity;
import com.svb.gateway.migration.common.repository.MigEntityRepository;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.sql.Timestamp;
import java.util.Date;
import java.util.*;

import static com.svb.gateway.migration.common.constants.MigrationConstants.*;

/**
 * @author bmourya
 */

@Service
@Log4j2
public class CardsService {

    public static final String CARD_SUCCESS = "1";
    @Autowired
    CacheManagerUtility cacheManagerUtility;
    @Value(value = "${mig.cardsPost.url}")
    String cardsPostUrl;
    @Value("${header.service.token}")
    String token;
    @Value("${migration.service.userid}")
    String updatedBy;
    @Value("${header.cardService.token}")
    String cardToken;
    @Value(value = "${mig.userCards.principal}")
    String migUserUuid;
    @Autowired
    CardProgramRepository cardProgramRepository;
    @Autowired
    MigClientRepository migClientRepository;
    @Autowired
    MigCardProgramRepository migCardProgramRepository;
    @Autowired
    MigStgClientRepository migStgClientRepository;
    @Autowired
    MigEntityRepository migEntityRepository;
    @Autowired
    private RetryService retryService;

    public CardProgramInformationResponse addCardProgramToClient(Long jobId, MigClient migClient) throws ServiceException {

        Message logMessage = Message.create().jobId(jobId).clientId(migClient.getEcClientId()).operation("Enroll Card Program");

        Date dt = new Date();
        long startTime = dt.getTime();

        CardProgramInformationResponse cardProgramInformationResponse = new CardProgramInformationResponse();
        List<CardProgramInformation> cardProgramInformationList = new ArrayList<>();

        if (null != migClient && null != migClient.getEcClientId()) {
            StgClient stgClient = migStgClientRepository.findByOlbClinetId(jobId, migClient.getEcClientId());

            //Load card Program request payload from the staging tables
            List<MigStgCardProgram> migStgCardProgramList = cardProgramRepository.findByOlbId(jobId, migClient.getEcClientId());

            createCard(jobId, migClient.getGwClientId(), cardProgramInformationList, migClient, stgClient, migStgCardProgramList, startTime);
        }
        cardProgramInformationResponse.setCardProgramInformationList(cardProgramInformationList);
        log.info(logMessage.descr("Enroll CardProgram Ended for clientId:" + migClient.getEcClientId()));
        return cardProgramInformationResponse;

    }

    private void createCard(Long jobId, String olbClientId, List<CardProgramInformation> cardProgramInformationList, MigClient migClient, StgClient stgClient, List<MigStgCardProgram> migStgCardProgramList, Long startTime) throws ServiceException {

        //updating the count of Success/Failure cardPrograms
        MigEntity migEntity = new MigEntity();
        migEntity.setEntityName(ENROLL_CARD_PROGRAM);
        migEntity.setStartTime(new Timestamp(startTime));
        migEntity.setEcclientId(migClient.getEcClientId());
        migEntity.setGwclientId(olbClientId);
        migEntity.setCIF_NUMBER(migClient.getPrimaryCifUbs().toString());
        migEntity.setJobId(jobId.intValue());

        RecordCount recordCount = new RecordCount();

        Map<String, MigCardProgram> existingMigCardProgramsMap = new HashMap<>();
        List<MigCardProgram> existingMigCardPrograms = migCardProgramRepository.findByOlbId(migClient.getGwClientId());
        for (MigCardProgram migCardProgram : existingMigCardPrograms) {
            existingMigCardProgramsMap.put(migCardProgram.getProgramId(), migCardProgram);
        }

        EnrollCardRequest enrollCardRequest = new EnrollCardRequest();
        for (MigStgCardProgram migStgCardProgram : migStgCardProgramList) {

            if (!migStgCardProgram.getPrincipalId().equals(PRINCIPAL_ID)) {
                throw new ServiceException("This prn is not expected");
            }

            // staging companyId == the programId
            MigCardProgram existingMigCardProgram = existingMigCardProgramsMap.get(migStgCardProgram.getCompanyId());
            if (existingMigCardProgram != null && !existingMigCardProgram.canRunAgain()) {
                log.warn(Message.create().jobId(jobId).clientId(migStgCardProgram.getOlbClientId()).descr("MigCardProgram already processed for the source programId").srcId(existingMigCardProgram.getProgramId()));
            } else {
                enrollCard(cardProgramInformationList, migClient, stgClient, recordCount, enrollCardRequest, migStgCardProgram);
            }
        }
        recordCount.stopTime();
        migEntity.setReadCount(recordCount.getTotal());
        migEntity.setWriteCount(recordCount.getSuccess());
        migEntity.setSkipCount(recordCount.getFailure());
        Date dt = new Date();
        long endTime = dt.getTime();
        migEntity.setEndTime(new Timestamp(endTime));
        long duration = (endTime - startTime) / 1000;
        migEntity.setTotalStepTime(Math.toIntExact(duration));
        migEntity.setCreatedDateTime(new Timestamp(System.currentTimeMillis()));

        migEntityRepository.save(migEntity);
    }

    private void enrollCard(List<CardProgramInformation> cardProgramInformationList, MigClient migClient,
                            StgClient stgClient, RecordCount recordCount,
                            EnrollCardRequest enrollCardRequest, MigStgCardProgram migStgCardProgram) {
        Message logMessage = Message.create().clientId(stgClient.getOlbClinetId()).operation("EnrollCard");
        HttpHeaders headers = new HttpHeaders();
        ResponseEntity<CardProgramInformation> cardProgramInformationResponseEntity;
        enrollCardRequest.setAgent(migStgCardProgram.getAgentId());
        enrollCardRequest.setBillingType(migStgCardProgram.getBillingType());
        enrollCardRequest.setCif(migClient.getPrimaryCifUbs().toString());
        enrollCardRequest.setClientProfileName(stgClient.getClientName());
        enrollCardRequest.setCreditLine(migStgCardProgram.getLoanAccountNumber());
        enrollCardRequest.setOlbClientId(migClient.getGwClientId());
        enrollCardRequest.setPrn(migStgCardProgram.getPrincipalId());
        enrollCardRequest.setStatus(migStgCardProgram.getStatusCd());
        enrollCardRequest.setProgramId(migStgCardProgram.getCompanyId());
        enrollCardRequest.setProgramType(SVB_INNOVATORS_CARD);
        enrollCardRequest.setSys(migStgCardProgram.getSystemId());

        HttpEntity<EnrollCardRequest> requestEntity = new HttpEntity<>(enrollCardRequest, headers);

        String finalUrl = cardsPostUrl + migClient.getGwClientId() + CARD_PROGRAMS;

        MigCardProgram migCardProgram = new MigCardProgram();

        CardProgramInformation cardProgramInformation = null;
        try {
            cardProgramInformationResponseEntity = retryService.exchange(finalUrl, HttpMethod.POST, requestEntity, new ParameterizedTypeReference<CardProgramInformation>() {
            });

            if (cardProgramInformationResponseEntity.getBody() != null) {
                cardProgramInformation = cardProgramInformationResponseEntity.getBody();
                cardProgramInformationList.add(cardProgramInformation);
                if (cardProgramInformation == null) {
                    throw new ServiceException("Invalid card information");
                }
                //Saving the response in mIg_card_program table
                BeanUtils.copyProperties(cardProgramInformation, migCardProgram);

                if (migCardProgram.getStatus().equals(CARD_SUCCESS)) {
                    migCardProgram.setStatus(STATUS_SUCCESS);
                } else if (isNumeric(migCardProgram.getStatus())) {
                    migCardProgram.setStatus(STATUS_FAILURE);
                } else {
                    // it is a non numeric string and we assume it is a proper status string, so we do nothing
                }
                migCardProgram.setEcStatusCode(migStgCardProgram.getStatusCd());
                updateMigCardProgram(migClient, STATUS_SUCCESS, MigrationConstants.MIGRATED_SUCCESS, migStgCardProgram, migCardProgram);
                migCardProgramRepository.save(migCardProgram);
                log.info(logMessage.descr("CardProgram Info saved in mig_card_program table"));

                recordCount.updateCounter(migCardProgram.getStatus());
            } else {
                recordCount.addFailure();
            }
        } catch (Exception exception) {
            log.error(logMessage.descr("Exception occurred while creation card Program  reason : " + exception.getMessage()));
            updateMigCardProgram(migClient, STATUS_FAILURE, exception.getMessage(), migStgCardProgram, migCardProgram);
            migCardProgramRepository.save(migCardProgram);
            recordCount.addFailure();
        }
    }

    private boolean isNumeric(String status) {
        try {
            Integer.parseInt(status);
            return true;
        } catch (NumberFormatException e) {
            return false;
        }
    }

    private void updateMigCardProgram(MigClient migClient, String status, String comment, MigStgCardProgram migStgCardProgram, MigCardProgram migCardProgram) {

        migCardProgram.setOlbClientId(migClient.getGwClientId());
        migCardProgram.setEcClientId(migClient.getEcClientId());
        migCardProgram.setStatus(status);
        migCardProgram.setComments(comment);
        migCardProgram.setJobId(migClient.getJobId());
        migCardProgram.setEcStatusCode(migStgCardProgram.getStatusCd());
        migCardProgram.setProgramId(migStgCardProgram.getCompanyId());
        migCardProgram.setPrn(migStgCardProgram.getPrincipalId());
        migCardProgram.setCreditLine(migStgCardProgram.getLoanAccountNumber());
        migCardProgram.setClientProfileName(migClient.getClientName());
        migCardProgram.setCif(String.valueOf(migClient.getPrimaryCifUbs()));
        migCardProgram.setBillingType(migStgCardProgram.getBillingType());
        migCardProgram.setAgent(migStgCardProgram.getAgentId());
        migCardProgram.setProgramType(SVB_INNOVATORS_CARD);
        migCardProgram.setUpdatedBy(updatedBy);
        migCardProgram.setCreatedBy(updatedBy);
        migCardProgram.setCreatedDate(migStgCardProgram.getCreatedDt());
        Date dt = new Date();
        dt.getTime();
        migCardProgram.setUpdatedDate(dt);

    }

    public void rollbackCardProgram(String ecClientId) {

        try {
            List<MigCardProgram> migCardProgramList = migCardProgramRepository.findAllByEcClientIdAndStatus(ecClientId, STATUS_SUCCESS);
            if (!migCardProgramList.isEmpty()) {
                migCardProgramList.forEach(card -> card.setStatus(STATUS_ROLLED_BACK));
                migCardProgramRepository.saveAll(migCardProgramList);
            }
        } catch (Exception e) {
            log.error(Message.create().descr("CardProgram Rollback failed").clientId(ecClientId));
        }
    }

}
