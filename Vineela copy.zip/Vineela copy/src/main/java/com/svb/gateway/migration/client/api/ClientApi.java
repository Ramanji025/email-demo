package com.svb.gateway.migration.client.api;

import com.svb.gateway.migration.client.model.EnrollClientResponse;
import com.svb.gateway.migration.common.exception.ServiceException;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

@Api(value = "Client")
@RequestMapping("api/clients")
public interface ClientApi {

    @ApiOperation(value = "Endpoint for enrolling client and primary user on Gateway", nickname = "enrollClient", notes = "Enroll Client")
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Client enrollment is Successful "),
            @ApiResponse(code = 401, message = "Unauthorized"),
            @ApiResponse(code = 400, message = "Invalid Client Id or Company Id "),
            @ApiResponse(code = 403, message = "Forbidden"),
            @ApiResponse(code = 500, message = "Service unavailable ")})
    @PostMapping(value = "/enrollClient/{jobId}/{companyId}/{clientId}",
            produces = {"application/json"},
            consumes = MediaType.ALL_VALUE)
    @ResponseStatus(HttpStatus.OK)
    @PreAuthorize("hasAuthority(@migrationServiceConfig.getAuthExecute())")
    default ResponseEntity<EnrollClientResponse> enrollClient(@PathVariable Long jobId,
            @PathVariable String companyId, @PathVariable String clientId) throws ServiceException {
        return new ResponseEntity<>(HttpStatus.NOT_IMPLEMENTED);
    }

    @ApiOperation(value = "Endpoint for inActivating and deleting client on Gateway", nickname = "deleteClient", notes = "Delete Client")
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Client Deleltion is Successful "),
            @ApiResponse(code = 401, message = "Unauthorized"),
            @ApiResponse(code = 500, message = "Service unavailable ")})
    @DeleteMapping(path = "/deleteClient/{olbClientId}",
            consumes = MediaType.ALL_VALUE, produces = {"application/json"})
    @ResponseStatus(HttpStatus.OK)
    @PreAuthorize("hasAuthority(@migrationServiceConfig.getAuthExecute())")
    ResponseEntity<String> deleteClient(@PathVariable("olbClientId") String olbClientId) throws ServiceException;

}