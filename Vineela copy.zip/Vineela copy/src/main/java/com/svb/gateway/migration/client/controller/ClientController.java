package com.svb.gateway.migration.client.controller;

import com.svb.gateway.migration.client.api.ClientApi;
import com.svb.gateway.migration.client.model.DeleteClientResponse;
import com.svb.gateway.migration.client.model.EnrollClientResponse;
import com.svb.gateway.migration.client.service.ClientExtensionService;
import com.svb.gateway.migration.client.service.ClientService;
import com.svb.gateway.migration.common.constants.MigrationConstants;
import com.svb.gateway.migration.common.exception.ServiceException;
import org.apache.commons.text.StringEscapeUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import springfox.documentation.annotations.ApiIgnore;

@ApiIgnore
@RestController
public class ClientController implements ClientApi {

    private final ClientService clientService;

    @Autowired
    public ClientController(ClientService clientService, ClientExtensionService clientExtensionService) {
        this.clientService = clientService;
    }

    @Override
    public ResponseEntity<EnrollClientResponse> enrollClient(Long jobId, String companyId, String clientId) throws ServiceException {

        String cleansedClientId = StringEscapeUtils.escapeHtml4(clientId);
        String cleansedCompanyId = StringEscapeUtils.escapeHtml4(companyId);
        return new ResponseEntity<>(clientService.enrollClient(cleansedCompanyId, cleansedClientId, jobId), HttpStatus.OK);
    }

    @Override
    public ResponseEntity<String> deleteClient(String olbClientId) throws ServiceException {

        ResponseEntity<String> responseEntity;
        try {
            String cleansedOlbClientId = StringEscapeUtils.escapeHtml4(olbClientId);
            DeleteClientResponse deleteClientResponse = clientService.inactiveAndDeleteClient(cleansedOlbClientId);
            if (deleteClientResponse.getStatus().equals(MigrationConstants.STATUS_SUCCESS)) {
                responseEntity = new ResponseEntity<>("Client Deleted Successfully", HttpStatus.OK);
            } else {
                responseEntity = new ResponseEntity<>(deleteClientResponse.getMessage(), HttpStatus.NOT_FOUND);
            }

        } catch (Exception e) {
            responseEntity = new ResponseEntity<>(e.getMessage(), HttpStatus.NOT_FOUND);
        }
        return responseEntity;
    }
}
