package com.svb.gateway.migration.client.entity;

import com.svb.gateway.migration.common.processors.IRetry;

import javax.persistence.*;
import java.util.Date;

@Entity
@Table(name = "MIG_CLIENT")
public class MigClient implements IRetry {

    @GeneratedValue(strategy=GenerationType.IDENTITY)
    @Id
    @Column(name = "MIGCLIENTID")
    private Integer migratingClientId;

    @Column(name = "JOBID")
    private Long jobId;

    @Column(name = "ECCLIENTID")
    private String ecClientId;

    @Column(name = "GWCLIENTID")
    private String gwClientId;

    @Column(name = "CLIENTNAME")
    private String clientName;

    @Column(name = "COMPANYID")
    private String companyId;

    @Column(name = "PRIMARYCIFUBS")
    private Integer primaryCifUbs;

    @Column(name = "PRIMARYCIFCBS")
    private Long primaryCifCbs;

    @Column(name = "COMMENTS")
    private String comments;

    @Column(name = "STATUS")
    private String status;

    @Column(name = "UPDATEDBY")
    private String updatedBy;

    @Column(name = "UPDATEDDATE")
    private Date updateDate;

    @Column(name = "BDCSTATUS")
    private Integer bdcStatus;

    public Integer getMigratingClientId() {
        return migratingClientId;
    }

    public void setMigratingClientId(Integer migratingClientId) {
        this.migratingClientId = migratingClientId;
    }

    public Long getJobId() {
        return jobId;
    }

    public void setJobId(Long jobId) {
        this.jobId = jobId;
    }

    public String getEcClientId() {
        return ecClientId;
    }

    public void setEcClientId(String ecClientId) {
        this.ecClientId = ecClientId;
    }

    public String getGwClientId() {
        return gwClientId;
    }

    public void setGwClientId(String gwClientId) {
        this.gwClientId = gwClientId;
    }

    public String getClientName() {
        return clientName;
    }

    public void setClientName(String clientName) {
        this.clientName = clientName;
    }

    public String getCompanyId() {
        return companyId;
    }

    public void setCompanyId(String companyId) {
        this.companyId = companyId;
    }

    public Integer getPrimaryCifUbs() {
        return primaryCifUbs;
    }

    public void setPrimaryCifUbs(Integer primaryCifUbs) {
        this.primaryCifUbs = primaryCifUbs;
    }

    public Long getPrimaryCifCbs() {
        return primaryCifCbs;
    }

    public void setPrimaryCifCbs(Long primaryCifCbs) {
        this.primaryCifCbs = primaryCifCbs;
    }

    public String getComments() {
        return comments;
    }

    public void setComments(String comments) {
        this.comments = comments;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getUpdatedBy() {
        return updatedBy;
    }

    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }

    public Date getUpdateDate() {
        return updateDate;
    }

    public void setUpdateDate(Date updateDate) {
        this.updateDate = updateDate;
    }

    public Integer getBdcStatus() {
        return bdcStatus;
    }

    public void setBdcStatus(Integer bdcStatus) {
        this.bdcStatus = bdcStatus;
    }
}
