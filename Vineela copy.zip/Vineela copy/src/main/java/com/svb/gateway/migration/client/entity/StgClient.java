package com.svb.gateway.migration.client.entity;


import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.time.LocalDate;


@Entity
@Table(name = "MIG_STG_CLIENT")
public class StgClient {

    @Id
    @Column(name = "OLB_CLIENT_ID")
    private String olbClinetId;

    @Column(name = "PRIMARY_CIF_CBS")
    private String primaryCifCbs;

    @Column(name = "PRIMARY_CIF_UBS")
    private String primaryCifUbs;

    @Column(name = "CLIENT_NAME")
    private String clientName;

    @Column(name = "CLIENT_TYPE_ID")
    private String clientTypeId;

    @Column(name = "STATUS_FLG")
    private String statusFalg;

    @Column(name = "DUAL_ADMIN_APPROVE")
    private String dualAdminApprove;

   // @Column(name= "MIGRATED_CLIENT")
   // private String migratedClinet;

    @Column(name = "STATUS")
    private String status;

    @Column(name = "JOB_ID")
    private String jobId;

    @Column(name = "REMARKS")
    private String remarks;

    @Column(name = "CREATED_BY")
    private String createdBy;

    @Column(name = "CREATED_DT")
    private LocalDate createdDt;

    public String getOlbClinetId() {
        return olbClinetId;
    }

    public void setOlbClinetId(String olbClinetId) {
        this.olbClinetId = olbClinetId;
    }

    public String getPrimaryCifCbs() {
        return primaryCifCbs;
    }

    public void setPrimaryCifCbs(String primaryCifCbs) {
        this.primaryCifCbs = primaryCifCbs;
    }

    public String getPrimaryCifUbs() {
        return primaryCifUbs;
    }

    public void setPrimaryCifUbs(String primaryCifUbs) {
        this.primaryCifUbs = primaryCifUbs;
    }

    public String getClientName() {
        return clientName;
    }

    public void setClientName(String clientName) {
        this.clientName = clientName;
    }

    public String getClientTypeId() {
        return clientTypeId;
    }

    public void setClientTypeId(String clientTypeId) {
        this.clientTypeId = clientTypeId;
    }

    public String getStatusFalg() {
        return statusFalg;
    }

    public void setStatusFalg(String statusFalg) {
        this.statusFalg = statusFalg;
    }

    public String getDualAdminApprove() {
        return dualAdminApprove;
    }

    public void setDualAdminApprove(String dualAdminApprove) {
        this.dualAdminApprove = dualAdminApprove;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getJobId() {
        return jobId;
    }

    public void setJobId(String jobId) {
        this.jobId = jobId;
    }

    public String getRemarks() {
        return remarks;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public LocalDate getCreatedDt() {
        return createdDt;
    }

    public void setCreatedDt(LocalDate createdDt) {
        this.createdDt = createdDt;
    }
}
