
package com.svb.gateway.migration.client.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "accountNum",
        "prodCode",
        "accCcy",
        "accName",
        "accStatus",
        "accSvcType",
        "accSvcPlan",
        "accOpenDate",
        "prodDesc"
})
public class Account {

    @JsonProperty("accountNum")
    private String accountNum;
    @JsonProperty("prodCode")
    private String prodCode;
    @JsonProperty("accCcy")
    private String accCcy;
    @JsonProperty("accName")
    private String accName;
    @JsonProperty("accStatus")
    private String accStatus;
    @JsonProperty("accSvcType")
    private String accSvcType;
	@JsonProperty("accSvcPlan")
    private String accSvcPlan;
	@JsonProperty("accOpenDate")
    private String accOpenDate;
	@JsonProperty("prodDesc")
	private String prodDesc;

    @JsonProperty("accountNum")
    public String getAccountNum() {
        return accountNum;
    }

    @JsonProperty("accountNum")
    public void setAccountNum(String accountNum) {
        this.accountNum = accountNum;
    }

    @JsonProperty("prodCode")
    public String getProdCode() {
        return prodCode;
    }

    @JsonProperty("prodCode")
    public void setProdCode(String prodCode) {
        this.prodCode = prodCode;
    }

    @JsonProperty("accCcy")
    public String getAccCcy() {
        return accCcy;
    }

    @JsonProperty("accCcy")
    public void setAccCcy(String accCcy) {
        this.accCcy = accCcy;
    }

    @JsonProperty("accName")
    public String getAccName() {
        return accName;
    }

    @JsonProperty("accName")
    public void setAccName(String accName) {
        this.accName = accName;
    }

    @JsonProperty("accStatus")
    public String getAccStatus() {
        return accStatus;
    }

    @JsonProperty("accStatus")
    public void setAccStatus(String accStatus) {
        this.accStatus = accStatus;
    }

    @JsonProperty("accSvcType")
    public String getAccSvcType() {
		return accSvcType;
	}
    
    @JsonProperty("accSvcType")
	public void setAccSvcType(String accSvcType) {
		this.accSvcType = accSvcType;
	}

    @JsonProperty("accSvcPlan")
	public String getAccSvcPlan() {
		return accSvcPlan;
	}

    @JsonProperty("accSvcPlan")
	public void setAccSvcPlan(String accSvcPlan) {
		this.accSvcPlan = accSvcPlan;
	}
    
    @JsonProperty("accOpenDate")
    public String getAccOpenDate() {
		return accOpenDate;
	}

    @JsonProperty("accOpenDate")
	public void setAccOpenDate(String accOpenDate) {
		this.accOpenDate = accOpenDate;
	}

	@JsonProperty("prodDesc")
    public String getProdDesc() {
		return prodDesc;
	}

    @JsonProperty("prodDesc")
	public void setProdDesc(String prodDesc) {
		this.prodDesc = prodDesc;
	}

}
