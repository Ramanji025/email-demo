package com.svb.gateway.migration.client.model;

import java.util.List;

public class AccountServices {

    private String accountNum;
    private String accountTyp;
    private String prodCode;
    private String accStat;
    private String accCcy;
    private String accName;
    private List< SvbService > accServ;

    public String getAccountNum() {
        return accountNum;
    }

    public void setAccountNum(String accountNum) {
        this.accountNum = accountNum;
    }

    public String getAccountTyp() {
        return accountTyp;
    }

    public void setAccountTyp(String accountTyp) {
        this.accountTyp = accountTyp;
    }

    public String getProdCode() {
        return prodCode;
    }

    public void setProdCode(String prodCode) {
        this.prodCode = prodCode;
    }

    public String getAccStat() {
        return accStat;
    }

    public void setAccStat(String accStat) {
        this.accStat = accStat;
    }

    public String getAccCcy() {
        return accCcy;
    }

    public void setAccCcy(String accCcy) {
        this.accCcy = accCcy;
    }

    public String getAccName() {
        return accName;
    }

    public void setAccName(String accName) {
        this.accName = accName;
    }

    public List< SvbService > getAccServ() {
        return accServ;
    }

    public void setAccServ(List< SvbService > accServ) {
        this.accServ = accServ;
    }
}
