package com.svb.gateway.migration.client.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import java.util.List;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "clientPartners"
})
public class BdcClient {

    @JsonProperty("clientPartners")
    private List<ClientPartners> clientPartners;

    public List<ClientPartners> getClientPartners() {
        return clientPartners;
    }

    public void setClientPartners(List<ClientPartners> clientPartners) {
        this.clientPartners = clientPartners;
    }
}
