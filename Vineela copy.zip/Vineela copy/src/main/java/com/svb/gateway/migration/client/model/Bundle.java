package com.svb.gateway.migration.client.model;

import java.util.List;

public class Bundle {

    private Integer digitalBundleId;
    private String digitalBundleName;
    private List<BundleServices> services;

    public Integer getDigitalBundleId() {
        return digitalBundleId;
    }

    public void setDigitalBundleId(Integer digitalBundleId) {
        this.digitalBundleId = digitalBundleId;
    }

    public String getDigitalBundleName() {
        return digitalBundleName;
    }

    public void setDigitalBundleName(String digitalBundleName) {
        this.digitalBundleName = digitalBundleName;
    }

    public List<BundleServices> getServices() {
        return services;
    }

    public void setServices(List<BundleServices> services) {
        this.services = services;
    }


}
