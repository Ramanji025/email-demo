package com.svb.gateway.migration.client.model;

public class BundleServices {

    private SvbService service;

    public SvbService getService() {
        return service;
    }

    public void setService(SvbService service) {
        this.service = service;
    }
}
