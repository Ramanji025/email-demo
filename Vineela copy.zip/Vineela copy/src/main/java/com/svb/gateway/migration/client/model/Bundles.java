package com.svb.gateway.migration.client.model;

import java.util.List;

public class Bundles {
    private List<Bundle> digitalBundles;

    public List<Bundle> getDigitalBundles() {
        return digitalBundles;
    }

    public void setDigitalBundles(List<Bundle> digitalBundles) {
        this.digitalBundles = digitalBundles;
    }


}
