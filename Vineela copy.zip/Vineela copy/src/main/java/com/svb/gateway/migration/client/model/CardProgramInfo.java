package com.svb.gateway.migration.client.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
	"cif",
    "programId",
    "creditLine",
    "billingType",
    "programType",
    "sys",
    "prn",
    "agent"
})
public class CardProgramInfo {

	@JsonProperty("cif")
	private String cif;
	@JsonProperty("programId")
	private String programId;
	@JsonProperty("creditLine")
	private String creditLine;
	@JsonProperty("billingType")
	private String billingType;
	@JsonProperty("programType")
	private String programType;
	@JsonProperty("sys")
	private String sys;
	@JsonProperty("prn")
	private String prn;
	@JsonProperty("agent")
	private String agent;

	public String getCif() {
		return cif;
	}
	public void setCif(String cif) {
		this.cif = cif;
	}
	public String getProgramId() {
		return programId;
	}
	public void setProgramId(String programId) {
		this.programId = programId;
	}
	public String getCreditLine() {
		return creditLine;
	}
	public void setCreditLine(String creditLine) {
		this.creditLine = creditLine;
	}
	public String getBillingType() {
		return billingType;
	}
	public void setBillingType(String billingType) {
		this.billingType = billingType;
	}
	public String getProgramType() {
		return programType;
	}
	public void setProgramType(String programType) {
		this.programType = programType;
	}
	public String getSys() {
		return sys;
	}
	public void setSys(String sys) {
		this.sys = sys;
	}
	public String getPrn() {
		return prn;
	}
	public void setPrn(String prn) {
		this.prn = prn;
	}
	public String getAgent() {
		return agent;
	}
	public void setAgent(String agent) {
		this.agent = agent;
	}
}
