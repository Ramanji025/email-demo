package com.svb.gateway.migration.client.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    	"cbsCifNumber",
    	"ubsCifNumber",
    	"name",
    	"addressLine1",
    	"addressLine2",
    	"addressLine3",
    	"city",
    	"state",
    	"country",
    	"zip",
    	"phoneNumber",
    	"teamCode",
    	"dateOpened",
    	"clientId",
    	"cifAccounts",
        "cifNumber",
        "Primary",
        "accountDetails",
        "taxId"
})
public class Cif {

	@JsonProperty("cbsCifNum")
    private String cbsCifNum;
	@JsonProperty("ubsCifNum")
    private String ubsCifNum;
	@JsonProperty("name")
    private String name;
	@JsonProperty("addressLine1")
    private String addressLine1;
	@JsonProperty("addressLine2")
    private String addressLine2;
	@JsonProperty("addressLine3")
    private String addressLine3;
	@JsonProperty("city")
    private String city;
	@JsonProperty("state")
    private String state;
	@JsonProperty("country")
    private String country;
	@JsonProperty("zip")
    private String zip;
	@JsonProperty("phoneNumber")
    private String phoneNumber;
	@JsonProperty("teamCode")
    private String teamCode;
	@JsonProperty("teamName")
	private String teamName;
	@JsonProperty("teamCodeEmail")
	private String teamCodeEmail;
	@JsonProperty("dateOpened")
    private String dateOpened;
	@JsonProperty("clientId")
    private String clientId;
	@JsonProperty("cifAccounts")
    private List< AccountServices > cifAccounts;
    @JsonProperty("cifNumber")
    private String cifNumber;
    @JsonProperty("Primary")
    private String primary;
    @JsonProperty("accountDetails")
    private List< Account > accountDetails = null;
    @JsonProperty("taxId")
    private String taxId;

    public String getCbsCifNum() {
        return cbsCifNum;
    }

    public void setCbsCifNum(String cbsCifNum) {
        this.cbsCifNum = cbsCifNum;
    }

    public String getUbsCifNum() {
        return ubsCifNum;
    }

    public void setUbsCifNum(String ubsCifNum) {
        this.ubsCifNum = ubsCifNum;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAddressLine1() {
        return addressLine1;
    }

    public void setAddressLine1(String addressLine1) {
        this.addressLine1 = addressLine1;
    }

    public String getAddressLine2() {
        return addressLine2;
    }

    public void setAddressLine2(String addressLine2) {
        this.addressLine2 = addressLine2;
    }

    public String getAddressLine3() {
        return addressLine3;
    }

    public void setAddressLine3(String addressLine3) {
        this.addressLine3 = addressLine3;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getZip() {
        return zip;
    }

    public void setZip(String zip) {
        this.zip = zip;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public String getTeamCode() {
        return teamCode;
    }

    public void setTeamCode(String teamCode) {
        this.teamCode = teamCode;
    }

    public List< AccountServices > getCifAccounts() {
        return cifAccounts;
    }

    public void setCifAccounts(List< AccountServices > cifAccounts) {
        this.cifAccounts = cifAccounts;
    }

    public String getDateOpened() {
        return dateOpened;
    }

    public void setDateOpened(String dateOpened) {
        this.dateOpened = dateOpened;
    }

    public String getClientId() {
        return clientId;
    }

    public void setClientId(String clientId) {
        this.clientId = clientId;
    }

	public String getCifNumber() {
		return cifNumber;
	}

	public void setCifNumber(String cifNumber) {
		this.cifNumber = cifNumber;
	}

	public String getPrimary() {
		return primary;
	}

	public void setPrimary(String primary) {
		this.primary = primary;
	}

	public List<Account> getAccountDetails() {
		return accountDetails;
	}

	public void setAccountDetails(List<Account> accountDetails) {
		this.accountDetails = accountDetails;
	}

	public String getTeamName() {
		return teamName;
	}

	public void setTeamName(String teamName) {
		this.teamName = teamName;
	}

	public String getTeamCodeEmail() {
		return teamCodeEmail;
	}

	public void setTeamCodeEmail(String teamCodeEmail) {
		this.teamCodeEmail = teamCodeEmail;
	}

	public String getTaxId() {
		return taxId;
	}

	public void setTaxId(String taxId) {
		this.taxId = taxId;
	}
    
}
