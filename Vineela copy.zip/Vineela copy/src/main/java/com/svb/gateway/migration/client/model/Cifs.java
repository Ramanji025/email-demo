package com.svb.gateway.migration.client.model;

import java.util.List;

public class Cifs {

	private List< Cif > cifData;

	public List< Cif > getCifData() {
		return cifData;
	}

	public void setCifData(List< Cif > cifData) {
		this.cifData = cifData;
	}
}
