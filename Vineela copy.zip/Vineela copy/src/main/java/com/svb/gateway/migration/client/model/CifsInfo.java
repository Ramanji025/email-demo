package com.svb.gateway.migration.client.model;

import java.util.List;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
		"CifData"
})
public class CifsInfo {

	@JsonProperty("cifs")
	private List< CifsInfo > cifData;

	@JsonProperty("cifs")
	public List< CifsInfo > getCifData() {
		return cifData;
	}

	@JsonProperty("cifs")
	public void setCifData(List< CifsInfo > cifData) {
		this.cifData = cifData;
	}
}
