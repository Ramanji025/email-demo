package com.svb.gateway.migration.client.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateTimeDeserializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateTimeSerializer;

import java.time.LocalDateTime;
import java.util.List;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "profileName",
        "olbId",
        "ecClientId",
        "segment",
        "digitalBundle",
        "bundleName",
        "billingAccount",
        "clientLoginId",
        "enrollmentDate",
        "migratedClient",
        "clientCardPrograms"
})
public class Client {

    @JsonProperty("profileName")
    private String profileName;
    @JsonProperty("olbId")
    private String olbId;
    @JsonProperty("ecClientId")
    private String ecClientId;
    @JsonProperty("segment")
    private String segment;
    @JsonProperty("digitalBundle")
    private String digitalBundle;
    @JsonProperty("bundleName")
    private String bundleName;
    @JsonProperty("billingAccount")
    private String billingAccount;
    @JsonProperty("cifs")
    private List<String> cifs;
    @JsonProperty("userDetails")
    private List<ClientUser> userDetails;
    @JsonProperty("clientServices")
    private List<ClientService> clientServices;
    @JsonProperty("clientLoginId")
    private String clientLoginId;
    @JsonProperty("clientCardPrograms")
    private List<CardProgramInfo> cardProgramsInfo;
    @JsonProperty("migratedClient")
    private String migrationFlag;

    @JsonProperty("enrollmentDate")
    @JsonSerialize(using = LocalDateTimeSerializer.class)
    @JsonDeserialize(using = LocalDateTimeDeserializer.class)
    @JsonFormat(pattern = "yyyy-MM-dd'T'hh:mm:ss.SSS'Z'")
    private LocalDateTime enrollmentDate;


    @JsonProperty("profileName")
    public String getProfileName() {
        return profileName;
    }

    @JsonProperty("profileName")
    public void setProfileName(String profileName) {
        this.profileName = profileName;
    }

    @JsonProperty("olbId")
    public String getOlbId() {
        return olbId;
    }

    @JsonProperty("olbId")
    public void setOlbId(String olbId) {
        this.olbId = olbId;
    }

    @JsonProperty("segment")
    public String getSegment() {
        return segment;
    }

    @JsonProperty("segment")
    public void setSegment(String segment) {
        this.segment = segment;
    }

    @JsonProperty("digitalBundle")
    public String getDigitalBundle() {
        return digitalBundle;
    }

    @JsonProperty("digitalBundle")
    public void setDigitalBundle(String digitalBundle) {
        this.digitalBundle = digitalBundle;
    }

    @JsonProperty("billingAccount")
    public String getBillingAccount() {
        return billingAccount;
    }

    @JsonProperty("billingAccount")
    public void setBillingAccount(String billingAccount) {
        this.billingAccount = billingAccount;
    }

    @JsonProperty("bundleName")
    public String getBundleName() {
        return bundleName;
    }

    @JsonProperty("bundleName")
    public void setBundleName(String bundleName) {
        this.bundleName = bundleName;
    }

    @JsonProperty("cifs")
    public List<String> getCifs() {
        return cifs;
    }

    @JsonProperty("cifs")
    public void setCifs(List<String> cifs) {
        this.cifs = cifs;
    }

    @JsonProperty("userDetails")
    public List<ClientUser> getUserDetails() {
        return userDetails;
    }

    @JsonProperty("userDetails")
    public void setUserDetails(List<ClientUser> userDetails) {
        this.userDetails = userDetails;
    }

    @JsonProperty("clientServices")
    public List<ClientService> getClientServices() {
        return clientServices;
    }

    @JsonProperty("clientServices")
    public void setClientServices(List<ClientService> clientServices) {
        this.clientServices = clientServices;
    }

    @JsonProperty("clientLoginId")
    public String getClientLoginId() {
        return clientLoginId;
    }

    @JsonProperty("clientLoginId")
    public void setClientLoginId(String clientLoginId) {
        this.clientLoginId = clientLoginId;
    }

    @JsonProperty("enrollmentDate")
    public LocalDateTime getEnrollmentDate() {
        return enrollmentDate;
    }

    @JsonProperty("enrollmentDate")
    public void setEnrollmentDate(LocalDateTime enrollmentDate) {
        this.enrollmentDate = enrollmentDate;
    }

    @JsonProperty("clientCardPrograms")
    public List<CardProgramInfo> getCardProgramsInfo() {
        return cardProgramsInfo;
    }

    @JsonProperty("clientCardPrograms")
    public void setCardProgramsInfo(List<CardProgramInfo> cardProgramsInfo) {
        this.cardProgramsInfo = cardProgramsInfo;
    }

    @JsonProperty("migratedClient")
    public String getMigrationFlag() {
        return migrationFlag;
    }

    @JsonProperty("migratedClient")
    public void setMigrationFlag(String migrationFlag) {
        this.migrationFlag = migrationFlag;
    }

    @JsonProperty("ecClientId")
    public String getEcClientId() {
        return ecClientId;
    }

    @JsonProperty("ecClientId")
    public void setEcClientId(String ecClientId) {
        this.ecClientId = ecClientId;
    }
}
