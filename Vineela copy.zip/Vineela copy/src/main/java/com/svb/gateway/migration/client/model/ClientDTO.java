package com.svb.gateway.migration.client.model;

import com.svb.gateway.migration.client.entity.StgClient;
import com.svb.gateway.migration.user.entity.StgUser;
import com.svb.gateway.migration.user.model.User;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ClientDTO {

    private String companyLoginId;
    private String migratingClientId;
    private StgClient stgClient;
    private Cif primaryCifDetails;
    private Client client;
    private String gwClientId;
    private String status;
    private String comments;
    private StgUser primaryUserDetails;
    private User primaryUser;
    private String gwPrimaryUserId;
}
