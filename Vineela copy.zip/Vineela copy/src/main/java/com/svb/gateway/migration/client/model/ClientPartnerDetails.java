package com.svb.gateway.migration.client.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "partnerTaskId",
        "partnerTaskName",
        "partnerTaskStatus",
        "partnerTaskDetails"
})
public class ClientPartnerDetails {

    @JsonProperty("partnerTaskId")
    private String partnerTaskId;

    @JsonProperty("partnerTaskName")
    private String partnerTaskName;

    @JsonProperty("partnerTaskStatus")
    private String partnerTaskStatus;

    @JsonProperty("partnerTaskDetails")
    private String partnerTaskDetails;

    public String getPartnerTaskId() {
        return partnerTaskId;
    }

    public void setPartnerTaskId(String partnerTaskId) {
        this.partnerTaskId = partnerTaskId;
    }

    public String getPartnerTaskName() {
        return partnerTaskName;
    }

    public void setPartnerTaskName(String partnerTaskName) {
        this.partnerTaskName = partnerTaskName;
    }

    public String getPartnerTaskStatus() {
        return partnerTaskStatus;
    }

    public void setPartnerTaskStatus(String partnerTaskStatus) {
        this.partnerTaskStatus = partnerTaskStatus;
    }

    public String getPartnerTaskDetails() {
        return partnerTaskDetails;
    }

    public void setPartnerTaskDetails(String partnerTaskDetails) {
        this.partnerTaskDetails = partnerTaskDetails;
    }
}
