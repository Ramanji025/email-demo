package com.svb.gateway.migration.client.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import java.util.List;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "partnerId",
        "partnerName",
        "partnerStatus",
        "clientPartnerDetails"
})
public class ClientPartners {

    @JsonProperty("partnerId")
    private String partnerId;
    @JsonProperty("partnerName")
    private String partnerName;
    @JsonProperty("partnerStatus")
    private String partnerStatus;
    @JsonProperty("clientPartnerDetails")
    private List<ClientPartnerDetails> clientPartnerDetails;

    public String getPartnerId() {
        return partnerId;
    }

    public void setPartnerId(String partnerId) {
        this.partnerId = partnerId;
    }

    public String getPartnerName() {
        return partnerName;
    }

    public void setPartnerName(String partnerName) {
        this.partnerName = partnerName;
    }

    public String getPartnerStatus() {
        return partnerStatus;
    }

    public void setPartnerStatus(String partnerStatus) {
        this.partnerStatus = partnerStatus;
    }

    public List<ClientPartnerDetails> getClientPartnerDetails() {
        return clientPartnerDetails;
    }

    public void setClientPartnerDetails(List<ClientPartnerDetails> clientPartnerDetails) {
        this.clientPartnerDetails = clientPartnerDetails;
    }
}
