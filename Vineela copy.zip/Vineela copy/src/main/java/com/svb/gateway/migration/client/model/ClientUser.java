
package com.svb.gateway.migration.client.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.svb.gateway.migration.user.model.UserAccount;

public class ClientUser {

    @JsonProperty("userLoginId")
    private String userLoginId;
    @JsonProperty("UserAccounts")
    private List<UserAccount> userAccountService = null;

    @JsonProperty("userLoginId")
    public String getUserLoginId() {
        return userLoginId;
    }

    @JsonProperty("userLoginId")
    public void setUserLoginId(String userLoginId) {
        this.userLoginId = userLoginId;
    }

    public List< UserAccount > getUserAccountService() {
        return userAccountService;
    }

    public void setUserAccountService(List< UserAccount > userAccountService) {
        this.userAccountService = userAccountService;
    }


}
