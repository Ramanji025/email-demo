package com.svb.gateway.migration.client.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModelProperty;

import javax.validation.constraints.NotNull;

public class DeleteClientResponse {

    @JsonProperty("Status")
    private String status;
    @JsonProperty("Message")
    private String message="";

    @ApiModelProperty(required = true, value = ".")
    @NotNull
    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

}
