package com.svb.gateway.migration.client.model;

import com.fasterxml.jackson.annotation.*;
import com.svb.gateway.migration.common.constants.MigrationConstants;
import com.svb.gateway.migration.common.model.Error;
import com.svb.gateway.migration.common.processors.IRetry;
import com.svb.gateway.migration.job.model.CreateJobResponse;
import com.svb.gateway.migration.job.model.CreateJobResponseData;
import io.swagger.annotations.ApiModelProperty;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class EnrollClientResponse implements IRetry {

    @JsonProperty("Data")
    private EnrollClientResponseData data = null;

    @JsonProperty("Errors")
    private List<Error> errors = null;

    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    public EnrollClientResponse data(EnrollClientResponseData data) {
        this.data = data;
        return this;
    }

    @ApiModelProperty(required = true, value = "")
    @NotNull
    @Valid
    public EnrollClientResponseData getData() {
        return data;
    }

    public void setData(EnrollClientResponseData data) {
        this.data = data;
    }

    @ApiModelProperty(required = true, value = "")
    @Valid
    public List<Error> getErrors() {
        return errors;
    }

    public void setErrors(List<Error> errors) {
        this.errors = errors;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public String getStatus(){
        if(getData()==null){
            return MigrationConstants.STATUS_FAILURE;
        }
        else{
            return getData().getStatus();
        }
    }
}
