package com.svb.gateway.migration.client.model;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModelProperty;

import javax.validation.constraints.NotNull;
import java.util.HashMap;
import java.util.Map;

public class EnrollClientResponseData {
    @JsonProperty("GWClientId")
    private String gwClientId;

    @JsonProperty("GWPrimaryUserId")
    private String gwPrimaryUserId;

    @JsonProperty("Status")
    private String status;

    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public EnrollClientResponseData gwClientId(String gwClientId) {
        this.gwClientId = gwClientId;
        return this;
    }

    @ApiModelProperty(required = true, value = ".")
    @NotNull
    public String getGwClientId() {
        return gwClientId;
    }

    public void setGwClientId(String gwClientId) {
        this.gwClientId = gwClientId;
    }

    public EnrollClientResponseData status (String status) {
        this.status = status;
        return this;
    }

    @ApiModelProperty(required = true, value = ".")
    @NotNull
    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public EnrollClientResponseData gwPrimaryUserId (String status) {
        this.status = status;
        return this;
    }

    @ApiModelProperty(required = true, value = ".")
    @NotNull
    public String getGwPrimaryUserId() {
        return gwPrimaryUserId;
    }

    public void setGwPrimaryUserId(String gwPrimaryUserId) {
        this.gwPrimaryUserId = gwPrimaryUserId;
    }
}
