package com.svb.gateway.migration.client.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModelProperty;

import javax.validation.constraints.NotNull;

public class InActiveClientResponse {

    @JsonProperty("Status")
    private Integer statusCode;

    @ApiModelProperty(required = true, value = ".")
    @NotNull
    public Integer getStatusCode() {
        return statusCode;
    }

    public void setStatusCode(Integer status) {
        this.statusCode = status;
    }
}
