package com.svb.gateway.migration.client.model;

import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;
import java.util.Date;

@Getter
@Setter
public class MigClientDTO implements Serializable {


    private Integer migratingClientId;
    private Long jobId;
    private String ecClientId;
    private String gwClientId;
    private String clientName;
    private String companyId;
    private Integer primaryCifUbs;
    private Long primaryCifCbs;
    private String comments;
    private String status;
    private String updatedBy;
    private Date updateDate;
    private Integer bdcStatus;
    
}
