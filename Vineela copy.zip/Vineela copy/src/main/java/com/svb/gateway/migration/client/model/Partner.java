package com.svb.gateway.migration.client.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "partnerId",
    "partnerName",
    "partnerTasks"
})
public class Partner {

	@JsonProperty("partnerId")
	private String partnerId;
	@JsonProperty("partnerName")
	private String partnerName;
	@JsonProperty("partnerTasks")
	private List<PartnerTask> partnerTasks;
	
	
	public String getPartnerId() {
		return partnerId;
	}
	public void setPartnerId(String partnerId) {
		this.partnerId = partnerId;
	}
	public String getPartnerName() {
		return partnerName;
	}
	public void setPartnerName(String partnerName) {
		this.partnerName = partnerName;
	}
	public List<PartnerTask> getPartnerTasks() {
		return partnerTasks;
	}
	public void setPartnerTasks(List<PartnerTask> partnerTasks) {
		this.partnerTasks = partnerTasks;
	}
	
	
	
}
