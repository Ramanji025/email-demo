package com.svb.gateway.migration.client.model;

import java.time.LocalDateTime;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateTimeDeserializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateTimeSerializer;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "partnerTaskId",
    "partnerTaskName",
    "partnerTaskStatus",
    "partnerTaskDetails"
})
public class PartnerTask {

	@JsonProperty("partnerTaskId")
	private String partnerTaskId;
	@JsonProperty("partnerTaskName")
	private String partnerTaskName;
	@JsonProperty("partnerTaskStatus")
	private String partnerTaskStatus;
	@JsonProperty("partnerTaskDetails")
	private String partnerTaskDetails;
	@JsonProperty("createdOn")
    @JsonSerialize(using = LocalDateTimeSerializer.class)
    @JsonDeserialize(using = LocalDateTimeDeserializer.class)
    @JsonFormat(pattern = "yyyy-MM-dd'T'hh:mm:ss.SSS'Z'")
	private LocalDateTime createdOn;
	
	public String getPartnerTaskId() {
		return partnerTaskId;
	}
	public void setPartnerTaskId(String partnerTaskId) {
		this.partnerTaskId = partnerTaskId;
	}
	public String getPartnerTaskName() {
		return partnerTaskName;
	}
	public void setPartnerTaskName(String partnerTaskName) {
		this.partnerTaskName = partnerTaskName;
	}
	public String getPartnerTaskStatus() {
		return partnerTaskStatus;
	}
	public void setPartnerTaskStatus(String partnerTaskStatus) {
		this.partnerTaskStatus = partnerTaskStatus;
	}
	public String getPartnerTaskDetails() {
		return partnerTaskDetails;
	}
	public void setPartnerTaskDetails(String partnerTaskDetails) {
		this.partnerTaskDetails = partnerTaskDetails;
	}
	public LocalDateTime getCreatedOn() {
		return createdOn;
	}
	public void setCreatedOn(LocalDateTime createdOn) {
		this.createdOn = createdOn;
	}
	
}
