package com.svb.gateway.migration.client.model;


import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import java.util.List;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "partnerId",
        "partnerName",
        "partnerTasks"
})
public class Partners {

    @JsonProperty("partnerId")
    private String partnerId;
    @JsonProperty("partnerName")
    private String partnerName;
    @JsonProperty("partnerTasks")
    private List<PartnerTasks> partnerTasks;

    public String getPartnerId() {
        return partnerId;
    }

    public void setPartnerId(String partnerId) {
        this.partnerId = partnerId;
    }

    public String getPartnerName() {
        return partnerName;
    }

    public void setPartnerName(String partnerName) {
        this.partnerName = partnerName;
    }

    public List<PartnerTasks> getPartnerTasks() {
        return partnerTasks;
    }

    public void setPartnerTasks(List<PartnerTasks> partnerTasks) {
        this.partnerTasks = partnerTasks;
    }
}
