
package com.svb.gateway.migration.client.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "svcTxnId",
    "svcTxnName",
    "svcTxnDisplayName",
    "svcTxnType",
    "svcAction",
    "operation",
    "serviceId",
    "serviceDisplayName"
})
public class ServiceTransaction {

    @JsonProperty("svcTxnId")
    private String svcTxnId;
    @JsonProperty("svcTxnName")
    private String svcTxnName;
    @JsonProperty("svcTxnDisplayName")
    private String svcTxnDisplayName;
    @JsonProperty("svcTxnType")
    private String svcTxnType;
    @JsonProperty("svcAction")
    private String svcAction;
    @JsonProperty("operation")
    private String operation;
    @JsonProperty("acctSpecificTxn")
    private String acctSpecificTxn;
    

    @JsonProperty("svcTxnId")
    public String getSvcTxnId() {
        return svcTxnId;
    }

    @JsonProperty("svcTxnId")
    public void setSvcTxnId(String svcTxnId) {
        this.svcTxnId = svcTxnId;
    }

    @JsonProperty("svcTxnName")
    public String getSvcTxnName() {
        return svcTxnName;
    }

    @JsonProperty("svcTxnName")
    public void setSvcTxnName(String svcTxnName) {
        this.svcTxnName = svcTxnName;
    }

    @JsonProperty("svcAction")
    public String getSvcAction() {
        return svcAction;
    }

    @JsonProperty("svcAction")
    public void setSvcAction(String svcAction) {
        this.svcAction = svcAction;
    }

    @JsonProperty("svcTxnType")
	public String getSvcTxnType() {
		return svcTxnType;
	}

    @JsonProperty("svcTxnType")
	public void setSvcTxnType(String svcTxnType) {
		this.svcTxnType = svcTxnType;
	}

    @JsonProperty("operation")
	public String getOperation() {
		return operation;
	}

    @JsonProperty("operation")
	public void setOperation(String operation) {
		this.operation = operation;
	}

	@JsonProperty("svcTxnDisplayName")
	public String getSvcTxnDisplayName() {
		return svcTxnDisplayName;
	}

	@JsonProperty("svcTxnDisplayName")
	public void setSvcTxnDisplayName(String svcTxnDisplayName) {
		this.svcTxnDisplayName = svcTxnDisplayName;
	}

	@JsonProperty("acctSpecificTxn")
	public String getAcctSpecificTxn() {
		return acctSpecificTxn;
	}

	@JsonProperty("acctSpecificTxn")
	public void setAcctSpecificTxn(String acctSpecificTxn) {
		this.acctSpecificTxn = acctSpecificTxn;
	}

}
