package com.svb.gateway.migration.client.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class SvbService {

	@JsonProperty("serviceId")
	private String serviceId;
	@JsonProperty("serviceName")
	private String serviceName;
	@JsonProperty("serviceDisplayName")
	private String serviceDisplayName;
	@JsonProperty("serviceType")
	private String serviceType;
	@JsonProperty("svcTxnDetails")
	private List< ServiceTransaction > serviceTxn;

	@JsonProperty("serviceId")
	public String getServiceId() {
		return serviceId;
	}

	@JsonProperty("serviceId")
	public void setServiceId(String serviceId) {
		this.serviceId = serviceId;
	}

	@JsonProperty("serviceName")
	public String getServiceName() {
		return serviceName;
	}

	@JsonProperty("serviceName")
	public void setServiceName(String serviceName) {
		this.serviceName = serviceName;
	}

	@JsonProperty("serviceDisplayName")
	public String getServiceDisplayName() {
		return serviceDisplayName;
	}

	@JsonProperty("serviceDisplayName")
	public void setServiceDisplayName(String serviceDisplayName) {
		this.serviceDisplayName = serviceDisplayName;
	}

	@JsonProperty("serviceType")
	public String getServiceType() {
		return serviceType;
	}

	@JsonProperty("serviceType")
	public void setServiceType(String serviceType) {
		this.serviceType = serviceType;
	}

	@JsonProperty("svcTxnDetails")
	public List< ServiceTransaction > getServiceTxn() {
		return serviceTxn;
	}

	@JsonProperty("svcTxnDetails")
	public void setServiceTxn(List< ServiceTransaction > serviceTxn) {
		this.serviceTxn = serviceTxn;
	}
}
