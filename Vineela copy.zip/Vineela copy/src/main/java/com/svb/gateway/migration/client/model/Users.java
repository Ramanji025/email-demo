package com.svb.gateway.migration.client.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import java.util.List;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "idStoreuserkey",
        "userFname",
        "userLname",
        "userstatus",
        "partners"
})
public class Users {
    @JsonProperty("idStoreuserkey")
    private String idStoreuserkey;
    @JsonProperty("userFname")
    private String userFname;
    @JsonProperty("userLname")
    private String userLname;
    @JsonProperty("userstatus")
    private String userstatus;
    @JsonProperty("partners")
    private List<Partners> partners;

    public String getIdStoreuserkey() {
        return idStoreuserkey;
    }

    public void setIdStoreuserkey(String idStoreuserkey) {
        this.idStoreuserkey = idStoreuserkey;
    }

    public String getUserFname() {
        return userFname;
    }

    public void setUserFname(String userFname) {
        this.userFname = userFname;
    }

    public String getUserLname() {
        return userLname;
    }

    public void setUserLname(String userLname) {
        this.userLname = userLname;
    }

    public String getUserstatus() {
        return userstatus;
    }

    public void setUserstatus(String userstatus) {
        this.userstatus = userstatus;
    }

    public List<Partners> getPartners() {
        return partners;
    }

    public void setPartners(List<Partners> partners) {
        this.partners = partners;
    }
}
