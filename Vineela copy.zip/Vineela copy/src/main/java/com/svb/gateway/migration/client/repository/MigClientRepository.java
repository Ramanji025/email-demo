package com.svb.gateway.migration.client.repository;

import com.svb.gateway.migration.client.entity.MigClient;
import com.svb.gateway.migration.user.model.CardUserMigrationData;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface MigClientRepository extends JpaRepository<MigClient, String> {

    @Query(value = "select * from mig_client  where ecClientId = ?1 and lower(status)='success' ", nativeQuery = true)
    MigClient findByEcClientId(String ecClintId);

    @Query(value = "select * from mig_client  where ecClientId = ?1 and JOBID=?2 and upper(status)=?3 ", nativeQuery = true)
    MigClient findByEcClientIdandJobIdStatus(String ecClintId, Long jobId, String status);

    @Query(value = "select * from mig_client  where ecClientId = ?1 and JOBID=?2 ", nativeQuery = true)
    MigClient findByEcClientIdAndJobId(String ecClintId, Long jobId);

    List<MigClient> findByJobId(Long jobId);

    @Query(value = "SELECT * FROM mig_client  WHERE JOBID = ?1 and status = ?2 ", nativeQuery = true)
    List<MigClient> findByJobIdAndStatus(Long jobId, String status);

    @Query(value = "SELECT * FROM mig_client  WHERE JOBID = ?1 and status <> ?2 ", nativeQuery = true)
    List<MigClient> findByJobIdAndNotStatus(Long jobId, String status);

    @Query(value = "SELECT * FROM mig_client  WHERE GWCLIENTID = ?1 and lower(status) = lower(?2) ", nativeQuery = true)
    MigClient findByGwClientIdAndStatus(String gwClintId, String status);

    @Query(value = "select mc.ecclientid as ecClientId, mu.gwuuid as gwUid, mu.gwClientId as gwClientId," +
            " mu.ecUserLoginId as ecUserLoginId,  mcp.program_id AS programId, mu.jobid AS jobId from mig_user mu inner join mig_client mc" +
            " on mc.ecclientid = mu.ecclientid inner join mig_card_program   mcp ON mcp.olb_client_id = mc.gwclientid" +
            " where mu.status = 'SUCCESS' and mc.status= 'SUCCESS' AND mu.ecclientid = ?1 and  mu.jobid = ?2 and mu.type_of_user in('COMBO_CARD_USER', 'CARD_HOLDER_ONLY_USER')",nativeQuery = true)
    List<CardUserMigrationData> getClientsByClientIdAndJob(String ecClientId, Long jobId);

    @Query(value = "select mu.ec_client_id as ecClientId, mu.gw_uuid as gwUid, mu.gw_Client_Id as gwClientId," +
    "mu.ec_user_login_id as ecUserLoginId,  mu.program_id AS programId, mu.jobid AS jobId "+
    "from mig_card_user mu where mu.ec_client_id=?1 and mu.status ='SUCCESS' ",nativeQuery = true )
    List<CardUserMigrationData> getCardUsersDataForMigrationRollback(String ecClientId);

    @Query(value = "select * from mig_client  where ecClientId = ?1 and lower(status)<> 'rollback' ", nativeQuery = true)
    List<MigClient> findByEcClientIdStatusNotRollback(String ecClintId);
}
