package com.svb.gateway.migration.client.service;

import com.svb.gateway.migration.client.model.BdcClient;
import com.svb.gateway.migration.client.model.BdcUser;
import com.svb.gateway.migration.client.model.InActiveClientResponse;
import com.svb.gateway.migration.client.repository.MigClientRepository;
import com.svb.gateway.migration.common.constants.MigrationConstants;
import com.svb.gateway.migration.common.exception.ServiceException;
import com.svb.gateway.migration.common.logging.Message;
import com.svb.gateway.migration.common.service.RetryService;
import com.svb.gateway.migration.common.utility.BasicValidation;
import com.svb.gateway.migration.common.utility.CacheManagerUtility;
import com.svb.gateway.migration.user.model.UserAddressRequest;
import lombok.extern.log4j.Log4j2;
import com.svb.gateway.migration.user.repository.MigUserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.util.UriComponentsBuilder;

import static com.svb.gateway.migration.common.constants.ClientConstants.*;

@Service
@Log4j2
public class ClientExtensionService {

    public static final String REGISTER_CLIENT_PARTNER = "registerClientPartner";
    public static final String CLIENT_STATUS_UPDATE = "ClientStatusUpdate";

    @Autowired
    CacheManagerUtility cacheManagerUtility;

    @Value(value = "${mig.enrollclient.url}")
    String migEnrollClientUrl;

    @Value(value = "${mig.user.principal}")
    String migUserUuid;

    @Value(value = "${mig.deleteClient.url}")
    String deleteClientUrl;

    @Value(value = "${mig.validateClientBdc.url}")
    String validateClientBdcUrl;

    @Value(value = "${mig.registerBdc.url}")
    String registerBdcUrl;

    @Autowired
    MigClientRepository migClientRepository;

    @Autowired
    MigUserRepository migUserRepository;

    @Autowired
    private RetryService retryService;

    /**
     * Client InActive Service which updates Client's status from Active to InActive
     */
    public InActiveClientResponse inActiveClient(String gwClientId, String status) throws ServiceException {
        Message messageLog=Message.create().clientId(gwClientId).operation(CLIENT_STATUS_UPDATE).entityName(Message.Entity.client);

        InActiveClientResponse inActiveClientResponse = new InActiveClientResponse();

        String oAuth = cacheManagerUtility.getOauthToken();
        BasicValidation.oAuthNullCheck(oAuth);

        HttpHeaders headers = new HttpHeaders();
        headers.add(MigrationConstants.AUTHORIZATION_HEADER_NAME, oAuth);

        UserAddressRequest userAddressRequest = new UserAddressRequest();
        userAddressRequest.setStatus(status);

        HttpEntity<UserAddressRequest> requestEntity = new HttpEntity<>(userAddressRequest, headers);

        String finalUrl = migEnrollClientUrl + MigrationConstants.SLASH + gwClientId + "/status";

        ResponseEntity<Object> clientResponse = retryService.exchange(finalUrl, HttpMethod.PUT, requestEntity, new ParameterizedTypeReference<Object>() {
        });
        log.info(messageLog.descr("Client InActivation Call Success and the response ::").status(String.valueOf((clientResponse.getStatusCodeValue()))));

        inActiveClientResponse.setStatusCode(clientResponse.getStatusCodeValue());

        return inActiveClientResponse;
    }

    /**
     * Client Delete Service which deletes Client's status from InActive to Deleted
     */
    public void deleteClient(String gwClientId) throws ServiceException {
        Message messageLog=Message.create().clientId(gwClientId).operation("ClientStatusDeletion").entityName(Message.Entity.client);
        String oAuth = cacheManagerUtility.getOauthToken();
        BasicValidation.oAuthNullCheck(oAuth);

        HttpHeaders headers = new HttpHeaders();
        headers.add(MigrationConstants.AUTHORIZATION_HEADER_NAME, oAuth);
        HttpEntity<Object> requestEntity = new HttpEntity<>(headers);

        String finalUrl = deleteClientUrl + gwClientId;

        ResponseEntity<String> clientResponse = retryService.exchange(finalUrl, HttpMethod.DELETE, requestEntity, new ParameterizedTypeReference<String>() {
        });

        if (!clientResponse.getStatusCode().equals(HttpStatus.OK)) {
            log.error(messageLog.descr("Client Deletion call Failed."));
            throw new ServiceException("Admin Api Call Failed for deleteClient");
        }
        log.info(messageLog.descr("Client Deletion Call Success and response :: ").status(String.valueOf(clientResponse.getStatusCodeValue())));
    }

    /**
     * BDC Client Retrieve Client Partner Details by Client ID
     */
    public BdcClient getBdcClient(String gwClientId) throws ServiceException {

        Message bdcLog=Message.create().clientId(gwClientId).operation("ClientBdcDetails").entityName(Message.Entity.client);

        ResponseEntity<BdcClient> bdcClient = null;

        try {
            HttpHeaders headers = new HttpHeaders();
            HttpEntity<Object> requestEntity = new HttpEntity<>(headers);

            String finalUrl = validateClientBdcUrl + gwClientId + MigrationConstants.SLASH + PARTNER;

            bdcClient = retryService.exchange(finalUrl, HttpMethod.GET, requestEntity, new ParameterizedTypeReference<BdcClient>() {
            });
        } catch (Exception exp) {
            log.error(bdcLog.descr(" Error in BDC Validation from AdminExt : "+ exp.getMessage()));
        }

        if (null == bdcClient || !bdcClient.getStatusCode().equals(HttpStatus.OK)) {
            log.error(bdcLog.descr("Client BDC Validation Failed :: ").status(bdcClient!=null&&bdcClient.getStatusCode()!=null?String.valueOf(bdcClient.getStatusCode()):""));
            throw new ServiceException("Admin Api Call Failed");
        }
        log.info(bdcLog.descr("Client BDC Validation success with BDCClient Response: ").status(bdcClient!=null&&bdcClient.getStatusCode()!=null?String.valueOf(bdcClient.getStatusCode()):""));
        return bdcClient.getBody();
    }

    /**
     * BDC User Retrieve Client User Partner details by Client ID
     */
    public BdcUser getBdcUsers(String gwClientId) throws ServiceException {
        Message bdcLog=Message.create().clientId(gwClientId).operation("UserBdcDetails").entityName(Message.Entity.user);

        String oAuth = cacheManagerUtility.getOauthToken();
        BasicValidation.oAuthNullCheck(oAuth);

        ResponseEntity<BdcUser> bdcUser = null;
        try {
            HttpHeaders headers = new HttpHeaders();
            headers.add(MigrationConstants.AUTHORIZATION_HEADER_NAME, oAuth);
            HttpEntity<Object> requestEntity = new HttpEntity<>(headers);

            String finalUrl = registerBdcUrl + migUserUuid + MigrationConstants.SLASH + CLIENT + MigrationConstants.SLASH + gwClientId + MigrationConstants.SLASH + CLIENT_USERS + MigrationConstants.SLASH + PARTNERS;
            bdcUser = retryService.exchange(finalUrl, HttpMethod.GET, requestEntity, new ParameterizedTypeReference<BdcUser>() {
            });

        } catch (Exception exp) {
            log.error(bdcLog.descr(" Error in BDC Validation from AdminExt "+ exp.getMessage()));
        }

        if (null == bdcUser || !bdcUser.getStatusCode().equals(HttpStatus.OK)) {
            log.error(bdcLog.descr("Users BDC Validation Failed :: " ).status(bdcUser!=null&&bdcUser.getStatusCode()!=null?String.valueOf(bdcUser.getStatusCode()):""));
            throw new ServiceException("Admin Api Call Failed for BDC User validation");
        }

        log.info(bdcLog.descr("BDC User Validation success with BDCUser Response: ").status(bdcUser!=null&&bdcUser.getStatusCode()!=null?String.valueOf(bdcUser.getStatusCode()):""));

        return bdcUser.getBody();
    }

    public boolean registerClientPartner(String gwClientId) throws ServiceException {
        Message messageLog=Message.create().clientId(gwClientId).entityName(Message.Entity.client).operation(REGISTER_CLIENT_PARTNER);

        HttpStatus httpStatus = null;
        String oAuth = cacheManagerUtility.getOauthToken();
        BasicValidation.oAuthNullCheck(oAuth);

        try {
            HttpHeaders headers = new HttpHeaders();
            headers.add(MigrationConstants.AUTHORIZATION_HEADER_NAME, oAuth);
            HttpEntity<Object> requestEntity = new HttpEntity<>(headers);

            String finalUrl = registerBdcUrl + migUserUuid + MigrationConstants.SLASH +
                    CLIENTS + MigrationConstants.SLASH + gwClientId + MigrationConstants.SLASH + PARTNERS;

            httpStatus = retryService.exchange(finalUrl, HttpMethod.PUT, requestEntity, new ParameterizedTypeReference<String>() {
            }).getStatusCode();
        } catch (Exception exp) {
            log.error(messageLog.descr("Error in BDC Registration for Client via AdminExt" + exp.getMessage()));
            return false;
        }
        log.info(messageLog.descr("Client BDC Registration Submitted Successfully with response :: ").status(String.valueOf(httpStatus)));

        return httpStatus.is2xxSuccessful();
    }

    public boolean registerPrimaryUserPartner(String gwClientId, String primaryUserId) throws ServiceException {
       Message messageLog=Message.create().clientId(gwClientId).operation("RegisterPrimaryUserPartner").entityName(Message.Entity.client);

        String oAuth = cacheManagerUtility.getOauthToken();
        BasicValidation.oAuthNullCheck(oAuth);
        HttpStatus httpStatus = null;
        try {
            HttpHeaders headers = new HttpHeaders();
            headers.add(MigrationConstants.AUTHORIZATION_HEADER_NAME, oAuth);
            HttpEntity<Object> requestEntity = new HttpEntity<>(new String[]{primaryUserId}, headers);

            String requestUrl = registerBdcUrl + migUserUuid + MigrationConstants.SLASH + CLIENTS + MigrationConstants.SLASH +
                    gwClientId + MigrationConstants.SLASH + CLIENT_USERS + MigrationConstants.SLASH + PARTNERS;

            UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(requestUrl)
                    .queryParam(MigrationConstants.OPERATION, MigrationConstants.PARTNER_RETRIGGER_ENROLLMENT);
            httpStatus = retryService.exchange(builder.toUriString(), HttpMethod.PUT, requestEntity, new ParameterizedTypeReference<Object>() {
            }).getStatusCode();
        } catch (Exception exp) {
            log.error(messageLog.descr("Error in Primary User Registration for Client Via AdminExt " + exp.getMessage()));
            return false;
        }
        log.info(messageLog.descr("Primary User BDC Registration Submitted Successfully with response ::.").status(String.valueOf(httpStatus)));
        return httpStatus.is2xxSuccessful();
    }
}
