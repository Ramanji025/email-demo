package com.svb.gateway.migration.client.service;

import com.svb.gateway.migration.client.entity.MigClient;
import com.svb.gateway.migration.client.entity.StgClient;
import com.svb.gateway.migration.client.mapper.AccountDetailsMapper;
import com.svb.gateway.migration.client.model.*;
import com.svb.gateway.migration.client.repository.ClientRepository;
import com.svb.gateway.migration.client.repository.MigClientRepository;
import com.svb.gateway.migration.common.constants.ClientConstants;
import com.svb.gateway.migration.common.constants.MigrationConstants;
import com.svb.gateway.migration.common.constants.UserConstants;
import com.svb.gateway.migration.common.exception.ServiceException;
import com.svb.gateway.migration.common.logging.Message;
import com.svb.gateway.migration.common.model.EntityRecordCount;
import com.svb.gateway.migration.common.model.Error;
import com.svb.gateway.migration.common.repository.GatewayOAuthRepository;
import com.svb.gateway.migration.common.utility.*;
import com.svb.gateway.migration.job.mapper.ClientMapper;
import com.svb.gateway.migration.user.entity.MigUser;
import com.svb.gateway.migration.user.entity.StgUser;
import com.svb.gateway.migration.user.mapper.UserAccountServicesMapper;
import com.svb.gateway.migration.user.mapper.UserMapper;
import com.svb.gateway.migration.user.model.User;
import com.svb.gateway.migration.user.model.UserAccountService;
import com.svb.gateway.migration.user.repository.MigUserRepository;
import com.svb.gateway.migration.user.repository.UserRepository;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.web.client.RestTemplate;

import java.sql.Timestamp;
import java.util.*;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.stream.Collectors;

import static com.svb.gateway.migration.common.constants.MigrationConstants.*;
import static com.svb.gateway.migration.common.constants.UserConstants.*;

@Log4j2
@Service
public class ClientService {

    @Value(value = "${mig.fetchBundles.url}")
    String migrationFetchBundlesUrl;

    @Value(value = "${mig.fetchCifAccounts.url}")
    String migrationFetchCifAccountUrl;

    @Value(value = "${mig.enrollclient.url}")
    String migEnrollClientUrl;

    @Value(value = "${mig.deleteClient.url}")
    String deleteClientUrl;

    @Value(value = "${mig.corelation.id}")
    String migCorelationId;

    @Value(value = "${mig.user.principal}")
    String miguserUuid;
    @Value(value = "${mig.startup-banking.bundle}")
    Integer migStartupBankingBundle;
    @Value("${mig.bankid}")
    String clientLoginId;
    @Value(value = "${last.login.date.threshold.in.months}")
    Integer lastLoginMonthThreshold;
    @Autowired
    GatewayOAuthRepository gatewayOAuthRepository;
    @Autowired
    ClientExtensionService clientExtensionService;
    @Autowired
    ClientRepository clientRepository;
    @Autowired
    UserRepository userRepository;
    @Autowired
    MigUserRepository migUserRepository;
    @Autowired
    MigClientRepository migClientRepository;
    @Autowired
    CacheManagerUtility cacheManagerUtility;
    @Value("${sleepInterval}")
    private int sleepInterval;
    @Autowired
    private RestTemplate restTemplate;

    @Autowired
    private ClientMapper clientMapper;

    @Autowired
    private EntityLogUtility entityLogUtility;

    @Autowired
    private UserMapper userMapper;

    public  MigClient getMigClient(String ecClientId, Long jobId) {
        return  migClientRepository.findByEcClientIdAndJobId(ecClientId, jobId);
    }

    public EnrollClientResponse enrollClient(String newCompanyLoginId, String migratingClientId, Long jobId) throws ServiceException{
        MigClient client = migClientRepository.findByEcClientIdAndJobId(migratingClientId, jobId);
        if(client==null){
            client=new MigClient();
            client.setCompanyId(newCompanyLoginId);
            client.setEcClientId(migratingClientId);
        }
        return enrollClient(client, jobId);
    }

    public EnrollClientResponse enrollClient(MigClient migClient, Long jobId) throws ServiceException {
        String migratingClientId=migClient.getEcClientId();
        String newCompanyLoginId=migClient.getCompanyId();
        Message logMessage=Message.create().clientId(migratingClientId).jobId(jobId);

        if (!migClient.canRunAgain()) {
            // do not re-run this client
            updateClientStatus(migratingClientId, migClient.getStatus(), ClientConstants.ALREADY_PROCESSED, jobId, migClient);
            return cannotRunAgainResponse(migClient, jobId, migratingClientId);
        }else{
            log.info(logMessage.descr("Enroll Client started for clientId:"));
            updateClientStatus(migratingClientId, MigrationConstants.STATUS_IN_PROGRESS, MigrationConstants.ENROLLING_CLIENT, jobId, migClient);
        }

        Date startTime = Calendar.getInstance().getTime();
        EnrollClientRequest enrollClientRequest = new EnrollClientRequest();

//        Step1: Load Client details from the Staging Database
        StgClient stagingClient = clientRepository.findByOlbClinetId(migratingClientId);

//        Step2: Load Primary User Details from the Staging Database
        List<com.svb.gateway.migration.user.entity.StgUser> users = userRepository.findByOlbClientId(migratingClientId);

//      Basic validation
        validate(newCompanyLoginId,migratingClientId, stagingClient,  users);

//        Step3: Get OCH oAuth Token for Authorization
        String oAuth = getOauthToken(migClient, jobId, migratingClientId, logMessage, stagingClient);

//        Step4: Prepare Request to retrieve CIF Account Details from AdminExt
        Cifs cifListRequest = createCifsRequest(stagingClient);

//        Step5: Retrieve CIF Account Info from AdminExt
        Cifs cifsInfo = getCifAccountInfo(cifListRequest, oAuth, clientLoginId, jobId);
        accountStatusCheck(cifsInfo, stagingClient, startTime, migClient);

//        Step6: Filter Out Primary CIF Details
        Cif primaryCifDetails = getPrimaryCifDetails(stagingClient, cifsInfo);

//        Step7: Prepare and populate "ClientData" element of EnrollClient payload
        Client clientData=createClientData(migratingClientId, newCompanyLoginId, primaryCifDetails);
        enrollClientRequest.setClientData(clientData);

//        Step8: Populate "ClientCifs" element of EnrollClient payload
        enrollClientRequest.setClientCifs(cifsInfo.getCifData());

//        Step9: Retrieve Bundled Services and filter for for Startup Banking Bundle from Admin Ext
        Bundle startupBankingBundle = getStartupBankingBundle(jobId, oAuth);

//        Step10: Prepare Account Services element for all account across CIFs
        List<AccountServices> accountServicesList = createAccountServicesList(cifsInfo);

//        Step11: Prepare a List of Accounts as List of Strings to be made part of "ClientServices" element
        //SKIPPED

//        Step12: Enrich "ClientServices" element with associating list of accounts to Product service
//        grouping and it is referenced to ensure if the account is associated to a product that is eligible for certain service
        List<com.svb.gateway.migration.client.model.ClientService> clientServices=filterBankingBundle(startupBankingBundle, accountServicesList);

//        Step13: Populate "ClientService" element of EnrollClient payload
        enrollClientRequest.setClientService(clientServices);

//        Step14: Filter out Primary User retrieved from Staging database
        StgUser primaryUserDetails = getPrimaryUserDetails(migratingClientId, users);

//        Step15: Populate User Account Services element with details fetched out of AdminExt
        List<UserAccountService> userAccountServices = UserAccountServicesMapper.INSTANCE.mapUserAccountServices(accountServicesList);

//        Step16: Collate SVBServices out of the Startup Banking Bundle
        List<SvbService> svbServices = startupBankingBundle.getServices().stream()
                .map(BundleServices::getService)
                .collect(Collectors.toList());

//        Step17: Create ServiceTransactions element based on SVBServices available for the Startup Bundle
        List<ServiceTransaction> serviceTransactions = new ArrayList<>();
        svbServices.forEach(item -> {
            serviceTransactions.addAll(item.getServiceTxn());
        });

//        Step18: Create a key value pair with Service Transaction Id and Service Transaction Operation
//        This is needed as Transaction description is mandatory although Transaction Id is present but not provided by Get CIF Account API
        Map<String, String> serviceTransactionMap = serviceTransactions.stream()
                .collect(Collectors.toMap(ServiceTransaction::getSvcTxnId, ServiceTransaction::getOperation));

//        Step19: Populate Service Transaction Description or Action Name
        setServiceTransactionDescription(userAccountServices, serviceTransactionMap);

//        Step20: Populate UserDetails element to create the first user or Primary User
        List<User> userDetails = new ArrayList<>();
        User primaryUser = createPrimaryUser(primaryUserDetails, userAccountServices);
        userDetails.add(primaryUser);

//        Step21: Populate "UserDetails" element of EnrollClient payload
        enrollClientRequest.setUserDetails(userDetails);
        log.info(Message.create().descr("Request Payload for Enroll Client: " + enrollClientRequest));
        log.info(Message.create().clientId(migratingClientId).jobId(jobId).descr("Request Payload for Enroll Client : " + enrollClientRequest));

//        Step22: Invoke EnrollClient API to create Client and Primary User
        boolean isInvalidLastLoginDate = LastLoginDateCheck.isInvalidLastLoginDate(primaryUserDetails.getLastLoginDate(), primaryUserDetails.getPrimaryUser(), lastLoginMonthThreshold);

        if (isInvalidPrimaryUser(primaryUserDetails, isInvalidLastLoginDate)) {
            ClientDTO clientDTO = createClientDto(migratingClientId, newCompanyLoginId, stagingClient, primaryCifDetails, clientData, primaryUserDetails, primaryUser);
            migClientUpdate(clientDTO, migClient);
            entityLogging(migratingClientId, MigrationConstants.CLIENT_CREATION, startTime, stagingClient, Calendar.getInstance().getTime(), 1, 0);
            updateMigUser(clientDTO);
            entityLogging(migratingClientId, MigrationConstants.PRIMARY_USER_CREATION, startTime, stagingClient, Calendar.getInstance().getTime(), 1, 0);
            return null;
        }

        if ((migClient != null && migClient.getGwClientId() != null)) {
            // Don't enroll client if it already is in progress since it already was enrolled in that case, or if the mig client already exists
            updateClientStatus(migratingClientId, STATUS_SUCCESS, MigrationConstants.MIGRATED_SUCCESS, jobId, migClient);
            EnrollClientResponse clientResponse = new EnrollClientResponse();
            EnrollClientResponseData clientResponseData = new EnrollClientResponseData();
            clientResponseData.setStatus(STATUS_SUCCESS);
            clientResponse.setData(clientResponseData);
            return clientResponse;
        }

        // proceed below with enrolling the client
        EnrollClientResponse clientEnrolled = createClient(enrollClientRequest, oAuth, migratingClientId, jobId);

        Date endTime = Calendar.getInstance().getTime();
        long duration = (endTime.getTime() - startTime.getTime()) / 1000;

        ClientDTO clientDTO = createClientDTO(migratingClientId, newCompanyLoginId, stagingClient, primaryCifDetails, clientData, primaryUserDetails, primaryUser);
        clientDTO.setStatus(clientEnrolled.getData().getStatus());
        clientDTO.setGwClientId(clientEnrolled.getData().getGwClientId());
        updateMigClient(migClient, migratingClientId, startTime, clientEnrolled, clientDTO);

        //Update mig_user table
        updateMigrationUserEntity(migratingClientId, startTime, primaryUserDetails, primaryUser, clientEnrolled, clientDTO);
        log.info(Message.create().clientId(migratingClientId).jobId(jobId).descr("Enroll Client response payload : " + clientEnrolled));
        log.info(Message.create().clientId(migratingClientId).jobId(jobId).descr("ClientService.enrollClient is finished. Elapsed time is ").timeTaken(duration));

        return clientEnrolled;
    }

    private void updateMigClient(MigClient migClient, String migratingClientId, Date startTime, EnrollClientResponse clientEnrolled, ClientDTO clientDTO) throws ServiceException {
        if (STATUS_FAILURE.equals(clientEnrolled.getData().getStatus())) {
            clientDTO.setComments(clientEnrolled.getErrors().get(0).getDescription());
            entityLogging(migratingClientId, MigrationConstants.CLIENT_CREATION, startTime, clientDTO, Calendar.getInstance().getTime(), 1, 0);
        } else {
            clientDTO.setComments(ClientConstants.CLIENT_ADDED);
            entityLogging(migratingClientId, MigrationConstants.CLIENT_CREATION, startTime, clientDTO, Calendar.getInstance().getTime(), 1, 1);
        }
        migClientUpdate(clientDTO, migClient);
    }

    private void updateMigrationUserEntity(String migratingClientId, Date startTime, StgUser primaryUserDetails, User primaryUser, EnrollClientResponse clientEnrolled, ClientDTO clientDTO) throws ServiceException {
        if (STATUS_FAILURE.equals(clientEnrolled.getData().getStatus()) && !clientEnrolled.getErrors().isEmpty()) {
            clientDTO.setPrimaryUserDetails(primaryUserDetails);
            clientDTO.setPrimaryUser(primaryUser);
            clientDTO.setGwPrimaryUserId(clientEnrolled.getData().getGwPrimaryUserId());
            clientDTO.setComments(clientEnrolled.getErrors().get(0).getDescription());

            updateMigUser(clientDTO);
            entityLogging(migratingClientId, MigrationConstants.PRIMARY_USER_CREATION, startTime, clientDTO, Calendar.getInstance().getTime(), 1, 0);

        } else {
            clientDTO.setPrimaryUserDetails(primaryUserDetails);
            clientDTO.setPrimaryUser(primaryUser);
            clientDTO.setGwPrimaryUserId(clientEnrolled.getData().getGwPrimaryUserId());
            clientDTO.setComments(ClientConstants.PRIMARY_USER_ADDED);
            updateMigUser(clientDTO);
            entityLogging(migratingClientId, MigrationConstants.PRIMARY_USER_CREATION, startTime, clientDTO, Calendar.getInstance().getTime(), 1, 1);

        }
    }

    private boolean isInvalidPrimaryUser(StgUser primaryUserDetails, boolean isInvalidLastLoginDate) {
        return ClientConstants.DISABLED_USER.equals(primaryUserDetails.getStatus()) || ClientConstants.DELETED_USER.equals(primaryUserDetails.getStatus())
                || ClientConstants.FROZEN_USER.equals(primaryUserDetails.getStatus()) || isInvalidLastLoginDate;
    }

    private ClientDTO createClientDto(String migratingClientId, String newCompanyLoginId, StgClient stagingClient, Cif primaryCifDetails, Client clientData, StgUser primaryUserDetails, User primaryUser) {
        ClientDTO clientDTO = new ClientDTO();
        clientDTO.setCompanyLoginId(newCompanyLoginId);
        clientDTO.setMigratingClientId(migratingClientId);
        clientDTO.setClient(clientData);
        clientDTO.setStgClient(stagingClient);
        clientDTO.setStatus(MigrationConstants.STATUS_IGNORE);
        if (ClientConstants.PRIMARY_USER_DISABLED.equals(primaryUserDetails.getStatus())) {
            clientDTO.setComments(ClientConstants.PRIMARY_USER_DISABLED);
        } else if (ClientConstants.DELETED_USER.equals(primaryUserDetails.getStatus())) {
            clientDTO.setComments(ClientConstants.PRIMARY_USER_DELETED);
        } else if (ClientConstants.FROZEN_USER.equals(primaryUserDetails.getStatus())) {
            clientDTO.setComments(ClientConstants.PRIMARY_USER_FROZEN);
        } else {
            clientDTO.setComments(ClientConstants.PRIMARY_USER_LAST_LOGIN_DATE_BEYOND_THRESHOLD);
        }
        clientDTO.setPrimaryCifDetails(primaryCifDetails);
        clientDTO.setPrimaryUser(primaryUser);
        clientDTO.setPrimaryUserDetails(primaryUserDetails);
        return clientDTO;
    }

    private void setServiceTransactionDescription(List<UserAccountService> userAccountServices, Map<String, String> map) {
        userAccountServices.forEach(svc -> {
            svc.getSvcDetails().forEach(svcDetails -> {
                svcDetails.getServiceTxn().forEach(txn -> {
                    txn.setSvcAction(map.get(txn.getSvcTxnId()));
                });
            });
        });
    }

    private StgUser getPrimaryUserDetails(String migratingClientId, List<StgUser> users) throws ServiceException {
        StgUser primaryUserDetails = users.stream()
                .filter(StgUser::getPrimaryUser)
                .findAny()
                .orElse(null);

        if (null == primaryUserDetails)
            throw new ServiceException("Primary User not available for ClientId: " + migratingClientId, "Primary User not available");
        return primaryUserDetails;
    }

    private List<AccountServices> createAccountServicesList(Cifs cifsInfo) {
        List<AccountServices> accountServicesList = new ArrayList<>();
        cifsInfo.getCifData().forEach(item -> {
            accountServicesList.addAll(item.getCifAccounts());
            item.setCifNumber(item.getUbsCifNum());
            item.setAccountDetails(AccountDetailsMapper.INSTANCE.mapAccountDetails(item.getCifAccounts()));
        });
        return accountServicesList;
    }

    private Bundle getStartupBankingBundle(Long jobId, String oAuth) throws ServiceException {
        Bundles bundles = getBundles(oAuth, clientLoginId, jobId);
        Bundle startupBankingBundle = bundles.getDigitalBundles()
                .stream()
                .filter(b -> b.getDigitalBundleId().equals(migStartupBankingBundle))
                .findAny()
                .orElse(null);
        if (null == startupBankingBundle)
            throw new ServiceException("Bundle not available", "Startup Banking Bundle - " + migStartupBankingBundle.toString() + " does not exist!");
        return startupBankingBundle;
    }

    private Cif getPrimaryCifDetails(StgClient client, Cifs cifsInfo) throws ServiceException {
        Cif primaryCifDetails = cifsInfo.getCifData()
                .stream()
                .filter(c -> c.getUbsCifNum().equals(client.getPrimaryCifUbs()))
                .findAny()
                .orElse(null);
        if (null == primaryCifDetails)
            throw new ServiceException("Cif details not available in Gateway for UBSCifNumber: " + client.getPrimaryCifUbs(), "Cif not available");
        return primaryCifDetails;
    }

    private String getOauthToken(MigClient migClient, Long jobId, String migratingClientId, Message logMessage, StgClient client) throws ServiceException {
        String oAuth = null;
        try {
            oAuth = cacheManagerUtility.getOauthToken();
            BasicValidation.oAuthNullCheck(oAuth);
        } catch (Exception e) {
            log.info(logMessage.descr("ClientService.client, client : ") + client.toString());
            updateClientStatus(migratingClientId, ClientConstants.FAILED, e.getMessage(), jobId, migClient);
            throw e;
        }
        return oAuth;
    }

    private void validate(String newCompanyLoginId, String migratingClientId, StgClient stagingClient, List<StgUser> users) throws ServiceException{
        BasicValidation.companyIdNullCheck(newCompanyLoginId);
        EcClientIdCheck.ecClientIdFormatCheck(migratingClientId);
        BasicValidation.clientNullCheck(stagingClient);
        BasicValidation.usersNullCheck(users);
    }

    private ClientDTO createClientDTO(String migratingClientId, String newCompanyLoginId, StgClient stagingClient, Cif primaryCifDetails, Client clientData, StgUser primaryUserDetails, User primaryUser) {
        ClientDTO clientDTO = new ClientDTO();
        clientDTO.setCompanyLoginId(newCompanyLoginId);
        clientDTO.setMigratingClientId(migratingClientId);
        clientDTO.setClient(clientData);
        clientDTO.setStgClient(stagingClient);
        clientDTO.setStatus(MigrationConstants.STATUS_IGNORE);
        if (ClientConstants.PRIMARY_USER_DISABLED.equals(primaryUserDetails.getStatus())) {
            clientDTO.setComments(ClientConstants.PRIMARY_USER_DISABLED);
        } else if (ClientConstants.DELETED_USER.equals(primaryUserDetails.getStatus())) {
            clientDTO.setComments(ClientConstants.PRIMARY_USER_DELETED);
        } else if (ClientConstants.FROZEN_USER.equals(primaryUserDetails.getStatus())) {
            clientDTO.setComments(ClientConstants.PRIMARY_USER_FROZEN);
        } else {
            clientDTO.setComments(ClientConstants.PRIMARY_USER_LAST_LOGIN_DATE_BEYOND_THRESHOLD);
        }
        clientDTO.setPrimaryCifDetails(primaryCifDetails);
        clientDTO.setPrimaryUser(primaryUser);
        clientDTO.setPrimaryUserDetails(primaryUserDetails);
        return clientDTO;
    }

    private User createPrimaryUser(StgUser primaryUserDetails, List<UserAccountService> userAccountServices) {
        User primaryUser = new User();
        primaryUser.setUserFname(primaryUserDetails.getFirstNm());
        primaryUser.setUserLname(primaryUserDetails.getLastNm());
        primaryUser.setUserEmail(primaryUserDetails.getEmail());
        primaryUser.setPrimaryPhNumber(primaryUserDetails.getCntPh());
        primaryUser.setUserAccess(primaryUserDetails.getUserAccess());
        primaryUser.setUserRole(primaryUserDetails.getUserRole());
        primaryUser.setUserAccountService(userAccountServices);
        primaryUser.setContactCountryCode(ClientConstants.COUNTRY_CODE);
        primaryUser.setContactLabel(ClientConstants.CONTACT_LABEL);
        primaryUser.setIsPrimaryContact(primaryUserDetails.getIsPrimaryContact());
        primaryUser.setSigner(ClientConstants.SIGNER);
        primaryUser.setEcUserId(primaryUserDetails.getUserLoginId());
        return primaryUser;
    }

    private Client createClientData(String migratingClientId, String newCompanyLoginId, Cif primaryCifDetails) {
        Client clientData = new Client();
        primaryCifDetails.setPrimary(ClientConstants.PRIMARY);
        clientData.setProfileName(primaryCifDetails.getName());
        clientData.setEcClientId(migratingClientId);
        clientData.setOlbId(primaryCifDetails.getClientId());
        clientData.setDigitalBundle(migStartupBankingBundle.toString());
        clientData.setClientLoginId(newCompanyLoginId);
        clientData.setMigrationFlag(ClientConstants.MIGRATION_FLAG);
        return clientData;
    }

    private Cifs createCifsRequest(StgClient client) {
        Cifs cifListRequest = new Cifs();
        Cif cif = new Cif();
        cif.setCifNumber(client.getPrimaryCifUbs());
        List<Cif> cifs = new ArrayList<>();
        cifs.add(cif);
        cifListRequest.setCifData(cifs);
        return cifListRequest;
    }

    private EnrollClientResponse cannotRunAgainResponse(MigClient migClient, Long jobId, String migratingClientId) {
        EnrollClientResponse clientResponse = new EnrollClientResponse();
        EnrollClientResponseData clientResponseData = new EnrollClientResponseData();
        clientResponseData.setStatus(migClient.getStatus());
        clientResponse.setData(clientResponseData);
        List<Error> errors = new ArrayList<Error>();
        Error error = new Error(ERROR_ALREADY_PROCESSED, "Already processed this clientId=" + migratingClientId + " for jobId=" + jobId + " status=" + migClient.getStatus());
        errors.add(error);
        clientResponse.setErrors(errors);
        return clientResponse;
    }

    public void updateClientStatus(String migratingClientId, String status, String comment, Long jobId, MigClient migClient) {
        migClient.setEcClientId(migratingClientId);
        migClient.setStatus(status);
        migClient.setComments(comment);
        migClient.setJobId(jobId);
        migClientRepository.save(migClient);
    }

    private void entityLogging(String migratingClientId, String entityName, Date startTime, StgClient client, Date end, int readCount, int writeCount) {

        EntityRecordCount entityRecordCount = new EntityRecordCount();
        entityRecordCount.setCIF_NUMBER("");
        entityRecordCount.setGWCLIENT_ID("");
        entityRecordCount.setJOB_ID(client.getJobId());
        entityLoggingCommonCode(migratingClientId, entityName, startTime, end, readCount, writeCount, entityRecordCount);
    }

    private void entityLogging(String migratingClientId, String entityName, Date startTime, ClientDTO client, Date end, int readCount, int writeCount) {

        EntityRecordCount entityRecordCount = new EntityRecordCount();
        entityRecordCount.setCIF_NUMBER(client.getPrimaryCifDetails().getUbsCifNum());
        if (null == client.getGwClientId()) {
            entityRecordCount.setGWCLIENT_ID("");
        } else {
            entityRecordCount.setGWCLIENT_ID(client.getGwClientId());
        }
        entityRecordCount.setJOB_ID(client.getStgClient().getJobId());
        entityLoggingCommonCode(migratingClientId, entityName, startTime, end, readCount, writeCount, entityRecordCount);
    }

    private void entityLoggingCommonCode(String migratingClientId, String entityName, Date startTime, Date end, int readCount, int writeCount, EntityRecordCount entityRecordCount) {
        long duration = (end.getTime() - startTime.getTime()) / 1000;

        entityRecordCount.setENTITY_NAME(entityName);
        entityRecordCount.setECCLIENT_ID(migratingClientId);
        entityRecordCount.setMIG_ENTITY_ID("");
        entityRecordCount.setREADCOUNT(readCount);
        entityRecordCount.setWRITECOUNT(writeCount);
        entityRecordCount.setSKIPCOUNT(readCount - writeCount);
        entityRecordCount.setSTART_TIME(new Timestamp(startTime.getTime()));
        entityRecordCount.setEND_TIME(new Timestamp(end.getTime()));
        entityRecordCount.setTOTAL_STEP_TIME(duration);
        entityLogUtility.saveEntityCountAndTimeLog(entityRecordCount);
    }

    private void updateMigUser(ClientDTO clientDTO) throws ServiceException {

        try {
            MigUser migUser = new MigUser();
            migUser.setUpdateBy(ClientConstants.ADDED);
            migUser.setStatus(clientDTO.getStatus());
            if(clientDTO.getPrimaryUserDetails() != null) {
                migUser.setTypeOfUser(clientDTO.getPrimaryUserDetails().getTypeOfUser());
                migUser.setEcUserLoginId(clientDTO.getPrimaryUserDetails().getUserLoginId());
            }
            migUser.setMobileNumber(clientDTO.getPrimaryUser().getPrimaryPhNumber());
            migUser.setGwUuid(clientDTO.getGwPrimaryUserId());
            migUser.setLastName(clientDTO.getPrimaryUser().getUserLname());
            migUser.setFirstName(clientDTO.getPrimaryUser().getUserFname());
            migUser.setGwClientId(clientDTO.getGwClientId());
            migUser.setEcClientId(clientDTO.getMigratingClientId());
            migUser.setComments(clientDTO.getComments());
            migUser.setJobId(Long.parseLong(clientDTO.getStgClient().getJobId()));
            migUser.setEmailId(clientDTO.getPrimaryUser().getUserEmail());
            migUser.setEmailFlag(N_FLAG);
            migUser.setCardHolderType(N_FLAG);
            migUser.setIsPrimaryUser(PRIMARY_USER_FLAG_TRUE);

            migUser.setBdcStatus(BDC_DISABLED);
            Date date = new Date();
            date.getTime();
            migUser.setUpdateDate(date);

            migUserRepository.save(migUser);
            log.info(Message.create().clientId(clientDTO.getMigratingClientId()).jobId(migUser.getJobId()).descr("Primary User updated successfully")
                    .userId(clientDTO.getGwPrimaryUserId()));

        } catch (Exception e){
                throw new ServiceException("User Creation Errored: ", "User Creation Errored. Not added Mig user");

        }
    }

    private void migClientUpdate
            (ClientDTO clientDTO, MigClient migClient) throws ServiceException {
        try {
            migClient.setPrimaryCifCbs(Long.parseLong(clientDTO.getPrimaryCifDetails().getCbsCifNum()));
            migClient.setPrimaryCifUbs(Integer.parseInt(clientDTO.getPrimaryCifDetails().getUbsCifNum()));
            migClient.setClientName(clientDTO.getClient().getProfileName());
            migClient.setEcClientId(clientDTO.getMigratingClientId());
            migClient.setGwClientId(clientDTO.getGwClientId());
            migClient.setStatus(clientDTO.getStatus());
            migClient.setCompanyId(clientDTO.getCompanyLoginId());
            migClient.setJobId(Long.parseLong(clientDTO.getStgClient().getJobId()));
            migClient.setComments(clientDTO.getComments());

            Date date = new Date();
            date.getTime();
            migClient.setUpdateDate(date);
            migClientRepository.save(migClient);
        } catch (Exception e) {
            throw new ServiceException("Client updating Errored: ", "Client updating Errored. Not added in Mig Client");

        }
    }

    private List<com.svb.gateway.migration.client.model.ClientService> filterBankingBundle( Bundle startupBankingBundle, List<AccountServices> accountServicesList) {
        List<com.svb.gateway.migration.client.model.ClientService> clientServices=new ArrayList<>();
        startupBankingBundle.getServices().forEach(item -> {
                    com.svb.gateway.migration.client.model.ClientService clientService = new com.svb.gateway.migration.client.model.ClientService();
                    clientService.setServiceName(item.getService().getServiceName());
                    clientService.setServiceId(item.getService().getServiceId());
                    if (Objects.equals(item.getService().getServiceTxn().stream()
                            .map(ServiceTransaction::getAcctSpecificTxn)
                            .findAny().orElse(null), ClientConstants.ACCOUNT_SPECIFIC_TRANSACTION)) {

                        List<String> accounts = new ArrayList<>();
                        accountServicesList.forEach(svc -> {
                            if (svc.getAccServ().stream().map(SvbService::getServiceName).anyMatch(str -> (Objects.equals(str, clientService.getServiceName()))))
                                accounts.add(svc.getAccountNum());
                        });

                        clientService.setAccounts(accounts);
                    } else
                        clientService.setAccounts(new ArrayList<String>());
                    clientServices.add(clientService);
                }
        );
        return clientServices;
    }

    private void accountStatusCheck(Cifs cifsInfo,StgClient stagingClient, Date startTime, MigClient migClient) throws ServiceException {
        if (cifsInfo == null) {
            throw new ServiceException("CIF account info is not present", "cifsInfo is null");
        }

        try{
            if (cifsInfo.getCifData() != null && !cifsInfo.getCifData().isEmpty()) {
                for (Cif cifObj : cifsInfo.getCifData()) {
                    if (cifObj.getCifAccounts() != null && !cifObj.getCifAccounts().isEmpty()) {
                        accountStatCheckByCif(cifObj);
                    }
                }
            }
        } catch (Exception e) {
            updateClientStatus(migClient.getEcClientId(), MigrationConstants.STATUS_FAILURE, e.getMessage(), migClient.getJobId(), migClient);
            Date end = Calendar.getInstance().getTime();
            entityLogging(migClient.getEcClientId(), MigrationConstants.CLIENT_CREATION,  startTime, stagingClient, end, 1, 0);
            throw new ServiceException(e.getMessage());
        }
    }

    private void accountStatCheckByCif(Cif cifObj) throws ServiceException {
        for (AccountServices ac : cifObj.getCifAccounts()) {
            if (ac.getAccStat() == null) {
                log.info(Message.create().descr("One of the accounts to this cifNumber's Account status is null" + cifObj.getCifNumber())
                        .accountNumber(ac.getAccountNum()));
                throw new ServiceException("Account status is null", "cifData.getAccStat is null");
            }
        }
    }

    public EnrollClientResponse createClient(EnrollClientRequest request, String oAuth, String ecClientId, Long jobId) throws ServiceException {
        log.info(Message.create().descr("ClientService.createClient is started: ").clientId(ecClientId).jobId(jobId));
        EnrollClientResponse enrollClientResponse = new EnrollClientResponse();
        EnrollClientResponseData enrollClientResponseData = new EnrollClientResponseData();
        ResponseEntity<ClientInfo> clientInfo = null;
        String error = null;

        try {
            HttpHeaders headers = new HttpHeaders();
            headers.add(MigrationConstants.AUTHORIZATION_HEADER_NAME, oAuth);
            headers.add(MigrationConstants.CONTENT_TYPE, MigrationConstants.APPLICATION_HEADER_JSON);

            HttpEntity<EnrollClientRequest> requestEntity = new HttpEntity<>(request, headers);

            clientInfo = restTemplate.exchange(migEnrollClientUrl, HttpMethod.POST, requestEntity, ClientInfo.class);

        } catch (Exception exception) {
            log.error(Message.create().descr("Exception occurred while creation client "+exception).clientId(ecClientId).jobId(jobId));
            error = exception.getMessage();
        }

        if (null != clientInfo && null != clientInfo.getBody() &&
                null != clientInfo.getBody().getClientData() && null != clientInfo.getBody().getUserDetails()) {
            enrollClientResponseData.setGwClientId(clientInfo.getBody().getClientData().getOlbId());
            enrollClientResponseData.setGwPrimaryUserId(clientInfo.getBody().getUserDetails().get(0).getIdStoreuserkey());
            enrollClientResponseData.setStatus(STATUS_SUCCESS);
        } else {
            enrollClientResponseData.setStatus(MigrationConstants.STATUS_FAILURE);
            Error e;
            if (error != null) {
                e = new Error("0000", error);
            } else {
                e = new Error("0000", UserConstants.ADD_USER_FAILED);
            }
            enrollClientResponse.setErrors(List.of(e));
            enrollClientResponse.setData(enrollClientResponseData);
        }

        enrollClientResponse.setData(enrollClientResponseData);
        log.info(Message.create().descr("ClientService.createClient is ended" + enrollClientResponse).clientId(ecClientId).jobId(jobId).entityName(Message.Entity.client).operation("CreatClient"));

        return enrollClientResponse;
    }

    public Cifs getCifAccountInfo(Cifs cifListRequest, String oAuth, String ecClientId, Long jobId) {
        Message message = Message.create().clientId(ecClientId).jobId(jobId);
        log.info(message.descr("ClientService.getCifAccountInfo is started"));

        ResponseEntity<Cifs> response = null;
        try {

            HttpHeaders headers = new HttpHeaders();
            headers.add(MigrationConstants.AUTHORIZATION_HEADER_NAME, oAuth);
            headers.add(MigrationConstants.CONTENT_TYPE, MigrationConstants.APPLICATION_HEADER_JSON);

            HttpEntity<Cifs> requestEntity = new HttpEntity<>(cifListRequest, headers);

            response = restTemplate.exchange(migrationFetchCifAccountUrl, HttpMethod.POST, requestEntity, Cifs.class);

        } catch (Exception exp) {
            log.error(message.descr(" Error in Fetch CIF Accounts from Finacle "+ exp));
        }
        if (null != response && null != response.getBody()) {
            log.info(message.descr("ClientService.getCifAccountInfo is ended" + response)
                        .entityName(Message.Entity.client).operation("FetchCifInfo"));
            return response.getBody();
        } else {
            return null;
        }
    }

    public Bundles getBundles(String oAuth, String ecClientId, Long jobId) {
            log.info(Message.create().descr("ClientService.getBundles is started").clientId(ecClientId).jobId(jobId)
                    .entityName(Message.Entity.client).operation("GetBundles"));

        ResponseEntity<Bundles> response = null;
        try {

            HttpHeaders headers = new HttpHeaders();
            headers.add(MigrationConstants.AUTHORIZATION_HEADER_NAME, oAuth);

            HttpEntity<?> requestEntity = new HttpEntity<>(headers);

            response = restTemplate.exchange(migrationFetchBundlesUrl, HttpMethod.GET, requestEntity, Bundles.class);

        } catch (Exception exp) {
            log.error(Message.create().descr(" Error in Fetch Digital Bundles from AdminExt "+ exp).clientId(ecClientId).jobId(jobId));
        }
        if (null != response && null != response.getBody()) {
            log.info(Message.create().descr("ClientService.getBundles is ended" + response)
                    .clientId(ecClientId).jobId(jobId).entityName(Message.Entity.client).operation("Get Bundles"));
            log.info(Message.create().descr("ClientService.getBundles is ended").clientId(ecClientId).jobId(jobId));
            return response.getBody();
        } else {
            return null;
        }
    }

    /**
     * Client inactiveAndDeleteClient Service will rollback the client
     */
    public DeleteClientResponse inactiveAndDeleteClient(String gwClientId) throws ServiceException {
        Message message = Message.create().clientId(gwClientId).entityName(Message.Entity.client);
        if(StringUtils.isEmpty(gwClientId)){
            throw new ServiceException("gwClientId is null, cannot delete client");
        }
        log.info(message.descr("InActive Client started").operation("InActiveClient"));
        DeleteClientResponse deleteClientResponse = new DeleteClientResponse();

        MigClient mg = migClientRepository.findByGwClientIdAndStatus(gwClientId, MigrationConstants.STATUS_SUCCESS);
        if (mg == null) {
            throw new ServiceException("No Client Found");
        } else {
            OlbClientIdCheck olbClientIdCheck = new OlbClientIdCheck();
            InActiveClientResponse inActiveClientResponse = null;
            olbClientIdCheck.olbIdFormatCheck(gwClientId);

            try {
                inActiveClientResponse = clientExtensionService.inActiveClient(gwClientId, ClientConstants.INACTIVE);
            } catch (Exception e) {
                deleteClientResponse.setMessage("Inactive client Errored");
                deleteClientResponse.setStatus(MigrationConstants.STATUS_FAILURE);
                return deleteClientResponse;
            }
            if (null != inActiveClientResponse && 204 == inActiveClientResponse.getStatusCode()) {
                try {
                    clientExtensionService.deleteClient(gwClientId);
                } catch (Exception e) {
                    deleteClientResponse.setMessage("Delete client Errored");
                    deleteClientResponse.setStatus(MigrationConstants.STATUS_FAILURE);
                }
                deleteClientResponse.setStatus(MigrationConstants.STATUS_SUCCESS);
            } else {
                assert inActiveClientResponse != null;
                deleteClientResponse.setMessage("Inactive client Errored, received status code is ::" + inActiveClientResponse.getStatusCode());
                deleteClientResponse.setStatus(MigrationConstants.STATUS_FAILURE);
            }

            mg.setStatus(STATUS_ROLLED_BACK);
            log.info(message.descr("Client RolledBack Success").operation("ClientRollBack").status(STATUS_ROLLED_BACK));
            migClientRepository.save(mg);
        }
        return deleteClientResponse;
    }


    public boolean processPartnerRegistrationStatus(String ecClientId, Long jobId) {
        //call client , update response
        Message logMessage = Message.create();
        try {

            MigClient client = migClientRepository.findByEcClientId(ecClientId);
            if (client == null || StringUtils.isEmpty(client.getGwClientId())) {
                log.info(logMessage.clientId(ecClientId).jobId(jobId).entityName(Message.Entity.client).descr("gwClient is null, will not process BDC registration"));
                return false;
            }
            logMessage.clientId(client.getEcClientId()).jobId(client.getJobId()).gwClientId(client.getGwClientId());

            String primaryUserUUId = Optional.ofNullable(migUserRepository.getMigratedPrimaryUser(ecClientId).getGwUuid()).orElse("");

            boolean isClientRegistered = getBdcClientStatus(client);
            log.info(logMessage.descr("Is client registered? ").status(String.valueOf(isClientRegistered)));

            boolean isUserRegistered = getBdcUserStatus(client, primaryUserUUId);
            log.info(logMessage.descr("Is user registered? ").status(String.valueOf(isUserRegistered)));

            boolean needToRegisterAgain = !(isClientRegistered && isUserRegistered);
            log.info(logMessage.descr("Need to register again? ").status(String.valueOf(needToRegisterAgain)));

            // If client and primary user registration is not successful
            if (needToRegisterAgain) {
                if (!registerBdcClient(client, isClientRegistered)) return false;
                if (!registerBdcPrimaryUser(client, isUserRegistered, primaryUserUUId)) return false;
            }

        } catch (ServiceException | InterruptedException e) {
            log.error(logMessage.descr("Could not register partner due to " + e.getMessage()));
            // Restore interrupted state...
            Thread.currentThread().interrupt();
            return false;
        }

        return true;
    }

    private boolean registerBdcClient(MigClient client, boolean isClientRegistered) throws InterruptedException, ServiceException {
        Message logMessage = Message.create().clientId(client.getEcClientId()).jobId(client.getJobId()).gwClientId(client.getGwClientId());

        if (!isClientRegistered) {
            log.info(logMessage.descr("Calling Admin for BDC Registration - client "));

            boolean registerClientPartner = clientExtensionService.registerClientPartner(client.getGwClientId());
            log.info(logMessage.descr("Submission Response for BDC Registration - client ").status(String.valueOf(registerClientPartner)));

            if (!registerClientPartner) return false;

            Thread.sleep(sleepInterval);

            if (!getBdcClientStatus(client)) return false;
        }
        log.info(logMessage.descr("Client has been registered in BDC "));
        return true;
    }

    //TODO there is no primary user in the response.
    private boolean registerBdcPrimaryUser(MigClient client, boolean isUserRegistered, String primaryUserId)
            throws InterruptedException, ServiceException {
        Message logMessage = Message.create().clientId(client.getEcClientId()).jobId(client.getJobId()).gwClientId(client.getGwClientId()).userId(primaryUserId);
        if (!isUserRegistered) {
            log.info(logMessage.descr("Registering primary user in BDC" + primaryUserId));
            boolean registerPrimaryUser = clientExtensionService.registerPrimaryUserPartner(client.getGwClientId(), primaryUserId);
            if (!registerPrimaryUser) return false;
            log.info(logMessage.descr("Called Admin endpoint for BDC registration "));

            Thread.sleep(sleepInterval);
            if (!getBdcUserStatus(client, primaryUserId)) return false;
        }
        log.info(logMessage.descr("Primary user has been registerd in BDC"));
        return true;
    }

    private boolean getBdcUserStatus(MigClient client, String primaryUserId) throws ServiceException {

        Message logMessage = Message.create().clientId(client.getEcClientId()).jobId(client.getJobId()).gwClientId(client.getGwClientId()).userId(primaryUserId);
        log.info(logMessage.descr("Getting primary user status in BDC"));

        BdcUser bdcUser=clientExtensionService.getBdcUsers(client.getGwClientId());

        if (bdcUser == null || bdcUser.getUsers().isEmpty()) {
            log.info(logMessage.descr("No BDC User present " + primaryUserId));
            return false;
        }
        List<Users> users=Optional.ofNullable(bdcUser.getUsers()).orElse(new ArrayList<>());

        if(users.isEmpty()){
            log.info(logMessage.descr("No Primary user present "));
            return false;
        }

        Set<String> uuidCompletedSet = new HashSet<>();
        for (Users user : users) {
            List<Partners> partners = user.getPartners()
                    .stream()
                    .filter(u -> BDC_NAME.equalsIgnoreCase(u.getPartnerName()))
                    .collect(Collectors.toList());

            if(partners!=null && partners.size()>0){
                long incompleteTasks=partners.get(0).getPartnerTasks().stream()
                        .filter(pt->!PARTNER_COMPLETED_STATUS.equalsIgnoreCase(pt.getPartnerTaskStatus()))
                        .count();
                if(incompleteTasks<1l){
                    uuidCompletedSet.add(user.getIdStoreuserkey());
                }
            }
        }

        return updateBdcStatusOfMigratedUsers(client, uuidCompletedSet);

    }

    private boolean updateBdcStatusOfMigratedUsers(MigClient client, Set<String> uuidCompletedSet) {
        AtomicBoolean primaryUserStatus = new AtomicBoolean(false);
        List<MigUser> migratedUsers = migUserRepository.findByJobId(client.getJobId());
        migratedUsers.stream().forEach(m -> {
            if (uuidCompletedSet.contains(m.getGwUuid())) {
                m.setBdcStatus(BDC_ENABLED);
                if (PRIMARY_USER_FLAG_TRUE.equals(m.getIsPrimaryUser())) {
                    primaryUserStatus.set(true);
                }
            } else {
                m.setBdcStatus(BDC_DISABLED);
            }
        });
        migUserRepository.saveAll(migratedUsers);
        return primaryUserStatus.get();
    }

    private boolean getBdcClientStatus(MigClient client) throws ServiceException {
        Message logMessage = Message.create().clientId(client.getEcClientId()).jobId(client.getJobId()).gwClientId(client.getGwClientId());
        boolean status=false;

        BdcClient bdcClient=clientExtensionService.getBdcClient(client.getGwClientId());
        if(bdcClient==null){
           log.info(logMessage.descr("No client present in BDC ").clientId(client.getEcClientId()).jobId(client.getJobId()));
            updateBDCStatus(client, BDC_DISABLED);
            return status;
        }

        List<ClientPartners> clientPartners=Optional.ofNullable(bdcClient.getClientPartners()).orElse(new ArrayList<>()).stream().
                filter(c-> BDC_NAME.equalsIgnoreCase(c.getPartnerName())
                        && PARTNER_COMPLETED_STATUS.equalsIgnoreCase(c.getPartnerStatus())
                ).collect(Collectors.toList());

        if(clientPartners==null || clientPartners.isEmpty()) {
            updateBDCStatus(client, BDC_DISABLED);
        }else{
            updateBDCStatus(client, BDC_ENABLED);
            status=true;
        }

        return status;
    }

    private void updateBDCStatus(MigClient client, Integer status) {
        client.setBdcStatus(status);
        migClientRepository.save(client);
    }
}
