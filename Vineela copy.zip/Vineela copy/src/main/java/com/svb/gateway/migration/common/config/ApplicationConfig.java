package com.svb.gateway.migration.common.config;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.svb.gateway.migration.common.listeners.MigrationJobListener;
import com.svb.gateway.migration.common.utility.MigrationConstants;
import com.svb.gateway.migration.ipay.batch.util.IPayConstants;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.job.builder.FlowBuilder;
import org.springframework.batch.core.job.flow.Flow;
import org.springframework.batch.core.job.flow.support.SimpleFlow;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.batch.core.launch.support.SimpleJobLauncher;
import org.springframework.batch.core.repository.JobRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.task.SimpleAsyncTaskExecutor;
import org.springframework.core.task.TaskExecutor;

import java.time.ZoneId;
import java.util.TimeZone;

@Configuration
public class ApplicationConfig {

    @Autowired
    private JobBuilderFactory jobBuilderFactory;

    @Autowired
    private Step stepDDATranHist;

    @Autowired
    private Step stepAccBalTrend;

    @Autowired
    private JobRepository jobRepository;

    @Autowired
    private Step stepAccStmts;

    @Bean
    public Job moveDDATransactionData(MigrationJobListener listener){
                   return jobBuilderFactory.get("moveDDATransactionData")
                .incrementer(new RunIdIncrementer())
                .listener(listener)
                .start(DDATranHistStepFlow())
                .end()
                .build();
    }

    @Bean
    public Job moveAccBalTrendData(MigrationJobListener listener){
        return jobBuilderFactory.get("moveAccBalTrendData")
                .incrementer(new RunIdIncrementer())
                .listener(listener)
                .start(AccBalTrendStepFlow())
                .end()
                .build();
    }


    @Bean
    public TaskExecutor taskExecutor(){
        return new SimpleAsyncTaskExecutor("spring_batch");
    }

    @Bean
    public Flow DDATranHistStepFlow()
    {
        return new FlowBuilder<SimpleFlow>("DDATranHistStepFlow")
                .start(stepDDATranHist)
                .build();
    }

    @Bean
    public Flow AccBalTrendStepFlow()
    {
        return new FlowBuilder<SimpleFlow>("AccBalTrendStepFlow")
                .start(stepAccBalTrend)
                .build();
    }


    @Bean(name = "objectMapper")
    public ObjectMapper objectMapper() {
        ObjectMapper objectMapper = new ObjectMapper();
        objectMapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
        objectMapper.setTimeZone(TimeZone.getTimeZone(ZoneId.of(MigrationConstants.US_TIME_ZONE)));
        return objectMapper;
    }
    @Bean(name = "migJobLauncher")
    public SimpleJobLauncher simpleJobLauncher() throws Exception {
        SimpleJobLauncher jobLauncher = new SimpleJobLauncher();
        jobLauncher.setJobRepository(jobRepository);
        jobLauncher.setTaskExecutor(new SimpleAsyncTaskExecutor());
        jobLauncher.afterPropertiesSet();
        return jobLauncher;
    }

    @Bean
    public Job moveAccStmtsData(MigrationJobListener listener){
        return jobBuilderFactory.get("moveAccStmtsData")
                .incrementer(new RunIdIncrementer())
                .listener(listener)
                .start(AccStmtsStepFlow())
                .end()
                .build();
    }

    @Bean
    public Flow AccStmtsStepFlow()
    {
        return new FlowBuilder<SimpleFlow>("AccStmtsStepFlow")
                .start(stepAccStmts)
                .build();
    }
}
