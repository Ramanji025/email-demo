package com.svb.gateway.migration.common.config;

import lombok.Getter;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;

@Component
//@PropertySource("file:config/config-${environment}.properties")
@Getter
public class KafkaConfigurationProperties {

    @Value("${kafka.bootstrapAddress}")
    private String bootstrapAddress;

    @Value("${kafka.sasl.jaas.config}")
    private String sslJaasConfig;

    @Value("${kafka.security.protocol}")
    private String secProtocol;

    @Value("${kafka.sasl.mechanism}")
    private String saslMechanism;

    @Value("${kafka.userName}")
    private String user;

    @Value("${kafka.pwd}")
    private String pwd;

    @Value("${topic.kafka.trn}")
    private String jsonTopic;

    @Value("${kafka.group-id}")
    private String groupId;


}
