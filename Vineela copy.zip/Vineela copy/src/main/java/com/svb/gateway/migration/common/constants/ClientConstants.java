package com.svb.gateway.migration.common.constants;

public class ClientConstants {

    public static final String COUNTRY_CODE = "1";
    public static final String CONTACT_LABEL = "MOBILE";
    public static final String SIGNER = "Y";
    public static final String PRIMARY = "Y";
    public static final String INACTIVE = "I";
    public static final String ACCOUNT_SPECIFIC_TRANSACTION = "Y";
    public static final String MIGRATION_FLAG = "Y";
    public static final String DISABLED_USER = "0";
    public static final String DELETED_USER = "2";
    public static final String FROZEN_USER = "3";
    public static final String ADDED = "ADDED";
    public static final String CLIENT_ADDED = "Client Added";
    public static final String PRIMARY_USER_ADDED = "Primary User Added";
    public static final String FAILED = "Failed";
    public static final String PRIMARY_USER_DISABLED = "Primary User Disabled";
    public static final String PRIMARY_USER_DELETED = "Primary User Deleted";
    public static final String PRIMARY_USER_FROZEN = "Primary User Frozen";
    public static final String PRIMARY_USER_LAST_LOGIN_DATE_BEYOND_THRESHOLD = "Primary User Last login date is beyond threshold";
    public static final String ALREADY_PROCESSED = "Already processed";
    public static final String PARTNERS = "partners";
    public static final String PARTNER = "partner";
    public static final String CLIENT_USERS = "clientusers";
    public static final String CLIENT = "client";
    public static final String CLIENTS = "clients";
}
