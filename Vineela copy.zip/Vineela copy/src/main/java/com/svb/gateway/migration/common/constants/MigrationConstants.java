package com.svb.gateway.migration.common.constants;

public class MigrationConstants {
    private MigrationConstants(){}
    public static final String VALID_CLIENTID_PATTERN = "^[a-zA-Z]{4}[0-9]{4}$";
    public static final String AUTHORIZATION_HEADER_NAME = "Authorization";
    public static final String CONTENT_TYPE = "Content-Type";
    public static final String APPLICATION_HEADER_JSON = "application/json";
    public static final String APPLICATION_FORM_URLENCODED = "application/x-www-form-urlencoded";

    // statuses for entities
    public static final String STATUS_SUCCESS = "SUCCESS";
    public static final String STATUS_IGNORE = "IGNORE";
    public static final String STATUS_FAILURE = "FAILURE";
    public static final String STATUS_ROLLED_BACK = "ROLLBACK";

    // Additional statuses for Client
    public static final String STATUS_IN_PROGRESS = "IN_PROGRESS";
    public static final String STATUS_CREATED = "CREATED";

    public static final String ERROR_ALREADY_PROCESSED = "409";

    public static final String BANK_ID = "SVB";
    public static final String BANK_ID_PARAM_NAME = "bank_id";
    public static final String CHANNEL_ID = "channel_id";
    public static final String LANGUAGE_ID = "language_id";
    public static final String LOGIN_FLAG = "LOGIN_FLAG";
    public static final String LOGIN_TYPE = "LOGIN_TYPE";
    public static final String CLIENT_ID = "client_id";
    public static final String CLIENT_SECRET = "client_secret";
    public static final String GRANT_TYPE = "grant_type";
    public static final String CORP_PRINCIPAL = "CORP_PRINCIPAL";
    public static final String USER_PRINCIPAL = "USER_PRINCIPAL";
    public static final String ACCESS_CODE = "ACCESS_CODE";
    public static final String USERNAME = "username";
    public static final String SIGNED_DATA = "signed_data";

    public static final String FULL_ACCESS = "FULLACCESS";
    public static final String CARD_HOLDER_ONLY_USER = "CARD_HOLDER_ONLY_USER";
    public static final String COMBO_CARD_USER = "COMBO_CARD_USER";
    public static final String ROLE_ADMIN = "ADMIN";
    public static final String ROLE_USER = "USER";
    public static final String CARD_HOLDER = "CARDHOLDER";
    public static final String ECONNECT_PRIMARY_USER_VALUE = "1";
    public static final String ECONNECT_NON_PRIMARY_USER_VALUE = "0";
    public static final String ECONNECT_ADMIN_GROUP_ID = "6";
    public static final String GW_PRIMARY_USER_VALUE = "Y";
    public static final String GW_NON_PRIMARY_USER_VALUE = "N";
    public static final String ECONNECT_PRIMARY_CONTACT_VALUE = "1";
    public static final String GW_PRIMARY_CONTACT_VALUE = "Y";
    public static final String GW_NON_PRIMARY_CONTACT_VALUE = "N";
    public static final String SLASH = "/";
    public static final String CORPORATES = "corporates";
    public static final String COUNTERPARTIES = "counterparties";
    public static final String PRIMARYUSER = "primaryuser";
    public static final String NOALERTSFLAG = "noalerts";

    public static final String CARD_PROGRAMS = "/cardPrograms";
    public static final String OPERATION = "operation";
    public static final String NOTIFICATION = "notification";
    public static final String EMAIL_REQUEST_ACCEPTED = "Email Request Accepted";
    public static final String FETCH_CLEARING_SYSTEM_DETAILS = "/fetchClearingSystemDetails?clearingSystem=Fedwire&routingCode=";

    // Gateway Headers
    public static final String HEADER_SERVICE_TOKEN = "Service-Token";
    public static final String HEADER_USER_INFO_BANK_USER_GROUP_NAME = "userinfo_bankusergroupname";
    public static final String HEADER_USER_INFO_CLIENT_LOGIN_ID = "userinfo_clientloginid";
    public static final String HEADER_USER_INFO_CLIENT_NAME = "userinfo_clientname";
    public static final String HEADER_USER_INFO_CLIENT_ID = "userinfo_clientid";
    public static final String HEADER_CORRELATION_ID = "correlationId";
    public static final String HEADER_USER_INFO_IP_ADDRESS = "userinfo_ipaddress";
    public static final String HEADER_IS_EMULATED_USER = "is_emulated_user";
    public static final String HEADER_DEVICE_INFO_CHANNEL = "deviceinfo_channel";
    public static final String HEADER_SESSION_INFO_OOB_AUTH = "sessioninfo_oobauth";
    public static final String HEADER_SESSION_INFO_SESSION_ID = "sessioninfo_sessionid";
    public static final String HEADER_DEVICE_INFO_USER_AGENT = "deviceinfo_useragent";
    public static final String HEADER_USER_INFO_USER_ID = "userinfo_userid";
    public static final String HEADER_USER_INFO_USER_LOGIN_ID = "userinfo_userloginid";
    public static final String HEADER_USER_INFO_USER_NAME = "userinfo_username";
    public static final String HEADER_REQUEST_ID = "x-request-id";

    //Transfers Constants

    public static final String DRCR_FLG = "P";
    public static final String FREQ_TYPE_O = "O";
    public static final String FREQ_TYPE_R = "R";
    public static final String REQ_STATUS = "AAC";
    public static final Integer DB_TS = 1;
    public static final String MARKED_FOR_STOP = "N";
    public static final Double REQ_REC_TOTAL_TXN_AMT_HOMECRN = 0.0;
    public static final Double REQ_REC_TOTAL_TXN_AMT = 0.0;
    public static final Double REQ_REC_TOTAL_AMT = 0.0;
    public static final Integer HIGHEST_ENTRY_SRL_NO = 1;
    public static final String IS_TXN_CONFIDENTIAL = "N";
    public static final Integer BULK_PMT_REF_NUM = 0;
    public static final String DEL_FLG = "N";
    public static final Integer FREQ_NDAYS = 0;
    public static final String HOLD_FLG = "N";
    public static final Integer NO_OF_INSTANCES_PROCESSED = 0;
    public static final String VALIDITY_INDICATOR = "N";
    public static final Integer TOT_NO_OF_INSTANCES = 1;
    public static final Double TOTAL_CHARGE_AMT = 0.0;
    public static final Integer PARENT_REQ_ID = 0;
    public static final Double HIGHEST_ENTRY_AMOUNT = 0.0;
    public static final Integer PMT_FREQ = 1;
    public static final String CHANNEL_ID_I = "I";
    public static final Double LIMIT_RATE = 0.0;
    public static final Double CHARGE_AMT = 0.0;
    public static final String CHARGE_CRN = "USD";
    public static final Double NW_COMMISSION_AMT = 0.0;
    public static final String NW_COMMISSION_CRN = "USD";
    public static final String NW_COMMISSION_INDICATOR = "S";
    public static final Integer MANDATE_NO = 0;
    public static final Double NEGOTIATED_RATE = 0.0;
    public static final Double FIRST_PMT_AMT = 0.0;
    public static final Double LAST_PMT_AMT = 0.0;
    public static final Integer NOTIFICATION_REF_NO = 0;
    public static final String IS_ADDENDA_DATA_AVAILABLE = "N";
    public static final String TRN_ACCT_ENTITY_TYPE = "T";
    public static final Integer REQ_SR_NO = 1;
    public static final String BENE_REF_NO = "0";
    public static final Integer TOTAL_NO_OF_ENTRIES = 1;
    public static final Double CTRD_DEBIT_AMOUNT = 0.0;
    public static final String ACCT_EXTN2 = "SB0";
    public static final String ACCT_EXTN1 = "SVB";
    public static final String TXN_TYPE = "XFR";
    public static final String NETWORK_ID = "WIB";
    public static final String CP_ENTITY_TYPE = "T";


    public static final String MIGRATION_JOB_REPORT_PREFIX = "MigrationJobReport";
    public static final String PDF = "pdf";
    public static final String XLS = "xls";
    public static final String XLSX = "xlsx";
    public static final String REPORT_DATE_FORMAT = "EEE, d MMM yyyy HH:mm";
    public static final String SVB = "SVB";
    public static final String SB0 = "SB0";
    public static final String USER_CREATION = "UserCreation";
    public static final String CLIENT_CREATION = "ClientCreation";
    public static final String ENROLL_CARD_PROGRAM = "Enroll-Card-Program";
    public static final String PRIMARY_USER_CREATION = "PrimaryUserCreation";
    public static final String ADDITIONAL_USER_CREATION = "AdditionalUserCreation";
    public static final String BENE_CREATION = "BeneCreation";
    public static final String TRANSFERS_CREATION = "TransfersCreation";
    public static final String INTERNAL_TRANSFER = "Internal Transfer";
    public static final String WIRE_TRANSFER = "Wire Transfer";
    public static final String WIRE_TRANSFERS_CREATION = "WireTransfersCreation";
    public static final String EMAIL_NOTIFICATION = "EmailNotificationSent";
    public static final String STEP_CLIENT_MIGRATION = "stepClientMigration";
    public static final String ADDRESS_DOCTOR_VALIDATION_MESSAGE = "Address Validation Score not meeting the C4 criteria.";
    public static final String DISABLED = "Disabled";
    public static final String CONTACT_LABEL = "MOBILE";
    public static final String COUNTRY_CODE = "1";
    public static final String INACTIVATE = "INACTIVATE";
    public static final String PARTNER_RETRIGGER_ENROLLMENT = "partnerRetriggerEnrollment";
    public static final Integer COUNT_ZERO = 0;
    public static final String MIGRATED_SUCCESS = "Successfully Migrated to Gateway";
    public static final String MIGRATED_ERROR_SUCCESS = "Successfully reported data errors to Gateway";
    public static final String MIGRATED_ERROR_IGNORED = "Validation errors not reported to Gateway";
    public static final String ENROLLING_CLIENT = "enrolling client";

    public static final String MDC_REQUEST_URI = "requestURI";
    public static final String MDC_REQUEST_METHOD = "requestMethod";
    public static final String MDC_REQUEST_IP = "userinfo_ipaddress";
    public static final String MDC_USER_AGENT = "deviceinfo_useragent";
    public static final String MDC_SESSION_ID = "sessioninfo_sessionid";
    public static final String MDC_USER_ID = "userId";
    public static final String MDC_START_TIME = "startTime";
    public static final String MDC_CORRELATION_ID ="correlationId";
    public static final String AUTHORIZATION_HEADER = "Authorization";
    public static final String ORIGINATING_IP_HEADER = "x-forwarded-for";
    public static final String USER_AGENT_HEADER = "User-Agent";

    public static final String DOM = "DOM";
    public static final String INTL = "INTL";
    public static final String FED = "FED";
    public static final String USI = "USI";
    public static final String SWIFT = "SWIFT";
    public static final String FALSE = "false";
    public static final String ROLLBACK_INITIATED = "rollback initiated";
    public static final String INTERNAL_TRANSFERS_TABLE_NAME = "MIG_INT_TRANSFERS";
    public static final String WIRE_TRANSFERS_TABLE_NAME = "MIG_WIRE_OUTGOING";
    public static final String SVB_INNOVATORS_CARD = "SVB Innovators Card";
    public static final String PRINCIPAL_ID = "8000";

    public static final String  BDC_NAME= "Bill.com";
    public static final String  PARTNER_COMPLETED_STATUS= "completed";
    public static final String ASTERISKS= "******";
    public static final String USER_WO_CARD = "USER_WO_CARD";
}
