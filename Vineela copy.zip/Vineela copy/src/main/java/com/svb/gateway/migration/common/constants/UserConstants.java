package com.svb.gateway.migration.common.constants;

public class UserConstants {

    public static final String DELETED = "D";
    public static final String FROZEN = "F";
    public static final String INACTIVE = "I";
    public static final String DELETED_USER = "2";
    public static final String FROZEN_USER = "3";
    public static final String DISABLED_USER = "0";
    public static final String PRIMARY_USER_SUCCESS = "Primary User Added";
    public static final String DELETED_USER_FAILURE = "Deleted User, Migration Failed";
    public static final String FROZEN_USER_FAILURE = "Frozen User, Migration Failed";
    public static final String ACTIVE_USER_SUCCESS = "Active User, Migration Success";
    public static final String DISABLED_USER_SUCCESS = "Disabled User, Migration Success";
    public static final String USER_ENTITY_FAILED = "user Entity insert/Update Failed";
    public static final String ADD_USER_FAILED = "Add User Failed";
    public static final String LAST_LOGIN_DATE_BEYOND_THRESHOLD = "Last login date beyond threshold, Migration Failed";
    public static final String N_FLAG = "N";
    public static final String Y_FLAG = "Y";
    public static final Integer BDC_DISABLED = 0;
    public static final Integer BDC_ENABLED = 1;
    public static final Integer PRIMARY_USER_FLAG_TRUE = 1;
    public static final Integer PRIMARY_USER_FLAG_FALSE = 0;
    public static final String ADDITIONAL_USER_SUCCESS = "Additional User created successfully";
}
