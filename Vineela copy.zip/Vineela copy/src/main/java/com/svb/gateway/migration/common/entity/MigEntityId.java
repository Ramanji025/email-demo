package com.svb.gateway.migration.common.entity;

public class MigEntityId implements java.io.Serializable{

    Integer jobId;
    String entityName;
}
