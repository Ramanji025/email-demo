package com.svb.gateway.migration.common.exception;

import com.svb.gateway.migration.common.utility.MigrationErrorCodeEnum;
import org.springframework.http.HttpStatus;

public class BadRequestException extends RuntimeException {

	private static final long serialVersionUID = 5164312703247351740L;

	private MigrationErrorCodeEnum errorCode;

	private String errorDescription;
	
	public BadRequestException() {
		super(HttpStatus.BAD_REQUEST.getReasonPhrase());
	}

	public BadRequestException(MigrationErrorCodeEnum errorCode) {
		super(HttpStatus.BAD_REQUEST.getReasonPhrase());
		this.errorCode = errorCode;
	}

	public BadRequestException(MigrationErrorCodeEnum errorCode, String errorMessage) {
		super(errorMessage);
		this.errorCode = errorCode;
		this.errorDescription = errorMessage;
	}

	public BadRequestException(MigrationErrorCodeEnum errorCode, String errorMessage, Throwable t) {
		super(errorMessage, t);
		this.errorCode = errorCode;
		this.errorDescription = errorMessage;
	}

	public MigrationErrorCodeEnum getErrorCode() {
		return errorCode;
	}

	public String getErrorDescription() {
		return errorDescription;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("BadRequestException [errorCode=").append(errorCode).append(", errorDescription=")
				.append(errorDescription).append("]");
		return builder.toString();
	}
}
