package com.svb.gateway.migration.common.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(code = HttpStatus.BAD_REQUEST)
public class InvalidInputException extends IllegalArgumentException {
    public InvalidInputException(String message) {
        super(message);     }

    public InvalidInputException(String message, Throwable cause) {
        super(message, cause);
    }
}
