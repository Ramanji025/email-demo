package com.svb.gateway.migration.common.listeners;

import com.svb.gateway.migration.common.model.OauthResponse;
import com.svb.gateway.migration.common.utility.MigrationConstants;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.ObjectUtils;
import org.ehcache.event.CacheEvent;
import org.ehcache.event.CacheEventListener;

import static com.svb.gateway.migration.common.utility.MigrationConstants.ASTERISKS;

@Slf4j
public class EhCacheEventListener implements CacheEventListener<Object, Object> {

    @Override
    public void onEvent(CacheEvent cacheEvent) {

        String newToken = null;
        String oldToken = null;
        OauthResponse response;
        if (cacheEvent.getOldValue() instanceof OauthResponse
                || cacheEvent.getNewValue() instanceof OauthResponse) {
            if (ObjectUtils.isNotEmpty(cacheEvent.getNewValue())) {
                response = (OauthResponse) cacheEvent.getNewValue();
                newToken = response.getAccess_token();
                newToken = ASTERISKS + newToken.substring(0, newToken.length() - 5) + ASTERISKS;
            }
            if (ObjectUtils.isNotEmpty(cacheEvent.getOldValue())) {
                response = (OauthResponse) cacheEvent.getOldValue();
                oldToken = response.getAccess_token();
                oldToken = ASTERISKS + oldToken.substring(0, oldToken.length() - 5) + ASTERISKS;
            }
        }
        log.info("Event Type --> {}, Key --> {}, Old Value --> {},New Value --> {}",
                cacheEvent.getType().name(), cacheEvent.getKey(), oldToken, newToken);
    }
}