package com.svb.gateway.migration.common.listeners;

import lombok.extern.slf4j.Slf4j;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.listener.ItemListenerSupport;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
@Slf4j
public class MigrationItemListener<I, O> extends ItemListenerSupport<I, O> {

    private Logger LOGGER = LoggerFactory.getLogger(MigrationItemListener.class);

    public MigrationItemListener() {
        super();
    }

    @Override
    public void afterRead(I item) {
        super.afterRead(item);
    }

    @Override
    public void beforeRead() {
        super.beforeRead();
    }

    @Override
    public void onReadError(Exception ex) {
        super.onReadError(ex);
    }

    @Override
    public void afterProcess(I item, O result) {
        super.afterProcess(item, result);
    }

    @Override
    public void beforeProcess(I item) {
        super.beforeProcess(item);
    }

    @Override
    public void onProcessError(I item, Exception e) {
        super.onProcessError(item, e);
    }

    @Override
    public void afterWrite(List<? extends O> item) {

        super.afterWrite(item);
    }

    @Override
    public void beforeWrite(List<? extends O> item) {
        super.beforeWrite(item);
    }

    @Override
    public void onWriteError(Exception ex, List<? extends O> item) {
        super.onWriteError(ex, item);
    }

}
