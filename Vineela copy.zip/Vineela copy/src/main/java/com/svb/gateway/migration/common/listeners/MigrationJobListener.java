package com.svb.gateway.migration.common.listeners;

import com.svb.gateway.migration.common.utility.JobStatusEnum;
import com.svb.gateway.migration.common.utility.MigrationConstants;
import com.svb.gateway.migration.job.entity.JobEntity;
import com.svb.gateway.migration.job.mapper.JobMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.BatchStatus;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.listener.JobExecutionListenerSupport;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.time.*;

@Component
public class MigrationJobListener extends JobExecutionListenerSupport {

    private static final Logger LOGGER = LoggerFactory.getLogger(MigrationJobListener.class);

    @Autowired
    private final JobMapper jobMapper;

    public MigrationJobListener(JobMapper jobMapper) {
        super();
        this.jobMapper = jobMapper;
    }

    @Override
    public void beforeJob(JobExecution jobExecution) {
        super.beforeJob(jobExecution);
    }

    @Override
    public void afterJob(JobExecution jobExecution) {
        if(jobExecution.getStatus() == BatchStatus.COMPLETED) {
            LOGGER.info("!!! JOB FINISHED! Time to verify the results");
            // update ec2Stage job completion
            if(MigrationConstants.MIGRATE_EC_DATA_JOB.equals(jobExecution.getJobInstance().getJobName())) {
                String jobID = jobExecution.getJobParameters().getParameters().get(MigrationConstants.JOB_ID_KEY).getValue().toString();
                JobEntity e = jobMapper.readMigrationJob(Integer.parseInt(jobID));
                OffsetDateTime now = OffsetDateTime.now().withOffsetSameInstant(ZoneOffset.UTC);
                e.setEndTime(now);
                e.setExtractionTime(Duration.between(e.getStartTime(), now).toSeconds());
                e.setUpdatedDate(now);
                e.setStatus(JobStatusEnum.EXTRACTION_COMPLETED);
                jobMapper.updateJob(e);
            }
        }
    }
}
