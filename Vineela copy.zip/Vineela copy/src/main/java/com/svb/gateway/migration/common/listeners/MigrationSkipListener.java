package com.svb.gateway.migration.common.listeners;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.svb.gateway.migration.common.utility.BatchMetaDataQueries;
import lombok.SneakyThrows;
import org.codehaus.jettison.json.JSONException;
import org.codehaus.jettison.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.SkipListener;
import org.springframework.batch.core.StepExecution;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.Map;

import static com.svb.gateway.migration.common.utility.MigrationConstants.*;

@Component
public class MigrationSkipListener<T, S> implements SkipListener<T, S> {

    private static final Logger LOGGER = LoggerFactory.getLogger(MigrationSkipListener.class);

    @Autowired
    private MigrationStepListener migrationStepListener;
    @Autowired
    @Qualifier("migrationNamedParameterJdbcTemplate")
    private NamedParameterJdbcTemplate jdbcTemplate;
    private ObjectMapper objectMapper = new ObjectMapper();

    @SneakyThrows
    @Override
    public void onSkipInRead(Throwable throwable) {
        saveSkipLog(null, throwable);
        LOGGER.debug("Reading record encountered error : " + throwable.getMessage());

    }

    @SneakyThrows
    @Override
    public void onSkipInWrite(S item, Throwable throwable) {

        saveSkipLog(item, throwable);
        LOGGER.debug("Writing record skipped : " + item.toString() + " Error : " + throwable.getMessage());
    }

    @SneakyThrows
    @Override
    public void onSkipInProcess(T item, Throwable throwable) {

        saveSkipLog(item, throwable);
        LOGGER.debug("Record skipped in-process. Reason: " + throwable.getMessage() + ". Item : " + item.toString());
    }

    private void saveSkipLog(Object item, Throwable throwable) throws JsonProcessingException, JSONException {
        StepExecution execution = migrationStepListener.getStepExecution();
        Map<String, Object> parameters = new HashMap<>();
        parameters.put(ENTITY_NAME, execution.getStepName());
        if (throwable.getCause() != null) {
            parameters.put(FAILURE_REASON, throwable.getCause().getMessage());
        } else {
            parameters.put(FAILURE_REASON, null);
        }
        parameters.put(EXCEPTION_TYPE, throwable.getClass().getName());
        parameters.put(JOB_ID, execution.getJobExecution().getJobParameters().getLong(JOB_ID_KEY));
        if (item != null) {
            String dataJson = objectMapper.writeValueAsString(item);
            JSONObject data = new JSONObject(dataJson);
            if (data.has(CUST_NUM)) {
                parameters.put(CIF_NUMBER, data.getLong(CUST_NUM));
            } else {
                parameters.put(CIF_NUMBER, null);
            }
            parameters.put(RECORD_DETAILS, dataJson);
            parameters.put(ECCLIENT_ID, null);
            parameters.put(GWCLIENT_ID, null);
        } else {
            parameters.put(CIF_NUMBER, null);
            parameters.put(RECORD_DETAILS, null);
            parameters.put(ECCLIENT_ID, null);
            parameters.put(GWCLIENT_ID, null);
        }
        jdbcTemplate.update(BatchMetaDataQueries.SKIP_LOG_QUERY_INSERT, parameters);
    }

}
