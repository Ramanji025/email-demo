package com.svb.gateway.migration.common.listeners;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.svb.gateway.migration.common.utility.BatchMetaDataQueries;
import lombok.SneakyThrows;
import org.codehaus.jettison.json.JSONException;
import org.codehaus.jettison.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.StepExecutionListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Component;

import java.time.OffsetDateTime;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import static com.svb.gateway.migration.common.utility.MigrationConstants.*;


@Component
public class MigrationStepListener implements StepExecutionListener {

    private static final Logger LOGGER = LoggerFactory.getLogger(MigrationStepListener.class);
    private ThreadLocal<StepExecution> thlStepExecution = new ThreadLocal<StepExecution>();

    private Date startTime;

    private Date endTime;

    @Autowired
    @Qualifier("migrationNamedParameterJdbcTemplate")
    private NamedParameterJdbcTemplate jdbcTemplate;
    private ObjectMapper objectMapper = new ObjectMapper();

    public StepExecution getStepExecution() {
        return thlStepExecution.get();
    }

    @Override
    public void beforeStep(StepExecution stepExecution) {

        thlStepExecution.set(stepExecution);
        this.startTime = new Date();
        LOGGER.debug("Before starting the step [" + stepExecution.getStepName() + "], time is: " + startTime);
    }

    @SneakyThrows
    @Override
    public ExitStatus afterStep(StepExecution stepExecution) {
        LOGGER.info("Skipped Records ==> {}", stepExecution.getSkipCount());
        LOGGER.info("Read Records ==> {}", stepExecution.getReadCount());
        LOGGER.info("Write Records ==> {}", stepExecution.getWriteCount());
        LOGGER.info("WriteSkip Records ==> {}", stepExecution.getWriteSkipCount());
        LOGGER.info("ReadSkip Records ==> {}", stepExecution.getReadSkipCount());
        LOGGER.info("Step Name ==> {}", stepExecution.getStepName());
        LOGGER.info("Job Status ==> {}", stepExecution.getStatus());
        endTime = new Date();
        String stepName = stepExecution.getStepName();
        LOGGER.info("After Finishing the step [" + stepName + "], time is: " + endTime);
        LOGGER.info("Total time taken by the step " + stepName + " is: "
                + ((endTime.getTime() - startTime.getTime()) / 1000) + " secs");
        LOGGER.info("Finished step: [" + stepName + "]");

        saveStepLog(stepExecution,startTime,endTime);
        return null;
    }

    private void saveStepLog(StepExecution stepExecution, Date startTime, Date endTime) throws JsonProcessingException, JSONException {
        Map<String, Object> parameters = new HashMap<>();
        parameters.put(MIG_ENTITY_ID,stepExecution.getJobExecution().getJobConfigurationName());
        parameters.put(ENTITY_NAME, stepExecution.getStepName());
        parameters.put(JOB_ID, stepExecution.getJobExecution().getJobParameters().getLong(JOB_ID_KEY));
        parameters.put(START_TIME,startTime);
        parameters.put(END_TIME,endTime);
        parameters.put(TOTAL_STEP_TIME,((endTime.getTime() - startTime.getTime())/1000 ));
        if (stepExecution != null) {
            String dataJson = objectMapper.writeValueAsString(stepExecution.getJobExecution().getJobParameters());
            JSONObject data = new JSONObject(dataJson);
            if (data.has(PARAMETERS)) {
                JSONObject param=data.getJSONObject(PARAMETERS);
                if(param.has(CIF_ID)) {
                    JSONObject cifIds=param.getJSONObject(CIF_ID);
                    parameters.put(CIF_NUMBER, cifIds.getString(VALUE));
                } else {
                    parameters.put(CIF_NUMBER, null);
                }

            } else {
                parameters.put(CIF_NUMBER, null);
            }
        }
        parameters.put(ECCLIENT_ID, null);
        parameters.put(GWCLIENT_ID, null);
        parameters.put(READCOUNT, stepExecution.getReadCount());
        parameters.put(WRITECOUNT, stepExecution.getWriteCount());
        parameters.put(SKIPCOUNT, stepExecution.getSkipCount());
        jdbcTemplate.update(BatchMetaDataQueries.ENTITY_LOG_QUERY_INSERT, parameters);
    }

}
