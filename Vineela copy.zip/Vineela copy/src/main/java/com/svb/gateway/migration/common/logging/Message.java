package com.svb.gateway.migration.common.logging;

import com.svb.gateway.migration.beneficiaries.entity.StgToTargetBeneEntity;
import com.svb.gateway.migration.common.constants.MigrationConstants;

import java.util.Comparator;
import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;

/**
 * A utility class for standardized logging.
 *
 * Use the annotaion @Log4j2 at the top of the class
 *
 * log.info(Message.create().descr("TESTING LOGGING").clientId("abcd1234").status(STATUS_SUCCESS));
 *
 */
public class Message {
    public enum SourceType{
        eConnect, iPay
    }

    public enum Entity {
        client, user, beneficiary, payment, transfer, creditCard, alert, updateCard
    }

    public enum JobType {
        load, extraction, rollback, postProcessing
    }

    // Add a new token in 3 places.
    // 1. a constant below.
    // 2. the place in the order array which is the order it will appear in the log
    // 3. a token method, sorted alphabetically, see below
    private static final String DESCRIPTION = "descr";
    private static final String STATUS = "status";
    private static final String JOB_ID = "jobId";
    private static final String CLIENT_ID = "clientId";
    private static final String GW_CLIENT_ID = "gwClientId";
    private static final String OPERATION = "op";
    private static final String TARGET_ID = "targetId";
    private static final String JOB_TYPE = "jobType";
    private static final String ENTITY_NAME = "name";
    private static final String SOURCE_TYPE = "srcType";
    private static final String SOURCE_ID = "srcId";
    private static final String USER_ID = "userId";
    public static final String ACCOUNT_NUMBER = "accountNumber";
    public static final String BANK_ID = "bankId";
    public static final String PAYEE_TYPE = "payeeType";
    public static final String TIME_TAKEN = "tt";
    public static final String URL = "url";
    public static final String ERROR_SOURCE = "errorSource";

    private static final String[] logOrder = new String[]
            { JOB_TYPE, JOB_ID, CLIENT_ID, GW_CLIENT_ID, USER_ID,ENTITY_NAME, OPERATION, SOURCE_TYPE, SOURCE_ID, TARGET_ID, STATUS,ACCOUNT_NUMBER, BANK_ID, PAYEE_TYPE, URL, TIME_TAKEN, ERROR_SOURCE, DESCRIPTION};

    private static final Map<String, Integer> loggingOrder = new HashMap<>();
    static {
        for (int i=0; i<logOrder.length; i++){
            loggingOrder.put(logOrder[i], i);
        }
    }

    class LogOrderComparator<T> implements Comparator<T>  {
        public static final int GREATER = 1;
        public static final int LESSER = -1;
        public static final int EQUAL = 0;
        @Override
        public int compare(T key1, T key2) {
            Integer v1 = loggingOrder.get(key1);
            Integer v2 = loggingOrder.get(key2);
            if(v1==null && v2==null){
                return String.valueOf(key1).compareTo(String.valueOf(key2));
            }
            else if(v1==null){
                return GREATER;
            }
            else if(v2==null){
                return LESSER;
            }
            else if(loggingOrder.get(key1) > loggingOrder.get(key2) ){
                return GREATER;
            }
            else if(loggingOrder.get(key1) < loggingOrder.get(key2) ){
                return LESSER;
            }
            else {
                return EQUAL;
            }
        }
    }

    private final Map<String, String> tokens = new TreeMap<>(new LogOrderComparator<>());

    public static Message create() {
        return new Message();
    }

    private Message() {
    }

    /**
     * Token methods sorted alphabetically below:
     */

    public Message accountNumber(String s) {
        return append(ACCOUNT_NUMBER,MigrationConstants.ASTERISKS +s.substring(s.length()-5));
    }

    public Message bankId(String s) {
        return append(BANK_ID, s);
    }

    public Message clientId(String s) {
        return append(CLIENT_ID, s);
    }

    public Message descr(String s) {
        return append(DESCRIPTION, s);
    }

    /**
     * @param s Entity.client, user, beneficiary, payment, transfer, creditCard
     * @return
     */
    public Message entityName(Entity s) {
        return append(ENTITY_NAME, s.name());
    }

    public Message errorSource(String s) { return append(ERROR_SOURCE, s); }

    public Message gwClientId(String s) {
        return append(GW_CLIENT_ID, s);
    }

    public Message jobId(Long s) {
        return append(JOB_ID, s);
    }

    /**
     * @param s JobType.load, extraction, rollback, postProcessing
     * @return
     */
    public Message jobType(JobType s) {
        return append(JOB_TYPE, s.name());
    }

    /**
     * Categorize steps within an entity
     * @param s
     * @return
     */
    public Message operation(String s) {
        return append(OPERATION, s);
    }

    public Message payeeType(StgToTargetBeneEntity.PAYEE_TYPE s) {
        return append(PAYEE_TYPE, s.name());
    }

    public Message srcId(String s) {
        return append(SOURCE_ID, s);
    }

    /**
     * @param s SourceType.eConnect, iPay
     * @return
     */
    public Message srcType(SourceType s) {
        return append(SOURCE_TYPE, s.name());
    }

    /**
     * For now use the status constants in MigrationConstants
     * @param s
     * @return
     */
    public Message status(String s) {
        return append(STATUS, s);
    }

    public Message targetId(String s) {
        return append(TARGET_ID, s);
    }

    public Message timeTaken(long s) {
        return append(TIME_TAKEN, s);
    }

    public Message url(String s) {
        return append(URL, s);
    }

    public Message userId(String s) {
        return append(USER_ID, s);
    }

    /**
     * Token methods sorted alphabetically above ^^^:
     */

    public Message append(String key, Object value) {
        tokens.put(key, String.valueOf(value));
        return this;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        for  (Map.Entry<String, String>  entry : tokens.entrySet()) {
            sb.append(" ");
            sb.append(entry.getKey());
            sb.append("=");
            String value = entry.getValue();
            // value is never null since append does String.valueOf(value)
            if (value.contains(" ")
                    && !(value.startsWith("[") && value.endsWith("]"))) {
                // put values with spaces in brackets
                sb.append("[");
                sb.append(value);
                sb.append("]");
            } else {
                sb.append(value);
            }
        }
        return sb.toString().trim();
    }
}
