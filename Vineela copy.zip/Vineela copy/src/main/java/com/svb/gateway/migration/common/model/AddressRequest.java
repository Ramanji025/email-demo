package com.svb.gateway.migration.common.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonPropertyOrder({
        "orignladdrln1",
        "orignladdrln2",
        "orignladdrln3",
        "orignlcitynm",
        "orignlstatecd",
        "orignlcntrycd",
        "orignlzipcd",
        "orignlcompleteaddr"
})
public class AddressRequest {

    @JsonProperty("orignladdrln1")
    private String orignladdrln1;
    @JsonProperty("orignladdrln2")
    private String orignladdrln2;
    @JsonProperty("orignladdrln3")
    private String orignladdrln3;
    @JsonProperty("orignlcitynm")
    private String orignlcitynm;
    @JsonProperty("orignlstatecd")
    private String orignlstatecd;
    @JsonProperty("orignlcntrycd")
    private String orignlcntrycd;
    @JsonProperty("orignlzipcd")
    private String orignlzipcd;
    @JsonProperty("orignlcompleteaddr")
    private String orignlcompleteaddr;



    public String getOrignladdrln1() {
        return orignladdrln1;
    }

    public void setOrignladdrln1(String orignladdrln1) {
        this.orignladdrln1 = orignladdrln1;
    }

    public String getOrignladdrln2() {
        return orignladdrln2;
    }

    public void setOrignladdrln2(String orignladdrln2) {
        this.orignladdrln2 = orignladdrln2;
    }

    public String getOrignladdrln3() {
        return orignladdrln3;
    }

    public void setOrignladdrln3(String orignladdrln3) {
        this.orignladdrln3 = orignladdrln3;
    }

    public String getOrignlcitynm() {
        return orignlcitynm;
    }

    public void setOrignlcitynm(String orignlcitynm) {
        this.orignlcitynm = orignlcitynm;
    }

    public String getOrignlstatecd() {
        return orignlstatecd;
    }

    public void setOrignlstatecd(String orignlstatecd) {
        this.orignlstatecd = orignlstatecd;
    }

    public String getOrignlcntrycd() {
        return orignlcntrycd;
    }

    public void setOrignlcntrycd(String orignlcntrycd) {
        this.orignlcntrycd = orignlcntrycd;
    }

    public String getOrignlzipcd() {
        return orignlzipcd;
    }

    public void setOrignlzipcd(String orignlzipcd) {
        this.orignlzipcd = orignlzipcd;
    }

    public String getOrignlcompleteaddr() {
        return orignlcompleteaddr;
    }

    public void setOrignlcompleteaddr(String orignlcompleteaddr) {
        this.orignlcompleteaddr = orignlcompleteaddr;
    }
}
