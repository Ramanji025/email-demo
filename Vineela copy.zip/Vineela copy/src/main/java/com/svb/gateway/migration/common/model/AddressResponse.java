package com.svb.gateway.migration.common.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;


@JsonPropertyOrder({
        "cleansedaddrln1",
        "cleansedaddrln2",
        "cleansedaddrln3",
        "cleansedcitynm",
        "cleansedstatecd",
        "cleansedstatefullname",
        "cleansedcntrycd",
        "cleansedcntryfullname",
        "cleansedzipcd",
        "validationscore",
        "validationdesc"
})
public class AddressResponse {

    @JsonProperty("cleansedaddrln1")
    private String cleansedaddrln1;
    @JsonProperty("cleansedaddrln2")
    private String cleansedaddrln2;
    @JsonProperty("cleansedaddrln3")
    private String cleansedaddrln3;
    @JsonProperty("cleansedcitynm")
    private String cleansedcitynm;
    @JsonProperty("cleansedstatecd")
    private String cleansedstatecd;
    @JsonProperty("cleansedstatefullname")
    private String cleansedstatefullname;
    @JsonProperty("cleansedcntrycd")
    private String cleansedcntrycd;
    @JsonProperty("cleansedcntryfullname")
    private String cleansedcntryfullname;
    @JsonProperty("cleansedzipcd")
    private String cleansedzipcd;
    @JsonProperty("validationscore")
    private String validationscore;
    @JsonProperty("validationdesc")
    private String validationdesc;

    public String getCleansedaddrln1() {
        return cleansedaddrln1;
    }

    public void setCleansedaddrln1(String cleansedaddrln1) {
        this.cleansedaddrln1 = cleansedaddrln1;
    }

    public String getCleansedaddrln2() {
        return cleansedaddrln2;
    }

    public void setCleansedaddrln2(String cleansedaddrln2) {
        this.cleansedaddrln2 = cleansedaddrln2;
    }

    public String getCleansedaddrln3() {
        return cleansedaddrln3;
    }

    public void setCleansedaddrln3(String cleansedaddrln3) {
        this.cleansedaddrln3 = cleansedaddrln3;
    }

    public String getCleansedcitynm() {
        return cleansedcitynm;
    }

    public void setCleansedcitynm(String cleansedcitynm) {
        this.cleansedcitynm = cleansedcitynm;
    }

    public String getCleansedstatecd() {
        return cleansedstatecd;
    }

    public void setCleansedstatecd(String cleansedstatecd) {
        this.cleansedstatecd = cleansedstatecd;
    }

    public String getCleansedstatefullname() {
        return cleansedstatefullname;
    }

    public void setCleansedstatefullname(String cleansedstatefullname) {
        this.cleansedstatefullname = cleansedstatefullname;
    }

    public String getCleansedcntrycd() {
        return cleansedcntrycd;
    }

    public void setCleansedcntrycd(String cleansedcntrycd) {
        this.cleansedcntrycd = cleansedcntrycd;
    }

    public String getCleansedcntryfullname() {
        return cleansedcntryfullname;
    }

    public void setCleansedcntryfullname(String cleansedcntryfullname) {
        this.cleansedcntryfullname = cleansedcntryfullname;
    }

    public String getCleansedzipcd() {
        return cleansedzipcd;
    }

    public void setCleansedzipcd(String cleansedzipcd) {
        this.cleansedzipcd = cleansedzipcd;
    }

    public String getValidationscore() {
        return validationscore;
    }

    public void setValidationscore(String validationscore) {
        this.validationscore = validationscore;
    }

    public String getValidationdesc() {
        return validationdesc;
    }

    public void setValidationdesc(String validationdesc) {
        this.validationdesc = validationdesc;
    }
}
