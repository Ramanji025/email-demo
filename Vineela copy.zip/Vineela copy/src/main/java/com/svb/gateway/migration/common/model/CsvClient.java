package com.svb.gateway.migration.common.model;

import com.opencsv.bean.CsvBindByName;
import lombok.Data;

@Data
public class CsvClient {

    @CsvBindByName(column = "EC_CLIENT_ID")
    private String ecClientId;

}
