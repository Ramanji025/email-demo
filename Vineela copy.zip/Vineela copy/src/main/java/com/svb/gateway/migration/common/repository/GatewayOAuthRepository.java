package com.svb.gateway.migration.common.repository;

import com.svb.gateway.migration.common.constants.MigrationConstants;
import com.svb.gateway.migration.common.exception.ServiceException;
import com.svb.gateway.migration.common.model.OauthResponse;
import com.svb.gateway.migration.common.utility.MigrationErrorCodeEnum;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.stereotype.Repository;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestClientResponseException;
import org.springframework.web.client.RestTemplate;


@Repository
public class GatewayOAuthRepository {

    @Autowired
    private RestTemplate restTemplate;

    @Value("${mig.channel.id}")
    private String channelId;

    @Value("${mig.client.id}")
    private String clientId;

    @Value("${mig.client.secret}")
    private String clientSecret;

    @Value("${mig.grant.type.password}")
    private String grantType;

    @Value("${mig.language.id}")
    private String langId;

    @Value("${mig.user.principal}")
    private String migUserPrincipal;


    @Value("${mig.oauth.url}")
    private String migOAuthUrl;

    @Value("${header.service.token}")
    String token;


    Logger logger = LoggerFactory.getLogger(GatewayOAuthRepository.class);

    @Autowired
    public GatewayOAuthRepository(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    }

    public OauthResponse getUserAccessToken() throws ServiceException
    {
        HttpHeaders headers = new HttpHeaders();
        headers.add(MigrationConstants.CONTENT_TYPE, MigrationConstants.APPLICATION_FORM_URLENCODED);

        MultiValueMap<String, String> mvm = new LinkedMultiValueMap<>();
        mvm.add(MigrationConstants.BANK_ID_PARAM_NAME, MigrationConstants.BANK_ID);
        mvm.add(MigrationConstants.CHANNEL_ID, channelId);
        mvm.add(MigrationConstants.LANGUAGE_ID, langId);
        mvm.add(MigrationConstants.CLIENT_ID, clientId);
        mvm.add(MigrationConstants.CLIENT_SECRET, clientSecret);
        mvm.add(MigrationConstants.GRANT_TYPE, grantType);
        mvm.add(MigrationConstants.USERNAME, migUserPrincipal.toUpperCase());
        mvm.add(MigrationConstants.SIGNED_DATA, token);

        try
        {
            HttpEntity<MultiValueMap<String, String>> httpEntity = new HttpEntity<>(mvm, headers);

            //logger.info("httpEntity.getBody() :: --> "+httpEntity.getBody());

            ResponseEntity<OauthResponse> response = restTemplate.exchange(migOAuthUrl, HttpMethod.POST, httpEntity, OauthResponse.class);

            return response.getBody();
        }
        catch(RestClientResponseException rce)
        {
            logger.error("Error in getting user access token");
            throw new ServiceException(HttpStatus.valueOf(rce.getRawStatusCode()), MigrationErrorCodeEnum.SSO_USER_ACCESSTOKEN_REQUEST_FAILED, rce);

        }

    }
    
}
