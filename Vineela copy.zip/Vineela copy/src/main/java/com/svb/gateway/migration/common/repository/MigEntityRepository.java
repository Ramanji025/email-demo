package com.svb.gateway.migration.common.repository;

import com.svb.gateway.migration.common.entity.MigEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface MigEntityRepository extends JpaRepository<MigEntity, Integer> {

    @Query(value = "select * from MIG_ENTITY where JOB_ID = ?1", nativeQuery = true)
    List<MigEntity> findbyJobId(Integer jobid);

    @Query(value = "SELECT * from MIG_ENTITY where JOB_ID = ?1 and ENTITY_NAME NOT IN ?2 ", nativeQuery = true)
    List<MigEntity> findByJobIdAndByEntityNameNotIn(Integer jobid, List<String> entityNames);

    @Query(value = "SELECT * from MIG_ENTITY where JOB_ID =?1 and ENTITY_NAME = 'EmailNotificationSent' ", nativeQuery = true)
    List<MigEntity> findbyJobd(Integer jobid);
}
