package com.svb.gateway.migration.common.repository;

import com.svb.gateway.migration.common.entity.MigEntityUser;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface MigEntityUserRepository extends JpaRepository<MigEntityUser, Integer> {

    @Query(value = "SELECT * from MIG_ENTITY where JOB_ID = ?1 and ENTITY_NAME IN ?2 and CREATED_DATETIME is not null", nativeQuery = true)
    List<MigEntityUser> findByJobIdAndByEntityNameIn(Integer jobid, List<String> entityNames);

    @Query(value = "SELECT * from MIG_ENTITY where JOB_ID = ?1 and ENTITY_NAME = ?2 ", nativeQuery = true)
    List<MigEntityUser> findByJobIdAndByEntityNameEmail(Integer jobid, String entityName);

}
