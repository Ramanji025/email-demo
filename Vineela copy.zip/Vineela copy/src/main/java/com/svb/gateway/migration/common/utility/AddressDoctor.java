package com.svb.gateway.migration.common.utility;

import com.svb.gateway.migration.beneficiaries.service.EntityWrapper;
import com.svb.gateway.migration.client.model.Cifs;
import com.svb.gateway.migration.common.constants.MigrationConstants;
import com.svb.gateway.migration.common.logging.Message;
import com.svb.gateway.migration.common.model.AddressRequest;
import com.svb.gateway.migration.common.model.AddressResponse;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.RestTemplate;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

import static com.svb.gateway.migration.common.constants.MigrationConstants.STATUS_FAILURE;

@Log4j2
@Component
public class AddressDoctor {

    public static final String ADDRESS_DOCTOR = "Address Doctor: ";
    @Autowired
    RestTemplate restTemplate;

    @Value(value ="${mig.addressDoctor.url}")
    String addressDoctorUrl;

    @Value(value ="${addressDoctor.allowed.country.list}")
    private String allowedCountryList;

    public AddressResponse validateAddress(String country, String completeAddress, EntityWrapper entityWrapper) {
        ResponseEntity<AddressResponse> addressResponseEntity = null;

        AddressResponse addressResponse=new AddressResponse();

        if(isAllowed(country)){
            AddressRequest addressRequest = new AddressRequest();
            addressRequest.setOrignlcompleteaddr(completeAddress);
            addressRequest.setOrignlcntrycd(country);
            addressRequest.setOrignladdrln1("");
            addressRequest.setOrignladdrln2("");
            addressRequest.setOrignladdrln3("");
            addressRequest.setOrignlcitynm("");
            addressRequest.setOrignlstatecd("");
            addressRequest.setOrignlzipcd("");

            HttpHeaders headers = new HttpHeaders();
            headers.add(com.svb.gateway.migration.common.constants.MigrationConstants.CONTENT_TYPE, MigrationConstants.APPLICATION_HEADER_JSON);

            HttpEntity<AddressRequest> requestEntity = new HttpEntity<>(addressRequest, headers);

            restTemplate = new RestTemplate();

            try {
                addressResponseEntity = restTemplate.exchange(addressDoctorUrl, HttpMethod.POST, requestEntity, AddressResponse.class);
                if (addressResponseEntity.getStatusCode().equals(HttpStatus.OK)) {
                    addressResponse = addressResponseEntity.getBody();
                } else {
                    addressResponse.setValidationdesc(ADDRESS_DOCTOR+addressResponseEntity.getBody().toString());
                }
            }
            catch(HttpServerErrorException e){
                addressResponse.setValidationdesc(ADDRESS_DOCTOR+e.getMessage());
                entityWrapper.addUnexpectedError(ADDRESS_DOCTOR,e.getMessage());
            }
        }

        return addressResponse;
    }

    private boolean isAllowed(String country){
        Set<String> convertedCountriesList= new HashSet<String>(Arrays.asList(allowedCountryList.split(",")));
        return convertedCountriesList.contains(country);
    }

}
