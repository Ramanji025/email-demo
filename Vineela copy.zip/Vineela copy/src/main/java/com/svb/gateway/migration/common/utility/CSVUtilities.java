package com.svb.gateway.migration.common.utility;

import com.opencsv.CSVReader;
import com.opencsv.exceptions.CsvException;
import org.springframework.web.multipart.MultipartFile;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.List;

public class CSVUtilities {

    @SuppressWarnings("unchecked")
    public static List<String[]> csvtoBeans(final MultipartFile file) throws IOException, CsvException {
        try (CSVReader csvReader = new CSVReader(new BufferedReader(new InputStreamReader(file.getInputStream())))){
            return csvReader.readAll();
        }//  readers closed automatically
    }
}
