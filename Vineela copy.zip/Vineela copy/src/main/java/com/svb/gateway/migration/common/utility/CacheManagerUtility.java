package com.svb.gateway.migration.common.utility;

import com.svb.gateway.migration.common.exception.ServiceException;
import com.svb.gateway.migration.common.model.OauthResponse;
import com.svb.gateway.migration.common.repository.GatewayOAuthRepository;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cache.Cache;
import org.springframework.cache.CacheManager;
import org.springframework.stereotype.Component;

import javax.validation.constraints.NotNull;
import java.util.Objects;

@Component
@Slf4j
public class CacheManagerUtility {

    @Value("${oAuth.cache.name}")
    private String authCacheName;
    @Autowired
    private GatewayOAuthRepository authRepository;

    @Autowired
    private CacheManager cacheManager;

    public String getValueOnlyString(@NotNull final String cacheName, @NotNull final String key) {
        Cache cache = cacheManager.getCache(cacheName);
        return cache.get(key, String.class);
    }

    public boolean put(@NotNull final String cacheName, @NotNull final Object key, final Object value) {
        try {
            Cache cache = cacheManager.getCache(cacheName);
            cache.put(key, value);
            return true;
        } catch (Exception e) {
            log.info(e.getMessage());
            return false;
        }
    }

    public String getOauthToken() throws ServiceException {
        Cache cache = cacheManager.getCache(authCacheName);
        OauthResponse token = cache.get(MigrationConstants.TOKEN, OauthResponse.class);
        if (Objects.nonNull(token)) {
            return token.getAccess_token();
        } else {
            OauthResponse oauthResponse = authRepository.getUserAccessToken();
            cache.put(MigrationConstants.TOKEN, oauthResponse);
            return oauthResponse.getAccess_token();
        }
    }
}
