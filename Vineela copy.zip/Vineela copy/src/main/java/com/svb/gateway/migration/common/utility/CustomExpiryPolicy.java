package com.svb.gateway.migration.common.utility;

import com.svb.gateway.migration.common.model.OauthResponse;
import org.ehcache.expiry.ExpiryPolicy;

import java.time.Duration;
import java.util.function.Supplier;

public class CustomExpiryPolicy implements ExpiryPolicy<String, OauthResponse> {

    @Override
    public Duration getExpiryForCreation(String s, OauthResponse oauthResponse) {
       return Duration.ofSeconds(Long.parseLong(oauthResponse.getExpires_in()) - 10);
    }

    @Override
    public Duration getExpiryForAccess(String s, Supplier<? extends OauthResponse> supplier) {
        return null;
    }

    @Override
    public Duration getExpiryForUpdate(String s, Supplier<? extends OauthResponse> supplier, OauthResponse oauthResponse) {
        return null;
    }
}
