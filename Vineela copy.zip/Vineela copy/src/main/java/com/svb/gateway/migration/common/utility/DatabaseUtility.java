package com.svb.gateway.migration.common.utility;

import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * This utility is used to return null values for operations such as
 * rs.getLong(columnLabel) etc as this would return the default primitive value if value in DB is null
 */
public class DatabaseUtility {

    public static Integer getInteger(ResultSet rs, String columnLabel) throws SQLException {
        Integer i = rs.getInt(columnLabel);
        return rs.wasNull() ? null : i;
    }

    public static Long getLong(ResultSet rs, String columnLabel) throws SQLException {
        Long l = rs.getLong(columnLabel);
        return rs.wasNull() ? null : l;
    }
}
