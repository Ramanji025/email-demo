package com.svb.gateway.migration.common.utility;

import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.time.temporal.TemporalAdjusters;
import java.util.Date;
import java.util.Locale;

public class DateUtility {

    public static LocalDateTime getNow() {
        return LocalDateTime.now();
    }

    public static int getRecurringByEndDateAndFrequency(LocalDate date, Integer frequencyId, Integer dayOfTheWeek) {

        long occurences = 0;
        if(date==null){
            return (int)occurences;
        }

        switch (frequencyId) {
            case 1:
                long days = getDays(date);
                occurences = days - 2 * (days/7);
                break;
            case 2:
                occurences = getWeekDiff(date, dayOfTheWeek);
                break;
            case 3:
                occurences = getWeekDiff(date, dayOfTheWeek)/2;
                break;
            case 4:
                occurences = getMonthsDiff(date);
                break;
        }

        return (int)occurences;
    }

    public static int getRecurringByEndDateAndFrequency(LocalDate paymentDate, LocalDate endDate, Character frequency) {

        long occurences = 0;
        if(paymentDate==null){
            return (int)occurences;
        }
        switch (frequency) {
            case 'W':
                occurences = getWeekDiff(paymentDate, endDate, paymentDate.getDayOfWeek().getValue());
                break;
            case 'B':
                occurences = getWeekDiff(paymentDate, endDate, paymentDate.getDayOfWeek().getValue())/2;
                break;
            case 'M':
                occurences = getMonthsDiff(paymentDate, endDate);
                break;
            case 'Q':
                occurences = getMonthsDiff(paymentDate, endDate)/3;
                break;
            case 'T':
                occurences = getMonthsDiff(paymentDate, endDate)/2;
                break;
        }

        return (int)occurences;
    }

    public static long getWeekDiff(LocalDate date, int dayOfTheWeek) {
        return getWeekDiff(LocalDate.now(), date, dayOfTheWeek);
    }

    public static long getWeekDiff(LocalDate fromDate, LocalDate endDate, int dayOfTheWeek) {
        long count = 0;
        LocalDate weekday = fromDate.with(TemporalAdjusters.nextOrSame(getDayOftheWeek(dayOfTheWeek)));
        while(weekday.isBefore(endDate)) {
            count++;
            weekday = weekday.plusWeeks(1);
        }
        return count;
    }

    public static long getDays(LocalDate date) {
        LocalDateTime input = LocalDateTime.of(date.getYear(), date.getMonth(), date.getDayOfMonth(), 0, 0);
        return Math.abs(ChronoUnit.DAYS.between(getNow(), input));
    }

    public static long getMonthsDiff(LocalDate date) {
        return getMonthsDiff(LocalDate.now(), date);
    }

    public static long getMonthsDiff(LocalDate fromDate, LocalDate endDate) {
        LocalDateTime input = LocalDateTime.of(endDate.getYear(), endDate.getMonth(), endDate.getDayOfMonth(), 0, 0);
        return Math.abs(ChronoUnit.MONTHS.between(fromDate, input));
    }

    private static DayOfWeek getDayOftheWeek(int weekday) {

        switch (weekday) {
            case 1:
                return DayOfWeek.SUNDAY;
            case 2:
                return DayOfWeek.MONDAY;
            case 3:
                return DayOfWeek.TUESDAY;
            case 4:
                return DayOfWeek.WEDNESDAY;
            case 5:
                return DayOfWeek.THURSDAY;
            case 6:
                return DayOfWeek.FRIDAY;
            case 7:
                return DayOfWeek.SATURDAY;
        }
        return null;
    }
    public static String getFileNameDateFormat(){
        DateTimeFormatter formatter=DateTimeFormatter.ofPattern("MMddyyyy_HH_mm_ss_z")
                .withLocale(Locale.US);
        ZonedDateTime dateTime=ZonedDateTime.now(ZoneId.of("America/Los_Angeles"));
        return formatter.format(dateTime);

    }

    public static String getDateString(Date date) {
        String pattern = "MM/dd/yyyy HH:mm:ss a";
        DateFormat df = new SimpleDateFormat(pattern);
        return df.format(date);
    }

    public static String getDateStringddMMMYYPattern(Date date) {
        String pattern = "dd/MMM/yy";
        DateFormat df = new SimpleDateFormat(pattern);
        return df.format(date);
    }

    public static LocalDateTime getTimeZoneDate(String timeZone){

        ZoneId zone = ZoneId.of(timeZone);
        LocalDateTime localDateTime=LocalDateTime.now(zone);
        return localDateTime;
    }

    public static java.sql.Date getDateFromLong(Long ts) {
        java.sql.Date date = new java.sql.Date(ts);
        return date;
    }

    public static Timestamp getCurrentTimestamp() {
        Date date = new Date();
        return  new Timestamp(date.getTime());
    }
}
