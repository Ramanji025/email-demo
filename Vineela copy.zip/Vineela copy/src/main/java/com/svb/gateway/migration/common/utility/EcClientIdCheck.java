package com.svb.gateway.migration.common.utility;

import com.svb.gateway.migration.common.exception.ServiceException;
import com.svb.gateway.migration.common.logging.Message;
import lombok.extern.log4j.Log4j2;

import java.util.regex.Matcher;
import java.util.regex.Pattern;
@Log4j2
public class EcClientIdCheck {

    public static void ecClientIdFormatCheck(String migratingClientId) throws ServiceException {

        if (migratingClientId == null) {
            log.error(Message.create().descr("Client ID passed is null").toString());
            throw new ServiceException("Olb Id not set", "Olb Id not passed");
        }

        String regex = "[a-zA-Z]{4}[0-9]{4}";
        Pattern p = Pattern.compile(regex);
        Matcher m = p.matcher(migratingClientId);

        if (!m.matches()) {
            log.error(Message.create().descr("Client ID has Invalid Format").clientId(migratingClientId).toString());
            throw new ServiceException("Client Id not proper", "Client id has Invalid Format");
        }
    }
}
