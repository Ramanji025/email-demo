package com.svb.gateway.migration.common.utility;

import org.apache.commons.validator.routines.EmailValidator;

public class EmailCheck {
	
	public static boolean isEmailValid(String email)
	{
		if(email == null) return false;
		
		return EmailValidator.getInstance().isValid(email);
	}
}
