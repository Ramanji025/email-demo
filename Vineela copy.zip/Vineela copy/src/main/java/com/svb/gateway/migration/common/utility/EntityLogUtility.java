package com.svb.gateway.migration.common.utility;


import com.svb.gateway.migration.common.model.EntityRecordCount;
import com.svb.gateway.migration.common.repository.EntityLoggingMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class EntityLogUtility {

    @Autowired
    EntityLoggingMapper entityLoggingMapper;

    private static final Logger logger = LoggerFactory.getLogger(EntityLogUtility.class);

    public void saveEntityCountAndTimeLog(EntityRecordCount entityRecordCount) {
        entityLoggingMapper.insertCountAndTime(entityRecordCount);
        logger.info("Count and time updated for : "+entityRecordCount.getENTITY_NAME());
    }
}