package com.svb.gateway.migration.common.utility;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public enum FrequencyPeriod {
    BI_WEEKLY("Bi-weekly",'B', 3 ),
    MONTHLY("Monthly", 'M', 4),
    QUARTERLY("Quarterly", 'Q', 5) ,
    ALTERNATE_MONTH("Every Other Month", 'T', 9),
    WEEKLY("Weekly", 'W', 2);

    private String description;
    private Integer ochCode;
    private char code;

    FrequencyPeriod(String desc, char code, Integer ochCode){
        this.description=desc;
        this.code=code;
        this.ochCode=ochCode;
    }

    public static FrequencyPeriod fromValue(Character c){
        for(FrequencyPeriod fp:FrequencyPeriod.values()){
            if(c==fp.code){
                return fp;
            }
        }
        return null;
    }

    public Integer getOchCode(){
        return ochCode;
    }

    public Character getCode(){
        return code;
    }

    public static List<Character> validFrequencies(){
        List<Character> frequencies=new ArrayList<>();
        Arrays.stream(FrequencyPeriod.values()).forEach(f->frequencies.add(f.code));
        return frequencies;
    }
}
