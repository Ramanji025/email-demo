package com.svb.gateway.migration.common.utility;

import com.svb.gateway.migration.common.exception.ServiceException;
import com.svb.gateway.migration.job.repository.MigJobRepository;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class JobIdCheck {

    @Autowired
    private MigJobRepository migJobRepository;

    public static void jobIdFormatCheck(String jobId) throws ServiceException {

        if (StringUtils.isBlank(jobId)) {
            throw new ServiceException("Job Id not set", "Job id not passed");
        }

    }

    public void checkJobExistence(String jobId) throws ServiceException{

        if (!migJobRepository.existsMigJobByJobId(Long.parseLong(jobId.trim()))) {
            throw new ServiceException("Job is not available","Job is not available");
        }
    }
}
