package com.svb.gateway.migration.common.utility;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;

public enum JobStatusEnum {
    CREATED("Migration.Job.Created"),
    AWAITING_EXTRACTION("Migration.Job.AwaitingExtraction"),
    EXTRACTING("Migration.Job.Extracting"),
    AWAITING_MIGRATION("Migration.Job.AwaitingMigration"),
    MIGRATING("Migration.Job.Migrating"),
    COMPLETE("Migration.Job.Complete"),
    CANCELLED("Migration.Job.Cancelled"),
    EXTRACTION_INPROCESS("Migration.Job.ExtractionInProgress"),
    EXTRACTION_COMPLETED("Migration.Job.ExtractionCompleted"),
    MIGRATION_COMPLETED("Migration.Job.MigrationCompleted"),
    MIGRATION_INPROCESS("Migration.Job.MigrationInProgress");

    private String value;

    JobStatusEnum(String value) {
        this.value = value;
    }

    @Override
    @JsonValue
    public String toString() {
        return String.valueOf(value);
    }

    @JsonCreator
    public static JobStatusEnum fromValue(String text) {
        for (JobStatusEnum b : JobStatusEnum.values()) {
            if (String.valueOf(b.value).equals(text)) {
                return b;
            }
        }
        return null;
    }
}
