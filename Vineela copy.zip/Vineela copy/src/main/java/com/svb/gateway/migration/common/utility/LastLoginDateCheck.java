package com.svb.gateway.migration.common.utility;

import com.svb.gateway.migration.common.constants.MigrationConstants;

import java.time.LocalDate;

public class LastLoginDateCheck {

    public static boolean isInvalidLastLoginDate(LocalDate lastLoginDate, boolean isPrimaryUser, Integer lastLoginMonthThreshold){
        boolean isInvalid = false;
        if(null == lastLoginDate){
            isInvalid = true;
            return isInvalid;
        }
        if(lastLoginDate.compareTo(LocalDate.now().minusMonths(lastLoginMonthThreshold))>= MigrationConstants.COUNT_ZERO || isPrimaryUser){
            isInvalid = false;
        }
        else{
            isInvalid = true;
        }
        return isInvalid;
    }
}
