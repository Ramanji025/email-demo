package com.svb.gateway.migration.common.utility;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;

public enum
MigrationErrorCodeEnum {
    // Bad Request codes
    MIGRATION_SAMPLE_CODE("MIGRATION.Unsupported.Type"),
    MIGRATION_DUPLICATE_ENTITY("MIGRATION.Duplicate.Entity"),
    MIGRATION_ROLLBACK_INVALID_CLIENT_ID("MIGRATION.Rollback.Invalid.ClientId"),

    // Service
    MIGRATION_UNEXPECTED_ERROR("MIGRATION.UnexpectedError"),
    MIGRATION_CSV_FILE_PARSING_ERROR("MIGRATION.Csv.FileParsingError"),
    MIGRATION_INVALID_EC_MIGRATION_STATUS("MIGRATION.Invalid.EC.Migration.Status"),

    CREATE_CLIENT_FAILED_FINACLE("ADMINEXT.INTERNALERROR.CLIENT_CREATE_FINACLE"),
    CREATE_CLIENT_FAILED_DB("ADMINEXT_INERNALERROR_CLIENT_CREATE_DB"),
    CREATE_CLIENT_FAILED_CLIENT_EXIST_DB("ADMINEXT_INERNALERROR_CLIENT_CREATE_DB_CLIENT_EXIST"),
    CREATE_CLIENT_FAILED("ADMINEXT.INTERNALERROR.CLIENT_CREATE"),
    CREATE_CLIENT_ROLLBACK_FAILED("ADMINEXT.INTERNALERROR.CLIENT_CREATE_ROLLBACK"),
    CREATE_CLIENT_INVALID_CLIENT_DATA("ADMINEXT.BADREQUEST.INVALID_CLIENT_DATA"),
    CREATE_CLIENT_INVALID_CIF_DATA("ADMINEXT.BADREQUEST.INVALID_CIF_DATA"),
    CREATE_CLIENT_INVALID_PHONE_DATA("ADMINEXT.BADREQUEST.INVALID_PHONE_DATA"),
    CREATE_CLIENT_INVALID_USER_DATA("ADMINEXT.BADREQUEST.INVALID_USER_DATA"),
    CREATE_CLIENT_SERVICE_FAILED("ADMINEXT.INTERNALERROR.CLIENT_CREATE_SERVICE"),
    ROLLBACK_CLIENT_CREATE_FAILED("ADMINEXT.INTERNALERROR.ROLLBACK_CLIENT_CREATE_SERVICE"),

    //User Service Enums
    MIGRATION_CREATE_CLIENT_USER_INVALID_REQ("Olb Id, Cif, Client loginId are mandatory fields"),
    MIGRATION_CREATE_CLIENT_USER_INVALID_DETAILS("User First & Last name, email, country code, contact label, access, role are mandatory fields"),
    MIGRATION_CREATE_CLIENT_USER_MISMATCH_DETAILS("Olb ID is not matching with CIF or Client login name"),
    MIGRATION_CREATE_CLIENT_USER_FAILED("Admext Create Client user failed"),
    MIGRATION_CREATE_CLIENT_USER_UNKNOWN_USER_TYPE("Client user cannot be created - unknown user type"),


    SSO_USER_ACCESSTOKEN_REQUEST_FAILED("ADMINEXT.FNCL_VTUSER_ACCESSTOKEN_REQUEST_FAILED")

            ;

    private String value;

    MigrationErrorCodeEnum(String value) {
        this.value = value;
    }

    @Override
    @JsonValue
    public String toString() {
        return String.valueOf(value);
    }

    @JsonCreator
    public static MigrationErrorCodeEnum fromValue(String text) {
        for (MigrationErrorCodeEnum migrationErrorCodeEnum : values()) {
            if (String.valueOf(migrationErrorCodeEnum.value).equals(text)) {
                return migrationErrorCodeEnum;
            }
        }
        return null;
    }
}
