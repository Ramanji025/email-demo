package com.svb.gateway.migration.common.utility;

import lombok.Getter;
import lombok.Setter;

import java.sql.Timestamp;

import static com.svb.gateway.migration.common.constants.MigrationConstants.STATUS_SUCCESS;

public class MigrationQueries {
	
	public static final String INSERT_CLIENT_INFO = "insert into MIG_STG_CLIENT(OLB_CLIENT_ID, PRIMARY_CIF_CBS, PRIMARY_CIF_UBS, CLIENT_NAME, EC_CLIENT_ID_NUM, CLIENT_TYPE_ID, DUAL_ADMIN_APPROVE, STATUS_FLG, JOB_ID, US_BILL_ACC_NUM, SELF_CRED_RESET_OPTED, "
			+ " US_BILL_ACC_MANDATORY, SSN_TXID, ADNL_SSN_TXID, CREATED_BY, CREATED_DT) "
			+ " values (:olbClientId, :primaryCIFCBS, :primaryCIFUBS, :clientName, :ecClientID, :clientTypeId, :dualAdminApprove, :status, :jobId, :usBillAccountNum, :selfCredentialResetOpted, :usBillingAccMandatory, "
			+ " :ssnTxid, :addnSsnTxid, :createdBy, :createdDate)";
	
	
	public static final String SELECT_CLIENT_INFO = "SELECT {0, number, #} AS JOB_ID, CBS.ADDR_1 AS CLIENT_NAME, L.LOGIN_NAME AS CLIENT_ID, L.ID as CLIENT_ID_NUM, C.STATUS_FLG, CBS.CUST_NUM AS PRIMARY_CIF_CBS, CBS.CUST_NUM_UBS AS PRIMARY_CIF_UBS, C.CLIENT_TYPE_ID, C.CREATED_BY, "
			+ "C.APPR_FOR_NEW_USR_ACTIVATION AS DUAL_ADMIN_APPROVE, A.ACC_NUM AS US_BIL_ACC_NUM, C.SELF_CRED_RESET_OPTED, C.PRIMARY_AFFL, C.SERVICE_CATEGORY, C.US_BIL_ACC_MAN, C.SSN_TXID, C.ADNL_SSN_TXID, C.CREATED_DT  "
			+ "FROM SVBCOM_CLIENT_CIF CIF, CLIENT C, CLIENT_CBS CBS, LOGIN_INFO L, ACCOUNT A "
			+ "WHERE CIF.CUST_NUM = CBS.CUST_NUM AND C.CLIENT_ID = CIF.CLIENT_ID AND L.ID = C.CLIENT_ID "
			+ "AND C.US_BIL_ACC_ID  = A.ACCOUNT_IDENTIFIER(+)"
			+ "AND CIF.PRM_CIF_FLG = 1 AND (L.LOGIN_NAME,0) IN ({1})";
	
	public static final String DELETE_CLIENT_INFO = "delete from GWDMG.MIG_STG_CLIENT where (OLB_CLIENT_ID,0) in ({0})";
	
	public static final String SELECT_CLIENT_CIF_LINK_INFO = "SELECT {0, number, #} AS JOB_ID, L.LOGIN_NAME AS CLIENT_ID, CBS.CUST_NUM AS CIF_CBS, CBS.CUST_NUM_UBS AS CIF_UBS, C.STATUS_FLG AS STATUS, C.CREATED_BY, C.CREATED_DT "
			+ "FROM SVBCOM_CLIENT_CIF CIF, CLIENT C, CLIENT_CBS CBS, LOGIN_INFO L "
			+ "WHERE CIF.CUST_NUM = CBS.CUST_NUM AND C.CLIENT_ID = CIF.CLIENT_ID AND L.ID = C.CLIENT_ID AND (L.LOGIN_NAME,0) IN ({1})";
	
	public static final String INSERT_CLIENT_CIF_LINK = "Insert into GWDMG.MIG_STG_CIF_LINKAGE (OLB_CLIENT_ID, CIF_UBS, CIF_CBS, DEL_FLAG, STATUS, JOB_ID, REMARKS, CREATED_BY, CREATED_DT) "
			+ "values (:olbClientId, :cifUbs, :cifCbs, :delFlag, :status, :jobId, :remarks, :createdBy, :createdDate )";
	
	public static final String DELETE_CIF_CLIENT_LINK ="delete from GWDMG.MIG_STG_CIF_LINKAGE where (OLB_CLIENT_ID,0) in ({0})";
	
	public static final String SELECT_USER_INFO = "select {0, number, #} as jobId, l.login_name as USER_LOGIN_ID, L.ID as USER_ID_NUM, c.login_name as OLB_CLIENT_ID, u.first_NM as FIRST_NAME,"
			+ " u.last_nm as LAST_NAME, u.email as EMAIL, u.cnt_ph as CONTACT_PHONE_NUMBER, u.country_code as COUNTRY_CODE, u.grp_id as USER_ROLE, "
			+ " u.primary_admin as PRIMARY_USER, u.cnt_person as PRIMARY_CONTACT, u.lifetime_status_code as STATUS, u.fax_num as FAX_NUM, u.secondary_phone as SECONDARY_PHONE, "
			+ " u.created_by_user_id as CREATED_BY, u.created_date as CREATED_DT, p.last_login as LAST_LOGGEDIN_DATE ,"
			+ "       (case when exists (select 1 from function_perm p where p.user_id = u.user_id and p.perm_id = 214 )"
			+ "             then (case when exists (select 1 from function_perm p where p.user_id = u.user_id and p.perm_id not in (214,264,198,208))"
			+ "                then ''COMBO_CARD_USER''"
			+ "                else ''CARD_HOLDER_ONLY_USER''"
			+ "            end)"
			+ "        else ''USER_WO_CARD''"
			+ "    end) as TYPE_OF_USER"
			+ " from login_info l, user_info u, login_info c, "
			+ " login_profile p where l.id = u.user_id and c.id = u.client_id and (u.grp_id = 6 or u.grp_id =7) and l.id = p.id and (c.login_name,0) in ({1})";

	public static final String INSERT_USER_INFO = "insert into GWDMG.MIG_STG_USER" +
			" (USER_LOGIN_ID, EC_USER_ID_NUM, OLB_CLIENT_ID, FIRST_NM, LAST_NM, EMAIL, COUNTRY_CODE, CNT_PH, USER_ROLE, USER_ACCESS, STATUS, JOB_ID, CREATED_BY, CREATED_DT, PRIMARY_USER, LAST_LOGGEDIN_DATE, TYPE_OF_USER, ISPRIMARYCONTACT) " +
			" values (:userLoginId, :ecUserID, :olbClientId, :firstName, :lastName, :email, :countryCode, :contactPhoneNo, :userRole, :userAccess, :status, :jobId, :createdBy, :createdDate, :primaryUser, :lastLoggedInDate, :typeOfUser, :primaryContact)";

	public static final String SELECT_USER_PHONE_INFO = "select {0, number, #} AS JOB_ID, l.login_name as USER_LOGIN_ID, c.login_name as OLB_CLIENT_ID, p.phone_name as PHONE_NAME, p.EXTENSION as EXTENSION, p.COUNTRY_CODE as COUNTRY_CODE, p.phone_no as PHONE_NUM"
			+ " from econnect.user_secondary_auth_devices p, econnect.login_info l, econnect.login_info c, econnect.user_info u"
			+ " where l.id = u.user_id and c.id = u.client_id and (u.grp_id = 6 or u.grp_id =7) and p.user_id = l.id and c.id = l.parent_id and (c.login_name,0) in ({1}) and p.activation_status=0";

	public static final String INSERT_USER_PHONE_INFO = "insert into GWDMG.MIG_STG_USER_PHONE_NUMBERS (USER_LOGIN_ID, OLB_CLIENT_ID, PHONE_NAME, EXTENSION, COUNTRY_CODE, PHONE_NUM, JOB_ID, CREATED_BY, CREATED_DT) values (:userId, :clientId, :phoneName, :extension, :countryCode, :phoneNumber, :jobId, :createdBy, :createdDate)";

	public static final String DELETE_USER_PHONE_INFO ="delete from GWDMG.MIG_STG_USER_PHONE_NUMBERS where (OLB_CLIENT_ID,0) in ({0})";

	public static final String SELECT_TRANSFER_INFO = "select {0, number, #} AS JOB_ID, t.TRN_ID, t.TRN_AMT, t.TRN_DT, t.DESCR, t.TRN_STAT, t.FR_ACC_NUM, t.TO_ACC_NUM, t.TRANSFER_DATE, a.CURRENCY_CODE, l.login_name as USER_LOGIN_ID, c.login_name as" 
			+ " OLB_CLIENT_ID, t.SCHEDULE_DETAILS_ID, t.OCCURRENCE_ID, sh.SCHEDULE_ID, sh.FREQUENCY_ID, sh.CREATED_DATE, sh.START_DATE, sh.DAY_OF_THE_WEEK, sh.SCHEDULE_END_TYPE_ID, sh.SCHEDULE_END_DATE, " 
			+ " sh.SCHEDULE_OCCURANCES, sh.STATUS, sh.DAY_OF_MONTH, so.OCCURRENCE_DATE, so.NTH_OCCURRENCE from SCHEDULE_HEADER_INFO sh, SCHEDULE_OCCURRENCES so, TRANSACTION_REQ t " 
			+ " join account a on t.fr_account_identifier=a.account_identifier , login_info l,  user_info u, login_info c " 
			+ " where c.parent_id = 0 and c.id = t.client_id and l.id = t.user_id and l.id = u.user_id and c.id = u.client_id and (u.grp_id = 6 or u.grp_id =7) and " 
			+ " t.OCCURRENCE_ID = so.OCCURRENCE_ID and so.SCHEDULE_ID = sh.SCHEDULE_ID and t.TRN_STAT = 0 and t.SCHEDULE_DETAILS_ID  is not null and t.OCCURRENCE_ID is not null and sh.STATUS = 1 " 
			+ " and so.OCCURRENCE_DATE > sysdate and t.FR_APPL_NUM = 20 and t.TO_APPL_NUM = 20 and (c.login_name,0) in ({1})" 
			+ " union all" 
			+ " select {0, number, #} as JOB_ID, t.TRN_ID, t.TRN_AMT, t.TRN_DT, t.DESCR, t.TRN_STAT, t.FR_ACC_NUM, t.TO_ACC_NUM, t.TRANSFER_DATE, a.CURRENCY_CODE, l.login_name as USER_LOGIN_ID, c.login_name as " 
			+ " OLB_CLIENT_ID, null as SCHEDULE_DETAILS_ID, null as OCCURRENCE_ID, null as SCHEDULE_ID, null as FREQUENCY_ID, null as CREATED_DATE, null as START_DATE, null as DAY_OF_THE_WEEK," 
			+ " null as SCHEDULE_END_TYPE_ID, null as SCHEDULE_END_DATE, null as SCHEDULE_OCCURANCES, null as STATUS, null as DAY_OF_MONTH, null as OCCURRENCE_DATE, null as NTH_OCCURRENCE " 
			+ " from TRANSACTION_REQ t join account a on t.fr_account_identifier=a.account_identifier , login_info l,  user_info u, login_info c where t.TRN_STAT = 0 and " 
			+ " t.SCHEDULE_DETAILS_ID  is null and t.OCCURRENCE_ID is null AND c.parent_id = 0 and c.id = t.client_id and l.id = t.user_id and l.id = u.user_id and c.id = u.client_id and " 
			+ " (u.grp_id = 6 or u.grp_id =7) and t.FR_APPL_NUM = 20 and t.TO_APPL_NUM = 20 and (c.login_name,0) in ({1})";
	
	public static final String SELECT_WIRE_TEMPLATE_INFO_ONE ="select * from (select {0, number, #} AS JOB_ID, w.TEMPLATE_ID, c.login_name as OLB_CLIENT_ID, w.TEMPLATE_NAME, w.PAYMENT_TYPE, w.ENTRYOP_NAME, w.ENTRY_DATE, " 
			+ " w.APPROVE_LVL1_DATE, w.CURRENT_STATE, w.APPROVE_LVL1OP_NAME, w.NEXT_STATE, w.APPROVE_LVL2OP_NAME, w.CANCELOP_NAME, w.CURRENCY_CODE, w.FOREX_AMOUNT, " 
			+ " w.BENEFICIARY_BANK_IDENTIFIER, w.APPROVE_LVL2_DATE, w.BENEFICIARY_ACCOUNT, w.CANCEL_DATE, w.BENEFICIARY_NAME, w.BENEFICIARY_ADDRESS_1, w.BENEFICIARY_ADDRESS_2, " 
			+ " w.BENEFICIARY_ADDRESS_3, w.BENEFICIARY_INSTRUCTIONS, w.FURTHER_APPROVALS, w.TOTAL_APPROVALS, w.BENEFICIARY_BANK_NAME, w.BENEFICIARY_BANK_ADDRESS, w.BENEFICIARY_BANK_CITY, " 
			+ " w.BENEFICIARY_BANK_CITY_ZIP, w.BENEFICIARY_BANK_STATE, w.BENEFICIARY_BANK_COUNTRY, l.login_name as USER_LOGIN_ID, w.APPROVE_LVL1OP_ID, w.APPROVE_LVL2OP_ID, w.CANCELOP_ID, " 
			+ " w.BANK_TO_BANK_INSTRUCTIONS, w.BENEFICIARY_BANK_SEARCH_MODE, w.IS_TEMPLATE_IMPORTED, a.acc_num, w.ENTERED_AMT_IN_DEBIT_CURRENCY, w.DEBITING_AMOUNT, " 
			+ " w.DEBITING_CURRENCY_CODE, w.IS_DELETED, w.DELETEOP_NAME, w.DELETE_DATE, w.DELETEOP_ID, w.TEMPLATE_CODE, w.IMPORT_FILE_INFO_ID, w.CHARGE_CODE_ID, " 
			+ " w.BENEFICIARY_BANK_REGION, w.INTERMEDIARY_ID, w.INTERMEDIARY_NAME, w.INTERMEDIARY_ADDRESS, w.IS_BENEFICIARY_ACC_SVB, w.IS_BENEFICIARY_ACC_SVB_DDA, w.PAYMENT_URGENCY, " 
			+ " w.ROUTING_CODE, ROW_NUMBER() over (partition by c.login_name , w.PAYMENT_TYPE , w.BENEFICIARY_BANK_IDENTIFIER, w.BENEFICIARY_ACCOUNT order by w.entry_date desc, " 
			+ " w.template_id desc) as r1 from WIRE_TEMPLATE w, login_info l, login_info c, user_info u, wire_outgoing wo, account a where l.id = u.user_id and c.id = u.client_id and (u.grp_id = 6 " 
			+ " or u.grp_id = 7) and w.current_state = 5 AND a.account_identifier = w.account_identifier AND c.parent_id = 0 and l.id = w.entryop_id and c.id = w.client_id and w.IS_DELETED <> 1 and (c.login_name,0) in ({1}) and " 
			+ " wo.ENTRY_DATE >= (SYSDATE - INTERVAL ''{2}'' MONTH) and w.template_id = wo.template_id and ((w.PAYMENT_TYPE =''DOM'' AND (REGEXP_LIKE(w.BENEFICIARY_BANK_IDENTIFIER, " 
			+ " ''^[0-9]{8}$'') OR REGEXP_LIKE(w.BENEFICIARY_BANK_IDENTIFIER, ''^[0-9]{9}$'') OR (REGEXP_LIKE(w.BENEFICIARY_BANK_IDENTIFIER, ''^[a-zA-Z0-9]'') and " 
			+ " (length(w.BENEFICIARY_BANK_IDENTIFIER) between 8 and 11)))) OR (w.PAYMENT_TYPE in (''FX'',''INTL'') AND ((REGEXP_LIKE(w.BENEFICIARY_BANK_IDENTIFIER, ''^[0-9]'') OR " 
			+ " REGEXP_LIKE(w.BENEFICIARY_BANK_IDENTIFIER, ''^[a-zA-Z0-9]'')))))) where r1=1";
	
	public static final String SELECT_WIRE_TEMPLATE_INFO_TWO ="select * from (select {0, number, #} AS JOB_ID, w.TEMPLATE_ID, c.login_name as OLB_CLIENT_ID, w.TEMPLATE_NAME, w.PAYMENT_TYPE, w.ENTRYOP_NAME, w.ENTRY_DATE, "
			+ " w.APPROVE_LVL1_DATE, w.CURRENT_STATE, w.APPROVE_LVL1OP_NAME, w.NEXT_STATE, w.APPROVE_LVL2OP_NAME, w.CANCELOP_NAME, w.CURRENCY_CODE, w.FOREX_AMOUNT, "
			+ " w.BENEFICIARY_BANK_IDENTIFIER, w.APPROVE_LVL2_DATE, w.BENEFICIARY_ACCOUNT, w.CANCEL_DATE, w.BENEFICIARY_NAME, w.BENEFICIARY_ADDRESS_1, w.BENEFICIARY_ADDRESS_2, "
			+ " w.BENEFICIARY_ADDRESS_3, w.BENEFICIARY_INSTRUCTIONS, w.FURTHER_APPROVALS, w.TOTAL_APPROVALS, w.BENEFICIARY_BANK_NAME, w.BENEFICIARY_BANK_ADDRESS, w.BENEFICIARY_BANK_CITY, "
			+ " w.BENEFICIARY_BANK_CITY_ZIP, w.BENEFICIARY_BANK_STATE, w.BENEFICIARY_BANK_COUNTRY, l.login_name as USER_LOGIN_ID, w.APPROVE_LVL1OP_ID, w.APPROVE_LVL2OP_ID, w.CANCELOP_ID, "
			+ " w.BANK_TO_BANK_INSTRUCTIONS, w.BENEFICIARY_BANK_SEARCH_MODE, w.IS_TEMPLATE_IMPORTED, a.acc_num, w.ENTERED_AMT_IN_DEBIT_CURRENCY, w.DEBITING_AMOUNT, "
			+ " w.DEBITING_CURRENCY_CODE, w.IS_DELETED, w.DELETEOP_NAME, w.DELETE_DATE, w.DELETEOP_ID, w.TEMPLATE_CODE, w.IMPORT_FILE_INFO_ID, w.CHARGE_CODE_ID, "
			+ " w.BENEFICIARY_BANK_REGION, w.INTERMEDIARY_ID, w.INTERMEDIARY_NAME, w.INTERMEDIARY_ADDRESS, w.IS_BENEFICIARY_ACC_SVB, w.IS_BENEFICIARY_ACC_SVB_DDA, w.PAYMENT_URGENCY, "
			+ " w.ROUTING_CODE, ROW_NUMBER() over (partition by c.login_name , w.PAYMENT_TYPE , w.BENEFICIARY_BANK_IDENTIFIER, w.BENEFICIARY_ACCOUNT order by w.entry_date desc, "
			+ " w.template_id desc) as r1 from WIRE_TEMPLATE w, login_info l, login_info c, user_info u, account a where l.id = u.user_id and c.id = u.client_id and (u.grp_id = 6 "
			+ " or u.grp_id = 7) and w.current_state = 5 AND a.account_identifier = w.account_identifier AND c.parent_id = 0 and l.id = w.entryop_id and c.id = w.client_id and w.IS_DELETED <> 1 and (c.login_name,0) in ({1}) and "
			+ " w.ENTRY_DATE >= (SYSDATE - INTERVAL ''{3}'' MONTH) and ((w.PAYMENT_TYPE =''DOM'' AND (REGEXP_LIKE(w.BENEFICIARY_BANK_IDENTIFIER, ''^[0-9]{8}$'') OR "
			+ " REGEXP_LIKE(w.BENEFICIARY_BANK_IDENTIFIER, ''^[0-9]{9}$'') OR (REGEXP_LIKE(w.BENEFICIARY_BANK_IDENTIFIER, ''^[a-zA-Z0-9]'') and (length(w.BENEFICIARY_BANK_IDENTIFIER) "
			+ " between 8 and 11)))) OR (w.PAYMENT_TYPE in (''FX'',''INTL'') AND ((REGEXP_LIKE(w.BENEFICIARY_BANK_IDENTIFIER, ''^[0-9]'') OR REGEXP_LIKE(w.BENEFICIARY_BANK_IDENTIFIER, "
			+ " ''^[a-zA-Z0-9]''))))) and w.template_id not in (select distinct w.template_id from wire_template w inner join wire_outgoing wo on "
			+ " w.template_id = wo.template_id)) where r1=1";
			
	public static final String INSERT_TRANSFER_INFO = "insert into MIG_STG_INTERNAL_XFER(TRN_ID, TRN_AMT, TRN_DT, DESCR, USER_LOGIN_ID, OLB_CLIENT_ID, TRN_STAT, FR_ACC_NUM, TO_ACC_NUM, TRANSFER_DATE, "
			+ " TRAN_ACT_CRN, FREQUENCY_ID, CREATED_DATE, START_DATE, DAY_OF_THE_WEEK, RECURRING_STATUS, DAY_OF_MONTH, OCCURRENCE_DATE, NTH_OCCURRENCE, SCHEDULE_DETAILS_ID, OCCURRENCE_ID, SCHEDULE_ID, "
			+ " SCHEDULE_END_TYPE_ID, SCHEDULE_END_DATE, SCHEDULE_OCCURANCES, JOB_ID, CREATED_DT, MODIFIED_DT)"
			+ " values (:trnId, :trnAmount, :trnDate, :desc, :userId, :clientId, :trnStatus, :fromAccNum, :toAccNum, :transferDate, :currencyCode, :frequencyId, :createdDate, :startDate, :dayOfTheWeek, "
			+ " :recurringStatus, :dayOfMonth, :occurenceDate, :nthOccurence, :scheduleDetailsId, :occurenceId, :scheduleId, :scheduleEndTypeId, :scheduleEndDate, :scheduleOccurences, :jobId, :createdDt, :modifiedDt)";
	 
	public static final String INSERT_WIRE_TEMPLATE_INFO = "insert into MIG_STG_WIRE_TEMPLATE(TEMPLATE_ID, OLB_CLIENT_ID, TEMPLATE_NAME, PAYMENT_TYPE, ENTRYOP_NAME, ENTRY_DATE, APPROVE_LVL1_DATE, CURRENT_STATE, APPROVE_LVL1OP_NAME, NEXT_STATE, APPROVE_LVL2OP_NAME, CANCELOP_NAME, "
			+ "CURRENCY_CODE, FOREX_AMOUNT, BENEFICIARY_BANK_IDENTIFIER, APPROVE_LVL2_DATE, BENEFICIARY_ACCOUNT, CANCEL_DATE, BENEFICIARY_NAME, BENEFICIARY_ADDRESS_1, BENEFICIARY_ADDRESS_2, "
			+ "BENEFICIARY_ADDRESS_3, BENEFICIARY_INSTRUCTIONS, FURTHER_APPROVALS, TOTAL_APPROVALS, BENEFICIARY_BANK_NAME, BENEFICIARY_BANK_ADDRESS, BENEFICIARY_BANK_CITY, BENEFICIARY_BANK_CITY_ZIP, "
			+ "BENEFICIARY_BANK_STATE, BENEFICIARY_BANK_COUNTRY, ENTRYOP_ID, APPROVE_LVL1OP_ID, APPROVE_LVL2OP_ID, CANCELOP_ID, BANK_TO_BANK_INSTRUCTIONS, BENEFICIARY_BANK_SEARCH_MODE, IS_TEMPLATE_IMPORTED, "
			+ "FROM_ACCOUNT_NUMBER, ENTERED_AMT_IN_DEBIT_CURRENCY, DEBITING_AMOUNT, DEBITING_CURRENCY_CODE, IS_DELETED, DELETEOP_NAME, DELETE_DATE, DELETEOP_ID, TEMPLATE_CODE, IMPORT_FILE_INFO_ID, "
			+ "CHARGE_CODE_ID, BENEFICIARY_BANK_REGION, INTERMEDIARY_ID, INTERMEDIARY_NAME, INTERMEDIARY_ADDRESS, IS_BENEFICIARY_ACC_SVB, IS_BENEFICIARY_ACC_SVB_DDA, PAYMENT_URGENCY, "
			+ "ROUTING_CODE, JOB_ID) VALUES (:templateId, :clientId, :templateName, :paymentType, :entryOpName, :entryDate, :approvalLvl1Date, :currentState, :approvalLvl1OpName, :nextState, :approvalLvl2OpName, :cancelOpName, :currencyCode, :forexAmount, :beneficiaryBankIdentifier, "
			+ ":approvalLvl2Date, :beneficiaryAccount, :cancelDate, :beneficiaryName, :beneficiaryAddress1, :beneficiaryAddress2, :beneficiaryAddress3, :beneficiaryInstructions, :furtherApprovals, "
			+ " :totalApprovals, :beneficiaryBankName, :beneficiaryBankAddress, :beneficiaryBankCity, :beneficiaryBankCityZip, :beneficiaryBankState, :beneficiaryBankCountry, "
			+ ":userId, :approveLvl1OpId, :approveLvl2OpId, :cancelOpId, :bankToBankInstructions, :beneficiaryBankSearchMode, :isTemplateImported, :fromAccountNumber, :enteredAmtInDebitCurrency, :debitingAmount, :debitingCurrencyCode, :isDeleted, :deleteOpName, "
			+ ":deleteDate, :deleteOpId, :templateCode, :importFileInfoId, :chargeCodeId, :beneficiaryBankRegion, :intermediaryId, :intermediaryName, :intermediaryAddress, :isBeneficiaryAccSvb, :isBeneficiaryAccSvbDda, :paymentUrgency, :routingCode, :jobId)";
	
	public static final String SELECT_WIRE_OUTGOING_INFO = "select {0, number, #} AS JOB_ID, c.login_name as OLB_CLIENT_ID, l.login_name as ENTRYOP_ID, w.WIRE_TRANSACTION_ID, w.PAYMENT_TYPE, w.TEMPLATE_ID, "
			+ " w.ENTRY_DATE, w.ENTRYOP_NAME, w.APPROVE_LVL1_DATE, w.VALUE_DATE, w.APPROVE_LVL1OP_NAME, w.CURRENT_STATE, w.APPROVE_LVL2OP_NAME, w.NEXT_STATE, w.CANCELOP_NAME, w.CURRENCY_CODE, w.FOREX_RATE, "
			+ " w.FOREX_AMOUNT, w.APPROVE_LVL2_DATE, w.CANCEL_DATE, w.BENEFICIARY_BANK_IDENTIFIER, w.BENEFICIARY_ACCOUNT, w.SETTLEMENT_DATE, w.BENEFICIARY_NAME, w.BENEFICIARY_ADDRESS_1, w.BENEFICIARY_ADDRESS_2, w.CONTRACT_ID, "
			+ " w.BENEFICIARY_INSTRUCTIONS, w.CONTRACT_RATE, w.BENEFICIARY_ADDRESS_3, w.FURTHER_APPROVALS, w.VALUE_DATE_CHANGED, w.TOTAL_APPROVALS, w.BENEFICIARY_BANK_NAME, w.BENEFICIARY_BANK_ADDRESS, w.BENEFICIARY_BANK_CITY, "
			+ " w.BENEFICIARY_BANK_CITY_ZIP, w.BENEFICIARY_BANK_STATE, w.BENEFICIARY_BANK_COUNTRY, w.APPROVE_LVL1OP_ID, w.APPROVE_LVL2OP_ID, w.CANCELOP_ID, w.BANK_TO_BANK_INSTRUCTIONS, w.BENEFICIARY_BANK_SEARCH_MODE, acc.acc_num, "
			+ " w.ENTERED_AMT_IN_DEBIT_CURRENCY, w.DEBITING_AMOUNT, w.DEBITING_CURRENCY_CODE, w.SENT_DATE, w.IMPORT_FILE_INFO_ID, w.CHARGE_CODE_ID, w.BENEFICIARY_BANK_REGION, w.INTERMEDIARY_ID, w.INTERMEDIARY_NAME, w.INTERMEDIARY_ADDRESS, "
			+ " w.IS_BENEFICIARY_ACC_SVB, w.IS_BENEFICIARY_ACC_SVB_DDA, w.PAYMENT_URGENCY, w.ROUTING_CODE, w.ORIGINAL_FX_CONTRACT_AMOUNT, w.ORIGINAL_CONTRACT_AMOUNT, w.CUST_REF_NUM from wire_outgoing w, login_info l, login_info c, user_info u, account acc "
			+ " where l.id = u.user_id and c.id = u.client_id and (u.grp_id = 6 or u.grp_id = 7) and c.parent_id = 0 and l.id = w.entryop_id and w.PAYMENT_TYPE in (''DOM'', ''INTL'',''FX'') "
			+ " and w.value_date > sysdate and w.cancel_date is NULL and w.next_state = 5 and acc.account_identifier = w.account_identifier and w.beneficiary_bank_identifier is not null and (c.login_name,0) in ({1})";
	
	public static final String INSERT_WIRE_OUTGOING_INFO = "Insert into MIG_STG_WIRE_OUTGOING(JOB_ID, WIRE_TRANSACTION_ID, OLB_CLIENT_ID, PAYMENT_TYPE, TEMPLATE_ID, ENTRY_DATE, ENTRYOP_NAME, "
			+ " APPROVE_LVL1_DATE, VALUE_DATE, APPROVE_LVL1OP_NAME, CURRENT_STATE, APPROVE_LVL2OP_NAME, NEXT_STATE, CANCELOP_NAME, CURRENCY_CODE, FOREX_RATE, FOREX_AMOUNT, APPROVE_LVL2_DATE, CANCEL_DATE, "
			+ " BENEFICIARY_BANK_IDENTIFIER, BENEFICIARY_ACCOUNT, SETTLEMENT_DATE, BENEFICIARY_NAME, BENEFICIARY_ADDRESS_1, BENEFICIARY_ADDRESS_2, CONTRACT_ID, BENEFICIARY_INSTRUCTIONS, CONTRACT_RATE, "
			+ " BENEFICIARY_ADDRESS_3, FURTHER_APPROVALS, VALUE_DATE_CHANGED, TOTAL_APPROVALS, BENEFICIARY_BANK_NAME, BENEFICIARY_BANK_ADDRESS, BENEFICIARY_BANK_CITY, BENEFICIARY_BANK_CITY_ZIP, BENEFICIARY_BANK_STATE, "
			+ " BENEFICIARY_BANK_COUNTRY, ENTRYOP_ID, APPROVE_LVL1OP_ID, APPROVE_LVL2OP_ID, CANCELOP_ID, BANK_TO_BANK_INSTRUCTIONS, BENEFICIARY_BANK_SEARCH_MODE, FROM_ACCOUNT_NUMBER, ENTERED_AMT_IN_DEBIT_CURRENCY, "
			+ " DEBITING_AMOUNT, DEBITING_CURRENCY_CODE, SENT_DATE, IMPORT_FILE_INFO_ID, CHARGE_CODE_ID, BENEFICIARY_BANK_REGION, INTERMEDIARY_ID, INTERMEDIARY_NAME, INTERMEDIARY_ADDRESS, IS_BENEFICIARY_ACC_SVB, "
			+ " IS_BENEFICIARY_ACC_SVB_DDA, PAYMENT_URGENCY, ROUTING_CODE, ORIGINAL_FX_CONTRACT_AMOUNT, ORIGINAL_CONTRACT_AMOUNT, CUST_REF_NUM) values (:jobId, :wireTrnId, :clientId, :paymentType, :templateId, "
			+ " :entryDate, :entryOpName, :approveLvl1Date, :valueDate, :approveLvl1OpName, :currentState, :approveLvl2OpName, :nextState, :cancelOpName, :currencyCode, :forexRate, :forexAmount, "
			+ " :approveLvl2Date, :cancelDate, :beneficiaryBankIdentifier, :beneficiaryAccount, :settlementDate, :beneficiaryName, :beneficiaryAddr1, :beneficiaryAddr2, :contractId, :beneficiaryInstructions, "
			+ " :contractRate, :beneficiaryAddr3, :furtherApprovals, :valueDateChanged, :totalApprovals, :beneficiaryBankName, :beneficiaryBankAddr, :beneficiaryBankCity, :beneficiaryBankCityZip, :beneficiaryBankState, "
			+ " :beneficiaryBankCountry, :entryOpId, :approveLvl1OpId, :approveLvl2OpId, :cancelOpId, :bankToBankInstructions, :beneficiaryBankSearchMode, :fromAccountNumber, :enteredAmtInDebitCurrency, "
			+ " :debitingAmount, :debitingCurrencyCode, :sentDate, :importFileInfoId, :chargeCodeId, :beneficiaryBankRegion, :intermediaryId, :intermediaryName, :intermediaryAddr, :isBeneficiaryAccSVB, "
			+ " :isBeneficiaryAccSVBDDA, :paymentUrgency, :routingCode, :originalFxContractAmt, :originalContractAmt, :custRefNum)";
	
	public static final String SELECT_FREEFORM_WIRE_BENE_INFO = "with cte as (select c.login_name as OLB_CLIENT_ID, MAX(w.WIRE_TRANSACTION_ID) as tx_id, w.CURRENCY_CODE, w.BENEFICIARY_BANK_IDENTIFIER, w.BENEFICIARY_ACCOUNT, count(*)" 
			+ " from wire_outgoing w, login_info l, login_info c, user_info u where l.id = u.user_id and c.id = u.client_id and (u.grp_id = 6 or u.grp_id = 7)" 
			+ " and c.parent_id = 0 and l.id = w.entryop_id and w.ENTRY_DATE >= (SYSDATE - INTERVAL ''2'' YEAR) and w.PAYMENT_TYPE in (''DOM'', ''INTL'',''FX'')" 
			+ " and w.template_id is null and w.cancel_date is NULL and w.BENEFICIARY_BANK_IDENTIFIER is not null and current_state = 4 and next_state = 4 and (c.login_name,0) in ({1}) group by c.login_name, w.CURRENCY_CODE, w.BENEFICIARY_BANK_IDENTIFIER, w.BENEFICIARY_ACCOUNT"
			+ " having count(*) > 1)" 
			+ " select {0, number, #} AS JOB_ID, cte.olb_client_id as OLB_CLIENT_ID, l.login_name as EC_USER_LOGIN_ID, tx_id as WIRE_TRANSACTION_ID, wo.PAYMENT_TYPE, wo.TEMPLATE_ID," 
			+ " wo.ENTRY_DATE, wo.VALUE_DATE, wo.CURRENT_STATE, wo.NEXT_STATE, wo.CURRENCY_CODE, wo.FOREX_RATE," 
			+ " wo.FOREX_AMOUNT,wo.CANCEL_DATE, wo.BENEFICIARY_BANK_IDENTIFIER, wo.BENEFICIARY_ACCOUNT, wo.SETTLEMENT_DATE, wo.BENEFICIARY_NAME, wo.BENEFICIARY_ADDRESS_1, wo.BENEFICIARY_ADDRESS_2, wo.CONTRACT_ID," 
			+ " wo.BENEFICIARY_INSTRUCTIONS, wo.CONTRACT_RATE, wo.BENEFICIARY_ADDRESS_3, wo.VALUE_DATE_CHANGED, wo.BENEFICIARY_BANK_NAME, wo.BENEFICIARY_BANK_ADDRESS, wo.BENEFICIARY_BANK_CITY," 
			+ " wo.BENEFICIARY_BANK_CITY_ZIP, wo.BENEFICIARY_BANK_STATE, wo.BENEFICIARY_BANK_COUNTRY, wo.BANK_TO_BANK_INSTRUCTIONS, wo.BENEFICIARY_BANK_SEARCH_MODE, acc.acc_num," 
			+ " wo.ENTERED_AMT_IN_DEBIT_CURRENCY, wo.DEBITING_AMOUNT, wo.DEBITING_CURRENCY_CODE, wo.SENT_DATE, wo.IMPORT_FILE_INFO_ID, wo.CHARGE_CODE_ID, wo.BENEFICIARY_BANK_REGION, wo.INTERMEDIARY_ID, wo.INTERMEDIARY_NAME, wo.INTERMEDIARY_ADDRESS," 
			+ " wo.IS_BENEFICIARY_ACC_SVB, wo.IS_BENEFICIARY_ACC_SVB_DDA, wo.PAYMENT_URGENCY, wo.ROUTING_CODE, wo.ORIGINAL_FX_CONTRACT_AMOUNT, wo.ORIGINAL_CONTRACT_AMOUNT, wo.CUST_REF_NUM" 
			+ " from cte, wire_outgoing wo, account acc, login_info l where wo.WIRE_TRANSACTION_ID = cte.tx_id and acc.account_identifier = wo.account_identifier and l.id = wo.entryop_id";


	public static final String INSERT_FREEFORM_WIRE_BENE_INFO = "Insert into MIG_STG_FREEFORM_TO_BENE(JOB_ID, WIRE_TRANSACTION_ID, OLB_CLIENT_ID, PAYMENT_TYPE, TEMPLATE_ID, ENTRY_DATE,"
			+ " VALUE_DATE, CURRENT_STATE, NEXT_STATE, CURRENCY_CODE, FOREX_RATE, FOREX_AMOUNT, CANCEL_DATE,"
			+ " BENEFICIARY_BANK_IDENTIFIER, BENEFICIARY_ACCOUNT, SETTLEMENT_DATE, BENEFICIARY_NAME, BENEFICIARY_ADDRESS_1, BENEFICIARY_ADDRESS_2, CONTRACT_ID, BENEFICIARY_INSTRUCTIONS, CONTRACT_RATE,"
			+ " BENEFICIARY_ADDRESS_3, VALUE_DATE_CHANGED, BENEFICIARY_BANK_NAME, BENEFICIARY_BANK_ADDRESS, BENEFICIARY_BANK_CITY, BENEFICIARY_BANK_CITY_ZIP, BENEFICIARY_BANK_STATE,"
			+ " BENEFICIARY_BANK_COUNTRY, EC_USER_LOGIN_ID, BANK_TO_BANK_INSTRUCTIONS, BENEFICIARY_BANK_SEARCH_MODE, FROM_ACCOUNT_NUMBER, ENTERED_AMT_IN_DEBIT_CURRENCY,"
			+ " DEBITING_AMOUNT, DEBITING_CURRENCY_CODE, SENT_DATE, IMPORT_FILE_INFO_ID, CHARGE_CODE_ID, BENEFICIARY_BANK_REGION, INTERMEDIARY_ID, INTERMEDIARY_NAME, INTERMEDIARY_ADDRESS, IS_BENEFICIARY_ACC_SVB,"
			+ " IS_BENEFICIARY_ACC_SVB_DDA, PAYMENT_URGENCY, ROUTING_CODE, ORIGINAL_FX_CONTRACT_AMOUNT, ORIGINAL_CONTRACT_AMOUNT, CUST_REF_NUM) values (:jobId, :wireTrnId, :clientId, :paymentType, :templateId,"
			+ " :entryDate, :valueDate, :currentState, :nextState, :currencyCode, :forexRate, :forexAmount,"
			+ " :cancelDate, :beneficiaryBankIdentifier, :beneficiaryAccount, :settlementDate, :beneficiaryName, :beneficiaryAddr1, :beneficiaryAddr2, :contractId, :beneficiaryInstructions,"
			+ " :contractRate, :beneficiaryAddr3, :valueDateChanged, :beneficiaryBankName, :beneficiaryBankAddr, :beneficiaryBankCity, :beneficiaryBankCityZip, :beneficiaryBankState,"
			+ " :beneficiaryBankCountry, :ecUserLoginId, :bankToBankInstructions, :beneficiaryBankSearchMode, :fromAccountNumber, :enteredAmtInDebitCurrency,"
			+ " :debitingAmount, :debitingCurrencyCode, :sentDate, :importFileInfoId, :chargeCodeId, :beneficiaryBankRegion, :intermediaryId, :intermediaryName, :intermediaryAddr, :isBeneficiaryAccSVB,"
			+ " :isBeneficiaryAccSVBDDA, :paymentUrgency, :routingCode, :originalFxContractAmt, :originalContractAmt, :custRefNum)";


	public static final String DELETE_INTERNAL_TRANSFER_INFO = "delete from MIG_STG_INTERNAL_XFER where (OLB_CLIENT_ID,0) in ({0})";

	public static final String SELECT_CARDPROGRAM_INFO = "select {0, number, #} AS JOB_ID, s.CIF, s.COMPANY_ID, s.AGENT_ID, s.PRINCIPAL_ID, s.SYSTEM_ID, s.BILLING_TYPE, s.LOAN_ACCOUNT_NUMBER, s.PROD_CD, s.MANAGE_AUTO_PAYMENT," 
			+ " s.ACCOUNT_AUTOPAY, s.ACCOUNT_PAYMENT, s.STATUS_CD, c.login_name as OLB_CLIENT_ID from SVBCOM_CLIENT_COMPANY s, login_info c" 
			+ " where c.parent_id = 0 and c.id = s.client_id and (c.login_name,0) in ({1})";
	
	public static final String INSERT_CARDPROGRAM_INFO = "Insert into MIG_STG_CARD_PROGRAM(JOB_ID, CIF, OLB_CLIENT_ID, COMPANY_ID, AGENT_ID, PRINCIPAL_ID, SYSTEM_ID, BILLING_TYPE, LOAN_ACCOUNT_NUMBER, PROD_CD, MANAGE_AUTO_PAYMENT, ACCOUNT_AUTOPAY, ACCOUNT_PAYMENT, STATUS_CD, CREATED_DT, MODIFIED_DT) "
			+ " values (:jobId, :cif, :clientId, :companyId, :agentId, :principalId, :systemId, :billingType, :loanAccountNumber, :prodCd, :manageAutoPayment, :accountAutoPay, :accountPayment, :statusCd, :createdDt, :modifiedDt)";
	
	public static final String SELECT_ACCOUNT_NICKNAME_INFO = "select {0, number, #} as JOB_ID, t.ACC_TITLE, t.PROD_DESC, t.UPDATED_BY, t.MODIFIED_BY_USER, a.ACC_NUM as ACCOUNT_NUMBER, a.ACC_STAT as ACCT_STATUS, c.login_name as OLB_CLIENT_ID from ACC_TITLE t "
			+ " join ACCOUNT a on t.ACCOUNT_IDENTIFIER = a.account_identifier, login_info l, login_info c where UPPER(t.MODIFIED_BY_USER) = UPPER(''TRUE'') " 
			+ " and UPPER(t.UPDATED_BY) = UPPER(''USER'') and c.parent_id = 0 and c.id = t.client_id and c.id = l.id and (c.login_name,0) in ({1})";
	
	public static final String INSERT_ACCOUNT_NICKNAME_INFO = "Insert into MIG_STG_ACCOUNT_NICK_NAME(JOB_ID, OLB_CLIENT_ID, ACC_TITLE, PROD_DESC, ACCOUNT_NUMBER, UPDATED_BY, MODIFIED_BY_USER, ACCT_STATUS, REMARKS, CREATED_DT, MODIFIED_DT) "
			+ " values (:jobId, :clientId, :accTitle, :prodDesc, :accountNumber, :updatedBy, :modifyByUser, :accStatus, :remarks, :createdDate, :modifiedDate)";
	
	public static final String SELECT_USER_QUERY_INFO = "select {0, number, #} as JOB_ID, l.login_name as USER_LOGIN_ID, c.login_name as OLB_CLIENT_ID, uq.QUERY_ID," 
			+ " decode(uq.QUERY_TYPE_ID,1,''ACCOUNT_DETAILS'',2,''TRANSACTION_DETAILS'',3,''STATEMENTS'',4,''SPECIAL_REPORTS'',5,''DOWNLOAD_DETAILS'') as QUERY_TYPE, uq.IS_SHARED, "
			+ " uq.QUERY_NAME, uq.MODIFIED_BY, uq.LAST_MODIFIED_DATE, decode(uq.DELETED,1,''ACTIVE'',2,''DELETED'') as DELETED, decode(uq.PERIOD_TYPE,''R'',''DATE_RANGE'',''S'',''SYSTEM_PREDEFINED'',''C'',''USER_DEFINED'',null) as PERIOD_TYPE, uq.PERIOD_KEY" 
			+ " from login_info l, user_info u, login_info c, USER_QUERY uq where l.id = u.user_id and c.id = u.client_id and (u.grp_id = 6 or u.grp_id =7) " 
			+ " and c.id = uq.CLIENT_ID and l.id = uq.user_id and uq.LAST_MODIFIED_DATE >= (SYSDATE - INTERVAL ''36'' MONTH) and (c.login_name,0) in ({1})";
	
	public static final String INSERT_USER_QUERY_INFO = "Insert into MIG_STG_USERQUERY(JOB_ID, USER_LOGIN_ID, OLB_CLIENT_ID, QUERY_ID, QUERY_TYPE, IS_SHARED, QUERY_NAME, MODIFIED_BY, LAST_MODIFIED_DATE, DELETED, PERIOD_TYPE, PERIOD_KEY, CREATED_DT, MODIFIED_DT) " 
			+ " values (:jobId, :userId, :clientId, :queryId, :queryType, :isShared, :queryName, :modifiedBy, :lastModifiedDate, :deleted, :periodType, :periodKey, :createdDt, :modifiedDt)";
	
	public static final String SELECT_CUSTOM_PERIOD_INFO = "select {0, number, #} as JOB_ID, l.login_name as USER_LOGIN_ID, c.login_name as OLB_CLIENT_ID, up.CUSTOM_PERIOD_ID, up.CUSTOM_PERIOD_NAME, " 
			+ " decode(up.CUSTOM_PERIOD_TYPE,1,''DAY_OF_MONTH'',2,''DAY_OF_WEEK'',3,''CURRENT_DAY'',4,''DATE_RANGE'') as CUSTOM_PERIOD_TYPE, " 
			+ " up.CUSTOM_PERIOD_VALUE, up.CUSTOM_RANGE, decode(up.DELETED,1,''ACTIVE'',2,''DELETED'') as DELETED " 
			+ " from login_info l, user_info u, login_info c, USER_CUSTOM_PERIOD up where l.id = u.user_id and c.id = u.client_id and " 
			+ " (u.grp_id = 6 or u.grp_id = 7) and c.id = up.client_id and l.id = up.user_id and (c.login_name,0) in ({1})";
	
	public static final String INSERT_CUSTOM_PERIOD_INFO = "Insert into MIG_STG_CUSTOM_PERIOD(JOB_ID, USER_LOGIN_ID, OLB_CLIENT_ID, CUSTOM_PERIOD_ID, CUSTOM_PERIOD_NAME, CUSTOM_PERIOD_TYPE, CUSTOM_PERIOD_VALUE, CUSTOM_RANGE, DELETED, CREATED_DT, MODIFIED_DT) "
			+ " values (:jobId, :userId, :clientId, :customPeriodId, :customPeriodName, :customPeriodType, :customPeriodValue, :customRange, :deleted, :createdDt, :modifiedDt)";
	
	public static final String SELECT_CARDALERT_INFO = "select {0, number, #} AS JOB_ID, l.login_name as EC_USER_LOGIN_ID, c.login_name as EC_CLIENT_ID, casi.SUBSCRIPTION_ID as ALERTS_CLIENT_CONFIG_ID, casi.ALERT_TYPE_ID, acs.ALERT_TYPE_NAME, " 
			+ " DECODE(acs.ALERTS_SIGNUP_TYPE_ID,1,''AUTOMATIC'',2,''AUTOMATIC_TIMER'',3,''SIGNUP'',4,''SIGNUP'') as EC_ALERT_TYPE, DECODE(casi.IS_ENABLED,1,''ACTIVE'',''INACTIVE'') as " 
			+ " ALERT_STATUS, casi.COMPANY_ID as EC_ALERT_ACCOUNT_ID from login_info l, login_info c, user_info u, ALERTS_SYSTEM_CONFIG acs, CAM_ALERT_SUBSCRIBER_INFO casi" 
			+ " where l.id = u.user_id and c.id = u.client_id and (u.grp_id = 6 or u.grp_id = 7) and c.id = l.parent_id and c.parent_id = 0 " 
			+ " and acs.ALERT_TYPE_ID IN (86,88,90,91,93,95,135,501,114,98) AND acs.ALERT_TYPE_ID = casi.ALERT_TYPE_ID and c.id = casi.client_id and l.id = casi.user_id and (c.login_name,0) in ({1})";
	
	public static final String INSERT_CARDALERT_INFO = "Insert into MIG_STG_USER_SIGNUP_ALERTS(JOB_ID, EC_CLIENT_ID, EC_USER_LOGIN_ID, ALERTS_CLIENT_CONFIG_ID, ALERT_TYPE_ID, ALERT_TYPE_NAME, EC_ALERT_TYPE, ALERT_STATUS, " 
			+ " EC_ALERT_ACCOUNT_ID, REMARKS, CREATED_DT, MODIFIED_DT, GW_ALERT_ID, GW_ALERT_TYPE, GW_ALERT_NAME, EC_SOURCE, EC_ALERT_DELIVERY_TYPE) " 
			+ " values(:jobId, :clientId, :userId, :alertsClientConfigId, :alertTypeId, :alertTypeName, :ecAlertType, :alertStatus, :ecAlertAccountId, :remarks, " 
			+ " :createdDate, :modifiedDate, :gwAlertId, :gwAlertType, :gwAlertName, :ecSource, :ecAlertDeliveryType)";
	
	public static final String SELECT_SPECIAL_REPORT_INFO = "select {0, number, #} AS JOB_ID, c.login_name as OLB_CLIENT_ID, r.REPORT_SNO, r.REPORT_DATE, r.LOAD_DATE, r.SECTION_NUM, r.ACCOUNT_IDENTIFIER, r.FILE_SEQ_ID, r.FILE_ID, r.CUST_NUM," 
			+ " rb.report_blob, null as report_clob from login_info c, reports_special r, reports_special_blob rb, svbcom_client_cif s, account a where c.id = s.client_id" 
			+ " and a.account_identifier = r.account_identifier(+) and s.cust_num = a.cust_num " 
			+ " and r.report_sno = rb.report_sno and r.LOAD_DATE >= (SYSDATE - INTERVAL ''36'' MONTH) and (c.login_name,0) in ({1}) " 
			+ " union all " 
			+ " select {0, number, #} AS JOB_ID, c.login_name as OLB_CLIENT_ID, r.REPORT_SNO, r.REPORT_DATE, r.LOAD_DATE, r.SECTION_NUM, r.ACCOUNT_IDENTIFIER, r.FILE_SEQ_ID, r.FILE_ID, r.CUST_NUM, " 
			+ " null as report_blob, rc.report_clob from login_info c, reports_special r, reports_special_clob rc, svbcom_client_cif s, account a where c.id = s.client_id " 
			+ " and a.account_identifier = r.account_identifier(+) and s.cust_num = a.cust_num " 
			+ " and r.report_sno = rc.report_sno and r.LOAD_DATE >= (SYSDATE - INTERVAL ''36'' MONTH) and (c.login_name,0) in ({1}) " 
			+ " union all " 
			+ " select {0, number, #} AS JOB_ID, c.login_name as OLB_CLIENT_ID, r.REPORT_SNO, r.REPORT_DATE, r.LOAD_DATE, r.SECTION_NUM, r.ACCOUNT_IDENTIFIER, r.FILE_SEQ_ID, r.FILE_ID, r.CUST_NUM, " 
			+ " rb.report_blob, null as report_clob from login_info c, reports_special r, reports_special_blob rb, svbcom_client_cif s where c.id = s.client_id " 
			+ " and s.cust_num = r.cust_num " 
			+ " and r.report_sno = rb.report_sno and r.LOAD_DATE >= (SYSDATE - INTERVAL ''36'' MONTH) and (c.login_name,0) in ({1})";
	
	public static final String INSERT_SPECIAL_REPORT_INFO = "Insert into MIG_STG_REPORTS_SPECIAL(JOB_ID, OLB_CLIENT_ID, REPORT_SNO, REPORT_DATE, LOAD_DATE, SECTION_NUM, ACCOUNT_IDENTIFIER, "
			+ " FILE_SEQ_ID, FILE_ID, CUST_NUM, REPORT_BLOB, REPORT_CLOB, REMARKS, CREATED_DT, MODIFIED_DT) "
			+ " values(:jobId, :clientId, :reportSNo, :reportDate, :loadDate, :sectionNum, :accountIdentifier, :fileSeqId, :fileId, :custNum, :reportBlob, :reportClob, :remarks, :createdDate, :modifiedDate)";

	public static final String SELECT_PAYMENTS_SIGNUP_ALERT_INFO = "select {0, number, #} AS JOB_ID, l.login_name as EC_USER_LOGIN_ID, c.login_name as EC_CLIENT_ID, ALC.ALERTS_CLIENT_CONFIG_ID, ALC.ALERT_TYPE_ID, "
			+ " acs.ALERT_TYPE_NAME, DECODE(acs.ALERTS_SIGNUP_TYPE_ID,1,''AUTOMATIC'',2,''AUTOMATIC_TIMER'',3,''SIGNUP'',4,''SIGNUP'') as EC_ALERT_TYPE, " 
			+ " ACS.ALERTS_SCHEDULE_ID,ACS.ALERTS_DELIVERY_GROUP_ID, DECODE(ALC.IS_CURRENTLY_ENABLED,1,''ACTIVE'',''INACTIVE'') AS ALERT_STATUS, " 
			+ " ACSI.ALERT_DELIVERY_TYPE, acc.acc_num as EC_ALERT_ACCOUNT_ID," 
			+ " CASE" 
			+ "     WHEN alc.ALERT_THRESHOLD_CONDITION = 2 THEN 0 " 
			+ "     ELSE alc.ALERT_THRESHOLD" 
			+ " END AS THRESHOLD_AMOUNT " 
			+ " from login_info l, login_info c, user_info u, ALERTS_SYSTEM_CONFIG acs, alerts_client_subscriber_info acsi," 
			+ " ALERTS_CLIENT_CONFIG ALC, ACCOUNT acc where l.id = u.user_id and c.id = u.client_id and (u.grp_id = 6 or u.grp_id = 7) and c.id = l.parent_id and c.parent_id = 0 " 
			+ " and c.id = alc.client_id AND alc.ALERTS_CLIENT_CONFIG_ID = acsi.ALERTS_CLIENT_CONFIG_ID and acsi.user_id = l.id" 
			+ " and acs.ALERT_TYPE_ID = alc.ALERT_TYPE_ID and alc.account_identifier = acc.account_identifier and alc.ALERT_TYPE_ID IN (11,16,17,18) and (c.login_name,0) in ({1})";
	
	public static final String INSERT_SIGNUP_ALERT_INFO = "Insert into MIG_STG_USER_SIGNUP_ALERTS(JOB_ID, EC_CLIENT_ID, EC_USER_LOGIN_ID, ALERTS_CLIENT_CONFIG_ID, ALERT_TYPE_ID, ALERT_TYPE_NAME, "
			+ " EC_ALERT_TYPE, ALERTS_SCHEDULE_ID, ALERTS_DELIVERY_GROUP_ID, ALERT_STATUS, EC_ALERT_DELIVERY_TYPE, EC_ALERT_ACCOUNT_ID, " 
			+ " THRESHOLD_AMOUNT, REMARKS, CREATED_DT, MODIFIED_DT, GW_ALERT_ID, GW_ALERT_TYPE, GW_ALERT_NAME, EC_SOURCE) " 
			+ " values(:jobId, :clientId, :userId, :alertsClientConfigId, :alertTypeId, :alertTypeName, :ecAlertType, :alertScheduleId, :alertDeliveryGroupId, :alertStatus, "
			+ " :ecAlertDeliveryType, :ecAlertAccountId, :thresholdAmount, :remarks, :createdDate, :modifiedDate, :gwAlertId, :gwAlertType, :gwAlertName, :ecSource)";

	public static final String SELECT_OTHER_SIGNUP_ALERT_INFO = "select {0, number, #} AS JOB_ID, l.login_name as EC_USER_LOGIN_ID, c.login_name as EC_CLIENT_ID, ALC.ALERTS_CLIENT_CONFIG_ID, ALC.ALERT_TYPE_ID, "
			+ " acs.ALERT_TYPE_NAME, DECODE(acs.ALERTS_SIGNUP_TYPE_ID,1,''AUTOMATIC'',2,''AUTOMATIC_TIMER'',3,''SIGNUP'',4,''SIGNUP'') as EC_ALERT_TYPE, "
			+ " ACS.ALERTS_SCHEDULE_ID,ACS.ALERTS_DELIVERY_GROUP_ID, DECODE(ALC.IS_CURRENTLY_ENABLED,1,''ACTIVE'',''INACTIVE'') AS ALERT_STATUS, "
			+ " ACSI.ALERT_DELIVERY_TYPE, acc.acc_num as EC_ALERT_ACCOUNT_ID,"
			+ " CASE"
			+ "     WHEN alc.ALERT_THRESHOLD_CONDITION = 2 THEN 0 "
			+ "     ELSE alc.ALERT_THRESHOLD"
			+ " END AS THRESHOLD_AMOUNT "
			+ " from login_info l, login_info c, user_info u, ALERTS_SYSTEM_CONFIG acs, alerts_client_subscriber_info acsi,"
			+ " ALERTS_CLIENT_CONFIG ALC, ACCOUNT acc where l.id = u.user_id and c.id = u.client_id and (u.grp_id = 6 or u.grp_id = 7) and c.id = l.parent_id and c.parent_id = 0 "
			+ " and c.id = alc.client_id AND alc.ALERTS_CLIENT_CONFIG_ID = acsi.ALERTS_CLIENT_CONFIG_ID and acsi.user_id = l.id"
			+ " and acs.ALERT_TYPE_ID = alc.ALERT_TYPE_ID and alc.account_identifier = acc.account_identifier and acs.ALERTS_SIGNUP_TYPE_ID in (3,4) and alc.ALERT_TYPE_ID NOT IN (11,16,17,18) and (c.login_name,0) in ({1})";
	
	public static final String DELETE_USER_INFO ="delete from GWDMG.MIG_STG_USER where (OLB_CLIENT_ID,0) in ({0})";
	
	public static final String DELETE_WIRE_TEMPLATE_INFO = "delete from MIG_STG_WIRE_TEMPLATE where  (OLB_CLIENT_ID,0) in ({0})";
	
	public static final String DELETE_WIRE_OUTGOING_INFO = "delete from MIG_STG_WIRE_OUTGOING where  (OLB_CLIENT_ID,0) in ({0})";
	
	public static final String DELETE_CARDPROGRAM_INFO = "delete from MIG_STG_CARD_PROGRAM where  (OLB_CLIENT_ID,0) in ({0})";
	
	public static final String DELETE_FREEFORM_WIRE_BENE_INFO = "delete from MIG_STG_FREEFORM_TO_BENE  where (OLB_CLIENT_ID,0) in ({0})";
	
	public static final String DELETE_ACCOUNT_NICKNAME_INFO = "delete from MIG_STG_ACCOUNT_NICK_NAME  where (OLB_CLIENT_ID,0) in ({0})";
	
	public static final String DELETE_SPECIAL_REPORT_INFO = "delete from MIG_STG_REPORTS_SPECIAL where (OLB_CLIENT_ID,0) in ({0})";
	
	public static final String SELECT_WIRE_MAP_INFO = "SELECT {0, number, #} as JOB_ID, map_info.*, user1.FIRST_NM||'' ''||user1.LAST_NM WIRE_CREATED_BY, user2.FIRST_NM||'' ''||user2.LAST_NM WIRE_MODIFIED_BY FROM ("
			+ " SELECT l.LOGIN_NAME, a.IMPORT_MAP_ID, a.MAP_NAME, a.MAP_TYPE_ID, b.MAP_TYPE_NAME, b.WIRE_TYPE_ID, c.WIRE_TYPE_NAME "
			+ ", a.MAP_DESC, a.CREATED_BY_USER_ID, a.LAST_MODIFIED_BY_USER_ID  FROM CLIENT_WIRE_IMP_MAPS  a, WIRE_IMP_MAP_TYPE_META_INFO b, WIRE_TYPE_META_INFO c, LOGIN_INFO l "
			+ " WHERE a.MAP_TYPE_ID = b.MAP_TYPE_ID AND b.WIRE_TYPE_ID = c.WIRE_TYPE_ID AND l.id in (a.client_id)  AND a.client_id IN (SELECT ID FROM LOGIN_INFO WHERE (LOGIN_NAME,0) IN ({1}))) map_info, user_info user1, user_info user2 "
			+ " WHERE map_info.CREATED_BY_USER_ID = user1.user_id(+) AND map_info.LAST_MODIFIED_BY_USER_ID = user2.user_id ORDER BY lower(map_info.MAP_NAME)";
	
	public static final String INSERT_WIRE_MAP_INFO = "insert into MIG_STG_WIRE_MAP (OLB_CLIENT_ID, JOB_ID, IMPORT_MAP_ID, MAP_NAME, MAP_TYPE_NAME, WIRE_TYPE_NAME, MAP_DESC, WIRE_CREATED_BY, WIRE_MODIFIED_BY, REMARKS) values "
			+"(:olbClientId, :jobId, :importMapId, :mapName, :mapTypeName, :wireTypeName, :mapDesc, :wireCreatedBy, :wireModifiedBy, :remarks)";
	
	public static final String DELETE_WIRE_MAP_INFO = "delete from MIG_STG_WIRE_MAP where  (OLB_CLIENT_ID,0) in ({0})";
	
	public static final String SELECT_USER_LEVEL_PERM_INFO = "select {0, number, #} as JOB_ID, l.login_name as USER_LOGIN_ID, c.login_name as OLB_CLIENT_ID, u.first_NM as FIRST_NAME, pl.perm_id, pl.perm_nm AS PERM_NAME, pl.perm_desc, pl.IS_VALID_ACC_LVL_PERM "
			+ " from login_info l, user_info u, login_info c, function_perm fp, perm_list pl "
			+ " where c.parent_id = 0 and  l.id = u.user_id and c.id = u.client_id and(u.grp_id = 6 or u.grp_id =7) and  l.id = u.user_id and l.id = fp.user_id and fp.perm_id = pl.perm_id and (c.login_name,0) in ({1})";
	
	public static final String INSERT_USER_LEVEL_PERM_INFO = "insert into GWDMG.MIG_STG_USER_LEVEL_PERM (USER_LOGIN_ID, OLB_CLIENT_ID, JOB_ID, PERM_ID, PERM_NAME, PERM_DESC, IS_VALID_ACC_LVL_PERM, REMARKS, CREATED_DT, MODIFIED_DT)"
			+ " values (:userId, :clientId, :jobId, :permId, :permName, :permDesc, :isValidAccLvlPerm, :remarks, :createdDate, :modifiedDate)";
	
	public static final String DELETE_USER_LEVEL_PERM_INFO = "delete from GWDMG.MIG_STG_USER_LEVEL_PERM where (OLB_CLIENT_ID,0) in ({0})";
	
	public static final String SELECT_ACCOUNT_LEVEL_PERM_INFO = "select {0, number, #} as JOB_ID, l.login_name as USER_LOGIN_ID, c.login_name as OLB_CLIENT_ID, ap.account_identifier AS ACCOUNT_NUMBER, ap.max_amount_per_txn, ap.max_amount_per_day, ap.max_num_of_txn_per_day, "
			+ " pl.perm_id, pl.perm_nm AS PERM_NAME, pl.perm_desc, pl.ALLOW_PER_TX_LIMITS, pl.ALLOW_PER_DAY_LIMITS, pl.ASSIGN_PERM_DISPLAY_LABEL, pl.IS_VALID_ACC_LVL_PERM from acc_lvl_perm ap, perm_list pl, login_info l, user_info u, login_info c "
			+ " where c.parent_id = 0 and l.id = u.user_id and c.id = u.client_id and (u.grp_id = 6 or u.grp_id = 7) and "
			+ " l.id = u.user_id and l.id = ap.user_id and ap.perm_id = pl.perm_id and (c.login_name,0) in ({1})";
	
	public static final String INSERT_ACCOUNT_LEVEL_PERM_INFO = "insert into GWDMG.MIG_STG_ACCOUNT_LEVEL_PERM (USER_LOGIN_ID ,OLB_CLIENT_ID, PERM_ID, JOB_ID, ACCOUNT_NUMBER, MAX_AMOUNT_PER_TXN, MAX_AMOUNT_PER_DAY, MAX_NUM_OF_TXN_PER_DAY, PERM_NAME, PERM_DESC,"
			+ "ALLOW_PER_TX_LIMITS, ALLOW_PER_DAY_LIMITS, ASSIGN_PER_DISPLAY_LABEL, IS_VALID_ACC_LVL_PERM, REMARKS, CREATED_DT, MODIFIED_DT) values (:userId, :clientId, :permId, :jobId, :accountNumber, :maxAmountPerTxn, :maxAmountPerDay, :maxNumOfTxnPerDay, :permName, :permDesc,"
			+ " :allowPerTxLimits, :allowPerDayLimits, :assignPerDisplayLabel, :isValidAccLevelPerm, :remarks, :createdDate, :modifiedDate)";
	
	public static final String DELETE_ACCOUNT_LEVEL_PERM_INFO = "delete from GWDMG.MIG_STG_ACCOUNT_LEVEL_PERM where (OLB_CLIENT_ID,0) in ({0})";
	
	public static final String SELECT_CLIENT_LEVEL_PERM_INFO = "select {0, number, #} AS JOB_ID, l.login_name AS OLB_CLIENT_NAME, ol.OPR_ID, ol.OPR_NM AS OPR_NAME, "
			+ " decode(ol.OPR_CATEGORY,1,''NORMAL'',2,''SPECIAL'') as OPR_CATEGORY , ol.OPR_DESC, ol.IS_AUDITABLE from "
			+ " client c, online_services_for_client sc, opr_list ol, login_info l "
			+ " where l.id =c.client_id and sc.client_id = c.client_id and sc.opr_id = ol.opr_id and (l.login_name,0) in ({1})";
	
	public static final String INSERT_CLIENT_LEVEL_PERM_INFO = "insert into GWDMG.MIG_STG_CLIENT_LEVEL_PERM (OLB_CLIENT_ID, OPR_ID, JOB_ID, OPR_NAME, OPR_CATEGORY, OPR_DESC, IS_AUDITABLE, REMARKS, CREATED_DT, MODIFIED_DT) "
			+ "values (:clientName, :oprId, :jobId, :oprName, :oprCategory, :oprDesc, :isAuditable, :remarks, :createdDate, :modifiedDate)";
	
	public static final String DELETE_CLIENT_LEVEL_PERM_INFO = "delete from GWDMG.MIG_STG_CLIENT_LEVEL_PERM where (OLB_CLIENT_ID,0) in ({0})";

	public static final String DELETE_USER_QUERY_INFO = "delete from MIG_STG_USERQUERY  where (OLB_CLIENT_ID,0) in ({0})";
	
	public static final String DELETE_CUSTOM_PERIOD_INFO = "delete from MIG_STG_CUSTOM_PERIOD  where (OLB_CLIENT_ID,0) in ({0})";
	
	public static final String DELETE_CARDALERT_INFO = "delete from MIG_STG_USER_SIGNUP_ALERTS where (EC_CLIENT_ID,0) in ({0})";

	public static final String SELECT_EC_CLIENT_MIGRATION_STATUS = "SELECT L.LOGIN_NAME AS CLIENT_LOGIN_NAME, C.STATUS_FLG AS CLIENT_STATUS, C.MIGRATION_STATUS" +
			" FROM CLIENT C, LOGIN_INFO L" +
			" WHERE L.ID = C.CLIENT_ID AND (L.LOGIN_NAME,0) IN ({0})";

	//Delete data from stg tables
	public static final String DELETE_MIG_STG_IPAY_PAYEES = "delete from MIG_STG_IPAY_PAYEES where (EC_CLIENT_ID,0) in ({0})";
	public static final String DELETE_MIG_STG_IPAY_PAYMENTS = "delete from MIG_STG_IPAY_PAYMENTS where (EC_CLIENT_ID,0) in ({0})";

	public static final String[] TRUNCATE_I_PAY_SRC_TABLEQUERIES = {"truncate table MIG_SRC_IPAY_SUBSCRIBER",
			"truncate table MIG_SRC_IPAY_SUBUSER",
			"truncate table MIG_SRC_IPAY_PAYEES",
			"truncate table MIG_SRC_IPAY_RECURRING_PAYMENTS",
			"truncate table MIG_SRC_IPAY_SINGLE_PAYMENTS",
			"truncate table MIG_SRC_IPAY_ACH_MERCHANTS",
			"truncate table MIG_SRC_IPAY_CNSUMR_BANK_ACCTS",
			"truncate table MIG_SRC_IPAY_FUTURE_OCCURRANCES_OVERRIDES"};

}