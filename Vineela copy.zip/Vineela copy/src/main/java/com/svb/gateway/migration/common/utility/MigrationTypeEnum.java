package com.svb.gateway.migration.common.utility;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;

public enum MigrationTypeEnum {
    CLIENT_MIGRATION("ClientMigration"),
    BANK_USER_MIGRATION("BankUserMigration");

    private String value;

    MigrationTypeEnum(String value) {
        this.value = value;
    }

    @Override
    @JsonValue
    public String toString() {
        return String.valueOf(value);
    }

    @JsonCreator
    public static MigrationTypeEnum fromValue(String text) {
        for (MigrationTypeEnum b : MigrationTypeEnum.values()) {
            if (String.valueOf(b.value).equals(text)) {
                return b;
            }
        }
        return null;
    }
}
