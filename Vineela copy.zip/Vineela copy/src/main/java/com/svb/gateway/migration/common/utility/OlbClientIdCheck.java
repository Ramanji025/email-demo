package com.svb.gateway.migration.common.utility;

import com.svb.gateway.migration.common.exception.InvalidInputException;
import com.svb.gateway.migration.common.exception.ServiceException;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class OlbClientIdCheck {


    public void olbIdFormatCheck(String olbClientId) throws ServiceException {

        if (olbClientId == null) {
            throw new ServiceException("Olb Id not set", "Olb Id not passed");
        }

        String regex = "GW[a-z]{4}[0-9]{4}";
        Pattern p = Pattern.compile(regex);
        Matcher m = p.matcher(olbClientId);

        if (!m.matches()) {
            throw new InvalidInputException("olbId not set, olbId has Invalid Format");
        }
    }
}
