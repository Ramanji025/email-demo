package com.svb.gateway.migration.common.utility;

import com.svb.gateway.migration.ipay.batch.util.IPayConstants;
import com.svb.gateway.migration.payments.entity.Payment;
import org.springframework.util.StringUtils;

public class PaymentUtils {

    public static boolean inValidRecurringPayment(Payment payment) {
        if(IPayConstants.SKIPPED_PAYMENT_VALUE.equals(payment.getSkippedPayment()) || !StringUtils.isEmpty(payment.getOverrideAmount())
                || !StringUtils.isEmpty(payment.getOverrideSubsidaryBankId())){
            return true;
        }
        boolean flag= payment.getPaymentFrequency()!= null && !IPayConstants.getValidFrequencies().contains(payment.getPaymentFrequency());
        return flag;
    }
}
