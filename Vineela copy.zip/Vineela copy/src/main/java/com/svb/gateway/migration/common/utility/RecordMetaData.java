package com.svb.gateway.migration.common.utility;

import java.util.HashMap;
import java.util.Map;

public enum RecordMetaData {

    senderBankName("SENDER BNK"),
    senderBankRoutingNum("SENDER ID"),
    senderAccName("ORG"),
    senderAccNum("ORG ID"),
    senderAccAddress("ORG ADDRESS"),

    originatingBankRoutingNum("ORG FI ID"),
    originatingBankName("ORG FI"),
    originatingBankAddress("ORG FI ADDRESS"),

    bnfAccNum("BNF ID"),
    bnfAccName("BNF NAME"),
    bnfAccAddress("BNF ADDRESS"),

    bnfBankRoutingNum("BNF FI"),
    bnfBankName("BNF FI ID"),

    intermediaryBankName("REC FI"),
    intermediaryBankRoutingNum("REC ID"),

    reasonForPayment("OBI"),
    bankToBankInst("BBI"),
    refToBeneficiary("RFB");

    private String value;

    private static final Map<String, String> lookup = new HashMap<>();

    static {
        // Create reverse lookup hash map
        for (RecordMetaData d : RecordMetaData.values())
            lookup.put(d.toString(), d.name());
    }

    private RecordMetaData(String valueStr) {
        this.value = valueStr;
    }

    @Override
    public String toString() {
        return this.value;
    }

    public String getValue() {
        return this.value;
    }

    public static String get(String enumValue) {
        // the reverse lookup by simply getting
        // the value from the lookup HsahMap.
        return lookup.get(enumValue);
    }
}
