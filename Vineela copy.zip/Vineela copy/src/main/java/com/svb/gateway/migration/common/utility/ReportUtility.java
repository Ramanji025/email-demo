package com.svb.gateway.migration.common.utility;

import com.svb.gateway.migration.common.constants.MigrationConstants;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.http.CacheControl;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;

@Slf4j
public class ReportUtility {

    public static ResponseEntity<ByteArrayResource> getResponseEntityForExport(ByteArrayResource resource, String format, String prefix) {

        StringBuilder filename = new StringBuilder();
        MediaType mediaType = null;
        if (com.svb.gateway.migration.common.constants.MigrationConstants.XLSX.equalsIgnoreCase(format)) {

            filename.append(prefix)
                    .append("_")
                    .append(DateUtility.getFileNameDateFormat())
                    .append(".").append(format);
            mediaType = MediaType.MULTIPART_FORM_DATA;
        } else if (com.svb.gateway.migration.common.constants.MigrationConstants.PDF.equalsIgnoreCase(format)) {
            filename.append(prefix)
                    .append("_")
                    .append(DateUtility.getFileNameDateFormat())
                    .append(".").append(MigrationConstants.PDF);

            mediaType = MediaType.APPLICATION_PDF;
        } else {
            log.error("Invalid format requested {} ", format);
        }

        HttpHeaders headers = new HttpHeaders();
        headers.add("Content-disposition", "attachment; filename=\"" + filename.toString() + "\"");

        return returnResponseEntity(resource, mediaType, headers);
    }

    private static ResponseEntity<ByteArrayResource> returnResponseEntity(ByteArrayResource resource, MediaType mediaType, HttpHeaders headers) {
        return ResponseEntity.ok()
                .headers(headers)
                .contentLength(resource.contentLength())
                .contentType(mediaType)
                .cacheControl(CacheControl.noCache())
                .body(resource);
    }
}
