package com.svb.gateway.migration.common.utility;

import java.util.Map;

public class RequestData<T> {

	T request;
	Map<Object, Object> properties;
	
	public void setRequest(T request, Map<Object, Object> properties)
	{
		this.request = request;
		this.properties = properties;
	}
	
	public T getRequest()
	{
		return request;
	}
	
	public void setRequest(T request)
	{
		this.request = request;
	}
	
	public Map<Object, Object> getProperties()
	{
		return properties;
	}
	
	public void setProperties(Map<Object, Object> props)
	{
		this.properties = props;
	}
}
