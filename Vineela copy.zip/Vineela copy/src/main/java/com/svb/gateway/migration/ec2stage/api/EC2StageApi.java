package com.svb.gateway.migration.ec2stage.api;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;

import com.svb.gateway.migration.ec2stage.model.Ec2StageMigrationRequest;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

/**
 * @author suvaidya
 *
 */
@Api(value = "EC2StageApi")
@RequestMapping("api/ec/stage")
public interface EC2StageApi {

	@ApiOperation(value = "Endpoint for triggering the eConnect to Stage Migration Batch Job", nickname = "EC2StageApi", notes = "Migrate eC data")
	@ApiResponses(value = { @ApiResponse(code = 201, message = "Job Request Accepted "),
			@ApiResponse(code = 401, message = "Unauthorized"),
			@ApiResponse(code = 400, message = "Invalid client Ids"), @ApiResponse(code = 403, message = "Forbidden"),
			@ApiResponse(code = 500, message = "Service unavailable ") })
	@PostMapping("/migrate")
	@ResponseStatus(HttpStatus.ACCEPTED)
	@PreAuthorize("hasAuthority(@migrationServiceConfig.getAuthExecute())")
	ResponseEntity<Object> migrateEc2Stage(@RequestBody Ec2StageMigrationRequest request) throws Exception;

}
