package com.svb.gateway.migration.ec2stage.config;

import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.DuplicateJobException;
import org.springframework.batch.core.configuration.JobRegistry;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.support.ReferenceJobFactory;
import org.springframework.batch.core.job.builder.FlowBuilder;
import org.springframework.batch.core.job.builder.JobBuilder;
import org.springframework.batch.core.job.builder.JobFlowBuilder;
import org.springframework.batch.core.job.flow.Flow;
import org.springframework.batch.core.job.flow.support.SimpleFlow;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.svb.gateway.migration.common.listeners.MigrationJobListener;
import com.svb.gateway.migration.common.utility.MigrationConstants;

/**
 * @author suvaidya
 */
@Configuration
public class Ec2StageJobConfig {

    private final Logger LOGGER = LoggerFactory.getLogger(Ec2StageJobConfig.class);

    @Autowired
    private JobBuilderFactory jobBuilderFactory;

    @Autowired
    private JobRegistry jobRegistry;

    @Autowired
    private Map<String, List<Step>> migConfigMetaDataMap;

    @Bean
    public Job migrateECData(MigrationJobListener listener) throws DuplicateJobException {

        JobBuilder jobBuilder = jobBuilderFactory.get(MigrationConstants.MIGRATE_EC_DATA_JOB)
                .incrementer(new RunIdIncrementer()).listener(listener);

        // Configure the first flow of the job, continue to next only if this step is
        // successful
        List<Step> cleanUpFlowSteps = migConfigMetaDataMap.get(MigrationConstants.CLEAN_UP_FLOW);
        JobFlowBuilder jobFlowBuilder = (JobFlowBuilder) jobBuilder
                .start(createFlow(MigrationConstants.CLEAN_UP_FLOW, cleanUpFlowSteps))
                .on(MigrationConstants.STATUS_FAILED).fail();

        // Configure the rest of the flows and steps, exclude first step i.e., delete
        // existing data for input client Ids
        migConfigMetaDataMap.entrySet().stream()
                .filter(e -> !e.getKey().equalsIgnoreCase(MigrationConstants.CLEAN_UP_FLOW)).forEach(entry -> {
            Flow flow = createFlow(entry.getKey(), entry.getValue());
            jobFlowBuilder.next(flow);
        });

        Job job = jobFlowBuilder.end().build();
        this.jobRegistry.register(new ReferenceJobFactory(job));
        return job;
    }

    /**
     * Method build a batch flow adding the step from inputed stepList
     *
     * @param flowName
     * @param stepList
     * @return
     */
    private Flow createFlow(String flowName, List<Step> stepList) {
        LOGGER.debug(" configuring flow :: {}  steps :: {} ", flowName, stepList);

        FlowBuilder<SimpleFlow> flowBuilder = new FlowBuilder<SimpleFlow>(flowName);
        Iterator<Step> i = stepList.stream().iterator();
        flowBuilder.start(i.next());
        i.forEachRemaining(item -> {
            flowBuilder.next(item);
            LOGGER.debug(" configuring step :: {} ", i);
        });

        return flowBuilder.build();
    }
}
