package com.svb.gateway.migration.ec2stage.config;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.batch.core.Step;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.svb.gateway.migration.common.utility.MigrationConstants;

/**
 * @author sdoddahanuma
 */
@Configuration
public class MetaDataConfig {

    @Value("${ec.enable.data-retention}")
    private boolean enableDataRetention;

    @Autowired
    public Step stepUserLevelPermMigration;

    @Autowired
    private Step stepClientMigration;

    @Autowired
    private Step stepCleanUpData;

    @Autowired
    private Step stepCifClientLinkage;

    @Autowired
    private Step stepUserMigration;

    @Autowired
    private Step stepUserPhoneMigration;

    @Autowired
    private Step stepTransferMigration;

    @Autowired
    private Step stepWireTemplateMigrationUsedForPayment;

    @Autowired
    private Step stepWireTemplateMigrationNotUsedForPayment;

    @Autowired
    private Step stepWireOutgoingMigration;

    @Autowired
    private Step stepCardProgramMigration;

    @Autowired
    private Step stepFreeformWireBeneMigration;

    @Autowired
    private Step stepIPayPayees;

    @Autowired
    private Step stepIPaySinglePayments;

    @Autowired
    private Step stepIPayRecurringPayments;

    @Autowired
    private Step stepAccountNicknameMigration;

    @Autowired
    private Step stepWireMapMigration;

    @Autowired
    private Step stepAccountLevelPermMigration;

    @Autowired
    private Step stepClientLevelPermMigration;

    @Autowired
    private Step stepCustomPeriodMigration;

    @Autowired
    private Step stepUserQueryMigration;

    @Autowired
    private Step stepCardAlertMigration;

    @Autowired
    private Step stepSpecialReportMigration;

    @Autowired
    private Step stepPaymentSignupAlertMigration;

    @Autowired
    private Step stepOtherSignupAlertMigration;

    @Bean
    public Map<String, List<Step>> migConfigMetaDataMap() {
        
        Map<String, List<Step>> configMap = new HashMap<String, List<Step>>();

        cleanUpFlow(configMap);

        clientMigrationFlow(configMap);

        userMigrationFlow(configMap);

        transfersMigrationFlow(configMap);

        wiresMigrationFlow(configMap);

        cardsProgramFlow(configMap);

        accountsMigrationFlow(configMap);

        userQueryMigrationFlow(configMap);

        reportsMigrationFlow(configMap);

        alertsMigrationFlow(configMap);

        return configMap;
    }

    private void cleanUpFlow(Map<String, List<Step>> configMap) {
        // Truncate flow and steps
        List<Step> truncateStepList = new ArrayList<>();
        truncateStepList.add(stepCleanUpData);
        configMap.put(MigrationConstants.CLEAN_UP_FLOW, truncateStepList);
    }

    private void clientMigrationFlow(Map<String, List<Step>> configMap) {
        // Client flow and steps
        List<Step> clientMigStepsList = new ArrayList<>();
        clientMigStepsList.add(stepClientMigration);
        clientMigStepsList.add(stepCifClientLinkage);
        configMap.put(MigrationConstants.CLIENT_MIG_FLOW, clientMigStepsList);

        if (enableDataRetention) {
            // Client level Perm flow and steps
            List<Step> clientLevelPermMigStepsList = new ArrayList<>();
            clientLevelPermMigStepsList.add(stepClientLevelPermMigration);
            configMap.put(MigrationConstants.CLIENT_LEVEL_PERM_MIG_FLOW, clientLevelPermMigStepsList);
        }
    }

    private void userMigrationFlow(Map<String, List<Step>> configMap) {
        // User flow and steps
        List<Step> userMigStepsList = new ArrayList<>();
        userMigStepsList.add(stepUserMigration);
        if (enableDataRetention) {
            userMigStepsList.add(stepUserPhoneMigration);
        }
        configMap.put(MigrationConstants.USER_MIG_FLOW, userMigStepsList);

        if (enableDataRetention) {
            // User Level Perm fow and steps
            List<Step> userLevelPermStepsList = new ArrayList<>();
            userLevelPermStepsList.add(stepUserLevelPermMigration);
            configMap.put(MigrationConstants.USER_LEVEL_PERM_MIG_FLOW, userLevelPermStepsList);
        }
    }

    private void transfersMigrationFlow(Map<String, List<Step>> configMap) {
        // Transfer flow and steps
        List<Step> transferMigStepsList = new ArrayList<>();
        transferMigStepsList.add(stepTransferMigration);
        configMap.put(MigrationConstants.TRANSFER_MIG_FLOW, transferMigStepsList);
    }

    private void wiresMigrationFlow(Map<String, List<Step>> configMap) {
        // Wire Template/outgoing flow and steps
        List<Step> wireMigStepList = new ArrayList<>();
        wireMigStepList.add(stepWireTemplateMigrationUsedForPayment);
        wireMigStepList.add(stepWireTemplateMigrationNotUsedForPayment);
        wireMigStepList.add(stepWireOutgoingMigration);
        // Removed as part of GCP-59940
        // wireMigStepList.add(stepFreeformWireBeneMigration);
        if (enableDataRetention) {
            wireMigStepList.add(stepWireMapMigration);
        }
        configMap.put(MigrationConstants.WIRE_MIG_FLOW, wireMigStepList);
    }

    private void cardsProgramFlow(Map<String, List<Step>> configMap) {
        // Card program flow and steps
        List<Step> cardProgramMigStepsList = new ArrayList<>();
        cardProgramMigStepsList.add(stepCardProgramMigration);
        configMap.put(MigrationConstants.CARDPROGRAM_MIG_FLOW, cardProgramMigStepsList);
    }

    private void accountsMigrationFlow(Map<String, List<Step>> configMap) {
        // Account nicknames flow and steps
        List<Step> accountNicknamesMigStepsList = new ArrayList<>();
        accountNicknamesMigStepsList.add(stepAccountNicknameMigration);
        configMap.put(MigrationConstants.ACCOUNTNICKNAME_MIG_FLOW, accountNicknamesMigStepsList);

        if (enableDataRetention) {
            //Account level Perm flow adn steps
            List<Step> accountLevelPermMigStepsList = new ArrayList<>();
            accountLevelPermMigStepsList.add(stepAccountLevelPermMigration);
            configMap.put(MigrationConstants.ACCOUNT_LEVEL_PERM_MIG_FLOW, accountLevelPermMigStepsList);
        }
    }

    private void userQueryMigrationFlow(Map<String, List<Step>> configMap) {
        if (enableDataRetention) {
            // User queries flow and steps
            List<Step> userQueryMigStepsList = new ArrayList<>();
            userQueryMigStepsList.add(stepUserQueryMigration);
            configMap.put(MigrationConstants.USERQUERY_MIG_FLOW, userQueryMigStepsList);

            // Custom periods flow and steps
            List<Step> customPeriodMigStepsList = new ArrayList<>();
            customPeriodMigStepsList.add(stepCustomPeriodMigration);
            configMap.put(MigrationConstants.CUSTOMPERIOD_MIG_FLOW, customPeriodMigStepsList);
        }
    }

    private void reportsMigrationFlow(Map<String, List<Step>> configMap) {
        if (enableDataRetention) {
            // Special reports flow and steps
            List<Step> specialReportsMigStepsList = new ArrayList<>();
            specialReportsMigStepsList.add(stepSpecialReportMigration);
            configMap.put(MigrationConstants.SPECIAL_REPORT_MIG_FLOW, specialReportsMigStepsList);
        }
    }

    private void alertsMigrationFlow(Map<String, List<Step>> configMap) {
        // Card alerts flow and steps
        List<Step> cardAlertsMigStepsList = new ArrayList<>();
        cardAlertsMigStepsList.add(stepCardAlertMigration);
        configMap.put(MigrationConstants.CARDALERT_MIG_FLOW, cardAlertsMigStepsList);

        // Signup alerts flow and steps
        List<Step> signupAlertsMigStepsList = new ArrayList<>();
        signupAlertsMigStepsList.add(stepPaymentSignupAlertMigration);
        if (enableDataRetention) {
            signupAlertsMigStepsList.add(stepOtherSignupAlertMigration);
        }
        configMap.put(MigrationConstants.SIGNUP_ALERT_MIG_FLOW, signupAlertsMigStepsList);
    }
}
