/**
 * 
 */
package com.svb.gateway.migration.ec2stage.controller;

import com.svb.gateway.migration.common.exception.BadRequestException;
import com.svb.gateway.migration.common.exception.ServiceException;
import com.svb.gateway.migration.common.model.Error;
import com.svb.gateway.migration.common.utility.MigrationConstants;
import com.svb.gateway.migration.common.utility.MigrationErrorCodeEnum;
import com.svb.gateway.migration.ec2stage.api.EC2StageApi;
import com.svb.gateway.migration.ec2stage.model.Ec2StageMigrationRequest;
import com.svb.gateway.migration.ec2stage.service.ECService;
import com.svb.gateway.migration.job.model.CreateJobResponse;
import com.svb.gateway.migration.job.model.CreateJobResponseData;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.configuration.JobRegistry;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.batch.core.repository.JobRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;
import springfox.documentation.annotations.ApiIgnore;

import javax.validation.Valid;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * @author suvaidya
 *
 */
@ApiIgnore
@RestController
public class EC2StageController implements EC2StageApi {

	private Logger LOGGER = LoggerFactory.getLogger(EC2StageController.class);

	@Autowired
	@Qualifier("migJobLauncher")
	private JobLauncher jobLauncher;
	
	@Autowired
	private JobRegistry jobRegistry;

	@Autowired
	JobRepository jobRepository;

	private ECService ecService;

	@Value("${migration.ecclient.id.length}")
	private Integer EC_CLIENT_ID_LENGTH;

	@Autowired
	public void setEcService(ECService ecService) {
		this.ecService = ecService;
	}

	@Override
	public ResponseEntity<Object> migrateEc2Stage(@Valid Ec2StageMigrationRequest request) throws Exception {
		return migrateEc2StageInternal(request);
	}

	public ResponseEntity<Object> migrateEc2StageInternal(Ec2StageMigrationRequest request) throws Exception {
		LOGGER.info("migrateEc2Stage() started Job Id --> {}", request.getJobId());
		CreateJobResponse jobRes = launchJob(request.getClientIds(), request.getJobId());
		LOGGER.info("migrateEc2Stage() scheduled");
		return ResponseEntity.accepted().body(jobRes);
	}

	/**
	 * Method launch migration job passing the job parameters i.e., list of client
	 * Ids and job id
	 * 
	 * @param clientIds
	 * @param jobId
	 * @return
	 * @throws Exception
	 */
	private CreateJobResponse launchJob(List<String> clientIds, long jobId) throws Exception {
		JobParametersBuilder builder = new JobParametersBuilder();
		builder.addLong(MigrationConstants.JOB_ID_KEY, jobId);
		CreateJobResponse response = null;

		if (!clientIds.isEmpty()) {
			LOGGER.info("launchJob() request for client ID's Count --> {}", clientIds.size());

			validateClientIds(clientIds);

			// Validate if clients have migration status set to "Due for migration in eC"
			List<String> clientNames = ecService.validateECMigrationStatus(clientIds);
			if(!clientNames.isEmpty() && clientNames.size() > 0) {
				LOGGER.info(" Following eC clients have incorrect migration status --> {}", clientNames);
				throw new BadRequestException(MigrationErrorCodeEnum.MIGRATION_INVALID_EC_MIGRATION_STATUS, " Incorrect Migration Status for clients :: " + clientNames);
			}

			// trigger client migration status update on ec
			ecService.updateClientDetailsEc(clientIds, MigrationConstants.EC_MIGRATION_STATUS_IN_PROGRESS);

			// get client Ids list as comma separated values
			builder.addString(MigrationConstants.CLIENT_IDS,
					clientIds.stream()
							.map(clientId -> MigrationConstants.PARANTHESIS_OPEN + MigrationConstants.SINGLE_QUOTE
									+ clientId + MigrationConstants.SINGLE_QUOTE + MigrationConstants.COMMA
									+ MigrationConstants.ZERO + MigrationConstants.PARANTHESIS_CLOSE)
							.collect(Collectors.joining(MigrationConstants.COMMA)));

			Job job = jobRegistry.getJob(MigrationConstants.MIGRATE_EC_DATA_JOB);
			JobExecution jobExecution = jobLauncher.run(job, builder.toJobParameters());
			String status = jobExecution.getStatus().name();
			LOGGER.info("launchJob() - SCHEDULED for jobId:: {}  and job status :: {} ", jobId, status);
			response = new CreateJobResponse(new CreateJobResponseData(jobId, status));
		} else {
			response = buildErrorResponse();
		}
		return response;
	}



	// This method is to validate clientId if it's empty or null or duplicate or
	// length is not 8
	public void validateClientIds(List<String> clientIds) throws ServiceException {
		final Set<String> clientsSet = new HashSet<>();
		for (String clientId : clientIds) {
			if (StringUtils.isBlank(clientId)) {
				throw new ServiceException("Empty ClientId exists in the list.");
			}
			// Preparing a set to identify the duplicate ClientId
			if (clientsSet.contains(clientId)) {
				throw new ServiceException("Duplicate record exist -> " + clientId);
			} else {
				clientsSet.add(clientId);
			}

			if (clientId.length() != EC_CLIENT_ID_LENGTH) {
				throw new ServiceException("Client Id length should be " + EC_CLIENT_ID_LENGTH);
			}
		}
		clientsSet.clear();
	}

	private CreateJobResponse buildErrorResponse() {

		List<Error> errList = new ArrayList<>();
		Error error = new Error("1", "Minimum one client Id is required!");
		errList.add(error);

		CreateJobResponse response = new CreateJobResponse();
		response.setErrors(errList);
		return response;
	}
}
