/**
 * 
 */
package com.svb.gateway.migration.ec2stage.model;

import java.util.List;

import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

/**
 * @author suvaidya
 *
 */
@Getter
@Setter
@NoArgsConstructor
@ToString
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
		"clientIds",
		"jobId"
})
public class Ec2StageMigrationRequest {

	@JsonProperty("clientIds")
	private List<String> clientIds;
	@JsonProperty("jobId")
	@NotNull(message ="JobId cannot be null")
	private Long jobId;
}
