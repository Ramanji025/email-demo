package com.svb.gateway.migration.ec2stage.service;

import com.svb.gateway.migration.common.exception.ServiceException;
import com.svb.gateway.migration.common.utility.MigrationConstants;
import com.svb.gateway.migration.ec2stage.dao.ECDao;
import com.svb.gateway.migration.ec2stage.model.ClientDetail;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
public class ECService {

    private Logger LOGGER = LoggerFactory.getLogger(ECService.class);

    private RestTemplate restTemplate;

    @Autowired
    private ECDao ecDao;

    @Value("${ec.updateStatus.url}")
    private String ecClientUrl;

    @Value("${ec.enable.validation}")
    private boolean enableECValidation;

    @Autowired
    public void setRestTemplate(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    }

    // temporarily disabled this validation
    public List<String> validateECMigrationStatus(List<String> clientIds) {
        return new ArrayList<>();

        /*List<ClientDetail> clientDetails = ecDao.getECMigrationStatus(clientIds);
        List<String> clientLoginNames = clientDetails
                .stream()
                .filter(c -> c.getMigrationStatus() != MigrationConstants.EC_MIGRATION_STATUS_DUE_FOR_MIGRATION)
                .map(c -> c.getClientLoginName())
                .collect(Collectors.toList());

        return clientLoginNames; */
    }

    public void updateClientDetailsEc(List<String> clientIds, int migrationStatus) throws ServiceException {
        if(!enableECValidation) {
            return;
        }

        boolean responseStatus = false;
        Map<String, Object> data = new HashMap<>();
        data.put(MigrationConstants.EC_CLIENT_NAME_JSON_KEY, clientIds);
        data.put(MigrationConstants.EC_MIGRATION_STATUS_JSON_KEY, migrationStatus);

        Map<String, Object> eCUpdateStatusRequest = new HashMap<>();
        eCUpdateStatusRequest.put("data", data);
        eCUpdateStatusRequest.put("meta", new HashMap<>());

        HttpHeaders headers = new HttpHeaders();
        ResponseEntity<Object> responseObject;
        headers.setContentType(MediaType.APPLICATION_JSON);
        HttpEntity<?> requestEntity = new HttpEntity<>(eCUpdateStatusRequest, headers);

        try {
            responseObject = restTemplate.exchange(ecClientUrl, HttpMethod.POST, requestEntity, Object.class);

            if(null != responseObject && responseObject.hasBody() && responseObject.getStatusCode() == HttpStatus.OK) {
                Map<String, Object> response = (Map<String, Object>) responseObject.getBody();
                if(!response.isEmpty() && null != response.get("data")) {
                    Map<String, Object> dataResponse = (HashMap<String, Object>) response.get("data");
                    responseStatus = "success".equalsIgnoreCase((String) dataResponse.get("status")) ? true : false;
                } else {
                    responseStatus = false;
                }
            } else {
                throw new ServiceException("Incorrect response code " + responseObject.getStatusCode());
            }

        } catch (Exception exception) {
            LOGGER.error("Error in updating the client status in eC", exception);
            throw new ServiceException("Error in updating the client status in eC");
        }

        if(!responseStatus) {
            LOGGER.error("Error in updating the client status in eC");
            throw new ServiceException("Error in updating the client status in eC");
        }
    }
}
