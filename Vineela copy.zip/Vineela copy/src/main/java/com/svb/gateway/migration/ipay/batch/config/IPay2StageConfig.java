package com.svb.gateway.migration.ipay.batch.config;

import com.svb.gateway.migration.common.listeners.MigrationJobListener;
import com.svb.gateway.migration.ipay.batch.util.IPayConstants;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.job.builder.FlowBuilder;
import org.springframework.batch.core.job.flow.Flow;
import org.springframework.batch.core.job.flow.support.SimpleFlow;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class IPay2StageConfig {

    @Autowired
    private JobBuilderFactory jobBuilderFactory;

    @Autowired
    private Step stepIPayPayees;

    @Autowired
    private Step stepIPaySinglePayments;

    @Autowired
    private Step stepIPayRecurringPayments;

    @Autowired
    private Step stepIPayCleanUpData;


    @Bean
    public Job moveIPay2Stage(MigrationJobListener listener){
        return jobBuilderFactory.get(IPayConstants.MOVE_I_PAY_2_STAGE_DATA)
                .incrementer(new RunIdIncrementer())
                .listener(listener)
                .start(IPay2StageStepFlow())
                .end()
                .build();
    }


    @Bean
    public Flow IPay2StageStepFlow() {
        return new FlowBuilder<SimpleFlow>(IPayConstants.I_PAY_2_STAGE_STEP_FLOW)
                .start(stepIPayCleanUpData).next(stepIPayPayees).next(stepIPaySinglePayments).next(stepIPayRecurringPayments)
                .build();
    }

}
