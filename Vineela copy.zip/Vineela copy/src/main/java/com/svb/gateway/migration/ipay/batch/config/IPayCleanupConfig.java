package com.svb.gateway.migration.ipay.batch.config;

import com.svb.gateway.migration.common.config.ConfigBase;
import com.svb.gateway.migration.common.utility.MigrationConstants;
import com.svb.gateway.migration.common.utility.MigrationQueries;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.*;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.JdbcTemplate;

import java.text.MessageFormat;

@Configuration
public class IPayCleanupConfig extends ConfigBase {

    Logger logger = LoggerFactory.getLogger(IPayCleanupConfig.class);

    @Autowired
    public JdbcTemplate migrationJdbcTemplate;

    public Tasklet stepIPayCleanUpDataTasklet() {
        return new Tasklet() {
            @Override
            public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {
                try {
                    JobParameters jobParameters = contribution.getStepExecution().getJobParameters();
                    String clientIds = jobParameters.getString(MigrationConstants.CLIENT_IDS,
                            MigrationConstants.EMPTY_STR);

                    migrationJdbcTemplate.update(MessageFormat.format(MigrationQueries.DELETE_MIG_STG_IPAY_PAYEES, clientIds));
                    migrationJdbcTemplate.update(MessageFormat.format(MigrationQueries.DELETE_MIG_STG_IPAY_PAYMENTS, clientIds));

                } catch (Exception ex) {
                    logger.error("Exception while deleting records ::", ex);
                    StepExecution stepExecution = chunkContext.getStepContext().getStepExecution();
                    stepExecution.addFailureException(ex);
                    stepExecution.setExitStatus(new ExitStatus(MigrationConstants.STATUS_FAILED, ex.getMessage()));
                }
                return RepeatStatus.FINISHED;
            }
        };
    }

    @Bean
    public Step stepIPayCleanUpData() {
        return stepBuilderFactory.get(MigrationConstants.STEP_IPAY_CLEAN_UP_DATA).listener(migrationSkipListener)
                .listener(migrationStepListener).tasklet(stepIPayCleanUpDataTasklet()).build();
    }
}
