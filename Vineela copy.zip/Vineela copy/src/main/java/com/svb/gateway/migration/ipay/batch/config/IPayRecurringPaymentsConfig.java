package com.svb.gateway.migration.ipay.batch.config;

import com.svb.gateway.migration.accountbalance.batch.dto.source.AccBalanceTrend;
import com.svb.gateway.migration.common.config.ConfigBase;
import com.svb.gateway.migration.common.listeners.MigrationItemListener;
import com.svb.gateway.migration.ipay.batch.dto.IPayPayees;
import com.svb.gateway.migration.ipay.batch.dto.IPayRecurringPayments;
import com.svb.gateway.migration.ipay.batch.mapper.IPayRecurringMapper;
import com.svb.gateway.migration.ipay.batch.processors.IPayRecurringProcessor;
import com.svb.gateway.migration.ipay.batch.util.IPayQueries;
import org.springframework.batch.core.ItemProcessListener;
import org.springframework.batch.core.ItemReadListener;
import org.springframework.batch.core.ItemWriteListener;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.core.step.builder.SimpleStepBuilder;
import org.springframework.batch.item.database.BeanPropertyItemSqlParameterSourceProvider;
import org.springframework.batch.item.database.JdbcBatchItemWriter;
import org.springframework.batch.item.database.JdbcCursorItemReader;
import org.springframework.batch.item.database.builder.JdbcBatchItemWriterBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import javax.sql.DataSource;
import java.text.MessageFormat;

import static com.svb.gateway.migration.common.utility.MigrationConstants.EMPTY_STRING;
import static com.svb.gateway.migration.common.utility.MigrationConstants.IPAY_RECURRING_PAYMENTS_ENTITY;

@Configuration
public class IPayRecurringPaymentsConfig extends ConfigBase {


    @Qualifier("migrationDataSource")
    @Autowired
    public DataSource migrationDataSource;

    @Autowired
    public MigrationItemListener<IPayPayees, IPayPayees> migrationItemListener;

    @Bean
    public Step stepIPayRecurringPayments() {
        return ((SimpleStepBuilder<IPayRecurringPayments, IPayRecurringPayments>) stepBuilderFactory.get(IPAY_RECURRING_PAYMENTS_ENTITY)
                .<AccBalanceTrend, AccBalanceTrend>chunk(chunkSize).faultTolerant().skipLimit(skipLimit).skipPolicy(exceptionSkipPolicy)
                .listener(migrationSkipListener).listener(migrationStepListener)).reader(ipayRecurringPaymentsReader(EMPTY_STRING))
                .listener((ItemReadListener) migrationItemListener).processor(ipayRecurringPaymentsProcessor())
                .listener((ItemProcessListener) migrationItemListener).writer(ipayRecurringPaymentsWriter())
                .listener((ItemWriteListener) migrationItemListener).build();
    }

    @Bean(destroyMethod="")
    @StepScope
    public JdbcCursorItemReader<IPayRecurringPayments> ipayRecurringPaymentsReader(@Value("#{jobParameters['clientIds']}") String ecClientId) {

        JdbcCursorItemReader<IPayRecurringPayments> reader = new JdbcCursorItemReader<IPayRecurringPayments>();
        reader.setDataSource(migrationDataSource);
        reader.setSql(MessageFormat.format(IPayQueries.getIPayRecurringSelectQuery(),ecClientId));
        reader.setRowMapper(new IPayRecurringMapper());
        return reader;
    }

    @Bean
    @StepScope
    public IPayRecurringProcessor ipayRecurringPaymentsProcessor() {
        return new IPayRecurringProcessor();
    }

    @Bean
    public JdbcBatchItemWriter<IPayRecurringPayments> ipayRecurringPaymentsWriter() {
        return new JdbcBatchItemWriterBuilder<IPayRecurringPayments>()
                .itemSqlParameterSourceProvider(new BeanPropertyItemSqlParameterSourceProvider<>())
                .sql(IPayQueries.getIPayRecurringInsert())
                .dataSource(migrationDataSource).build();
    }

}
