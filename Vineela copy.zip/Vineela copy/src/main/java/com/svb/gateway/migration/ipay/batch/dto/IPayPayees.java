package com.svb.gateway.migration.ipay.batch.dto;

import lombok.Data;

@Data
public class IPayPayees {

    private Integer subscriberId;
    private String payeeRelationshipNumber;
    private String beneNickname;
    private String beneAccount;
    private String beneName;
    private String beneAddress1;
    private String beneAddress2;
    private String beneAddress3;
    private String payeeCity;
    private String payeeState;
    private String payeeZipCode;
    private String payeePhoneNum;
    private String merchantCategory;
    private String merchantAccountType;
    private String electronicIndicator;
    private String createdBy;
    private String ecClientId;
    private String beneBankIdentifier;
    private Long jobId;
}
