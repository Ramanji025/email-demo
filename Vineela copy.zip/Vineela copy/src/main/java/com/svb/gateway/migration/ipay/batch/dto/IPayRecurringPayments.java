package com.svb.gateway.migration.ipay.batch.dto;

import lombok.Data;

@Data
public class IPayRecurringPayments {

    private String subscriberId;
    private String payeeRelationshipNumber;
    private String payeeAmount;
    private String paymentDate;
    private String paymentDate2;
    private String paymentEndDate;
    private String paymentFrequency;
    private String ecClientId;
    private String beneficiaryId;
    private String subscriberAccountNumber;
    private String transactionType;
    private String numberOccurencesRemaing;
    private String createdBy;
    private String overrideSubsBankId;
    private String overrideAmount;
    private String skippedPayment;
    private Long jobId;
}
