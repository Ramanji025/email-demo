package com.svb.gateway.migration.ipay.batch.dto;

import lombok.Data;

@Data
public class IPaySinglePayments {

    private String paymentId;
    private String subscriberId;
    private String paymentAmount;
    private String paymentDate;
    private String payeeRelationshipNumber;
    private String subscriberBankAcctId;
    private String createdBy;
    private String ecClientId;
    private String transactionType;
    private Long jobId;
    private String beneficiaryId;
}
