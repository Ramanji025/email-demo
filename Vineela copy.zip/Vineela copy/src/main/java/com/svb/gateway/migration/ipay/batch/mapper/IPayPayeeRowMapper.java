package com.svb.gateway.migration.ipay.batch.mapper;

import com.svb.gateway.migration.ipay.batch.dto.IPayPayees;
import org.springframework.jdbc.core.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import static com.svb.gateway.migration.ipay.batch.util.IPayConstants.*;

public class IPayPayeeRowMapper implements RowMapper<IPayPayees> {

    @Override
    public IPayPayees mapRow(ResultSet rs, int rowNum) throws SQLException {

        IPayPayees payees = new IPayPayees();
        payees.setSubscriberId(rs.getInt(SUBSCRIBER_ID));
        payees.setPayeeRelationshipNumber(rs.getString(PAYEE_RELTNSHP_NUM));
        payees.setBeneNickname(rs.getString(BENE_NICK_NAME));
        payees.setBeneAccount(rs.getString(BENE_ACCOUNT));
        payees.setBeneName(rs.getString(BENE_NAME));
        payees.setBeneAddress1(rs.getString(BENE_ADDRESS_1));
        payees.setBeneAddress2(rs.getString(BENE_ADDRESS_2));
        payees.setPayeeCity(rs.getString(PAYEE_CITY));
        payees.setPayeeState(rs.getString(PAYEE_STATE));
        payees.setPayeeZipCode(rs.getString(PAYEE_ZIP_CODE));
        payees.setPayeePhoneNum(rs.getString(PAYEE_PHONE_NUM));
        payees.setMerchantCategory(rs.getString(MERCHANT_CATEGORY));
        payees.setMerchantAccountType(rs.getString(MERCHANT_ACCOUNT_TYPE));
        payees.setElectronicIndicator(rs.getString(ELECTRONIC_INDICATOR));
        payees.setCreatedBy(rs.getString(CREATED_BY));
        payees.setEcClientId(rs.getString(ECCLIENT_ID));
        payees.setBeneBankIdentifier(rs.getString(BENE_BANK_IDENTIFIER));
        return payees;
    }
}
