package com.svb.gateway.migration.ipay.batch.mapper;

import com.svb.gateway.migration.common.utility.DateUtility;
import com.svb.gateway.migration.ipay.batch.dto.IPayRecurringPayments;
import org.springframework.jdbc.core.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;

import static com.svb.gateway.migration.ipay.batch.util.IPayConstants.*;

public class IPayRecurringMapper implements RowMapper<IPayRecurringPayments> {

    @Override
    public IPayRecurringPayments mapRow(ResultSet rs, int rowNum) throws SQLException {

        IPayRecurringPayments payments = new IPayRecurringPayments();
        payments.setSubscriberId(rs.getString(SUBSCRIBER_ID));
        payments.setPayeeRelationshipNumber(rs.getString(PAYEE_RELATIONSHIP_NUMBER));
        payments.setPayeeAmount(rs.getString(PAYEE_AMOUNT));
        payments.setPaymentDate(DateUtility.getDateStringddMMMYYPattern(rs.getDate(PAYMENT_DATE)));
        Date paymentEndDate = rs.getDate(PAYMENT_END_DATE);
        if ( paymentEndDate != null) {
            payments.setPaymentDate2(DateUtility.getDateStringddMMMYYPattern(paymentEndDate));
        }
        payments.setPaymentFrequency(rs.getString(PAYMENT_FREQUENCY));
        payments.setEcClientId(rs.getString(EC_CLIENT_ID));
        payments.setBeneficiaryId(rs.getString(BENEFICIARY_ID));
        payments.setSubscriberAccountNumber(rs.getString(SUBSCRIBER_ACCOUNT_NUMBER));
        payments.setTransactionType(rs.getString(TRANSACTION_TYPE));
        payments.setNumberOccurencesRemaing(rs.getString(NUMBER_OCCURENCES_REMAING));
        payments.setCreatedBy(rs.getString(CREATED_BY));
        payments.setOverrideAmount(rs.getString(OVERRIDE_AMOUNT));
        payments.setSkippedPayment(rs.getString(SKIPPED_PAYMENT));
        payments.setOverrideSubsBankId(rs.getString(OVERRIDE_SUBS_BANK_ID));
        return payments;
    }
}
