package com.svb.gateway.migration.ipay.batch.mapper;

import com.svb.gateway.migration.common.utility.DateUtility;
import com.svb.gateway.migration.ipay.batch.dto.IPaySinglePayments;
import org.springframework.jdbc.core.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import static com.svb.gateway.migration.ipay.batch.util.IPayConstants.*;

public class IPaySinglePaymentsMapper implements RowMapper<IPaySinglePayments> {

    @Override
    public IPaySinglePayments mapRow(ResultSet rs, int rowNum) throws SQLException {
        IPaySinglePayments psp = new IPaySinglePayments();
        psp.setCreatedBy(rs.getString(CREATED_BY));
        psp.setEcClientId(rs.getString(ECCLIENT_ID));
        psp.setPayeeRelationshipNumber(rs.getString(PAYEE_RELATIONSHIP_NUMBER));
        psp.setPaymentAmount(rs.getString(PAYMENT_AMOUNT));
        psp.setPaymentDate(DateUtility.getDateStringddMMMYYPattern(rs.getDate(PAYMENT_DATE)));
        psp.setPaymentId(rs.getString(PAYMENT_ID));
        psp.setSubscriberBankAcctId(rs.getString(SUBSCRIBER_BANK_ACCT_ID));
        psp.setSubscriberId(rs.getString(SUBSCRIBER_ID));
        psp.setTransactionType(rs.getString(TRANSACTION_TYPE));
        psp.setBeneficiaryId(rs.getString(BENEFICIARY_ID));
        return psp;
    }
}
