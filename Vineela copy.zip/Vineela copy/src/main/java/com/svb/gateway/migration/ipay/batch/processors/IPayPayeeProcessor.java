package com.svb.gateway.migration.ipay.batch.processors;
import com.svb.gateway.migration.ipay.batch.dto.IPayPayees;
import org.apache.commons.lang3.StringUtils;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.beans.factory.annotation.Value;

public class IPayPayeeProcessor implements ItemProcessor<IPayPayees, IPayPayees> {

    @Value("#{jobParameters['jobid']}")
    private long jobid;

    @Override
    public IPayPayees process(IPayPayees item) throws Exception {
        item.setJobId(jobid);

        StringBuilder address = new StringBuilder();
        if (StringUtils.isNotBlank(item.getPayeeCity())) {
            address.append(item.getPayeeCity()).append(" ");
        }
        if (StringUtils.isNotBlank(item.getPayeeState())) {
            address.append(item.getPayeeState()).append(" ");
        }
        if (StringUtils.isNotBlank(item.getPayeeZipCode())) {
            address.append(item.getPayeeZipCode());
        }
        item.setBeneAddress3(address.toString().trim());
        return item;
    }
}
