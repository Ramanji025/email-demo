package com.svb.gateway.migration.ipay.batch.processors;

import com.svb.gateway.migration.ipay.batch.dto.IPaySinglePayments;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.beans.factory.annotation.Value;

public class IPaySinglePaymentsProcessor implements ItemProcessor<IPaySinglePayments, IPaySinglePayments> {

    @Value("#{jobParameters['jobid']}")
    private long jobid;

    @Override
    public IPaySinglePayments process(IPaySinglePayments item) throws Exception {
        item.setJobId(jobid);
        return item;
    }
}
