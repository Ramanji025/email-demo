package com.svb.gateway.migration.ipay.batch.util;

import com.svb.gateway.migration.common.utility.FrequencyPeriod;

import java.util.Arrays;
import java.util.List;

public class IPayConstants {
    protected static final List<Character> validFrequencies = FrequencyPeriod.validFrequencies();

    public static final String SUBSCRIBER_ID = "subscriberId";
    public static final String PAYEE_RELTNSHP_NUM = "payeeReltnshpNum";
    public static final String BENE_NICK_NAME = "beneNickName";
    public static final String BENE_ACCOUNT = "beneAccount";
    public static final String BENE_NAME = "beneName";
    public static final String BENE_ADDRESS_1 = "beneAddress1";
    public static final String BENE_ADDRESS_2 = "beneAddress2";
    public static final String PAYEE_CITY = "payeeCity";
    public static final String PAYEE_STATE = "payeeState";
    public static final String PAYEE_ZIP_CODE = "payeeZipCode";
    public static final String PAYEE_PHONE_NUM = "payeePhoneNum";
    public static final String MERCHANT_CATEGORY = "merchantCategory";
    public static final String MERCHANT_ACCOUNT_TYPE = "merchantAccountType";
    public static final String ELECTRONIC_INDICATOR = "electronicIndicator";
    public static final String CREATED_BY = "createdBy";
    public static final String ECCLIENT_ID = "ecclientId";
    public static final String BENE_BANK_IDENTIFIER = "beneBankIdentifier";
    public static final String MOVE_I_PAY_PAYEES_DATA = "moveIPayPayeesData";
    public static final String MOVE_I_PAY_SINGLE_PAYMENTS_DATA = "moveIPaySinglePaymentsData";
    public static final String MOVE_I_PAY_RECURRING_PAYMENTS_DATA = "moveIPayRecurringPaymentsData";
    public static final String MOVE_I_PAY_2_STAGE_DATA = "moveIPay2StageData";
    public static final String I_PAY_PAYEES_STEP_FLOW = "IPayPayeesStepFlow";
    public static final String I_PAY_SINGLE_PAYMENTS_STEP_FLOW = "IPaySinglePaymentssStepFlow";
    public static final String I_PAY_RECURRING_PAYMENTS_STEP_FLOW = "IPayRecurringPaymentssStepFlow";
    public static final String I_PAY_2_STAGE_STEP_FLOW = "IPay2StageStepFlow";

    public static final String PAYEE_RELATIONSHIP_NUMBER = "payeeRelationshipNumber";
    public static final String PAYMENT_AMOUNT = "paymentAmount";
    public static final String PAYMENT_DATE = "paymentDate";
    public static final String PAYMENT_ID = "paymentId";
    public static final String SUBSCRIBER_BANK_ACCT_ID = "subscriberBankAcctId";
    public static final String TRANSACTION_TYPE = "transactionType";
    public static final String BENEFICIARY_ID = "beneficiaryId";
    public static final String PAYEE_AMOUNT = "payeeAmount";
    public static final String PAYMENT_DATE_2 = "paymentDate2";
    public static final String PAYMENT_END_DATE = "paymentEndDate";
    public static final String PAYMENT_FREQUENCY = "paymentFrequency";
    public static final String EC_CLIENT_ID = "ecClientId";
    public static final String SUBSCRIBER_ACCOUNT_NUMBER = "subscriberAccountNumber";
    public static final String NUMBER_OCCURENCES_REMAING = "numberOccurencesRemaing";
    public static final String INVALID_EC_CLIENT_OR_JOB_ID = "Invalid EcClient or JobId";
    public static final String OVERRIDE_SUBS_BANK_ID = "overrideSubsBankId";
    public static final String OVERRIDE_AMOUNT = "overrideAmount";
    public static final String SKIPPED_PAYMENT = "skippedPayment";
    public static final String VALID_PAYMENT = "validPayment";
    public static final String SKIPPED_PAYMENT_VALUE = "1";
    public static final String FREQUENCY_NOT_SUPPORTED = "Frequency not supported";

    public static List<Character> getValidFrequencies(){
        return validFrequencies;
    }

}
