package com.svb.gateway.migration.ipay.batch.util;

public interface IPayQueries {

    static String getIPayPayeeQuery() {

        StringBuilder sb = new StringBuilder();
        sb.append("SELECT ");
        sb.append("mp.subscriber_id                  AS subscriberId,");
        sb.append("mp.payee_reltnshp_num             AS payeeReltnshpNum,");
        sb.append("mp.payee_nickname                 AS beneNickName,");
        sb.append("mp.payee_acct_num                 AS beneAccount,");
        sb.append("mp.payee_name                     AS beneName,");
        sb.append("mp.payee_address1                 AS beneAddress1,");
        sb.append("mp.payee_address2                 AS beneAddress2,");
        sb.append("mp.payee_city                     AS payeeCity,");
        sb.append("mp.payee_state                    AS payeeState,");
        sb.append("mp.payee_zip_code                 AS payeeZipCode,");
        sb.append("mp.payee_phone_num                AS payeePhoneNum,");
        sb.append("mp.merchant_category              AS merchantCategory,");
        sb.append("mp.merchant_account_type          AS merchantAccountType,");
        sb.append("mp.electronic_indicator           AS electronicIndicator,");
        sb.append("mp.created_by                     AS createdBy,");
        sb.append("ms.login_id                       AS ecclientId,");
        sb.append("mp.routing_number                 AS beneBankIdentifier");
        sb.append(" FROM ");
        sb.append(" mig_src_ipay_payees           mp ");
        sb.append(" JOIN mig_src_ipay_subscriber                 ms ON ms.subscriber_id = mp.subscriber_id ");
        sb.append(" WHERE ");
        sb.append("  (ms.login_id,0) in ({0}) ");
        sb.append(" and ms.active=''TRUE'' ");
        return sb.toString();
    }

    static String getIPayMergeQuery() {
        StringBuilder sb = new StringBuilder();
        sb.append("MERGE INTO gwdmg.mig_stg_ipay_payees USING dual");
        sb.append(" on (subscriber_id = :subscriberId and payee_reltnshp_num= :payeeRelationshipNumber)");
        sb.append(" WHEN MATCHED THEN");
        sb.append(" UPDATE SET beneficiary_nickname= :beneNickname,");
        sb.append("        beneficiary_account= :beneAccount,");
        sb.append("        beneficiary_name= :beneName,");
        sb.append("        beneficiary_address_1= :beneAddress1,");
        sb.append("        beneficiary_address_2= :beneAddress2,");
        sb.append("        beneficiary_address_3= :beneAddress3,");
        sb.append("        payee_city= :payeeCity,");
        sb.append("        payee_state= :payeeState,");
        sb.append("        payee_zip_code= :payeeZipCode,");
        sb.append("        payee_phone_num= :payeePhoneNum,");
        sb.append("   merchant_category= :merchantCategory,");
        sb.append("         electronic_indicator= :electronicIndicator,");
        sb.append(" merchant_account_type= :merchantAccountType,");
        sb.append("        beneficiary_bank_identifier= :beneBankIdentifier,");
        sb.append("        created_by= :createdBy,");
        sb.append("        modified_timestamp=sysdate,");
        sb.append("         ec_client_id= :ecClientId,");
        sb.append("        job_id= :jobId");
        sb.append(" WHEN NOT MATCHED THEN INSERT (");
        sb.append("subscriber_id,payee_reltnshp_num,beneficiary_nickname,beneficiary_account,");
        sb.append("beneficiary_name,beneficiary_address_1,beneficiary_address_2,beneficiary_address_3,");
        sb.append("payee_city,payee_state,payee_zip_code,payee_phone_num,merchant_category,");
        sb.append("electronic_indicator,merchant_account_type,beneficiary_bank_identifier,created_by,");
        sb.append("created_timestamp,modified_timestamp,ec_client_id, job_id");
        sb.append(") VALUES (");
        sb.append(":subscriberId,:payeeRelationshipNumber,:beneNickname,:beneAccount,:beneName,");
        sb.append(":beneAddress1,:beneAddress2,:beneAddress3,:payeeCity,:payeeState,");
        sb.append(":payeeZipCode,:payeePhoneNum,:merchantCategory,:electronicIndicator,");
        sb.append(":merchantAccountType,    :beneBankIdentifier,:createdBy, sysdate,sysdate,");
        sb.append(":ecClientId,:jobId)");
        return sb.toString();
    }

    static String getIPaySinglePaymentsSelectQuery() {

        StringBuilder sb = new StringBuilder();
        sb.append("SELECT")
                .append("        msp.payment_id                AS paymentId,")
                .append("        msp.subscriber_id             AS subscriberId,")
                .append("        msp.payee_amount              AS paymentAmount,")
                .append("        msp.payment_date              AS paymentDate,")
                .append("        msp.payee_reltnshp_num        AS payeeRelationshipNumber,")
                .append("        (select mba.bank_acct_num from gwdmg.mig_src_ipay_cnsumr_bank_accts mba where mba.subscriber_id = msp.subscriber_id and SUB_BANK_ACCT_ID= msp.subscriber_bank_acct_id and ROWNUM =1) as subscriberBankAcctId,")
                .append("        msp.created_by                AS createdBy,")
                .append("        mss.login_id                   AS ecclientId,")
                .append("        mpp.ipayee_bene_id            AS beneficiaryId,")
                .append("        (")
                .append("        SELECT")
                .append("        CASE WHEN mip.electronic_indicator = ''Y'' THEN ''ACH''")
                .append("        WHEN mip.electronic_indicator = ''N'' then ''CHK'' end")
                .append("        FROM")
                .append("        gwdmg.mig_stg_ipay_payees mip")
                .append("        WHERE")
                .append("        mip.subscriber_id = msp.subscriber_id and  mip.payee_reltnshp_num = msp.payee_reltnshp_num")
                .append("        AND ROWNUM = 1")
                .append("        ) AS transactiontype")
                .append("        FROM")
                .append("        gwdmg.mig_src_ipay_single_payments   msp")
                .append("        JOIN gwdmg.mig_stg_ipay_payees                  mpp ON mpp.subscriber_id = msp.subscriber_id and mpp.payee_reltnshp_num = msp.payee_reltnshp_num ")
                .append("        JOIN mig_src_ipay_subscriber                        mss ON mss.subscriber_id = msp.subscriber_id")
                .append("        WHERE")
                .append("        (mss.login_id,0) in ({0})")
                .append("        AND mpp.electronic_indicator IN (")
                .append("        ''Y'',''N'')")
                .append("        GROUP BY")
                .append("        msp.payment_id,")
                .append("        msp.subscriber_id,")
                .append("        msp.payee_amount,")
                .append("        msp.payment_date,")
                .append("        msp.payee_reltnshp_num,")
                .append("        msp.subscriber_bank_acct_id,")
                .append("        msp.created_by,")
                .append("        mss.login_id,")
                .append("        mpp.ipayee_bene_id");
        return sb.toString();
    }

    static String getIPaySinglePaymentMergeQuery() {
        StringBuilder sb = new StringBuilder();
        sb.append("MERGE INTO gwdmg.MIG_STG_IPAY_PAYMENTS USING dual")
                .append(" on (PAYMENT_ID = :paymentId and BENEFICIARY_ID= :beneficiaryId)")
                .append(" WHEN MATCHED THEN")
                .append(" UPDATE SET ")
                .append("        EC_CLIENT_ID= :ecClientId,")
                .append("        PAYEE_RELATIONSHIP_NUMBER= :payeeRelationshipNumber,")
                .append("        subscriber_id = :subscriberId,")
                .append("        JOB_ID= :jobId,")
                .append("        TRANSACTION_TYPE= :transactionType,")
                .append("        PAYMENT_AMOUNT= :paymentAmount,")
                .append("        PAYMENT_DATE= :paymentDate,")
                .append("        SUBSCRIBER_ACCOUNT_NUMBER= :subscriberBankAcctId,")
                .append("        MODIFIED_DATE= sysdate")
                .append("        WHEN NOT MATCHED THEN INSERT (")
                .append("        EC_CLIENT_ID,")
                .append("        SUBSCRIBER_ID,")
                .append("        BENEFICIARY_ID,")
                .append("        JOB_ID,")
                .append("        TRANSACTION_TYPE,")
                .append("        PAYMENT_AMOUNT,")
                .append("        PAYMENT_DATE, PAYEE_RELATIONSHIP_NUMBER, SUBSCRIBER_ACCOUNT_NUMBER, CREATED_BY,")
                .append("        CREATED_DATE,MODIFIED_DATE")
                .append(" ) VALUES (:ecClientId, :subscriberId, :beneficiaryId, :jobId, :transactionType, :paymentAmount, :paymentDate,")
                .append(":payeeRelationshipNumber, :subscriberBankAcctId, :createdBy, sysdate, sysdate)");
        return sb.toString();
    }

    static String getIPayRecurringSelectQuery() {
        StringBuilder sb = new StringBuilder();
        sb.append("SELECT MRP.SUBSCRIBER_ID as subscriberId,");
        sb.append("MRP.PAYEE_RELTNSHP_NUM AS payeeRelationshipNumber, Mrp.Payee_Name AS payeeName,");
        sb.append("MRP.PAYEE_AMOUNT  as payeeAmount, MRP.NEXT_PAYMENT_DATE AS paymentDate,");
        sb.append(" MRP.PAYMENT_END_DATE AS paymentEndDate,");
        sb.append("MRP.PAYMENT_FREQUENCY AS paymentFrequency, MIP.EC_CLIENT_ID AS ecClientId,");
        sb.append(" MIP.IPAYEE_BENE_ID AS beneficiaryId,");
        sb.append("(select mba.bank_acct_num from gwdmg.mig_src_ipay_cnsumr_bank_accts mba");
        sb.append("  where mba.subscriber_id = MRP.subscriber_id and MBA.SUB_BANK_ACCT_ID= MRP.subscriber_bank_acct_id and ROWNUM =1) as subscriberAccountNumber,");
        sb.append("(CASE WHEN MIP.ELECTRONIC_INDICATOR = ''Y'' THEN ''ACH''");
        sb.append("  WHEN Mip.Electronic_Indicator = ''N'' then ''CHK'' end) as transactionType,");
        sb.append("MRP.SKIPPED_PAYMENT AS skippedPayment, MRP.OVERRIDE_AMOUNT AS overrideAmount,");
        sb.append("MRP.OVERRIDE_SUBS_BANK_ID AS overrideSubsBankId, ");
        sb.append(" MRP.NUMBER_OCURNCE_REMAING AS numberOccurencesRemaing, MRP.CREATED_BY AS createdBy");
        sb.append("    FROM MIG_SRC_IPAY_RECURRING_PAYMENTS MRP JOIN MIG_STG_IPAY_PAYEES MIP");
        sb.append("  ON MIP.SUBSCRIBER_ID = MRP.SUBSCRIBER_ID AND MIP.PAYEE_RELTNSHP_NUM = MRP.PAYEE_RELTNSHP_NUM");
        sb.append("  WHERE (MIP.EC_CLIENT_ID,0) in ({0}) AND (mrp.skipped_payment = 0 OR mrp.last_business_day = ''N'')");
        return sb.toString();

    }

    static String getIPayRecurringInsert() {

        StringBuilder sb = new StringBuilder();
        sb.append(" INSERT INTO MIG_STG_IPAY_PAYMENTS (EC_CLIENT_ID, SUBSCRIBER_ID, ");
        sb.append("BENEFICIARY_ID, JOB_ID, TRANSACTION_TYPE, PAYMENT_AMOUNT,");
        sb.append(" PAYMENT_DATE, PAYEE_RELATIONSHIP_NUMBER, SUBSCRIBER_ACCOUNT_NUMBER,");
        sb.append("SKIPPED_PAYMENT, OVERRIDE_AMOUNT, OVERRIDE_SUBS_BANK_ID, ");
        sb.append("NUM_OF_OCCURENCE_REM, PAYMENT_END_DATE,");
        sb.append("PAYMENT_FREQUENCY, CREATED_BY, CREATED_DATE, MODIFIED_DATE ");
        sb.append(") VALUES (:ecClientId, :subscriberId, :beneficiaryId, :jobId, :transactionType, ");
        sb.append(":payeeAmount, :paymentDate, :payeeRelationshipNumber,");
        sb.append(":subscriberAccountNumber, :skippedPayment, :overrideAmount,");
        sb.append(":overrideSubsBankId, :numberOccurencesRemaing,");
        sb.append(":paymentEndDate, :paymentFrequency, :createdBy, sysdate, sysdate )");
        return sb.toString();
    }
}
