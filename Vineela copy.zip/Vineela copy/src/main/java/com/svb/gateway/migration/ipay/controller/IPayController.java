package com.svb.gateway.migration.ipay.controller;

import com.svb.gateway.migration.common.exception.ServiceException;
import com.svb.gateway.migration.ipay.api.IPayApi;
import com.svb.gateway.migration.ipay.batch.util.IPayConstants;
import com.svb.gateway.migration.ipay.service.IPayPayeesService;
import com.svb.gateway.migration.job.model.CreateJobResponse;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.math.NumberUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;
import springfox.documentation.annotations.ApiIgnore;

@ApiIgnore
@RestController
public class IPayController implements IPayApi {

    @Autowired
    private IPayPayeesService payeesService;

    @Override
    public ResponseEntity<Object> migrateIPay2Stage(String ecClientId, Integer jobId) throws Exception {
        if (StringUtils.isBlank(ecClientId) || NumberUtils.INTEGER_ZERO.equals(jobId)) {
            throw new ServiceException(IPayConstants.INVALID_EC_CLIENT_OR_JOB_ID);
        }
        CreateJobResponse response = payeesService.ipay2stageJobLauncher(ecClientId, Long.valueOf(jobId));
        return ResponseEntity.accepted().body(response);
    }

    @Override
    public ResponseEntity<Object> truncateIPaySourceTables() throws Exception {
        payeesService.truncateIPaySrcTables();
        return ResponseEntity.ok().build();
    }


}
