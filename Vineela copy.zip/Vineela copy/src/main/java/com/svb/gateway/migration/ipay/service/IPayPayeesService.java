package com.svb.gateway.migration.ipay.service;

import com.svb.gateway.migration.job.model.CreateJobResponse;

public interface IPayPayeesService {

    CreateJobResponse ipay2stageJobLauncher(String ecClientId, Long jobId) throws Exception ;

    void truncateIPaySrcTables();
}
