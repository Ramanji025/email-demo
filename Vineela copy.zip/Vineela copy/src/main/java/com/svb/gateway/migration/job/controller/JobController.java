package com.svb.gateway.migration.job.controller;

import com.opencsv.exceptions.CsvException;
import com.svb.gateway.migration.client.entity.MigClient;
import com.svb.gateway.migration.client.repository.MigClientRepository;
import com.svb.gateway.migration.common.exception.ServiceException;
import com.svb.gateway.migration.common.logging.Message;
import com.svb.gateway.migration.common.model.Error;
import com.svb.gateway.migration.common.utility.JobStatusEnum;
import com.svb.gateway.migration.common.utility.MigrationConstants;
import com.svb.gateway.migration.job.api.JobApi;
import com.svb.gateway.migration.job.entity.ClientEntity;
import com.svb.gateway.migration.job.entity.JobEntity;
import com.svb.gateway.migration.job.entity.MigJob;
import com.svb.gateway.migration.job.mapper.JobMapper;
import com.svb.gateway.migration.job.model.ClientEntityList;
import com.svb.gateway.migration.job.model.CreateJobResponse;
import com.svb.gateway.migration.job.model.CreateJobResponseData;
import com.svb.gateway.migration.job.model.JobResponse;
import com.svb.gateway.migration.job.repository.MigJobRepository;
import com.svb.gateway.migration.job.service.JobService;
import com.svb.gateway.migration.job.service.LoadService;
import io.swagger.v3.oas.annotations.parameters.RequestBody;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.*;

@RestController
@Log4j2
public class JobController implements JobApi {
    private final JobService jobService;
    private final LoadService loadService;
    @Autowired
    MigJobRepository migJobRepository;
    @Autowired
    MigClientRepository migClientRepository;
    @Autowired
    JobMapper jobMapper;
    @Value("${clients.threshold}")
    private int threshold;
    @Autowired
    public JobController(JobService jobService, LoadService loadService) {
        this.jobService = jobService;
        this.loadService = loadService;
    }

    @Override
    @PostMapping(value = "/job",
            produces = {"application/json"},
            consumes = {MediaType.MULTIPART_FORM_DATA_VALUE})
    @ResponseStatus(HttpStatus.OK)
    public ResponseEntity<CreateJobResponse> createJob(MultipartFile file, final String authorization) throws ServiceException, IOException {
        List<ClientEntity> migratingClients;
        CreateJobResponse response;
        Date startTime = Calendar.getInstance().getTime();
        try {
            migratingClients = jobService.parseCSVFile(file);
        }
        catch (CsvException e) {
            return handleException("Error while parsing CSV File  ==> ", e.getMessage());
        }
        catch (ServiceException  e) {
            return handleException("Service Error starting the job  ==> ", e.getErrorMessage());
        }
        catch (Exception e) {
            return handleException("Internal Server Error when starting the job  ==> ", e.getMessage());
        }
        if (migratingClients.size() > threshold) {
            Error error = new Error(HttpStatus.BAD_REQUEST.toString(), MigrationConstants.MAX_CLIENT_ERROR_MESSAGE + " " + threshold);
            response = new CreateJobResponse();
            response.setErrors(Collections.singletonList(error));
            log.warn(Message.create().descr(MigrationConstants.MAX_CLIENT_ERROR_MESSAGE + " " + threshold).operation("createJob"));
            return ResponseEntity.badRequest().body(response);
        }

        JobEntity jobEntity = jobService.createJob(migratingClients);
        jobService.createClients(migratingClients, authorization, jobEntity);
        Date endTime = Calendar.getInstance().getTime();
        long duration = (endTime.getTime() - startTime.getTime()) / 1000;
        jobEntity.setExtractionTime(duration);
        jobMapper.updateMigExtractionTime(jobEntity);
        CreateJobResponse jobResponse = new CreateJobResponse();
        jobResponse.setData(new CreateJobResponseData().jobId(jobEntity.getJobId()).status(JobStatusEnum.CREATED.name()));
        log.info(Message.create().descr("Successfully created job").jobId(jobEntity.getJobId()).status(JobStatusEnum.CREATED.name()).operation("createJob"));
        return new ResponseEntity<>(jobResponse, HttpStatus.ACCEPTED);
    }

    private ResponseEntity<CreateJobResponse> handleException(String description, String errorMessage) {
        CreateJobResponse response;
        Error error = new Error(HttpStatus.BAD_REQUEST.toString(), description + errorMessage);
        response = new CreateJobResponse();
        response.setErrors(Collections.singletonList(error));
        log.warn(Message.create().descr(description + errorMessage).operation("createJob"));
        return ResponseEntity.badRequest().body(response);
    }

    @Override
    @GetMapping(value = "/job",
            produces = {"application/json"},
            consumes = {"*/*"})
    public ResponseEntity<JobResponse> getJob(Integer jobId) throws ServiceException {

        JobResponse jobResponse = jobService.getJobById(jobId);
        if (jobResponse != null) {
            return new ResponseEntity<>(jobResponse, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }


    @Override
    @PostMapping(path = "/job/load/{jobId}",
            consumes = MediaType.ALL_VALUE, produces = {"application/json"})
    @ResponseStatus(HttpStatus.OK)
    public ResponseEntity<CreateJobResponse> loadStart(@PathVariable("jobId") Long jobId, @RequestBody ClientEntityList clientIds) throws ServiceException {

        log.debug(Message.create().descr("loadService.processJob, processJob: ").jobId(jobId));

        CreateJobResponse jobResponse = new CreateJobResponse();
        jobResponse.setData(new CreateJobResponseData().jobId(jobId).status(JobStatusEnum.MIGRATION_INPROCESS.name()));

        Map<MigJob, List<MigClient>> processResponse = loadService.validateAndPersistLoadRequest(jobId, clientIds.getClientEntityList());
        loadService.startLoad(processResponse);

        return new ResponseEntity<>(jobResponse, HttpStatus.ACCEPTED);
    }
}