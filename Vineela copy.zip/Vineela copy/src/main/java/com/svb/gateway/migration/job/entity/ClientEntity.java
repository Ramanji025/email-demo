package com.svb.gateway.migration.job.entity;

import com.svb.gateway.migration.common.processors.IRetry;
import lombok.*;

import javax.persistence.*;
import java.time.OffsetDateTime;

@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode
@ToString
@Setter
@Getter
@Entity
@Table(name = "MIG_CLIENT")
@Deprecated
public class ClientEntity implements IRetry {


    @Id
    @Column(name = "ECCLIENTID")
    private String eCClientId;
    @Transient
    private Integer migClientId;
    @Column(name = "JOBID")
    private Long jobId;
    @Column(name = "GWCLIENTID")
    private String gWClientId;
    @Column(name = "CLIENTNAME")
    private String clientName;
    @Column(name = "COMPANYID")
    private String companyId;
    @Column(name = "PRIMARYCIFUBS")
    private Integer primaryCifUbs;
    @Column(name = "PRIMARYCIFCBS")
    private Integer primaryCifCbs;
    @Column(name = "COMMENTS")
    private String comments;
    @Column(name = "STATUS")
    private String status;
    @Column(name = "UPDATEDBY")
    private String updatedBy;
    @Column(name = "UPDATEDDATE")
    private OffsetDateTime updatedDate;
    @Column(name = "BDCSTATUS")
    private Integer bdcStatus;
}
