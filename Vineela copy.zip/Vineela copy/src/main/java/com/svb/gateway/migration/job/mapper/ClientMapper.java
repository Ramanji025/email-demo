package com.svb.gateway.migration.job.mapper;

import com.svb.gateway.migration.client.entity.MigClient;
import com.svb.gateway.migration.client.model.ClientDTO;
import com.svb.gateway.migration.job.entity.ClientEntity;
import org.apache.ibatis.annotations.*;
import org.springframework.stereotype.Repository;

import java.util.List;

@Mapper
@Repository
public interface ClientMapper {

    @Select(value = {
            "SELECT",
            "JOBID, ECCLIENTID, GWCLIENTID, CLIENTNAME, COMPANYID, PRIMARYCIFUBS, PRIMARYCIFCBS, COMMENTS, STATUS, UPDATEDBY, UPDATEDDATE",
            "FROM",
            "GWDMG.MIG_CLIENT",
            "WHERE",
            "JOBID = #{jobId}"
    })
    List<ClientEntity> getClientsByJobId(@Param("jobId") Integer jobId);

    @Select(value = {
            "SELECT",
            "JOBID, ECCLIENTID, GWCLIENTID, CLIENTNAME, COMPANYID, PRIMARYCIFUBS, PRIMARYCIFCBS, COMMENTS, STATUS, UPDATEDBY, UPDATEDDATE",
            "FROM",
            "GWDMG.MIG_CLIENT",
            "WHERE",
            "JOBID = #{jobId} AND ECCLIENTID= #{ecClientId}"
    })
    ClientEntity getClient(@Param("jobId") Long jobId, @Param("ecClientId") String ecClientId);

    @Insert(value = {
            "INSERT INTO",
            "GWDMG.MIG_CLIENT",
            "(JOBID, ECCLIENTID, COMPANYID, STATUS, UPDATEDBY, UPDATEDDATE)",
            "VALUES",
            "(#{jobId}, #{eCClientId}, #{companyId}, #{status}, 'MigrationUser', sysdate)"
    })
    @Options(useGeneratedKeys = true, keyProperty = "migClientId", keyColumn = "MIGCLIENTID")
    Integer InsertMigratingClient(ClientEntity client);

    default void InsertMigratingClients(List<ClientEntity> migratingClients) {
        for (ClientEntity client : migratingClients) {
            InsertMigratingClient(client);
        }
    }

    @Update(value = "UPDATE GWDMG.MIG_CLIENT SET PRIMARYCIFUBS = #{primaryCifUbs}, " +
            "PRIMARYCIFCBS= #{primaryCifCbs}, CLIENTNAME = #{clientName}, ECCLIENTID = #{ecClientId}, GWCLIENTID= #{gwClientId}, " +
            "STATUS = #{status}, COMPANYID = #{companyId}, COMMENTS = #{comments}, UPDATEDDATE=sysdate WHERE JOBID= #{jobId} AND ECCLIENTID= #{ecClientId}")
    void updateClient(MigClient migClient);

    @Update(value = "UPDATE GWDMG.MIG_CLIENT SET STATUS = #{status}, COMMENTS = #{comments}, UPDATEDDATE=sysdate WHERE ECCLIENTID= #{ecClientId} AND JOBID= #{jobId}")
    void updateClientStatus(MigClient migClient);

    @Update(value = "UPDATE GWDMG.MIG_CLIENT SET BDCSTATUS = #{bdcStatus} WHERE ECCLIENTID= #{ecClientId} AND JOBID= #{jobId}")
    void updateClientBdcStatus(MigClient migClient);

}
