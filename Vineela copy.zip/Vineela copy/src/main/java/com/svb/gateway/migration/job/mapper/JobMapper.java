package com.svb.gateway.migration.job.mapper;

import com.svb.gateway.migration.client.entity.MigClient;
import com.svb.gateway.migration.job.entity.JobEntity;
import com.svb.gateway.migration.job.entity.MigJob;
import org.apache.ibatis.annotations.*;
import org.springframework.stereotype.Repository;

@Mapper
@Repository
public interface JobMapper {

    @Select(value = {
            "SELECT",
                "JOBID, TYPE, STARTTIME, ENDTIME, CANDIDATECOUNT, STATUS, UPDATEDBY, UPDATEDDATE",
            "FROM",
                "GWDMG.MIG_JOB",
            "WHERE",
                "JOBID = #{jobId}"
    })
    JobEntity readMigrationJob(@Param("jobId") Integer jobId);

    @Insert(value = {
            "INSERT INTO",
            "GWDMG.MIG_JOB",
            "(TYPE, STARTTIME, CANDIDATECOUNT, STATUS, UPDATEDBY, UPDATEDDATE)",
            "VALUES",
            "(#{type}, #{startTime}, #{candidateCount}, #{status}, #{updatedBy}, #{startTime})"
    })
    @Options(useGeneratedKeys = true, keyProperty = "jobId", keyColumn = "jobId")
    Integer insertJob(JobEntity jobEntity);

    @Update(value = {"UPDATE GWDMG.MIG_JOB SET STATUS = #{status}, ENDTIME = #{endTime}, EXTRACTIONTIME = #{ExtractionTime}, UPDATEDDATE = #{updatedDate} where JOBID= #{jobId}"})
    Integer updateJob(JobEntity jobEntity);

    @Update(value = {"UPDATE GWDMG.MIG_JOB SET EXTRACTIONTIME = #{extractionTime} where JOBID = #{jobId}"})
    Integer updateMigExtractionTime(JobEntity jobEntity);
}