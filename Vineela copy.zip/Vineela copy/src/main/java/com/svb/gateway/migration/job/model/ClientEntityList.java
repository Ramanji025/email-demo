package com.svb.gateway.migration.job.model;

import java.util.List;

public class ClientEntityList {

    List<String> clientEntityIdList ;

    public List<String> getClientEntityList() {
        return clientEntityIdList;
    }

    public void setClientEntityList(List<String> clientEntityIdList) {
        this.clientEntityIdList = clientEntityIdList;
    }
}