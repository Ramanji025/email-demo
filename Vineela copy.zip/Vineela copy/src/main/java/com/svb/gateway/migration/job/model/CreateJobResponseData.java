package com.svb.gateway.migration.job.model;

import com.fasterxml.jackson.annotation.*;
import io.swagger.annotations.ApiModelProperty;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotNull;
import java.util.HashMap;
import java.util.Map;

@JsonInclude(JsonInclude.Include.NON_NULL)
@NoArgsConstructor
public class CreateJobResponseData {
    @JsonProperty("JobId")
    private Long jobId;

    @JsonProperty("Status")
    private String status;

    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<>();

    public CreateJobResponseData(Long jobId, String status) {
        this.jobId = jobId;
        this.status = status;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public CreateJobResponseData jobId(Long jobId) {
        this.jobId = jobId;
        return this;
    }

    @ApiModelProperty(required = true, value = ".")
    @NotNull
    public Long getJobId() {
        return jobId;
    }

    public void setJobId(Long jobId) {
        this.jobId = jobId;
    }

    public CreateJobResponseData status (String status) {
        this.status = status;
        return this;
    }

    @ApiModelProperty(required = true, value = ".")
    @NotNull
    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

}
