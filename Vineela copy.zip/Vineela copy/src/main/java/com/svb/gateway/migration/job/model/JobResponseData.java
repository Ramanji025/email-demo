package com.svb.gateway.migration.job.model;

import com.fasterxml.jackson.annotation.*;
import io.swagger.annotations.ApiModelProperty;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotNull;
import java.time.OffsetDateTime;
import java.util.HashMap;
import java.util.Map;

@JsonInclude(JsonInclude.Include.NON_NULL)
@NoArgsConstructor
public class JobResponseData {
    @JsonProperty("JobId")
    private Long jobId;

    @JsonProperty("Status")
    private String status;

    @JsonProperty("JobType")
    private String jobType;

    @JsonProperty("StartTime")
    private String startTime;

    @JsonProperty("EndTime")
    private String endTime;

    @JsonProperty("CandidateCount")
    private String candidateCount;

    @JsonProperty("UpdatedBy")
    private String updatedBy;

    @JsonProperty("UpdatedDate")
    private String updatedDate;

    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<>();

    public JobResponseData(Long jobId, String status) {
        this.jobId = jobId;
        this.status = status;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public JobResponseData jobId(Long jobId) {
        this.jobId = jobId;
        return this;
    }

    @ApiModelProperty(required = true, value = ".")
    @NotNull
    public Long getJobId() {
        return jobId;
    }

    public void setJobId(Long sessionId) {
        this.jobId = sessionId;
    }


    public JobResponseData startTime (String startTime) {
        this.startTime = startTime;
        return this;
    }
    @ApiModelProperty(required = true, value = ".")
    @NotNull
    public String getStartTime() {
        return startTime;
    }

    public void setStartTime(String startTime) {
        this.startTime = startTime;
    }



    public JobResponseData endTime (String endTime) {
        this.endTime = endTime;
        return this;
    }
    @ApiModelProperty(required = true, value = ".")
    @NotNull
    public String getEndTime() {
        return endTime;
    }

    public void setEndTime(String endTime) {
        this.endTime = endTime;
    }



    public JobResponseData updatedDate (String updatedDate) {
        this.updatedDate = updatedDate;
        return this;
    }
    @ApiModelProperty(required = true, value = ".")
    @NotNull
    public String getUpdatedDate() {
        return updatedDate;
    }

    public void setUpdatedDate(String updatedDate) {
        this.updatedDate = updatedDate;
    }




    public JobResponseData updatedBy (String updatedBy) {
        this.updatedBy = updatedBy;
        return this;
    }
    @ApiModelProperty(required = true, value = ".")
    @NotNull
    public String getUpdatedBy() {
        return updatedBy;
    }

    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }


    public JobResponseData jobType (String jobType) {
        this.jobType = jobType;
        return this;
    }
    @ApiModelProperty(required = true, value = ".")
    @NotNull
    public String getJobType() {
        return jobType;
    }

    public void setJobType(String jobType) {
        this.jobType = jobType;
    }

    public JobResponseData status (String status) {
        this.status = status;
        return this;
    }

    @ApiModelProperty(required = true, value = ".")
    @NotNull
    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
