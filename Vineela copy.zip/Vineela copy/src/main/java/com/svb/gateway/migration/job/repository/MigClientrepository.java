package com.svb.gateway.migration.job.repository;

import com.svb.gateway.migration.job.entity.ClientEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.Collection;
import java.util.List;
import java.util.Set;


@Repository
public interface MigClientrepository extends JpaRepository<ClientEntity, Integer> {

    @Query(value = "SELECT count(X) FROM ClientEntity X WHERE X.status <> :status AND X.eCClientId IN :ecIds")
    Long findClientEntities(@Param("ecIds") Set<String> ecClientIds, @Param("status") String status);
}
