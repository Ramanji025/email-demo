package com.svb.gateway.migration.job.service;

import com.opencsv.exceptions.CsvException;
import com.svb.gateway.migration.common.constants.MigrationConstants;
import com.svb.gateway.migration.common.exception.ServiceException;
import com.svb.gateway.migration.common.logging.Message;
import com.svb.gateway.migration.common.service.RetryService;
import com.svb.gateway.migration.common.utility.CSVUtilities;
import com.svb.gateway.migration.common.utility.GlobalUtilty;
import com.svb.gateway.migration.common.utility.JobStatusEnum;
import com.svb.gateway.migration.common.utility.MigrationTypeEnum;
import com.svb.gateway.migration.ec2stage.controller.EC2StageController;
import com.svb.gateway.migration.ec2stage.model.Ec2StageMigrationRequest;
import com.svb.gateway.migration.ipay.service.IPayPayeesService;
import com.svb.gateway.migration.job.entity.ClientEntity;
import com.svb.gateway.migration.job.entity.JobEntity;
import com.svb.gateway.migration.job.mapper.ClientMapper;
import com.svb.gateway.migration.job.mapper.JobMapper;
import com.svb.gateway.migration.job.model.JobResponse;
import com.svb.gateway.migration.job.model.JobResponseData;
import com.svb.gateway.migration.job.repository.MigClientrepository;
import lombok.extern.log4j.Log4j2;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.util.*;
import java.util.stream.Collectors;

@Service
@Log4j2
public class JobService {

    @Value("${migration.service.user-id}")
    public String MIGRATION_USER_ID;
    @Value("${mig.ec.stage.url}")
    public String migStageUrl;
    @Value("${mig.admext.base.host}")
    public String admextBaseHost;
    static final String companyIdCheckEndpoint = "/adminext/v1/clients/";
    static final String protocol = "https";
    @Value("${migration.service.maxCompanyIdRetries:3}")
    private Integer maxCompanyIdAttempts;
    @Value("${migration.company.id.length.max}")
    private Integer COMPANY_ID_LENGTH_MAX;
    @Value("3")
    private Integer COMPANY_ID_LENGTH_MIN;
    @Value("${migration.ecclient.id.length}")
    private Integer EC_CLIENT_ID_LENGTH;
    private final JobMapper jobMapper;
    private final MigClientrepository clientrepository;
    private final ClientMapper clientMapper;
    private final IPayPayeesService iPayPayeesService;


    @Autowired
    protected RetryService retryService;

    @Autowired
    private EC2StageController eC2StageController;
    private Random randomGenerator=new Random();

    @Autowired
    public JobService(JobMapper jobMapper, MigClientrepository clientrepository, ClientMapper clientMapper, IPayPayeesService iPayPayeesService) {
        this.jobMapper = jobMapper;
        this.clientrepository = clientrepository;
        this.clientMapper = clientMapper;
        this.iPayPayeesService = iPayPayeesService;
    }

    @Transactional(rollbackFor = {RuntimeException.class, ServiceException.class})
    public JobEntity createJob(List<ClientEntity> migratingClients) {
        JobEntity jobEntity = new JobEntity();
        jobEntity.setType(MigrationTypeEnum.CLIENT_MIGRATION);
        jobEntity.setCandidateCount(migratingClients.size());
        jobEntity.setStatus(JobStatusEnum.CREATED);
        jobEntity.setUpdatedBy(MIGRATION_USER_ID);
        jobEntity.setStartTime(OffsetDateTime.now().withOffsetSameInstant(ZoneOffset.UTC));
        jobMapper.insertJob(jobEntity);
        return jobEntity;
    }

    @Async
    public void createClients(List<ClientEntity> migratingClients, String authorization, JobEntity jobEntity) {
        migratingClients.parallelStream().forEach(entity -> {
            entity.setJobId(jobEntity.getJobId());
            entity.setStatus(MigrationConstants.STATUS_CREATED);
            entity.setUpdatedBy(MIGRATION_USER_ID);
            entity.setUpdatedDate(OffsetDateTime.now());
        });
        clientMapper.InsertMigratingClients(migratingClients);
        Ec2StageMigrationRequest ec2Request = new Ec2StageMigrationRequest(migratingClients.stream()
                .map(ClientEntity::getECClientId).collect(Collectors.toList()), jobEntity.getJobId());
        try {
            eC2StageController.migrateEc2StageInternal(ec2Request);
            String clientIds = GlobalUtilty.getClientIds(migratingClients);
            iPayPayeesService.ipay2stageJobLauncher(clientIds, jobEntity.getJobId());
        } catch (Exception exception) {
            log.error(Message.create().descr("Exception occurred while extraction API invocation reason" + exception.getMessage()));
        }
    }

    public JobResponse getJobById(Integer jobId) {
        JobResponse jobResponse= new JobResponse();
        JobResponseData jobResponseData = new JobResponseData();
        JobEntity job = jobMapper.readMigrationJob(jobId);
        if(null!= job) {
            jobResponseData.setJobId(job.getJobId());
            jobResponseData.setJobType(job.getType().name());
            if (null != job.getEndTime()) jobResponseData.setEndTime(job.getEndTime().toString());
            jobResponseData.setStartTime(job.getStartTime().toString());
            jobResponseData.setUpdatedBy(job.getUpdatedBy());
            jobResponseData.setUpdatedDate(job.getUpdatedDate().toString());
            jobResponseData.setStatus(job.getStatus().name());
        }
        jobResponse.setData(jobResponseData);
        return jobResponse;
    }

    public List<ClientEntity> parseCSVFile(final MultipartFile file) throws ServiceException, IOException, CsvException {
        List<String[]> csvBeans = CSVUtilities.csvtoBeans(file);
        final List<ClientEntity> clients = new ArrayList<>();
        final Map<String, String> clientsMap = new HashMap<>();
        if (csvBeans.isEmpty()) {
            throw new ServiceException("CSV_FILE_SHOULD_NOT_BE_EMPTY");
        }
        for (String[] cs : csvBeans) {
            String ecClientId = cs[0];
            if (StringUtils.isBlank(ecClientId)) {
                throw new ServiceException("Error record EcclientId -->" + ecClientId);
            }
            String companyId = getCompanyId(ecClientId);
            //Preparing a map to identify the duplicate ecClientId or Company Id
            if (clientsMap.containsKey(ecClientId) || clientsMap.containsValue(companyId)) {
                throw new ServiceException("Duplicate record in CSV file " + ecClientId + " and " + companyId);
            } else {
                clientsMap.put(ecClientId, companyId);
            }
            if (companyId.length() > COMPANY_ID_LENGTH_MAX || companyId.length() < COMPANY_ID_LENGTH_MIN) {
                throw new ServiceException("Company Id length should be between "
                        + COMPANY_ID_LENGTH_MIN +" and "+COMPANY_ID_LENGTH_MAX);
            }
            if (ecClientId.length() != EC_CLIENT_ID_LENGTH) {
                throw new ServiceException("EcClient Id length should be " + EC_CLIENT_ID_LENGTH);
            }
            final ClientEntity client = new ClientEntity();
            client.setECClientId(ecClientId);
            client.setCompanyId(companyId);
            clients.add(client);
            log.info(Message.create().clientId(ecClientId).append("companyId",companyId).descr("set companyId").operation("parseCSVFile"));
        }
        Long existing = clientrepository.findClientEntities(clientsMap.keySet(), MigrationConstants.STATUS_ROLLED_BACK);
        if (existing>0) {
            throw new ServiceException(existing+ " client(s) is/are already migrated or not rolled back ");
        }

        return clients;
    }

    String getCompanyId(String ecClientId) throws ServiceException {
        int attempts=1;
        // start by trying to use the ecClientId as companyId
        String companyId = ecClientId;
        while(!companyIdIsUnique(companyId) && attempts <= maxCompanyIdAttempts) {
            if(++attempts > maxCompanyIdAttempts){
                throw new ServiceException("too many attempts to produce a companyId for "+ ecClientId);
            }
            companyId = generateCompanyId(ecClientId);
        }
        return companyId;
    }

    String generateCompanyId(String ecClientId) {
        String randomString = String.valueOf(randomGenerator.nextInt(10000));
        String suffix = "0000".substring(randomString.length())+randomString;
        return ecClientId.substring(0,4)+suffix;
    }

    private boolean companyIdIsUnique(String companyId ) {
        HttpHeaders headers = new HttpHeaders();
        headers.add(MigrationConstants.CONTENT_TYPE, MigrationConstants.APPLICATION_HEADER_JSON);
        HttpEntity<?> requestEntity = new HttpEntity<>(headers);
        ResponseEntity<String> beneficiaryInfoResponseEntity = retryService.exchange(
                protocol+"://"+admextBaseHost+companyIdCheckEndpoint+companyId, HttpMethod.GET, requestEntity, new ParameterizedTypeReference<String>() {});
        String isUniqueString = beneficiaryInfoResponseEntity.getBody();
        return Boolean.valueOf(isUniqueString);
    }

}
