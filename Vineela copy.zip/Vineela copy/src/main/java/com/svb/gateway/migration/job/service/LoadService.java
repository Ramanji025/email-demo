package com.svb.gateway.migration.job.service;

import com.svb.gateway.migration.alerts.service.AlertsService;
import com.svb.gateway.migration.beneficiaries.repository.BeneficiaryRepository;
import com.svb.gateway.migration.beneficiaries.service.BeneficiariesService;
import com.svb.gateway.migration.cards.service.CardsService;
import com.svb.gateway.migration.client.entity.MigClient;
import com.svb.gateway.migration.client.model.EnrollClientResponse;
import com.svb.gateway.migration.client.repository.MigClientRepository;
import com.svb.gateway.migration.client.service.ClientService;
import com.svb.gateway.migration.common.exception.ServiceException;
import com.svb.gateway.migration.common.logging.Message;
import com.svb.gateway.migration.common.utility.EcClientIdCheck;
import com.svb.gateway.migration.common.utility.JobStatusEnum;
import com.svb.gateway.migration.job.entity.MigJob;
import com.svb.gateway.migration.job.repository.MigJobRepository;
import com.svb.gateway.migration.nickname.service.NicknameService;
import com.svb.gateway.migration.payments.service.IpayPaymentService;
import com.svb.gateway.migration.payments.service.TransferService;
import com.svb.gateway.migration.user.repository.UserRepository;
import com.svb.gateway.migration.user.service.UserService;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

import static com.google.common.base.Preconditions.checkArgument;
import static com.svb.gateway.migration.beneficiaries.entity.StgToTargetBeneEntity.PAYEE_TYPE.*;
import static com.svb.gateway.migration.common.constants.MigrationConstants.*;

@Service
@EnableAsync
@Log4j2
public class LoadService {

    @Autowired
    MigJobRepository migJobRepository;
    @Autowired
    MigClientRepository migClientRepository;
    @Autowired
    UserRepository userRepository;
    @Autowired
    ClientService clientService;
    @Autowired
    UserService userService;
    @Autowired
    CardsService cardsService;
    @Autowired
    AlertsService alertsService;
    @Autowired
    NicknameService nicknameService;
    @Autowired
    BeneficiariesService beneficiariesService;
    @Autowired
    BeneficiaryRepository beneficiaryRepository;

    @Autowired
    private IpayPaymentService ipayPaymentService;
    @Autowired
    private TransferService transferService;

    public Map<MigJob, List<MigClient>> validateAndPersistLoadRequest(Long jobId, List<String> selectClients) throws ServiceException {

        checkArgument(jobId != null, "jobId must not be null");
        MigJob job = migJobRepository.findByJobIdOkToLoad(jobId);

        checkArgument(job != null, "invalid jobId provided");
        //Retrieve all the Clients from MIG_CLIENT table for that JOB-ID
        List<MigClient> jobClients = migClientRepository.findByJobId(jobId);
        checkArgument(jobClients != null, "job does not have any associated client");

        List<MigClient> filteredClients = null;
        if (null != selectClients) {
            filteredClients = jobClients.stream()
                    .filter(client -> selectClients.contains(client.getEcClientId()))
                    .collect(Collectors.toList());
            for (String ecClientId : selectClients) {
                EcClientIdCheck.ecClientIdFormatCheck(ecClientId);
            }
        } else
            filteredClients = jobClients;
        //If the Job Status is extraction Extraction-Complete, change the status to "Migration-Inprogress"
        job.setStatus(JobStatusEnum.MIGRATION_INPROCESS.name());
        migJobRepository.saveAndFlush(job);
        return Map.of(job, filteredClients);
    }


    //@Async
    //@Transactional
    public void startLoad(Map<MigJob, List<MigClient>> jobClients) {
        log.info(Message.create().descr("Load started"));
        MigJob job = jobClients.keySet().stream().findFirst().orElse(null);
        if (null == job) {log.warn(Message.create().descr("exiting load as job is null / invalid")); return;}

        Date startTime = Calendar.getInstance().getTime();

        try{
            List<MigClient> selectClients = null;
            selectClients = jobClients.get(job);
            for (MigClient client : selectClients) {
                if (enrollClient(job.getJobId(), client)) {
                    // only continue with a client if the client enrollment is successful
                    processAddCardProgram(job.getJobId(), client);
                    processAddUser(job.getJobId(), client);
                    processAddCardUserUpdate(job.getJobId(), client);
                    processWireBeneficiaries(job.getJobId(), client);
                    processTransfers(job.getJobId(), client);
                    processWireOutgoing(job.getJobId(),client);
                    processNickName(job.getJobId(),client);
                    processAlerts(job.getJobId(),client);
                    if (validateAndProcessPartnerRegistration(client, job.getJobId())) {
                        processIpayBeneficiaries(job.getJobId(), client);
                        processIpayPayments(job.getJobId(),client);
                    }
                }
            }
        } catch (Exception e){
            log.error(Message.create().descr("load job encountered exception reason"+ e.getMessage()));
        } finally {
            job.setStatus(JobStatusEnum.MIGRATION_COMPLETED.name());
            Date endTime = Calendar.getInstance().getTime();
            long duration = (endTime.getTime() - startTime.getTime()) / 1000;
            job.setLoadTime(duration);
            migJobRepository.save(job);
        }
        log.info(Message.create().descr("Load Completed"));
    }

    private boolean validateAndProcessPartnerRegistration(MigClient migClient, Long jobId) throws InterruptedException {
        Message bdcLog = Message.create().clientId(migClient.getEcClientId()).jobId(jobId);
        boolean status=clientService.processPartnerRegistrationStatus(migClient.getEcClientId(), jobId);
        if(!status){
            //update BDC status for client and User
            log.error(bdcLog.descr(" BDC registration is not completed, cannot process Ipay bene and Payments"));
        }
        return status;
    }

    private boolean enrollClient(Long jobId, MigClient client) {
        try {
            EnrollClientResponse enrollClientResponse = clientService.enrollClient(client, jobId);
            return enrollClientResponse.getData().getStatus().equals(STATUS_SUCCESS);
        } catch (Exception e) {
            log.error(Message.create().descr("enrollClient failed reason" + e.getMessage() ).clientId(client.getEcClientId()).jobId(jobId));

        }
        return false;
    }

    private void processAddCardProgram(Long jobId, MigClient mc){
        try{
            cardsService.addCardProgramToClient(jobId, mc);
        } catch(Exception e){
            log.error(Message.create().descr("Add cardProgram Errored "+ e.getMessage()).clientId(mc.getEcClientId()).jobId(jobId));
        }
    }

    private void processAddUser(Long jobId, MigClient mc) {
        try {
            userService.createUsers(jobId, mc);
        } catch (Exception e) {
            log.error(Message.create().descr("Add Users Errored  "+e.getMessage()).clientId(mc.getEcClientId()).jobId(jobId));
        }
    }

    private void processAddCardUserUpdate(Long jobId, MigClient mc) {
            try {
                userService.updateCardUserId(jobId, mc.getEcClientId());
            } catch (Exception e) {
                log.error(Message.create().descr("Add Users Errored  "+e.getMessage()).clientId(mc.getEcClientId()).jobId(jobId));
            }
       }

    private List<String> processWireBeneficiaries(Long jobId, MigClient mc) {
        List<String> statusList = new ArrayList<>();
        try {
            beneficiariesService.addBeneficiaries(jobId, mc, TEMPLATE);
            beneficiariesService.addBeneficiaries(jobId, mc, FUTURE);

        } catch (Exception e) {
            log.error(Message.create().descr("Beneficiary's insertion errored for that clientId "+e).clientId(mc.getEcClientId()));
            statusList.add(STATUS_FAILURE);
        }
        return statusList;
    }

    private List<String> processIpayBeneficiaries(Long jobId, MigClient mc) {
        List<String> statusList = new ArrayList<>();
        try {
            beneficiariesService.addBeneficiaries(jobId, mc, CHECK);
            beneficiariesService.addBeneficiaries(jobId, mc, ACH);
            beneficiariesService.addBeneficiaries(jobId, mc, ACH_LARGE);

        } catch (Exception e) {
            log.error(Message.create().descr("Beneficiary's insertion errored ").clientId( mc.getEcClientId()).jobId(jobId));
            statusList.add(STATUS_FAILURE);
        }
        return statusList;
    }

    private void processWireOutgoing(Long jobId, MigClient mc) {
        try {
            transferService.wireTransfer(jobId, mc);

        } catch (Exception e) {
            log.error(Message.create().descr("wireoutgoing insertion errored  "+e.getMessage()).clientId( mc.getEcClientId()).jobId(mc.getJobId()));
        }
    }

    private void processNickName(Long jobId, MigClient mc) {
        try {
            nicknameService.migrateAccountNickname(jobId, mc);

        } catch (Exception e) {
            log.error(Message.create().descr("NickName insertion errored  "+e.getMessage()).clientId( mc.getEcClientId()).jobId(mc.getJobId()));
        }
    }

    private void processAlerts(Long jobId, MigClient mc) {
        try {
            alertsService.registerAlerts(jobId, mc);

        } catch (Exception e) {
            log.error(Message.create().descr("Alerts insertion errored  "+e.getMessage()).clientId( mc.getEcClientId()).jobId(mc.getJobId()));
        }
    }

    private void processTransfers(Long jobId, MigClient mc) {
        try {
            transferService.internalTransfer(jobId, mc);

        } catch (Exception e) {
            log.error(Message.create().descr("transfer's insertion errored  "+e.getMessage()).clientId( mc.getEcClientId()).jobId(mc.getJobId()));
        }
    }

    private void processIpayPayments(Long jobId, MigClient mc) {
        try {
            ipayPaymentService.createPayments(jobId, mc.getEcClientId());
        } catch (Exception e) {
            log.error(Message.create().descr("IPay Payments insertion errored ").clientId(mc.getEcClientId()).jobId(mc.getJobId()));
        }
    }

}



