package com.svb.gateway.migration.nickname.controller;

import com.svb.gateway.migration.client.entity.MigClient;
import com.svb.gateway.migration.client.model.MigClientDTO;
import com.svb.gateway.migration.common.exception.ServiceException;
import com.svb.gateway.migration.nickname.api.NicknameApi;
import com.svb.gateway.migration.nickname.model.NicknameResponse;
import com.svb.gateway.migration.nickname.service.NicknameService;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;
import springfox.documentation.annotations.ApiIgnore;

@ApiIgnore
@RestController
public class NicknameController implements NicknameApi {

    NicknameService nicknameService;

    @Autowired
    public NicknameController(NicknameService nicknameService){
        this.nicknameService = nicknameService;
    }

    @Override
    @PostMapping(path = "/" +
            "{jobId}",
            consumes = MediaType.ALL_VALUE, produces = {"application/json"})
    public ResponseEntity<NicknameResponse> migrateAccountNicknames(Long jobId, MigClientDTO migClientDTO)  {
        try {
            MigClient migClient=new MigClient();
            BeanUtils.copyProperties(migClientDTO,migClient);
            return new ResponseEntity<>(nicknameService.migrateAccountNickname(jobId,migClient), HttpStatus.OK);
        } catch (ServiceException e) {
            return new ResponseEntity<>(toErrorMessage(e.getMessage()), HttpStatus.BAD_REQUEST);
        }
    }

    private NicknameResponse toErrorMessage(String message) {
        NicknameResponse nicknameResponse = new NicknameResponse();
        nicknameResponse.setMessage(message);
        return nicknameResponse;
    }
}
