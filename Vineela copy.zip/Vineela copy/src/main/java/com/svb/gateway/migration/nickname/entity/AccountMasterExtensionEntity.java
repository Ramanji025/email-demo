package com.svb.gateway.migration.nickname.entity;
import lombok.*;

import java.time.LocalDateTime;


@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode
@ToString
@Setter
@Getter
public class AccountMasterExtensionEntity {

    private Integer dbTs;
    private String bankId;
    private String branchId;
    private String acid;
    private String bayUserId;
    private String acNicName;
    private Integer minPrefBal;
    private Integer largeCreditBal;
    private Integer largeDebitBal;
    private String traceAc;
    private String delFlg;
    private String RModId;
    private LocalDateTime RModTime;
    private String RCreId;
    private LocalDateTime RCreTime;
    private String userBankId;

}
