package com.svb.gateway.migration.nickname.entity;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.time.LocalDateTime;

@ToString
@Getter
@Setter
@Entity
@Table(schema = "GWDMG", name = "MIG_STG_ACCOUNT_NICK_NAME")
@Data
public class Nicknames {

    @Column(name = "OLB_CLIENT_ID")
    private String olbClientId;

    @Column(name = "ACC_TITLE")
    private String accTitle;

    @Column(name ="PROD_DESC")
    private String prodDesc;

    @Id
    @Column(name ="ACCOUNT_NUMBER")
    private String accountNumber;

    @Column(name = "MODIFIED_BY_USER")
    private String modifiedByUser;

    @Column(name = "UPDATED_BY")
    private String updatedBy;

    @Column(name = "CREATED_BY")
    private String createdBy;

    @Column(name = "CREATED_DT")
    private LocalDateTime createdDt;

    @Column(name = "MODIFIED_DT")
    private LocalDateTime modifiedDt;

    @Column(name = "ACCT_STATUS")
    private Integer acctStatus;

    @Column(name = "JOB_ID")
    private String jobId;

    @Column(name = "REMARKS")
    private String remarks ;

}
