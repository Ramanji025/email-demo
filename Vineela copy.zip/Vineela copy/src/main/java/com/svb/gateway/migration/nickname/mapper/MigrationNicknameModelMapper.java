package com.svb.gateway.migration.nickname.mapper;

import com.svb.gateway.migration.client.entity.MigClient;
import com.svb.gateway.migration.common.constants.MigrationConstants;
import com.svb.gateway.migration.common.utility.DateUtility;
import com.svb.gateway.migration.nickname.entity.MigratedNicknamesEntity;
import com.svb.gateway.migration.nickname.entity.MigrationNickname;
import com.svb.gateway.migration.nickname.entity.Nicknames;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import java.time.LocalDateTime;


@Mapper(componentModel="spring")
public interface MigrationNicknameModelMapper {

    MigrationNicknameModelMapper INSTANCE = Mappers.getMapper(MigrationNicknameModelMapper.class);
    public static String SPECIAL_CHARACTER_IGNORE_STATUS=MigrationConstants.STATUS_IGNORE;
    public static String SPECIAL_CHARACTER_IGNORE_MESSAGE="Record is ignored for migration due to special characters in nickname";


    @Mapping(source="nickname.olbClientId",target="ecClientId")
    @Mapping(expression="java(determineDuplicateStatus(migratedNickname))",target="status" )
    @Mapping(expression="java(addComments(migratedNickname))",target="comments" )
    @Mapping(constant= "svc.gateway.migration",target="updatedBy")
    @Mapping(expression= "java(getPSTDate())",target="updatedDate")
    @Mapping(source="migratedNickname.gw_Client_Id",target="gwClientId")
    @Mapping(source="migratedNickname.account_Number",target="accountNumber")
    @Mapping(source="migratedNickname.account_Nickname",target="accountNickname")
    @Mapping(source="nickname.jobId",target="jobId")
    @Mapping(source="migratedNickname.cif_Number", target="cifNumber")
    MigrationNickname mapAlreadyMigratedNicknameToEntity(Nicknames nickname, MigratedNicknamesEntity migratedNickname);

    @Mapping(source="nickname.olbClientId",target="ecClientId")
    @Mapping(constant=SPECIAL_CHARACTER_IGNORE_STATUS,target="status" )
    @Mapping(constant=SPECIAL_CHARACTER_IGNORE_MESSAGE,target="comments" )
    @Mapping(constant= "svc.gateway.migration",target="updatedBy")
    @Mapping(expression= "java(getPSTDate())",target="updatedDate")
    @Mapping(source="migClient.gwClientId",target="gwClientId")
    @Mapping(source="nickname.accountNumber",target="accountNumber")
    @Mapping(source="nickname.accTitle",target="accountNickname")
    @Mapping(source="nickname.jobId",target="jobId")
    @Mapping(source="migClient.primaryCifUbs", target="cifNumber")
    MigrationNickname mapIgnoredNicknameToEntity(Nicknames nickname,MigClient migClient);

    @Mapping(source="nickname.olbClientId",target="ecClientId")
    @Mapping(constant= "svc.gateway.migration",target="updatedBy")
    @Mapping(expression= "java(getPSTDate())",target="updatedDate")
    @Mapping(source="migClient.gwClientId",target="gwClientId")
    @Mapping(source="nickname.accountNumber",target="accountNumber")
    @Mapping(source="nickname.accTitle",target="accountNickname")
    @Mapping(source="nickname.jobId",target="jobId")
    @Mapping(source="migClient.primaryCifUbs", target="cifNumber")
    MigrationNickname mapMigratedNicknameToEntity(Nicknames nickname, MigClient migClient);

    public default LocalDateTime getPSTDate(){
        return DateUtility.getTimeZoneDate("America/Los_Angeles");
    }

    public default String determineDuplicateStatus(MigratedNicknamesEntity migratedNickname){
        if(migratedNickname!=null){
            return MigrationConstants.STATUS_IGNORE;
        }
        return MigrationConstants.STATUS_FAILURE;
    }

    public default String addComments(MigratedNicknamesEntity migratedNickname){

        if(migratedNickname!=null){
            return "Already migrated in the previous job id: "+migratedNickname.getJobId();
        }
        return "";
    }
}
