package com.svb.gateway.migration.nickname.mapper;

import com.svb.gateway.migration.nickname.entity.AccountMasterExtensionEntity;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

@Mapper
@Repository
public interface NicknameToACMXMapper {

    @Insert(value = {
            "INSERT INTO",
            "OCHADM.ACMX",
            "(DB_TS,BANK_ID,BRANCH_ID,ACID,BAY_USER_ID,AC_NIC_NAME,MIN_PREF_BAL,LARGE_CREDIT_BAL,LARGE_DEBIT_BAL,TRACE_AC,DEL_FLG,R_MOD_ID,R_MOD_TIME,R_CRE_ID,R_CRE_TIME,USER_BANK_ID)",
            "VALUES",
            "(#{dbTs}, #{bankId}, #{branchId}, #{acid}, #{bayUserId}, #{acNicName}, #{minPrefBal}, #{largeCreditBal}, #{largeDebitBal}, #{traceAc}, #{delFlg}, #{RModId}, #{RModTime}, #{RCreId}, #{RCreTime}, #{userBankId})"
    })
    Integer insertAccountNicknamesInOCH(AccountMasterExtensionEntity accountMasterExtensionEntity);
}
