package com.svb.gateway.migration.nickname.repository;

import com.svb.gateway.migration.nickname.entity.MigrationNickname;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface NickNameRepository extends JpaRepository<MigrationNickname, Long> {

    List<MigrationNickname> findAllByEcClientIdAndStatus(String ecClientId, String status);
}
