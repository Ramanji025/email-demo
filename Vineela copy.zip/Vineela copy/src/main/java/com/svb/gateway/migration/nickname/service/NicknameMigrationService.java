package com.svb.gateway.migration.nickname.service;

import com.svb.gateway.migration.client.entity.MigClient;
import com.svb.gateway.migration.common.constants.MigrationConstants;
import com.svb.gateway.migration.common.exception.ServiceException;
import com.svb.gateway.migration.common.logging.Message;
import com.svb.gateway.migration.nickname.entity.AccountMasterExtensionEntity;
import com.svb.gateway.migration.nickname.entity.MigrationNickname;
import com.svb.gateway.migration.nickname.entity.Nicknames;
import com.svb.gateway.migration.nickname.mapper.MigrationNicknameModelMapper;
import com.svb.gateway.migration.nickname.mapper.NicknameToACMXMapper;
import com.svb.gateway.migration.nickname.mapper.NicknameToACMXModelMapper;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;


@Log4j2
@Service
@Transactional(rollbackFor = Exception.class)
public class NicknameMigrationService {

    private static final String UNIQUE_CONSTRAINT_FAILURE = "Unique Constraint Violated in Target";

    @Autowired
    NicknameToACMXMapper nicknameToACMXMapper;

    @Value(value="${mig.user.principal}")
    String bankUserUuid;

    public MigrationNickname insert(Nicknames nickname, MigClient migratingClient) throws ServiceException {
        log.info(Message.create().descr("Migrating nickname").clientId(nickname.getOlbClientId()));
        MigrationNickname migrationNickname;
        try{
            AccountMasterExtensionEntity accountMasterExtensionEntity= NicknameToACMXModelMapper.INSTANCE.convertSingleAccountNicknameToACMXData(nickname,migratingClient.getGwClientId().toUpperCase(),bankUserUuid.toUpperCase());
            nicknameToACMXMapper.insertAccountNicknamesInOCH(accountMasterExtensionEntity);
            migrationNickname=setResponse(nickname, migratingClient, MigrationConstants.STATUS_SUCCESS,MigrationConstants.MIGRATED_SUCCESS);
        }
        catch(DuplicateKeyException duplicateKeyException){
            log.error(Message.create().descr(duplicateKeyException.getMessage()));
            migrationNickname=setResponse(nickname, migratingClient, MigrationConstants.STATUS_FAILURE, UNIQUE_CONSTRAINT_FAILURE);
        }catch(Exception e){
            log.error(Message.create().descr(e.getMessage()));
            migrationNickname=setResponse(nickname, migratingClient, MigrationConstants.STATUS_FAILURE, e.getMessage());
        }
        return migrationNickname;
    }

    private MigrationNickname setResponse(Nicknames nickname, MigClient migratingClient, String status, String message) {
        MigrationNickname migrationNickname= MigrationNicknameModelMapper.INSTANCE.mapMigratedNicknameToEntity(nickname, migratingClient);
        if(migratingClient.getPrimaryCifUbs() !=null) {
            migrationNickname.setCifNumber(String.valueOf(migratingClient.getPrimaryCifUbs()));
        }
        migrationNickname.setStatus(status);
        migrationNickname.setComments(message);
        return migrationNickname;
    }

}
