package com.svb.gateway.migration.nickname.service;

import com.svb.gateway.migration.client.entity.MigClient;
import com.svb.gateway.migration.common.exception.ServiceException;
import com.svb.gateway.migration.common.logging.Message;
import com.svb.gateway.migration.common.mapper.MigrationEntityMapper;
import com.svb.gateway.migration.common.utility.EntityLogUtility;
import com.svb.gateway.migration.nickname.entity.MigratedNicknamesEntity;
import com.svb.gateway.migration.nickname.entity.MigrationNickname;
import com.svb.gateway.migration.nickname.entity.Nicknames;
import com.svb.gateway.migration.nickname.mapper.MigrationNicknameMapper;
import com.svb.gateway.migration.nickname.mapper.MigrationNicknameModelMapper;
import com.svb.gateway.migration.nickname.model.NicknameResponse;
import com.svb.gateway.migration.nickname.model.NicknameResponseData;
import com.svb.gateway.migration.nickname.model.RecordCount;
import com.svb.gateway.migration.nickname.repository.NickNameRepository;
import com.svb.gateway.migration.nickname.repository.StgAccountNicknameRepository;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.sql.Timestamp;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static com.svb.gateway.migration.common.constants.MigrationConstants.*;

@Log4j2
@Service
public class NicknameService {

    public static final String NO_DATA_TO_MIGRATE = "No account nicknames available to migrate for provided client Id";
    public static final String NO_NICKNAME_TO_MIGRATE = "No account nicknames to migrate";
    public static final String ENTITY_NAME = "Account Nickname";
    public static final String SPECIAL_CHARACTER_ALLOWED = "^[a-zA-Z0-9\\s]+$";


    @Autowired
    private StgAccountNicknameRepository stgAccountNicknameRepository;

    @Autowired
    EntityLogUtility entityLogUtility;

    @Autowired
    private MigrationNicknameMapper migrationNicknameMapper;

    @Autowired
    private NicknameMigrationService nicknameMigrationService;
    @Autowired
    private NickNameRepository nickNameRepository;

    public NicknameResponse migrateAccountNickname(Long jobId,MigClient migClient) throws ServiceException {
        return process(migClient,jobId);
    }

    protected NicknameResponse process(MigClient migClient,Long jobId)  throws ServiceException {
        NicknameResponse nicknameResponse = new NicknameResponse();
        Message logMessage = Message.create().jobId(jobId).clientId(migClient.getEcClientId()).gwClientId(migClient.getGwClientId());
        log.info(logMessage.descr("Entry: Migrating nickname "));
        final RecordCount recordCount=new RecordCount();
        recordCount.setStartTime(new Timestamp(System.currentTimeMillis()));

        final MigClient migratedClient = migClient;

        List<Nicknames> nicknamesList = stgAccountNicknameRepository.findByEcClientId(migClient.getEcClientId());

        if (nicknamesList.isEmpty()) {
            recordCount.setEndTime(new Timestamp(System.currentTimeMillis()));
            entityLogUtility.saveEntityCountAndTimeLog(MigrationEntityMapper.INSTANCE.convertNoNicknamesToMigEntity(migratedClient, recordCount, ENTITY_NAME));
            throw new ServiceException(NO_DATA_TO_MIGRATE, NO_NICKNAME_TO_MIGRATE);
        }

        nicknamesList.stream().forEach(nickName -> {
            recordCount.setTotal(recordCount.getTotal()+1);

            MigrationNickname newAccountNickname=new MigrationNickname();
            try {
                MigratedNicknamesEntity migratedNickname= migrationNicknameMapper.checkIfMigratedIgnoredOrRolledBack(jobId,migratedClient.getEcClientId(),nickName.getAccountNumber());
                if (migratedNickname!=null && !migratedNickname.canRunAgain()){
                    recordCount.setTotal(recordCount.getTotal()-1);
                    MigrationNickname alreadyMigratedNickname= MigrationNicknameModelMapper.INSTANCE.mapAlreadyMigratedNicknameToEntity(nickName, migratedNickname);
                    createResponse(nicknameResponse, recordCount, alreadyMigratedNickname, STATUS_SUCCESS);
                }
                else if(isInvalidNickname(nickName)){
                    recordCount.setFailure(recordCount.getFailure()+1);
                    MigrationNickname ignoredNickname= MigrationNicknameModelMapper.INSTANCE.mapIgnoredNicknameToEntity(nickName,migratedClient);
                    migrationNicknameMapper.insertMigratedAccountNicknames(ignoredNickname);
                    createResponse(nicknameResponse, recordCount, ignoredNickname, STATUS_SUCCESS);
                }
                else {
                    newAccountNickname= nicknameMigrationService.insert(nickName,migratedClient);
                    updateCounter(recordCount, newAccountNickname);
                    migrationNicknameMapper.insertMigratedAccountNicknames(newAccountNickname);
                    createResponse(nicknameResponse, recordCount, newAccountNickname, STATUS_SUCCESS);
                }

            }catch (ServiceException e) {
                log.error(logMessage.descr("Error occurred while processing "+e.getMessage()));
                createResponse(nicknameResponse, recordCount, newAccountNickname, STATUS_FAILURE);
                nicknameResponse.setAdditionalProperty(e.getErrorCode(), e.getErrorMessage());
            }

        });
        recordCount.setEndTime(new Timestamp(System.currentTimeMillis()));
        if(recordCount.getTotal()>0){
            entityLogUtility.saveEntityCountAndTimeLog(MigrationEntityMapper.INSTANCE.convertNicknamesToMigEntity(nicknameResponse, recordCount, ENTITY_NAME));
        }

        log.info(logMessage.descr("Exit: Response for clientId "+ nicknameResponse.toString()));

        return nicknameResponse;
    }

    private boolean isInvalidNickname(Nicknames nickname){
        boolean isIvalid=false;
        if(null==nickname.getAccTitle()){
            isIvalid=true;
        }
        else{
            Pattern regExPattern = Pattern.compile(SPECIAL_CHARACTER_ALLOWED);
            Matcher allowedCharacterMatcher = regExPattern.matcher(nickname.getAccTitle());
            if(!allowedCharacterMatcher.matches()) {
                isIvalid=true;
            }
        }
        return isIvalid;
    }

    private void updateCounter(RecordCount recordCount, MigrationNickname newNickname) {
        if (STATUS_SUCCESS.equalsIgnoreCase(newNickname.getStatus())) {
            recordCount.setSuccess(recordCount.getSuccess() + 1);
        } else {
            recordCount.setFailure(recordCount.getFailure() + 1);
        }
    }

    private void createResponse(NicknameResponse nicknameResponse, RecordCount recordCount, MigrationNickname migrationNickname, String status) {
        nicknameResponse.setNicknameResponseData(NicknameResponseData.builder()
                .gwClientId(migrationNickname.getGwClientId())
                .ecClientId(migrationNickname.getEcClientId())
                .cifNumber(migrationNickname.getCifNumber())
                .jobId(migrationNickname.getJobId()==null?0:migrationNickname.getJobId().intValue())
                .status(status).recordCount(recordCount).build());
        nicknameResponse.setAdditionalProperty("Total Records for client: " + migrationNickname.getEcClientId() + " is: ", recordCount.getTotal());
        nicknameResponse.setAdditionalProperty("Total Successfully registered alert Records: ", recordCount.getSuccess());
        nicknameResponse.setAdditionalProperty("Total Failed alert Records :", recordCount.getFailure());
    }

    public void rollback(String ecClientId) {
        try {
            List<MigrationNickname> migrationNicknames = nickNameRepository.findAllByEcClientIdAndStatus(ecClientId, STATUS_SUCCESS);
            if (!migrationNicknames.isEmpty()) {
                migrationNicknames.forEach(nickName -> nickName.setStatus(STATUS_ROLLED_BACK));
                nickNameRepository.saveAll(migrationNicknames);
            }
        }catch (Exception e) {
            log.error(Message.create().descr("Nickname Rollback failed").clientId(ecClientId));
        }
    }
}
