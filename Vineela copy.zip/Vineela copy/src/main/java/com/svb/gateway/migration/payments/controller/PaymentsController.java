package com.svb.gateway.migration.payments.controller;

import com.svb.gateway.migration.common.exception.ServiceException;
import com.svb.gateway.migration.payments.api.PaymentsApi;
import com.svb.gateway.migration.payments.model.PaymentResponse;
import com.svb.gateway.migration.payments.service.IpayPaymentService;
import org.apache.commons.text.StringEscapeUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import springfox.documentation.annotations.ApiIgnore;

@ApiIgnore
@RestController
public class PaymentsController implements PaymentsApi {

    IpayPaymentService ipayPaymentService;

    @Autowired
    public PaymentsController(IpayPaymentService ipayPaymentService){
        this.ipayPaymentService = ipayPaymentService;
    }

    @Override
    @RequestMapping(path = "/" +
            "ipay/{jobId}/{clientId}",
            consumes = MediaType.ALL_VALUE, produces = {"application/json"},
            method = RequestMethod.POST)
    public ResponseEntity<PaymentResponse> createPayments(Long jobId, String clientId)  {
        String cleanedClientId = StringEscapeUtils.escapeHtml4(clientId);
        try {
            return new ResponseEntity<>(ipayPaymentService.createPayments(jobId, cleanedClientId), HttpStatus.OK);
        } catch (ServiceException e) {
            return new ResponseEntity<>(toErrorMessage(e.getMessage()), HttpStatus.BAD_REQUEST);
        }
    }

    private PaymentResponse toErrorMessage(String message) {
        PaymentResponse paymentResponse = new PaymentResponse();
        paymentResponse.setMessage(message);
        return paymentResponse;
    }
}
