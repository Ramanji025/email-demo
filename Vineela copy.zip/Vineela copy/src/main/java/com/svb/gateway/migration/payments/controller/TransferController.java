package com.svb.gateway.migration.payments.controller;

import com.svb.gateway.migration.client.entity.MigClient;
import com.svb.gateway.migration.client.model.MigClientDTO;
import com.svb.gateway.migration.client.service.ClientService;
import com.svb.gateway.migration.common.exception.ServiceException;
import com.svb.gateway.migration.payments.api.TransferApi;
import com.svb.gateway.migration.payments.model.TransferResponse;
import com.svb.gateway.migration.payments.service.TransferService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.text.StringEscapeUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import springfox.documentation.annotations.ApiIgnore;

@ApiIgnore
@Slf4j
@RestController
@RequestMapping("transfer")
public class TransferController implements TransferApi {

    private final TransferService transferService;
    private final ClientService clientService;

    @Autowired
    public TransferController(TransferService transferService, ClientService clientService) {
        this.transferService=transferService;
        this.clientService = clientService;
    }

    @Override
    @RequestMapping(path = "/scheduled/{jobId}",
            consumes = MediaType.APPLICATION_JSON_VALUE, produces = {"application/json"},
            method = RequestMethod.POST)
    @ResponseStatus(HttpStatus.OK)
    public ResponseEntity<TransferResponse> internalTransfer(@PathVariable("jobId") Long jobId,@RequestBody  MigClientDTO migClientDTO) throws ServiceException {
        log.debug("TransfersController.transfers, clientId: " + migClientDTO.getEcClientId());
        MigClient migClient=new MigClient();
        BeanUtils.copyProperties(migClientDTO, migClient);
        return new ResponseEntity<>(transferService.internalTransfer(jobId, migClient), HttpStatus.OK);
    }


    @Override
    @RequestMapping(path = "/wireoutgoing/{jobId}/{clientId}",
            consumes = MediaType.ALL_VALUE, produces = {"application/json"},
            method = RequestMethod.POST)
    @ResponseStatus(HttpStatus.OK)
    public ResponseEntity<TransferResponse> wireTransfer(@PathVariable("jobId") Long jobId, @PathVariable("clientId") String clientId) throws ServiceException {

        log.debug("TransfersController.wireOutgoing, clientId: " + clientId);
        String cleansedClientId = StringEscapeUtils.escapeHtml4(clientId);
        MigClient migClient = clientService.getMigClient(cleansedClientId, jobId);
        return new ResponseEntity<>(transferService.wireTransfer(jobId, migClient), HttpStatus.OK);
    }

}
