package com.svb.gateway.migration.payments.entity;


import com.svb.gateway.migration.payments.entity.ACMXEntity;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import javax.persistence.*;

@Getter
@Setter
@ToString
@Entity
@Table(schema = "OCHADM", name = "ACCT_MASTER")
public class ACMTTransfers {

    @Id
    @Column(name = "ACID")
    private String acid;


    @Column(name = "AC_NAME")
    private String acName;

    @Column(name = "CRN_CODE")
    private String acmtCrnCode;

    @Column(name = "CUST_ID")
    private String custId;

}
