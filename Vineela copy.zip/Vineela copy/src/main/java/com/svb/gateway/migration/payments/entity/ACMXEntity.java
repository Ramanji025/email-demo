package com.svb.gateway.migration.payments.entity;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import javax.persistence.*;

@ToString
@Getter
@Setter
@Entity
@Table(schema = "OCHADM", name = "ACCT_MASTER_EXTENSION")
@Data
public class ACMXEntity {
    @Id
    @Column(name="ACID")
    private String acId;


    @Column(name="AC_NIC_NAME")
    private String acNicName;

    @Column(name="BRANCH_ID")
    private String branchId;

    @Column(name="BAY_USER_ID")
    private String bayUserId;


}
