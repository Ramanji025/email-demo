package com.svb.gateway.migration.payments.entity;


import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import javax.persistence.*;
import java.sql.Timestamp;

@Getter
@Setter
@Entity
@ToString
@IdClass(MigrationEntityId.class)
@Table(schema = "GWDMG", name = "MIG_ENTITY")
public class MigrationEntity {

    @Id
    @Column(name = "MIGENTITYID")
    private Integer migEntityId;

    @Column(name = "JOB_ID")
    private Integer jobId;

    @Column(name = "ECCLIENT_ID")
    private String ecClientId;

    @Column(name = "GWCLIENT_ID")
    private String gwClientId;

    @Column(name = "CIF_NUMBER")
    private String CIF_NUMBER;

    @Id
    @Column(name = "ENTITY_NAME")
    private String entityName;

    @Column(name = "READCOUNT")
    private Integer readCount;

    @Column(name = "WRITECOUNT")
    private Integer writeCount;

    @Column(name = "SKIPCOUNT")
    private Integer skipCount;

    @Column(name = "START_TIME")
    private Timestamp startTime;

    @Column(name = "END_TIME")
    private Timestamp endTime;

    @Column(name = "TOTAL_STEP_TIME")
    private Integer totalStepTime;

    @Column(name = "CREATED_DATETIME")
    private Timestamp createdDateTime;

}
