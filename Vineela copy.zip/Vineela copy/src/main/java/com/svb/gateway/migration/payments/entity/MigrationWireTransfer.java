package com.svb.gateway.migration.payments.entity;

import com.svb.gateway.migration.common.processors.IRetry;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.util.Date;

@Setter
@Getter
@Entity
@Table(schema = "GWDMG", name = "MIG_WIRE_OUTGOING")
public class MigrationWireTransfer implements IRetry {

    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(name = "ID")
    private Long id;

    @Column(name = "JOBID")
    private Long jobId;

    @Column(name = "EC_CLIENT_ID")
    private String ecClientId;

    @Column(name = "GW_CLIENT_ID")
    private String gwClientId;

    @Column(name = "EC_USERLOGIN_ID")
    private String ecUserLoginId;

    @Column(name = "GW_UUID")
    private String gwUuid;

    @Column(name = "EC_TXN_ID")
    private Integer ecTxnId;

    @Column(name = "GW_REQ_ID")
    private Long gwReqId;

    @Column(name = "BENEFICIARY_ID")
    private String beneId;

    @Column(name = "TEMPLATE_ID")
    private String templateId;

    @Column(name = "STATUS")
    private String status;

    @Column(name = "RECORD_DETAILS")
    private String recordDetails;

    @Column(name = "COMMENTS")
    private String comments;

    @Column(name = "UPDATEDBY")
    private String updatedby;

    @Column(name = "UPDATEDDATE")
    private Date updatedDate;

    /**
     * Updates object from another object, except the following:
     * GwReqId, status , comments which are already set, and updatedBy and updatedDate are done in DB.
     * @param other another MigrationPayment
     * @return updated MigrationPayment
     */
    public MigrationWireTransfer updateFrom(MigrationWireTransfer other) {
        if(other != null){
            // update existing object with everything except
            setId(other.getId());
            setJobId(other.getJobId());
            setEcClientId(other.getEcClientId());
            setGwClientId(other.getGwClientId());
            setEcUserLoginId(other.getEcUserLoginId());
            setGwUuid(other.getGwUuid());
            setRecordDetails(other.getRecordDetails());

            setTemplateId(other.getTemplateId());
            setBeneId(other.getBeneId());
            setEcTxnId(other.getEcTxnId());
        }
        return this;
    }

}
