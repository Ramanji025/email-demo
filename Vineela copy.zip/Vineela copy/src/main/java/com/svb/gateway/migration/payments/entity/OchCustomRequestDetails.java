package com.svb.gateway.migration.payments.entity;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.time.LocalDateTime;

@Setter
@Getter
@Entity
@Table(schema = "OCHADM", name = "CUSTOM_TRANSACTION_REQUEST_DETAILS")
public class OchCustomRequestDetails {

    @Id
    @Column(name = "REQ_ID")
    private Long reqId;

    @Column(name = "BANK_ID")
    private String bankId;

    @Column(name = "DB_TS")
    private Integer dbTs;

    @Column(name = "R_CRE_TIME")
    private LocalDateTime rCreTime;

    @Column(name = "R_MOD_TIME")
    private LocalDateTime rModTime;

    @Column(name = "REQ_SR_NO")
    private Integer reqSNo;

    @Column(name = "R_CRE_ID")
    private String rCreId;

    @Column(name = "R_MOD_ID")
    private String rModId;

    @Column(name = "DEL_FLG")
    private String delFlg;

    @Column(name= "DEBIT_AMOUNT")
    private Double debitAmount;

    @Column(name = "FX_RATE")
    private Double fxRate;

    @Column(name = "CURRENCY_PAIR")
    private String currencyPair;

    @Column(name = "NOTE_TO_PAYEE")
    private String noteToPayee;

    @Column(name = "BANK_TO_BANK_INSTRUCTIONS")
    private String bankToBankInst;

    @Column(name = "IB_ROUTING_CODE")
    private String ibRoutingCode;

    @Column(name = "IB_BANK_NAME")
    private String ibBankName;

    @Column(name = "IB_ADDRESS_1")
    private String ibAddress1;

    @Column(name = "CP_EMAIL_ADDRESSES")
    private String cpEmailAddress;
}
