package com.svb.gateway.migration.payments.entity;

import lombok.Data;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(schema = "OCHADM", name = "TRANSACTION_HEADER")
@Data
public class OchTransactionHeader {

    @Id
    @Column (name = "REQ_ID")
    private Integer reqId;

    @Column(name = "TXN_ID")
    private Integer txnId;

}
