package com.svb.gateway.migration.payments.entity;


import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.time.LocalDateTime;

@Setter
@Getter
@Entity
@Table(schema = "OCHADM", name = "TRANSACTION_REQUEST_DETAILS")
public class OchTransactionRequestDetails {

    @Id
    @Column(name = "REQ_ID")
    private Long reqId;

    @Column(name = "BANK_ID")
    private String bankId;

    @Column(name = "DB_TS")
    private Integer dbTs;

    @Column(name = "R_CRE_TIME")
    private LocalDateTime rCreTime;

    @Column(name = "R_MOD_TIME")
    private LocalDateTime rModTime;

    @Column(name = "REQ_SR_NO")
    private Integer reqSNo;

    @Column(name = "R_CRE_ID")
    private String rCreId;

    @Column(name = "R_MOD_ID")
    private String rModId;

    @Column(name = "TOTAL_ENTRY_AMT")
    private Double totEntryAmt;

    @Column(name = "ENTRY_AMT")
    private Double entryAmt;

    @Column(name = "LIMIT_AMT_IN_HOMECRN")
    private Double limitAmtInHomeCrn;

    @Column(name = "ENTRY_RMKS")
    private String entryRemarks;

    @Column(name = "TRAN_ACT_REMARKS")
    private String tranActRemarks;

    @Column(name = "TRAN_ACT_ENTITY_EXTN1")
    private String trnActEntityExtn1;

    @Column(name = "TRAN_ACT_ENTITY_EXTN2")
    private String trnActEntityExtn2;

    @Column(name = "CP_ACCT_TYPE")
    private String cpAcctType;

    @Column(name = "TRAN_ACT_ENTITY_ID")
    private String tranActEntityId;

    @Column(name = "CP_ENTITY_ID")
    private String cpEntityId;

    @Column(name = "VALUE_DATE")
    private LocalDateTime valueDate;

    @Column(name = "TRAN_ACT_CRN")
    private String tranActCrn;

    @Column(name = "CP_ACCT_CRN")
    private String cpAcctCrn;

    @Column(name = "CP_ENTITY_TYPE")
    private String cpEntityType;

    @Column(name = "TRAN_ACT_ENTITY_TYPE")
    private String tranActEntityType;

    @Column(name = "NETWORK_ID")
    private String networkId;

    @Column(name = "DRCR_FLG")
    private String drcrFlg;

    @Column(name = "BENEFICIARY_REFERENCE")
    private String beneRef;

    @Column(name = "REQ_REC_TOTAL_ENTRY_AMT")
    private Double reqRecTotalEntryAmt;

    @Column(name = "REQ_REC_LIMIT_AMT_IN_HOMECRN")
    private Double reqRecLimitAmtInHomecrn;

    @Column(name = "REQ_REC_ENTRY_AMT")
    private Double reqRecEntryAmt;

    @Column(name = "CHANNEL_ID")
    private String channelId;

    @Column(name = "LIMIT_RATE")
    private Double limit_rate;

    @Column(name = "CHARGE_AMT")
    private Double chargeAmt;

    @Column(name = "CHARGE_CRN")
    private String chargeCrn;

    @Column(name = "NW_COMMISSION_AMT")
    private Double nwCommissionAmt;

    @Column(name = "NW_COMMISSION_CRN")
    private String nwCommissionCrn;

    @Column(name = "NW_COMMISSION_INDICATOR")
    private String nwCommissionIndicator;

    @Column(name = "MANDATE_NO")
    private Integer mandateNo;

    @Column(name = "NEGOTIATED_RATE")
    private Double negotiatedRate;

    @Column(name = "FIRST_PMT_AMT")
    private Double firstPmtAmt;

    @Column(name = "LAST_PMT_AMT")
    private Double lastPmtAmt;

    @Column(name = "DEL_FLG")
    private String delFlg;

    @Column(name = "NOTIFICATION_REF_NO")
    private Integer notificationRefNo;

    @Column(name = "IS_ADDENDA_DATA_AVAILABLE")
    private String isAddendaDataAvailable;

    @Column(name = "CP_ENTITY_NICKNAME")
    private String cpEntityNickname;

    @Column(name = "TRAN_ACT_ENTITY_NICKNAME")
    private String tranActEntityNickname;

    @Column(name = "CP_ENTITY_EXTN1")
    private String cpEntityExtn1;

    @Column(name = "CP_ENTITY_EXTN2")
    private String cpEntityExtn2;
}
