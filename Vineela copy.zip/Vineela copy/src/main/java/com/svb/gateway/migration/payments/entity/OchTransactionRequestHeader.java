package com.svb.gateway.migration.payments.entity;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import javax.persistence.*;
import java.time.LocalDateTime;
import java.util.Date;

@Entity
@Table(schema = "OCHADM", name = "TRANSACTION_REQUEST_HEADER")
@Data
@Setter
@Getter
@ToString
public class OchTransactionRequestHeader {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator="REQ_ID")
    @SequenceGenerator(sequenceName = "OCHADM.NXT_TRAN_REQ_IDSVB", allocationSize = 1, name="REQ_ID")
    Long reqId;

    @Column(name = "BANK_ID")
    private String bankId;

    @Column(name = "DB_TS")
    private Integer dbTs;

    @Column(name = "MARKED_FOR_STOP")
    private String markedForStop;

    @Column(name = "TOTAL_CHARGE_AMT")
    private Double totalChargeAmt;

    @Column(name = "TOT_NO_OF_INSTANCES")
    private Integer totNoOfInstances;

    @Column(name = "VALIDITY_INDICATOR")
    private String validityIndicator;

    @Column(name = "NO_OF_INSTANCES_PROCESSED")
    private Integer noOfInstancesProcessed;

    @Column(name = "HOLD_FLG")
    private String holdFLG;

    @Column(name = "HIGHEST_ENTRY_AMOUNT")
    private Double highestEntryAmount;

    @Column(name = "ENTERER_ID")
    private String entererId;

    @Column(name = "FREQ_NDAYS")
    private Integer freqNdays;

    @Column(name = "DEL_FLG")
    private String delFlg;

    @Column(name = "BULK_PMT_REF_NUM")
    private Integer bulkPmtRefNum;

    @Column(name = "IS_TXN_CONFIDENTIAL")
    private String isTxnConfidential;

    @Column(name = "REQ_REC_TOTAL_TXN_AMT")
    private Double reqRecTotalTxnAmt;

    @Column(name = "TOTAL_TXN_AMT_IN_HOMECRN")
    private Double TotalTxnAmtInHomecrn;

    @Column(name = "REQ_REC_TOTAL_TXN_AMT_HOMECRN")
    private Double reqRecTotalTxnAmtHomecrn;

    @Column(name = "REQ_REC_TOTAL_AMT")
    private Double reqRecTotalAmt;

    @Column(name = "HIGHEST_ENTRY_SRL_NO")
    private Integer highestEntrySrlNo;

    @Column(name = "R_CRE_TIME")
    private LocalDateTime rCreTime;

    @Column(name = "R_MOD_TIME")
    private LocalDateTime rModTime;

    @Column(name = "PARENT_REQ_ID")
    private Integer parentReqId;

    @Column(name = "R_CRE_ID")
    private String rCreId;

    @Column(name = "R_MOD_ID")
    private String rModId;

    @Column(name = "TOTAL_TXN_AMT")
    private Double totalTxnAmt;

    @Column(name = "TOTAL_AMT")
    private Double totalAmt;

    @Column(name = "REQUEST_DATE")
    private LocalDateTime reqDate;

    @Column(name = "CORP_USER")
    private String corpUser;

    @Column(name = "CORP_ID")
    private String corpId;

    @Column(name = "ACCOUNTS_USED")
    private String accountsUsed;

    @Column(name = "TXN_DATE")
    private Date txnDate;


    @Column(name = "PMT_FREQ")
    private Integer pmtFreq;

    @Column(name = "USER_INPUT_DATE")
    private Date userInputDate;

    @Column(name = "TXN_CRN")
    private String txnCrn;

    @Column(name = "TXN_TYPE")
    private String txnType;

    @Column(name = "FREQ_TYPE")
    private String freqType;

    @Column(name = "REQUEST_STATUS")
    private String reqStatus;

    @Column(name = "FU_REC_NUM")
    private Integer fuRecNum;

    @Column(name = "TOTAL_NO_OF_ENTRIES")
    private Integer totalNoOfEntries;

    @Column(name = "TMPL_ID")
    private Integer tmplId;

    @Column(name = "TMPL_DISPLAY_ID")
    private Integer tmplDiplsayId;
}
