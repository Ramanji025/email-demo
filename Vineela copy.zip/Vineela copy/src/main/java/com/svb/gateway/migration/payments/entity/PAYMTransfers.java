package com.svb.gateway.migration.payments.entity;


import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Getter
@Setter
@ToString
@Entity
@Table(schema = "OCHADM", name = "PAYEE_MASTER")
public class PAYMTransfers {

    @Id
    @Column(name = "BNF_ID")
    private String bnfId;

    @Column(name = "BNF_CODE")
    private String bnfCode;

    @Column(name = "BNF_NAME")
    private String bnfName;

    @Column(name = "BNF_ADDRESS_1")
    private String bnfAddress1;

    @Column(name = "BNF_ADDRESS_2")
    private String bnfAddress2;

    @Column(name = "BNF_ADDRESS_3")
    private String bnfAddress3;

    @Column(name = "BNF_STATE")
    private String bnfState;

    @Column(name = "BNF_CNTRY")
    private String bnfCntry;

    @Column(name = "BNF_TYPE")
    private String bnfType;

    @Column(name = "BNF_BANK_NAME")
    private String bnfBankName;

    @Column(name = "BNF_BANK_ADDRESS")
    private String bnfBankAddress;

    @Column(name = "BNF_BANK_COUNTRY")
    private String bnfBankCountry;

    @Column(name = "BNF_ACCT_CRN")
    private String bnfAcctCrn;

    @Column(name = "ACCOUNT_ID")
    private String paymAcctId;

    @Column(name = "BNF_ACCT_TYPE")
    private String bnfAcctType;

    @Column(name = "BNF_CITY_ZIP")
    private String bnfCityZip;

    @Column(name = "BNF_BANK_CITY_ZIP")
    private String bnfBankCityZip;

    @Column(name = "BNF_EMAIL")
    private String bnfEmail;

    @Column(name = "BANK_TYPE")
    private String bankType;

    @Column(name = "BNF_CITY_CODE")
    private String bnfCityCode;

    @Column(name = "BNF_ZIP_CODE")
    private String bnfZipCode;

    @Column(name = "NETWORK_ID")
    private String networkId;

    @Column(name = "BANK_IDENTIFIER")
    private String bankIdentifier;

}
