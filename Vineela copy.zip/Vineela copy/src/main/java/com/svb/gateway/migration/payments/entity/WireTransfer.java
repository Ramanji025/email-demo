package com.svb.gateway.migration.payments.entity;

import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;

import javax.persistence.*;
import java.util.Date;

import static com.svb.gateway.migration.common.constants.MigrationConstants.*;

@Slf4j
@Getter
@Setter
@Entity
@Table(schema = "GWDMG", name = "MIG_STG_WIRE_OUTGOING")
public class WireTransfer {

    @Id
    @Column(name = "WIRE_TRANSACTION_ID")
    private Integer wireTxnId;

    @Column(name = "OLB_CLIENT_ID")
    private String olbClientId;

    @Column(name = "PAYMENT_TYPE")
    private String pmtType;

    @Column(name = "TEMPLATE_ID")
    private Integer templateId;

    @Column(name = "ENTRY_DATE")
    private Date entryDate;

    @Column(name = "ENTRYOP_NAME")
    private String entryopName;

    @Column(name = "ENTRYOP_ID")
    private String entryopId;

    @Column(name = "VALUE_DATE")
    private Date valueDate;

    @Column(name = "CURRENT_STATE")
    private Integer currentState;

    @Column(name = "CURRENCY_CODE")
    private String crncyCode;

    @Column(name = "FOREX_RATE")
    private Double fxRate;

    @Column(name = "FOREX_AMOUNT")
    private Double fxAmount;

    @Column(name = "CANCEL_DATE")
    private Date canceldate;

    @Column(name = "BENEFICIARY_BANK_IDENTIFIER")
    private String beneBankId;

    @Column(name = "BENEFICIARY_ACCOUNT")
    private String beneAccount;

    @Column(name = "SETTLEMENT_DATE")
    private Date settlementDate;

    @Column(name = "BENEFICIARY_NAME")
    private String beneName;

    @Column(name = "BENEFICIARY_ADDRESS_1")
    private String beneAdd1;

    @Column(name = "BENEFICIARY_ADDRESS_2")
    private String beneAdd2;

    @Column(name = "CONTRACT_ID")
    private String contractId;

    @Column(name = "BENEFICIARY_INSTRUCTIONS")
    private String beneInstructions;

    @Column(name = "CONTRACT_RATE")
    private Double contractRate;

    @Column(name = "BENEFICIARY_ADDRESS_3")
    private String beneAdd3;

    @Column(name = "BENEFICIARY_BANK_NAME")
    private String beneBankName;

    @Column(name = "BENEFICIARY_BANK_ADDRESS")
    private String beneBankAddress;

    @Column(name = "BENEFICIARY_BANK_CITY")
    private String beneBankCity;

    @Column(name = "BENEFICIARY_BANK_CITY_ZIP")
    private String beneBankCityZip;

    @Column(name = "BENEFICIARY_BANK_STATE")
    private String beneBankState;

    @Column(name = "BENEFICIARY_BANK_COUNTRY")
    private String beneBankCountry;

    @Column(name = "BANK_TO_BANK_INSTRUCTIONS")
    private String bankToBankInstructions;


    @Column(name = "ENTERED_AMT_IN_DEBIT_CURRENCY")
    private Double enteredAmtInDebitCrncy;

    @Column(name = "DEBITING_AMOUNT")
    private Double debitAmt;

    @Column(name = "DEBITING_CURRENCY_CODE")
    private String debitCrncyCode;

    @Column(name = "SENT_DATE")
    private Date sentDate;

    @Column(name = "BENEFICIARY_BANK_REGION")
    private String beneBankRegion;

    @Column(name = "INTERMEDIARY_ID")
    private String intrmId;

    @Column(name = "INTERMEDIARY_NAME")
    private String intrmName;

    @Column(name = "INTERMEDIARY_ADDRESS")
    private String intrmAddress;

    @Column(name = "ROUTING_CODE")
    private String routingCode;

    @Column(name = "JOB_ID")
    private String jobId;

    @Column(name = "FROM_ACCOUNT_NUMBER")
    private String fromAccountNumber;

    @Transient
    private String bnfAccountType;

    @Transient
    private String bnfId;

    @Transient
    private String accNickName;

    public String getTransactionType(){
        if (DOM.equalsIgnoreCase(pmtType)) {
            return FED;
        } else if(INTL.equalsIgnoreCase(pmtType)){
            return USI;
        }
        return null;
    }

    public String getNetworkId(){
        if (DOM.equalsIgnoreCase(pmtType)) {
            return FED;
        } else if(INTL.equalsIgnoreCase(pmtType)){
            return SWIFT;
        }
        return null;
    }

    public String getFromAccountNumber(){
        return fromAccountNumber;
    }
}
