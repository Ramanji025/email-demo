package com.svb.gateway.migration.payments.mapper;

import com.svb.gateway.migration.common.utility.DateUtility;
import com.svb.gateway.migration.common.utility.PaymentUtils;
import com.svb.gateway.migration.ipay.batch.util.IPayConstants;
import com.svb.gateway.migration.payments.entity.*;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;
import org.springframework.util.StringUtils;

import java.time.*;

import static com.svb.gateway.migration.common.constants.MigrationConstants.STATUS_FAILURE;
import static com.svb.gateway.migration.common.constants.MigrationConstants.STATUS_IGNORE;


@Mapper(componentModel="spring")
public interface MigrationPaymentModelMapper {

    MigrationPaymentModelMapper INSTANCE = Mappers.getMapper(MigrationPaymentModelMapper.class);
    public static final String ONE="1";

    @Mapping(source="payment.paymentId",target="paymentId")
    @Mapping(source="payment.ecClientId",target="ecClientId")
    @Mapping(expression="java(determineStatus(payment))",target="status" )
    @Mapping(expression="java(addComments(payment))",target="comments" )
    @Mapping(constant= "svc.gateway.migration",target="updatedby")
    @Mapping(expression= "java(getPSTDate())",target="updatedDate")
    @Mapping(source="migratedPayment.gwClientId",target="gwClientId")
    @Mapping(source="migratedPayment.gwUuid",target="gwUuid")
    @Mapping(source="migratedPayment.gwReqId",target="gwReqId")
    @Mapping(source="migratedPayment.jobId",target="jobId")
    @Mapping(source="payment.beneficiaryId",target="beneficiaryId")
    MigrationPayment convertIpayPaymentToEntity(Payment payment, MigrationPayment migratedPayment);

    @Mapping(source="payment.paymentId",target="paymentId")
    @Mapping(source="payment.ecClientId",target="ecClientId")
    @Mapping(constant= "svc.gateway.migration",target="updatedby")
    @Mapping(expression= "java(getPSTDate())",target="updatedDate")
    @Mapping(source="migrationUser.gwClientId",target="gwClientId")
    @Mapping(source="migrationUser.gwUuid",target="gwUuid")
    @Mapping(source="payment.jobId",target="jobId")
    @Mapping(source="payment.targetBeneficiaryId",target="beneficiaryId")
    MigrationPayment convertIpayPaymentToEntity(Payment payment, MigrationUser migrationUser);

    @Mapping(source="transfer.trnId",target="ecTxnId")
    @Mapping(source="migrationUser.ecClientId",target="ecClientId")
    @Mapping(constant= "svc.gateway.migration",target="updatedby")
    @Mapping(expression= "java(new java.util.Date())",target="updatedDate")
    @Mapping(source="migrationUser.gwClientId",target="gwClientId")
    @Mapping(source="migrationUser.gwUuid",target="gwUuid")
    @Mapping(source="transfer.jobId",target="jobId")
    @Mapping(source="migrationUser.migUserId",target="ecUserLoginId" )
    MigrationInternalTransfer convertTransferToEntity(InternalTransfer transfer, MigrationUser migrationUser);

    @Mapping(source="migrationUser.ecClientId",target="ecClientId")
    @Mapping(constant= "svc.gateway.migration",target="updatedby")
    @Mapping(expression= "java(new java.util.Date())",target="updatedDate")
    @Mapping(source="migrationUser.gwClientId",target="gwClientId")
    @Mapping(source="migrationUser.gwUuid",target="gwUuid")
    @Mapping(source="transfer.jobId",target="jobId")
    @Mapping(source="migrationUser.migUserId",target="ecUserLoginId" )
    @Mapping(source="transfer.wireTxnId",target="ecTxnId")
    MigrationWireTransfer convertTransferToEntity(WireTransfer transfer, MigrationUser migrationUser);

    default public LocalDateTime getPSTDate(){
        return DateUtility.getTimeZoneDate("America/Los_Angeles");
    }

    default public String determineStatus(Payment payment){
        if(PaymentUtils.inValidRecurringPayment(payment)){
            return STATUS_FAILURE;
        }
        return STATUS_IGNORE;
    }

    default public String addComments(Payment payment){

        if(PaymentUtils.inValidRecurringPayment(payment)){
            if(ONE.equals(payment.getSkippedPayment())){
                return IPayConstants.SKIPPED_PAYMENT;
            }

            if(!StringUtils.isEmpty(payment.getOverrideSubsidaryBankId())){
                return IPayConstants.OVERRIDE_SUBS_BANK_ID;
            }

            if(!StringUtils.isEmpty(payment.getOverrideAmount())){
                return IPayConstants.OVERRIDE_AMOUNT;
            }
            if(!IPayConstants.getValidFrequencies().contains(payment.getPaymentFrequency())){
                return IPayConstants.FREQUENCY_NOT_SUPPORTED + payment.getPaymentFrequency();
            }
        }
        return "";
    }
}
