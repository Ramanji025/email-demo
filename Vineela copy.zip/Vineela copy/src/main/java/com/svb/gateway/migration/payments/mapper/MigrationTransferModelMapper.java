package com.svb.gateway.migration.payments.mapper;

import com.svb.gateway.migration.common.utility.DateUtility;
import com.svb.gateway.migration.payments.entity.*;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;


import java.time.LocalDateTime;

import static com.svb.gateway.migration.common.constants.MigrationConstants.STATUS_IGNORE;


@Mapper(componentModel="spring")
public interface MigrationTransferModelMapper {

    MigrationTransferModelMapper INSTANCE = Mappers.getMapper(MigrationTransferModelMapper.class);

    @Mapping(source="payment.paymentId",target="paymentId")
    @Mapping(source="payment.ecClientId",target="ecClientId")
    @Mapping(constant= "svc.gateway.migration",target="updatedby")
    @Mapping(expression= "java(getPSTDate())",target="updatedDate")
    @Mapping(source="migrationUser.gwClientId",target="gwClientId")
    @Mapping(source="migrationUser.gwUuid",target="gwUuid")
    @Mapping(source="payment.jobId",target="jobId")
    @Mapping(source="payment.targetBeneficiaryId",target="beneficiaryId")
    MigrationPayment convertIpayPaymentToEntity(Payment payment, MigrationUser migrationUser);

    @Mapping(source="transfer.trnId",target="ecTxnId")
    @Mapping(source="transfer.olbClientId",target="ecClientId")
    @Mapping(expression="java(determineStatus(transfer))",target="status" )
    @Mapping(source="transfer.userLoginId",target="ecUserLoginId")
    @Mapping(expression="java(addComments(migrationTransfer))",target="comments" )
    @Mapping(constant= "svc.gateway.migration",target="updatedby")
    @Mapping(expression= "java(" +
            "com.svb.gateway.migration.common.utility.DateUtility.getDateFromLong(System.currentTimeMillis()))",target="updatedDate")
    @Mapping(source="migrationTransfer.gwClientId",target="gwClientId")
    @Mapping(source="migrationTransfer.gwUuid",target="gwUuid")
    @Mapping(source="migrationTransfer.gwReqId",target="gwReqId")
    @Mapping(source="migrationTransfer.jobId",target="jobId")
    MigrationInternalTransfer convertMigrationTransferToEntity(InternalTransfer transfer, MigrationInternalTransfer migrationTransfer);

    @Mapping(source="transfer.wireTxnId",target="ecTxnId")
    @Mapping(source="transfer.olbClientId",target="ecClientId")
    @Mapping(constant=STATUS_IGNORE,target="status" )
    @Mapping(source="transfer.entryopId",target="ecUserLoginId")
    @Mapping(constant="Duplicate",target="comments" )
    @Mapping(constant= "svc.gateway.migration",target="updatedby")
    @Mapping(expression= "java(" +
            "com.svb.gateway.migration.common.utility.DateUtility.getDateFromLong(System.currentTimeMillis()))",target="updatedDate")
    @Mapping(source="migrationTransfer.gwClientId",target="gwClientId")
    @Mapping(source="migrationTransfer.gwUuid",target="gwUuid")
    @Mapping(source="migrationTransfer.gwReqId",target="gwReqId")
    @Mapping(source="migrationTransfer.jobId",target="jobId")
    @Mapping(expression="java(determineTemplate(transfer))",target="templateId")
    MigrationWireTransfer convertWireMigrationTransferToEntity(WireTransfer transfer, MigrationWireTransfer migrationTransfer);

    default public LocalDateTime getPSTDate(){
        return DateUtility.getTimeZoneDate("America/Los_Angeles");
    }

    default public String determineStatus(InternalTransfer transferRecord){
        return STATUS_IGNORE;
    }

    default public String addComments(MigrationInternalTransfer migrationTransfer){
        return "This is a Duplicate record. Record was processed Already with TRQH.Req id: " + migrationTransfer.getGwReqId() ;
    }

    default public String determineTemplate(WireTransfer transfer){
        if (null != transfer.getTemplateId()) {
            return transfer.getTemplateId().toString();
        } else {
            return transfer.getWireTxnId().toString();
        }
    }

}
