package com.svb.gateway.migration.payments.mapper;

import com.svb.gateway.migration.common.utility.FrequencyPeriod;
import com.svb.gateway.migration.payments.entity.*;
import com.svb.gateway.migration.payments.model.RecurringType;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;
import org.mapstruct.factory.Mappers;

import com.svb.gateway.migration.common.utility.DateUtility;
import java.time.LocalDateTime;
import static com.svb.gateway.migration.common.constants.MigrationConstants.*;

@Mapper(componentModel="spring")
public interface PaymentToOchMapper {
    PaymentToOchMapper INSTANCE = Mappers.getMapper(PaymentToOchMapper.class);

    public static String ZERO_AMOUNT="0.0";
    public static String ZERO="0";
    public static final String ACCT_EXTN2 = "SB0";
    public static final String ACCT_EXTN1 = "SVB";
    public static final String USD = "USD";
    public static final String PST_TIME_ZONE="America/Los_Angeles";

    //tran_act_entity_nickname

    @Mapping(source="payment",target="accountsUsed", qualifiedByName="appendSVB")
    @Mapping(source="payment",target="entererId", qualifiedByName="entererId")
    @Mapping(constant=USD,target="txnCrn")
    @Mapping(source="payment.paymentAmount",target="totalAmt")
    @Mapping(source="payment.paymentAmount",target="totalTxnAmt")
    @Mapping(source="payment.transactionType",target="txnType")
    @Mapping(source= "payment.paymentFrequency", target="freqType", qualifiedByName = "determineFrequency")
    @Mapping(constant = "1",target="dbTs")
    @Mapping(constant = "N",target="delFlg")
    @Mapping(constant = ZERO,target="bulkPmtRefNum")
    @Mapping(constant = BANK_ID,target="bankId")
    @Mapping(source="migrationUser",target="RModId" , qualifiedByName = "formattedClient")
    @Mapping(source="migrationUser",target="RCreId", qualifiedByName = "formattedClient")
    @Mapping(source="migrationUser.gwClientId",target="corpId")
    @Mapping(source="migrationUser.gwUuid",target="corpUser")
    @Mapping(constant=ZERO,target="freqNdays")
    @Mapping(constant=ZERO,target="parentReqId")
    @Mapping(expression="java(payment.getRecurringType().getInstancesProcessed())",target="noOfInstancesProcessed")
    @Mapping(constant="N",target="markedForStop")
    @Mapping(constant="N",target="isTxnConfidential")
    @Mapping(constant="N",target="holdFLG")
    @Mapping(constant="1",target="highestEntrySrlNo")
    @Mapping(expression="java(getPSTDate())",target="RCreTime")
    @Mapping(expression="java(getPSTDate())",target="RModTime")
    @Mapping(source="payment.paymentAmount",target="totalTxnAmtInHomecrn")
    @Mapping(constant=ZERO_AMOUNT,target="reqRecTotalAmt")
    @Mapping(expression = "java(payment.getRecurringType().getEntries())",target="totalNoOfEntries")
    @Mapping(source="payment.paymentAmount",target="highestEntryAmount")
    @Mapping(constant=ZERO_AMOUNT,target="reqRecTotalTxnAmt")
    @Mapping(constant=ZERO_AMOUNT,target="reqRecTotalTxnAmtHomecrn")
    @Mapping(constant="AAC",target="reqStatus")
    @Mapping(constant=ZERO_AMOUNT,target="totalChargeAmt")
    @Mapping(expression="java(getTotalInstances(payment))",target="totNoOfInstances")
    @Mapping(expression="java(getPSTDate())",target="reqDate")
    @Mapping(source="payment.paymentDate",target="txnDate")
    @Mapping(source= "payment.paymentDate",target="userInputDate")
    @Mapping(constant=ZERO,target="tmplId")
    @Mapping(constant=ZERO,target="tmplDiplsayId")
    @Mapping(constant=ZERO,target="fuRecNum")
    @Mapping(constant="N",target="validityIndicator")
    @Mapping(expression="java(ochFrequencyCode(payment))", target="pmtFreq")
    OchTransactionRequestHeader convertSinglePastPaymentToTRQH(Payment payment, MigrationUser migrationUser);

    @Mapping(source="migrationUser",target="tranActRemarks", qualifiedByName = "appendFullName")
    @Mapping(source="payment.targetBeneficiaryId",target="cpEntityId")
    @Mapping(constant = BANK_ID,target="bankId")
    @Mapping(constant = USD,target="cpAcctCrn")
    @Mapping(constant=CHARGE_CRN,target="chargeCrn")
    @Mapping(constant=CHANNEL_ID_I,target="channelId")
    @Mapping(constant=ZERO_AMOUNT,target="chargeAmt")
    @Mapping(constant="P",target="cpEntityType")
    @Mapping(constant="1",target="dbTs")
    @Mapping(constant="P",target="drcrFlg")
    @Mapping(constant="N",target="delFlg")
    @Mapping(source="payment.paymentAmount",target="entryAmt")
    @Mapping(constant="N",target="isAddendaDataAvailable")
    @Mapping(constant=ZERO_AMOUNT,target="firstPmtAmt")
    @Mapping(constant=ZERO_AMOUNT,target="lastPmtAmt")
    @Mapping(constant=ZERO_AMOUNT,target="limit_rate")
    @Mapping(source="payment.paymentAmount",target="limitAmtInHomeCrn")
    @Mapping(constant=ZERO,target="mandateNo")
    @Mapping(constant=ZERO_AMOUNT,target="negotiatedRate")
    @Mapping(source="payment.transactionType",target="networkId")
    @Mapping(constant=ZERO,target="notificationRefNo")
    @Mapping(constant=BENE_REF_NO,target="beneRef")
    @Mapping(constant=NW_COMMISSION_CRN,target="nwCommissionCrn")
    @Mapping(constant=NW_COMMISSION_INDICATOR,target="nwCommissionIndicator")
    @Mapping(constant=ZERO_AMOUNT,target="nwCommissionAmt")
    @Mapping(constant=ZERO_AMOUNT,target="reqRecEntryAmt")
    @Mapping(constant=ZERO_AMOUNT,target="reqRecTotalEntryAmt")
    @Mapping(constant=ZERO_AMOUNT,target="reqRecLimitAmtInHomecrn")
    @Mapping(constant="1",target="reqSNo")
    @Mapping(source="migrationUser",target="RModId", qualifiedByName = "formattedClient")
    @Mapping(source="migrationUser",target="RCreId", qualifiedByName = "formattedClient")
    @Mapping(expression="java(getPSTDate())",target="RCreTime")
    @Mapping(expression="java(getPSTDate())",target="RModTime")
    @Mapping(source="payment.paymentAmount",target="totEntryAmt")
    @Mapping(source="payment.subscriberAccountNumber",target="tranActEntityId")
    @Mapping(expression="java(getPSTDate())",target="valueDate")
    @Mapping(constant=ACCT_EXTN1,target="trnActEntityExtn1")
    @Mapping(constant=ACCT_EXTN2,target="trnActEntityExtn2")
    @Mapping(constant="T",target="tranActEntityType")
    @Mapping(constant=USD,target="tranActCrn")
    @Mapping(source="payment.accNickName",target="tranActEntityNickname")
    OchTransactionRequestDetails convertSinglePastPaymentToTRQD(Payment payment, MigrationUser migrationUser);

    @Mapping(constant=BANK_ID,target="bankId")
    @Mapping(constant = "1",target="dbTs")
    @Mapping(constant="1",target="reqSNo")
    @Mapping(constant=ZERO_AMOUNT,target="fxRate")
    @Mapping(constant=ZERO_AMOUNT,target="debitAmount")
    @Mapping(source="migrationUser",target="RModId", qualifiedByName = "formattedClient")
    @Mapping(source="migrationUser",target="RCreId", qualifiedByName = "formattedClient")
    @Mapping(expression="java(getPSTDate())",target="RCreTime")
    @Mapping(expression="java(getPSTDate())",target="RModTime")
    @Mapping(constant = "N",target="delFlg")
    OchCustomRequestDetails convertSinglePastPaymentToCTRD( MigrationUser migrationUser);

    @Named("formattedClient")
    default String appendClient(MigrationUser migrationUser){
        return migrationUser.getGwClientId() + "." + migrationUser.getGwUuid();
    }

    @Named("determineFrequency")
    default String determineFrequency(Character paymentFrequency){
        return paymentFrequency==null || paymentFrequency==' '? FREQ_TYPE_O: FREQ_TYPE_R;
    }

    default Integer ochFrequencyCode(Payment payment){
        if(payment.getPaymentFrequency()==null){
            return null;
        }
        FrequencyPeriod fp=FrequencyPeriod.fromValue(payment.getPaymentFrequency());
        return fp!=null?fp.getOchCode():null;
    }

    @Named("appendFullName")
    default String appendFullName(MigrationUser migrationUser){
        return migrationUser.getFirstName()+" "+migrationUser.getLastName();
    }

    @Named("appendSVB")
    default String appendSVB(Payment payment){
        return payment.getSubscriberAccountNumber()+"|SVB|SB0#";
    }

    default String entererId(MigrationUser migrationUser){
        //SVB.#mig.user.principal
        return "";
    }

    default Integer getTotalInstances(Payment payment){
        int totalInstances=0;
        if(payment.getRecurringType()== RecurringType.NONE) return 1;
        if(payment.getRecurringType()==RecurringType.OCCURENCE) {
            totalInstances= Integer.valueOf(payment.getOccurencesRemaining());
        }else if(payment.getRecurringType() == RecurringType.ENDDATE){
            totalInstances=DateUtility.getRecurringByEndDateAndFrequency(
                    payment.getPaymentDate(),payment.getPaymentEndDate(), payment.getPaymentFrequency());
        }
        return totalInstances;
    }

    default public LocalDateTime getPSTDate(){
        return DateUtility.getTimeZoneDate("America/Los_Angeles");
    }
}

