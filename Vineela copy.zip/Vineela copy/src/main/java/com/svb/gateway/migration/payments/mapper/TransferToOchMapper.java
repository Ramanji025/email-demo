package com.svb.gateway.migration.payments.mapper;

import com.svb.gateway.migration.common.utility.DateUtility;
import com.svb.gateway.migration.payments.entity.*;
import com.svb.gateway.migration.payments.model.RecurringType;
import com.svb.gateway.migration.payments.repository.ACMXRepository;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;
import org.mapstruct.factory.Mappers;
import org.springframework.beans.factory.annotation.Autowired;

import java.time.LocalDateTime;

import static com.svb.gateway.migration.common.constants.MigrationConstants.*;

@Mapper(componentModel="spring")
public interface TransferToOchMapper {
    TransferToOchMapper INSTANCE = Mappers.getMapper(TransferToOchMapper.class);

    public static String ZERO_AMOUNT="0.0";
    public static String ZERO="0";
    public static final String ACCT_EXTN2 = "SB0";
    public static final String ACCT_EXTN1 = "SVB";
    public static final String USD = "USD";
    public static final String PST_TIME_ZONE="America/Los_Angeles";
    public static final String TRANSFER_TXN_TYPE = "XFR";

    @Mapping(constant="svc.gateway.migration", target="entererId")
    @Mapping(source="transfer.trnAcCrn", target="txnCrn")
    @Mapping(source="transfer.transferAmount", target="totalAmt")
    @Mapping(source="transfer.transferAmount", target="totalTxnAmt")
    @Mapping(constant=TRANSFER_TXN_TYPE, target="txnType")
    @Mapping(constant ="1", target="dbTs")
    @Mapping(constant = "N", target="delFlg")
    @Mapping(constant = ZERO, target="bulkPmtRefNum")
    @Mapping(constant = "SVB", target="bankId")
    @Mapping(source="migrationUser", target="RModId" , qualifiedByName = "formattedClient")
    @Mapping(source="migrationUser", target="RCreId", qualifiedByName = "formattedClient")
    @Mapping(source="migrationUser.gwClientId", target="corpId")
    @Mapping(source="migrationUser.gwUuid", target="corpUser")
    @Mapping(constant="0", target="freqNdays")
    @Mapping(constant=ZERO, target="parentReqId")
    @Mapping(expression="java(transfer.getRecurringType().getInstancesProcessed())", target="noOfInstancesProcessed")
    @Mapping(constant="N", target="markedForStop")
    @Mapping(constant="N", target="isTxnConfidential")
    @Mapping(constant="N", target="holdFLG")
    @Mapping(constant= "1", target="highestEntrySrlNo")
    @Mapping(expression="java(getPSTDate())", target="RCreTime")
    @Mapping(expression="java(getPSTDate())", target="RModTime")
    @Mapping(source="transfer.transferAmount", target="totalTxnAmtInHomecrn")
    @Mapping(constant=ZERO_AMOUNT, target="reqRecTotalAmt")
    @Mapping(expression = "java(transfer.getRecurringType().getEntries())", target="totalNoOfEntries")
    @Mapping(source="transfer.transferAmount", target="highestEntryAmount")
    @Mapping(constant=ZERO_AMOUNT, target="reqRecTotalTxnAmt")
    @Mapping(constant=ZERO_AMOUNT, target="reqRecTotalTxnAmtHomecrn")
    @Mapping(constant=REQ_STATUS, target="reqStatus")
    @Mapping(constant=ZERO_AMOUNT, target="totalChargeAmt")
    @Mapping(expression="java(getTotalInstances(transfer))", target="totNoOfInstances")
    @Mapping(expression="java(getPSTDate())", target="reqDate")
    @Mapping(source="transfer.transferDate", target="txnDate")
    @Mapping(source= "transfer.transferDate", target="userInputDate")
    @Mapping(constant=VALIDITY_INDICATOR, target="validityIndicator")
    @Mapping(source="transfer.frequencyId", target="pmtFreq")
    @Mapping(source= "transfer", target="freqType", qualifiedByName = "determineFrequency")
    @Mapping(expression="java(transfer.getFromAccountNumber() + \"|SVB|SB0\")", target="accountsUsed")
    OchTransactionRequestHeader convertPastTransferToTRQH(InternalTransfer transfer, MigrationUser migrationUser);

    @Mapping(source="migrationUser", target="tranActRemarks", qualifiedByName = "appendFullName")
    @Mapping(source="transfer.toAccountNumber", target="cpEntityId")
    @Mapping(constant = BANK_ID, target="bankId")
    @Mapping(constant = USD, target="cpAcctCrn")
    @Mapping(constant=CHARGE_CRN, target="chargeCrn")
    @Mapping(constant=CHANNEL_ID_I, target="channelId")
    @Mapping(constant=ZERO_AMOUNT, target="chargeAmt")
    @Mapping(constant="T", target="cpEntityType")
    @Mapping(constant="1", target="dbTs")
    @Mapping(constant="P", target="drcrFlg")
    @Mapping(constant=DEL_FLG, target="delFlg")
    @Mapping(source="transfer.transferAmount", target="entryAmt")
    @Mapping(constant="N", target="isAddendaDataAvailable")
    @Mapping(constant=ZERO_AMOUNT, target="firstPmtAmt")
    @Mapping(constant=ZERO_AMOUNT, target="lastPmtAmt")
    @Mapping(constant=ZERO_AMOUNT, target="limit_rate")
    @Mapping(source="transfer.transferAmount", target="limitAmtInHomeCrn")
    @Mapping(constant=ZERO, target="mandateNo")
    @Mapping(constant=ZERO_AMOUNT, target="negotiatedRate")
    @Mapping(constant=NETWORK_ID, target="networkId")
    @Mapping(constant=ZERO, target="notificationRefNo")
    @Mapping(constant=BENE_REF_NO, target="beneRef")
    @Mapping(constant=NW_COMMISSION_CRN, target="nwCommissionCrn")
    @Mapping(constant=ZERO_AMOUNT, target="nwCommissionAmt")
    @Mapping(constant=ZERO_AMOUNT, target="reqRecEntryAmt")
    @Mapping(constant=ZERO_AMOUNT, target="reqRecTotalEntryAmt")
    @Mapping(constant=ZERO_AMOUNT, target="reqRecLimitAmtInHomecrn")
    @Mapping(constant="1", target="reqSNo")
    @Mapping(source="migrationUser", target="RModId", qualifiedByName = "formattedClient")
    @Mapping(source="migrationUser", target="RCreId", qualifiedByName = "formattedClient")
    @Mapping(expression="java(getPSTDate())", target="RCreTime")
    @Mapping(expression="java(getPSTDate())", target="RModTime")
    @Mapping(source="transfer.transferAmount", target="totEntryAmt")
    @Mapping(source="transfer.fromAccountNumber", target="tranActEntityId")
    @Mapping(expression="java(getPSTDate())", target="valueDate")
    @Mapping(constant=ACCT_EXTN1, target="trnActEntityExtn1")
    @Mapping(constant=ACCT_EXTN2, target="trnActEntityExtn2")
    @Mapping(constant="T", target="tranActEntityType")
    @Mapping(constant=USD, target="tranActCrn")
    @Mapping(constant=SVB, target="cpEntityExtn1")
    @Mapping(constant= SB0, target="cpEntityExtn2")
    @Mapping(source="transfer.frAccNickName",target="tranActEntityNickname")
    @Mapping(source="transfer.toAccNickName",target="cpEntityNickname")
    OchTransactionRequestDetails convertPastTransferToTRQD(InternalTransfer transfer, MigrationUser migrationUser);

    @Mapping(constant=BANK_ID, target="bankId")
    @Mapping(constant = "1", target="dbTs")
    @Mapping(constant="1", target="reqSNo")
    @Mapping(constant=ZERO_AMOUNT, target="fxRate")
    @Mapping(constant=ZERO_AMOUNT, target="debitAmount")
    @Mapping(source="migrationUser", target="RModId", qualifiedByName = "formattedClient")
    @Mapping(source="migrationUser", target="RCreId", qualifiedByName = "formattedClient")
    @Mapping(expression="java(getPSTDate())", target="RCreTime")
    @Mapping(expression="java(getPSTDate())", target="RModTime")
    @Mapping(constant = "N", target="delFlg")
    OchCustomRequestDetails convertPastInternalTransferToCTRD(MigrationUser migrationUser);

    @Named("formattedClient")
    default String appendClient(MigrationUser migrationUser){
        return migrationUser.getGwClientId() + "." + migrationUser.getGwUuid();
    }
    @Named("determineFrequency")
    default String determineFrequency(InternalTransfer transfer){
        return transfer.getRecurringType().name().equals(RecurringType.NONE.name())? FREQ_TYPE_O:FREQ_TYPE_R;
    }

    @Named("appendFullName")
    default String appendFullName(MigrationUser migrationUser){
        return migrationUser.getFirstName()+" "+migrationUser.getLastName();
    }




    default Integer getTotalInstances(InternalTransfer transfer){
        int totalInstances=0;
        if(transfer.getRecurringType()== RecurringType.NONE) return 1;
        if(transfer.getRecurringType()==RecurringType.OCCURENCE) {
            totalInstances= transfer.getScheduleOccurrences() - transfer.getNthOccurrence();
        }else if(transfer.getRecurringType() == RecurringType.ENDDATE){
            totalInstances=DateUtility.getRecurringByEndDateAndFrequency(
                    transfer.getScheduleEndDate()
                            , transfer.getFrequencyId(), transfer.getDayOfTheWeek());
        }
        return totalInstances;
    }


    default public LocalDateTime getPSTDate(){
        return DateUtility.getTimeZoneDate("America/Los_Angeles");
    }
}

