package com.svb.gateway.migration.payments.mapper;

import com.svb.gateway.migration.common.utility.DateUtility;
import com.svb.gateway.migration.payments.entity.*;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;
import org.mapstruct.factory.Mappers;

import java.time.LocalDateTime;

import static com.svb.gateway.migration.common.constants.MigrationConstants.*;

@Mapper(componentModel="spring")
public interface WireTransferToOchMapper {
    WireTransferToOchMapper INSTANCE = Mappers.getMapper(WireTransferToOchMapper.class);

    public static String ZERO_AMOUNT="0.0";
    public static String ZERO="0";
    public static final String ACCT_EXTN2 = "SB0";
    public static final String ACCT_EXTN1 = "SVB";
    public static final String USD = "USD";
    public static final String PST_TIME_ZONE="America/Los_Angeles";
    public static final String TRANSFER_TXN_TYPE = "XFR";

    @Mapping(expression="java(transfer.getFromAccountNumber() + \"|SVB|SB0\" )", target="accountsUsed")
    @Mapping(constant="svc.gateway.migration", target="entererId")
    @Mapping(source="transfer.crncyCode",target="txnCrn")
    @Mapping(source="transfer.debitAmt",target="totalAmt")
    @Mapping(source="transfer.debitAmt",target="totalTxnAmt")
    @Mapping(expression="java(transfer.getTransactionType())",target="txnType")
    @Mapping(constant= FREQ_TYPE_O, target="freqType")
    @Mapping(constant ="1",target="dbTs")
    @Mapping(constant = "N",target="delFlg")
    @Mapping(constant = ZERO,target="bulkPmtRefNum")
    @Mapping(constant = BANK_ID,target="bankId")
    @Mapping(source="migrationUser",target="RModId" , qualifiedByName = "formattedClient")
    @Mapping(source="migrationUser",target="RCreId", qualifiedByName = "formattedClient")
    @Mapping(source="migrationUser.gwClientId",target="corpId")
    @Mapping(source="migrationUser.gwUuid",target="corpUser")
    @Mapping(constant="0", target="freqNdays")
    @Mapping(constant=ZERO,target="parentReqId")
    @Mapping(constant="0",target="noOfInstancesProcessed")
    @Mapping(constant="N",target="markedForStop")
    @Mapping(constant="N",target="isTxnConfidential")
    @Mapping(constant="N",target="holdFLG")
    @Mapping(constant= "1",target="highestEntrySrlNo")
    @Mapping(expression="java(getPSTDate())",target="RCreTime")
    @Mapping(expression="java(getPSTDate())",target="RModTime")
    @Mapping(source="transfer.debitAmt",target="totalTxnAmtInHomecrn")
    @Mapping(constant=ZERO_AMOUNT,target="reqRecTotalAmt")
    @Mapping(constant = "1" ,target="totalNoOfEntries")
    @Mapping(source="transfer.debitAmt", target="highestEntryAmount")
    @Mapping(constant=ZERO_AMOUNT,target="reqRecTotalTxnAmt")
    @Mapping(constant=ZERO_AMOUNT,target="reqRecTotalTxnAmtHomecrn")
    @Mapping(constant=REQ_STATUS,target="reqStatus")
    @Mapping(constant=ZERO_AMOUNT,target="totalChargeAmt")
    @Mapping(constant="1",target="totNoOfInstances")
    @Mapping(source="transfer.entryDate",target="reqDate")
    @Mapping(source="transfer.valueDate",target="txnDate")
    @Mapping(source= "transfer.valueDate",target="userInputDate")
    @Mapping(constant=ZERO,target="tmplId")
    @Mapping(constant=ZERO,target="tmplDiplsayId")
    @Mapping(constant=ZERO,target="fuRecNum")
    @Mapping(constant=VALIDITY_INDICATOR,target="validityIndicator")
    OchTransactionRequestHeader convertPastWireTransferToTRQH(WireTransfer transfer, MigrationUser migrationUser);

    @Mapping(source="migrationUser",target="tranActRemarks", qualifiedByName = "appendFullName")
    @Mapping(source="transfer.bnfId",target="cpEntityId")
    @Mapping(constant = BANK_ID,target="bankId")
    @Mapping(constant = USD,target="cpAcctCrn")
    @Mapping(constant=CHARGE_CRN,target="chargeCrn")
    @Mapping(constant=CHANNEL_ID_I,target="channelId")
    @Mapping(constant=ZERO_AMOUNT,target="chargeAmt")
    @Mapping(constant= "P",target="cpEntityType")
    @Mapping(constant="1",target="dbTs")
    @Mapping(constant="P",target="drcrFlg")
    @Mapping(constant=DEL_FLG,target="delFlg")
    @Mapping(source="transfer.debitAmt",target="entryAmt")
    @Mapping(constant="N",target="isAddendaDataAvailable")
    @Mapping(constant=ZERO_AMOUNT,target="firstPmtAmt")
    @Mapping(constant=ZERO_AMOUNT,target="lastPmtAmt")
    @Mapping(constant=ZERO_AMOUNT,target="limit_rate")
    @Mapping(source="transfer.debitAmt",target="limitAmtInHomeCrn")
    @Mapping(constant=ZERO,target="mandateNo")
    @Mapping(constant=ZERO_AMOUNT,target="negotiatedRate")
    @Mapping(expression="java(transfer.getNetworkId())",target="networkId")
    @Mapping(constant=ZERO,target="notificationRefNo")
    @Mapping(constant=BENE_REF_NO,target="beneRef")
    @Mapping(constant=NW_COMMISSION_CRN,target="nwCommissionCrn")
    @Mapping(constant=NW_COMMISSION_INDICATOR,target="nwCommissionIndicator")
    @Mapping(constant=ZERO_AMOUNT,target="nwCommissionAmt")
    @Mapping(constant=ZERO_AMOUNT,target="reqRecEntryAmt")
    @Mapping(constant=ZERO_AMOUNT,target="reqRecTotalEntryAmt")
    @Mapping(constant=ZERO_AMOUNT,target="reqRecLimitAmtInHomecrn")
    @Mapping(constant="1",target="reqSNo")
    @Mapping(source="migrationUser",target="RModId", qualifiedByName = "formattedClient")
    @Mapping(source="migrationUser",target="RCreId", qualifiedByName = "formattedClient")
    @Mapping(expression="java(getPSTDate())",target="RCreTime")
    @Mapping(expression="java(getPSTDate())",target="RModTime")
    @Mapping(source="transfer.debitAmt",target="totEntryAmt")
    @Mapping(source="transfer.fromAccountNumber",target="tranActEntityId")
    @Mapping(expression="java(getPSTDate())",target="valueDate")
    @Mapping(constant=ACCT_EXTN1,target="trnActEntityExtn1")
    @Mapping(constant=ACCT_EXTN2,target="trnActEntityExtn2")
    @Mapping(constant="T",target="tranActEntityType")
    @Mapping(constant=USD,target="tranActCrn")
    @Mapping(source="transfer.bnfAccountType",target="cpAcctType")
    @Mapping(source="transfer.accNickName",target="tranActEntityNickname")
    OchTransactionRequestDetails convertPastWireTransferToTRQD(WireTransfer transfer, MigrationUser migrationUser);

    @Mapping(constant=BANK_ID,target="bankId")
    @Mapping(constant = "1",target="dbTs")
    @Mapping(constant="1",target="reqSNo")
    @Mapping(constant=ZERO_AMOUNT,target="fxRate")
    @Mapping(constant=ZERO_AMOUNT,target="debitAmount")
    @Mapping(source="migrationUser",target="RModId", qualifiedByName = "formattedClient")
    @Mapping(source="migrationUser",target="RCreId", qualifiedByName = "formattedClient")
    @Mapping(expression="java(getPSTDate())",target="RCreTime")
    @Mapping(expression="java(getPSTDate())",target="RModTime")
    @Mapping(constant = "N",target="delFlg")
    OchCustomRequestDetails convertPastWireTransferToCTRD(MigrationUser migrationUser);

    @Named("formattedClient")
    default String appendClient(MigrationUser migrationUser){
        return migrationUser.getGwClientId() + "." + migrationUser.getGwUuid();
    }


    @Named("appendFullName")
    default String appendFullName(MigrationUser migrationUser){
        return migrationUser.getFirstName()+" "+migrationUser.getLastName();
    }

    default public LocalDateTime getPSTDate(){
        return DateUtility.getTimeZoneDate("America/Los_Angeles");
    }
}

