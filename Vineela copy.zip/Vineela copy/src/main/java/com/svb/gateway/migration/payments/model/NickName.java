package com.svb.gateway.migration.payments.model;

public interface NickName {

    String getAcmxNicName();
    String getAcmtAcName();
}
