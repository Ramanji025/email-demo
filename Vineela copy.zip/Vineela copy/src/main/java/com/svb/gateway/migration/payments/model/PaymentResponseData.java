package com.svb.gateway.migration.payments.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.svb.gateway.migration.common.utility.RecordCount;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

import java.util.HashMap;
import java.util.Map;

@Builder
@Getter
@Setter
public class PaymentResponseData {
    @JsonProperty("GWClientId")
    private String gwClientId;

    @JsonProperty("ECClientId")
    private String ecClientId;

    @JsonProperty("GWPrimaryUserId")
    private String gwPrimaryUserId;

    @JsonProperty("Status")
    private String status;

    @JsonProperty("jobId")
    private Integer jobId;

    @JsonIgnore
    @Builder.Default
    private Map<String, Object> additionalProperties = new HashMap<>();

    @JsonProperty("recordCount")
    private RecordCount recordCount;
}
