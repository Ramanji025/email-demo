package com.svb.gateway.migration.payments.model;

import com.svb.gateway.migration.payments.entity.InternalTransfer;
import com.svb.gateway.migration.payments.entity.Payment;
import lombok.Getter;

@Getter
public enum RecurringType {
    NONE(0, 1),
    UNLIMITED(1,1),
    OCCURENCE(0,1),
    ENDDATE(0,1);

    private int instancesProcessed;
    private int entries;


    RecurringType(int instancesProcessed, int entries){
        this.instancesProcessed=instancesProcessed;
        this.entries=entries;
    }
    public static RecurringType fromPayment(Payment payment) {
        if (payment.getPaymentFrequency() == null) {
            return NONE;
        }
        if (payment.getOccurencesRemaining() != null) {
            return OCCURENCE;
        }
        if (payment.getPaymentEndDate() == null) {
            return UNLIMITED;
        }
        return ENDDATE;
    }

    public static RecurringType fromTransfer(InternalTransfer transfer) {
        if (transfer.getScheduleDetailsId() == null) {
            return NONE;
        }
        if (transfer.getScheduleDetailsId() ==1) {
            return UNLIMITED;
        }
        if (transfer.getScheduleDetailsId() ==2) {
            return OCCURENCE;
        }
        return ENDDATE;
    }
}
