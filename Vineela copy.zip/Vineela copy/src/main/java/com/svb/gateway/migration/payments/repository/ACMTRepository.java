package com.svb.gateway.migration.payments.repository;


import com.svb.gateway.migration.payments.entity.ACMTTransfers;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface ACMTRepository extends JpaRepository<ACMTTransfers, Integer> {

    @Query
            (value = "SELECT * FROM OCHADM.ACCT_MASTER  where acid = ?1 ", nativeQuery = true)
    ACMTTransfers findByAcid(String acid);
}
