package com.svb.gateway.migration.payments.repository;


import com.svb.gateway.migration.payments.entity.OchCustomRequestDetails;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface CustomRequestDetailsRepository extends JpaRepository<OchCustomRequestDetails, Long> {
    @Query
            (value = "SELECT * FROM OCHADM.CUSTOM_TRANSACTION_REQUEST_DETAILS  where req_id = ?1 ", nativeQuery = true)
    OchCustomRequestDetails findByReqId(Long reqId);
}
