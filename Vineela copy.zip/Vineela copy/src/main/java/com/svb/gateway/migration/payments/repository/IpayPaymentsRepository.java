package com.svb.gateway.migration.payments.repository;

import com.svb.gateway.migration.payments.entity.Payment;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface IpayPaymentsRepository extends JpaRepository<Payment, String> {

    @Query(value = "SELECT * FROM MIG_STG_IPAY_PAYMENTS p where p.JOB_ID= ?1 and p.EC_CLIENT_ID= ?2 and PAYMENT_DATE > sysdate", nativeQuery = true)
    List<Payment> findByEcClientId(Long jobId, String ecClientId);

}
