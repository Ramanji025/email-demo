package com.svb.gateway.migration.payments.repository;


import com.svb.gateway.migration.payments.entity.MigrationEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface MigrationEntityRepository extends JpaRepository<MigrationEntity, Long> {

}
