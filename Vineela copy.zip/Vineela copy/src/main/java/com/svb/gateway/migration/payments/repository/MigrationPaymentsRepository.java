package com.svb.gateway.migration.payments.repository;

import com.svb.gateway.migration.payments.entity.MigrationPayment;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface MigrationPaymentsRepository extends JpaRepository<MigrationPayment, Integer> {


    @Query(value = "SELECT * FROM MIG_IPAY_PAYMENTS m where m.jobid= ?1 and status='SUCCESS' ", nativeQuery = true)
    List<MigrationPayment> findByJobId(Long jobId);

    @Query(value = "select * from MIG_IPAY_PAYMENTS  where EC_CLIENT_ID=?1 and JOBID = ?2 and STATUS in ?3", nativeQuery = true)
    List<MigrationPayment> findByEcClientIdAndJobIdAndStatus(String olbClientId, Long jobId, List<String> status);

}
