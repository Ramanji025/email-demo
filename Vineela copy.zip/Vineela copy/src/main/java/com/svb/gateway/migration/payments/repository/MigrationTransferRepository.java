package com.svb.gateway.migration.payments.repository;

import com.svb.gateway.migration.payments.entity.MigrationInternalTransfer;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface MigrationTransferRepository extends JpaRepository<MigrationInternalTransfer, Integer> {

    @Query
            (value = "SELECT * FROM MIG_INT_TRANSFERS m where m.jobid= ?1 and ec_txn_id is not null  and status='SUCCESS' ", nativeQuery = true)
    List<MigrationInternalTransfer> findByJobId(Long jobId);

    @Query
            (value = "SELECT * FROM MIG_INT_TRANSFERS m where m.ec_txn_id= ?1 and lower(m.status)='success'", nativeQuery = true)
    MigrationInternalTransfer findByEcTxnId(Integer ecTxnId);

    @Query
            (value = "SELECT * FROM MIG_INT_TRANSFERS m where m.ec_client_id= ?1 and lower(m.status)='success'", nativeQuery = true)
    List<MigrationInternalTransfer> findByEcClientId(String ecClientId);

    @Query(value = "select * from MIG_INT_TRANSFERS  where ec_client_id=?1", nativeQuery = true)
    List<MigrationInternalTransfer> findByEcClentId(String ecClientId);

    @Query(value = "select * from MIG_INT_TRANSFERS  where EC_CLIENT_ID=?1 and JOBID = ?2 and STATUS in ?3", nativeQuery = true)
    List<MigrationInternalTransfer> findByEcClientIdAndJobIdAndStatus(String olbClientId, Long jobId, List<String> status);
}
