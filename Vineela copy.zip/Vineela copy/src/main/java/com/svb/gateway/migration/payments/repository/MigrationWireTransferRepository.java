package com.svb.gateway.migration.payments.repository;

import com.svb.gateway.migration.payments.entity.MigrationInternalTransfer;
import com.svb.gateway.migration.payments.entity.MigrationWireTransfer;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface MigrationWireTransferRepository extends JpaRepository<MigrationWireTransfer, Integer> {

    @Query
            (value = "SELECT * FROM MIG_WIRE_OUTGOING m where m.jobid = ?1 AND m.ec_txn_id is not null and status='SUCCESS' ", nativeQuery = true)
    List<MigrationWireTransfer> findByJobId(Long jobId);

    @Query(value = "select * from MIG_WIRE_OUTGOING  where EC_CLIENT_ID=?1 and JOBID = ?2 and STATUS in ?3", nativeQuery = true)
    List<MigrationWireTransfer> findByEcClientIdAndJobIdAndStatus(String olbClientId, Long jobId, List<String> status);
}

