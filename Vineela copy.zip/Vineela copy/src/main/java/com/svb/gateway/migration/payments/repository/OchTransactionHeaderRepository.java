package com.svb.gateway.migration.payments.repository;



import com.svb.gateway.migration.payments.entity.OchTransactionHeader;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface OchTransactionHeaderRepository extends JpaRepository<OchTransactionHeader, Long> {

    @Query
            (value = "SELECT * FROM OCHADM.TRANSACTION_HEADER  where req_id = ?1 ", nativeQuery = true)
    OchTransactionHeader findByReqId(Long reqId);
}
