package com.svb.gateway.migration.payments.repository;


import com.svb.gateway.migration.payments.entity.OchTransactionRequestDetails;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface TransactionRequestDetailsRepository extends JpaRepository<OchTransactionRequestDetails, Long> {

    @Query
            (value = "SELECT * FROM OCHADM.TRANSACTION_REQUEST_DETAILS  where req_id = ?1 ", nativeQuery = true)
    OchTransactionRequestDetails findByReqId(Long reqId);

}
