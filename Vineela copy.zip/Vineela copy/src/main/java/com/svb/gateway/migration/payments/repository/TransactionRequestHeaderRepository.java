package com.svb.gateway.migration.payments.repository;


import com.svb.gateway.migration.payments.entity.OchTransactionRequestHeader;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface TransactionRequestHeaderRepository extends JpaRepository<OchTransactionRequestHeader, Long> {

    @Query
            (value = "SELECT * FROM OCHADM.TRANSACTION_REQUEST_HEADER  where req_id = ?1 ", nativeQuery = true)
    OchTransactionRequestHeader findByReqId(Long reqId);

}
