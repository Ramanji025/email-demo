package com.svb.gateway.migration.payments.repository;


import com.svb.gateway.migration.payments.entity.WireTransfer;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface WireTransferRepository extends JpaRepository<WireTransfer, Integer> {

    @Query
            (value = "SELECT * FROM MIG_STG_WIRE_OUTGOING m where JOB_ID = ?1 AND m.olb_client_id = ?2 ", nativeQuery = true)
    List<WireTransfer> findByOlbClientId(Long jobId, String olbClientId);
}
