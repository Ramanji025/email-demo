package com.svb.gateway.migration.payments.service;

import com.svb.gateway.migration.common.exception.ServiceException;
import com.svb.gateway.migration.common.logging.Message;
import com.svb.gateway.migration.common.mapper.MigrationEntityMapper;
import com.svb.gateway.migration.common.utility.PaymentUtils;
import com.svb.gateway.migration.common.utility.RecordCount;
import com.svb.gateway.migration.payments.entity.MigrationPayment;
import com.svb.gateway.migration.payments.entity.Payment;
import com.svb.gateway.migration.payments.mapper.MigrationPaymentModelMapper;
import com.svb.gateway.migration.payments.model.PaymentResponse;
import com.svb.gateway.migration.payments.model.PaymentResponseData;
import com.svb.gateway.migration.payments.model.RecurringType;
import com.svb.gateway.migration.payments.repository.MigrationEntityRepository;
import com.svb.gateway.migration.payments.repository.MigrationPaymentsRepository;
import com.svb.gateway.migration.payments.repository.IpayPaymentsRepository;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.function.Function;
import java.util.stream.Collectors;


import static com.svb.gateway.migration.common.constants.MigrationConstants.STATUS_FAILURE;
import static com.svb.gateway.migration.common.constants.MigrationConstants.STATUS_SUCCESS;

@Log4j2
@Service
public class IpayPaymentService {

    public static final String NO_DATA_TO_MIGRATE = "No payments to migrate for provided client Id";
    public static final String NO_IPAY_PAYMENTS_TO_MIGRATE = "No payments to migrate";

    @Autowired
    private OchPaymentService ochPaymentService;

    @Autowired
    private MigrationPaymentsRepository migrationPaymentsRepository;

    @Autowired
    private IpayPaymentsRepository ipayPaymentsRepository;

    @Autowired
    private MigrationEntityRepository migrationEntityRepository;

    public PaymentResponse createPayments(Long jobId, String clientId) throws ServiceException {
        return process(jobId, clientId);
    }

    protected PaymentResponse process(Long jobId, String clientId)  throws ServiceException{
        PaymentResponse paymentResponse=new PaymentResponse();
        Message logMessage = Message.create().jobId(jobId).clientId(clientId).entityName(Message.Entity.payment);

        log.info(logMessage.descr("Entry: Processing payments for client"));
        final RecordCount recordCount=new RecordCount();

        List<Payment> stagingPaymentsList = ipayPaymentsRepository.findByEcClientId(jobId, clientId);
        log.debug(logMessage.descr("PaymentService single payments , for transactions : "+stagingPaymentsList.size()));

        if (stagingPaymentsList.isEmpty()) {
            recordCount.stopTime();
            migrationEntityRepository.save(MigrationEntityMapper.INSTANCE.convertPaymentToMigEntity(paymentResponse, recordCount));
            log.error(logMessage.descr("No payments available for processing for client"));
            throw new ServiceException(NO_DATA_TO_MIGRATE, NO_IPAY_PAYMENTS_TO_MIGRATE);
        }
        applyRecurringType(stagingPaymentsList);

        Map<Integer, MigrationPayment> migrationPaymentMap = currentMigratedPaymentsByPaymentId(jobId);
        List<MigrationPayment> migrationPaymentList=new ArrayList<>();

        stagingPaymentsList.stream().forEach(payment -> {

            log.debug(logMessage.descr("Processing Payment:").srcId(String.valueOf(payment.getPaymentId())));
            MigrationPayment newPayment=null;
            MigrationPayment migratedPayment = null;
            try {
                migratedPayment = migrationPaymentMap.get(payment.getPaymentId());

                if (PaymentUtils.inValidRecurringPayment(payment) ) {
                    newPayment = MigrationPaymentModelMapper.INSTANCE.convertIpayPaymentToEntity(payment, migratedPayment);
                    newPayment.setJobId(jobId);
                    migrationPaymentList.add(newPayment);
                    recordCount.addFailure();
                } else if (migratedPayment != null && !migratedPayment.canRunAgain()  ) {
                    newPayment = MigrationPaymentModelMapper.INSTANCE.convertIpayPaymentToEntity(payment, migratedPayment);
                    // we do not need to save this again. It is already there. No updates are expected.
                    log.error(Message.create().descr(newPayment.getComments()).clientId(clientId).srcId(String.valueOf(newPayment.getPaymentId())));
                } else {
                    newPayment = ochPaymentService.insert(jobId, payment);
                    newPayment.updateFrom(migratedPayment);
                    migrationPaymentList.add(newPayment);
                    log.debug(logMessage.descr(newPayment.getComments()+": Payment Insert Done").srcId(String.valueOf(newPayment.getPaymentId())));
                    recordCount.updateCounter(newPayment.getStatus());
                }
                createResponse(paymentResponse, recordCount, migratedPayment, newPayment, STATUS_SUCCESS);
                log.debug(logMessage.descr("Successfully inserted the Payment for ").srcId(String.valueOf(newPayment.getPaymentId())));
            }catch (ServiceException e) {
                recordCount.addFailure();
                log.error(Message.create().descr(e.getMessage()).clientId(clientId).status(STATUS_FAILURE));
                createResponse(paymentResponse, recordCount, migratedPayment, newPayment, STATUS_FAILURE);
                paymentResponse.setAdditionalProperty(e.getErrorCode(), e.getErrorMessage());
            }

        });
        if(migrationPaymentList!=null && !migrationPaymentList.isEmpty()){
            migrationPaymentsRepository.saveAll(migrationPaymentList); // insert or update
        }

        recordCount.stopTime();
        if(recordCount.getTotal()>0){
            migrationEntityRepository.save(MigrationEntityMapper.INSTANCE.convertPaymentToMigEntity(paymentResponse, recordCount));
        }
        log.info(logMessage.descr("Processed all the Payments that were eligible for migration."));
        return paymentResponse;
    }

    private Map<Integer, MigrationPayment> currentMigratedPaymentsByPaymentId(Long jobId) {
        return Optional.ofNullable(migrationPaymentsRepository.findByJobId(jobId)).orElse(new ArrayList<>()).stream()
                    .filter(p->p!=null)
                    .collect(Collectors.toMap(MigrationPayment::getPaymentId, Function.identity()));
    }

    private void applyRecurringType(List<Payment> paymentsList) {
        paymentsList.stream().forEach(payment-> payment.setRecurringType(RecurringType.fromPayment(payment)));
    }

    private void createResponse(PaymentResponse paymentResponse, RecordCount recordCount, MigrationPayment migratedPayment, MigrationPayment newPayment, String status) {

        if(newPayment!=null){
            paymentResponse.setPaymentResponseData(PaymentResponseData.builder()
                    .gwClientId(newPayment.getGwClientId())
                    .ecClientId(newPayment.getEcClientId())
                    .jobId(newPayment.getJobId()==null?0:newPayment.getJobId().intValue())
                    .status(status).recordCount(recordCount).build());
        }
        else if(migratedPayment!=null){
            paymentResponse.setPaymentResponseData(PaymentResponseData.builder()
                    .gwClientId(migratedPayment.getGwClientId())
                    .ecClientId(migratedPayment.getEcClientId())
                    .jobId(migratedPayment.getJobId()==null?0:migratedPayment.getJobId().intValue())
                    .status(status).recordCount(recordCount).build());
        }
        paymentResponse.setAdditionalProperty("Total Records Total is: ", recordCount.getTotal());
        paymentResponse.setAdditionalProperty("Total Succesfully migrated txn Records: ", recordCount.getSuccess());
        paymentResponse.setAdditionalProperty("Total Failed Records :", recordCount.getFailure());
    }
}
