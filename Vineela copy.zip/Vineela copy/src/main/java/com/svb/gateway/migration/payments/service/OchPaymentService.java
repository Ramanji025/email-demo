package com.svb.gateway.migration.payments.service;

import com.svb.gateway.migration.beneficiaries.entity.MigBeneficiary;
import com.svb.gateway.migration.beneficiaries.repository.MigBeneficiaryRepository;
import com.svb.gateway.migration.common.constants.MigrationConstants;
import com.svb.gateway.migration.common.exception.ServiceException;
import com.svb.gateway.migration.common.logging.Message;
import com.svb.gateway.migration.payments.entity.*;
import com.svb.gateway.migration.payments.mapper.*;
import com.svb.gateway.migration.payments.model.NickName;
import com.svb.gateway.migration.payments.repository.*;
import com.svb.gateway.migration.payments.repository.ACMTRepository;
import com.svb.gateway.migration.payments.repository.PAYMRepository;
import com.svb.gateway.migration.payments.entity.PAYMTransfers;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;
import java.util.List;

import static com.svb.gateway.migration.common.constants.MigrationConstants.*;
import static com.svb.gateway.migration.common.logging.Message.SourceType.iPay;
import static com.svb.gateway.migration.common.logging.Message.Entity;


@Log4j2
@Service
@Transactional(rollbackFor = Exception.class)
public class OchPaymentService {

    public static final String PAYMENT_SUCCESS_MESSAGE="Payment stored in OCH completed successfully for payment Id {}";
    public static final String USER_IS_NOT_MIGRATED_FOR_CLIENT_ID = "User is not migrated for client Id : ";

    @Autowired
    TransactionRequestHeaderRepository transactionRequestHeaderRepository;

    @Autowired
    TransactionRequestDetailsRepository transactionRequestDetailsRepository;

    @Autowired
    CustomRequestDetailsRepository customRequestDetailsRepository;

    @Autowired
    MigrationUserRepository migrationUserRepository;

    @Autowired
    PAYMRepository paymRepository;

    @Autowired
    private MigBeneficiaryRepository migBeneficiaryRepository;

    @Autowired
    private OchTransactionHeaderRepository ochTransactionHeaderRepository;

    @Autowired
    OchMapper ochMapper;

    @Autowired
    ACMXRepository acmxRepository;

    @Autowired
    ACMTRepository acmtRepository;

    private Long createOchPayment(String eCClientId, OchTransactionRequestHeader transactionRequestHeader, OchTransactionRequestDetails transactionRequestDetails, OchCustomRequestDetails customRequestDetails) {

        transactionRequestHeaderRepository.save(transactionRequestHeader);
        Long ochRequestId=transactionRequestHeader.getReqId();

        log.debug(Message.create().descr("TRQH committed with req Id: " + ochRequestId).clientId(eCClientId));
        transactionRequestDetails.setReqId(ochRequestId);

        transactionRequestDetailsRepository.save(transactionRequestDetails);
        log.debug(Message.create().descr("TRQD committed with req Id: " + ochRequestId).clientId(eCClientId));
        customRequestDetails.setReqId(ochRequestId);

        customRequestDetailsRepository.save(customRequestDetails);
        log.debug(Message.create().descr("CTRD committed with req Id: " + ochRequestId).clientId(eCClientId));

        return ochRequestId;
    }

    public MigrationPayment insert(Long jobId, Payment payment) throws ServiceException {

        log.info(Message.create().entityName(Entity.payment).descr("Inserting Payment data for:").clientId(payment.getEcClientId()).toString());
        MigrationUser migrationUser = migrationUserRepository.findByEcClientAndPrimaryUser(payment.getEcClientId());
        if (migrationUser == null) {
            log.error(Message.create().clientId(payment.getEcClientId()).descr(USER_IS_NOT_MIGRATED_FOR_CLIENT_ID).srcId(String.valueOf(payment.getPaymentId())).srcType(iPay));
            throw new ServiceException(USER_IS_NOT_MIGRATED_FOR_CLIENT_ID+ payment.getEcClientId());
        }
        MigrationPayment migrationPayment;
        Long ochRequestId=null;
        try{

            // set dependency on Beneficiary
            getAndSetBeneficiary(jobId, payment);

            payment.setAccNickName(mapNickName(payment.getSubscriberAccountNumber(),migrationUser.getGwClientId() ));
            OchTransactionRequestHeader transactionRequestHeader=PaymentToOchMapper.INSTANCE.convertSinglePastPaymentToTRQH(payment, migrationUser);
            OchTransactionRequestDetails transactionRequestDetails=PaymentToOchMapper.INSTANCE.convertSinglePastPaymentToTRQD(payment, migrationUser);
            OchCustomRequestDetails customRequestDetails=PaymentToOchMapper.INSTANCE.convertSinglePastPaymentToCTRD(migrationUser);

            ochRequestId = createOchPayment(payment.getEcClientId(), transactionRequestHeader, transactionRequestDetails, customRequestDetails);
            log.info(Message.create().descr(PAYMENT_SUCCESS_MESSAGE).clientId(payment.getEcClientId()).srcId(String.valueOf(payment.getPaymentId())).targetId(String.valueOf(ochRequestId)));

            migrationPayment= setResponse(payment, migrationUser, ochRequestId, MigrationConstants.STATUS_SUCCESS,"");

        }catch(Exception e){
            log.error(Message.create().descr(e.getMessage()).clientId(payment.getEcClientId()).operation("Payments").entityName(Message.Entity.payment));
            migrationPayment = setResponse(payment, migrationUser, ochRequestId, MigrationConstants.STATUS_FAILURE, e.getMessage());
        }
        return migrationPayment;
    }

    public MigrationInternalTransfer insert(InternalTransfer transfer) throws ServiceException {

        log.info(Message.create().descr("Inserting Internal Transfers for client").clientId(transfer.getOlbClientId()));
        MigrationInternalTransfer migrationTransfer;
        MigrationUser migrationUser=migrationUserRepository.findByEcUserLoginId(transfer.getUserLoginId());
        if (migrationUser == null) {
            log.error(Message.create().descr(USER_IS_NOT_MIGRATED_FOR_CLIENT_ID).clientId(transfer.getOlbClientId()));
            throw new ServiceException(USER_IS_NOT_MIGRATED_FOR_CLIENT_ID+ transfer.getOlbClientId());
        }
        Long ochRequestId=null;
        try {

            transfer.setFrAccNickName(mapNickName(transfer.getFromAccountNumber(),migrationUser.getGwClientId() ));
            transfer.setToAccNickName(mapNickName(transfer.getToAccountNumber(),migrationUser.getGwClientId() ));

            OchTransactionRequestHeader transactionRequestHeader = TransferToOchMapper.INSTANCE.convertPastTransferToTRQH(transfer, migrationUser);
            OchTransactionRequestDetails transactionRequestDetails=TransferToOchMapper.INSTANCE.convertPastTransferToTRQD(transfer, migrationUser);
            OchCustomRequestDetails customRequestDetails=TransferToOchMapper.INSTANCE.convertPastInternalTransferToCTRD(migrationUser);

            ochRequestId = createOchPayment(transfer.getOlbClientId(), transactionRequestHeader, transactionRequestDetails, customRequestDetails);
            log.info(Message.create().descr(PAYMENT_SUCCESS_MESSAGE).clientId(transfer.getOlbClientId()));

            migrationTransfer=setResponse(transfer, migrationUser, ochRequestId, MigrationConstants.STATUS_SUCCESS,"");

        }catch(Exception e){
            log.error(Message.create().descr(e.getMessage()).operation("Migration of Internal Transfers"));
            migrationTransfer=setResponse(transfer, migrationUser, ochRequestId, MigrationConstants.STATUS_FAILURE, e.getMessage());
        }

        return migrationTransfer;
    }

    public MigrationWireTransfer insert(Long jobId, WireTransfer transfer) throws ServiceException {
        log.debug(Message.create().descr("Inserting Wire transfers for client")
                .clientId(transfer.getOlbClientId()).srcId(String.valueOf(transfer.getWireTxnId())));
        MigrationWireTransfer migrationTransfer=new MigrationWireTransfer();
        Long ochRequestId=null;

        MigrationUser migrationUser = migrationUser(transfer);

        try {
            checkFutureDatedPayment(transfer);

            // set dependency on Beneficiary
            migrationTransfer.setBeneId(validateAndReturnBeneficiary(jobId, transfer).getBeneficiaryId());

            applyTemplate(transfer, migrationTransfer);

            transfer.setAccNickName(mapNickName(transfer.getFromAccountNumber(),migrationUser.getGwClientId().toUpperCase()));
            OchTransactionRequestHeader transactionRequestHeader = WireTransferToOchMapper.INSTANCE.convertPastWireTransferToTRQH(transfer, migrationUser);
            OchTransactionRequestDetails transactionRequestDetails=WireTransferToOchMapper.INSTANCE.convertPastWireTransferToTRQD(transfer, migrationUser);
            OchCustomRequestDetails customRequestDetails= WireTransferToOchMapper.INSTANCE.convertPastWireTransferToCTRD(migrationUser);

            ochRequestId = createOchPayment(transfer.getOlbClientId(), transactionRequestHeader, transactionRequestDetails, customRequestDetails);
            log.info(Message.create().descr(PAYMENT_SUCCESS_MESSAGE).clientId(transfer.getOlbClientId()).operation("Wire Transfers Migration").status(STATUS_SUCCESS));

            migrationTransfer= setResponse(transfer, migrationUser, ochRequestId, MigrationConstants.STATUS_SUCCESS,"");

        } catch(Exception e){
            log.error(Message.create().descr(e.getMessage()).operation("Migration of Wires Transfers"));
            migrationTransfer = setResponse(transfer, migrationUser, ochRequestId, MigrationConstants.STATUS_FAILURE, e.getMessage());
        }

        return migrationTransfer;
    }

    private void checkFutureDatedPayment(WireTransfer transfer) throws ServiceException{
        if(transfer.getValueDate()==null){
            throw new ServiceException("Value date for wire transfer is null for transaction id ="+transfer.getWireTxnId());
        }
        if(transfer.getValueDate().compareTo(new Date()) < 0){
            throw new ServiceException("Transfer Date is not future date:", "This is not a scheduled Transfer as transfer date is past date.");
        }
    }

    private void applyTemplate(WireTransfer transfer, MigrationWireTransfer migrationTransfer) {
        if (transfer.getTemplateId() != null) {
            migrationTransfer.setTemplateId(transfer.getTemplateId().toString());
        } else {
            migrationTransfer.setTemplateId(transfer.getWireTxnId().toString());
        }
    }

    private MigrationUser migrationUser(WireTransfer transfer) throws ServiceException{
        MigrationUser migrationUser=migrationUserRepository.findByEcUserLoginId(transfer.getEntryopId());
        if (migrationUser == null) {
            throw new ServiceException(USER_IS_NOT_MIGRATED_FOR_CLIENT_ID + transfer.getOlbClientId());
        }
        return migrationUser;
    }

    private MigBeneficiary validateAndReturnBeneficiary(Long jobId, WireTransfer transfer) throws ServiceException{
        MigBeneficiary migBeneficiary=null;

        if (null != transfer.getTemplateId()) {
            migBeneficiary = migBeneficiaryRepository.findByTemplateIdandAndEcClientId(jobId, transfer.getTemplateId(), transfer.getOlbClientId());
        } else {
            migBeneficiary = migBeneficiaryRepository.findByTemplateIdandAndEcClientId(jobId, transfer.getWireTxnId(), transfer.getOlbClientId());
        }
        if (migBeneficiary == null) {
            throw new ServiceException("The associated template with template id : "+ transfer.getTemplateId()+ " was not migrated as recipient in gateway.");
        }
        try{
            Long.valueOf(migBeneficiary.getBeneficiaryId());
        }
        catch(NumberFormatException e){
            throw new ServiceException("beneficiaryId "+migBeneficiary.getBeneficiaryId()+" has to be a numeric value to look up by BnfId in PAYMRepository");
        }
        PAYMTransfers paymTransfers = paymRepository.findByBnfId(migBeneficiary.getBeneficiaryId());
        if (!(paymTransfers.getBankIdentifier().equalsIgnoreCase(transfer.getBeneBankId()))) {
            throw new ServiceException("Staging Bank Identifier not matching with PAYM"+ transfer.getBeneBankId());
        }
        if (!(paymTransfers.getPaymAcctId().equalsIgnoreCase(transfer.getBeneAccount()))) {
            throw new ServiceException("Staging Bene Account not matching with PAYM"+ transfer.getBeneAccount());
        }

        transfer.setBnfAccountType(paymTransfers.getBnfAcctType());
        transfer.setBnfId(paymTransfers.getBnfId());

        //Throw Exception if Payment type is not DOM or INTL
        if (!(DOM.equalsIgnoreCase(transfer.getPmtType()) || INTL.equalsIgnoreCase(transfer.getPmtType()))) {
            throw new ServiceException("Transaction is not of DOM OR INTL type", transfer.getWireTxnId().toString());
        }
        return migBeneficiary;
    }

    public String mapNickName(String accNumber, String gwClientId){

        NickName nickName= acmxRepository.findByAccId(accNumber,gwClientId);
        if(nickName!=null && nickName.getAcmxNicName()!= null){
            return nickName.getAcmxNicName();
            }
        else if (nickName!=null && nickName.getAcmtAcName()!= null){
            return nickName.getAcmtAcName();
        }
        return "";
    }

    private MigrationPayment setResponse(Payment payment, MigrationUser migrationUser, Long ochRequestId, String status, String message) {
        MigrationPayment migrationPayment= MigrationPaymentModelMapper.INSTANCE.convertIpayPaymentToEntity(payment, migrationUser);
        migrationPayment.setGwReqId(ochRequestId);
        migrationPayment.setStatus(status);
        migrationPayment.setComments(message);
        return migrationPayment;
    }

    private MigrationInternalTransfer setResponse(InternalTransfer transfer, MigrationUser migrationUser, Long ochRequestId, String status, String message) {
        MigrationInternalTransfer migrationTransfer= MigrationPaymentModelMapper.INSTANCE.convertTransferToEntity(transfer, migrationUser);
        migrationTransfer.setGwReqId(ochRequestId);
        migrationTransfer.setStatus(status);
        migrationTransfer.setComments(message);
        return migrationTransfer;
    }

    private MigrationWireTransfer setResponse(WireTransfer transfer, MigrationUser migrationUser, Long ochRequestId, String status, String message) {
        MigrationWireTransfer migrationTransfer= MigrationPaymentModelMapper.INSTANCE.convertTransferToEntity(transfer, migrationUser);
        migrationTransfer.setGwReqId(ochRequestId);
        migrationTransfer.setStatus(status);
        migrationTransfer.setComments(message);
        return migrationTransfer;
    }

    private void getAndSetBeneficiary(Long jobId, Payment payment) throws ServiceException {
        MigBeneficiary beneficiary=migBeneficiaryRepository.findByBeneSourceForIpayMigrated(jobId, payment.getBeneficiaryId());
        if(beneficiary==null || beneficiary.getBeneficiaryId()==null){
            // beneficiary.getBeneficiaryId()==null indicates that the beneficiary was not successfully created
            throw new ServiceException("No Beneficiary found for ", payment.getBeneficiaryId().toString());
        }else{
            payment.setTargetBeneficiaryId(Integer.valueOf(beneficiary.getBeneficiaryId()));
        }
    }

    public boolean rollback(List<Long> requestIds) {
        try {
            if(requestIds.isEmpty()){
                log.info("OCH RequestIds list is empty, nothing to soft delete here.");
                return false;
            }

            ochMapper.deleteTransactionRequests(requestIds, "TRANSACTION_REQUEST_HEADER");
            ochMapper.deleteTransactionRequests(requestIds, "TRANSACTION_REQUEST_DETAILS");
            ochMapper.deleteTransactionRequests(requestIds, "CUSTOM_TRANSACTION_REQUEST_DETAILS");
            log.info("Soft delete successful in OCH for requestIds = {}", requestIds);

        }catch (Exception e){
            log.error("OCH could not be updated for {} due to {}", requestIds, e.getMessage());
            return false;
        }
        return true;
    }
}
