package com.svb.gateway.migration.payments.service;

import com.svb.gateway.migration.client.entity.MigClient;
import com.svb.gateway.migration.client.repository.MigClientRepository;
import com.svb.gateway.migration.common.constants.MigrationConstants;
import com.svb.gateway.migration.common.exception.ServiceException;
import com.svb.gateway.migration.common.logging.Message;
import com.svb.gateway.migration.common.mapper.MigrationEntityMapper;
import com.svb.gateway.migration.common.utility.BasicValidation;
import com.svb.gateway.migration.common.utility.EcClientIdCheck;
import com.svb.gateway.migration.common.utility.RecordCount;
import com.svb.gateway.migration.payments.entity.*;
import com.svb.gateway.migration.payments.mapper.MigrationTransferModelMapper;
import com.svb.gateway.migration.payments.mapper.TransferMapper;
import com.svb.gateway.migration.payments.model.*;
import com.svb.gateway.migration.payments.repository.*;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.sql.Timestamp;
import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

import static com.svb.gateway.migration.common.constants.MigrationConstants.INTERNAL_TRANSFER;
import static com.svb.gateway.migration.common.constants.MigrationConstants.WIRE_TRANSFER;

@Log4j2
@Service
public class TransferService {

    @Autowired
    private OchPaymentService ochPaymentService;

    @Autowired
    private MigrationEntityRepository migrationEntityRepository;

    @Autowired
    MigClientRepository migClientRepository;

    @Autowired
    InternalTransferRepository internalTransferRepository;

    @Autowired
    MigrationTransferRepository migrationTransferRepository;

    @Autowired
    WireTransferRepository wireTransferRepository;

    @Autowired
    MigrationWireTransferRepository migrationWireTransferRepository;

    @Autowired
    TransferMapper transferMapper;


    public TransferResponse internalTransfer(Long jobId, MigClient migClient) throws ServiceException {

        TransferResponse transferResponse = new TransferResponse();
        final RecordCount recordCount=new RecordCount();
        recordCount.setStartTime(new Timestamp(System.currentTimeMillis()));
        Message logMessage = Message.create().jobId(jobId).clientId(migClient.getEcClientId()).gwClientId(migClient.getGwClientId()).operation(INTERNAL_TRANSFER);
        try {

            List<InternalTransfer> transferList = internalTransferRepository.findByOlbClientId(jobId, migClient.getEcClientId());
            log.debug(logMessage.descr("TransfersService. Internal transfers for : " + transferList));


            if (transferList.isEmpty()) {
                recordCount.setEndTime(new Timestamp(System.currentTimeMillis()));
                migrationEntityRepository.save(MigrationEntityMapper.INSTANCE.convertTransferToMigEntity(migClient, recordCount, INTERNAL_TRANSFER));
                log.error(logMessage.descr("No Transactions present for provided client Id: "));
                throw new ServiceException("No Transactions present for provided client Id: ", migClient.getEcClientId());
            }
            applyRecurringType(transferList);

            List<MigrationInternalTransfer> migrationInternalTransferList=new ArrayList();
            Map<Integer, MigrationInternalTransfer> processedRecords=currentMigratedInternalTransfers(jobId);

            transferList.forEach(transferRec -> {
                log.debug(logMessage.descr("processing record with ecTxnId").srcId(String.valueOf(transferRec.getTrnId())).toString());
                MigrationInternalTransfer migrationTransfer=null, processedRecord=null;

                try {
                    processedRecord=processedRecords.get(transferRec.getTrnId());
                    if (processedRecord != null && !processedRecord.canRunAgain()) {
                        migrationTransfer =
                                MigrationTransferModelMapper.INSTANCE.convertMigrationTransferToEntity(transferRec, processedRecord);
                        log.error(Message.create().descr("Record already processed with req id: "+processedRecord.getGwReqId()).srcId(String.valueOf(transferRec.getTrnId())));
                    } else {
                        log.debug(Message.create().descr("Processing record for EcTxnID").srcId(String.valueOf(transferRec.getTrnId())).toString());
                        migrationTransfer = ochPaymentService.insert(transferRec);
                        migrationTransfer.updateFrom(processedRecord);
                        migrationInternalTransferList.add(migrationTransfer);  // insert or update
                        recordCount.updateCounter(migrationTransfer.getStatus());
                        log.debug(logMessage.descr("Audit data written to MIG_INTERNAL_TRANSFERS").srcId(String.valueOf(transferRec.getTrnId())));
                    }

                    createResponse(transferResponse, recordCount, processedRecord, migrationTransfer, MigrationConstants.STATUS_SUCCESS);
                } catch (ServiceException e) {
                    recordCount.addFailure();
                    log.error(logMessage.descr(e.getErrorMessage()));
                    transferResponse.setAdditionalProperty(e.getErrorCode(), e.getErrorMessage());
                    createResponse(transferResponse, recordCount, processedRecord, migrationTransfer, MigrationConstants.STATUS_FAILURE);
                }
            });
            if(migrationInternalTransferList !=null && !migrationInternalTransferList.isEmpty()) {
                migrationTransferRepository.saveAll(migrationInternalTransferList);
            }
            recordCount.stopTime();
            MigrationEntity migEntity=MigrationEntityMapper.INSTANCE.convertTransferToMigEntity(migClient, recordCount, INTERNAL_TRANSFER);
            if(recordCount.getTotal()>0){
                migrationEntityRepository.save(migEntity);
                log.info(logMessage.descr("Data committed to MIG_ENTITY table for Internal transfer"));
            }


        } catch (ServiceException e) {
           log.error(logMessage.descr(e.getErrorMessage()));
            transferResponse.setAdditionalProperty(e.getErrorCode(), e.getErrorMessage());
        }
       return transferResponse;
    }


    public TransferResponse wireTransfer(Long jobId, MigClient migClient) throws ServiceException {
        Message logMessage = Message.create().clientId(migClient.getEcClientId()).jobId(jobId);
        log.debug(logMessage.descr("Migration Initiated").operation("WIRES"));
        EcClientIdCheck.ecClientIdFormatCheck(migClient.getEcClientId());

        TransferResponse transferResponse = new TransferResponse();
        final RecordCount recordCount=new RecordCount();
        recordCount.setStartTime(new Timestamp(System.currentTimeMillis()));

        try {

            BasicValidation.transfersClientIdNullCheck(migClient);

//        Step1: Load transaction records based on Client details from the Staging Database
            List<WireTransfer> transferList = wireTransferRepository.findByOlbClientId(jobId, migClient.getEcClientId());
            log.debug("Wire Transfer Service, for transfers : " + transferList);

            if (transferList.isEmpty()) {
                recordCount.setEndTime(new Timestamp(System.currentTimeMillis()));
                migrationEntityRepository.save(MigrationEntityMapper.INSTANCE.convertTransferToMigEntity(migClient, recordCount, WIRE_TRANSFER));
                throw new ServiceException("No Transactions present for provided client Id: ", migClient.getEcClientId());
            }

            List<MigrationWireTransfer> migrationWireTransferList=new ArrayList();
            Map<Integer, MigrationWireTransfer> processedRecords=currentMigratedWireTransfers(jobId);

            transferList.forEach(transferRec -> {
                log.debug(Message.create().descr("Processing transaction record with EcTxnID:").srcId(String.valueOf(transferRec.getWireTxnId())).toString());
                MigrationWireTransfer migrationWireTransfer=null;
                MigrationWireTransfer processedRecord = null;
                try {
                    processedRecord = processedRecords.get(transferRec.getWireTxnId());
                    if (processedRecord != null &&  !processedRecord.canRunAgain()) {
                        migrationWireTransfer= MigrationTransferModelMapper.INSTANCE.convertWireMigrationTransferToEntity(transferRec, processedRecord);
                        log.error(Message.create().descr("Record already processed for EcClientId").srcId(String.valueOf(processedRecord.getEcTxnId())).toString());
                    } else {
                        migrationWireTransfer=ochPaymentService.insert(jobId, transferRec);
                        migrationWireTransfer.updateFrom(processedRecord);
                        recordCount.updateCounter(migrationWireTransfer.getStatus());
                        migrationWireTransferList.add(migrationWireTransfer);
                        log.info(Message.create().descr("Transaction has been migrated with Req Id").targetId(String.valueOf(migrationWireTransfer.getGwReqId())).toString()); //record now processed with req Id:
                    }
                    log.debug(logMessage.descr("Data written into Wire Audit table"));
                    createResponse(transferResponse, recordCount, processedRecord, migrationWireTransfer, MigrationConstants.STATUS_SUCCESS);
                } catch (ServiceException e) {
                    recordCount.addFailure();
                    log.error(logMessage.descr(e.getErrorMessage()));
                    transferResponse.setAdditionalProperty(e.getErrorCode(), e.getErrorMessage());
                    createResponse(transferResponse, recordCount, processedRecord, migrationWireTransfer, MigrationConstants.STATUS_FAILURE);
                }
            });
            if(migrationWireTransferList !=null && !migrationWireTransferList.isEmpty()){
                migrationWireTransferRepository.saveAll(migrationWireTransferList);
            }
            recordCount.stopTime();
            if(recordCount.getTotal()>0){
                migrationEntityRepository.save(MigrationEntityMapper.INSTANCE.convertTransferToMigEntity(migClient, recordCount, WIRE_TRANSFER));
                log.info(logMessage.descr("Data committed to MIG_ENTITY table for Wire Transfer records"));
            }

        } catch (ServiceException e) {
            log.error(logMessage.descr(e.getErrorMessage()));
            transferResponse.setAdditionalProperty(e.getErrorCode(), e.getErrorMessage());
        }
        return transferResponse;
    }

    private Map<Integer, MigrationInternalTransfer> currentMigratedInternalTransfers(Long jobId) {
        return Optional.ofNullable(migrationTransferRepository.findByJobId(jobId)).orElse(new ArrayList<>()).stream().filter(t->t!=null)
                .collect(Collectors.toMap(MigrationInternalTransfer::getEcTxnId, Function.identity()));

    }

    private Map<Integer, MigrationWireTransfer> currentMigratedWireTransfers(Long jobId) {
        return Optional.ofNullable(migrationWireTransferRepository.findByJobId(jobId)).orElse(new ArrayList<>()).stream().filter(t->t!=null)
                .collect(Collectors.toMap(MigrationWireTransfer::getEcTxnId, Function.identity()));

    }



    private void applyRecurringType(List<InternalTransfer> transferList) {
        transferList.stream().forEach(transfer-> transfer.setRecurringType(RecurringType.fromTransfer(transfer)));
    }

    private void createResponse(TransferResponse transferResponse, RecordCount recordCount, MigrationInternalTransfer existingTransfer, MigrationInternalTransfer migrationTransfer, String status) {
        if(migrationTransfer!=null){
            transferResponse.setPaymentResponseData(PaymentResponseData.builder()
                    .gwClientId(migrationTransfer.getGwClientId())
                    .ecClientId(migrationTransfer.getEcClientId())
                    .jobId(migrationTransfer.getJobId()==null?0:migrationTransfer.getJobId().intValue())
                    .status(status).recordCount(recordCount).build());
        }
        else if(existingTransfer!=null){
            transferResponse.setPaymentResponseData(PaymentResponseData.builder()
                    .gwClientId(existingTransfer.getGwClientId())
                    .ecClientId(existingTransfer.getEcClientId())
                    .jobId(existingTransfer.getJobId()==null?0:existingTransfer.getJobId().intValue())
                    .status(status).recordCount(recordCount).build());
        }
        transferResponse.setAdditionalProperty("Total Records Total is: ", recordCount.getTotal());
        transferResponse.setAdditionalProperty("Total Succesfully migrated txn Records: ", recordCount.getSuccess());
        transferResponse.setAdditionalProperty("Total Failed Records :", recordCount.getFailure());
    }

    private void createResponse(TransferResponse transferResponse, RecordCount recordCount, MigrationWireTransfer existingTransfer, MigrationWireTransfer migrationTransfer, String status) {
        if(migrationTransfer!=null){
            transferResponse.setPaymentResponseData(PaymentResponseData.builder()
                    .gwClientId(migrationTransfer.getGwClientId())
                    .ecClientId(migrationTransfer.getEcClientId())
                    .jobId(migrationTransfer.getJobId()==null?0:migrationTransfer.getJobId().intValue())
                    .status(status).recordCount(recordCount).build());
        }
        else if(existingTransfer!=null){
            transferResponse.setPaymentResponseData(PaymentResponseData.builder()
                    .gwClientId(existingTransfer.getGwClientId())
                    .ecClientId(existingTransfer.getEcClientId())
                    .jobId(existingTransfer.getJobId()==null?0:existingTransfer.getJobId().intValue())
                    .status(status).recordCount(recordCount).build());
        }
        transferResponse.setAdditionalProperty("Total Records Total is: ", recordCount.getTotal());
        transferResponse.setAdditionalProperty("Total Succesfully migrated txn Records: ", recordCount.getSuccess());
        transferResponse.setAdditionalProperty("Total Failed Records :", recordCount.getFailure());
    }
}

