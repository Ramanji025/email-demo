package com.svb.gateway.migration.payments.utils;

import com.svb.gateway.migration.payments.entity.InternalTransfer;
import com.svb.gateway.migration.payments.entity.Payment;
import com.svb.gateway.migration.payments.entity.TransactionEntity;
import com.svb.gateway.migration.payments.entity.WireTransfer;
import com.svb.gateway.migration.payments.model.RecurringType;
import lombok.experimental.UtilityClass;

import java.time.LocalDate;

import static com.svb.gateway.migration.common.constants.MigrationConstants.STATUS_SUCCESS;

@UtilityClass
public class PaymentsUtils {
    public static Payment createPayment() {
        Payment payment=new Payment();
        payment.setEcClientId("test0005");
        payment.setBeneficiaryId(1234);
        payment.setJobId("1");
        payment.setPayeeRelationshipNumber("PRN");
        payment.setPaymentAmount(100d);
        payment.setPaymentFrequency(null);
        payment.setPaymentDate(LocalDate.now());
        payment.setPaymentId(1234);
        payment.setSubscriberAccountNumber("3300724935");
        payment.setTargetBeneficiaryId(9999);
        payment.setTransactionType("ACH");
        payment.setRecurringType(RecurringType.NONE);
        return payment;
    }

    public static InternalTransfer createInternalTransfer() {
        InternalTransfer internalTransfer=new InternalTransfer();
        internalTransfer.setJobId("123");
        internalTransfer.setFromAccountNumber("ABC");
        internalTransfer.setToAccountNumber("XYZ");
        internalTransfer.setRecurringType(RecurringType.ENDDATE);
        internalTransfer.setTransferAmount(100d);
        internalTransfer.setTrnId(550);
        internalTransfer.setFrequencyId(0);
        return internalTransfer;
    }


    public static WireTransfer createWireTransfer() {
        WireTransfer wireTransfer=new WireTransfer();
        wireTransfer.setPmtType("DOM");
        wireTransfer.setJobId("123");
        wireTransfer.setFromAccountNumber("ABC");
        wireTransfer.setBnfAccountType("bnfAccountType");
        wireTransfer.setWireTxnId(550);
        wireTransfer.setBeneAccount("bene");
        wireTransfer.setCrncyCode("USD");
        wireTransfer.setDebitAmt(100d);
        wireTransfer.setBeneBankId("ABC");
        wireTransfer.setOlbClientId("test0005");

        return wireTransfer;
    }

    public static TransactionEntity createTransactionEntity() {
        TransactionEntity transactionEntity=new TransactionEntity();
        transactionEntity.setEC_CLIENT_ID("EC_CLIENT");
        transactionEntity.setEC_TXN_ID(123);
        transactionEntity.setEC_USERLOGIN_ID("USER");
        transactionEntity.setGW_CLIENT_ID("GW_CLIENT");
        transactionEntity.setGW_REQ_ID(1l);
        transactionEntity.setJOBID("0");
        transactionEntity.setSTATUS(STATUS_SUCCESS);
        transactionEntity.setPAYMENT_ID("123");
        return transactionEntity;
    }
}
