package com.svb.gateway.migration.report.api;

import com.svb.gateway.migration.common.exception.ServiceException;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

@Api(value = "ClientReport", tags = "Report Controller")
@RequestMapping("/v1/api")
public interface ReportApi {

    @ApiOperation(value = "Endpoint for creating a Excel Migration report of migrated clients from eConnect to Gateway based on jobId", nickname = "createMigrationReport", notes = "Migration Report")
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Report is Successfully created "),
            @ApiResponse(code = 400, message = "Invalid Client Id or Company Id "),
            @ApiResponse(code = 500, message = "Service unavailable ")})
    @GetMapping(value = "/migration/report/excel/{jobId}",
            produces = {MediaType.MULTIPART_FORM_DATA_VALUE},
            consumes = {"*/*"})
    @ResponseStatus(HttpStatus.OK)
    @PreAuthorize("hasAuthority(@migrationServiceConfig.getAuthExecute())")
    ResponseEntity<ByteArrayResource> generateMigrationExcelReport(@PathVariable String jobId) throws ServiceException;

}
