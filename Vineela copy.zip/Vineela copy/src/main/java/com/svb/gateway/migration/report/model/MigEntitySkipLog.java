package com.svb.gateway.migration.report.model;

import javax.persistence.*;
import java.sql.Timestamp;

@Entity
@IdClass(MigEntitySkipLogId.class)
@Table(schema = "GWDMG", name = "MIG_ENTITY_SKIP_LOG")
public class MigEntitySkipLog {

    @Id
    @Column(name = "JOB_ID")
    private String jobId;

    @Column(name = "ECCLIENT_ID")
    private String ecclientId;

    @Column(name = "GWCLIENT_ID")
    private String gwclientId;

    @Column(name = "CIF_NUMBER")
    private String CIF_NUMBER;

    @Id
    @Column(name = "ENTITY_NAME")
    private String entityName;

    @Id
    @Column(name = "RECORD_DETAILS")
    private String recordDetails;

    @Column(name = "FAILURE_REASON")
    private String failureReason;

    @Column(name = "EXCEPTION_TYPE")
    private String exceptionType;

    @Column(name = "CREATED_DATETIME")
    private Timestamp createdDateTime;

    public String getJobId() {
        return jobId;
    }

    public void setJobId(String jobId) {
        this.jobId = jobId;
    }

    public String getEcclientId() {
        return ecclientId;
    }

    public void setEcclientId(String ecclientId) {
        this.ecclientId = ecclientId;
    }

    public String getGwclientId() {
        return gwclientId;
    }

    public void setGwclientId(String gwclientId) {
        this.gwclientId = gwclientId;
    }

    public String getCIF_NUMBER() {
        return CIF_NUMBER;
    }

    public void setCIF_NUMBER(String CIF_NUMBER) {
        this.CIF_NUMBER = CIF_NUMBER;
    }

    public String getEntityName() {
        return entityName;
    }

    public void setEntityName(String entityName) {
        this.entityName = entityName;
    }

    public String getRecordDetails() {
        return recordDetails;
    }

    public void setRecordDetails(String recordDetails) {
        this.recordDetails = recordDetails;
    }

    public String getFailureReason() {
        return failureReason;
    }

    public void setFailureReason(String failureReason) {
        this.failureReason = failureReason;
    }

    public String getExceptionType() {
        return exceptionType;
    }

    public void setExceptionType(String exceptionType) {
        this.exceptionType = exceptionType;
    }

    public Timestamp getCreatedDateTime() {
        return createdDateTime;
    }

    public void setCreatedDateTime(Timestamp createdDateTime) {
        this.createdDateTime = createdDateTime;
    }
}
