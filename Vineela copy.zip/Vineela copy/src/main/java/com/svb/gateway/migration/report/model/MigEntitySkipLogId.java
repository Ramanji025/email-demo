package com.svb.gateway.migration.report.model;

public class MigEntitySkipLogId implements java.io.Serializable{

    String jobId;
    String entityName;
    String recordDetails;
}
