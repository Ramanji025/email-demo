package com.svb.gateway.migration.report.repository;

import com.svb.gateway.migration.report.model.MigEntitySkipLog;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface MigEntitySkipLogRepository extends JpaRepository<MigEntitySkipLog, String> {

    @Query(value = "select * from MIG_ENTITY_SKIP_LOG  where JOB_ID=?1 ", nativeQuery = true)
    List<MigEntitySkipLog> findByJobId(String jobId);

}
