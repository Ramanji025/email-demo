package com.svb.gateway.migration.report.service;

import com.svb.gateway.migration.alerts.entity.MigratedAlertsEntity;
import com.svb.gateway.migration.alerts.mapper.MigrationAlertsMapper;
import com.svb.gateway.migration.beneficiaries.entity.MigBeneficiary;
import com.svb.gateway.migration.cards.entity.MigCardProgram;
import com.svb.gateway.migration.cards.repository.MigCardProgramRepository;
import com.svb.gateway.migration.beneficiaries.repository.MigBeneficiaryRepository;
import com.svb.gateway.migration.client.entity.MigClient;
import com.svb.gateway.migration.client.repository.MigClientRepository;
import com.svb.gateway.migration.common.constants.MigrationConstants;
import com.svb.gateway.migration.common.constants.ReportConstants;
import com.svb.gateway.migration.common.exception.ServiceException;
import com.svb.gateway.migration.common.utility.JobIdCheck;
import com.svb.gateway.migration.job.entity.MigJob;
import com.svb.gateway.migration.job.repository.MigJobRepository;
import com.svb.gateway.migration.nickname.entity.MigratedNicknamesEntity;
import com.svb.gateway.migration.nickname.mapper.MigrationNicknameMapper;
import com.svb.gateway.migration.payments.entity.MigrationInternalTransfer;
import com.svb.gateway.migration.payments.entity.MigrationPayment;
import com.svb.gateway.migration.payments.entity.MigrationWireTransfer;
import com.svb.gateway.migration.payments.repository.MigrationPaymentsRepository;
import com.svb.gateway.migration.payments.repository.MigrationTransferRepository;
import com.svb.gateway.migration.payments.repository.MigrationWireTransferRepository;
import com.svb.gateway.migration.report.model.MigEntitySkipLog;
import com.svb.gateway.migration.report.repository.MigEntitySkipLogRepository;
import com.svb.gateway.migration.common.entity.MigEntity;
import com.svb.gateway.migration.common.entity.MigEntityUser;
import com.svb.gateway.migration.common.repository.MigEntityRepository;
import com.svb.gateway.migration.common.repository.MigEntityUserRepository;
import com.svb.gateway.migration.user.entity.MigUser;
import com.svb.gateway.migration.user.repository.MigUserRepository;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.stereotype.Service;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.stream.Collectors;

import static com.svb.gateway.migration.common.constants.MigrationConstants.EMAIL_NOTIFICATION;
import static com.svb.gateway.migration.common.constants.ReportConstants.*;

@Service
public class ReportService {

    private static final Logger logger = LoggerFactory.getLogger(ReportService.class);

    @Autowired
    private MigClientRepository migClientRepository;

    @Autowired
    private MigUserRepository migUserRepository;

    @Autowired
    private MigJobRepository migJobRepository;

    @Autowired
    private MigEntityUserRepository migEntityUserRepository;

    @Autowired
    private MigEntityRepository migEntityRepository;

    @Autowired
    private MigBeneficiaryRepository migBeneficiaryRepository;

    @Autowired
    private MigCardProgramRepository migCardProgramRepository;

    @Autowired
    private MigEntitySkipLogRepository migEntitySkipLogRepository;

    @Autowired
    private MigrationTransferRepository migrationTransferRepository;

    @Autowired
    private MigrationWireTransferRepository migrationWireTransferRepository;

    @Autowired
    private JobIdCheck jobIdCheck;

    @Autowired
    private MigrationAlertsMapper migrationAlertsMapper;

    @Autowired
    private MigrationNicknameMapper migrationNicknameMapper;

    @Autowired
    private MigrationPaymentsRepository migrationPaymentsRepository;

    public ByteArrayResource generateMigrationExcelReport(final String jobId) throws ServiceException {

        JobIdCheck.jobIdFormatCheck(jobId);
        jobIdCheck.checkJobExistence(jobId);

        MigJob migJob = migJobRepository.findByJobIdValue(Long.parseLong(jobId));

        List<MigClient> migClientList = migClientRepository.findByJobIdAndStatus(Long.parseLong(jobId), MigrationConstants.STATUS_SUCCESS);

        List<MigUser> migUsersList = migUserRepository.findByJobIdandStatus(Long.parseLong(jobId), MigrationConstants.STATUS_SUCCESS);

        List<MigClient> migClientFailList = migClientRepository.findByJobIdAndNotStatus(Long.parseLong(jobId), MigrationConstants.STATUS_SUCCESS);
        if (migClientList.isEmpty() && migClientFailList.isEmpty()) {
            throw new ServiceException(CLIENT_NOT_PRESENT, CLIENT_NOT_PRESENT);
        }

        List<String> names = new ArrayList<>();
        names.add(BENE_CREATION_TEMPLATE);
        names.add(BENE_CREATION_FUTURE);
        names.add(BENE_CREATION_CHECK);
        names.add(BENE_CREATION_ACH_LARGE);
        names.add(BENE_CREATION_ACH);
        names.add(ADDITIONAL_USER_CREATION);
        names.add(PRIMARY_USER_CREATION);
        names.add(CLIENT_CREATION);
        names.add(ENROLL_CARD_PROGRAM);
        names.add(TRANSFERS_CREATION);
        names.add(WIRE_TRANSFERS_CREATION);
        names.add(WIRE_TRANSFERS);
        names.add(INTERNAL_TRANSFER);
        names.add(MIG_CARD_USER_UPDATE);
        names.add(MIG_CARD_USER_ROLLBACK);
        names.add(ACCOUNT_NICKNAME);
        names.add(ALERT_SUBSCRIPTION);
        names.add(IPAY_PAYMENTS);

        List<MigEntityUser> migEntityList = migEntityUserRepository.findByJobIdAndByEntityNameIn(Integer.parseInt(jobId), names);
        List<MigEntity> migEntityExtList = migEntityRepository.findByJobIdAndByEntityNameNotIn(Integer.parseInt(jobId), names);
        List<MigEntity> migEntityWelcomeList = migEntityExtList.stream()
                .filter(entity -> entity.getEntityName().equals(EMAIL_NOTIFICATION)).collect(Collectors.toList());
        migEntityExtList.removeAll(migEntityWelcomeList);
        if (migEntityList.isEmpty() && migEntityExtList.isEmpty()) {
            throw new ServiceException(ENTITY_NOT_PRESENT, ENTITY_NOT_PRESENT);
        }


        XSSFWorkbook wb = new XSSFWorkbook();
        try {
            Sheet jobDataSheet = wb.createSheet(JOB_REPORT);
            Sheet clientDataSheet = wb.createSheet(CLIENT_REPORT);
            Sheet userDataSheet = wb.createSheet(USER_REPORT);
            Sheet extractionDataSheet = wb.createSheet(EXTRACTION_REPORT);
            Sheet targetLoadDataSheet = wb.createSheet(TARGET_LOAD_REPORT);
            Sheet exceptionDataSheet = wb.createSheet(EXCEPTION);
            columnHeaderMigrationJobReport(jobDataSheet, 0);
            columnHeaderClientReport(clientDataSheet, 0);
            columnHeaderUserReport(userDataSheet, 0);
            columnHeaderExtractionReport(extractionDataSheet, 0);
            columnHeaderTargetLoadReport(targetLoadDataSheet, 0);
            columnHeaderExceptionDataReport(exceptionDataSheet, 0);

            int count = 1;

            int exceptionCount = 1;

            fillJobReportData(jobDataSheet, count, migJob);

            for (MigClient client : migClientList) {
                fillClientReportData(clientDataSheet, count, client);
                count++;
            }

            count = 1;
            for (MigUser user : migUsersList) {
                fillUserReportData(userDataSheet, count, user);
                count++;
            }

            for (MigClient client : migClientFailList) {
                fillClientReportData(clientDataSheet, count, client);
                count++;
                fillClientReportExceptionData(exceptionDataSheet, exceptionCount++, client);

            }

            count = 1;
            for (MigEntity entity : migEntityExtList) {

                fillExtractionReportData(extractionDataSheet, count, entity);
                count++;
            }

            count = 1;
            List<MigEntitySkipLog> migEntitySkipLogList = migEntitySkipLogRepository.findByJobId(jobId);
            for (MigEntitySkipLog migEntitySkipLog : migEntitySkipLogList) {
                fillSkipLogExceptionData(exceptionDataSheet, exceptionCount++, migEntitySkipLog);
            }
            Collection<MigEntityUser> collatedMigEntityList = collateRetries(migEntityList);
            for (MigEntityUser entity : collatedMigEntityList) {

                fillTargetLoadReportData(targetLoadDataSheet, count, entity);
                count++;

                if (ADDITIONAL_USER_CREATION.equals(entity.getEntityName()) || PRIMARY_USER_CREATION.equals(entity.getEntityName())) {
                    List<String> failStatus = new ArrayList<>();
                    failStatus.add(MigrationConstants.STATUS_FAILURE);
                    failStatus.add(MigrationConstants.STATUS_IGNORE);
                    List<MigUser> migUserList = migUserRepository.findByJobIdAndAndEcClientIdAndStatus(Long.valueOf(entity.getJobId()), entity.getEcclientId(), failStatus);
                    for (MigUser user : migUserList) {
                        fillUserReportExceptionData(exceptionDataSheet, exceptionCount++, user);
                    }
                } else if (BENE_CREATION_TEMPLATE.equals(entity.getEntityName()) || BENE_CREATION_FUTURE.equals(entity.getEntityName()) || BENE_CREATION_ACH.equals(entity.getEntityName()) || BENE_CREATION_ACH_LARGE.equals(entity.getEntityName()) || BENE_CREATION_CHECK.equals(entity.getEntityName())) {
                    List<String> failStatus = new ArrayList<>();
                    failStatus.add(VALIDATION_FAILED);
                    failStatus.add(MigrationConstants.STATUS_FAILURE);
                    List<MigBeneficiary> migBeneList = migBeneficiaryRepository.findByEcClientIdAndJobIdAndStatus(Long.valueOf(entity.getJobId()), entity.getEcclientId(), failStatus);
                    for (MigBeneficiary bene : migBeneList) {

                        fillBeneReportExceptionData(exceptionDataSheet, exceptionCount++, bene);
                    }
                } else if (INTERNAL_TRANSFER.equals(entity.getEntityName())) {

                    List<String> failStatus = new ArrayList<>();
                    failStatus.add(VALIDATION_FAILED);
                    failStatus.add(MigrationConstants.STATUS_FAILURE);
                    failStatus.add(MigrationConstants.STATUS_IGNORE);
                    List<MigrationInternalTransfer> migTransfersList = migrationTransferRepository.findByEcClientIdAndJobIdAndStatus(entity.getEcclientId(), Long.valueOf(entity.getJobId()), failStatus);
                    for (MigrationInternalTransfer transfers : migTransfersList) {
                        fillTransferReportExceptionData(exceptionDataSheet, exceptionCount++, transfers);
                    }
                }else if (WIRE_TRANSFERS.equals(entity.getEntityName())) {

                    List<String> failStatus = new ArrayList<>();
                    failStatus.add(VALIDATION_FAILED);
                    failStatus.add(MigrationConstants.STATUS_FAILURE);
                    failStatus.add(MigrationConstants.STATUS_IGNORE);
                    List<MigrationWireTransfer> migWireTransfersList = migrationWireTransferRepository.findByEcClientIdAndJobIdAndStatus(entity.getEcclientId(), Long.valueOf(entity.getJobId()), failStatus);
                    for (MigrationWireTransfer wireTransfer : migWireTransfersList) {
                        fillWireTransferReportExceptionData(exceptionDataSheet, exceptionCount++, wireTransfer);
                    }
                }else if (ALERT_SUBSCRIPTION.equals(entity.getEntityName())) {

                    List<String> failStatus = new ArrayList<>();
                    failStatus.add(VALIDATION_FAILED);
                    failStatus.add(MigrationConstants.STATUS_FAILURE);
                    failStatus.add(MigrationConstants.STATUS_IGNORE);
                    List<MigratedAlertsEntity> migratedAlertsEntitiesList = migrationAlertsMapper.findByEcClientIdAndJobIdAndStatus( Long.valueOf(entity.getJobId()),entity.getEcclientId());
                    for (MigratedAlertsEntity migratedAlertsEntity : migratedAlertsEntitiesList) {
                        fillAlertsReportExceptionData(exceptionDataSheet, exceptionCount++, migratedAlertsEntity);
                    }
                }else if (ACCOUNT_NICKNAME.equals(entity.getEntityName())) {

                    List<String> failStatus = new ArrayList<>();
                    failStatus.add(VALIDATION_FAILED);
                    failStatus.add(MigrationConstants.STATUS_FAILURE);
                    failStatus.add(MigrationConstants.STATUS_IGNORE);
                    List<MigratedNicknamesEntity> migratedNicknamesEntitiesList = migrationNicknameMapper.findByEcClientIdAndJobIdAndStatus( Long.valueOf(entity.getJobId()),entity.getEcclientId());
                    for (MigratedNicknamesEntity migratedNicknamesEntity : migratedNicknamesEntitiesList) {
                        fillNicknamesReportExceptionData(exceptionDataSheet, exceptionCount++, migratedNicknamesEntity);
                    }
                }else if (IPAY_PAYMENTS.equals(entity.getEntityName())) {

                    List<String> failStatus = new ArrayList<>();
                    failStatus.add(VALIDATION_FAILED);
                    failStatus.add(MigrationConstants.STATUS_FAILURE);
                    failStatus.add(MigrationConstants.STATUS_IGNORE);
                    List<MigrationPayment> migrationPaymentList = migrationPaymentsRepository.findByEcClientIdAndJobIdAndStatus( entity.getEcclientId(),Long.valueOf(entity.getJobId()), failStatus);
                    for (MigrationPayment migrationPayment : migrationPaymentList) {
                        fillPaymentsReportExceptionData(exceptionDataSheet, exceptionCount++, migrationPayment);
                    }
                }else if (ENROLL_CARD_PROGRAM.equals(entity.getEntityName())){
                    List<String> failStatus = new ArrayList<>();
                    failStatus.add(VALIDATION_FAILED);
                    failStatus.add(MigrationConstants.STATUS_FAILURE);
                    failStatus.add(MigrationConstants.STATUS_IGNORE);
                    List<MigCardProgram> migCardProgramList = migCardProgramRepository.findByEcClientIdAndJobIdAndStatus(entity.getEcclientId(), Long.valueOf(entity.getJobId()), failStatus);
                    for (MigCardProgram cardProgram : migCardProgramList) {
                        fillCardProgramReportExceptionData(exceptionDataSheet, exceptionCount++, cardProgram);
                    }
                }

            }
            try {

                int numberOfSheets = wb.getNumberOfSheets();
                for (int i = 0; i < numberOfSheets; i++) {
                    Sheet sheet = wb.getSheetAt(i);
                    if (sheet.getPhysicalNumberOfRows() > 0) {
                        Row row = sheet.getRow(sheet.getFirstRowNum());
                        Iterator<Cell> cellIterator = row.cellIterator();
                        while (cellIterator.hasNext()) {
                            Cell cell = cellIterator.next();
                            int columnIndex = cell.getColumnIndex();
                            sheet.autoSizeColumn(columnIndex);
                        }
                    }
                }

                ByteArrayOutputStream out = new ByteArrayOutputStream();

                wb.write(out);
                return new ByteArrayResource(out.toByteArray());
            } catch (Exception e) {
                throw new ServiceException(REPORTEXCEPTION);
            }

        } catch (Exception e) {
            throw new ServiceException(SERVICEREPORTEXCEPTION);
        } finally {
            try {
                wb.close();
            } catch (IOException e) {
                logger.error(String.valueOf(e));
            }
        }
    }

    private Collection<MigEntityUser> collateRetries(List<MigEntityUser> migEntityList) {
        Map<String, MigEntityUser> collateMap = new LinkedHashMap<>();
        for(MigEntityUser migEntityUser : migEntityList){
            String key = migEntityUser.getEcclientId()+":"+migEntityUser.getEntityName();
            if(collateMap.containsKey(key)){
                MigEntityUser existingMigEntityUser = collateMap.get(key);
                existingMigEntityUser.setReadCount(Math.max(migEntityUser.getReadCount(),existingMigEntityUser.getReadCount()));
                existingMigEntityUser.setWriteCount(migEntityUser.getWriteCount() + existingMigEntityUser.getWriteCount());
                existingMigEntityUser.setSkipCount(Math.min(migEntityUser.getSkipCount(),existingMigEntityUser.getSkipCount()));
            }
            else{
                collateMap.put(key, migEntityUser);
            }
        }
        return collateMap.values();
    }

    private void fillSkipLogExceptionData(Sheet exceptionDataSheet, int count, MigEntitySkipLog migEntitySkipLog) {
        Row data = exceptionDataSheet.createRow(count);
        Cell dSrNo = data.createCell(0);
        dSrNo.setCellValue(count);

        Cell dJobId = data.createCell(1);
        dJobId.setCellValue(migEntitySkipLog.getJobId());

        Cell dEcClientID = data.createCell(2);
        dEcClientID.setCellValue(ReportConstants.BLANK);

        Cell dGWClientId = data.createCell(3);
        dGWClientId.setCellValue(ReportConstants.BLANK);

        Cell dEntityName = data.createCell(4);
        dEntityName.setCellValue(MIG_STG_SKIP_LOG);

        Cell dExceptionDetails = data.createCell(7);
        dExceptionDetails.setCellValue(migEntitySkipLog.getRecordDetails());
    }

    private void fillBeneReportExceptionData(Sheet exceptionDataSheet, int count, MigBeneficiary bene) {
        Row data = exceptionDataSheet.createRow(count);
        Cell dSrNo = data.createCell(0);
        dSrNo.setCellValue(count);

        Cell dJobId = data.createCell(1);
        dJobId.setCellValue(bene.getJobId());

        Cell dEcClientID = data.createCell(2);
        dEcClientID.setCellValue(bene.getEcClientId());

        Cell dGWClientId = data.createCell(3);
        dGWClientId.setCellValue(bene.getGwClientId());

        Cell dEntityName = data.createCell(4);
        dEntityName.setCellValue(MIG_BENEFICIARY);

        Cell dSourceType = data.createCell(5);
        dSourceType.setCellValue(bene.getBeneSourceType());

        Cell dSourceSystemId = data.createCell(6);
        dSourceSystemId.setCellValue(bene.getBeneSourceId());

        Cell dExceptionDetails = data.createCell(7);
        dExceptionDetails.setCellValue(bene.getComments());
    }

    private void fillTransferReportExceptionData(Sheet exceptionDataSheet, int count, MigrationInternalTransfer transfers) {
        Row data = exceptionDataSheet.createRow(count);
        Cell dSrNo = data.createCell(0);
        dSrNo.setCellValue(count);

        Cell dJobId = data.createCell(1);
        dJobId.setCellValue(transfers.getJobId());

        Cell dEcClientID = data.createCell(2);
        dEcClientID.setCellValue(transfers.getEcClientId());

        Cell dGWClientId = data.createCell(3);
        if (transfers.getGwClientId() != null) {
            dGWClientId.setCellValue(transfers.getGwClientId());
        } else {
            dGWClientId.setCellValue(ReportConstants.BLANK);
        }

        Cell dEntityName = data.createCell(4);
        dEntityName.setCellValue(MIG_TRANSFERS);

        Cell dSourceSystemId = data.createCell(6);
        dSourceSystemId.setCellValue(transfers.getEcTxnId());

        Cell dExceptionDetails = data.createCell(7);
        dExceptionDetails.setCellValue(transfers.getComments());
    }

    private void fillWireTransferReportExceptionData(Sheet exceptionDataSheet, int count, MigrationWireTransfer transfers) {
        Row data = exceptionDataSheet.createRow(count);
        Cell dSrNo = data.createCell(0);
        dSrNo.setCellValue(count);

        Cell dJobId = data.createCell(1);
        dJobId.setCellValue(transfers.getJobId());

        Cell dEcClientID = data.createCell(2);
        dEcClientID.setCellValue(transfers.getEcClientId());

        Cell dGWClientId = data.createCell(3);
        if (transfers.getGwClientId() != null) {
            dGWClientId.setCellValue(transfers.getGwClientId());
        } else {
            dGWClientId.setCellValue(ReportConstants.BLANK);
        }

        Cell dEntityName = data.createCell(4);
        dEntityName.setCellValue(WIRE_TRANSFERS);

        Cell dSourceSystemId = data.createCell(6);
        dSourceSystemId.setCellValue(transfers.getEcTxnId());

        Cell dExceptionDetails = data.createCell(7);
        dExceptionDetails.setCellValue(transfers.getComments());
    }

    private void fillAlertsReportExceptionData(Sheet exceptionDataSheet, int count, MigratedAlertsEntity migratedAlertsEntity) {
        Row data = exceptionDataSheet.createRow(count);
        Cell dSrNo = data.createCell(0);
        dSrNo.setCellValue(count);

        Cell dJobId = data.createCell(1);
        dJobId.setCellValue(migratedAlertsEntity.getJobId());

        Cell dEcClientID = data.createCell(2);
        dEcClientID.setCellValue(migratedAlertsEntity.getEc_Client_Id());

        Cell dGWClientId = data.createCell(3);
        if (migratedAlertsEntity.getGw_Client_Id() != null) {
            dGWClientId.setCellValue(migratedAlertsEntity.getGw_Client_Id());
        } else {
            dGWClientId.setCellValue(ReportConstants.BLANK);
        }

        Cell dEntityName = data.createCell(4);
        dEntityName.setCellValue(ALERT_SUBSCRIPTION);

        Cell dSourceSystemId = data.createCell(6);
        dSourceSystemId.setCellValue(migratedAlertsEntity.getGw_Alert_Id());

        Cell dExceptionDetails = data.createCell(7);
        dExceptionDetails.setCellValue(migratedAlertsEntity.getComments());
    }

    private void fillNicknamesReportExceptionData(Sheet exceptionDataSheet, int count, MigratedNicknamesEntity migratedNicknamesEntity) {
        Row data = exceptionDataSheet.createRow(count);
        Cell dSrNo = data.createCell(0);
        dSrNo.setCellValue(count);

        Cell dJobId = data.createCell(1);
        dJobId.setCellValue(migratedNicknamesEntity.getJobId());

        Cell dEcClientID = data.createCell(2);
        dEcClientID.setCellValue(migratedNicknamesEntity.getEc_Client_Id());

        Cell dGWClientId = data.createCell(3);
        if (migratedNicknamesEntity.getGw_Client_Id() != null) {
            dGWClientId.setCellValue(migratedNicknamesEntity.getGw_Client_Id());
        } else {
            dGWClientId.setCellValue(ReportConstants.BLANK);
        }

        Cell dEntityName = data.createCell(4);
        dEntityName.setCellValue(ACCOUNT_NICKNAME);

        Cell dSourceSystemId = data.createCell(6);
        dSourceSystemId.setCellValue(migratedNicknamesEntity.getAccount_Number());

        Cell dExceptionDetails = data.createCell(7);
        dExceptionDetails.setCellValue(migratedNicknamesEntity.getComments());
    }

    private void fillPaymentsReportExceptionData(Sheet exceptionDataSheet, int count, MigrationPayment migrationPayment) {
        Row data = exceptionDataSheet.createRow(count);
        Cell dSrNo = data.createCell(0);
        dSrNo.setCellValue(count);

        Cell dJobId = data.createCell(1);
        dJobId.setCellValue(migrationPayment.getJobId());

        Cell dEcClientID = data.createCell(2);
        dEcClientID.setCellValue(migrationPayment.getEcClientId());

        Cell dGWClientId = data.createCell(3);
        if (migrationPayment.getGwClientId() != null) {
            dGWClientId.setCellValue(migrationPayment.getGwClientId());
        } else {
            dGWClientId.setCellValue(ReportConstants.BLANK);
        }

        Cell dEntityName = data.createCell(4);
        dEntityName.setCellValue(IPAY_PAYMENTS);

        Cell dSourceSystemId = data.createCell(6);
        dSourceSystemId.setCellValue(migrationPayment.getPaymentId());

        Cell dExceptionDetails = data.createCell(7);
        dExceptionDetails.setCellValue(migrationPayment.getComments());
    }

    private void fillClientReportExceptionData(Sheet exceptionDataSheet, int count, MigClient client) {

        Row data = exceptionDataSheet.createRow(count);
        Cell dSrNo = data.createCell(0);
        dSrNo.setCellValue(count);

        Cell dJobId = data.createCell(1);
        dJobId.setCellValue(client.getJobId());

        Cell dEcClientID = data.createCell(2);
        dEcClientID.setCellValue(client.getEcClientId());

        Cell dGwClientId = data.createCell(3);
        if (client.getGwClientId() != null) {
            dGwClientId.setCellValue(client.getGwClientId());
        } else {
            dGwClientId.setCellValue(ReportConstants.BLANK);
        }

        Cell dEntityName = data.createCell(4);
        dEntityName.setCellValue(CLIENT_MIGRATION);

        Cell dExceptionDetails = data.createCell(7);
        dExceptionDetails.setCellValue(client.getComments());

    }

    private void fillUserReportExceptionData(Sheet exceptionDataSheet, int count, MigUser user) {

        Row data = exceptionDataSheet.createRow(count);
        Cell dSrNo = data.createCell(0);
        dSrNo.setCellValue(count);

        Cell dJobId = data.createCell(1);
        dJobId.setCellValue(user.getJobId());

        Cell dEcClientID = data.createCell(2);
        dEcClientID.setCellValue(user.getEcClientId());

        Cell dGwClientId = data.createCell(3);
        if (user.getGwClientId() != null) {
            dGwClientId.setCellValue(user.getGwClientId());
        } else {
            dGwClientId.setCellValue(ReportConstants.BLANK);
        }

        Cell dEntityName = data.createCell(4);
        dEntityName.setCellValue(MIG_USER);

        Cell dSourceSystemId = data.createCell(6);
        dSourceSystemId.setCellValue(user.getEcUserLoginId());

        Cell dExceptionDetails = data.createCell(7);
        dExceptionDetails.setCellValue(user.getComments());

    }

    private void columnHeaderMigrationJobReport(Sheet sheet, int rownum) {

        Row header = sheet.createRow(rownum);
        Cell cSrNo = header.createCell(0);
        cSrNo.setCellValue(SRNO);

        Cell jobId = header.createCell(1);
        jobId.setCellValue(JOBID);

        Cell cJobType = header.createCell(2);
        cJobType.setCellValue(JOB_TYPE);

        Cell cStartTime = header.createCell(3);
        cStartTime.setCellValue(EXTRACTION_TIME);

        Cell cEndTime = header.createCell(4);
        cEndTime.setCellValue(LOAD_TIME);

        Cell cClientCount = header.createCell(5);
        cClientCount.setCellValue(CLIENT_COUNT);

        Cell cStatus = header.createCell(6);
        cStatus.setCellValue(STATUS);
    }

    private void columnHeaderClientReport(Sheet sheet, int rownum) {

        Row header = sheet.createRow(rownum);
        Cell cSrNo = header.createCell(0);
        cSrNo.setCellValue(SRNO);

        Cell cJobId = header.createCell(1);
        cJobId.setCellValue(JOBID);

        Cell cEcClientID = header.createCell(2);
        cEcClientID.setCellValue(ECCLIENTID);

        Cell cGwClientId = header.createCell(3);
        cGwClientId.setCellValue(GWCLIENTID);

        Cell cClientName = header.createCell(4);
        cClientName.setCellValue(CLIENT_NAME);

        Cell cCompanyId = header.createCell(5);
        cCompanyId.setCellValue(COMPANY_ID);

        Cell cPrimaryCifUbs = header.createCell(6);
        cPrimaryCifUbs.setCellValue(PRIMARY_CIF_UBS);

        Cell cStatus = header.createCell(7);
        cStatus.setCellValue(STATUS);

        Cell cUDate = header.createCell(8);
        cUDate.setCellValue(UPDATED_DATE);

        Cell clientBDCStatus = header.createCell(9);
        clientBDCStatus.setCellValue(BDC_REGISTRATION_STATUS);
    }

    private void columnHeaderUserReport(Sheet sheet, int rownum) {

        Row header = sheet.createRow(rownum);
        Cell cSrNo = header.createCell(0);
        cSrNo.setCellValue(SRNO);

        Cell cJobId = header.createCell(1);
        cJobId.setCellValue(JOBID);

        Cell cEcClientID = header.createCell(2);
        cEcClientID.setCellValue(ECCLIENTID);

        Cell cGwClientId = header.createCell(3);
        cGwClientId.setCellValue(GWCLIENTID);

        Cell cEcUserLoginId = header.createCell(4);
        cEcUserLoginId.setCellValue(EC_USER_LOGIN_ID);

        Cell cGwUuid = header.createCell(5);
        cGwUuid.setCellValue(GW_UUID);

        Cell cFirstName = header.createCell(6);
        cFirstName.setCellValue(FIRST_NAME);

        Cell cLastName = header.createCell(7);
        cLastName.setCellValue(LAST_NAME);

        Cell cMobileNumber = header.createCell(8);
        cMobileNumber.setCellValue(MOBILE_NUMBER);

        Cell cEmailId = header.createCell(9);
        cEmailId.setCellValue(EMAIL_ID);

        Cell cStatus = header.createCell(10);
        cStatus.setCellValue(STATUS);

        Cell cUserType = header.createCell(11);
        cUserType.setCellValue(USER_TYPE);

        Cell cBdcStatus = header.createCell(12);
        cBdcStatus.setCellValue(BDC_STATUS);

        Cell cIsPrimaryUser = header.createCell(13);
        cIsPrimaryUser.setCellValue(IS_PRIMARY_USER);

        Cell cWcEmailFlag = header.createCell(14);
        cWcEmailFlag.setCellValue(WC_EMAIL_SNT_FLAG);
    }

    private void columnHeaderExtractionReport(Sheet sheet, int rownum) {

        Row header = sheet.createRow(rownum);
        Cell cSrNo = header.createCell(0);
        cSrNo.setCellValue(SRNO);

        Cell jobId = header.createCell(1);
        jobId.setCellValue(JOBID);

        Cell entityName = header.createCell(2);
        entityName.setCellValue(STEP_NAME);

        Cell readCount = header.createCell(3);
        readCount.setCellValue(SOURCE_COUNT);

        Cell writeCount = header.createCell(4);
        writeCount.setCellValue(STAGING_COUNT);

        Cell skipCount = header.createCell(5);
        skipCount.setCellValue(SKIP_COUNT);
    }

    private void columnHeaderTargetLoadReport(Sheet sheet, int rownum) {

        Row header = sheet.createRow(rownum);
        Cell cSrNo = header.createCell(0);
        cSrNo.setCellValue(SRNO);

        Cell jobId = header.createCell(1);
        jobId.setCellValue(JOBID);

        Cell cEcClientID = header.createCell(2);
        cEcClientID.setCellValue(ECCLIENTID);

        Cell cGwClientId = header.createCell(3);
        cGwClientId.setCellValue(GWCLIENTID);

        Cell entityName = header.createCell(4);
        entityName.setCellValue(ENTITY_NAME);

        Cell readCount = header.createCell(5);
        readCount.setCellValue(STAGING_COUNT);

        Cell writeCount = header.createCell(6);
        writeCount.setCellValue(TARGET_COUNT);

        Cell skipCount = header.createCell(7);
        skipCount.setCellValue(SKIP_COUNT);
    }

    private void fillCardProgramReportExceptionData(Sheet exceptionDataSheet, int count, MigCardProgram cardProgram) {

        Row data = exceptionDataSheet.createRow(count);
        Cell dSrNo = data.createCell(0);
        dSrNo.setCellValue(count);

        Cell dJobId = data.createCell(1);
        dJobId.setCellValue(cardProgram.getJobId());

        Cell dEcClientID = data.createCell(2);
        dEcClientID.setCellValue(cardProgram.getEcClientId());

        Cell dGwClientId = data.createCell(3);
        if (cardProgram.getOlbClientId() != null) {
            dGwClientId.setCellValue(cardProgram.getOlbClientId());
        } else {
            dGwClientId.setCellValue(ReportConstants.BLANK);
        }

        Cell dEntityName = data.createCell(4);
        dEntityName.setCellValue(MIG_CARD_PROGRAM);

        Cell dSourceSystemId = data.createCell(6);
        dSourceSystemId.setCellValue(cardProgram.getProgramId());

        Cell dExceptionDetails = data.createCell(7);
        dExceptionDetails.setCellValue(cardProgram.getComments());

    }

    private void columnHeaderExceptionDataReport(Sheet sheet, int rownum) {

        Row header = sheet.createRow(rownum);
        Cell cSrNo = header.createCell(0);
        cSrNo.setCellValue(SRNO);

        Cell jobId = header.createCell(1);
        jobId.setCellValue(JOBID);

        Cell cEcClientID = header.createCell(2);
        cEcClientID.setCellValue(ECCLIENTID);

        Cell cGwClientId = header.createCell(3);
        cGwClientId.setCellValue(GWCLIENTID);

        Cell entityName = header.createCell(4);
        entityName.setCellValue(STEP_ENTITY_NAME);

        Cell readCount = header.createCell(5);
        readCount.setCellValue(SOURCE_SYSTEM_TYPE);

        Cell writeCount = header.createCell(6);
        writeCount.setCellValue(SOURCE_SYSTEM_ID);

        Cell status = header.createCell(7);
        status.setCellValue(EXCEPTION_DETAILS);
    }

    private void fillJobReportData(Sheet jobDataSheet, int count, MigJob migJob) {

        Row data = jobDataSheet.createRow(count);
        Cell dSrNo = data.createCell(0);
        dSrNo.setCellValue(count);

        Cell dJobId = data.createCell(1);
        dJobId.setCellValue(migJob.getJobId());

        Cell dJobType = data.createCell(2);
        dJobType.setCellValue(migJob.getType());

        Cell dExtractionTime = data.createCell(3);
        dExtractionTime.setCellValue(migJob.getExtractionTime().toString());

        Cell dLoadTime = data.createCell(4);
        if (migJob.getLoadTime() != null) {
            dLoadTime.setCellValue(migJob.getLoadTime().toString());
        } else {
            dLoadTime.setCellValue(ReportConstants.BLANK);
        }

        Cell dCandidateCount = data.createCell(5);
        dCandidateCount.setCellValue(migJob.getCandidateCount());

        Cell dStatus = data.createCell(6);
        dStatus.setCellValue(migJob.getStatus());
    }

    private void fillClientReportData(Sheet sheet, int count, MigClient client) {

        Row data = sheet.createRow(count);
        Cell dSrNo = data.createCell(0);
        dSrNo.setCellValue(count);

        Cell dJobId = data.createCell(1);
        dJobId.setCellValue(client.getJobId());

        Cell dEcClientID = data.createCell(2);
        dEcClientID.setCellValue(client.getEcClientId());

        Cell dGwClientId = data.createCell(3);
        if (client.getGwClientId() != null) {
            dGwClientId.setCellValue(client.getGwClientId());
        } else {
            dGwClientId.setCellValue(ReportConstants.BLANK);
        }

        Cell dClientName = data.createCell(4);
        if (client.getClientName() != null) {
            dClientName.setCellValue(client.getClientName());
        } else {
            dClientName.setCellValue(ReportConstants.BLANK);
        }

        Cell dCompanyId = data.createCell(5);
        dCompanyId.setCellValue(client.getCompanyId());

        Cell dPrimaryCifUbs = data.createCell(6);
        if (client.getPrimaryCifUbs() != null) {
            dPrimaryCifUbs.setCellValue(client.getPrimaryCifUbs());
        } else {
            dPrimaryCifUbs.setCellValue(ReportConstants.BLANK);
        }

        Cell dStatus = data.createCell(7);
        dStatus.setCellValue(client.getStatus());

        Cell dUDate = data.createCell(8);
        dUDate.setCellValue(new SimpleDateFormat("dd/MM/yyyy HH:mm").format(client.getUpdateDate()));

        Cell clientBDCStatus = data.createCell(9);
        clientBDCStatus.setCellValue((client.getBdcStatus() == null || client.getBdcStatus() == 0) ? "No" : "Yes");

    }

    private void fillExtractionReportData(Sheet sheet, int count, MigEntity entity) {

        Row data = sheet.createRow(count);
        Cell dSrNo = data.createCell(0);
        dSrNo.setCellValue(count);

        Cell dJobId = data.createCell(1);
        dJobId.setCellValue(entity.getJobId());

        Cell dStepName = data.createCell(2);
        dStepName.setCellValue(entity.getEntityName());

        Cell dSourceCount = data.createCell(3);
        dSourceCount.setCellValue(entity.getReadCount());

        Cell dTargetCount = data.createCell(4);
        dTargetCount.setCellValue(entity.getWriteCount());

        Cell dSkipCount = data.createCell(5);
        dSkipCount.setCellValue(entity.getSkipCount());
    }

    private void fillTargetLoadReportData(Sheet sheet, int count, MigEntityUser entity) {

        Row data = sheet.createRow(count);
        Cell dSrNo = data.createCell(0);
        dSrNo.setCellValue(count);

        Cell dJobId = data.createCell(1);
        dJobId.setCellValue(entity.getJobId());

        Cell dEcClientID = data.createCell(2);
        if (entity.getEcclientId() != null) {
            dEcClientID.setCellValue(entity.getEcclientId());
        } else {
            dEcClientID.setCellValue(ReportConstants.BLANK);
        }

        Cell dGwClientId = data.createCell(3);
        if (entity.getGwclientId() != null) {
            dGwClientId.setCellValue(entity.getGwclientId());
        } else {
            dGwClientId.setCellValue(ReportConstants.BLANK);
        }

        Cell dStepName = data.createCell(4);
        dStepName.setCellValue(entity.getEntityName());

        Cell dSourceCount = data.createCell(5);
        dSourceCount.setCellValue(entity.getReadCount());

        Cell dTargetCount = data.createCell(6);
        dTargetCount.setCellValue(entity.getWriteCount());

        Cell dSkipCount = data.createCell(7);
        dSkipCount.setCellValue(entity.getSkipCount());
    }

    private void fillUserReportData(Sheet sheet, int count, MigUser migUser) {

        Row data = sheet.createRow(count);
        Cell dSrNo = data.createCell(0);
        dSrNo.setCellValue(count);

        Cell dJobId = data.createCell(1);
        dJobId.setCellValue(migUser.getJobId());

        Cell dEcClientID = data.createCell(2);
        if (migUser.getEcClientId() != null) {
            dEcClientID.setCellValue(migUser.getEcClientId());
        } else {
            dEcClientID.setCellValue(ReportConstants.BLANK);
        }

        Cell dGwClientId = data.createCell(3);
        if (migUser.getGwClientId() != null) {
            dGwClientId.setCellValue(migUser.getGwClientId());
        } else {
            dGwClientId.setCellValue(ReportConstants.BLANK);
        }

        Cell dEcUserLoginId = data.createCell(4);
        dEcUserLoginId.setCellValue(migUser.getEcUserLoginId());

        Cell dGwUuid = data.createCell(5);
        dGwUuid.setCellValue(migUser.getGwUuid());

        Cell dFirstName = data.createCell(6);
        dFirstName.setCellValue(migUser.getFirstName());

        Cell dLastName = data.createCell(7);
        dLastName.setCellValue(migUser.getLastName());

        Cell dMobileNumber = data.createCell(8);
        dMobileNumber.setCellValue(migUser.getMobileNumber());

        Cell dEmailId = data.createCell(9);
        dEmailId.setCellValue(migUser.getMobileNumber());

        Cell dStatus = data.createCell(10);
        dStatus.setCellValue(migUser.getStatus());

        Cell dUserType = data.createCell(11);
        dUserType.setCellValue(migUser.getTypeOfUser());

        Cell dBdcStatus = data.createCell(12);
        dBdcStatus.setCellValue(migUser.getBdcStatus());

        Cell dIsPrimaryUser = data.createCell(13);
        dIsPrimaryUser.setCellValue(migUser.getIsPrimaryUser());

        Cell dWcEmailFlag = data.createCell(14);
        dWcEmailFlag.setCellValue(migUser.getEmailFlag());

    }

}
