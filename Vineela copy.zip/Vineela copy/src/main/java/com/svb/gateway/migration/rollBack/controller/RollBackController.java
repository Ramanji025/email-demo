package com.svb.gateway.migration.rollBack.controller;

import com.svb.gateway.migration.common.exception.ServiceException;
import com.svb.gateway.migration.rollBack.api.RollBackApi;
import com.svb.gateway.migration.rollBack.model.RollBackResponse;
import com.svb.gateway.migration.rollBack.service.RollBackService;
import org.apache.commons.text.StringEscapeUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

/**
 * @author psrikanta
 */

@RestController
public class RollBackController implements RollBackApi {

    private final RollBackService rollBackService;

    @Autowired
    public RollBackController(RollBackService rollBackService) {
        this.rollBackService = rollBackService;
    }

    @Override
    @DeleteMapping(path = "rollback/{clientId}",
            consumes = MediaType.ALL_VALUE, produces = {"application/json"})
    @ResponseStatus(HttpStatus.OK)
    public ResponseEntity<RollBackResponse> rollback(@PathVariable("clientId") String clientId) throws ServiceException {
        String cleansedClientId = StringEscapeUtils.escapeHtml4(clientId);

        return new ResponseEntity<>(rollBackService.rollback(cleansedClientId), HttpStatus.OK);

    }
}
