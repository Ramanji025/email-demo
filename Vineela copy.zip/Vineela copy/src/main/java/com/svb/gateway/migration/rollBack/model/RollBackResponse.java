package com.svb.gateway.migration.rollBack.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.svb.gateway.migration.common.model.Error;
import com.svb.gateway.migration.payments.model.PaymentResponseData;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.util.ArrayList;
import java.util.List;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Getter
@Setter
@ToString
public class RollBackResponse {

    @JsonProperty("Data")
    private PaymentResponseData paymentResponseData = null;

    @JsonProperty("Message")
    private List<String> messages = new ArrayList<>();
    @JsonProperty("Errors")
    private List<Error> errors = new ArrayList<>();
    private String status;

    public void addMessage(String message) {
        messages.add(message);
    }

    public List<String> getMessages() {
        return messages;
    }
}
