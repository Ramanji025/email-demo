package com.svb.gateway.migration.rollBack.service;

import com.svb.gateway.migration.alerts.mapper.MigrationAlertsMapper;
import com.svb.gateway.migration.alerts.service.AlertsService;
import com.svb.gateway.migration.beneficiaries.mapper.MigBeneficiaryMapper;
import com.svb.gateway.migration.cards.service.CardsService;
import com.svb.gateway.migration.client.entity.MigClient;
import com.svb.gateway.migration.client.model.DeleteClientResponse;
import com.svb.gateway.migration.client.repository.MigClientRepository;
import com.svb.gateway.migration.client.service.ClientService;
import com.svb.gateway.migration.common.constants.MigrationConstants;
import com.svb.gateway.migration.common.exception.BadRequestException;
import com.svb.gateway.migration.common.exception.ServiceException;
import com.svb.gateway.migration.common.logging.Message;
import com.svb.gateway.migration.common.utility.EcClientIdCheck;
import com.svb.gateway.migration.common.utility.MigrationErrorCodeEnum;
import com.svb.gateway.migration.ec2stage.service.ECService;
import com.svb.gateway.migration.job.repository.MigJobRepository;
import com.svb.gateway.migration.nickname.service.NicknameService;
import com.svb.gateway.migration.payments.entity.TransactionEntity;
import com.svb.gateway.migration.payments.service.OchPaymentService;
import com.svb.gateway.migration.rollBack.mapper.RollBackMapper;
import com.svb.gateway.migration.rollBack.model.RollBackResponse;
import com.svb.gateway.migration.user.mapper.UserMapper;
import com.svb.gateway.migration.user.service.UserService;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import static com.svb.gateway.migration.common.constants.MigrationConstants.STATUS_ROLLED_BACK;

/**
 * @author bmourya & psrikanta
 */

/**
 * RollBack Service program
 * <p>
 * The rollback will be implemented for a client Id and a jobId.
 * It should wipe out all the client's data from gateway including the payments, alerts, transfers, etc. 
 * It should change the status of the client in the staging table as rolled back so that we can
 * retry migration for that client.
 */
@Service
@Log4j2
@Transactional
public class RollBackService {

    @Autowired
    MigClientRepository migClientRepository;

    @Autowired
    MigJobRepository migJobRepository;

    @Autowired
    OchPaymentService ochPaymentService;

    @Autowired
    MigBeneficiaryMapper migBeneficiaryMapper;

    @Autowired
    ClientService clientService;

    @Autowired
    AlertsService alertsService;

    @Autowired
    RollBackMapper rollbackMapper;

    @Autowired
    MigrationAlertsMapper migrationAlertsMapper;

    @Autowired
    UserMapper userMapper;

    @Autowired
    UserService userService;

    @Autowired
    NicknameService nicknameService;

    @Autowired
    CardsService cardsService;

    @Autowired
    ECService ecService;

    public RollBackResponse rollback(String clientId) throws ServiceException {
        RollBackResponse rollbackResponse = new RollBackResponse();
        EcClientIdCheck.ecClientIdFormatCheck(clientId);

        List<MigClient> migrationClients = migClientRepository.findByEcClientIdStatusNotRollback(clientId);

        if (migrationClients == null || migrationClients.isEmpty()) {
            log.info(Message.create().clientId(clientId).descr("No valid Migration entity to roll back for :: "));
            throw new BadRequestException(MigrationErrorCodeEnum.MIGRATION_ROLLBACK_INVALID_CLIENT_ID, "No valid Migration entity to roll back for :: " + clientId);
        }
        //As we are rolling back single client.
        MigClient migrationClient=migrationClients.get(0);

        try {
            validateClient(clientId, rollbackResponse, migrationClient);

            rollbackPayments(clientId, rollbackResponse);
            rollbackClient(rollbackResponse, migrationClient);
            alertsService.rollBackAlerts(clientId, migrationClient.getGwClientId());
            nicknameService.rollback(clientId);
            cardsService.rollbackCardProgram(clientId);
            userMapper.rollback(clientId);
            userService.rollbackCardUserId(clientId);
            migBeneficiaryMapper.rollbackByEcClientId(clientId);
            ecService.updateClientDetailsEc(Arrays.asList(clientId), com.svb.gateway.migration.common.utility.MigrationConstants.EC_MIGRATION_STATUS_ROLLBACK);

        } catch (Exception e) {
            return processException(clientId, rollbackResponse, migrationClient, e);
        }

        updateRollbackResponse(rollbackResponse, true, "Rollback Execution Status : " + MigrationConstants.STATUS_SUCCESS);
        return rollbackResponse;
    }

    private RollBackResponse processException(String clientId, RollBackResponse rollbackResponse, MigClient migrationClient, Exception e) {
        Message logMessage=Message.create().clientId(clientId).descr(" Exception occurred for Rollback for client due to "+ e.getMessage());
        if(migrationClient!=null){
            logMessage.jobId(migrationClient.getJobId());
        }
        log.error(logMessage);
        updateRollbackResponse(rollbackResponse, false, " Rollback status: " + MigrationConstants.STATUS_FAILURE);
        rollbackResponse.addMessage(" Rollback Execution  Status "+ MigrationConstants.STATUS_FAILURE +" "+ e.getMessage());
        return rollbackResponse;
    }

    private void updateRollbackResponse(RollBackResponse rollbackResponse, boolean state, String message) {
        if (state) {
            rollbackResponse.setStatus(MigrationConstants.STATUS_SUCCESS);
        } else {
            rollbackResponse.setStatus(MigrationConstants.STATUS_FAILURE);
        }
        rollbackResponse.addMessage(message);
    }

    private boolean rollbackClient(RollBackResponse rollbackResponse, MigClient migrationClient) throws ServiceException {
        DeleteClientResponse deleteClientResponse = clientService.inactiveAndDeleteClient(migrationClient.getGwClientId());
        rollbackResponse.addMessage("Client Deletion: " + deleteClientResponse.getStatus() + " " + deleteClientResponse.getMessage());

        if (!MigrationConstants.STATUS_SUCCESS.equalsIgnoreCase(deleteClientResponse.getStatus())) {
            rollbackResponse.setStatus(MigrationConstants.STATUS_FAILURE);
            return false;
        }
        return true;
    }

    private void validateClient(String clientId, RollBackResponse rollbackResponse, MigClient migrationClient) throws ServiceException{
        Message message=Message.create().clientId(clientId);

        if (migrationClient == null) {
            log.info(message.descr("No valid Migration entity to roll back "));
            rollbackResponse.setStatus(MigrationConstants.STATUS_FAILURE);
            rollbackResponse.addMessage("No valid Migration entity to roll back for  " + clientId);
            throw new ServiceException(message.toString());
        }
        message.jobId(migrationClient.getJobId());

        if(jobInProgress(migrationClient.getJobId())){
            log.info(message.descr("The job of the client is still in progress, cannot rollback now. Try again later"));
            throw new ServiceException(message.toString());
        }

        if (StringUtils.isEmpty(migrationClient.getGwClientId())) {
            migrationClient.setStatus(STATUS_ROLLED_BACK);
            migClientRepository.save(migrationClient);
            log.info(message.descr("No Gateway client Id available for MIG_CLIENT_ID , Status updated to "+STATUS_ROLLED_BACK));
            rollbackResponse.addMessage("No Gateway client Id available for MIG_CLIENT_ID " + migrationClient.getMigratingClientId() + " Status updated to " + STATUS_ROLLED_BACK);
            rollbackResponse.setStatus(STATUS_ROLLED_BACK);
            throw new ServiceException(message.toString());
        }
    }

    private boolean jobInProgress(Long jobId) {
        return migJobRepository.findByJobMigrationInProgress(jobId)!=null;
    }

    private boolean rollbackPayments(String clientId, RollBackResponse rollbackResponse) {

        try {
            // Internal Transfer (MIG_INT_TRANSFERS)
            List<TransactionEntity> internalTransfers = rollbackMapper.getTransfers(clientId, MigrationConstants.INTERNAL_TRANSFERS_TABLE_NAME);
            if (!internalTransfers.isEmpty()) {
                ochPaymentService.rollback(internalTransfers.stream().map(TransactionEntity::getGW_REQ_ID).collect(Collectors.toList()));
                rollbackMapper.updateTransferStatus(internalTransfers.stream().map(TransactionEntity::getEC_TXN_ID).collect(Collectors.toList()),
                        STATUS_ROLLED_BACK, MigrationConstants.INTERNAL_TRANSFERS_TABLE_NAME);
                rollbackResponse.addMessage("Internal transfer completed for " + internalTransfers.size() + " transfers.");
            } else {
                rollbackResponse.addMessage("No Internal transfers available for rollback");
            }


            // Wire Transfer
            List<TransactionEntity> wireTransfers = rollbackMapper.getTransfers(clientId, MigrationConstants.WIRE_TRANSFERS_TABLE_NAME);
            if (!wireTransfers.isEmpty()) {
                ochPaymentService.rollback(wireTransfers.stream().map(TransactionEntity::getGW_REQ_ID).collect(Collectors.toList()));
                rollbackMapper.updateTransferStatus(wireTransfers.stream().map(TransactionEntity::getEC_TXN_ID).collect(Collectors.toList()),
                        STATUS_ROLLED_BACK, MigrationConstants.WIRE_TRANSFERS_TABLE_NAME);
                rollbackResponse.addMessage("Wire transfer completed for " + wireTransfers.size() + " transfers.");
            } else {
                rollbackResponse.addMessage("No wire transfers available for rollback");
            }


            // Ipay Payments
            List<TransactionEntity> ipayPayments = rollbackMapper.getPayments(clientId);
            if (!ipayPayments.isEmpty()) {
                ochPaymentService.rollback(ipayPayments.stream().map(TransactionEntity::getGW_REQ_ID).collect(Collectors.toList()));
                rollbackMapper.updatePayments(ipayPayments.stream().map(t -> Integer.parseInt(t.getPAYMENT_ID())).collect(Collectors.toList()),
                        STATUS_ROLLED_BACK);
                rollbackResponse.addMessage("Ipay payments completed for " + ipayPayments.size() + " payments.");
            } else {
                rollbackResponse.addMessage("No Ipay Payments available for rollback");
            }

        } catch (Exception e) {
            rollbackResponse.setStatus(MigrationConstants.STATUS_FAILURE);
            return false;
        }
        return true;
    }

}
