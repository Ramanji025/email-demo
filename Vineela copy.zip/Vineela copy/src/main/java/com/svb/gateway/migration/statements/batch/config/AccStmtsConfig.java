package com.svb.gateway.migration.statements.batch.config;

import com.svb.gateway.migration.statements.batch.dto.source.AccStmtsSourceDTO;
import com.svb.gateway.migration.statements.batch.dto.target.AccStmtsTargetDTO;
import com.svb.gateway.migration.statements.batch.mapper.AccStmtsRowMapper;
import com.svb.gateway.migration.statements.batch.processors.AccStmtsProcessor;
import com.svb.gateway.migration.common.config.ConfigBase;
import com.svb.gateway.migration.common.listeners.MigrationItemListener;
import com.svb.gateway.migration.common.utility.MigrationConstants;
import com.svb.gateway.migration.statements.batch.utils.Queries;
import io.micrometer.core.instrument.util.StringUtils;
import org.springframework.batch.core.ItemProcessListener;
import org.springframework.batch.core.ItemReadListener;
import org.springframework.batch.core.ItemWriteListener;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.core.step.builder.SimpleStepBuilder;
import org.springframework.batch.item.database.BeanPropertyItemSqlParameterSourceProvider;
import org.springframework.batch.item.database.JdbcBatchItemWriter;
import org.springframework.batch.item.database.JdbcCursorItemReader;
import org.springframework.batch.item.database.builder.JdbcBatchItemWriterBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.PreparedStatementSetter;

import javax.sql.DataSource;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Date;


@Configuration
public class AccStmtsConfig extends ConfigBase {

    @Autowired
    public MigrationItemListener<AccStmtsSourceDTO, AccStmtsSourceDTO> migrationItemListener;

    @Qualifier("eConnectDataSource")
    @Autowired
    public DataSource eConnectDataSource;

    @Qualifier("migrationDataSource")
    @Autowired
    public DataSource migrationDataSource;


    private static final String EMPTY_STRING = "";

    private static final String DATE_FILTER_REQUIRED = "1";

    @Bean
    public Step stepAccStmts() {
        return ((SimpleStepBuilder<AccStmtsSourceDTO, AccStmtsTargetDTO>) stepBuilderFactory.get(MigrationConstants.AC_STATEMENT_ENITTY)
                .<AccStmtsSourceDTO, AccStmtsTargetDTO>chunk(chunkSize).faultTolerant().skipLimit(skipLimit).skipPolicy(exceptionSkipPolicy)
                .listener(migrationSkipListener).listener(migrationStepListener)).reader(accStmtsReader(EMPTY_STRING, EMPTY_STRING, new Date(), new Date()))
                .listener((ItemReadListener) migrationItemListener).processor(accStmtsProcessor())
                .listener((ItemProcessListener) migrationItemListener).writer(accStmtsWriter())
                .listener((ItemWriteListener) migrationItemListener).build();
    }

    @Bean(destroyMethod="")
    @StepScope
    public JdbcCursorItemReader<AccStmtsSourceDTO> accStmtsReader(@Value("#{jobParameters['cifIds']}") String cif,
                                                                   @Value("#{jobParameters['datefilterrequired']}") String dateFilterRequired,
                                                                   @Value("#{jobParameters['fromdate']}") Date fromDate,
                                                                   @Value("#{jobParameters['todate']}") Date toDate) {
        StringBuilder query =
                new StringBuilder(Queries.ACC_STMTS_MIGRATION_QUERY);
        if(StringUtils.isNotBlank(dateFilterRequired))
            if (dateFilterRequired.equals(DATE_FILTER_REQUIRED)) {
                query.append(Queries.AND_CBS_STMT_DT_BETWEEN_AND);
            }
        if(StringUtils.isNotBlank(cif)) { query.append(" AND A.CUST_NUM IN (" ); query.append(cif); query.append(")"); }

        JdbcCursorItemReader<AccStmtsSourceDTO> reader = new JdbcCursorItemReader<>();
        reader.setDataSource(eConnectDataSource);
        reader.setSql(query.toString());
        getPreparedStatement(dateFilterRequired, fromDate, toDate, reader);
        reader.setRowMapper(new AccStmtsRowMapper());
        return reader;
    }

    @Bean
    @StepScope
    public AccStmtsProcessor accStmtsProcessor() {
        return new AccStmtsProcessor();
    }

    @Bean
    public JdbcBatchItemWriter<AccStmtsTargetDTO> accStmtsWriter() {
        return new JdbcBatchItemWriterBuilder<AccStmtsTargetDTO>()
                .itemSqlParameterSourceProvider(new BeanPropertyItemSqlParameterSourceProvider<>())
                .sql(Queries.ACC_STMTS_MERGE_QUERY)
                .dataSource(migrationDataSource).build();
    }

    private void getPreparedStatement(String dateFilterRequired, Date fromDate, Date toDate, JdbcCursorItemReader<AccStmtsSourceDTO> reader) {
        reader.setPreparedStatementSetter(new PreparedStatementSetter() {
            @Override
            public void setValues(PreparedStatement psv) throws SQLException {

                if(StringUtils.isNotBlank(dateFilterRequired))
                    if (dateFilterRequired.equals(DATE_FILTER_REQUIRED)) {
                        psv.setDate(1, new java.sql.Date(fromDate.getTime()));
                        psv.setDate(2, new java.sql.Date(toDate.getTime()));
                    }
            }
        });
    }
}
