package com.svb.gateway.migration.statements.batch.mapper;

import com.svb.gateway.migration.statements.batch.dto.source.AccStmtsSourceDTO;
import org.springframework.jdbc.core.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;

public class AccStmtsRowMapper implements RowMapper<AccStmtsSourceDTO>{
    /**
     * Implementations must implement this method to map each row of data
     * in the ResultSet. This method should not call {@code next()} on
     * the ResultSet; it is only supposed to map values of the current row.
     *
     * @param rs     the ResultSet to map (pre-initialized for the current row)
     * @param rowNum the number of the current row
     * @return the result object for the current row (may be {@code null})
     * @throws SQLException if an SQLException is encountered getting
     *                      column values (that is, there's no need to catch SQLException)
     */
    @Override
    public AccStmtsSourceDTO mapRow(ResultSet rs, int rowNum) throws SQLException {
        AccStmtsSourceDTO accStmtsSourceDTO=new AccStmtsSourceDTO();
        accStmtsSourceDTO.setCustNum(rs.getLong("CUST_NUM"));
        accStmtsSourceDTO.setAccNum(rs.getString("ACC_NUM"));
        accStmtsSourceDTO.setCbsStmtDate(rs.getTimestamp("CBS_STMT_DATE"));
        if(rs.getTimestamp("STMT_AVAIL_CONF_TSTAMP") != null)
            accStmtsSourceDTO.setStmtAvailConfTstamp(rs.getTimestamp("STMT_AVAIL_CONF_TSTAMP"));
        if(rs.getString("STMT_AVAILABLE") != null)
            accStmtsSourceDTO.setStmtAvailable(rs.getInt("STMT_AVAILABLE"));
        if(rs.getTimestamp("STMT_FIRST_RETR_SUCC_TSTAMP") != null)
            accStmtsSourceDTO.setStmtFirstRetrSuccTstamp(rs.getTimestamp("STMT_FIRST_RETR_SUCC_TSTAMP"));
        if(rs.getTimestamp("STMT_CYCLE_DATE") != null)
            accStmtsSourceDTO.setStmtCycleDate(rs.getTimestamp("STMT_CYCLE_DATE"));
        if(rs.getString("STATEMENT_TYPE") != null)
            accStmtsSourceDTO.setStatementType(rs.getString("STATEMENT_TYPE"));
        if(rs.getString("ACC_TYP") != null)
            accStmtsSourceDTO.setAccTyp(rs.getString("ACC_TYP"));
        if(rs.getString("ACC_MODIFIER") !=null)
            accStmtsSourceDTO.setAcName(rs.getString("ACC_MODIFIER"));
        if(rs.getString("PROD_DESC") !=null)
            accStmtsSourceDTO.setProdDesc(rs.getString("PROD_DESC"));
        return accStmtsSourceDTO;
    }
}
