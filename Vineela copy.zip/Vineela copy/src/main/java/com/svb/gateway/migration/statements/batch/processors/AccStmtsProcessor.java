package com.svb.gateway.migration.statements.batch.processors;

import com.svb.gateway.migration.statements.batch.dto.source.AccStmtsSourceDTO;
import com.svb.gateway.migration.statements.batch.dto.target.AccStmtsTargetDTO;

import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.item.ItemProcessor;



@Slf4j
public class AccStmtsProcessor implements ItemProcessor<AccStmtsSourceDTO, AccStmtsTargetDTO> {



    @Override
    public AccStmtsTargetDTO process(final AccStmtsSourceDTO accStmtsSourceDTO)  {
        AccStmtsTargetDTO accStmtsTargetDTO = new AccStmtsTargetDTO();

        accStmtsTargetDTO.setAcId(accStmtsSourceDTO.getAccNum());

        if(accStmtsSourceDTO.getAccTyp()!=null && accStmtsSourceDTO.getAccTyp().equals("6")){
            accStmtsSourceDTO.setAccTyp("CAA");
        }else if(accStmtsSourceDTO.getAccTyp()!=null && accStmtsSourceDTO.getAccTyp().equals("0")) {
            accStmtsSourceDTO.setAccTyp("LAA");
        }else{
            accStmtsSourceDTO.setAccTyp(null);
        }
        accStmtsTargetDTO.setAcType(accStmtsSourceDTO.getAccTyp());

        accStmtsTargetDTO.setCbsStmtDate(accStmtsSourceDTO.getCbsStmtDate());

        if(accStmtsSourceDTO.getStatementType()!=null && accStmtsSourceDTO.getStatementType().equals("BILLING_ST")){
            accStmtsSourceDTO.setStmtProdType("AA");
        }else{
            accStmtsSourceDTO.setStmtProdType("DDA");
        }
        accStmtsTargetDTO.setStatementType(accStmtsSourceDTO.getStatementType());

        accStmtsTargetDTO.setStmtAvailConfTstamp(accStmtsSourceDTO.getStmtAvailConfTstamp());
        accStmtsTargetDTO.setStmtAvailable(accStmtsSourceDTO.getStmtAvailable());
        accStmtsTargetDTO.setStmtCycleDate(accStmtsSourceDTO.getStmtCycleDate());
        accStmtsTargetDTO.setStmtFirstRetrSuccTstamp(accStmtsSourceDTO.getStmtFirstRetrSuccTstamp());
        accStmtsTargetDTO.setStmtProdType(accStmtsSourceDTO.getStmtProdType());
        if(accStmtsSourceDTO.getAcName()!=null && accStmtsSourceDTO.getAcName().length()>20){
            accStmtsSourceDTO.setAcName(accStmtsSourceDTO.getProdDesc());
        }
        accStmtsTargetDTO.setAcName(accStmtsSourceDTO.getAcName());
        accStmtsTargetDTO.setCreatedBy("Migration User");
        accStmtsTargetDTO.setCreatedDate(accStmtsSourceDTO.getCreatedDate());
        accStmtsTargetDTO.setJobid(accStmtsSourceDTO.getJobid());
        accStmtsTargetDTO.setCustNum(accStmtsSourceDTO.getCustNum());
        return accStmtsTargetDTO;
    }
}
