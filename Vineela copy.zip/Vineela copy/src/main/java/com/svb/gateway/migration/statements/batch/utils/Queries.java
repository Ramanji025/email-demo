package com.svb.gateway.migration.statements.batch.utils;

public class Queries {

    public static final String ACC_STMTS_MIGRATION_QUERY = "SELECT A.ACC_NUM,A.CUST_NUM, "+
            "S.CBS_STMT_DATE, " +
            "S.STMT_AVAIL_CONF_TSTAMP, " +
            "S.STMT_AVAILABLE, " +
            "S.STMT_FIRST_RETR_SUCC_TSTAMP, " +
            "S.STMT_CYCLE_DATE, " +
            "S.STATEMENT_TYPE, " +
            "A.ACC_TYP, " +
            "DA.ACC_MODIFIER, " +
            "PT.PROD_DESC " +
            "FROM ONLINE_STATEMENTS_INFO S , ACCOUNT A , DDA_ACC DA , PROD_TYP PT " +
            "WHERE S.ACCOUNT_IDENTIFIER = A.ACCOUNT_IDENTIFIER AND S.ACCOUNT_IDENTIFIER = DA.ACCOUNT_IDENTIFIER AND A.PROD_TYP = PT.PROD_TYP " ;

    public static final String ACC_STMTS_MERGE_QUERY = "MERGE INTO GWREPORTING.ONLINE_STATEMENTS_INFO USING dual " +
            "            on (ACID = :acId and CBS_STMT_DATE= :cbsStmtDate and STMT_PROD_TYPE= :stmtProdType) " +
            "            \n" +
            "            WHEN MATCHED THEN UPDATE SET " +
            "            STMT_AVAIL_CONF_TSTAMP = :stmtAvailConfTstamp, " +
            "            STMT_AVAILABLE= :stmtAvailable, " +
            "            STMT_FIRST_RETR_SUCC_TSTAMP= :stmtFirstRetrSuccTstamp, " +
            "            STMT_CYCLE_DATE= :stmtCycleDate, " +
            "            STATEMENT_TYPE= :statementType, " +
            "            AC_TYPE= :acType, " +
            "            AC_NAME= :acName " +
            "            \n" +
            "            WHEN NOT MATCHED THEN INSERT ( ACID, " +
            "            CBS_STMT_DATE, " +
            "            STMT_AVAIL_CONF_TSTAMP, " +
            "            STMT_AVAILABLE, " +
            "            STMT_FIRST_RETR_SUCC_TSTAMP, " +
            "            STMT_CYCLE_DATE, " +
            "            STATEMENT_TYPE, " +
            "            AC_TYPE, " +
            "            AC_NAME, " +
            "            STMT_PROD_TYPE ) " +
            "                   \n" +
            "            VALUES ( " +
            "            :acId, " +
            "            :cbsStmtDate, " +
            "            :stmtAvailConfTstamp, " +
            "            :stmtAvailable, " +
            "            :stmtFirstRetrSuccTstamp, " +
            "            :stmtCycleDate, " +
            "            :statementType, " +
            "            :acType, " +
            "            :acName, " +
            "            :stmtProdType " +
            "            )";

    public static final String AND_CBS_STMT_DT_BETWEEN_AND = " AND S.CBS_STMT_DATE BETWEEN ? AND ? ";
}
