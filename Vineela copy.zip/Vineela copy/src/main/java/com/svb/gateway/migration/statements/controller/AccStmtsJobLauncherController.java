package com.svb.gateway.migration.statements.controller;

import com.svb.gateway.migration.statements.api.AccStmtsJobLauncherApi;
import com.svb.gateway.migration.statements.service.AccStmtsService;
import com.svb.gateway.migration.job.model.CreateJobResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import springfox.documentation.annotations.ApiIgnore;

import java.util.ArrayList;
import java.util.Date;

@ApiIgnore
@RestController
public class AccStmtsJobLauncherController implements AccStmtsJobLauncherApi {

    private Logger LOGGER = LoggerFactory.getLogger(AccStmtsJobLauncherController.class);

    @Autowired
    private AccStmtsService accStmtsService;

    @Override
    public ResponseEntity migrateAccStmts(Date fromDate, Date toDate, ArrayList<Long> cifIds) throws Exception {
        LOGGER.info("migrateAccStmts() started CIF ID's Count --> {}" , cifIds.size());
        CreateJobResponse result = accStmtsService.accStmtsJobLauncher(fromDate, toDate, cifIds);
        LOGGER.info("migrateAccStmts() Completed");
        return ResponseEntity.accepted().body(result);
    }

}
