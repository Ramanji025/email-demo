package com.svb.gateway.migration.statements.service;

import com.svb.gateway.migration.job.model.CreateJobResponse;
import java.util.Date;
import java.util.List;

public interface AccStmtsService {
     CreateJobResponse accStmtsJobLauncher(final Date fromDate, final Date toDate, List<Long> cifIds) throws Exception;
}