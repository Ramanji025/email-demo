package com.svb.gateway.migration.statements.service;

import com.svb.gateway.migration.common.exception.InvalidInputException;
import com.svb.gateway.migration.common.utility.MigrationConstants;
import com.svb.gateway.migration.job.model.CreateJobResponse;
import com.svb.gateway.migration.job.model.CreateJobResponseData;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class AccStmtsServiceImpl implements AccStmtsService{

    private static final String UNKNOWN = "UNKNOWN" ;
    private Logger LOGGER = LoggerFactory.getLogger(AccStmtsServiceImpl.class);

    @Autowired
    @Qualifier("migJobLauncher")
    private JobLauncher jobLauncher;

    @Autowired
    private Job moveAccStmtsData;

    @Override
    public CreateJobResponse accStmtsJobLauncher(Date fromDate, Date toDate, List<Long> cifIds) throws Exception {

        long jobid = new Date().getTime();
        JobParametersBuilder builder = new JobParametersBuilder();
        builder.addLong(MigrationConstants.JOB_ID_KEY, jobid);
        if(fromDate != null && toDate != null){
            if (toDate.before(fromDate))
                throw new InvalidInputException("Invalid Date Range!");
            builder.addString(MigrationConstants.DATE_FILTER_REQUIRED_KEY, "1");
            builder.addDate(MigrationConstants.FROM_DATE_KEY, fromDate);
            builder.addDate(MigrationConstants.TO_DATE_KEY, toDate);
        }
        else{
            builder.addString(MigrationConstants.DATE_FILTER_REQUIRED_KEY, "0");
        }
        if (cifIds.size() > 0) {
            builder.addString(MigrationConstants.CIF_ID, cifIds.stream().map(String::valueOf).collect(Collectors.joining(",")));
        } else {
            throw new InvalidInputException("Minimum one CIF Id is required!");
        }
        JobExecution jobExecution = jobLauncher.run(moveAccStmtsData, builder.toJobParameters());
        String status = jobExecution.getStatus().name();
        LOGGER.info("accStmtsJobLauncher() - COMPLETE!.");
        return new CreateJobResponse(new CreateJobResponseData(jobid,status));
    }
}
