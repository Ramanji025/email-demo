package com.svb.gateway.migration.transaction.api;

import com.svb.gateway.migration.common.utility.MigrationConstants;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.Date;

@Api(value = "DDATransactionJobApi")
@RequestMapping("/api/job")
public interface DDATransactionJobApi {

    @ApiOperation(value = "Endpoint for triggering the DDA Transaction Hist Batch Job", nickname = "migrateDDATransHist", notes = "Migrate DDaTransHist")
    @ApiResponses(value = {
            @ApiResponse(code = 201, message = "Job Request Accepted "),
            @ApiResponse(code = 401, message = "Unauthorized"),
            @ApiResponse(code = 400, message = "Invalid CIF ID's or Date Range"),
            @ApiResponse(code = 403, message = "Forbidden"),
            @ApiResponse(code = 500, message = "Service unavailable ")})
    @PostMapping("/moveDDATransactionData")
    @ResponseStatus(HttpStatus.ACCEPTED)
    @PreAuthorize("hasAuthority(@migrationServiceConfig.getAuthExecute())")
    ResponseEntity<Object> migrateDDATransHist(@RequestParam(value = "from", required = false) @DateTimeFormat(pattern="yyyy-MM-dd") Date fromDate,
                                              @RequestParam(value = "to", required = false) @DateTimeFormat(pattern="yyyy-MM-dd") Date toDate,
                                              @RequestBody ArrayList<Long> cifIds) throws Exception;
}
