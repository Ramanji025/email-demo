package com.svb.gateway.migration.transaction.batch.config;

import com.svb.gateway.migration.common.config.ConfigBase;
import com.svb.gateway.migration.common.listeners.MigrationItemListener;
import com.svb.gateway.migration.common.utility.MigrationConstants;
import com.svb.gateway.migration.transaction.batch.dto.DDATransaction;
import com.svb.gateway.migration.transaction.batch.mapper.DDATransHistRowMapper;
import com.svb.gateway.migration.transaction.batch.processors.DDATranHistProcessor;
import com.svb.gateway.migration.transaction.batch.processors.TransactionKafkaWriter;
import com.svb.gateway.migration.transaction.batch.utils.Queries;
import io.micrometer.core.instrument.util.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.ItemProcessListener;
import org.springframework.batch.core.ItemReadListener;
import org.springframework.batch.core.ItemWriteListener;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.core.step.builder.SimpleStepBuilder;
import org.springframework.batch.item.database.JdbcCursorItemReader;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.PreparedStatementSetter;

import javax.sql.DataSource;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Date;

import static com.svb.gateway.migration.common.utility.MigrationConstants.*;

@Configuration
public class DDATransHistConfig extends ConfigBase {

    private Logger LOGGER = LoggerFactory.getLogger(DDATransHistConfig.class);

    @Autowired
    public MigrationItemListener<DDATransaction, DDATransaction> migrationItemListener;

    @Qualifier("eConnectDataSource")
    @Autowired
    public DataSource eConnectDataSource;

    @Autowired
    private  TransactionKafkaWriter transactionKafkaWriter;

    @Bean
    public Step stepDDATranHist() {

        return ((SimpleStepBuilder<DDATransaction, DDATransaction>) stepBuilderFactory.get(DDA_TRAN_HIST_ENTITY)
                .<DDATransaction, DDATransaction>chunk(chunkSize).faultTolerant().skipLimit(skipLimit).skipPolicy(exceptionSkipPolicy)
                .listener(migrationSkipListener).listener(migrationStepListener)).reader(dDATranHistReader(EMPTY_STRING, EMPTY_STRING, new Date(), new Date()))
                .listener((ItemReadListener) migrationItemListener).processor(dDATranHistProcessor())
                .listener((ItemProcessListener) migrationItemListener).writer(transactionKafkaWriter)
                .listener((ItemWriteListener) migrationItemListener).build();
    }

    @Bean(destroyMethod = "")
    @StepScope
    public JdbcCursorItemReader<DDATransaction> dDATranHistReader(@Value("#{jobParameters['cifIds']}") String cif,
                                                               @Value("#{jobParameters['datefilterrequired']}") String dateFilterRequired,
                                                               @Value("#{jobParameters['fromdate']}") Date fromDate,
                                                               @Value("#{jobParameters['todate']}") Date toDate) {

        JdbcCursorItemReader<DDATransaction> reader = new JdbcCursorItemReader<DDATransaction>();
        reader.setDataSource(eConnectDataSource);

        StringBuilder query = new StringBuilder(Queries.DDA_TRANS_HIST_QRY);

        if (DATE_FILTER_REQUIRED.equals(dateFilterRequired)) {
            query.append(Queries.AND_D_PST_DT_BETWEEN_AND);
        }
        if (StringUtils.isNotBlank(cif)) {
            query.append(" AND a.CUST_NUM IN (");
            query.append(cif);
            query.append(")");
        }
        query.append(Queries.ORDER_BY_A_ACC_NUM_DESC_RNK_ASC);
        reader.setSql(query.toString());
        getPrepareStatement(dateFilterRequired, fromDate, toDate, reader);
        reader.setRowMapper(new DDATransHistRowMapper());
        return reader;
    }

    @Bean
    @StepScope
    public DDATranHistProcessor dDATranHistProcessor() {
        return new DDATranHistProcessor();
    }

    private void getPrepareStatement(String dateFilterRequired, Date fromDate, Date toDate, JdbcCursorItemReader<DDATransaction> reader) {
        reader.setPreparedStatementSetter(new PreparedStatementSetter() {
            @Override
            public void setValues(PreparedStatement psv) throws SQLException {
                if (StringUtils.isNotBlank(dateFilterRequired))
                    if (dateFilterRequired == DATE_FILTER_REQUIRED) {
                        psv.setDate(1, new java.sql.Date(fromDate.getTime()));
                        psv.setDate(2, new java.sql.Date(toDate.getTime()));
                    }
            }
        });
    }
}
