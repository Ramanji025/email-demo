package com.svb.gateway.migration.transaction.batch.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.text.DecimalFormat;
import java.util.Date;
import java.util.Map;

@Data
@NoArgsConstructor
public class DDATransaction implements Serializable {

	private static final long serialVersionUID = 1L;
	private static final String TRANSACTION_SATUS_CODE_MEMO = "PEN";
	private static final String TRANSACTION_SATUS_CODE_TRN = "POS";

	private static final String TRANSACTION_SATUS_CODE_DESC_MEMO = "PENDING";
	private static final String TRANSACTION_SATUS_CODE_DESC_TRN = "POSTED";

	private static final int TRANSACTION_CODE_CHECK_PAID = 82;

	private static final String CURRENCY_CODE = "USD";
	
	DecimalFormat df = new DecimalFormat("#.00");

	private String maskedAccNum;

	@JsonIgnore
	public boolean memo;

	public String batchNum;

	public String id;
	private Long custNum;

	@JsonProperty("accountId")
	private String accNum;

	private Integer applNum;

	private String applNumCode;

	private Integer accountInfoSourceId;

	private String accountInfoSourceDesc;

	private String accountTitle;

	private Integer prodType;

	private String prodTypeDesc;

	private String businessUnit;

	private String bankId;

	@JsonFormat(pattern="yyyy-MM-dd HH:mm:ss")
	@JsonProperty("transactionDate")
	private Date pstDt;

	@JsonProperty("transactionDate_TS")
	private Date pstDtTimeStamp;

	@JsonProperty("transactionId")
	private Integer numTrnDy;

	@JsonProperty("amountCode")
	private String drCrCd;

	@JsonProperty("amtCodeDescription")
	private String amtCodeDescription;

	@JsonProperty("transactionAmount")
	private Double trnAmt;

	@JsonProperty("transactionAmountStr")
	private String trnAmtStr;

	private String currency = CURRENCY_CODE;

	@JsonIgnore
	private String desc1;

	@JsonIgnore
	private String desc2;

	@JsonIgnore
	private String desc3;

	@JsonProperty("transactionRemarks")
	private String transactionRemarks;

	@JsonProperty("transactionRemarks_UI")
	private String transactionRemarksUI;

	private String runNumber;

	private Double runningBalance=0.0;

	private String runningBalanceStr="0.0";

	@JsonProperty("instrumentId")
	private String srlChkNum;
	
	@JsonProperty("instrumentIdNum")
	private long instrumentId;

	@JsonProperty("transactionTypeCode")
	private Integer	trnCd;

	@JsonProperty("transactionTypeDesc")
	private String transactionTypeDesc;

	private String transStatusCode;

	private String transStatusDescription;

	@JsonProperty("bankReferenceNumber")
	private String	bankRef;

	private String sortCode;

	private String rvslFlag;

	private Integer timeOfDay;

	@JsonProperty("balanceOfPosting")
	private Double balAsOfPsting;

	@JsonProperty("transactionGrp")
	private String transactionGrp;

	@JsonProperty("tranQuarter")
	private String tranQuarter;

	private Map<String, String> tranDetails;


	/**
	 * @return the desc1
	 */
	public String getDesc1() {
		if(this.desc1!=null) {
			return this.desc1.trim();
		}else {
			return "";
		}
	}

	/**
	 * @return the desc2
	 */
	public String getDesc2() {
		if(this.desc2!=null) {
			return this.desc2.trim();
		}else {
			return "";
		}
	}



	/**
	 * @return the desc3
	 */
	public String getDesc3() {
		if(this.desc3!=null) {
			return this.desc3.trim();
		}else {
			return "";
		}
	}



	/**
	 * @return the transStatusCode
	 */
	public String getTransStatusCode() {
		if(memo) {
			transStatusCode=TRANSACTION_SATUS_CODE_MEMO;
		} else {
			transStatusCode=TRANSACTION_SATUS_CODE_TRN;
		}
		return transStatusCode;
	}

	/**
	 * @return the transSatusDescription
	 */
	public String getTransStatusDescription() {
		if(memo) {
			transStatusDescription=TRANSACTION_SATUS_CODE_DESC_MEMO;
		} else {
			transStatusDescription=TRANSACTION_SATUS_CODE_DESC_TRN;
		}
		return transStatusDescription;
	}
}