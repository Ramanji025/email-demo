package com.svb.gateway.migration.transaction.batch.mapper;

import com.svb.gateway.migration.transaction.batch.dto.DDATransaction;
import com.svb.gateway.migration.common.utility.RecordMetaData;
import org.springframework.jdbc.core.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.Map;

public class DDATransHistRowMapper implements RowMapper<DDATransaction> {

    private volatile Map<String, Double> runningBalMap = new HashMap<String, Double>();
    private static final SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

    /**
     *
     * @param rs
     * @param rowNum
     * @return
     * @throws SQLException
     */
    @Override
    public DDATransaction mapRow(ResultSet rs, int rowNum) throws SQLException {
        DDATransaction ddaTransaction = new DDATransaction();
        try {
            ddaTransaction.setCustNum(rs.getLong("CUST_NUM"));
            ddaTransaction.setAccNum(rs.getString("ACC_NUM"));
            ddaTransaction.setApplNum(rs.getInt("APPL_NUM"));
            ddaTransaction.setApplNumCode(rs.getString("APPL_NUM_CODE"));
            ddaTransaction.setAccountInfoSourceId(rs.getInt("ACCOUNT_INFO_SOURCE_ID"));
            ddaTransaction.setAccountInfoSourceDesc(rs.getString("ACCOUNT_INFO_SOURCE_DESC"));
            ddaTransaction.setAccountTitle(rs.getString("ACC_TITLE"));
            ddaTransaction.setProdType(rs.getInt("PROD_TYP"));
            ddaTransaction.setProdTypeDesc(rs.getString("PROD_TYPE_DESC"));
            ddaTransaction.setBusinessUnit(rs.getString("BUSINESS_UNIT"));
            ddaTransaction.setBankId(rs.getString("BANKID"));
            ddaTransaction.setRunNumber(rs.getString("RUN_NMBR"));
            ddaTransaction.setPstDt(rs.getDate("PST_DT"));
            ddaTransaction.setPstDtTimeStamp(rs.getDate("PST_DT"));
            ddaTransaction.setNumTrnDy(rs.getInt("NUM_TRN_DY"));
            ddaTransaction.setDrCrCd(rs.getString("AMOUNTCODE"));
            ddaTransaction.setAmtCodeDescription(rs.getString("AMTCODEDESCRIPTION"));
            ddaTransaction.setTrnAmt(rs.getDouble("TRN_AMT"));
            ddaTransaction.setSrlChkNum(rs.getString("SRL_CHK_NUM"));
            ddaTransaction.setInstrumentId(rs.getLong("SRL_CHK_NUM"));
            ddaTransaction.setRvslFlag(rs.getString("RVSL_FLG"));
            ddaTransaction.setDesc1(rs.getString("DESC_1"));
            ddaTransaction.setDesc2(rs.getString("DESC_2"));
            ddaTransaction.setDesc3(rs.getString("DESC_3"));
            ddaTransaction.setTrnCd(rs.getInt("TRN_CD"));
            ddaTransaction.setSortCode(rs.getString("SORT_CD"));
            ddaTransaction.setBankRef(rs.getString("BANK_REF"));
            ddaTransaction.setTransactionGrp(rs.getString("TRANSACTIONGRP") == null ? "" : rs.getString("TRANSACTIONGRP"));
            ddaTransaction.setTransactionTypeDesc(rs.getString("TRANSACTION_TYPE_DESC"));
            double runningBal = getRunningBalance(rs);
            ddaTransaction.setRunningBalance(runningBal);
            ddaTransaction.setTranQuarter(rs.getString("TRN_QTR"));

            if(rs.getString("TRN_DETAILS") != null) {
                Map<String, String> dataMap = createMapfromDetails(rs.getString("TRN_DETAILS"));
                dataMap.put("trnCode",rs.getString("det_trn_cd"));
                dataMap.put("trnAmt",rs.getString("det_trn_amt"));
                dataMap.put("trnCurrency","USD");
                dataMap.put("bnkRefNum",rs.getString("bnk_ref_num"));
                dataMap.put("custRefNum",rs.getString("cust_ref_num"));
                dataMap.put("accNum",rs.getString("ACC_NUM"));
                dataMap.put("accTitle",rs.getString("ACC_TITLE"));
                dataMap.put("trnDesc",rs.getString("det_trn_desc"));
                dataMap.put("trnDate", dateFormat.format(rs.getDate("det_trn_dt")));
                ddaTransaction.setTranDetails(dataMap);

            }
            return ddaTransaction;
        } catch (Exception e) {
            throw new SQLException(e);
        }
    }

    private double getRunningBalance(ResultSet rs) throws SQLException{
        double runningBal = 0;
        String accNum = rs.getString("ACC_NUM");
        double accBal = rs.getDouble("CURR_BAL");
        double trnAmt = rs.getDouble("TRN_AMT");
        int rank = rs.getInt("rnk");
        if(rank == 1) {
            runningBal = accBal;
        }else {
            runningBal = runningBalMap.get(accNum);
        }
        int creditDebitFlg = rs.getString("AMOUNTCODE").equals("04")? -1 : 1; //CREDIT IS subtract from previous running balance, DEBIT is add
        runningBalMap.put(accNum,runningBal + (creditDebitFlg) * trnAmt); // calculate running balance at end of last trn by adding or subtracting current transaction amount
        return runningBal;
    }
    private Map<String, String> createMapfromDetails(String string) {
        Map<String, String> dataMap = new HashMap<>();
        String[] trnDescArray = string.split(";");
        for (String string2 : trnDescArray) {
            String[] indDataArray = string2.split(":=");
            String key = RecordMetaData.get(indDataArray[0].trim());
            if(null != key) {
                dataMap.put(key, indDataArray[1].trim());
            }
        }
        return dataMap;
    }
}
