package com.svb.gateway.migration.transaction.batch.processors;


import com.svb.gateway.migration.transaction.batch.dto.DDATransaction;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.StepExecutionListener;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.beans.factory.annotation.Value;

import java.util.Optional;

public class DDATranHistProcessor implements ItemProcessor<DDATransaction, DDATransaction> , StepExecutionListener {

    private static final Logger LOGGER = LoggerFactory.getLogger(DDATranHistProcessor.class);

    private Long jobExecutionId;

    @Value("${memo.index.prefix}")
    public String memoIndexPrefix;

    @Value("${tran.index.prefix}")
    public String tranIndexPrefix;

    @Override
    public DDATransaction process(DDATransaction item) {

        item.setId(item.getAccNum() + item.getPstDt() + item.getNumTrnDy());
        item.setBatchNum(tranIndexPrefix+"-"+item.getTranQuarter());
        String maskAccNum = "";
        String originalAccNum = item.getAccNum();

        if (originalAccNum != null && originalAccNum.length() >= 4) {
            maskAccNum = "***" + originalAccNum.substring(originalAccNum.length() - 4, originalAccNum.length());
        }else {
            maskAccNum = "***"+originalAccNum;
        }
        item.setMaskedAccNum(maskAccNum);
        return item;
    }

    @Override
    public void beforeStep(StepExecution stepExecution) {
        jobExecutionId = Optional.ofNullable(stepExecution.getJobExecutionId()).orElse(0L);
    }

    @Override
    public ExitStatus afterStep(StepExecution stepExecution) {
        return null;
    }
}