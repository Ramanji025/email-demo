package com.svb.gateway.migration.transaction.batch.processors;

import com.svb.gateway.migration.common.config.KafkaConfigurationProperties;
import com.svb.gateway.migration.common.utility.GlobalUtilty;
import com.svb.gateway.migration.transaction.batch.dto.DDATransaction;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.SendResult;
import org.springframework.stereotype.Component;
import org.springframework.util.concurrent.ListenableFuture;
import org.springframework.util.concurrent.ListenableFutureCallback;

import java.util.List;


@Component
@Slf4j
public class TransactionKafkaWriter implements ItemWriter<DDATransaction> {

	@Autowired
	private KafkaConfigurationProperties properties;
	
    @Autowired
    private KafkaTemplate<String, String> kafkaTemplate;

	@Override
    public void write(List<? extends DDATransaction> trns) throws Exception {
    	for(DDATransaction trn : trns) {
    		String jsonInString = GlobalUtilty.getObjectMapper().writeValueAsString(trn);
    		ListenableFuture<SendResult<String, String>> future = kafkaTemplate.send(properties.getJsonTopic(),trn.getId(), jsonInString);
			future.addCallback(new ListenableFutureCallback<SendResult<String, String>>() {
				@Override
				public void onSuccess(SendResult<String, String> result) {
					log.debug("Transaction Message with Id :" + trn.getId() + " and trnAmt: " + trn.getRunningBalance() + " posted to kafka topic " + properties.getJsonTopic());
				}

				@Override
				public void onFailure(Throwable ex) {
					log.debug("Failure while posting transaction message with Id: " + trn.getId() + " Exception is " + ex.getMessage());
				}
			});
    	
    	}
    }
}
