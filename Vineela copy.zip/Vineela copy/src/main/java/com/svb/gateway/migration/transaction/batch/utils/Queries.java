package com.svb.gateway.migration.transaction.batch.utils;

public class Queries {

    public static final String DDA_TRANS_HIST_QRY = "select a.acc_num,a.CUST_NUM, " +
            "        da.curr_bal, " +
            "        d.PST_DT, " +
            "        d.num_trn_dy,  " +
            "        d.TRN_AMT, " +
            "        d.TRN_CD, " +
            "        d.RVSL_FLG, " +
            "        d.DESC_1, " +
            "        d.DESC_2, " +
            "        d.DESC_3,  " +
            "        d.BANK_REF, " +
            "        d.SRL_CHK_NUM, " +
            "        d.SORT_CD, 0 as RUN_NMBR, " +
            "        w.trn_cd as det_trn_cd, " +
            "        w.trn_amt as det_trn_amt, " +
            "        w.bnk_ref_num,  " +
            "        w.cust_ref_num, " +
            "        w.detl_desc as TRN_DETAILS, " +
            "        w.trn_desc as det_trn_desc, " +
            "        w.trn_dt as det_trn_dt, " +
            "       RANK() OVER(PARTITION BY d.account_identifier ORDER BY PST_DT DESC, NUM_TRN_DY DESC) rnk, " +
            "       COUNT(*) OVER (PARTITION BY d.account_identifier) CNT, " +
            "       tr.TRN_DESC AS TRANSACTION_TYPE_DESC, " +
            "       td.group_id AS TRANSACTIONGRP, " +
            "       DECODE(d.dr_cr_cd, '6', '05', '7', '05', '8', '05', '04') as amountCode," +
            "       DECODE(d.dr_cr_cd, '6', 'DEBIT', '7', 'DEBIT', '8', 'DEBIT', 'CREDIT')  as AMTCODEDESCRIPTION," +
            "       a.appl_num, DECODE(a.appl_num, 20, 'CAA', 50, 'LAA', 'CAA') as APPL_NUM_CODE, " +
            "       a.account_info_source_id, " +
            "       DECODE(a.account_info_source_id, 1, 'SVB DDA', 2, 'SVB MCA', 'SVB DDA') as ACCOUNT_INFO_SOURCE_DESC," +
            "       p.prod_desc as ACC_TITLE," +
            "       a.prod_typ, " +
            "       p.prod_desc as PROD_TYPE_DESC,  " +
            "       'SB0' AS BUSINESS_UNIT,  " +
            "       'SVB' AS BANKID ,  " +
            "       TO_CHAR(to_date(d.PST_DT, 'DD-MON-YY HH24:mi:ss'), 'YYYY-Q') AS TRN_QTR " +
            "       from wire w, dda_trn_hist d, dda_acc da, account a, TRN_DESC tr, dda_trn_desc td , prod_typ p where  " +
            "       d.account_identifier = a.account_identifier " +
            "       and d.account_identifier = da.account_identifier and a.prod_typ = p.prod_typ " +
            "       and d.trn_amt = w.trn_amt(+) " +
            "       and d.pst_dt = w.trn_dt(+) " +
            "       and d.trn_cd = tr.trn_cd(+) " +
            "       AND DECODE(d.trn_cd,21, 195,76,495,d.trn_cd) = w.trn_cd(+) " +
            "       and d.trn_cd = td.Internal_trn_cd(+)  " +
            "       and REGEXP_SUBSTR(d.desc_2,'[0-9]{12}',1)  = SUBSTR(w.bnk_ref_num(+), 1, 12)";



    public static final String ACC_BAL_MIGRATION_QUERY = "SELECT AC.ACC_NUM,AC.CUST_NUM, " +
            " DT.LEDG_BK_BAL, " +
            " DT.COLLECTED_BAL, " +
            " DT.OPENING_AVL_BAL, " +
            " DT.AVAILABLE_AMOUNT_OF_LINE_TCY,  " +
            " DT.ONE_DY_FLT, " +
            " DT.TWO_PLS_DY_FLT, " +
            " DT.TOTEL_NUM_CR, " +
            " DT.TOTAL_AMT_CR, " +
            " DT.TOTEL_NUM_DB, " +
            " DT.TOTAL_AMT_DB, " +
            " DT.AS_OF_DT, " +
            " DT.LINE_AMOUNT_TCY  " +
            " FROM DDA_ACC_TREND DT " +
            " INNER JOIN ACCOUNT AC on DT.ACCOUNT_IDENTIFIER = AC.ACCOUNT_IDENTIFIER " +
            " INNER JOIN CLIENT_CBS CC on AC.CUST_NUM = CC.CUST_NUM " +
            " WHERE AC.BUSINESS_UNIT IS NULL " +
            " AND AC.ACCOUNT_INFO_SOURCE_ID = ? " +
            " AND AC.APPL_NUM = ? ";
    public static final String ACC_BAL_TREND_INSERT_QUERY = "MERGE INTO OCHADM.AC_BAL_TREND USING dual " +
            "on (AS_OF_DT = :asOfDt and ACID= :acid and BRANCH_ID= :branchId and BANK_ID = :bankId) " +
            "WHEN MATCHED THEN UPDATE SET " +
            "                          DB_TS = :dbTs ," +
            "                          LEDG_BK_BAL= :ledgBkBal, " +
            "                          COLLECTED_BAL= :collectedBal, " +
            "                          OPENING_AVL_BAL= :openingAvlBal, " +
            "                          AVAILABLE_AMT_OF_LINE_TCY= :availableAmtOfLineTcy, " +
            "                          ONE_DY_FLT= :oneDyFlt, " +
            "                          TWO_PLS_DY_FLT= :twoPlsDyFlt, " +
            "                          TOTEL_NUM_CR= :totelNumCr, " +
            "                          TOTAL_AMT_CR= :totalAmtCr, " +
            "                          TOTEL_NUM_DB= :totelNumDb, " +
            "                          TOTAL_AMT_DB= :totalAmtDb, " +
            "                          AVAIL_BAL= :availBal, " +
            "                          LINE_AMT_TCY= :lineAmtTcy, " +
            "                          USERFIELD1= :userfield1, " +
            "                          USERFIELD2= :userfield2, " +
            "                          USERFIELD3= :userfield3, " +
            "                          DATEUSERFIELD1= :dateuserfield1, " +
            "                          DATEUSERFIELD2= :dateuserfield2, " +
            "                          DATEUSERFIELD3= :dateuserfield3, " +
            "                          DEL_FLG= :delFlg, " +
            "                          R_MOD_ID= :rModId, " +
            "                          R_MOD_TIME= sysdate, " +
            "                          R_CRE_ID= :rCreId, " +
            "                          R_CRE_TIME = sysdate " +
            " WHEN NOT MATCHED THEN INSERT  (                 " +
            "                          DB_TS, " +
            "                          BANK_ID, " +
            "                          BRANCH_ID, " +
            "                          ACID, LEDG_BK_BAL, " +
            "                          COLLECTED_BAL, OPENING_AVL_BAL, " +
            "                          AVAILABLE_AMT_OF_LINE_TCY, " +
            "                          ONE_DY_FLT, " +
            "                          TWO_PLS_DY_FLT, " +
            "                          TOTEL_NUM_CR, " +
            "                          TOTAL_AMT_CR, " +
            "                          TOTEL_NUM_DB, " +
            "                          TOTAL_AMT_DB, " +
            "                          AVAIL_BAL, " +
            "                          AS_OF_DT, " +
            "                          LINE_AMT_TCY, " +
            "                          USERFIELD1, " +
            "                          USERFIELD2, " +
            "                          USERFIELD3, " +
            "                          DATEUSERFIELD1, " +
            "                          DATEUSERFIELD2, " +
            "                          DATEUSERFIELD3, " +
            "                          DEL_FLG, " +
            "                          R_MOD_ID, " +
            "                          R_MOD_TIME, " +
            "                          R_CRE_ID, " +
            "                          R_CRE_TIME) " +
            "                          \n" +
            "                VALUES    (:dbTs, " +
            "                           :bankId, " +
            "                           :branchId, " +
            "                           :acid, " +
            "                           :ledgBkBal, " +
            "                           :collectedBal, " +
            "                           :openingAvlBal, " +
            "                           :availableAmtOfLineTcy, " +
            "                           :oneDyFlt, " +
            "                           :twoPlsDyFlt, " +
            "                           :totelNumCr, " +
            "                           :totalAmtCr, " +
            "                           :totelNumDb, " +
            "                           :totalAmtDb, " +
            "                           :availBal, " +
            "                           :asOfDt, " +
            "                           :lineAmtTcy, " +
            "                           :userfield1, " +
            "                           :userfield2, " +
            "                           :userfield3, " +
            "                           :dateuserfield1, " +
            "                           :dateuserfield2, " +
            "                           :dateuserfield3, " +
            "                           :delFlg, " +
            "                           :rModId, " +
            "                           sysdate, " +
            "                           :rCreId, " +
            "                           sysdate)";
    public static final String AND_DT_AS_OF_DT_BETWEEN_AND = " AND DT.AS_OF_DT BETWEEN ? AND ? ";
    public static final String AND_D_PST_DT_BETWEEN_AND = " AND d.PST_DT BETWEEN ? AND ? ";
    public static final String ORDER_BY_A_ACC_NUM_DESC_RNK_ASC = " order by a.ACC_num desc, rnk asc ";


    public static final String DDA_TRN_HIST_MV ="CREATE MATERIALIZED VIEW dda_trn_hist_mv\n" +
            "BUILD IMMEDIATE\n" +
            "REFRESH FORCE\n" +
            "ON DEMAND\n" +
            "AS\n" +
            "SELECT\n" +
            "    acc_num  accountId,\n" +
            "    '******'||substr(th.acc_num,-4) masked_accnum,\n" +
            "    rnk,\n" +
            "    TRN_ID transactionId,\n" +
            "    ACC_TYP,\n" +
            "    PST_DT transactionDate,\n" +
            "    NUM_TRN_DY timeOfDay,\n" +
            "    DECODE(dr_cr_cd, '6', '05', '7', '05', '8', '05', '04') AMOUNTCODE,\n" +
            "    DECODE(dr_cr_cd, '6', 'DEBIT', '7', 'DEBIT', '8', 'DEBIT', 'CREDIT')  as AMTCODEDESCRIPTION,\n" +
            "    TO_CHAR(to_date(PST_DT, 'DD-MON-YY HH24:mi:ss'), 'YYYY-Q') AS TRN_QTR ,\n" +
            "    curr_bal balanceOfPosting,\n" +
            "    0 runNumber,\n" +
            "    TRN_AMT transactionAmount,\n" +
            "    SUM(reverse_signed_amount) OVER(PARTITION BY acc_num order by rnk)-reverse_signed_amount+curr_bal runningBalance,\n" +
            "    SRL_CHK_NUM,\n" +
            "    nvl(DESC_1,'Check paid  #' ||SRL_CHK_NUM)  transactionRemarks,\n" +
            "    nvl(DESC_1,'Check paid  #' ||SRL_CHK_NUM)  transactionRemarks_UI,\n" +
            "    RVSL_FLG rvslFlag,\n" +
            "    DESC_1 transactionTypeDesc1,\n" +
            "    DESC_2,\n" +
            "    DESC_3,\n" +
            "    TRN_CD transactionTypeCode,\n" +
            "    BANK_REF bankReferenceNumber,\n" +
            "    'SB0'   businessUnit,\n" +
            "    'SVB'   bankId,\n" +
            "    'USD'   currency,\n" +
            "    FILE_SEQ_ID,\n" +
            "    TRN_DESC transactionTypeDesc,\n" +
            "    appl_num applNum,\n" +
            "    DECODE(appl_num, 20, 'CAA', 50, 'LAA', 'CAA') as applNumCode,\n" +
            "    account_info_source_id accountInfoSourceId,\n" +
            "    DECODE(account_info_source_id, 1, 'SVB DDA', 2, 'SVB MCA', 'SVB DDA') as accountInfoSourceDesc,\n" +
            "    PROD_DESC accountTitle,\n" +
            "    PROD_TYP prodType,\n" +
            "    PROD_DESC prodTypeDesc,\n" +
            "    SVB_UPDT_TIMESTAMP,\n" +
            "    TRAN_AMT_LCY transactionAmountStr,\n" +
            "    CONV_RATE,\n" +
            "    LCY_CODE,\n" +
            "    systimestamp R_CRE_TIME,\n" +
            "    SORT_CD sortCode,\n" +
            "    'POS'   transStatusCode,\n" +
            "    'POSTED'    transStatusDescription,\n" +
            "    account_identifier\n" +
            "FROM (SELECT a.acc_num, dsc.TRN_DESC,pt.PROD_DESC,pt.PROD_TYP, curr_bal, d.PST_DT, d.num_trn_dy, d.account_identifier,a.appl_num,a.account_info_source_id,\n" +
            "        CASE WHEN d.dr_cr_cd not in (6,7,8) then -1*d.TRN_AMT ELSE D.TRN_AMT end reverse_signed_amount, TRN_ID, d.ACC_TYP, d.DR_CR_CD, d.TRN_AMT, d.SRL_CHK_NUM,\n" +
            "        d.RVSL_FLG, d.DESC_1, d.DESC_2, d.DESC_3, d.TRN_CD, d.BANK_REF, d.FILE_SEQ_ID, d.SVB_UPDT_TIMESTAMP, d.TRAN_AMT_LCY, d.CONV_RATE, d.LCY_CODE, d.SORT_CD,\n" +
            "        RANK() OVER(PARTITION BY d.account_identifier ORDER BY PST_DT desc, NUM_TRN_DY desc) rnk\n" +
            "        from dda_trn_hist d\n" +
            "            inner join account a on d.account_identifier = a.account_identifier\n" +
            "            inner join dda_acc da on d.account_identifier = da.account_identifier     \n" +
            "            left join TRN_DESC dsc on d.trn_cd=dsc.trn_cd\n" +
            "            left join dda_trn_desc td on d.trn_cd = td.Internal_trn_cd\n" +
            "            left join prod_typ pt on a.prod_typ = pt.prod_typ and pt.appl_num = 20\n" +
            "            --where a.cust_num in(3301411268)\n" +
            "        ) th\n" +
            "ORDER BY acc_num, rnk asc;\n" ;
}
