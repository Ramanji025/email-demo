package com.svb.gateway.migration.transaction.controller;

import com.svb.gateway.migration.common.model.Error;
import com.svb.gateway.migration.job.model.CreateJobResponse;
import com.svb.gateway.migration.transaction.api.DDATransactionJobApi;
import com.svb.gateway.migration.transaction.service.DDATransactionService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;
import springfox.documentation.annotations.ApiIgnore;

import java.util.ArrayList;
import java.util.Date;

@ApiIgnore
@RestController
public class DDATransactionJobController implements DDATransactionJobApi {

    private static final Logger LOGGER = LoggerFactory.getLogger(DDATransactionJobController.class);

    @Autowired
    private DDATransactionService ddaTransactionService;

    @Override
    public ResponseEntity migrateDDATransHist(Date fromDate, Date toDate, ArrayList<Long> cifIds) {
        LOGGER.info("REST API - '/job/moveDDATransactionData' triggered, CIF ID's Size ==> {}", cifIds.size());
        try {
            CreateJobResponse result = ddaTransactionService.ddaTransactionJobLauncher(fromDate, toDate, cifIds);
            LOGGER.info("REST API - '/job/moveDDATransactionData' COMPLETE!.");
            return ResponseEntity.accepted().body(result);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(new Error(HttpStatus.INTERNAL_SERVER_ERROR.toString(), e.getLocalizedMessage()));
        }

    }
}
