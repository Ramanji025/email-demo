package com.svb.gateway.migration.transaction.service;

import com.svb.gateway.migration.job.model.CreateJobResponse;

import java.util.Date;
import java.util.List;

public interface DDATransactionService {

    CreateJobResponse ddaTransactionJobLauncher(final Date fromDate, final Date toDate, final List<Long> cifIds) throws Exception;
}
