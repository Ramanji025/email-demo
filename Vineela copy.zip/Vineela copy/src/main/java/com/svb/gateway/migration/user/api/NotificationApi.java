package com.svb.gateway.migration.user.api;

import com.svb.gateway.migration.common.exception.ServiceException;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseStatus;

@Api(value = "Notification", tags = "Notification Controller")
@RequestMapping("/v1/api/notification")
public interface NotificationApi {

    @ApiOperation(value = "Endpoint for Sedning a notification to the users migrated in Gateway", nickname = "notification", notes = "Send Notification")
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Send Notification Successful "),
            @ApiResponse(code = 401, message = "Unauthorized"),
            @ApiResponse(code = 400, message = "Invalid Client Id "),
            @ApiResponse(code = 403, message = "Forbidden"),
            @ApiResponse(code = 500, message = "Service unavailable ")})
    @RequestMapping(value = "/email/{jobId}/{clientId}",
            produces = MediaType.ALL_VALUE,
            consumes = MediaType.ALL_VALUE,
            method = RequestMethod.POST)
    @ResponseStatus(HttpStatus.OK)
    @PreAuthorize("hasAuthority(@migrationServiceConfig.getAuthExecute())")
    ResponseEntity<?> sendNotification(@PathVariable Integer jobId, @PathVariable String clientId) throws ServiceException;
}
