package com.svb.gateway.migration.user.controller;

import com.svb.gateway.migration.common.constants.MigrationConstants;
import com.svb.gateway.migration.common.exception.ServiceException;
import com.svb.gateway.migration.user.api.NotificationApi;
import com.svb.gateway.migration.user.service.NotificationService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;

import java.util.Objects;

@RestController
@Slf4j
public class NotificationController implements NotificationApi {

    @Autowired
    private NotificationService notificationService;

    @Override
    public ResponseEntity<?> sendNotification(Integer jobId, String clientId) throws ServiceException {

        if (StringUtils.isBlank(clientId)) {
            throw new ServiceException(HttpStatus.BAD_REQUEST.name(), "Invalid ClientId");
        }
        if(Objects.isNull(jobId) || jobId == 0) {
            throw new ServiceException(HttpStatus.BAD_REQUEST.name(), "Invalid Job Id");
        }
        notificationService.sendEmailNotification(clientId, jobId);
        return ResponseEntity.accepted().body(MigrationConstants.EMAIL_REQUEST_ACCEPTED);
    }
}
