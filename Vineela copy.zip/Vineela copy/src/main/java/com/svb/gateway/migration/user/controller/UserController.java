package com.svb.gateway.migration.user.controller;

import com.svb.gateway.migration.client.entity.MigClient;
import com.svb.gateway.migration.client.service.ClientService;
import com.svb.gateway.migration.common.exception.ServiceException;
import com.svb.gateway.migration.user.api.UserApi;
import com.svb.gateway.migration.user.model.AddUserResponse;
import com.svb.gateway.migration.user.model.CardUserResponse;
import com.svb.gateway.migration.user.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import springfox.documentation.annotations.ApiIgnore;

@ApiIgnore
@RestController
public class UserController implements UserApi {

    private final UserService userService;
    private final ClientService clientService;

    @Autowired
    public UserController(UserService userService, ClientService clientService) {
        this.userService = userService;
        this.clientService = clientService;
    }

    @Override
    @PostMapping(path = "/addUser/{jobId}/{migratingClientId}",
            consumes = MediaType.ALL_VALUE, produces = {"application/json"})
    @ResponseStatus(HttpStatus.OK)
    public ResponseEntity<AddUserResponse> addUser(@PathVariable Long jobId, @PathVariable String migratingClientId) throws ServiceException{
        MigClient migclient = clientService.getMigClient(migratingClientId, jobId);
        return new ResponseEntity<>(userService.createUsers(jobId, migclient), HttpStatus.OK);
    }

    @Override
    public ResponseEntity<CardUserResponse> updateCards(Long jobId, String ecClientId) throws ServiceException {
        CardUserResponse response = userService.updateCardUserId(jobId, ecClientId);
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

}
