package com.svb.gateway.migration.user.entity;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.util.Date;

@Entity
@Getter
@Setter
@Table(name = "MIG_CARD_USER")
@Data
public class MigCardUserEntity {

    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(name = "ID")
    private Long id;
    @Column(name = "REQUEST_ID")
    private String requestId;
    @Column(name = "EC_USER_LOGIN_ID")
    private String ecUserLoginId;
    @Column(name = "EC_CLIENT_ID")
    private String ecClientId;
    @Column(name = "GW_CLIENT_ID")
    private String gwClientId;
    @Column(name = "GW_UUID")
    private String gwUUId;
    @Column(name = "CARD_HOLDER_TYPE")
    private String cardHolderType;
    @Column(name = "PROGRAM_ID")
    private String programId;
    @Column(name = "STATUS")
    private String status;
    @Column(name = "CREATEDDATE")
    private Date createdDate;
    @Column(name = "CREATEDBY")
    private String createdBy;
    @Column(name= "JOBID")
    private Integer jobId;
    @Column(name = "UPDATEDDATE")
    private Date updatedDate;
    @Column(name = "UPDATEDBY")
    private String updatedBy;

}
