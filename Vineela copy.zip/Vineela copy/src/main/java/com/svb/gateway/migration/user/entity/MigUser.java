package com.svb.gateway.migration.user.entity;

import com.svb.gateway.migration.common.processors.IRetry;
import lombok.*;

import javax.persistence.*;
import java.util.Date;

@AllArgsConstructor
@NoArgsConstructor
@ToString
@Setter
@Getter
@Entity
@Table(name = "MIG_USER")
public class MigUser implements IRetry {

    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(name = "MIGUSERID")
    private Integer migUserId;

    @Column(name = "JOBID")
    private Long jobId;

    @Column(name = "ECCLIENTID")
    private String ecClientId;

    @Column(name = "GWCLIENTID")
    private String gwClientId;

    @Column(name = "ECUSERLOGINID")
    private String ecUserLoginId;

    @Column(name = "GWUUID")
    private String gwUuid;

    @Column(name = "FIRSTNAME")
    private String firstName;

    @Column(name = "LASTNAME")
    private String lastName;

    @Column(name = "MOBILENUMBER")
    private String mobileNumber;

    @Column(name = "EMILID")
    private String emailId;

    @Column(name = "COMMENTS")
    private String comments;

    @Column(name = "STATUS")
    private String status;

    @Column(name = "UPDATEDBY")
    private String updateBy;

    @Column(name = "UPDATEDDATE")
    private Date updateDate;

    @Column(name = "EMAIL_FLAG")
    private String emailFlag;

    @Column(name = "CARD_HOLDER_TYPE")
    private String cardHolderType;

    @Column(name = "BDCSTATUS")
    private Integer bdcStatus;

    @Column(name = "ISPRIMARYUSER")
    private Integer isPrimaryUser;

    @Column(name = "TYPE_OF_USER")
    private String typeOfUser;
}