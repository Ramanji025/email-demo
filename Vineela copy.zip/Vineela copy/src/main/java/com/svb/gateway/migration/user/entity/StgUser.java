package com.svb.gateway.migration.user.entity;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.time.LocalDate;

@Setter
@Getter
@ToString
@Entity
@Table(name = "MIG_STG_USER")
public class StgUser {

    @Id
    @Column(name = "USER_LOGIN_ID")
    private String userLoginId;

    @Column(name = "OLB_CLIENT_ID")
    private String olbClientId;

    @Column(name = "FIRST_NM")
    private String firstNm;

    @Column(name = "LAST_NM")
    private String lastNm;

    @Column(name = "EMAIL")
    private String email;

    @Column(name = "COUNTRY_CODE")
    private String countryCode;

    @Column(name = "CNT_PH")
    private String cntPh;

    @Column(name = "USER_ROLE")
    private String userRole;

    @Column(name = "USER_ACCESS")
    private String userAccess;

    @Column(name = "STATUS")
    private String status;

    @Column(name = "JOB_ID")
    private String jobId;

    @Column(name = "REMARKS")
    private String remarks;

    @Column(name = "CREATED_BY")
    private String createdBy;

    @Column(name = "CREATED_DT")
    private LocalDate createdDt;

    @Column(name = "PRIMARY_USER")
    private Boolean primaryUser;

    @Column(name = "LAST_LOGGEDIN_DATE")
    private LocalDate lastLoginDate;

    @Column(name = "TYPE_OF_USER")
    private String typeOfUser;

    @Column(name = "ISPRIMARYCONTACT")
    private String isPrimaryContact;


    public String getUserLoginId() {
        return userLoginId;
    }

    public void setUserLoginId(String userLoginId) {
        this.userLoginId = userLoginId;
    }

    public String getOlbClientId() {
        return olbClientId;
    }

    public void setOlbClientId(String olbClientId) {
        this.olbClientId = olbClientId;
    }

    public String getFirstNm() {
        return firstNm;
    }

    public void setFirstNm(String firstNm) {
        this.firstNm = firstNm;
    }

    public String getLastNm() {
        return lastNm;
    }

    public String getUserAccess() {
        return userAccess;
    }

    public void setUserAccess(String userAccess) {
        this.userAccess = userAccess;
    }

    public void setLastNm(String lastNm) {
        this.lastNm = lastNm;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getCountryCode() {
        return countryCode;
    }

    public void setCountryCode(String countryCode) {
        this.countryCode = countryCode;
    }

    public String getCntPh() {
        return cntPh;
    }

    public void setCntPh(String cntPh) {
        this.cntPh = cntPh;
    }

    public String getUserRole() {
        return userRole;
    }

    public void setUserRole(String userRole) {
        this.userRole = userRole;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getJobId() {
        return jobId;
    }

    public void setJobId(String jobId) {
        this.jobId = jobId;
    }

    public String getRemarks() {
        return remarks;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public LocalDate getCreatedDt() {
        return createdDt;
    }

    public void setCreatedDt(LocalDate createdDt) {
        this.createdDt = createdDt;
    }

    public Boolean getPrimaryUser() {
        return primaryUser;
    }

    public void setPrimaryUser(Boolean primaryUser) {
        this.primaryUser = primaryUser;
    }

    public LocalDate getLastLoginDate() {
        return lastLoginDate;
    }

    public void setLastLoginDate(LocalDate lastLoginDate) {
        this.lastLoginDate = lastLoginDate;
    }

    public String getTypeOfUser() {
        return typeOfUser;
    }

    public void setTypeOfUser(String typeOfUser) {
        this.typeOfUser = typeOfUser;
    }

    public String getIsPrimaryContact() {
        return isPrimaryContact;
    }

    public void setIsPrimaryContact(String isPrimaryContact) {
        this.isPrimaryContact = isPrimaryContact;
    }
}
