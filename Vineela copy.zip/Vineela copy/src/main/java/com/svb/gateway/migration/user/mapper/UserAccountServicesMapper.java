package com.svb.gateway.migration.user.mapper;

import com.svb.gateway.migration.client.model.AccountServices;
import com.svb.gateway.migration.user.model.UserAccountService;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import java.util.List;

@Mapper(componentModel="spring")
public interface UserAccountServicesMapper {
    UserAccountServicesMapper INSTANCE = Mappers.getMapper(UserAccountServicesMapper.class);

    @Mapping(target = "accountNumber", source = "accountNum")
    @Mapping(target = "svcDetails", source = "accServ")
    UserAccountService map(AccountServices source);

    List<UserAccountService> mapUserAccountServices(List<AccountServices> source);
}
