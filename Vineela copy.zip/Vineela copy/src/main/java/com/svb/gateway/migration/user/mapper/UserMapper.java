package com.svb.gateway.migration.user.mapper;

import com.svb.gateway.migration.common.constants.MigrationConstants;
import com.svb.gateway.migration.user.entity.MigUser;
import org.apache.ibatis.annotations.*;
import org.springframework.stereotype.Repository;

@Mapper
@Repository
public interface UserMapper {

    @Insert(value = {
            "INSERT INTO",
            "GWDMG.MIG_USER",
            "(JOBID, ECCLIENTID, GWCLIENTID, ECUSERLOGINID,  GWUUID, FIRSTNAME, LASTNAME, MOBILENUMBER, EMILID, COMMENTS, STATUS, UPDATEDBY, UPDATEDDATE, EMAIL_FLAG, CARD_HOLDER_TYPE, BDCSTATUS, ISPRIMARYUSER, TYPE_OF_USER)",
            "VALUES",
            "(#{jobId}, " +
                    "#{ecClientId}, " +
                    "#{gwClientId}, " +
                    "#{ecUserLoginId}," +
                    "#{gwUuid}, #{firstName}, #{lastName}, #{mobileNumber}, #{emailId}, #{comments}, #{status}, #{updateBy},sysdate, #{emailFlag}, #{cardHolderType}, #{bdcStatus}, #{isPrimaryUser}, #{typeOfUser})"
    })
    @Options(useGeneratedKeys = true, keyProperty = "migUserId", keyColumn = "MIGUSERID")
    Integer insertMigratingUser(MigUser migUser);

    @Update(value = "UPDATE GWDMG.MIG_USER SET EMAIL_FLAG = #{emailFlag},  UPDATEDDATE=sysdate WHERE MIGUSERID= #{migUserId}")
    void updateUserStatus(MigUser migUser);

    @Update(value = "UPDATE MIG_USER SET status='"+ MigrationConstants.STATUS_ROLLED_BACK+"' WHERE ECCLIENTID=#{clientId} ")
    void rollback(@Param("clientId") String clientId);
}
