package com.svb.gateway.migration.user.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.svb.gateway.migration.client.model.CardProgramInfo;
import com.svb.gateway.migration.client.model.Cif;
import com.svb.gateway.migration.client.model.Client;
import com.svb.gateway.migration.client.model.ClientService;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

import java.util.List;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "clientData",
        "clientCifs",
        "cardProgramDetails",
        "clientServices",
        "userDetails"
})
public class AddUserRequest {

    @JsonProperty("clientData")
    private Client clientData;
    @JsonProperty("clientCifs")
    private List<Cif> clientCifs = null;
    @JsonProperty("clientServices")
    private List<ClientService> clientServices = null;
    @JsonProperty("userDetails")
    private List<User> userDetails = null;
    @JsonProperty("cardProgramDetails")
    private List<CardProgramInfo> cardProgramDetails;
    @JsonProperty("status")
    private String status;

    @JsonProperty("clientData")
    public Client getClientData() {
        return clientData;
    }

    @JsonProperty("clientData")
    public void setClientData(Client clientData) {
        this.clientData = clientData;
    }

    @JsonProperty("clientCifs")
    public List<Cif> getClientCifs() {
        return clientCifs;
    }

    @JsonProperty("clientCifs")
    public void setClientCifs(List<Cif> clientCifs) {
        this.clientCifs = clientCifs;
    }

    @JsonProperty("clientServices")
    public List<ClientService> getClientService() {
        return clientServices;
    }

    @JsonProperty("clientServices")
    public void setClientService(List<ClientService> clientServices) {
        this.clientServices = clientServices;
    }

    @JsonProperty("userDetails")
    public List<User> getUserDetails() {
        return userDetails;
    }

    @JsonProperty("userDetails")
    public void setUserDetails(List<User> userDetails) {
        this.userDetails = userDetails;
    }

    public List<CardProgramInfo> getCardProgramDetails() {
        return cardProgramDetails;
    }

    @JsonProperty("cardProgramDetails")
    public void setCardProgramDetails(List<CardProgramInfo> cardProgramDetails) {
        this.cardProgramDetails = cardProgramDetails;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this).append("clientData", clientData).append("clientCifs", clientCifs).append("clientServices", clientServices).append("userDetails", userDetails).toString();
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(clientCifs).append(clientServices).append(clientData).append(userDetails).toHashCode();
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof AddUserRequest) == false) {
            return false;
        }
        AddUserRequest rhs = ((AddUserRequest) other);
        return new EqualsBuilder().append(clientCifs, rhs.clientCifs).append(clientServices, rhs.clientServices).append(clientData, rhs.clientData).append(userDetails, rhs.userDetails).isEquals();
    }

}