package com.svb.gateway.migration.user.model;

public interface CardUserMigrationData {
    String getEcClientId();
    String getGwUid();
    String getGwClientId();
    String getEcUserLoginId();
    String getProgramId();
    Integer getJobId();

}