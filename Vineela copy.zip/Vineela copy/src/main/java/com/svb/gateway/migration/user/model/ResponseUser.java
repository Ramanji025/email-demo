
package com.svb.gateway.migration.user.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.svb.gateway.migration.client.model.Partner;

import javax.persistence.Column;
import java.util.List;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "gwUuid", "ecUserLoginId"
})
public class ResponseUser {


    @JsonProperty("gwUuid")
    private String gwUuid;

    @JsonProperty("ecUserLoginId")
    private String ecUserLoginId;

    public String getGwUuid() {
        return gwUuid;
    }

    public void setGwUuid(String gwUuid) {
        this.gwUuid = gwUuid;
    }

    public String getEcUserLoginId() {
        return ecUserLoginId;
    }

    public void setEcUserLoginId(String ecUserLoginId) {
        this.ecUserLoginId = ecUserLoginId;
    }
}
