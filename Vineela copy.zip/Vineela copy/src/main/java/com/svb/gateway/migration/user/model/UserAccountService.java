
package com.svb.gateway.migration.user.model;

import java.util.List;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.svb.gateway.migration.client.model.SvbService;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "accountNumber",
    "svcTxnDetails"
})
public class UserAccountService {

    @JsonProperty("accountNumber")
    private String accountNumber;
    @JsonProperty("svcDetails")
    private List<SvbService> svcDetails;

    @JsonProperty("accountNumber")
    public String getAccountNumber() {
        return accountNumber;
    }

    @JsonProperty("accountNumber")
    public void setAccountNumber(String accountNumber) {
        this.accountNumber = accountNumber;
    }
    
    @JsonProperty("svcDetails")
    public List<SvbService> getSvcDetails() {
		return svcDetails;
	}

    @JsonProperty("svcDetails")
	public void setSvcDetails(List<SvbService> svcDetails) {
		this.svcDetails = svcDetails;
	}
}
