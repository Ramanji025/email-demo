package com.svb.gateway.migration.user.model;

public interface UserNotification {
     String getEcClientId();
     Integer getMigUserId();
     String getGwUid();
     String getGwClientId();
     String getPrimaryCifUbs();
     String getUserStatus();
     String getClientStatus();
}
