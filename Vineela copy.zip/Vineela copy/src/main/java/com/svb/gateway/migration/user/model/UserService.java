package com.svb.gateway.migration.user.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "serviceName",
    "serviceDisplayName",
    "serviceId",
    "accountRelated",
    "serviceTransactions"
})
public class UserService {

    @JsonProperty("serviceName")
    private String serviceName;

    @JsonProperty("serviceDisplayName")
    private String serviceDisplayName;

    @JsonProperty("serviceId")
    private String serviceId;
    
    @JsonProperty("accountRelated")
    private String accountRelated;
    
    @JsonProperty("serviceTransactions")
    private List<UserServiceTransaction> serviceTransactions;

    public String getServiceName() {
        return serviceName;
    }

    public void setServiceName(String serviceName) {
        this.serviceName = serviceName;
    }

    public String getServiceDisplayName() {
        return serviceDisplayName;
    }

    public void setServiceDisplayName(String serviceDisplayName) {
        this.serviceDisplayName = serviceDisplayName;
    }

    public String getServiceId() {
        return serviceId;
    }

    public void setServiceId(String serviceId) {
        this.serviceId = serviceId;
    }

	public String getAccountRelated() {
		return accountRelated;
	}

	public void setAccountRelated(String accountRelated) {
		this.accountRelated = accountRelated;
	}

	public List<UserServiceTransaction> getServiceTransactions() {
		return serviceTransactions;
	}

	public void setServiceTransactions(List<UserServiceTransaction> serviceTransactions) {
		this.serviceTransactions = serviceTransactions;
	}
    
    
}
