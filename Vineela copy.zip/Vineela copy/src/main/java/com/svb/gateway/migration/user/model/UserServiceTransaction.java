package com.svb.gateway.migration.user.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "transactionName",
        "access",
        "displayName",
        "accounts",
        "cardPrograms"
})
public class UserServiceTransaction {

	@JsonProperty("transactionName")
    private String transactionName;
	@JsonProperty("access")
    private String access;
	@JsonProperty("displayName")
	private String displayName;
	@JsonProperty("accounts")
	private List<String> accounts;
	@JsonProperty("cardPrograms")
	private List<String> cardPrograms;

    public String getTransactionName() {
        return transactionName;
    }

    public void setTransactionName(String transactionName) {
        this.transactionName = transactionName;
    }

    public String getAccess() {
        return access;
    }

    public void setAccess(String access) {
        this.access = access;
    }

	public String getDisplayName() {
		return displayName;
	}

	public void setDisplayName(String displayName) {
		this.displayName = displayName;
	}

	public List<String> getAccounts() {
		return accounts;
	}

	public void setAccounts(List<String> accounts) {
		this.accounts = accounts;
	}

	public List<String> getCardPrograms() {
		return cardPrograms;
	}

	public void setCardPrograms(List<String> cardPrograms) {
		this.cardPrograms = cardPrograms;
	}

    

}
