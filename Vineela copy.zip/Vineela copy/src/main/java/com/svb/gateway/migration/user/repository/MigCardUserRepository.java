package com.svb.gateway.migration.user.repository;

import com.svb.gateway.migration.user.entity.MigCardUserEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface MigCardUserRepository extends JpaRepository<MigCardUserEntity, Long> {

    MigCardUserEntity findByEcUserLoginId(String ecUserLoginId);

    @Query(value = "SELECT * FROM MIG_CARD_USER  WHERE EC_USER_LOGIN_ID = ?1 and lower(STATUS) = lower(?2) ", nativeQuery = true)
    MigCardUserEntity findByGwClientIdAndStatus(String ecUserLoginId, String status);
}
