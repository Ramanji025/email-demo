package com.svb.gateway.migration.user.repository;

import com.svb.gateway.migration.user.entity.StgUser;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface UserRepository extends JpaRepository<StgUser, Integer> {

    List<StgUser> findByOlbClientId(String olbClientId);

    @Query(value = "select * from mig_stg_user  where OLB_CLIENT_ID = ?1 and PRIMARY_USER ='N'", nativeQuery = true)
    List<StgUser> findBYOlbClntId(String olbClientId);
}
