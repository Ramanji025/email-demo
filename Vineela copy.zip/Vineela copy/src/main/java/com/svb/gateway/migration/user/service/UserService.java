package com.svb.gateway.migration.user.service;

import com.svb.gateway.migration.client.entity.MigClient;
import com.svb.gateway.migration.client.model.Cif;
import com.svb.gateway.migration.client.model.Client;
import com.svb.gateway.migration.client.model.ClientInfo;
import com.svb.gateway.migration.client.repository.ClientRepository;
import com.svb.gateway.migration.client.repository.MigClientRepository;
import com.svb.gateway.migration.common.constants.ClientConstants;
import com.svb.gateway.migration.common.constants.MigrationConstants;
import com.svb.gateway.migration.common.constants.UserConstants;
import com.svb.gateway.migration.common.exception.ServiceException;
import com.svb.gateway.migration.common.logging.Message;
import com.svb.gateway.migration.common.mapper.MigrationEntityMapper;
import com.svb.gateway.migration.common.model.Error;
import com.svb.gateway.migration.common.repository.GatewayOAuthRepository;
import com.svb.gateway.migration.common.utility.*;
import com.svb.gateway.migration.common.entity.MigEntity;
import com.svb.gateway.migration.common.repository.MigEntityRepository;
import com.svb.gateway.migration.nickname.model.RecordCount;
import com.svb.gateway.migration.user.entity.MigCardUserEntity;
import com.svb.gateway.migration.user.entity.MigUser;
import com.svb.gateway.migration.user.entity.StgUser;
import com.svb.gateway.migration.user.mapper.UserMapper;
import com.svb.gateway.migration.user.model.*;
import com.svb.gateway.migration.user.repository.MigCardUserRepository;
import com.svb.gateway.migration.user.repository.MigUserRepository;
import com.svb.gateway.migration.user.repository.UserRepository;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import com.svb.gateway.migration.common.service.RetryService;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.web.util.UriComponentsBuilder;

import java.sql.Timestamp;
import java.util.*;
import java.util.stream.Collectors;

import static com.svb.gateway.migration.common.constants.MigrationConstants.*;
import static com.svb.gateway.migration.common.constants.ReportConstants.*;
import static com.svb.gateway.migration.common.constants.UserConstants.*;

@Log4j2
@Service
public class UserService {

    public static final int FIRST = 0;
    public static final String NO_DATA_TO_MIGRATE = "No additional users available to migrate for provided client Id";
    public static final String NO_USERS_TO_MIGRATE = "No additonal users to migrate";
    public static final String ENTITY_NAME = "Additional Users";
    private static final String USER_CREATION_FAILURE = "Exception occurred while calling add user api call";

    @Value(value = "${mig.createuser.url}")
    String migAddUserUrl;
    @Value(value = "${mig.createCardUser.url}")
    String migAddCardUserUrl;
    @Value(value = "{{GATEWAY_ADMINEXT_BASE_URL}}/adminext/v1/banks/svb/bankusers/{{GATEWAY_ADM_BANK_USERID}}/clientusers")
    String migCorelationId;
    @Value(value = "${mig.updateCardUser.url}")
    String migUpdateCardUserUrl;
    @Value(value = "${mig.user.principal}")
    String miguserUuid;
    @Value("${header.service.token}")
    String token;
    @Value("${mig.bankid}")
    String clientLoginId;
    @Value("${mig.user.login.id}")
    String userLoginId;
    @Value(value = "${last.login.date.threshold.in.months}")
    Integer lastLoginMonthThreshold;
    @Value("${migration.service.userid}")
    String updatedBy;

    @Autowired
    ClientRepository clientRepository;

    @Autowired
    UserRepository userRepository;

    @Autowired
    MigClientRepository migClientRepository;

    @Autowired
    GatewayOAuthRepository gatewayOAuthRepository;

    @Autowired
    CacheManagerUtility cacheManagerUtility;

    @Autowired
    MigUserRepository migUserRepository;

    @Autowired
    private UserMapper userMapper;

    @Autowired
    private EntityLogUtility entityLogUtility;

    @Autowired
    private MigEntityRepository migEntityRepository;

    @Autowired
    private MigCardUserRepository migCardUserRepository;

    @Autowired
    private RetryService retryService;

    public void save(MigUser entity) {
        migUserRepository.save(entity);
    }

    public AddUserResponse createUsers(Long jobId, MigClient migClient) throws ServiceException {

        /******************* Initialize *****************/
        Message logMessage = Message.create().clientId(migClient.getEcClientId()).jobId(jobId);
        log.info(logMessage.descr("UserService.createClientAdditionalUser starts"));

        final com.svb.gateway.migration.nickname.model.RecordCount recordCount = new RecordCount();

        recordCount.setStartTime(new Timestamp(System.currentTimeMillis()));
        final MigClient migratedClient = migClient;
        AddUserResponse addUserResponse = new AddUserResponse();
        AddUserResponseData addUserResponseData = new AddUserResponseData();
        addUserResponse.setData(addUserResponseData);
        AddUserRequest addUserRequest = new AddUserRequest();
        Map<String, StgUser> uniqUser = new HashMap<>();
        List<ResponseUser> responseUsers = new ArrayList<>();
        int cntSuccess = 0;
        int cntFailure = 0;
        int cntAlreadyProcessed = 0;

        /******************* Read *****************/
        List<StgUser> stgUsersList = userRepository.findBYOlbClntId(migClient.getEcClientId());
        if (stgUsersList.isEmpty()) {
            recordCount.setEndTime(new Timestamp(System.currentTimeMillis()));
            entityLogUtility.saveEntityCountAndTimeLog(MigrationEntityMapper.INSTANCE.convertNoUsersToMigEntity(migratedClient, recordCount, ENTITY_NAME));
            throw new ServiceException(NO_DATA_TO_MIGRATE, NO_USERS_TO_MIGRATE);
        }

        log.info(logMessage.descr("UserService.users, No.of Additional users : " + stgUsersList.size()));

        String oAuth = cacheManagerUtility.getOauthToken();
        BasicValidation.oAuthNullCheck(oAuth);

        prepareBaseUserRequestPayload(addUserRequest, migClient);
        for (StgUser stgUser : stgUsersList) {

            recordCount.setTotal(recordCount.getTotal() + 1);
            User newAdditionalUser = new User();

            /******************* Transform *****************/
            boolean isInvalidLastLoginDate = LastLoginDateCheck.isInvalidLastLoginDate(stgUser.getLastLoginDate(), stgUser.getPrimaryUser(), lastLoginMonthThreshold);
            boolean toBeIgnored = UserConstants.DELETED_USER.equals(stgUser.getStatus()) || UserConstants.FROZEN_USER.equals(stgUser.getStatus()) || isInvalidLastLoginDate;

            if (!uniqUser.containsKey(stgUser.getUserLoginId())) {

                MigUser migUser = new MigUser();

                uniqUser.put(stgUser.getUserLoginId(), stgUser);
                List<MigUser> migratedUsers = migUserRepository.getMigratedUsers(stgUser.getUserLoginId(), stgUser.getOlbClientId(), stgUser.getJobId());
                // check if the MigUser is already created and should not be re-tried according to MigUser status
                // StgUser has fields 1. userLoginId, 2. olbClientId and 3. jobId
                // map and look up MigUser in MIG_USER based on 1. ecUserLoginId, 2. ecClientId and 3. jobId
                //    StgUser     => MigUser
                // 1. userLoginId => ecUserLoginId
                // 2. olbClientId => ecClientId
                // 3. jobId       => jobId
                if (migratedUsers != null && !migratedUsers.isEmpty() && !migratedUsers.get(FIRST).canRunAgain()) {
                    cntAlreadyProcessed++;
                    recordCount.setTotal(recordCount.getTotal() - 1);
                    // skip to the next user in the loop
                    continue;
                }

                enrichUserRequestPayload(addUserRequest, stgUser, newAdditionalUser);
                /******************* Write Target *****************/
                AddUserResponse newlyCreatedUser = null;
                AddUserResponse updatedUser = null;
                if (!toBeIgnored) {
                    if (CARD_HOLDER_ONLY_USER.equals(stgUser.getTypeOfUser())) {
                        newlyCreatedUser = createCardUser(addUserRequest);
                    } else if (MigrationConstants.FULL_ACCESS.equals(stgUser.getUserAccess())) {
                        newlyCreatedUser = createUser(addUserRequest, oAuth);
                    } else {
                        // Log userType and userAccess
                        throw new ServiceException(MigrationErrorCodeEnum.MIGRATION_CREATE_CLIENT_USER_UNKNOWN_USER_TYPE);
                    }

                    AddUserResponseData userResponseData = Optional.ofNullable(newlyCreatedUser)
                            .map(AddUserResponse::getData)
                            .orElse(null);

                    /******************* Update user status Start *****************/
                    if (UserConstants.DISABLED_USER.equalsIgnoreCase(stgUser.getStatus()) && null != userResponseData) {
                        String userId = userResponseData.getGwPrimaryUserId();
                        try {
                            updatedUser = updateUser(oAuth, UserConstants.INACTIVE, userId);
                        } catch (Exception ex) {
                            migUser.setComments(ex.getMessage());
                            log.error(logMessage.gwClientId(newlyCreatedUser.getData().getGwClientId()).descr("Update User Status Failed :: " + ex.getMessage()));
                        }
                        userResponseData = Optional.ofNullable(updatedUser)
                                .map(AddUserResponse::getData)
                                .orElse(null);
                    }
                    /******************* Update user status End *****************/

                    if (null != userResponseData) {
                        migUser.setGwClientId(newlyCreatedUser.getData().getGwClientId());
                        migUser.setGwUuid(newlyCreatedUser.getData().getGwPrimaryUserId());
                        migUser.setStatus(newlyCreatedUser.getData().getStatus()); //
                        migUser.setComments(ADDITIONAL_USER_SUCCESS);
                        recordCount.setSuccess(recordCount.getSuccess() + 1);// can be STATUS_SUCCESS or STATUS_FAILURE
                        cntSuccess++;
                    } else {
                        migUser.setStatus(STATUS_FAILURE);
                        migUser.setComments(UserConstants.USER_ENTITY_FAILED);
                        recordCount.setFailure(recordCount.getFailure() + 1);
                        cntFailure++;
                    }

                } else {
                    cntFailure++;
                    recordCount.setFailure(recordCount.getFailure() + 1);
                    migUser.setStatus(MigrationConstants.STATUS_IGNORE);
                    if (UserConstants.DELETED_USER.equals(stgUser.getStatus()))
                        migUser.setComments(UserConstants.DELETED_USER_FAILURE);
                    if (UserConstants.FROZEN_USER.equals(stgUser.getStatus()))
                        migUser.setComments(UserConstants.FROZEN_USER_FAILURE);
                    if (isInvalidLastLoginDate) migUser.setComments(UserConstants.LAST_LOGIN_DATE_BEYOND_THRESHOLD);
                }

                /******************* Write Staging *****************/
                enrichMigUserEntity(migUser, newAdditionalUser, migClient, stgUser);

                Date date = new Date();
                date.getTime();
                migUser.setUpdateDate(date);
                migUserRepository.save(migUser);
                log.debug(logMessage.descr(" Additional user updated successfully in mig_user table "));

                ResponseUser responseUser = new ResponseUser();
                responseUser.setEcUserLoginId(migUser.getEcUserLoginId());
                responseUser.setGwUuid(migUser.getGwUuid());
                responseUsers.add(responseUser);
            }
        }


        /******************* Post Processing *****************/
        addUserResponse.getData().setAdditionalUsers(responseUsers);
        addUserResponse.getData().setGwPrimaryUserId(null);
        addUserResponse.setAdditionalProperty(STATUS_SUCCESS, cntSuccess);
        addUserResponse.setAdditionalProperty(STATUS_FAILURE, cntFailure);

        recordCount.setEndTime(new Timestamp(System.currentTimeMillis()));

        if (recordCount.getTotal() > 0) {
            entityLogUtility.saveEntityCountAndTimeLog(MigrationEntityMapper.INSTANCE.convertUsersToMigEntity(migratedClient, recordCount, ENTITY_NAME));
        }
        return addUserResponse;
    }

    private void enrichMigUserEntity(MigUser migUser, User additionalUser, MigClient migClient, StgUser stgUser) {

        migUser.setEcClientId(migClient.getEcClientId());
        migUser.setEmailId(additionalUser.getUserEmail());
        migUser.setFirstName(additionalUser.getUserFname());
        migUser.setLastName(additionalUser.getUserLname());
        migUser.setMobileNumber(additionalUser.getPrimaryPhNumber());
        migUser.setUpdateBy(migClient.getUpdatedBy());
        migUser.setJobId(migClient.getJobId());
        migUser.setEcUserLoginId(stgUser.getUserLoginId());
        migUser.setBdcStatus(BDC_DISABLED);
        migUser.setIsPrimaryUser(PRIMARY_USER_FLAG_FALSE);
        migUser.setTypeOfUser(stgUser.getTypeOfUser());

        if (CARD_HOLDER_ONLY_USER.equals(stgUser.getTypeOfUser()) || COMBO_CARD_USER.equals(stgUser.getTypeOfUser())) {
            migUser.setCardHolderType(UserConstants.Y_FLAG);
        } else {
            migUser.setCardHolderType(N_FLAG);
        }
        migUser.setEmailFlag(N_FLAG);

    }

    private void enrichUserRequestPayload(AddUserRequest addUserRequest, StgUser stgUser, User newAdditionalUser) {
        List<User> userDetails = new ArrayList<>();

        newAdditionalUser.setUserFname(stgUser.getFirstNm());
        newAdditionalUser.setUserLname(stgUser.getLastNm());
        newAdditionalUser.setUserEmail(stgUser.getEmail());
        newAdditionalUser.setContactLabel(MigrationConstants.CONTACT_LABEL);
        newAdditionalUser.setContactCountryCode(MigrationConstants.COUNTRY_CODE);
        newAdditionalUser.setPrimaryPhNumber(stgUser.getCntPh());
        newAdditionalUser.setEcUserId(stgUser.getUserLoginId());
        newAdditionalUser.setIsPrimaryContact(stgUser.getIsPrimaryContact());
        if (CARD_HOLDER_ONLY_USER.equals(stgUser.getTypeOfUser())) {
            newAdditionalUser.setUserRole(MigrationConstants.ROLE_USER);
            newAdditionalUser.setUserAccess(MigrationConstants.CARD_HOLDER);
        } else {
            newAdditionalUser.setUserRole(MigrationConstants.ROLE_ADMIN);
            newAdditionalUser.setUserAccess(stgUser.getUserAccess());
        }
        newAdditionalUser.setSalutation("");
        userDetails.add(newAdditionalUser);

        // Step 5 Populate "UserDetails" element of user payload
        addUserRequest.setUserDetails(userDetails);
    }

    private void prepareBaseUserRequestPayload(AddUserRequest addUserRequest, MigClient migClient) {
        Cif cif = new Cif();
        cif.setCifNumber(migClient.getPrimaryCifUbs().toString());
        cif.setPrimary(MigrationConstants.GW_PRIMARY_USER_VALUE);
        List<Cif> cifs = new ArrayList<>();
        cifs.add(cif);

        //step 3 preparing clientData
        Client clientData = new Client();
        clientData.setOlbId(migClient.getGwClientId());

        clientData.setClientLoginId(migClient.getCompanyId());
        clientData.setProfileName(migClient.getClientName());
        clientData.setMigrationFlag(ClientConstants.MIGRATION_FLAG);

        addUserRequest.setClientCifs(cifs);
        addUserRequest.setClientData(clientData);
    }

    public AddUserResponse createUser(AddUserRequest request, String oAuth) {
        Message logMessage = Message.create().operation("UserService.createUser").entityName(Message.Entity.user);
        AddUserResponse addUserResponse = new AddUserResponse();
        AddUserResponseData addUserResponseData = new AddUserResponseData();
        ResponseEntity<ClientInfo> clientInfo = null;
        String error = null;

        try {
            HttpHeaders headers = new HttpHeaders();
            headers.add(MigrationConstants.AUTHORIZATION_HEADER_NAME, oAuth);
            headers.add(MigrationConstants.CONTENT_TYPE, MigrationConstants.APPLICATION_HEADER_JSON);

            HttpEntity<AddUserRequest> requestEntity = new HttpEntity<>(request, headers);

            clientInfo = retryService.exchange(migAddUserUrl, HttpMethod.POST, requestEntity, new ParameterizedTypeReference<ClientInfo>() {
            });

        } catch (Exception exception) {
            log.error(logMessage.descr(USER_CREATION_FAILURE + exception.getMessage()));
            error = exception.getMessage();
        }
        log.debug(logMessage.descr("UserService.createUser is ended, response is" + clientInfo));

        return getAddUserResponse(addUserResponse, addUserResponseData, clientInfo, error);
    }

    public AddUserResponse updateUser(String oAuth, String status, String userId) {

        AddUserResponse addUserResponse = new AddUserResponse();
        AddUserResponseData addUserResponseData = new AddUserResponseData();
        String error = null;
        ResponseEntity<ClientInfo> clientInfo = null;

        try {
            HttpHeaders headers = new HttpHeaders();
            headers.add(MigrationConstants.AUTHORIZATION_HEADER_NAME, oAuth);
            headers.add(MigrationConstants.OPERATION, MigrationConstants.INACTIVATE);

            UserAddressRequest userAddressRequest = new UserAddressRequest();
            userAddressRequest.setStatus(status);

            HttpEntity<UserAddressRequest> requestEntity = new HttpEntity<>(userAddressRequest, headers);

            String finalUrl = migAddUserUrl + MigrationConstants.SLASH + userId + "/status";

            UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(finalUrl)
                    .queryParam(MigrationConstants.OPERATION, MigrationConstants.INACTIVATE);

            clientInfo = retryService.exchange(builder.toUriString(), HttpMethod.PUT, requestEntity, new ParameterizedTypeReference<ClientInfo>() {
            });

        } catch (Exception exception) {
            log.error(Message.create().operation("User Update").entityName(Message.Entity.user).descr(USER_CREATION_FAILURE + exception.getMessage()));
            error = exception.getMessage();
        }
        return getAddUserResponse(addUserResponse, addUserResponseData, clientInfo, error);

    }

    public AddUserResponse createCardUser(AddUserRequest request) {
        Message logMessage = Message.create().entityName(Message.Entity.user).operation("UserService.CreateCardUser");
        AddUserResponse addUserResponse = new AddUserResponse();
        AddUserResponseData addUserResponseData = new AddUserResponseData();
        ResponseEntity<ClientInfo> clientInfo = null;
        String error = null;

        try {
            HttpHeaders headers = new HttpHeaders();
            HttpEntity<AddUserRequest> requestEntity = new HttpEntity<>(request, headers);
            clientInfo = retryService.exchange(migAddCardUserUrl, HttpMethod.POST, requestEntity, new ParameterizedTypeReference<ClientInfo>() {
            });

        } catch (Exception exception) {
            log.error(logMessage.descr(USER_CREATION_FAILURE + exception.getMessage()));
            error = exception.getMessage();
        }
        log.debug(logMessage.descr("UserService.cardService is ended, response is" + clientInfo));
        return getAddUserResponse(addUserResponse, addUserResponseData, clientInfo, error);
    }

    private AddUserResponse getAddUserResponse(AddUserResponse addUserResponse, AddUserResponseData addUserResponseData, ResponseEntity<ClientInfo> clientInfo, String error) {


        Client clientData = Optional.ofNullable(clientInfo)
                .map(ResponseEntity<ClientInfo>::getBody)
                .map(ClientInfo::getClientData)
                .orElse(null);

        List<User> userDetails = Optional.ofNullable(clientInfo)
                .map(ResponseEntity<ClientInfo>::getBody)
                .map(ClientInfo::getUserDetails)
                .orElse(null);

        if (null != clientData && null != userDetails) {
            addUserResponseData.setGwClientId(clientData.getOlbId());
            addUserResponseData.setClientLoginId(clientData.getClientLoginId());
            addUserResponseData.setGwPrimaryUserId(userDetails.get(0).getIdStoreuserkey());
            addUserResponseData.setStatus(STATUS_SUCCESS);
        } else {
            addUserResponseData.setStatus(STATUS_FAILURE);
            Error e;
            if (error == null) {
                e = new Error("0000", null);
            } else {
                e = new Error("0000", UserConstants.ADD_USER_FAILED);
            }
            addUserResponse.setErrors(List.of(e));
        }
        addUserResponse.setData(addUserResponseData);

        return addUserResponse;

    }

    public CardUserResponse updateCardUserId(Long jobId, String ecClientId) throws ServiceException {

        Message logMessage = Message.create().jobId(jobId).clientId(ecClientId).operation("UserService.UpdateCardUserId").entityName(Message.Entity.updateCard);
        log.debug(logMessage.descr("Update Card Service starts for the client::" + ecClientId));
        long startTime = new Date().getTime();
        int writeCount = 0;
        int skipCount = 0;

        //Card Users data
        List<CardUserMigrationData> userList = migClientRepository.getClientsByClientIdAndJob(ecClientId, jobId);
        List<CardUserMigrationData> updatedUserList = userList.stream()
                .filter(x -> !(x.getGwUid() == null || x.getEcUserLoginId() == null)).collect(Collectors.toList());
        CardUserResponse response = new CardUserResponse();
        if (!userList.isEmpty()) {
            skipCount += userList.size() - updatedUserList.size();
        }
        String oAuth = cacheManagerUtility.getOauthToken();
        BasicValidation.oAuthNullCheck(oAuth);
        for (CardUserMigrationData client : updatedUserList) {
            CardUserRequest request = new CardUserRequest();
            request.setNewClientId(client.getGwClientId());
            request.setNewUserId(client.getGwUid());
            request.setOldClientId(client.getEcClientId());
            request.setOldUserId(client.getEcUserLoginId());
            request.setPrograms(Collections.singletonList(client.getProgramId()));
            request.setRequestId(UUID.randomUUID().toString());
            MigCardUserEntity cardUser = null;
            cardUser = new MigCardUserEntity();
            try {
                HttpHeaders headers = new HttpHeaders();
                headers.add(MigrationConstants.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE);
                headers.add(MigrationConstants.AUTHORIZATION_HEADER, oAuth);
                HttpEntity<CardUserRequest> requestEntity = new HttpEntity<>(request, headers);
                logMessage.url(migUpdateCardUserUrl);
                ResponseEntity<CardUserResponse> responseEntity =
                        retryService.exchange(migUpdateCardUserUrl, HttpMethod.POST, requestEntity, new ParameterizedTypeReference<CardUserResponse>() {
                        });

                cardUserEntity(client, request, cardUser);
                cardUser.setStatus(STATUS_SUCCESS);
                cardUser.setCreatedDate(DateUtility.getCurrentTimestamp());
                migCardUserRepository.save(cardUser);
                log.info(logMessage.descr("Update Card details stored in mig_card_user table::" + ecClientId));
                response = responseEntity.getBody();
                writeCount++;
            } catch (Exception exception) {
                log.error(logMessage.descr(exception.getMessage()));
                cardUser.setStatus(STATUS_FAILURE);
                migCardUserRepository.save(cardUser);
                cardUser.setCreatedDate(DateUtility.getCurrentTimestamp());
                if (response != null) {
                    response.setMigrationStatus(ROLLBACK_INITIATED);
                    response.setRequestID(request.getRequestId());
                    response.setMigrationStatus(FALSE);
                }
                skipCount++;
            }
        }

        long endTime = new Date().getTime();
        Long duration = (endTime - startTime) / 1000;
        MigEntity migEntity = new MigEntity();
        migEntity.setEcclientId(ecClientId);
        migEntity.setCreatedDateTime(new Timestamp(new Date().getTime()));
        migEntity.setStartTime(new Timestamp(startTime));
        migEntity.setEndTime(new Timestamp(endTime));
        migEntity.setEntityName(MIG_CARD_USER_UPDATE);
        migEntity.setReadCount(userList.size());
        migEntity.setWriteCount(writeCount);
        migEntity.setSkipCount(skipCount);
        migEntity.setJobId(Math.toIntExact(jobId));
        if (!userList.isEmpty()) {
            migEntity.setGwclientId(userList.get(0).getGwClientId());
        }
        else{
            migEntity.setGwclientId(null);
        }
        migEntity.setTotalStepTime(duration.intValue());
        migEntityRepository.save(migEntity);
        log.info(logMessage.descr("Update Card Service ended for the client::" + ecClientId));
        return response;
    }

    public CardUserResponse rollbackCardUserId(String ecClientId) {

        Message logMessage = Message.create().clientId(ecClientId)
                .entityName(Message.Entity.updateCard);

        long startTime = new Date().getTime();
        int writeCount = 0;
        int skipCount = 0;

        String gwClientId = null;
        List<CardUserMigrationData> userList = migClientRepository.getCardUsersDataForMigrationRollback(ecClientId);
        CardUserResponse cardUserResponse = new CardUserResponse();
        List<CardUserMigrationData> updatedUserList = userList.stream()
                .filter(x -> !(x.getGwUid() == null || x.getEcUserLoginId() == null)).collect(Collectors.toList());
        if (!userList.isEmpty()) {
            gwClientId = userList.get(0).getGwClientId();
            skipCount += userList.size() - updatedUserList.size();
        }
        for (CardUserMigrationData cardUser : updatedUserList) {

            log.info(logMessage.userId(cardUser.getEcUserLoginId()).descr("Rollback of Update Card Service starts for UUID :: " + cardUser.getGwUid()));

            CardUserRequest request = new CardUserRequest();
            request.setNewClientId(cardUser.getGwClientId());
            request.setOldClientId(cardUser.getEcClientId());
            request.setOldUserId(cardUser.getEcUserLoginId());
            request.setNewUserId(cardUser.getGwUid());
            request.setPrograms(Collections.singletonList(cardUser.getProgramId()));
            request.setRequestId(UUID.randomUUID().toString());
            MigCardUserEntity cardUserEntity = migCardUserRepository.findByGwClientIdAndStatus(cardUser.getEcUserLoginId(), MigrationConstants.STATUS_SUCCESS);
            try {
                HttpHeaders headers = new HttpHeaders();
                headers.add(MigrationConstants.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE);
                headers.add(MigrationConstants.AUTHORIZATION_HEADER, token);
                HttpEntity<CardUserRequest> requestEntity = new HttpEntity<>(request, headers);
                logMessage.url(migUpdateCardUserUrl);
                ResponseEntity<CardUserResponse> responseEntity =
                        retryService.exchange(migUpdateCardUserUrl, HttpMethod.POST, requestEntity, new ParameterizedTypeReference<CardUserResponse>() {
                        });
                writeCount++;
                cardUserEntity(cardUser, request, cardUserEntity);
                cardUserEntity.setStatus(STATUS_ROLLED_BACK);
                cardUserEntity.setUpdatedDate(new Date());
                migCardUserRepository.save(cardUserEntity);
                cardUserResponse = responseEntity.getBody();
            } catch (Exception exception) {
                log.error(logMessage.descr(exception.getMessage()));
                if (cardUserResponse != null) {
                    cardUserResponse.setRequestID(request.getRequestId());
                    cardUserResponse.setMigrationStatus(FALSE);
                    cardUserEntity.setStatus(STATUS_FAILURE);
                    cardUserEntity.setUpdatedDate(new Date());
                    migCardUserRepository.save(cardUserEntity);
                }
                skipCount++;
            }
        }

        long endTime = new Date().getTime();
        Long duration = (endTime - startTime) / 1000;
        MigEntity migEntity = new MigEntity();
        migEntity.setEcclientId(ecClientId);
        migEntity.setCreatedDateTime(new Timestamp(new Date().getTime()));
        migEntity.setStartTime(new Timestamp(startTime));
        migEntity.setEndTime(new Timestamp(endTime));
        migEntity.setEntityName(MIG_CARD_USER_ROLLBACK);
        migEntity.setReadCount(userList.size());
        migEntity.setWriteCount(writeCount);
        migEntity.setSkipCount(skipCount);
        migEntity.setGwclientId(gwClientId);
        migEntity.setTotalStepTime(duration.intValue());
        migEntityRepository.save(migEntity);
        return cardUserResponse;

    }

    private void cardUserEntity(CardUserMigrationData client, CardUserRequest request, MigCardUserEntity cardUser) {
        cardUser.setCardHolderType("Y");
        cardUser.setEcClientId(client.getEcClientId());
        cardUser.setEcUserLoginId(request.getOldUserId());
        cardUser.setGwClientId(request.getNewClientId());
        cardUser.setGwUUId(request.getNewUserId());
        cardUser.setProgramId(client.getProgramId());
        cardUser.setRequestId(request.getRequestId());
        cardUser.setJobId(client.getJobId());
        cardUser.setCreatedBy(updatedBy);
        cardUser.setUpdatedBy(updatedBy);
        cardUser.setCreatedDate(cardUser.getCreatedDate());
    }

}
