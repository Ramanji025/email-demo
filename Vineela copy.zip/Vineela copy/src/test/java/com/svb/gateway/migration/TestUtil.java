package com.svb.gateway.migration;

public class TestUtil {
    public static final String TEST_USER_USER1 =  "crmuser1" ;
    public static final String TEST_USER_USER3 =  "crmuser3" ;
    public static final String TEST_USER1_INVALID_PASSWORD =  "invalidPassword" ;
    public static final String TEST_USER1_VALID_PASSWORD =  "Access123" ;
    public static final String TEST_USER1_ROLE_EXECUTE = "App-gateway-migration-dev-execute";
    public static final String TEST_USER1_ROLE_VIEW = "App-gateway-migration-dev-view";

    /*public static final String TEST_USER_USER2 =  "crmuser2" ;
    public static final String TEST_USER2_INVALID_PASSWORD =  "invalidPassword" ;
    public static final String TEST_USER2_VALID_PASSWORD =  "Access123" ;
    public static final String TEST_USER2_ROLE_EXECUTE = "SLA_chd-vd-tgapp01";*/
}
