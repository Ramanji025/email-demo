package com.svb.gateway.migration.accountbalance.processors;

import com.svb.gateway.migration.accountbalance.batch.dto.source.AccBalanceTrend;
import com.svb.gateway.migration.accountbalance.batch.dto.target.AcBalTrend;
import com.svb.gateway.migration.accountbalance.batch.processors.AccBalTrendProcessor;
import com.svb.gateway.migration.common.DataProvider;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import static org.junit.jupiter.api.Assertions.assertNotNull;

@SpringBootTest
@ExtendWith(SpringExtension.class)
public class AccountBalanceProcessorTest {

    private AccBalTrendProcessor accBalTrendProcessor;

    private static final String data  = "{\n" +
            "  \"accNum\": \"351173171\",\n" +
            "  \"ledgBkBal\": 0,\n" +
            "  \"collectedBal\": 0,\n" +
            "  \"openingAvlBal\": 0,\n" +
            "  \"availableAmountOfLineTcy\": 0,\n" +
            "  \"oneDyFlt\": 0,\n" +
            "  \"twoPlsDyFlt\": 0,\n" +
            "  \"totalNumCr\": 0,\n" +
            "  \"totalAmtCr\": 0,\n" +
            "  \"totalNumDb\": 0,\n" +
            "  \"totalAmtDb\": 0,\n" +
            "  \"asOfDt\": 1577952000000,\n" +
            "  \"lineAmtTcy\": 0,\n" +
            "  \"createdDate\": null,\n" +
            "  \"jobid\": 0\n" +
            "}";

    @BeforeEach
    public void beforeEach() {
        accBalTrendProcessor = new AccBalTrendProcessor();
    }

    @Test
    public  void testProcessWithCreditTrnType()  throws Exception{

        AccBalanceTrend accBalanceTrend = (AccBalanceTrend) DataProvider.getGenericObject(data, AccBalanceTrend.class);
        AcBalTrend acBalTrend  = accBalTrendProcessor.process(accBalanceTrend);
        assertNotNull(acBalTrend);
    }

}
