package com.svb.gateway.migration.alerts.service;

import com.svb.gateway.migration.alerts.entity.Alerts;
import com.svb.gateway.migration.alerts.entity.AlertsIPDTForAULTEntity;
import com.svb.gateway.migration.alerts.entity.MigRefAlertMapping;
import com.svb.gateway.migration.alerts.entity.MigrationAlerts;
import com.svb.gateway.migration.alerts.model.MigAlertUser;
import com.svb.gateway.migration.alerts.repository.MigAlertUserRepository;
import com.svb.gateway.migration.cards.entity.MigCardProgram;
import com.svb.gateway.migration.cards.repository.MigCardProgramRepository;
import com.svb.gateway.migration.common.constants.MigrationConstants;
import com.svb.gateway.migration.common.exception.ServiceException;
import lombok.extern.slf4j.Slf4j;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.test.context.junit.jupiter.SpringExtension;


import java.util.ArrayList;
import java.util.Collection;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.fail;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

@Slf4j
@SpringBootTest
@ExtendWith(SpringExtension.class)
public class AlertMigrationServiceTest {

    @Mock
    private MigAlertUserRepository migAlertUserRepository;

    @Mock
    private MigCardProgramRepository migCardProgramRepository;

    @Qualifier("alertsFASNamedParameterJdbcTemplate")
    @Mock
    private NamedParameterJdbcTemplate alertsFASJdbcTemplate;


    @InjectMocks
    @Spy
    AlertMigrationService alertMigrationService;

    Alerts alerts=new Alerts();
    MigAlertUser migrationUser;
    MigCardProgram migCardProgram=new MigCardProgram();
    MigRefAlertMapping migRefAlertMapping =new MigRefAlertMapping();
    Collection<AlertsIPDTForAULTEntity> inputDetailsEntities=new ArrayList<>();
    AlertsIPDTForAULTEntity alertsIPDTForAULTEntity1 =new AlertsIPDTForAULTEntity();
    AlertsIPDTForAULTEntity alertsIPDTForAULTEntity2 =new AlertsIPDTForAULTEntity();
    AlertsIPDTForAULTEntity alertsIPDTForAULTEntity3 =new AlertsIPDTForAULTEntity();
    AlertsIPDTForAULTEntity alertsIPDTForAULTEntity4 =new AlertsIPDTForAULTEntity();


    @BeforeEach
    void setUp() {
         migrationUser= new MigAlertUser() {
            @Override
            public String getEcClientId() {
                return "data1234";
            }

            @Override
            public String getEcUserLoginId() {
                return "user123456";
            }

            @Override
            public String getGwUid() {
                return "27DGH3434WDK78ED78";
            }

            @Override
            public String getGwClientId() {
                return "GWADDR1234";
            }

            @Override
            public String getPrimaryCifUbs() {
                return "2000023423";
            }

            @Override
            public String getUserStatus() {
                return "SUCCESS";
            }

            @Override
            public String getClientStatus() {
                return "SUCCESS";
            }
        };

        migCardProgram.setCif("1234567");

        migRefAlertMapping.setEcAlertTypeId(11);
        migRefAlertMapping.setGwAlertId("SVB_ABCD");
        migRefAlertMapping.setGwAlertType("DEFAULT");

        alertsIPDTForAULTEntity1.setFieldName("STRING1");
        alertsIPDTForAULTEntity1.setDefaultValue("PRO");
        alertsIPDTForAULTEntity2.setFieldName("STRING2");
        alertsIPDTForAULTEntity2.setDefaultValue("SUC");
        alertsIPDTForAULTEntity3.setFieldName("STRING3");
        alertsIPDTForAULTEntity3.setDefaultValue(null);
        alertsIPDTForAULTEntity4.setFieldName("STRING4");
        alertsIPDTForAULTEntity4.setDefaultValue(null);
        inputDetailsEntities.add(alertsIPDTForAULTEntity1);
        inputDetailsEntities.add(alertsIPDTForAULTEntity2);
        inputDetailsEntities.add(alertsIPDTForAULTEntity3);
        inputDetailsEntities.add(alertsIPDTForAULTEntity4);

        alerts.setAlertStatus("ACTIVE");
        alerts.setAlertTypeId(11);
        alerts.setAlertTypeName("CAM_");
        alerts.setAlertsClientConfigId(12345);
        alerts.setEcAlertType("SIGNUP");
        alerts.setEcClientId("data1234");
        alerts.setEcAlertAccountId("12345678");
        alerts.setEcAlertDeliveryType(3);
    }

    @Test
    void insert_throws_ServiceException() {
        try {
            MigrationAlerts migrationAlerts=alertMigrationService.insert(alerts, migRefAlertMapping,inputDetailsEntities);
            assertEquals(MigrationConstants.STATUS_FAILURE,migrationAlerts.getStatus());
        } catch (ServiceException serviceException) {

        }
    }

    @Test
    void insert_throws_ServiceExceptionForCardProgram() {
        try {
            when(migAlertUserRepository.getMigratedAlertUser(anyString(),anyString())).thenReturn(migrationUser);
            MigrationAlerts migrationAlerts=alertMigrationService.insert(alerts, migRefAlertMapping,inputDetailsEntities);
            assertEquals(MigrationConstants.STATUS_FAILURE,migrationAlerts.getStatus());
        } catch (ServiceException serviceException) {

        }
    }

    @Test
    void insert_CardsAlert() {
        try {
            when(migAlertUserRepository.getMigratedAlertUser(any(),any())).thenReturn(migrationUser);
            when(migCardProgramRepository.findByOlbIdAndCardProgram(any(),any())).thenReturn(migCardProgram);
            alertMigrationService.alertEndDateToAfterNYears=2;
            MigrationAlerts migrationAlerts=alertMigrationService.insert(alerts, migRefAlertMapping,inputDetailsEntities);
        } catch (ServiceException e) {
           fail();
        }
    }

    @Test
    void insert_NoCardProgramLinked() {
        try {
            when(migAlertUserRepository.getMigratedAlertUser(any(),any())).thenReturn(migrationUser);
            when(migCardProgramRepository.findByOlbIdAndCardProgram(any(),any())).thenReturn(null);
            alertMigrationService.alertEndDateToAfterNYears=2;
            MigrationAlerts migrationAlerts=alertMigrationService.insert(alerts, migRefAlertMapping,inputDetailsEntities);
        } catch (ServiceException e) {
            fail();
        }
    }

    @Test
    void insert_CardsAlertUniqueConstraintAtTarget() {
        try {
            alerts.setAlertTypeName("Account Transaction");
            when(migAlertUserRepository.getMigratedAlertUser(any(),any())).thenReturn(migrationUser);
            when(migCardProgramRepository.findByOlbIdAndCardProgram(any(),any())).thenReturn(migCardProgram);
            alertMigrationService.alertEndDateToAfterNYears=2;
            when(alertsFASJdbcTemplate.update(any(), (Map<String, ?>) any())).thenThrow(DuplicateKeyException.class);
            MigrationAlerts migrationAlerts=alertMigrationService.insert(alerts, migRefAlertMapping,inputDetailsEntities);
        } catch (ServiceException e) {
            fail();
        }
    }

    @Test
    void insert_CardsAlertDataIntegrityViolationExceptionAtTarget() {
        try {
            when(migAlertUserRepository.getMigratedAlertUser(any(),any())).thenReturn(migrationUser);
            when(migCardProgramRepository.findByOlbIdAndCardProgram(any(),any())).thenReturn(migCardProgram);
            alertMigrationService.alertEndDateToAfterNYears=2;
            when(alertsFASJdbcTemplate.update(any(), (Map<String, ?>) any())).thenThrow(DataIntegrityViolationException.class);
            MigrationAlerts migrationAlerts=alertMigrationService.insert(alerts, migRefAlertMapping,inputDetailsEntities);
        } catch (ServiceException e) {
            fail();
        }
    }

}
