package com.svb.gateway.migration.alerts.service;

import com.svb.gateway.migration.alerts.entity.*;
import com.svb.gateway.migration.alerts.mapper.MigrationAlertsMapper;
import com.svb.gateway.migration.alerts.model.AlertsResponse;
import com.svb.gateway.migration.alerts.repository.MigRefAlertMappingRepository;
import com.svb.gateway.migration.alerts.repository.SignUpAlertsRepository;
import com.svb.gateway.migration.client.entity.MigClient;
import com.svb.gateway.migration.client.repository.MigClientRepository;
import com.svb.gateway.migration.common.exception.ServiceException;
import com.svb.gateway.migration.common.utility.EntityLogUtility;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentMatchers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.fail;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.when;
import static org.mockito.Mockito.doThrow;

@Slf4j
@SpringBootTest
@ExtendWith(SpringExtension.class)
class AlertsServiceTest {

    @Mock
    private AlertMigrationService alertMigrationService;

    @Mock
    private MigClientRepository migClientRepository;

    @Mock
    private MigrationAlertsMapper migrationAlertsMapper;

    @Mock
    private SignUpAlertsRepository signUpAlertsRepository;

    @Mock
    private MigRefAlertMappingRepository migRefAlertMappingRepository;

    @Qualifier("alertsFASNamedParameterJdbcTemplate")
    @Mock
    private NamedParameterJdbcTemplate alertsFASJdbcTemplate;

    @Mock
    EntityLogUtility entityLogUtility;

    @InjectMocks
    @Spy
    AlertsService alertsService;

    public String clientId="data1234";
    public Long jobId=Long.valueOf("123");
    public String getClientId="GWname1234";
    public String status="SUCCESS";

    Alerts alert=new Alerts();
    MigClient migClient = new MigClient();
    MigRefAlertMapping migRefAlertMapping =new MigRefAlertMapping();
    List<MigRefAlertMapping> migRefAlertMappingList =new ArrayList<>();
    List<AlertsIPDTForAULTEntity> inputDetailsEntities=new ArrayList<>();
    AlertsIPDTForAULTEntity alertsIPDTForAULTEntity =new AlertsIPDTForAULTEntity();

    MigratedAlertsEntity successAlert=new MigratedAlertsEntity();
    MigrationAlerts successMigrationAlert=new MigrationAlerts();


    @BeforeEach
    void setUp() {
        alert.setAlertTypeId(11);
        migRefAlertMapping.setEcAlertTypeId(11);
        migRefAlertMapping.setGwAlertType("DEFAULT");
        migRefAlertMapping.setGwAlertId("SVB_ABCD");
        migRefAlertMappingList.add(migRefAlertMapping);
        alertsIPDTForAULTEntity.setFieldName("STRING1");
        alertsIPDTForAULTEntity.setDefaultValue("PRO");
        inputDetailsEntities.add(alertsIPDTForAULTEntity);
        migClient.setEcClientId(clientId);
    }

    @Test
    void registerAlerts()  {
        try {
            List<Alerts> alertsList=new ArrayList<>();
            alertsList.add(alert);
            successAlert.setStatus("SUCCESS");
            successAlert.setJobId(jobId);
            successAlert.setEc_Client_Id("data1234");
            migClient.setGwClientId(getClientId);
            when(migRefAlertMappingRepository.findGWMappingDetails()).thenReturn(migRefAlertMappingList);
            when(alertsFASJdbcTemplate.query(anyString(),any(RowMapper.class))).thenReturn(inputDetailsEntities);
            when(signUpAlertsRepository.findByEcClientId(clientId)).thenReturn(alertsList);
            when(migrationAlertsMapper.checkIfMigratedIgnoredOrRolledBack(ArgumentMatchers.anyLong(),ArgumentMatchers.anyString(),ArgumentMatchers.anyString(),ArgumentMatchers.anyString())).thenReturn(successAlert);
            when(alertMigrationService.insert(any(Alerts.class),any(MigRefAlertMapping.class),anyCollection())).thenReturn(successMigrationAlert);
            AlertsResponse response=alertsService.registerAlerts(jobId,migClient);
            assertNotNull(response);
        } catch (ServiceException e) {
            fail();
        }
    }

    @Test
    void registerAlerts_ThrowsServiceException_WhenAlertsNull()  {
        try {
            List<Alerts> alertsList=new ArrayList<>();
            successAlert.setStatus("SUCCESS");
            migClient.setGwClientId(getClientId);
            when(migRefAlertMappingRepository.findGWMappingDetails()).thenReturn(migRefAlertMappingList);
            when(alertsFASJdbcTemplate.query(anyString(),any(RowMapper.class))).thenReturn(inputDetailsEntities);
            when(signUpAlertsRepository.findByEcClientId(clientId)).thenReturn(alertsList);
            when(migrationAlertsMapper.checkIfMigratedIgnoredOrRolledBack(anyLong(),anyString(),anyString(),anyString())).thenReturn(successAlert);
            when(alertMigrationService.insert(any(Alerts.class),any(MigRefAlertMapping.class),anyCollection())).thenReturn(successMigrationAlert);
            AlertsResponse response=alertsService.registerAlerts(jobId,migClient);
            fail();
        } catch (ServiceException e) {

        }
    }

    @Test
    void process() {
        try {
            List<Alerts> alertsList=new ArrayList<>();
            alertsList.add(alert);

            migClient.setGwClientId(getClientId);

            when(migRefAlertMappingRepository.findGWMappingDetails()).thenReturn(migRefAlertMappingList);
            when(alertsFASJdbcTemplate.query(anyString(),any(RowMapper.class))).thenReturn(inputDetailsEntities);

            when(signUpAlertsRepository.findByEcClientId(clientId)).thenReturn(alertsList);
            when(migrationAlertsMapper.checkIfMigratedIgnoredOrRolledBack(anyLong(),anyString(),anyString(),anyString())).thenReturn(null);
            when(alertMigrationService.insert(any(Alerts.class),any(MigRefAlertMapping.class),anyCollection())).thenReturn(successMigrationAlert);
            alertsService.process(migClient,jobId);
        } catch (ServiceException e) {
            fail();
        }
    }

    @Test
    void processSuccess() {
        try {
            List<Alerts> alertsList=new ArrayList<>();
            alertsList.add(alert);
            successMigrationAlert.setStatus("Success");

            migClient.setGwClientId(getClientId);

            when(migRefAlertMappingRepository.findGWMappingDetails()).thenReturn(migRefAlertMappingList);
            when(alertsFASJdbcTemplate.query(anyString(),any(RowMapper.class))).thenReturn(inputDetailsEntities);

            when(signUpAlertsRepository.findByEcClientId(clientId)).thenReturn(alertsList);
            when(migrationAlertsMapper.checkIfMigratedIgnoredOrRolledBack(anyLong(),anyString(),anyString(),anyString())).thenReturn(null);
            when(alertMigrationService.insert(any(Alerts.class),any(MigRefAlertMapping.class),anyCollection())).thenReturn(successMigrationAlert);
            alertsService.process(migClient,jobId);
        } catch (ServiceException e) {
            fail();
        }
    }

    @Test
    void processSuccessWithJobId() {
        try {
            List<Alerts> alertsList=new ArrayList<>();
            alertsList.add(alert);
            successMigrationAlert.setStatus("Success");
            successMigrationAlert.setJobId(Long.valueOf("123"));

            migClient.setGwClientId(getClientId);

            when(migRefAlertMappingRepository.findGWMappingDetails()).thenReturn(migRefAlertMappingList);
            when(alertsFASJdbcTemplate.query(anyString(),any(RowMapper.class))).thenReturn(inputDetailsEntities);

            when(signUpAlertsRepository.findByEcClientId(clientId)).thenReturn(alertsList);
            when(migrationAlertsMapper.checkIfMigratedIgnoredOrRolledBack(anyLong(),anyString(),anyString(),anyString())).thenReturn(null);
            when(alertMigrationService.insert(any(Alerts.class),any(MigRefAlertMapping.class),anyCollection())).thenReturn(successMigrationAlert);
            alertsService.process(migClient,jobId);
        } catch (ServiceException e) {
            fail();
        }
    }

    @Test
    void processWithServiceException(){
        try {
            List<Alerts> alertsList=new ArrayList<>();
            alertsList.add(alert);
            successAlert.setStatus("Success");

            when(migRefAlertMappingRepository.findGWMappingDetails()).thenReturn(migRefAlertMappingList);
            when(alertsFASJdbcTemplate.query(anyString(),any(RowMapper.class))).thenReturn(inputDetailsEntities);

            when(signUpAlertsRepository.findByEcClientId(clientId)).thenReturn(alertsList);
            when(migrationAlertsMapper.checkIfMigratedIgnoredOrRolledBack(anyLong(),anyString(),anyString(),anyString())).thenReturn(null);
            doThrow(new ServiceException("Internal Server Error")).when(alertMigrationService).insert(any(Alerts.class),any(MigRefAlertMapping.class),anyCollection());
            alertsService.process(migClient,jobId);
        } catch (ServiceException e) {
            fail();
        }
    }

    @Test
    void validate_rollBack_withNoRecordsInTarget(){
       when(alertsFASJdbcTemplate.update(anyString(),anyMap())).thenReturn(0);
       alertsService.rollBackAlerts(clientId,"GWname1234");
    }

    @Test
    void validate_rollBack_withRecordsInTarget(){
        when(alertsFASJdbcTemplate.update(anyString(),anyMap())).thenReturn(2);
        alertsService.rollBackAlerts(clientId,"GWname1234");
    }
}
