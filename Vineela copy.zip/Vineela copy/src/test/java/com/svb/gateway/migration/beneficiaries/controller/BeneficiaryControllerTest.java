package com.svb.gateway.migration.beneficiaries.controller;

import static com.svb.gateway.migration.beneficiaries.entity.StgToTargetBeneEntity.PAYEE_TYPE.*;

import com.svb.gateway.migration.beneficiaries.entity.StgToTargetBeneEntity;
import com.svb.gateway.migration.beneficiaries.model.MigBeneResponse;
import com.svb.gateway.migration.beneficiaries.service.BeneficiariesService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import static org.mockito.ArgumentMatchers.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;


@SpringBootTest
@AutoConfigureMockMvc
public class BeneficiaryControllerTest {

    @MockBean
    private BeneficiariesService beneficiariesService;

    @Autowired
    private MockMvc mockMvc;

    @BeforeEach
    public void setup() throws Exception {
        MigBeneResponse migBeneResponse =new MigBeneResponse();
        Mockito.when(beneficiariesService.addBeneficiaries(any(), any(), any())).thenReturn(migBeneResponse);
    }

    @Test
    public void testAddBeneficiaryTemplateNotFound() throws Exception {

        this.mockMvc.perform(post("/addBeneficiaries/{jobId}/{clientId}/{payeeType}",123, "test","0")
                .contentType(MediaType.APPLICATION_JSON_VALUE)
                .header("Authorization","Basic Y3JtdXNlcjI6QWNjZXNzMTIz"))
                .andExpect(status().isNotFound());
    }

    @Test
    public void testAddBeneficiaryTemplate() throws Exception {

        this.mockMvc.perform(post("/api/beneficiaries/addBeneficiaries/{jobId}/{clientId}/{payeeType}",123, "test1234","0")
                .contentType(MediaType.APPLICATION_JSON_VALUE)
                .header("Authorization","Basic Y3JtdXNlcjI6QWNjZXNzMTIz"))
                .andExpect(status().isOk());
    }

}
