package com.svb.gateway.migration.beneficiaries.service;

import com.svb.gateway.migration.beneficiaries.entity.StgToTargetBeneEntity;
import com.svb.gateway.migration.beneficiaries.model.*;
import com.svb.gateway.migration.common.exception.ServiceException;
import com.svb.gateway.migration.common.service.RetryService;
import com.svb.gateway.migration.common.utility.CacheManagerUtility;
import org.junit.Before;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.web.client.RestClientResponseException;
import org.springframework.web.client.RestTemplate;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

import static com.svb.gateway.migration.beneficiaries.model.ValidationError.ROUTING_NUMBER_INCORRECT;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.fail;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.doThrow;

@SpringBootTest
@ExtendWith(SpringExtension.class)
public class ValidationUtilityTest {
    public static final boolean HAS_DATA = true;
    final String BENEFICIARY_BANK_IDENTIFIER = "asdfasdf1234";

    @Mock
    CacheManagerUtility cacheManagerUtility;

    @Mock
    RestTemplate restTemplate;

    @Mock
    RetryService retryService;

    @InjectMocks
    @Spy
    BeneficiaryValidationUtility validationUtility;

    @Before
    public void setUp(){
    }

    @Test
    public void validateBankBranchAndFetchListOK() throws ServiceException {
        EntityWrapper entityWrapper = setupEntityWrapper();
        List<BankBranchResponseData> responseList = setupBankBranchResponseData();
        ResponseEntity<List<BankBranchResponseData>> bankBranchResponseEntity = new ResponseEntity<List<BankBranchResponseData>>(responseList, HttpStatus.OK);
        doReturn("oauthToken").when(cacheManagerUtility).getOauthToken();
        doReturn(bankBranchResponseEntity).when(retryService).exchange(anyString(), any(HttpMethod.class), any(HttpEntity.class), any(ParameterizedTypeReference.class));
        validationUtility.bankBranchUrl="http://serviceurl/";
        BankBranchResponse bankBranchResponse = validationUtility.validateBankBranchAndFetchList(entityWrapper);

        assertEquals(true, bankBranchResponse.isValidated());
        assertEquals(BENEFICIARY_BANK_IDENTIFIER, bankBranchResponse.getData().get(0).getBankClearingCode());
    }

    @Test
    public void validateBankBranchAndFetchList404() throws ServiceException {
        EntityWrapper entityWrapper = setupEntityWrapper();
        List<BankBranchResponseData> responseList = setupBankBranchResponseData();
        ResponseEntity<List<BankBranchResponseData>> bankBranchResponseEntity = new ResponseEntity<List<BankBranchResponseData>>(responseList, HttpStatus.NOT_FOUND);
        doReturn("oauthToken").when(cacheManagerUtility).getOauthToken();
        doReturn(bankBranchResponseEntity).when(retryService).exchange(anyString(), any(HttpMethod.class), any(HttpEntity.class), any(ParameterizedTypeReference.class));
        validationUtility.bankBranchUrl="http://serviceurl/";
        BankBranchResponse bankBranchResponse = validationUtility.validateBankBranchAndFetchList(entityWrapper);

        assertEquals(false, bankBranchResponse.isValidated());
    }

    @Test
    public void validateBankBranchAndFetchListUnexpectedRestException() throws ServiceException {
        EntityWrapper entityWrapper = setupEntityWrapper();
        List<BankBranchResponseData> responseList = setupBankBranchResponseData();
        doReturn("oauthToken").when(cacheManagerUtility).getOauthToken();
        doThrow(new RestClientResponseException("rest exception", 400, "BAD_REQUEST",null, null, null)).when(retryService).exchange(anyString(), any(HttpMethod.class), any(HttpEntity.class), any(ParameterizedTypeReference.class));
        validationUtility.bankBranchUrl="http://serviceurl/";
        try {
            BankBranchResponse bankBranchResponse = validationUtility.validateBankBranchAndFetchList(entityWrapper);
            assertEquals(false, bankBranchResponse.isValidated());
            assertEquals("get bank branch endpoint rest exception", entityWrapper.getUnexpectedErrorList().get(0).getDescription());
        }
        catch(RestClientResponseException e){
            fail("should not throw exception");
        }
    }

    @Test
    public void validateBankBranchAndFetchListValidationRestException() throws ServiceException {
        EntityWrapper entityWrapper = setupEntityWrapper();
        String responseBody = "{\"status\":{\"message\":[\n" +
                "    {\"message_TYPE\":\"BE\",\n" +
                "     \"nameSpaceInfo\":\"PROD\",\n" +
                "     \"messageDesc\":\"The bank details do not exist.\",\n" +
                "     \"messageCode\":\"103627\"}]\n" +
                "}}";
        doThrow(new RestClientResponseException("rest exception", 400, "BAD_REQUEST",null, responseBody.getBytes(StandardCharsets.UTF_8), null)).when(retryService).exchange(anyString(), any(HttpMethod.class), any(HttpEntity.class), any(ParameterizedTypeReference.class));
        validationUtility.bankBranchUrl="http://serviceurl/";
        try {
            BankBranchResponse bankBranchResponse = validationUtility.validateBankBranchAndFetchList(entityWrapper);
            assertEquals(false, bankBranchResponse.isValidated());
            assertEquals(0, entityWrapper.getUnexpectedErrorList().size());
        }
        catch(RestClientResponseException e){
            fail("should not throw exception");
        }
    }

    @Test
    public void validateBankBranchAndFetchListUnexpectedServiceException() throws ServiceException {
        EntityWrapper entityWrapper = setupEntityWrapper();
        doThrow(new ServiceException("general exception")).when(cacheManagerUtility).getOauthToken();
        validationUtility.bankBranchUrl="http://serviceurl/";
        try {
            BankBranchResponse bankBranchResponse = validationUtility.validateBankBranchAndFetchList(entityWrapper);
            assertEquals(false, bankBranchResponse.isValidated());
            assertEquals("get bank branch endpoint general exception", entityWrapper.getUnexpectedErrorList().get(0).getDescription());
        }
        catch(RestClientResponseException e){
            fail("should not throw exception");
        }
    }

    @Test
    public void validateIbanCountrySpecificRulesAndValidation() throws ServiceException {
        IbanCountryRulesResponse methodResponse = validateIbanCountrySpecificRules(HttpStatus.OK, true, "M", "12", null);
        assertEquals(true, methodResponse.isValidated());
    }

    @Test
    public void validateIbanCountrySpecificRulesAndValidationNotValid1() throws ServiceException {
        IbanCountryRulesResponse methodResponse = validateIbanCountrySpecificRules(HttpStatus.OK, false, "M", "12", null);
        assertEquals(false, methodResponse.isValidated());
    }

    @Test
    public void validateIbanCountrySpecificRulesIbanOptionalAndValid() throws ServiceException {
        IbanCountryRulesResponse methodResponse = validateIbanCountrySpecificRules(HttpStatus.OK, true, "O", "12", null);
        assertEquals(true, methodResponse.isValidated());
    }

    @Test
    public void validateIbanCountrySpecificRulesIbanOptionalAndInvalid() throws ServiceException {
        IbanCountryRulesResponse methodResponse = validateIbanCountrySpecificRules(HttpStatus.OK, false, "O", "12", null);
        assertEquals(false, methodResponse.isValidated());
    }

    @Test
    public void validateIbanCountrySpecificRulesIbanOptionalButNotMatchingCountryCode() throws ServiceException {
        IbanCountryRulesResponse methodResponse = validateIbanCountrySpecificRules(HttpStatus.OK, false, "O", "89", null);
        assertEquals(true, methodResponse.isValidated());
    }

    @Test
    public void validateIbanCountrySpecificRulesMandatory() throws ServiceException {
        BeneBankInfoRule beneBankInfoRule = new BeneBankInfoRule();
        beneBankInfoRule.setLocalRoutingCodeRequired("M");
        IbanCountryRulesResponse methodResponse = validateIbanCountrySpecificRules(HttpStatus.OK, false, "NA", "89", beneBankInfoRule);
        assertEquals(false, methodResponse.isValidated());
    }

    @Test
    public void validateIbanCountryIbanNotRequired() throws ServiceException {
        IbanCountryRulesResponse methodResponse = validateIbanCountrySpecificRules(HttpStatus.OK, false, "NA", "89", null);
        assertEquals(true, methodResponse.isValidated());
    }

    @Test
    public void validateIbanCountryHTTPError() throws ServiceException {
        IbanCountryRulesResponse methodResponse = validateIbanCountrySpecificRules(HttpStatus.BAD_GATEWAY, false, "NA", "89", null);
        assertEquals(false, methodResponse.isValidated());
    }

    @Test
    public void validateIbanCountryException() throws ServiceException {
        EntityWrapper entityWrapper = setupEntityWrapper();
        validationUtility.ibanRuleUrl="http://serviceurl/";

        doThrow(new RestClientResponseException("rest exception", 400, "BAD_REQUEST",null, null, null)).when(retryService).exchange(anyString(), any(HttpMethod.class), any(HttpEntity.class), any(ParameterizedTypeReference.class));
        try {
            IbanCountryRulesResponse methodResponse = validationUtility.validateIbanCountrySpecificRulesAndValidation(entityWrapper, "US", 1L, "abcd1234");
            assertEquals(false, methodResponse.isValidated());
            assertEquals("Payment validation rules endpoint for IBAN country rest exception", entityWrapper.getUnexpectedErrorList().get(0).getDescription());
        }
        catch(RestClientResponseException e){
            fail("should not throw exception");
        }
    }

    private IbanCountryRulesResponse validateIbanCountrySpecificRules(HttpStatus httpStatus, boolean isIbanValid, String ibanRequired, String ibanISOCountryCode, BeneBankInfoRule beneBankInfoRule) throws ServiceException {
        EntityWrapper entityWrapper = setupEntityWrapper();
        IbanCountryRulesResponse ibanCountryRulesResponse = new IbanCountryRulesResponse();
        IbanCountryRulesResponseData data = new IbanCountryRulesResponseData();
        BeneIbanAccountRule beneficaryAccount = new BeneIbanAccountRule();
        beneficaryAccount.setIbanRequired(ibanRequired);
        IbanFormatRule iban = new IbanFormatRule();
        // bene account is "12345678", comparing the first 2 chars
        iban.setIbanISOCountryCode(ibanISOCountryCode);
        beneficaryAccount.setIban(iban);
        data.setBeneficaryAccount(beneficaryAccount);
        data.setBeneficiaryBankInfo(beneBankInfoRule);
        ibanCountryRulesResponse.setData(data);
        ResponseEntity<IbanCountryRulesResponse> bankBranchResponseEntity = new ResponseEntity<IbanCountryRulesResponse>(ibanCountryRulesResponse, httpStatus);
        doReturn(bankBranchResponseEntity).when(retryService).exchange(anyString(), any(HttpMethod.class), any(HttpEntity.class), any(ParameterizedTypeReference.class));
        IbanValidationResponse ibanValidationResponse = new IbanValidationResponse();
        ibanValidationResponse.setValidated(isIbanValid);
        doReturn(ibanValidationResponse).when(validationUtility).validateIBAN(any(), any());
        validationUtility.ibanRuleUrl="http://serviceurl/";

        IbanCountryRulesResponse methodResponse = validationUtility.validateIbanCountrySpecificRulesAndValidation(entityWrapper, "US", 1L, "abcd1234");
        return methodResponse;
    }

    @Test
    public void validateIBAN()throws ServiceException {
        IbanValidationResponse methodResponse = validateIbanRules(HttpStatus.OK, "0", "asdfasdf90", HAS_DATA);
        assertEquals(true, methodResponse.isValidated());
    }

    @Test
    public void validateIBANWithWarning()throws ServiceException {
        IbanValidationResponse methodResponse = validateIbanRules(HttpStatus.OK, "2", "asdfasdf90", HAS_DATA);
        assertEquals(true, methodResponse.isValidated());
    }

    @Test
    public void validateIBANWrongSwift()throws ServiceException {
        IbanValidationResponse methodResponse = validateIbanRules(HttpStatus.OK, "0", "XXXfasdf90", HAS_DATA);
        assertEquals(false, methodResponse.isValidated());
    }

    @Test
    public void validateIBANWrongCode()throws ServiceException {
        IbanValidationResponse methodResponse = validateIbanRules(HttpStatus.OK, "1", "asdfasdf90", HAS_DATA);
        assertEquals(false, methodResponse.isValidated());
    }

    @Test
    public void validateIBANMissingData()throws ServiceException {
        IbanValidationResponse methodResponse = validateIbanRules(HttpStatus.OK, "0", "asdfasdf90", !HAS_DATA);
        assertEquals(false, methodResponse.isValidated());
    }

    @Test
    public void validateIBANHTTPErrorCode()throws ServiceException {
        IbanValidationResponse methodResponse = validateIbanRules(HttpStatus.BAD_GATEWAY, "0", "asdfasdf90", !HAS_DATA);
        assertEquals(false, methodResponse.isValidated());
    }

    @Test
    public void validateIBANHTTPException() {
        EntityWrapper entityWrapper = setupEntityWrapper();
        validationUtility.ibanValidationUrl="http://serviceurl/";
        doThrow(new RestClientResponseException("rest exception", 400, "BAD_REQUEST",null, null, null)).when(retryService).exchange(anyString(), any(HttpMethod.class), any(HttpEntity.class), any(ParameterizedTypeReference.class));
        try {
            IbanValidationResponse methodResponse = validationUtility.validateIBAN(entityWrapper,  "abcd1234");
            assertEquals(false, methodResponse.isValidated());
            assertEquals("Payment validation rules endpoint for IBAN country rest exception", entityWrapper.getUnexpectedErrorList().get(0).getDescription());
        }
        catch(RestClientResponseException e){
            fail("should not throw exception");
        }
    }

    private IbanValidationResponse validateIbanRules(HttpStatus httpStatus, String code, String swiftBic, boolean hasData) throws ServiceException {
        EntityWrapper entityWrapper = setupEntityWrapper();
        IbanValidationResponse ibanValidationResponse = new IbanValidationResponse();
        IbanValidationResponseData data = new IbanValidationResponseData();
        InstitutionDetails institutionDetails = new InstitutionDetails();
        institutionDetails.setSwiftBIC(swiftBic);
        data.setInstitutionDetails(institutionDetails);
        ResponseCode responseCode = new ResponseCode();
        responseCode.setCode(code);
        data.setResponseCode(responseCode);
        ibanValidationResponse.setData(hasData?data:null);
        ResponseEntity<IbanValidationResponse> bankBranchResponseEntity = new ResponseEntity<IbanValidationResponse>(ibanValidationResponse, httpStatus);
        doReturn(bankBranchResponseEntity).when(retryService).exchange(anyString(), any(HttpMethod.class), any(HttpEntity.class), any(ParameterizedTypeReference.class));

        validationUtility.ibanValidationUrl="http://serviceurl/";

        IbanValidationResponse methodResponse = validationUtility.validateIBAN(entityWrapper,  "abcd1234");
        return methodResponse;
    }

    @Test
    public void validateReachabilityCheck()throws ServiceException {
        ReachabilityCheckResponse methodResponse = reachabilityCheck(HttpStatus.OK, HAS_DATA);
        assertEquals(true, methodResponse.isValidated());
    }

    @Test
    public void validateReachabilityCheckNoDetails()throws ServiceException {
        ReachabilityCheckResponse methodResponse = reachabilityCheck(HttpStatus.OK, !HAS_DATA);
        assertEquals(false, methodResponse.isValidated());
    }

    @Test
    public void validateReachabilityBadHTTPStatus()throws ServiceException {
        ReachabilityCheckResponse methodResponse = reachabilityCheck(HttpStatus.BAD_GATEWAY, HAS_DATA);
        assertEquals(false, methodResponse.isValidated());
    }

    @Test
    public void validateReachabilityException()throws ServiceException{
        EntityWrapper entityWrapper = setupEntityWrapper();
        doReturn("oauthToken").when(cacheManagerUtility).getOauthToken();
        validationUtility.reachabilityUrl="http://serviceurl/";
        doThrow(new RestClientResponseException("rest exception", 400, "BAD_REQUEST",null, null, null)).when(restTemplate).exchange(anyString(), any(HttpMethod.class), any(HttpEntity.class), any(ParameterizedTypeReference.class));
        try {
            ReachabilityCheckResponse methodResponse = validationUtility.reachabilityCheck(entityWrapper, "Gw12341234234");
            assertEquals(false, methodResponse.isValidated());
            assertEquals(ROUTING_NUMBER_INCORRECT, entityWrapper.getValidationErrorList().get(0).getDescription());
        }
        catch(RestClientResponseException e){
            fail("should not throw exception");
        }
    }

    private ReachabilityCheckResponse reachabilityCheck(HttpStatus httpStatus, boolean hasData) throws ServiceException {
        EntityWrapper entityWrapper = setupEntityWrapper();
        ReachabilityCheckResponseData reachabilityCheckResponseData = new ReachabilityCheckResponseData();
        List<ClearingSystemDetail> clearingSystemDetails = new ArrayList<>();
        if (hasData){
            ClearingSystemDetail clearingSystemDetail = new ClearingSystemDetail();
            clearingSystemDetail.setClearingSystem("clearingSystem");
            clearingSystemDetails.add(clearingSystemDetail);
        }
        reachabilityCheckResponseData.setClearingSystemDetails(clearingSystemDetails);
        ResponseEntity<ReachabilityCheckResponseData> reachabilityCheckResponseEntity = new ResponseEntity<>(reachabilityCheckResponseData, httpStatus);
        doReturn("oauthToken").when(cacheManagerUtility).getOauthToken();
        doReturn(reachabilityCheckResponseEntity).when(restTemplate).exchange(anyString(), any(HttpMethod.class), any(HttpEntity.class), any(ParameterizedTypeReference.class));

        validationUtility.reachabilityUrl="http://serviceurl/";

        ReachabilityCheckResponse methodResponse = validationUtility.reachabilityCheck(entityWrapper,  "Gw12341234234");
        return methodResponse;
    }

    private List<BankBranchResponseData> setupBankBranchResponseData() {
        List<BankBranchResponseData> responseList = new ArrayList<>();
        BankBranchResponseData bankBranchResponseData = new BankBranchResponseData();
        bankBranchResponseData.setBankClearingCode(BENEFICIARY_BANK_IDENTIFIER);
        responseList.add(bankBranchResponseData);
        return responseList;
    }

    private EntityWrapper setupEntityWrapper() {
        StgToTargetBeneEntity stgToTargetBeneEntity = new StgToTargetBeneEntity();
        stgToTargetBeneEntity.setOLB_CLIENT_ID("medi4798");
        stgToTargetBeneEntity.setTEMPLATE_ID(1234);
        stgToTargetBeneEntity.setBENEFICIARY_ACCOUNT("12345678");
        stgToTargetBeneEntity.setELECTRONIC_INDICATOR("Y");
        stgToTargetBeneEntity.setJOB_ID(1L);
        stgToTargetBeneEntity.setBENEFICIARY_BANK_IDENTIFIER(BENEFICIARY_BANK_IDENTIFIER);
        EntityWrapper entityWrapper =new EntityWrapper(stgToTargetBeneEntity);
        return entityWrapper;
    }
}
