package com.svb.gateway.migration.client.service;

import com.svb.gateway.migration.client.entity.MigClient;
import com.svb.gateway.migration.client.entity.StgClient;
import com.svb.gateway.migration.client.model.*;
import com.svb.gateway.migration.client.repository.ClientRepository;
import com.svb.gateway.migration.client.repository.MigClientRepository;
import com.svb.gateway.migration.common.constants.MigrationConstants;
import com.svb.gateway.migration.common.constants.UserConstants;
import com.svb.gateway.migration.common.exception.ServiceException;
import com.svb.gateway.migration.common.model.Error;
import com.svb.gateway.migration.common.utility.CacheManagerUtility;
import com.svb.gateway.migration.common.utility.EntityLogUtility;
import com.svb.gateway.migration.job.entity.ClientEntity;
import com.svb.gateway.migration.job.mapper.ClientMapper;
import com.svb.gateway.migration.user.entity.MigUser;
import com.svb.gateway.migration.user.entity.StgUser;
import com.svb.gateway.migration.user.mapper.UserMapper;
import com.svb.gateway.migration.user.repository.MigUserRepository;
import com.svb.gateway.migration.user.repository.UserRepository;
import org.junit.Assert;
import org.junit.Ignore;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.*;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.*;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;

import static com.svb.gateway.migration.common.constants.MigrationConstants.BDC_NAME;
import static junit.framework.TestCase.assertEquals;
import static junit.framework.TestCase.assertTrue;
import static org.junit.Assert.*;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.*;

@SpringBootTest
@ExtendWith(SpringExtension.class)
public class ClientServiceTest {

    public static String clientId;
    public static String oAuth;
    public static String companyId;
    @Mock
    CacheManagerUtility cacheManagerUtility;
    String migCorelationId = "migCorelationId";
    Integer migStartupBankingBundle = 15;

    @Mock
    StgClient stgClient;
    @Mock
    ClientRepository clientRepository;
    @Mock
    MigClientRepository migClientRepository;

    @Mock
    MigUserRepository migUserRepository;

    @Mock
    EntityLogUtility entityLogUtility;
    @Mock
    UserRepository userRepository;
    @Mock
    Cifs cifsInfo;
    @Mock
    EnrollClientResponse clientEnrolled;
    @Mock
    RestTemplate restTemplate;
    @Mock
    EnrollClientRequest request;
    @Mock
    List<com.svb.gateway.migration.user.entity.StgUser> users;
    @Mock
    ClientMapper clientMapper;
    @Mock
    UserMapper userMapper;

    @Mock
    ClientExtensionService clientExtensionService;
    @InjectMocks
    @Spy
    ClientService clientService;

    @BeforeAll
    public static void setUp() {

        clientId = "addr9768";
        companyId = "SVB";

    }

    @BeforeEach
    public void before() {
        doNothing().when(clientMapper).updateClient(ArgumentMatchers.any());
        when(clientRepository.findByOlbClinetId(ArgumentMatchers.any())).thenReturn(stgClient);

        // doReturn(clientEntity).when(clientMapper).getClient(ArgumentMatchers.any(), ArgumentMatchers.any());
    }

    @Test
    public void enrollClient_alreadySuccessfullyMigrated() throws Exception {
        MigClient mg = new MigClient();
        mg.setStatus(MigrationConstants.STATUS_SUCCESS);
        when(migClientRepository.findByEcClientIdAndJobId(ArgumentMatchers.any(), ArgumentMatchers.any())).thenReturn(mg);
        EnrollClientResponse actClientEnrolled = clientService.enrollClient(companyId, clientId, 1L);
        assertEquals("SUCCESS", actClientEnrolled.getData().getStatus());
    }

    @Test
    public void enrollClient_alreadyMigratedAndIgnored() throws Exception {
        MigClient mg = new MigClient();
        mg.setGwClientId("GWa1234");
        mg.setStatus(MigrationConstants.STATUS_IGNORE);
        mg.setCompanyId(companyId);
        when(migClientRepository.findByEcClientIdAndJobId(ArgumentMatchers.any(), ArgumentMatchers.any())).thenReturn(mg);
        // doReturn(clientEntity).when(clientMapper).getClient(ArgumentMatchers.any(), ArgumentMatchers.any());
        EnrollClientResponse actClientEnrolled = clientService.enrollClient(companyId, clientId, 1L);
        assertEquals("IGNORE", actClientEnrolled.getData().getStatus());
    }

    @Test
    public void enrollClient_success() throws Exception {
        when(clientRepository.findByOlbClinetId(clientId)).thenReturn(stgClient);
        doReturn("123").when(stgClient).getJobId();
        clientService.lastLoginMonthThreshold= 18;
        StgUser u = new StgUser();
        u.setPrimaryUser(true);
        u.setStatus("1");
        u.setLastLoginDate(LocalDate.now());
        List<StgUser> users = new ArrayList<>();
        users.add(u);

        when(userRepository.findByOlbClientId(clientId)).thenReturn(users);
        when(userRepository.findBYOlbClntId(clientId)).thenReturn(users);
        oAuth = "e2561beef23920c18902ada758a1118de96be728add38b1a04acb2d911845352";
        when(cacheManagerUtility.getOauthToken()).thenReturn(oAuth);
        when(stgClient.getPrimaryCifUbs()).thenReturn("200030009");

        Cifs cifListRequest = new Cifs();
        Cif cif = new Cif();
        cif.setCifNumber(stgClient.getPrimaryCifUbs());

        List<Cif> cifs = new ArrayList<>();
        List<AccountServices> cifaccounts = new ArrayList<>();
        AccountServices as = new AccountServices();
        List<SvbService> accServ = new ArrayList<>();
        SvbService ss = new SvbService();


        List<ServiceTransaction> serviceTxns = new ArrayList<>();
        ServiceTransaction sTxn = new ServiceTransaction();
        sTxn.setSvcTxnId("svcTxnId");
        serviceTxns.add(sTxn);
        ss.setServiceTxn(serviceTxns);
        accServ.add(ss);
        as.setAccServ(accServ);
        as.setAccStat("Y");
        as.setAccountNum("accNum");
        cifaccounts.add(as);
        cif.setCifAccounts(cifaccounts);
        cifs.add(cif);
        cifListRequest.setCifData(cifs);
        doReturn(cifListRequest).when(clientService).getCifAccountInfo(any(), any(), any(), any() );

        Bundles bundles = new Bundles();
        List<Bundle> digitalBundles = new ArrayList<>();
        Bundle b = new Bundle();
        List<BundleServices> services = new ArrayList<>();
        BundleServices bs = new BundleServices();
        SvbService service = new SvbService();
        List<ServiceTransaction> serviceTxn = new ArrayList<>();
        service.setServiceId("sId");
        service.setServiceName("sName");
        ServiceTransaction st = new ServiceTransaction();
        st.setAcctSpecificTxn("Y");
        st.setOperation("Credit");
        st.setSvcTxnId("svcTxnId");

        serviceTxn.add(st);

        service.setServiceTxn(serviceTxn);
        bs.setService(service);
        services.add(bs);
        b.setServices(services);
        b.setDigitalBundleId(15);
        digitalBundles.add(b);
        bundles.setDigitalBundles(digitalBundles);
        doReturn(bundles).when(clientService).getBundles(any(), any(), any());

        List<AccountServices> cifAccounts = new ArrayList<>();
        AccountServices accountServices = new AccountServices();
        accountServices.setAccCcy("accCcy");
        accountServices.setAccName("accName");
        accountServices.setAccountNum("1234567890");
        accountServices.setAccountTyp("CC");
        accountServices.setAccStat("stat");
        accountServices.setProdCode("prodCode");
        accountServices.setAccServ(accServ);
        cifAccounts.add(accountServices);

        List<Cif> cifData = new ArrayList<>();
        Cif c = new Cif();
        c.setUbsCifNum("200030009");
        c.setCbsCifNum("200030009");
        c.setCifAccounts(cifAccounts);
        cifData.add(c);
        when(cifsInfo.getCifData()).thenReturn(cifData);
        cifListRequest.setCifData(cifData);

        clientService.migStartupBankingBundle = 15;

        EnrollClientResponse clientEnrolled = new EnrollClientResponse();
        EnrollClientResponseData data = new EnrollClientResponseData();
        data.setGwPrimaryUserId("pUserId");
        data.setGwClientId("geClientId");
        data.setStatus("success");
        clientEnrolled.setData(data);

        doReturn(clientEnrolled).when(clientService).createClient(any(), any(),any(), any());

        doNothing().when(entityLogUtility).saveEntityCountAndTimeLog(Mockito.any());
        doReturn(1).when(userMapper).insertMigratingUser(Mockito.any(MigUser.class));
        //doNothing().when(clientMapper).updateClient(Mockito.any(MigClient.class));

        EnrollClientResponse actClientEnrolled = clientService.enrollClient(companyId, clientId, 1L);

        assertEquals(clientEnrolled, actClientEnrolled);

        System.out.println("client updated successfully");

    }

    @Test
    public void enrollClient_fail() throws Exception {
        when(clientRepository.findByOlbClinetId(clientId)).thenReturn(stgClient);
        doReturn("123").when(stgClient).getJobId();
        clientService.lastLoginMonthThreshold = 18;
        StgUser u = new StgUser();
        u.setPrimaryUser(true);
        u.setStatus("1");
        u.setLastLoginDate(LocalDate.now());
        List<StgUser> users = new ArrayList<>();
        users.add(u);

        when(userRepository.findByOlbClientId(clientId)).thenReturn(users);
        when(userRepository.findBYOlbClntId(clientId)).thenReturn(users);
        oAuth = "e2561beef23920c18902ada758a1118de96be728add38b1a04acb2d911845352";
        when(cacheManagerUtility.getOauthToken()).thenReturn(oAuth);
        when(stgClient.getPrimaryCifUbs()).thenReturn("200030009");

        Cifs cifListRequest = new Cifs();
        Cif cif = new Cif();
        cif.setCifNumber(stgClient.getPrimaryCifUbs());

        List<Cif> cifs = new ArrayList<>();
        List<AccountServices> cifaccounts = new ArrayList<>();
        AccountServices as = new AccountServices();
        List<SvbService> accServ = new ArrayList<>();
        SvbService ss = new SvbService();


        List<ServiceTransaction> serviceTxns = new ArrayList<>();
        ServiceTransaction sTxn = new ServiceTransaction();
        sTxn.setSvcTxnId("svcTxnId");
        serviceTxns.add(sTxn);
        ss.setServiceTxn(serviceTxns);
        accServ.add(ss);
        as.setAccServ(accServ);
        as.setAccStat("Y");
        as.setAccountNum("accNum");
        cifaccounts.add(as);
        cif.setCifAccounts(cifaccounts);
        cifs.add(cif);
        cifListRequest.setCifData(cifs);
        doReturn(cifListRequest).when(clientService).getCifAccountInfo(any(), any(), any(), any());

        Bundles bundles = new Bundles();
        List<Bundle> digitalBundles = new ArrayList<>();
        Bundle b = new Bundle();
        List<BundleServices> services = new ArrayList<>();
        BundleServices bs = new BundleServices();
        SvbService service = new SvbService();
        List<ServiceTransaction> serviceTxn = new ArrayList<>();
        service.setServiceId("sId");
        service.setServiceName("sName");
        ServiceTransaction st = new ServiceTransaction();
        st.setAcctSpecificTxn("Y");
        st.setOperation("Credit");
        st.setSvcTxnId("svcTxnId");

        serviceTxn.add(st);

        service.setServiceTxn(serviceTxn);
        bs.setService(service);
        services.add(bs);
        b.setServices(services);
        b.setDigitalBundleId(15);
        digitalBundles.add(b);
        bundles.setDigitalBundles(digitalBundles);
        doReturn(bundles).when(clientService).getBundles(any(), any(), any());

        List<AccountServices> cifAccounts = new ArrayList<>();
        AccountServices accountServices = new AccountServices();
        accountServices.setAccCcy("accCcy");
        accountServices.setAccName("accName");
        accountServices.setAccountNum("1234567890");
        accountServices.setAccountTyp("CC");
        accountServices.setAccStat("stat");
        accountServices.setProdCode("prodCode");
        accountServices.setAccServ(accServ);
        cifAccounts.add(accountServices);

        List<Cif> cifData = new ArrayList<>();
        Cif c = new Cif();
        c.setUbsCifNum("200030009");
        c.setCbsCifNum("200030009");
        c.setCifAccounts(cifAccounts);
        cifData.add(c);
        when(cifsInfo.getCifData()).thenReturn(cifData);
        cifListRequest.setCifData(cifData);

        clientService.migStartupBankingBundle = 15;

        EnrollClientResponse clientEnrolled = new EnrollClientResponse();
        EnrollClientResponseData data = new EnrollClientResponseData();
        data.setGwPrimaryUserId("pUserId");
        data.setGwClientId("geClientId");
        Error e = new Error("0000", UserConstants.ADD_USER_FAILED);
        clientEnrolled.setErrors(List.of(e));
        data.setStatus(MigrationConstants.STATUS_FAILURE);
        clientEnrolled.setData(data);

        doReturn(clientEnrolled).when(clientService).createClient(any(), any(),any(), any());

        doNothing().when(entityLogUtility).saveEntityCountAndTimeLog(Mockito.any());
        doReturn(1).when(userMapper).insertMigratingUser(Mockito.any(MigUser.class));
        doReturn(null).when(migClientRepository).findByEcClientIdAndJobId(Mockito.anyString(),Mockito.any());
        doReturn(null).when(migClientRepository).save(Mockito.any());

        EnrollClientResponse actClientEnrolled = clientService.enrollClient(companyId, clientId, 1L);

        assertEquals(clientEnrolled, actClientEnrolled);

        System.out.println("client updated successfully");

    }

    @Test
    public void enrollClient_mig_client_error() throws Exception {
        when(clientRepository.findByOlbClinetId(clientId)).thenReturn(stgClient);
        doReturn("123").when(stgClient).getJobId();
        StgUser u = new StgUser();
        u.setPrimaryUser(true);
        u.setStatus("0");
        List<StgUser> users = new ArrayList<>();
        users.add(u);

        when(userRepository.findByOlbClientId(clientId)).thenReturn(users);
        when(userRepository.findBYOlbClntId(clientId)).thenReturn(users);
        oAuth = "e2561beef23920c18902ada758a1118de96be728add38b1a04acb2d911845352";
        when(cacheManagerUtility.getOauthToken()).thenReturn(oAuth);
        when(stgClient.getPrimaryCifUbs()).thenReturn("200030009");

        Cifs cifListRequest = new Cifs();
        Cif cif = new Cif();
        cif.setCifNumber(stgClient.getPrimaryCifUbs());

        List<Cif> cifs = new ArrayList<>();
        List<AccountServices> cifaccounts = new ArrayList<>();
        AccountServices as = new AccountServices();
        List<SvbService> accServ = new ArrayList<>();
        SvbService ss = new SvbService();


        List<ServiceTransaction> serviceTxns = new ArrayList<>();
        ServiceTransaction sTxn = new ServiceTransaction();
        sTxn.setSvcTxnId("svcTxnId");
        serviceTxns.add(sTxn);
        ss.setServiceTxn(serviceTxns);
        accServ.add(ss);
        as.setAccServ(accServ);
        as.setAccStat("Y");
        as.setAccountNum("accNum");
        cifaccounts.add(as);
        cif.setCifAccounts(cifaccounts);
        cifs.add(cif);
        cifListRequest.setCifData(cifs);
        doReturn(cifListRequest).when(clientService).getCifAccountInfo(any(), any(), any(), any());

        Bundles bundles = new Bundles();
        List<Bundle> digitalBundles = new ArrayList<>();
        Bundle b = new Bundle();
        List<BundleServices> services = new ArrayList<>();
        BundleServices bs = new BundleServices();
        SvbService service = new SvbService();
        List<ServiceTransaction> serviceTxn = new ArrayList<>();
        service.setServiceId("sId");
        service.setServiceName("sName");
        ServiceTransaction st = new ServiceTransaction();
        st.setAcctSpecificTxn("Y");
        st.setOperation("Credit");
        st.setSvcTxnId("svcTxnId");

        serviceTxn.add(st);

        service.setServiceTxn(serviceTxn);
        bs.setService(service);
        services.add(bs);
        b.setServices(services);
        b.setDigitalBundleId(15);
        digitalBundles.add(b);
        bundles.setDigitalBundles(digitalBundles);
        doReturn(bundles).when(clientService).getBundles(any(), any(), any());

        List<AccountServices> cifAccounts = new ArrayList<>();
        AccountServices accountServices = new AccountServices();
        accountServices.setAccCcy("accCcy");
        accountServices.setAccName("accName");
        accountServices.setAccountNum("1234567890");
        accountServices.setAccountTyp("CC");
        accountServices.setAccStat("stat");
        accountServices.setProdCode("prodCode");
        accountServices.setAccServ(accServ);
        cifAccounts.add(accountServices);

        List<Cif> cifData = new ArrayList<>();
        Cif c = new Cif();
        c.setUbsCifNum("200030009");
        c.setCifAccounts(cifAccounts);
        cifData.add(c);
        when(cifsInfo.getCifData()).thenReturn(cifData);
        cifListRequest.setCifData(cifData);

        clientService.migStartupBankingBundle = 15;
        doReturn(clientEnrolled).when(clientService).createClient(any(), any(),any(), any());

        doNothing().when(clientMapper).updateClient(Mockito.any(MigClient.class));

        Exception exception = assertThrows(ServiceException.class, () -> {
            clientService.enrollClient(companyId, clientId, 1L);
        });

        String expectedMessage = "Client updating Errored. Not added in Mig Client";
        String actualMessage = exception.getMessage();

        assertTrue(actualMessage.contains(expectedMessage));

    }

    @Test
    public void enrollClient_acc_error() throws Exception {
        when(clientRepository.findByOlbClinetId(clientId)).thenReturn(stgClient);

        StgUser u = new StgUser();
        u.setPrimaryUser(true);
        List<StgUser> users = new ArrayList<>();
        users.add(u);

        when(userRepository.findByOlbClientId(clientId)).thenReturn(users);
        when(userRepository.findBYOlbClntId(clientId)).thenReturn(users);
        oAuth = "e2561beef23920c18902ada758a1118de96be728add38b1a04acb2d911845352";
        when(cacheManagerUtility.getOauthToken()).thenReturn(oAuth);
        when(stgClient.getPrimaryCifUbs()).thenReturn("200030009");

        Cifs cifListRequest = new Cifs();
        Cif cif = new Cif();
        cif.setCifNumber(stgClient.getPrimaryCifUbs());

        List<Cif> cifs = new ArrayList<>();
        List<AccountServices> cifaccounts = new ArrayList<>();
        AccountServices as = new AccountServices();
        List<SvbService> accServ = new ArrayList<>();
        SvbService ss = new SvbService();


        List<ServiceTransaction> serviceTxns = new ArrayList<>();
        ServiceTransaction sTxn = new ServiceTransaction();
        sTxn.setSvcTxnId("svcTxnId");
        serviceTxns.add(sTxn);
        ss.setServiceTxn(serviceTxns);
        accServ.add(ss);
        as.setAccServ(accServ);
        as.setAccountNum("accNum");
        cifaccounts.add(as);
        cif.setCifAccounts(cifaccounts);
        cifs.add(cif);
        cifListRequest.setCifData(cifs);
        doReturn(cifListRequest).when(clientService).getCifAccountInfo(any(), any(), any(), any());

        Bundles bundles = new Bundles();
        List<Bundle> digitalBundles = new ArrayList<>();
        Bundle b = new Bundle();
        List<BundleServices> services = new ArrayList<>();
        BundleServices bs = new BundleServices();
        SvbService service = new SvbService();
        List<ServiceTransaction> serviceTxn = new ArrayList<>();
        service.setServiceId("sId");
        service.setServiceName("sName");
        ServiceTransaction st = new ServiceTransaction();
        st.setAcctSpecificTxn("Y");
        st.setOperation("Credit");
        st.setSvcTxnId("svcTxnId");

        serviceTxn.add(st);

        service.setServiceTxn(serviceTxn);
        bs.setService(service);
        services.add(bs);
        b.setServices(services);
        b.setDigitalBundleId(15);
        digitalBundles.add(b);
        bundles.setDigitalBundles(digitalBundles);
        doReturn(bundles).when(clientService).getBundles(any(), any(), any());

        List<AccountServices> cifAccounts = new ArrayList<>();
        AccountServices accountServices = new AccountServices();
        accountServices.setAccCcy("accCcy");
        accountServices.setAccName("accName");
        accountServices.setAccountNum("1234567890");
        accountServices.setAccountTyp("CC");
        //accountServices.setAccStat("stat");
        accountServices.setProdCode("prodCode");
        accountServices.setAccServ(accServ);
        cifAccounts.add(accountServices);

        List<Cif> cifData = new ArrayList<>();
        Cif c = new Cif();
        c.setUbsCifNum("200030009");
        c.setCifAccounts(cifAccounts);
        cifData.add(c);
        when(cifsInfo.getCifData()).thenReturn(cifData);
        cifListRequest.setCifData(cifData);

        clientService.migStartupBankingBundle = 15;
        doReturn(clientEnrolled).when(clientService).createClient(any(), any(),any(), any());

        doNothing().when(entityLogUtility).saveEntityCountAndTimeLog(Mockito.any());

        Exception exception = assertThrows(ServiceException.class, () -> {
            clientService.enrollClient(companyId, clientId, 1L);
        });

        String expectedMessage = "cifData.getAccStat is null";
        String actualMessage = exception.getMessage();

        assertTrue(actualMessage.contains(expectedMessage));

    }

    @Ignore
    public void enrollClient_success_2() throws Exception {
        stgClient.setJobId("123");
        when(clientRepository.findByOlbClinetId(clientId)).thenReturn(stgClient);
        doReturn("123").when(stgClient).getJobId();
        StgUser u = new StgUser();
        u.setPrimaryUser(true);
        u.setLastLoginDate( LocalDate.now());
        List<StgUser> users = new ArrayList<>();
        users.add(u);
        clientService.lastLoginMonthThreshold = 18;

        when(userRepository.findByOlbClientId(Matchers.any())).thenReturn(users);
        when(userRepository.findBYOlbClntId(Matchers.any())).thenReturn(users);
        oAuth="e2561beef23920c18902ada758a1118de96be728add38b1a04acb2d911845352";
        when(cacheManagerUtility.getOauthToken()).thenReturn(oAuth);
        when(stgClient.getPrimaryCifUbs()).thenReturn("200030009");

        Cifs cifListRequest = new Cifs();
        Cif cif = new Cif();
        cif.setCifNumber(stgClient.getPrimaryCifUbs());

        List<Cif> cifs = new ArrayList<>();
        List<AccountServices> cifaccounts = new ArrayList<>();
        AccountServices as = new AccountServices();
        List<SvbService> accServ = new ArrayList<>();
        SvbService ss = new SvbService();

        List<ServiceTransaction> serviceTxns = new ArrayList<>();
        ServiceTransaction sTxn = new ServiceTransaction();
        sTxn.setSvcTxnId("svcTxnId");
        serviceTxns.add(sTxn);
        ss.setServiceTxn(serviceTxns);
        accServ.add(ss);
        as.setAccServ(accServ);
        as.setAccountNum("accNum");
        cifs.add(cif);
        cifListRequest.setCifData(cifs);
        doReturn(cifListRequest).when(clientService).getCifAccountInfo(any(), any(), any(), any());

        Bundles bundles = new Bundles();
        List<Bundle> digitalBundles = new ArrayList<>();
        Bundle b = new Bundle();
        List<BundleServices> services = new ArrayList<>();
        BundleServices bs = new BundleServices();
        SvbService service = new SvbService();
        List<ServiceTransaction> serviceTxn = new ArrayList<>();
        service.setServiceId("sId");
        service.setServiceName("sName");
        ServiceTransaction st = new ServiceTransaction();
        st.setAcctSpecificTxn("N");
        st.setOperation("Credit");
        st.setSvcTxnId("svcTxnId");
        ServiceTransaction st1 = new ServiceTransaction();
        st1.setAcctSpecificTxn("N");
        st1.setOperation("Credit");
        st1.setSvcTxnId("svcTxnId1");
        ServiceTransaction st2 = new ServiceTransaction();
        st1.setAcctSpecificTxn("N");
        st2.setOperation("Credit");
        st2.setSvcTxnId("svcTxnId2");

        serviceTxn.add(st);
        serviceTxn.add(st1);
        serviceTxn.add(st2);

        service.setServiceTxn(serviceTxn);
        bs.setService(service);
        services.add(bs);
        b.setServices(services);
        b.setDigitalBundleId(15);
        digitalBundles.add(b);
        bundles.setDigitalBundles(digitalBundles);
        doReturn(bundles).when(clientService).getBundles(any(), any(), any());

        List<AccountServices> cifAccounts = new ArrayList<>();
        AccountServices accountServices = new AccountServices();
        accountServices.setAccCcy("accCcy");
        accountServices.setAccName("accName");
        accountServices.setAccountNum("1234567890");
        accountServices.setAccountTyp("CC");
        accountServices.setAccStat("stat");
        accountServices.setProdCode("prodCode");
        accountServices.setAccServ(accServ);
        cifAccounts.add(accountServices);

        List<Cif> cifData = new ArrayList<>();
        Cif c = new Cif();
        c.setUbsCifNum("200030009");
        c.setCbsCifNum("2000300009");
        c.setCifAccounts(cifAccounts);
        cifData.add(c);
        when(cifsInfo.getCifData()).thenReturn(cifData);
        cifListRequest.setCifData(cifData);

        EnrollClientResponse clientEnrolled = new EnrollClientResponse();
        EnrollClientResponseData data = new EnrollClientResponseData();
        data.setGwPrimaryUserId("pUserId");
        data.setGwClientId("geClientId");
        data.setStatus("success");
        clientEnrolled.setData(data);

        //doNothing().when(clientService).save(Mockito.any(MigClient.class));

        clientService.migStartupBankingBundle = 15;
        doReturn(clientEnrolled).when(clientService).createClient(any(), any(),any(), any());

        MigClient mg = new MigClient();
        mg.setGwClientId("geClientId");
        mg.setCompanyId("home9500");
        mg.setStatus("success");
        mg.setEcClientId("home9522");
        doReturn(mg).when(migClientRepository).findByEcClientIdAndJobId(Mockito.anyString(),Mockito.any());
        doReturn(mg).when(migClientRepository).save(Mockito.any());

        EnrollClientResponse actClientEnrolled = clientService.enrollClient(companyId, clientId, 1L);

        assertEquals(clientEnrolled, actClientEnrolled);

    }

    @Test
    public void enrollClient_success_3() throws Exception {
        stgClient.setJobId("123");
        when(clientRepository.findByOlbClinetId(clientId)).thenReturn(stgClient);
        doReturn("123").when(stgClient).getJobId();
        StgUser u = new StgUser();
        u.setPrimaryUser(true);
        u.setStatus("0");
        List<StgUser> users = new ArrayList<>();
        users.add(u);

        when(userRepository.findByOlbClientId(clientId)).thenReturn(users);
        when(userRepository.findBYOlbClntId(clientId)).thenReturn(users);
        oAuth = "e2561beef23920c18902ada758a1118de96be728add38b1a04acb2d911845352";
        when(cacheManagerUtility.getOauthToken()).thenReturn(oAuth);
        when(stgClient.getPrimaryCifUbs()).thenReturn("200030009");

        Cifs cifListRequest = new Cifs();
        Cif cif = new Cif();
        cif.setCifNumber(stgClient.getPrimaryCifUbs());

        List<Cif> cifs = new ArrayList<>();
        List<AccountServices> cifaccounts = new ArrayList<>();
        AccountServices as = new AccountServices();
        List<SvbService> accServ = new ArrayList<>();
        SvbService ss = new SvbService();

        List<ServiceTransaction> serviceTxns = new ArrayList<>();
        ServiceTransaction sTxn = new ServiceTransaction();
        sTxn.setSvcTxnId("svcTxnId");
        serviceTxns.add(sTxn);
        ss.setServiceTxn(serviceTxns);
        accServ.add(ss);
        as.setAccServ(accServ);
        as.setAccountNum("accNum");
        cifs.add(cif);
        cifListRequest.setCifData(cifs);
        doReturn(cifListRequest).when(clientService).getCifAccountInfo(any(), any(), any(), any());

        Bundles bundles = new Bundles();
        List<Bundle> digitalBundles = new ArrayList<>();
        Bundle b = new Bundle();
        List<BundleServices> services = new ArrayList<>();
        BundleServices bs = new BundleServices();
        SvbService service = new SvbService();
        List<ServiceTransaction> serviceTxn = new ArrayList<>();
        service.setServiceId("sId");
        service.setServiceName("sName");
        ServiceTransaction st = new ServiceTransaction();
        st.setAcctSpecificTxn("N");
        st.setOperation("Credit");
        st.setSvcTxnId("svcTxnId");
        ServiceTransaction st1 = new ServiceTransaction();
        st1.setAcctSpecificTxn("N");
        st1.setOperation("Credit");
        st1.setSvcTxnId("svcTxnId1");
        ServiceTransaction st2 = new ServiceTransaction();
        st1.setAcctSpecificTxn("N");
        st2.setOperation("Credit");
        st2.setSvcTxnId("svcTxnId2");

        serviceTxn.add(st);
        serviceTxn.add(st1);
        serviceTxn.add(st2);

        service.setServiceTxn(serviceTxn);
        bs.setService(service);
        services.add(bs);
        b.setServices(services);
        b.setDigitalBundleId(15);
        digitalBundles.add(b);
        bundles.setDigitalBundles(digitalBundles);
        doReturn(bundles).when(clientService).getBundles(any(), any(), any());

        List<AccountServices> cifAccounts = new ArrayList<>();
        AccountServices accountServices = new AccountServices();
        accountServices.setAccCcy("accCcy");
        accountServices.setAccName("accName");
        accountServices.setAccountNum("1234567890");
        accountServices.setAccountTyp("CC");
        accountServices.setAccStat("stat");
        accountServices.setProdCode("prodCode");
        accountServices.setAccServ(accServ);
        cifAccounts.add(accountServices);

        List<Cif> cifData = new ArrayList<>();
        Cif c = new Cif();
        c.setUbsCifNum("200030009");
        c.setCbsCifNum("2000300009");
        c.setCifAccounts(cifAccounts);
        cifData.add(c);
        when(cifsInfo.getCifData()).thenReturn(cifData);
        cifListRequest.setCifData(cifData);

        EnrollClientResponse clientEnrolled = new EnrollClientResponse();
        EnrollClientResponseData data = new EnrollClientResponseData();
        data.setGwPrimaryUserId("pUserId");
        data.setGwClientId("geClientId");
        data.setStatus("success");
        clientEnrolled.setData(data);

        doReturn(1).when(userMapper).insertMigratingUser(Mockito.any(MigUser.class));
//        doNothing().when(clientMapper).updateClient(Mockito.any(MigClient.class));

        doNothing().when(entityLogUtility).saveEntityCountAndTimeLog(Mockito.any());
        clientService.migStartupBankingBundle = 15;
        doReturn(clientEnrolled).when(clientService).createClient(any(), any(),any(), any());

        EnrollClientResponse actClientEnrolled = clientService.enrollClient(companyId, clientId, 1L);

        assertNull(actClientEnrolled);

    }

    @Test
    public void enrollClient_user_empty() throws Exception {
        when(clientRepository.findByOlbClinetId(clientId)).thenReturn(stgClient);

        StgUser u = new StgUser();
        u.setPrimaryUser(true);
        List<StgUser> users = new ArrayList<>();
        //users.add(u);

        when(userRepository.findByOlbClientId(clientId)).thenReturn(users);
        when(userRepository.findBYOlbClntId(clientId)).thenReturn(users);
        oAuth = "e2561beef23920c18902ada758a1118de96be728add38b1a04acb2d911845352";
        when(cacheManagerUtility.getOauthToken()).thenReturn(oAuth);
        when(stgClient.getPrimaryCifUbs()).thenReturn("200030009");

        Cifs cifListRequest = new Cifs();
        Cif cif = new Cif();
        cif.setCifNumber(stgClient.getPrimaryCifUbs());

        List<Cif> cifs = new ArrayList<>();
        List<AccountServices> cifaccounts = new ArrayList<>();
        AccountServices as = new AccountServices();
        List<SvbService> accServ = new ArrayList<>();
        SvbService ss = new SvbService();

        List<ServiceTransaction> serviceTxns = new ArrayList<>();
        ServiceTransaction sTxn = new ServiceTransaction();
        sTxn.setSvcTxnId("svcTxnId");
        serviceTxns.add(sTxn);
        ss.setServiceTxn(serviceTxns);
        accServ.add(ss);
        as.setAccServ(accServ);
        as.setAccountNum("accNum");
        cifs.add(cif);
        cifListRequest.setCifData(cifs);
        doReturn(cifListRequest).when(clientService).getCifAccountInfo(any(), any(), any(), any());

        Bundles bundles = new Bundles();
        List<Bundle> digitalBundles = new ArrayList<>();
        Bundle b = new Bundle();
        List<BundleServices> services = new ArrayList<>();
        BundleServices bs = new BundleServices();
        SvbService service = new SvbService();
        List<ServiceTransaction> serviceTxn = new ArrayList<>();
        service.setServiceId("sId");
        service.setServiceName("sName");
        ServiceTransaction st = new ServiceTransaction();
        st.setAcctSpecificTxn("Y");
        st.setOperation("Credit");
        st.setSvcTxnId("svcTxnId");

        serviceTxn.add(st);

        service.setServiceTxn(serviceTxn);
        bs.setService(service);
        services.add(bs);
        b.setServices(services);
        b.setDigitalBundleId(15);
        digitalBundles.add(b);
        bundles.setDigitalBundles(digitalBundles);
        doReturn(bundles).when(clientService).getBundles(any(), any(), any());

        List<AccountServices> cifAccounts = new ArrayList<>();
        AccountServices accountServices = new AccountServices();
        accountServices.setAccCcy("accCcy");
        accountServices.setAccName("accName");
        accountServices.setAccountNum("1234567890");
        accountServices.setAccountTyp("CC");
        accountServices.setAccStat("stat");
        accountServices.setProdCode("prodCode");
        accountServices.setAccServ(accServ);
        cifAccounts.add(accountServices);

        List<Cif> cifData = new ArrayList<>();
        Cif c = new Cif();
        c.setUbsCifNum("200030009");
        c.setCifAccounts(cifAccounts);
        cifData.add(c);
        when(cifsInfo.getCifData()).thenReturn(cifData);
        cifListRequest.setCifData(cifData);

        clientService.migStartupBankingBundle = 15;
        doReturn(clientEnrolled).when(clientService).createClient(any(), any(), any(), any());

        Exception exception = assertThrows(ServiceException.class, () -> {
            clientService.enrollClient(companyId, clientId, 1L);
        });

        String expectedMessage = "Users are not present";
        String actualMessage = exception.getMessage();

        assertTrue(actualMessage.contains(expectedMessage));

    }

    @Test
    public void enrollClient_oAuth_null() throws Exception {
        when(clientRepository.findByOlbClinetId(clientId)).thenReturn(stgClient);

        StgUser u = new StgUser();
        u.setPrimaryUser(true);
        List<StgUser> users = new ArrayList<>();
        users.add(u);

        when(userRepository.findByOlbClientId(clientId)).thenReturn(users);
        when(userRepository.findBYOlbClntId(clientId)).thenReturn(users);
        oAuth = null;
        when(cacheManagerUtility.getOauthToken()).thenReturn(oAuth);
        when(stgClient.getPrimaryCifUbs()).thenReturn("200030009");

        Cifs cifListRequest = new Cifs();
        Cif cif = new Cif();
        cif.setCifNumber(stgClient.getPrimaryCifUbs());

        List<Cif> cifs = new ArrayList<>();
        List<AccountServices> cifaccounts = new ArrayList<>();
        AccountServices as = new AccountServices();
        List<SvbService> accServ = new ArrayList<>();
        SvbService ss = new SvbService();

        List<ServiceTransaction> serviceTxns = new ArrayList<>();
        ServiceTransaction sTxn = new ServiceTransaction();
        sTxn.setSvcTxnId("svcTxnId");
        serviceTxns.add(sTxn);
        ss.setServiceTxn(serviceTxns);
        accServ.add(ss);
        as.setAccServ(accServ);
        as.setAccountNum("accNum");
        cifs.add(cif);
        cifListRequest.setCifData(cifs);
        doReturn(cifListRequest).when(clientService).getCifAccountInfo(any(), any(), any(), any());

        Bundles bundles = new Bundles();
        List<Bundle> digitalBundles = new ArrayList<>();
        Bundle b = new Bundle();
        List<BundleServices> services = new ArrayList<>();
        BundleServices bs = new BundleServices();
        SvbService service = new SvbService();
        List<ServiceTransaction> serviceTxn = new ArrayList<>();
        service.setServiceId("sId");
        service.setServiceName("sName");
        ServiceTransaction st = new ServiceTransaction();
        st.setAcctSpecificTxn("Y");
        st.setOperation("Credit");
        st.setSvcTxnId("svcTxnId");

        serviceTxn.add(st);

        service.setServiceTxn(serviceTxn);
        bs.setService(service);
        services.add(bs);
        b.setServices(services);
        b.setDigitalBundleId(15);
        digitalBundles.add(b);
        bundles.setDigitalBundles(digitalBundles);
        doReturn(bundles).when(clientService).getBundles(any(), any(), any());

        List<AccountServices> cifAccounts = new ArrayList<>();
        AccountServices accountServices = new AccountServices();
        accountServices.setAccCcy("accCcy");
        accountServices.setAccName("accName");
        accountServices.setAccountNum("1234567890");
        accountServices.setAccountTyp("CC");
        accountServices.setAccStat("stat");
        accountServices.setProdCode("prodCode");
        accountServices.setAccServ(accServ);
        cifAccounts.add(accountServices);

        List<Cif> cifData = new ArrayList<>();
        Cif c = new Cif();
        c.setUbsCifNum("200030009");
        c.setCifAccounts(cifAccounts);
        cifData.add(c);
        when(cifsInfo.getCifData()).thenReturn(cifData);
        cifListRequest.setCifData(cifData);

        clientService.migStartupBankingBundle = 15;
        doReturn(clientEnrolled).when(clientService).createClient(any(), any(), any(), any());

        Exception exception = assertThrows(ServiceException.class, () -> {
            clientService.enrollClient(companyId, clientId, 1L);
        });

        String expectedMessage = "unable to retrieve Oauth";
        String actualMessage = exception.getMessage();

        assertTrue(actualMessage.contains(expectedMessage));

    }

    @Test
    public void enrollClient_cifInfo_null() throws Exception {
        when(clientRepository.findByOlbClinetId(Matchers.any())).thenReturn(stgClient);

        StgUser u = new StgUser();
        u.setPrimaryUser(true);
        List<StgUser> users = new ArrayList<>();
        users.add(u);

        when(userRepository.findByOlbClientId(Matchers.any())).thenReturn(users);
        when(userRepository.findBYOlbClntId(Matchers.any())).thenReturn(users);
        oAuth = "e2561beef23920c18902ada758a1118de96be728add38b1a04acb2d911845352";
        when(cacheManagerUtility.getOauthToken()).thenReturn(oAuth);
        when(stgClient.getPrimaryCifUbs()).thenReturn("200030009");

        Cifs cifListRequest = new Cifs();
        Cif cif = new Cif();
        cif.setCifNumber(stgClient.getPrimaryCifUbs());

        List<Cif> cifs = new ArrayList<>();
        List<AccountServices> cifaccounts = new ArrayList<>();
        AccountServices as = new AccountServices();
        List<SvbService> accServ = new ArrayList<>();
        SvbService ss = new SvbService();

        List<ServiceTransaction> serviceTxns = new ArrayList<>();
        ServiceTransaction sTxn = new ServiceTransaction();
        sTxn.setSvcTxnId("svcTxnId");
        serviceTxns.add(sTxn);
        ss.setServiceTxn(serviceTxns);
        accServ.add(ss);
        as.setAccServ(accServ);
        as.setAccountNum("accNum");
        cifs.add(cif);
        cifListRequest.setCifData(cifs);
        doReturn(null).when(clientService).getCifAccountInfo(any(), any(), any(), any());

        Bundles bundles = new Bundles();
        List<Bundle> digitalBundles = new ArrayList<>();
        Bundle b = new Bundle();
        List<BundleServices> services = new ArrayList<>();
        BundleServices bs = new BundleServices();
        SvbService service = new SvbService();
        List<ServiceTransaction> serviceTxn = new ArrayList<>();
        service.setServiceId("sId");
        service.setServiceName("sName");
        ServiceTransaction st = new ServiceTransaction();
        st.setAcctSpecificTxn("Y");
        st.setOperation("Credit");
        st.setSvcTxnId("svcTxnId");

        serviceTxn.add(st);

        service.setServiceTxn(serviceTxn);
        bs.setService(service);
        services.add(bs);
        b.setServices(services);
        b.setDigitalBundleId(15);
        digitalBundles.add(b);
        bundles.setDigitalBundles(digitalBundles);
        doReturn(bundles).when(clientService).getBundles(any(), any(), any());

        List<AccountServices> cifAccounts = new ArrayList<>();
        AccountServices accountServices = new AccountServices();
        accountServices.setAccCcy("accCcy");
        accountServices.setAccName("accName");
        accountServices.setAccountNum("1234567890");
        accountServices.setAccountTyp("CC");
        accountServices.setAccStat("stat");
        accountServices.setProdCode("prodCode");
        accountServices.setAccServ(accServ);
        cifAccounts.add(accountServices);

        List<Cif> cifData = new ArrayList<>();
        Cif c = new Cif();
        c.setUbsCifNum("200030009");
        c.setCifAccounts(cifAccounts);
        cifData.add(c);
        when(cifsInfo.getCifData()).thenReturn(cifData);
        cifListRequest.setCifData(cifData);

        clientService.migStartupBankingBundle = 15;
        doReturn(clientEnrolled).when(clientService).createClient(any(), any(), any(), any());

        doNothing().when(entityLogUtility).saveEntityCountAndTimeLog(Mockito.any());
        Exception exception = assertThrows(ServiceException.class, () -> {
            clientService.enrollClient(companyId, clientId, 1L);
        });

        String expectedMessage = "cifsInfo is null";
        String actualMessage = exception.getMessage();

        assertTrue(actualMessage.contains(expectedMessage));

    }

    @Test
    public void enrollClient_error_user() throws Exception {
        when(clientRepository.findByOlbClinetId(clientId)).thenReturn(stgClient);
        List<com.svb.gateway.migration.user.entity.StgUser> users1 = new ArrayList<>();
        StgUser u = new StgUser();
        u.setPrimaryUser(false);
        users1.add(u);

        when(userRepository.findByOlbClientId(clientId)).thenReturn(users1);
        when(userRepository.findBYOlbClntId(clientId)).thenReturn(users);
        oAuth = "e2561beef23920c18902ada758a1118de96be728add38b1a04acb2d911845352";
        when(cacheManagerUtility.getOauthToken()).thenReturn(oAuth);
        when(stgClient.getPrimaryCifUbs()).thenReturn("200030009");

        Cifs cifListRequest = new Cifs();
        Cif cif = new Cif();
        cif.setCifNumber(stgClient.getPrimaryCifUbs());
        List<Cif> cifs = new ArrayList<>();
        cifs.add(cif);
        cifListRequest.setCifData(cifs);
        doReturn(cifsInfo).when(clientService).getCifAccountInfo(any(), any(), any(), any());

        Bundles bundles = new Bundles();
        List<Bundle> digitalBundles = new ArrayList<>();
        Bundle b = new Bundle();
        List<BundleServices> services = new ArrayList<>();
        BundleServices bs = new BundleServices();
        SvbService service = new SvbService();
        List<ServiceTransaction> serviceTxn = new ArrayList<>();
        service.setServiceId("sId");
        service.setServiceName("sName");
        ServiceTransaction st = new ServiceTransaction();
        st.setAcctSpecificTxn("Y");
        serviceTxn.add(st);

        service.setServiceTxn(serviceTxn);
        bs.setService(service);
        services.add(bs);
        b.setServices(services);
        b.setDigitalBundleId(15);
        digitalBundles.add(b);
        bundles.setDigitalBundles(digitalBundles);
        doReturn(bundles).when(clientService).getBundles(any(), any(), any());

        List<AccountServices> cifAccounts = new ArrayList<>();
        AccountServices accountServices = new AccountServices();
        accountServices.setAccCcy("accCcy");
        accountServices.setAccName("accName");
        accountServices.setAccountNum("1234567890");
        accountServices.setAccountTyp("CC");
        accountServices.setAccStat("stat");
        accountServices.setProdCode("prodCode");
        List<SvbService> accServ = new ArrayList<>();
        SvbService svbService = new SvbService();
        svbService.setServiceName("sName");
        accServ.add(svbService);
        accountServices.setAccServ(accServ);
        cifAccounts.add(accountServices);

        List<Cif> cifData = new ArrayList<>();
        Cif c = new Cif();
        c.setUbsCifNum("200030009");
        c.setCifAccounts(cifAccounts);
        cifData.add(c);
        when(cifsInfo.getCifData()).thenReturn(cifData);
        cifListRequest.setCifData(cifData);

        clientService.migStartupBankingBundle = 15;

        Exception exception = assertThrows(ServiceException.class, () -> {
            clientService.enrollClient(companyId, clientId, 1L);
        });

        String expectedMessage = "Primary User not available";
        String actualMessage = exception.getMessage();

        assertTrue(actualMessage.contains(expectedMessage));
    }

    @Test
    public void clientIdnull() throws Exception {


        Exception exception = assertThrows(ServiceException.class, () -> {
            clientService.enrollClient(companyId, null, 1L);
        });

        String expectedMessage = "Olb Id not passed";
        String actualMessage = exception.getMessage();

        assertTrue(actualMessage.contains(expectedMessage));
    }

    @Test
    public void companyIdFormatSuccess() throws Exception {
        when(clientRepository.findByOlbClinetId(clientId)).thenReturn(stgClient);

        StgUser u = new StgUser();
        u.setPrimaryUser(true);
        List<StgUser> users = new ArrayList<>();
        users.add(u);

        when(userRepository.findByOlbClientId(clientId)).thenReturn(users);
        when(userRepository.findBYOlbClntId(clientId)).thenReturn(users);
        oAuth = "e2561beef23920c18902ada758a1118de96be728add38b1a04acb2d911845352";
        when(cacheManagerUtility.getOauthToken()).thenReturn(oAuth);
        when(stgClient.getPrimaryCifUbs()).thenReturn("200030009");

        Cifs cifListRequest = new Cifs();
        Cif cif = new Cif();
        cif.setCifNumber(stgClient.getPrimaryCifUbs());

        List<Cif> cifs = new ArrayList<>();
        List<AccountServices> cifaccounts = new ArrayList<>();
        AccountServices as = new AccountServices();
        List<SvbService> accServ = new ArrayList<>();
        SvbService ss = new SvbService();

        List<ServiceTransaction> serviceTxns = new ArrayList<>();
        ServiceTransaction sTxn = new ServiceTransaction();
        sTxn.setSvcTxnId("svcTxnId");
        serviceTxns.add(sTxn);
        ss.setServiceTxn(serviceTxns);
        accServ.add(ss);
        as.setAccServ(accServ);
        as.setAccountNum("accNum");
        cifs.add(cif);
        cifListRequest.setCifData(cifs);
        doReturn(cifListRequest).when(clientService).getCifAccountInfo(any(), any(), any(), any());

        Bundles bundles = new Bundles();
        List<Bundle> digitalBundles = new ArrayList<>();
        Bundle b = new Bundle();
        List<BundleServices> services = new ArrayList<>();
        BundleServices bs = new BundleServices();
        SvbService service = new SvbService();
        List<ServiceTransaction> serviceTxn = new ArrayList<>();
        service.setServiceId("sId");
        service.setServiceName("sName");
        ServiceTransaction st = new ServiceTransaction();
        st.setAcctSpecificTxn("Y");
        st.setOperation("Credit");
        st.setSvcTxnId("svcTxnId");

        serviceTxn.add(st);

        service.setServiceTxn(serviceTxn);
        bs.setService(service);
        services.add(bs);
        b.setServices(services);
        b.setDigitalBundleId(15);
        digitalBundles.add(b);
        bundles.setDigitalBundles(digitalBundles);
        doReturn(bundles).when(clientService).getBundles(any(), any(), any());

        List<AccountServices> cifAccounts = new ArrayList<>();
        AccountServices accountServices = new AccountServices();
        accountServices.setAccCcy("accCcy");
        accountServices.setAccName("accName");
        accountServices.setAccountNum("1234567890");
        accountServices.setAccountTyp("CC");
        accountServices.setAccStat("stat");
        accountServices.setProdCode("prodCode");
        accountServices.setAccServ(accServ);
        cifAccounts.add(accountServices);

        List<Cif> cifData = new ArrayList<>();
        Cif c = new Cif();
        c.setUbsCifNum("200030009");
        c.setCifAccounts(cifAccounts);
        cifData.add(c);
        when(cifsInfo.getCifData()).thenReturn(cifData);
        cifListRequest.setCifData(cifData);

        clientService.migStartupBankingBundle = 15;
        doReturn(clientEnrolled).when(clientService).createClient(any(), any(), any(), any());

        Exception exception = assertThrows(ServiceException.class, () -> {
            clientService.enrollClient(companyId, "123456", 1L);
        });

        String expectedMessage = "Client id has Invalid Format";
        String actualMessage = exception.getMessage();

        assertTrue(actualMessage.contains(expectedMessage));

    }

    @Test
    public void companyIdNull() throws Exception {
        Exception exception = assertThrows(ServiceException.class, () -> {
            clientService.enrollClient(null, clientId, 1L);
        });

        String expectedMessage = "Company id not passed";
        String actualMessage = exception.getMessage();

        assertTrue(actualMessage.contains(expectedMessage));
    }

    @Test
    public void enrollClient_error_bundle() throws Exception {
        when(clientRepository.findByOlbClinetId(clientId)).thenReturn(stgClient);
        when(userRepository.findByOlbClientId(clientId)).thenReturn(users);
        when(userRepository.findBYOlbClntId(clientId)).thenReturn(users);
        oAuth = "e2561beef23920c18902ada758a1118de96be728add38b1a04acb2d911845352";
        when(cacheManagerUtility.getOauthToken()).thenReturn(oAuth);
        when(stgClient.getPrimaryCifUbs()).thenReturn("200030009");

        Cifs cifListRequest = new Cifs();
        Cif cif = new Cif();
        cif.setCifNumber(stgClient.getPrimaryCifUbs());
        List<Cif> cifs = new ArrayList<>();
        cifs.add(cif);
        cifListRequest.setCifData(cifs);
        doReturn(cifsInfo).when(clientService).getCifAccountInfo(any(), any(), any(), any());

        Bundles bundles = new Bundles();
        List<Bundle> digitalBundles = new ArrayList<>();
        Bundle b = new Bundle();
        b.setDigitalBundleId(16);
        digitalBundles.add(b);
        bundles.setDigitalBundles(digitalBundles);
        doReturn(bundles).when(clientService).getBundles(any(), any(), any());

        List<Cif> cifData = new ArrayList<>();
        Cif c = new Cif();
        c.setUbsCifNum("200030009");
        cifData.add(c);
        when(cifsInfo.getCifData()).thenReturn(cifData);
        cifListRequest.setCifData(cifData);

        clientService.migStartupBankingBundle = 15;

        Exception exception = assertThrows(ServiceException.class, () -> {
            clientService.enrollClient(companyId, clientId, 1L);
        });

        String expectedMessage = "Startup Banking Bundle - 15 does not exist!";
        String actualMessage = exception.getMessage();

        assertTrue(actualMessage.contains(expectedMessage));
    }

    @Test
    public void enrollClient_error_cifData() throws Exception {
        when(clientRepository.findByOlbClinetId(clientId)).thenReturn(stgClient);
        when(userRepository.findByOlbClientId(clientId)).thenReturn(users);
        oAuth = "e2561beef23920c18902ada758a1118de96be728add38b1a04acb2d911845352";
        when(cacheManagerUtility.getOauthToken()).thenReturn(oAuth);
        when(stgClient.getPrimaryCifUbs()).thenReturn("200030009");

        List<Cif> cifData = new ArrayList<>();
        Cif c = new Cif();
        c.setUbsCifNum("2000030009");
        cifData.add(c);
        when(cifsInfo.getCifData()).thenReturn(cifData);
        doReturn(cifsInfo).when(clientService).getCifAccountInfo(any(), any(), any(), any());

        Exception exception = assertThrows(ServiceException.class, () -> {
            clientService.enrollClient(companyId, clientId, 1L);
        });

        String expectedMessage = "Cif not available";
        String actualMessage = exception.getMessage();

        assertTrue(actualMessage.contains(expectedMessage));

    }

    @Test
    public void createClient_error() throws Exception {

        ClientInfo ci = new ClientInfo();
        ResponseEntity<ClientInfo> clientInfo = new ResponseEntity<>(ci, HttpStatus.ACCEPTED);

        HttpHeaders headers = new HttpHeaders();
        headers.add(MigrationConstants.AUTHORIZATION_HEADER_NAME, oAuth);
        headers.add(MigrationConstants.CONTENT_TYPE, MigrationConstants.APPLICATION_HEADER_JSON);

        HttpEntity<EnrollClientRequest> requestEntity = new HttpEntity<>(request, headers);

        doThrow(new RestClientException("Test Exception")).when(restTemplate).exchange(Mockito.anyString(), Mockito.any(HttpMethod.class), Mockito.any(HttpEntity.class), eq(ClientInfo.class));

        clientService.migEnrollClientUrl = "migEnrollClientUrlTest";
        clientService.createClient(request, oAuth, "test", 100L);
    }

    @Test
    public void createClient_success() throws Exception {

        ClientInfo ci = new ClientInfo();
        com.svb.gateway.migration.client.model.Client c = new com.svb.gateway.migration.client.model.Client();
        c.setOlbId("olbId");
        List<com.svb.gateway.migration.user.model.User> userDetails = new ArrayList<>();
        com.svb.gateway.migration.user.model.User u = new com.svb.gateway.migration.user.model.User();
        u.setIdStoreuserkey("idStoreuserkey");
        userDetails.add(u);

        ci.setUserDetails(userDetails);
        ci.setClientData(c);
        ResponseEntity<ClientInfo> clientInfo = new ResponseEntity<>(ci, HttpStatus.ACCEPTED);

        HttpHeaders headers = new HttpHeaders();
        headers.add(MigrationConstants.AUTHORIZATION_HEADER_NAME, oAuth);
        headers.add(MigrationConstants.CONTENT_TYPE, MigrationConstants.APPLICATION_HEADER_JSON);

        HttpEntity<EnrollClientRequest> requestEntity = new HttpEntity<>(request, headers);

        doReturn(clientInfo).when(restTemplate).exchange(Mockito.anyString(), Mockito.any(HttpMethod.class), Mockito.any(HttpEntity.class), eq(ClientInfo.class));

        clientService.migEnrollClientUrl = "migEnrollClientUrlTest";
        EnrollClientResponse enrollClientResponse = clientService.createClient(request, oAuth, "test", 100L);
        assertEquals(MigrationConstants.STATUS_SUCCESS, enrollClientResponse.getData().getStatus());
    }

    @Test
    public void createClient_body_null() throws Exception {

        ClientInfo ci = new ClientInfo();
        ResponseEntity<ClientInfo> clientInfo = new ResponseEntity<>(null, HttpStatus.ACCEPTED);

        HttpHeaders headers = new HttpHeaders();
        headers.add(MigrationConstants.AUTHORIZATION_HEADER_NAME, oAuth);
        headers.add(MigrationConstants.CONTENT_TYPE, MigrationConstants.APPLICATION_HEADER_JSON);

        HttpEntity<EnrollClientRequest> requestEntity = new HttpEntity<>(request, headers);

        doReturn(clientInfo).when(restTemplate).exchange(Mockito.anyString(), Mockito.any(HttpMethod.class), Mockito.any(HttpEntity.class), eq(ClientInfo.class));

        clientService.migEnrollClientUrl = "migEnrollClientUrlTest";
        clientService.createClient(request, oAuth, "Test", 100L);
    }

    @Test
    public void createClient_data_null() throws Exception {

        ClientInfo ci = new ClientInfo();
        ResponseEntity<ClientInfo> clientInfo = new ResponseEntity<>(ci, HttpStatus.ACCEPTED);

        HttpHeaders headers = new HttpHeaders();
        headers.add(MigrationConstants.AUTHORIZATION_HEADER_NAME, oAuth);
        headers.add(MigrationConstants.CONTENT_TYPE, MigrationConstants.APPLICATION_HEADER_JSON);

        HttpEntity<EnrollClientRequest> requestEntity = new HttpEntity<>(request, headers);

        doReturn(clientInfo).when(restTemplate).exchange(Mockito.anyString(), Mockito.any(HttpMethod.class), Mockito.any(HttpEntity.class), eq(ClientInfo.class));

        clientService.migEnrollClientUrl = "migEnrollClientUrlTest";
        clientService.createClient(request, oAuth, "test", 100L);
    }

    @Test
    public void createClient_user_null() throws Exception {

        ClientInfo ci = new ClientInfo();
        com.svb.gateway.migration.client.model.Client c = new com.svb.gateway.migration.client.model.Client();
        ci.setClientData(c);
        ResponseEntity<ClientInfo> clientInfo = new ResponseEntity<>(ci, HttpStatus.ACCEPTED);

        HttpHeaders headers = new HttpHeaders();
        headers.add(MigrationConstants.AUTHORIZATION_HEADER_NAME, oAuth);
        headers.add(MigrationConstants.CONTENT_TYPE, MigrationConstants.APPLICATION_HEADER_JSON);

        HttpEntity<EnrollClientRequest> requestEntity = new HttpEntity<>(request, headers);

        doReturn(clientInfo).when(restTemplate).exchange(Mockito.anyString(), Mockito.any(HttpMethod.class), Mockito.any(HttpEntity.class), eq(ClientInfo.class));

        clientService.migEnrollClientUrl = "migEnrollClientUrlTest";
        clientService.createClient(request, oAuth, "test", 100L);
    }

    @Test
    public void getCifAccountInfo() throws Exception {

        HttpHeaders headers = new HttpHeaders();
        headers.add(MigrationConstants.AUTHORIZATION_HEADER_NAME, oAuth);
        headers.add(MigrationConstants.CONTENT_TYPE, MigrationConstants.APPLICATION_HEADER_JSON);

        Cifs cifListRequest = new Cifs();
        HttpEntity<Cifs> requestEntity = new HttpEntity<>(cifListRequest, headers);

        Cif c = new Cif();
        c.setUbsCifNum("200030009");
        ResponseEntity<Cifs> response2 = new ResponseEntity<>(cifListRequest, HttpStatus.ACCEPTED);

        doReturn(response2).when(restTemplate).exchange(Mockito.anyString(), Mockito.any(HttpMethod.class), Mockito.any(HttpEntity.class), eq(Cifs.class));
        clientService.migrationFetchCifAccountUrl = "migrationFetchCifAccountUrlTest";
        Cifs cifs = clientService.getCifAccountInfo(cifListRequest, oAuth, "test", 100l);
        assertNotNull(cifs);
    }

    @Test
    public void getCifAccountInfo_null_data() throws Exception {

        HttpHeaders headers = new HttpHeaders();
        headers.add(MigrationConstants.AUTHORIZATION_HEADER_NAME, oAuth);
        headers.add(MigrationConstants.CONTENT_TYPE, MigrationConstants.APPLICATION_HEADER_JSON);

        Cifs cifListRequest = new Cifs();
        HttpEntity<Cifs> requestEntity = new HttpEntity<>(cifListRequest, headers);

        Cif c = new Cif();
        c.setUbsCifNum("200030009");
        ResponseEntity<Cifs> response2 = new ResponseEntity<>(null, HttpStatus.ACCEPTED);

        doReturn(response2).when(restTemplate).exchange(Mockito.anyString(), Mockito.any(HttpMethod.class), Mockito.any(HttpEntity.class), eq(Cifs.class));
        clientService.migrationFetchCifAccountUrl = "migrationFetchCifAccountUrlTest";
        Cifs cifs = clientService.getCifAccountInfo(cifListRequest, oAuth, "test", 100L);
        assertNull(cifs);
    }

    @Test
    public void getCifAccountInfo_resp_null() throws Exception {

        HttpHeaders headers = new HttpHeaders();
        headers.add(MigrationConstants.AUTHORIZATION_HEADER_NAME, oAuth);
        headers.add(MigrationConstants.CONTENT_TYPE, MigrationConstants.APPLICATION_HEADER_JSON);

        Cifs cifListRequest = new Cifs();
        HttpEntity<Cifs> requestEntity = new HttpEntity<>(cifListRequest, headers);

        doReturn(null).when(restTemplate).exchange(Mockito.anyString(), Mockito.any(HttpMethod.class), Mockito.any(HttpEntity.class), eq(Cifs.class));
        clientService.migrationFetchCifAccountUrl = "migrationFetchCifAccountUrlTest";
        Cifs cifs = clientService.getCifAccountInfo(cifListRequest, oAuth, "test", 200L);
        assertNull(cifs);
    }

    @Test
    public void getCifAccountInfo_error() throws Exception {

        HttpHeaders headers = new HttpHeaders();
        headers.add(MigrationConstants.AUTHORIZATION_HEADER_NAME, oAuth);
        headers.add(MigrationConstants.CONTENT_TYPE, MigrationConstants.APPLICATION_HEADER_JSON);

        Cifs cifListRequest = new Cifs();
        HttpEntity<Cifs> requestEntity = new HttpEntity<>(cifListRequest, headers);

        doThrow(new RestClientException("Test Exception")).when(restTemplate).exchange(Mockito.anyString(), Mockito.any(HttpMethod.class), Mockito.any(HttpEntity.class), eq(Cifs.class));
        clientService.migrationFetchCifAccountUrl = "migrationFetchCifAccountUrlTest";
        Cifs cifs = clientService.getCifAccountInfo(cifListRequest, oAuth, "test", 200L);
        assertNull(cifs);
    }

    @Test
    public void getBundles_success() throws Exception {

        HttpHeaders headers = new HttpHeaders();

        headers.add(MigrationConstants.AUTHORIZATION_HEADER_NAME, oAuth);

        HttpEntity<Bundles> requestEntity = new HttpEntity<>(headers);

        Bundles bundles = new Bundles();

        ResponseEntity<Bundles> response2 = new ResponseEntity<>(bundles, HttpStatus.ACCEPTED);

        doReturn(response2).when(restTemplate).exchange(Mockito.anyString(), Mockito.any(HttpMethod.class), Mockito.any(HttpEntity.class), eq(Bundles.class));

        clientService.migrationFetchBundlesUrl = "migrationFetchBundlesUrl";

        Bundles b = clientService.getBundles(oAuth, "test", 100L);
        assertEquals(bundles, b);

    }

    @Test
    public void getBundles_data_null() throws Exception {

        HttpHeaders headers = new HttpHeaders();

        headers.add(MigrationConstants.AUTHORIZATION_HEADER_NAME, oAuth);

        HttpEntity<Bundles> requestEntity = new HttpEntity<>(headers);

        Bundles bundles = new Bundles();

        ResponseEntity<Bundles> response2 = new ResponseEntity<>(null, HttpStatus.ACCEPTED);

        doReturn(response2).when(restTemplate).exchange(Mockito.anyString(), Mockito.any(HttpMethod.class), Mockito.any(HttpEntity.class), eq(Bundles.class));

        clientService.migrationFetchBundlesUrl = "migrationFetchBundlesUrl";

        Bundles b = clientService.getBundles(oAuth, "test", 100l);
        assertNull(b);

    }

    @Test
    public void getBundles_error() throws Exception {

        HttpHeaders headers = new HttpHeaders();

        headers.add(MigrationConstants.AUTHORIZATION_HEADER_NAME, oAuth);

        HttpEntity<Bundles> requestEntity = new HttpEntity<>(headers);

        Bundles bundles = new Bundles();

        ResponseEntity<Bundles> response2 = new ResponseEntity<>(bundles, HttpStatus.ACCEPTED);

        doThrow(new RestClientException("Test Exception")).when(restTemplate).exchange(Mockito.anyString(), Mockito.any(HttpMethod.class), Mockito.any(HttpEntity.class), eq(Bundles.class));

        clientService.migrationFetchBundlesUrl = "migrationFetchBundlesUrl";

        Bundles b = clientService.getBundles(oAuth, "test", 100l);
        assertNull(b);

    }

    @Test
    public void getBundles_null() throws Exception {

        HttpHeaders headers = new HttpHeaders();

        headers.add(MigrationConstants.AUTHORIZATION_HEADER_NAME, oAuth);

        HttpEntity<Bundles> requestEntity = new HttpEntity<>(headers);

        doReturn(null).when(restTemplate).exchange(Mockito.anyString(), Mockito.any(HttpMethod.class), Mockito.any(HttpEntity.class), eq(Bundles.class));

        clientService.migrationFetchBundlesUrl = "migrationFetchBundlesUrl";

        assertNull(clientService.getBundles(oAuth, "test", 100l));
    }

    @Test
    public void test_inactiveAndDeleteClient() {
        doReturn(null).when(migClientRepository).findByGwClientIdAndStatus(Mockito.anyString(),Mockito.anyString());
        Exception exception = assertThrows(ServiceException.class, () -> {
            clientService.inactiveAndDeleteClient("GWclnt1234");
        });
    }

    @Test
    public void test_inactiveAndDeleteClient_1() throws Exception {
        MigClient mg = new MigClient();
        doReturn(mg).when(migClientRepository).findByGwClientIdAndStatus(Mockito.anyString(),Mockito.anyString());
        doReturn(mg).when(migClientRepository).save(Mockito.any());
        InActiveClientResponse inActiveClientResponse = new InActiveClientResponse();
        inActiveClientResponse.setStatusCode(404);
        doReturn(inActiveClientResponse).when(clientExtensionService).inActiveClient(Mockito.anyString(),Mockito.anyString());

        DeleteClientResponse deleteClientResponse = clientService.inactiveAndDeleteClient("GWclnt1234");
        assertEquals(deleteClientResponse.getStatus(),MigrationConstants.STATUS_FAILURE);

    }

    @Test
    public void test_inactiveAndDeleteClient_2() throws Exception {
        MigClient mg = new MigClient();
        doReturn(mg).when(migClientRepository).findByGwClientIdAndStatus(Mockito.anyString(),Mockito.anyString());
        doReturn(mg).when(migClientRepository).save(Mockito.any());
        InActiveClientResponse inActiveClientResponse = new InActiveClientResponse();
        inActiveClientResponse.setStatusCode(204);
        doReturn(inActiveClientResponse).when(clientExtensionService).inActiveClient(Mockito.anyString(),Mockito.anyString());
        doNothing().when(clientExtensionService).deleteClient(Mockito.anyString());

        DeleteClientResponse deleteClientResponse = clientService.inactiveAndDeleteClient("GWclnt1234");

        Assertions.assertEquals(MigrationConstants.STATUS_SUCCESS,deleteClientResponse.getStatus());

    }

    @Test
    public void test_processPartnerRegistrationStatus_WhenRegisteredPreviously() {
        MigClient mg = new MigClient();
        mg.setGwClientId("GWa1234");
        MigUser migUser=new MigUser();
        migUser.setGwUuid("1234");
        migUser.setComments(UserConstants.PRIMARY_USER_SUCCESS);
        migUser.setIsPrimaryUser(1);
        List<MigUser> migratedUsers=new ArrayList<>();

        try {
            migratedUsers.add(migUser);
            when(migUserRepository.getMigratedPrimaryUser(any())).thenReturn(migUser);
            when(clientExtensionService.getBdcClient(any())).thenReturn(getBdcClient());
            when(clientExtensionService.registerClientPartner(any())).thenReturn(true);
            when(clientExtensionService.registerPrimaryUserPartner(any(), any())).thenReturn(true);
            when(clientExtensionService.getBdcUsers(any())).thenReturn(getBdcUser());
            when(migClientRepository.findByEcClientId(any())).thenReturn(mg);
            when(migUserRepository.findByJobId(any())).thenReturn(migratedUsers);

            boolean isRegistered=clientService.processPartnerRegistrationStatus("ecclientid", 100L);
            Assert.assertEquals(true, isRegistered);
        }catch (ServiceException se){
            fail();
        }
    }

    @Test
    public void test_processPartnerRegistrationStatus_WhenNOTRegistered() {
        MigClient mg = new MigClient();
        mg.setGwClientId("GWa1234");

        MigUser migUser=new MigUser();
        migUser.setGwUuid("1234");

        try {
            when(migUserRepository.getMigratedPrimaryUser(any())).thenReturn(migUser);
            when(clientExtensionService.getBdcClient(any())).thenReturn(new BdcClient());
            when(clientExtensionService.registerClientPartner(any())).thenReturn(true);
            when(clientExtensionService.registerPrimaryUserPartner(any(), any())).thenReturn(true);
            when(clientExtensionService.getBdcUsers(any())).thenReturn(getBdcUser());
            when(migClientRepository.findByEcClientId(any())).thenReturn(mg);

            boolean isRegistered=clientService.processPartnerRegistrationStatus("ecclientId", 100L);
            Assert.assertEquals(false, isRegistered);
        }catch (ServiceException se){
            fail();
        }
    }


    private BdcUser getBdcUser() {

        List<Partners> partnerList=new ArrayList<>();
        Partners partner=new Partners();
        partner.setPartnerName(BDC_NAME);
        PartnerTasks partnerTasks=new PartnerTasks();
        partnerTasks.setPartnerTaskName("Bill.com User Enrollment");
        partnerTasks.setPartnerTaskStatus("completed");
        List<PartnerTasks> partnerTaskList=new ArrayList<>();
        partnerTaskList.add(partnerTasks);

        partner.setPartnerTasks(partnerTaskList);

        partnerList.add(partner);

        Users user=new Users();
        user.setIdStoreuserkey("1234");
        user.setPartners(partnerList);

        BdcUser bdcUser=new BdcUser();
        List<Users> list=new ArrayList<>();
        list.add(user);
        bdcUser.setUsers(list);
        return bdcUser;
    }

    private BdcClient getBdcClient() {
        ClientPartners clientPartners=new ClientPartners();
        clientPartners.setPartnerName(BDC_NAME);
        clientPartners.setPartnerStatus(MigrationConstants.PARTNER_COMPLETED_STATUS);
        List<ClientPartners> partners=new ArrayList<>();
        partners.add(clientPartners);

        BdcClient bdcClient=new BdcClient();
        bdcClient.setClientPartners(partners);
        return bdcClient;
    }
}

