package com.svb.gateway.migration.common.filter;

import com.svb.gateway.migration.common.constants.MigrationConstants;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.invocation.InvocationOnMock;
import org.mockito.stubbing.Answer;
import org.slf4j.MDC;
import org.springframework.dao.DataAccessResourceFailureException;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;


public class MDCFilterTest {

    public static final String TEST_URI = "/analytics/search";
    public static final String TEST_ORIGINATING_IP_HEADER = "127.0.0.1";
    public static final String TEST_AUTHORIZATION_HEADER = "testAuthorizationHeader";
    public static final String TEST_CORRELATION_ID_HEADER = "testCorrelationIdHeader";
    public static final String TEST_REQUEST_ID_HEADER = "testRequestIdHeader";
    public static final String TEST_METHOD = "POST";
    public static final String TEST_HEALTH_ENDPOINT_URI = "/reporting/actuator/health";

    private MDCFilter filter;
    private HttpServletRequest mockHttpServletRequest;
    private HttpServletResponse mockHttpServletResponse;
    private FilterChain mockFilterChain;
    private Map<String, String> mdc;

    @BeforeEach
    public void setup() throws Exception {
        filter = new MDCFilter();
        mockHttpServletRequest = mock(HttpServletRequest.class);
        mockHttpServletResponse = mock(HttpServletResponse.class);
        mockFilterChain = mock(FilterChain.class);

        doAnswer(new Answer<Void>() {
            public Void answer(InvocationOnMock invocation) {
                mdc = MDC.getCopyOfContextMap();
                return null;
            }
        }).when(mockFilterChain).doFilter(any(ServletRequest.class), any(ServletResponse.class));
    }

    @AfterEach
    public void cleanup() {
        MDC.clear();
    }

    @Test
    public void testDoFilterInternal() throws ServletException, IOException {
        when(mockHttpServletRequest.getRequestURI()).thenReturn(TEST_URI);
        when(mockHttpServletRequest.getHeader(MigrationConstants.ORIGINATING_IP_HEADER)).thenReturn(TEST_ORIGINATING_IP_HEADER);
        when(mockHttpServletRequest.getHeader(MigrationConstants.AUTHORIZATION_HEADER)).thenReturn(TEST_AUTHORIZATION_HEADER);
        when(mockHttpServletRequest.getMethod()).thenReturn(TEST_METHOD);

        filter.doFilterInternal(mockHttpServletRequest, mockHttpServletResponse, mockFilterChain);
        verify(mockFilterChain, times(1)).doFilter(any(ServletRequest.class), any(ServletResponse.class));
        assertEquals(TEST_URI, mdc.get(MigrationConstants.MDC_REQUEST_URI), "test MDC requestURI");
        assertEquals(TEST_METHOD, mdc.get(MigrationConstants.MDC_REQUEST_METHOD), "test MDC requestMethod");
        assertEquals(TEST_ORIGINATING_IP_HEADER, mdc.get(MigrationConstants.MDC_REQUEST_IP), "test MDC requestIp");
    }

    @Test
    public void testChainDoFilterThrowsException() throws ServletException, IOException {
        when(mockHttpServletRequest.getRequestURI()).thenReturn(TEST_URI);
        when(mockHttpServletRequest.getHeader(MigrationConstants.ORIGINATING_IP_HEADER)).thenReturn(TEST_ORIGINATING_IP_HEADER);
        when(mockHttpServletRequest.getHeader(MigrationConstants.AUTHORIZATION_HEADER)).thenReturn(TEST_AUTHORIZATION_HEADER);
        when(mockHttpServletRequest.getMethod()).thenReturn(TEST_METHOD);
        when(mockHttpServletResponse.getStatus()).thenReturn(500);
        doThrow(new DataAccessResourceFailureException("testException")).when(mockFilterChain).doFilter(any(HttpServletRequest.class), any(HttpServletResponse.class));
        filter.doFilterInternal(mockHttpServletRequest, mockHttpServletResponse, mockFilterChain);
        verify(mockFilterChain, times(1)).doFilter(any(ServletRequest.class), any(ServletResponse.class));
        verify(mockHttpServletResponse, times(1)).getStatus();
        assertNull(MDC.getCopyOfContextMap());
    }

    @Test
    public void testShouldNotFilter() throws ServletException {
        when(mockHttpServletRequest.getRequestURI()).thenReturn(TEST_URI);
        boolean retVal = filter.shouldNotFilter(mockHttpServletRequest);
        assertFalse(retVal);
        when(mockHttpServletRequest.getRequestURI()).thenReturn(TEST_HEALTH_ENDPOINT_URI);
        retVal = filter.shouldNotFilter(mockHttpServletRequest);
        assertTrue(retVal);
    }
}