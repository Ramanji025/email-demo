package com.svb.gateway.migration.common.interceptor;

import org.junit.jupiter.api.Test;
import org.springframework.http.HttpMethod;
import org.springframework.http.client.ClientHttpRequest;
import org.springframework.http.client.ClientHttpRequestExecution;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import java.net.URI;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;

class RestTemplateClientInterceptorTest {

    @Test
    void interceptShouldAddHeader() throws Exception {
        SimpleClientHttpRequestFactory requestFactory = new SimpleClientHttpRequestFactory();
        ClientHttpRequest request = requestFactory.createRequest(new URI("http://example.com"), HttpMethod.GET);
        ClientHttpRequestExecution execution = mock(ClientHttpRequestExecution.class);
        byte[] body = new byte[] {};
        new RestTemplateClientInterceptor().intercept(request, body, execution);
        verify(execution).execute(request, body);
        assertNotNull(request.getHeaders().getFirst("x-request-id"));
    }

}
