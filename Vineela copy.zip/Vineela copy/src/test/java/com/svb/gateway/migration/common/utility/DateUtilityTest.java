package com.svb.gateway.migration.common.utility;

import org.junit.Assert;
import org.junit.jupiter.api.Test;

import java.time.LocalDate;

import static org.junit.jupiter.api.Assertions.*;

class DateUtilityTest {

    @Test
    void getRecurringByEndDateAndFrequency_Weeks_ReturnAsExpected() {
        LocalDate endDate =LocalDate.now().plusWeeks(4);
        int result= DateUtility.getRecurringByEndDateAndFrequency(LocalDate.now(),endDate, 'W');
        Assert.assertEquals(4, result);
    }

    @Test
    void getRecurringByEndDateAndFrequency_BiWeekly_ReturnAsExpected() {
        LocalDate endDate =LocalDate.now().plusMonths(6);
        int result= DateUtility.getRecurringByEndDateAndFrequency(LocalDate.now(),endDate, 'B');
        Assert.assertTrue(result >= 12);
    }

    @Test
    void getRecurringByEndDateAndFrequency_Quarterly_ReturnAsExpected() {
        LocalDate endDate =LocalDate.now().plusMonths(6);
        int result= DateUtility.getRecurringByEndDateAndFrequency(LocalDate.now().plusDays(-1),endDate, 'Q');
        Assert.assertEquals(2, result);
    }

    @Test
    void getRecurringByEndDateAndFrequency_Month_ReturnAsExpected() {
        LocalDate endDate =LocalDate.now().plusMonths(14);
        int result= DateUtility.getRecurringByEndDateAndFrequency(LocalDate.now(),endDate, 'M');
        Assert.assertEquals(14, result);
    }

    @Test
    void getRecurringByEndDateAndFrequency_BiMonth_ReturnAsExpected() {
        LocalDate endDate =LocalDate.now().plusMonths(6);
        int result= DateUtility.getRecurringByEndDateAndFrequency(LocalDate.now().plusDays(-1),endDate, 'T');
        Assert.assertEquals(3, result);
    }
}
