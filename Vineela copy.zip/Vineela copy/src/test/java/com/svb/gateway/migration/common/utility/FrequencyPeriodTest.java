package com.svb.gateway.migration.common.utility;

import org.junit.Assert;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class FrequencyPeriodTest {

    @Test
    void fromValue() {
        FrequencyPeriod fp=FrequencyPeriod.fromValue('B');
        Assert.assertEquals(FrequencyPeriod.BI_WEEKLY, fp);

        fp=FrequencyPeriod.fromValue('M');
        Assert.assertEquals(FrequencyPeriod.MONTHLY, fp);

        fp=FrequencyPeriod.fromValue('T');
        Assert.assertEquals(FrequencyPeriod.ALTERNATE_MONTH, fp);

        fp=FrequencyPeriod.fromValue('W');
        Assert.assertEquals(FrequencyPeriod.WEEKLY, fp);

        fp=FrequencyPeriod.fromValue('Q');
        Assert.assertEquals(FrequencyPeriod.QUARTERLY, fp);
    }
}
