package com.svb.gateway.migration.ec2stage.batch.account.processor;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.svb.gateway.migration.common.DataProvider;
import com.svb.gateway.migration.ec2stage.batch.account.dto.AccountLevelPerm;

@ExtendWith(SpringExtension.class)
@TestInstance(TestInstance.Lifecycle.PER_CLASS)
public class AccountLevelPermProcessorTest {

	@InjectMocks
	private AccountLevelPermProcessor accountLevelPermProcessor;
	
	@Test
	public void testAccountLevelPermProcess() throws Exception {
		AccountLevelPerm accountLevelPerm = new AccountLevelPerm();
		ObjectMapper mapper = new ObjectMapper();
		String accountLevelPermStr = mapper.writeValueAsString(accountLevelPerm);
		
		AccountLevelPerm accountLevelPermToProcess = (AccountLevelPerm) DataProvider.getGenericObject(accountLevelPermStr, AccountLevelPerm.class);
		AccountLevelPerm processedAccountLevelPerm = accountLevelPermProcessor.process(accountLevelPermToProcess);
		assertNotNull(processedAccountLevelPerm);
		assertEquals(accountLevelPermToProcess, processedAccountLevelPerm);
		
	}
	
}
