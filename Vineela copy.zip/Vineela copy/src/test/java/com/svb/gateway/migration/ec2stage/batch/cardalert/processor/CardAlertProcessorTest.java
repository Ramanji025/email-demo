package com.svb.gateway.migration.ec2stage.batch.cardalert.processor;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.svb.gateway.migration.common.DataProvider;
import com.svb.gateway.migration.ec2stage.batch.cardalerts.dto.CardAlert;
import com.svb.gateway.migration.ec2stage.batch.cardalerts.processor.CardAlertProcessor;

@ExtendWith(SpringExtension.class)
@TestInstance(TestInstance.Lifecycle.PER_CLASS)
public class CardAlertProcessorTest {

	@InjectMocks
    private CardAlertProcessor cardAlertProcessor;
	
	@Test
    public void testCardAlertProcess() throws Exception {
		CardAlert cardAlert = new CardAlert();
        ObjectMapper mapper = new ObjectMapper();
        String cardAlertStr = mapper.writeValueAsString(cardAlert);


        CardAlert cardAlertToProcess = (CardAlert) DataProvider.getGenericObject(cardAlertStr, CardAlert.class);
        CardAlert processedCardAlert = cardAlertProcessor.process(cardAlertToProcess);
        assertNotNull(processedCardAlert);
        assertEquals(cardAlertToProcess, processedCardAlert);
    }
	
}
