package com.svb.gateway.migration.ec2stage.batch.cardprogram.processor;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.svb.gateway.migration.common.DataProvider;
import com.svb.gateway.migration.ec2stage.batch.cardprograms.dto.CardProgram;
import com.svb.gateway.migration.ec2stage.batch.cardprograms.processor.CardProgramProcessor;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import static org.junit.jupiter.api.Assertions.*;

@ExtendWith(SpringExtension.class)
@TestInstance(TestInstance.Lifecycle.PER_CLASS)
class CardProgramProcessorTest {
    @InjectMocks
    private CardProgramProcessor cardProgramProcessor;

    @Test
    public void testCardProgramProcess() throws Exception {
    	CardProgram cardProgram = new CardProgram();
        ObjectMapper mapper = new ObjectMapper();
        String cardProgramStr = mapper.writeValueAsString(cardProgram);


        CardProgram cardProgramToProcess = (CardProgram) DataProvider.getGenericObject(cardProgramStr, CardProgram.class);
        CardProgram processedCardProgram = cardProgramProcessor.process(cardProgramToProcess);
        assertNotNull(processedCardProgram);
        assertEquals(cardProgramToProcess, processedCardProgram);
    }
}