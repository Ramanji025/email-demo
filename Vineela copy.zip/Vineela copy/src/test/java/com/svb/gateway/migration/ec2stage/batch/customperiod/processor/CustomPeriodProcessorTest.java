package com.svb.gateway.migration.ec2stage.batch.customperiod.processor;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.svb.gateway.migration.common.DataProvider;
import com.svb.gateway.migration.ec2stage.batch.customperiods.dto.CustomPeriod;
import com.svb.gateway.migration.ec2stage.batch.customperiods.processor.CustomPeriodProcessor;

@ExtendWith(SpringExtension.class)
@TestInstance(TestInstance.Lifecycle.PER_CLASS)
public class CustomPeriodProcessorTest {
	@InjectMocks
    private CustomPeriodProcessor customPeriodProcessor;

    @Test
    public void testCustomPeriodProcess() throws Exception {
    	CustomPeriod customPeriod = new CustomPeriod();
        ObjectMapper mapper = new ObjectMapper();
        String customPeriodStr = mapper.writeValueAsString(customPeriod);


        CustomPeriod customPeriodToProcess = (CustomPeriod) DataProvider.getGenericObject(customPeriodStr, CustomPeriod.class);
        CustomPeriod processedCustomPeriod = customPeriodProcessor.process(customPeriodToProcess);
        assertNotNull(processedCustomPeriod);
        assertEquals(customPeriodToProcess, processedCustomPeriod);
    }
}
