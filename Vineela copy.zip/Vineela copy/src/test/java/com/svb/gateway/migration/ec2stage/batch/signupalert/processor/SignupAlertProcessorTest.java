package com.svb.gateway.migration.ec2stage.batch.signupalert.processor;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.svb.gateway.migration.common.DataProvider;
import com.svb.gateway.migration.ec2stage.batch.signupalerts.dto.SignupAlert;
import com.svb.gateway.migration.ec2stage.batch.signupalerts.processor.SignupAlertProcessor;

@ExtendWith(SpringExtension.class)
@TestInstance(TestInstance.Lifecycle.PER_CLASS)
public class SignupAlertProcessorTest {

	@InjectMocks
    private SignupAlertProcessor signupAlertProcessor;
	
	@Test
    public void testSignupAlertProcess() throws Exception {
		SignupAlert signupAlert = new SignupAlert();
        ObjectMapper mapper = new ObjectMapper();
        String signupAlertStr = mapper.writeValueAsString(signupAlert);


        SignupAlert signupAlertToProcess = (SignupAlert) DataProvider.getGenericObject(signupAlertStr, SignupAlert.class);
        SignupAlert processedSignupAlert = signupAlertProcessor.process(signupAlertToProcess);
        assertNotNull(processedSignupAlert);
        assertEquals(signupAlertToProcess, processedSignupAlert);
    }
	
}
