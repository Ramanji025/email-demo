package com.svb.gateway.migration.ec2stage.batch.specialreport.processor;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.svb.gateway.migration.common.DataProvider;
import com.svb.gateway.migration.ec2stage.batch.specialreports.dto.SpecialReport;
import com.svb.gateway.migration.ec2stage.batch.specialreports.processor.SpecialReportProcessor;

@ExtendWith(SpringExtension.class)
@TestInstance(TestInstance.Lifecycle.PER_CLASS)
public class SpecialReportProcessorTest {

	@InjectMocks
    private SpecialReportProcessor specialReportProcessor;
	
	@Test
    public void testSpecialReportProcess() throws Exception {
		SpecialReport specialReport = new SpecialReport();
        ObjectMapper mapper = new ObjectMapper();
        String specialReportStr = mapper.writeValueAsString(specialReport);


        SpecialReport specialReportToProcess = (SpecialReport) DataProvider.getGenericObject(specialReportStr, SpecialReport.class);
        SpecialReport processedSpecialReport = specialReportProcessor.process(specialReportToProcess);
        assertNotNull(processedSpecialReport);
        assertEquals(specialReportToProcess, processedSpecialReport);
    }
	
	
}
