package com.svb.gateway.migration.ec2stage.batch.transfers.processor;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.svb.gateway.migration.common.DataProvider;
import com.svb.gateway.migration.ec2stage.batch.client.dto.Client;
import com.svb.gateway.migration.ec2stage.batch.client.processor.ClientProcessor;
import com.svb.gateway.migration.ec2stage.batch.transfers.dto.Transfer;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import static org.junit.jupiter.api.Assertions.*;

@ExtendWith(SpringExtension.class)
@TestInstance(TestInstance.Lifecycle.PER_CLASS)
class TransferProcessorTest {
    @InjectMocks
    private TransferProcessor transferProcessor;

    @Test
    public void testClientProcess() throws Exception {
        Transfer transfer = new Transfer();
        ObjectMapper mapper = new ObjectMapper();
        String transferStr = mapper.writeValueAsString(transfer);


        Transfer transferToProcess = (Transfer) DataProvider.getGenericObject(transferStr, Transfer.class);
        Transfer processedTransfer = transferProcessor.process(transferToProcess);
        assertNotNull(processedTransfer);
        assertEquals(transferToProcess, processedTransfer);
    }
}