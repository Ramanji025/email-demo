package com.svb.gateway.migration.ec2stage.batch.user.processor;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import org.junit.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.svb.gateway.migration.common.DataProvider;
import com.svb.gateway.migration.ec2stage.batch.user.dto.UserLevelPerm;

@ExtendWith(SpringExtension.class)
@TestInstance(TestInstance.Lifecycle.PER_CLASS)
public class UserLevelPermProcessorTest {
	
	@InjectMocks
	private UserLevelPermProcessor userLevelPermProcessor;
	
	@Test
	public void testUserLevelPermProcess() throws Exception {
		UserLevelPerm userLevelPerm = new UserLevelPerm();
		ObjectMapper mapper = new ObjectMapper();
		String userLevelPermStr = mapper.writeValueAsString(userLevelPerm);
		
		UserLevelPerm userLevelPermToProcess = (UserLevelPerm) DataProvider.getGenericObject(userLevelPermStr, UserLevelPerm.class);
		UserLevelPerm processedUserLevelPerm = userLevelPermProcessor.process(userLevelPermToProcess);
		assertNotNull(processedUserLevelPerm);
		assertEquals(userLevelPermToProcess, processedUserLevelPerm);
		
	}
	

}
