package com.svb.gateway.migration.ec2stage.batch.user.processor;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.svb.gateway.migration.common.DataProvider;
import com.svb.gateway.migration.ec2stage.batch.user.dto.UserPhone;

@ExtendWith(SpringExtension.class)
@TestInstance(TestInstance.Lifecycle.PER_CLASS)
public class UserPhoneProcessorTest {
	
	@InjectMocks
	private UserPhoneProcessor userPhoneProcessor;
	
	@Test
	void testProcess() throws Exception {
		UserPhone userPhone = new UserPhone();
		ObjectMapper mapper = new ObjectMapper();
		String userPhoneStr = mapper.writeValueAsString(userPhone);

		UserPhone userPhoneToProcess = (UserPhone) DataProvider.getGenericObject(userPhoneStr, UserPhone.class);
		UserPhone processedUserPhone = userPhoneProcessor.process(userPhoneToProcess);
		assertNotNull(processedUserPhone);
		assertEquals(userPhoneToProcess, processedUserPhone);
	}

}
