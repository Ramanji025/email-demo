package com.svb.gateway.migration.ec2stage.batch.user.processor;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.svb.gateway.migration.common.DataProvider;
import com.svb.gateway.migration.ec2stage.batch.user.dto.User;
import com.svb.gateway.migration.ec2stage.batch.user.processor.UserProcessor;

@ExtendWith(SpringExtension.class)
@TestInstance(TestInstance.Lifecycle.PER_CLASS)
public class UserProcessorTest {

	@InjectMocks
	private UserProcessor userProcessor;

	@Test
	void testProcess() throws Exception {

		ObjectMapper mapper = new ObjectMapper();

		User user = new User();
		user.setUserRole("6");
		user.setPrimaryUser("0");
		user.setPrimaryContact("0");
		String userStr = mapper.writeValueAsString(user);

		User userToProcess = (User) DataProvider.getGenericObject(userStr, User.class);
		User processedUser = userProcessor.process(userToProcess);

		assertNotNull(processedUser);
		assertTrue(processedUser.getPrimaryUser().equals("N"));
		assertTrue(processedUser.getUserRole().equals("ADMIN"));
		assertTrue(processedUser.getPrimaryContact().equals("N"));

		User user3 = new User();
		user3.setUserRole("6");
		user3.setPrimaryUser("1");
		user3.setPrimaryContact("1");
		String user3Str = mapper.writeValueAsString(user3);

		User user3ToProcess = (User) DataProvider.getGenericObject(user3Str, User.class);
		User processedUser3 = userProcessor.process(user3ToProcess);

		assertNotNull(processedUser3);
		assertTrue(processedUser3.getPrimaryUser().equals("Y"));
		assertTrue(processedUser3.getUserRole().equals("ADMIN"));
		assertTrue(processedUser3.getPrimaryContact().equals("Y"));

		User user2 = new User();
		user2.setUserRole("7");
		user2.setPrimaryUser("0");
		String user2Str = mapper.writeValueAsString(user2);

		User user2ToProcess = (User) DataProvider.getGenericObject(user2Str, User.class);
		User processedUser2 = userProcessor.process(user2ToProcess);

		assertNotNull(processedUser2);
		assertTrue(processedUser2.getPrimaryUser().equals("N"));
		assertTrue(processedUser2.getUserRole().equals("USER"));
	}
}
