package com.svb.gateway.migration.ec2stage.batch.userquery.processor;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.svb.gateway.migration.common.DataProvider;
import com.svb.gateway.migration.ec2stage.batch.userqueries.dto.UserQuery;
import com.svb.gateway.migration.ec2stage.batch.userqueries.processor.UserQueryProcessor;

@ExtendWith(SpringExtension.class)
@TestInstance(TestInstance.Lifecycle.PER_CLASS)
public class UserQueryProcessorTest {
	@InjectMocks
    private UserQueryProcessor userQueryProcessor;

    @Test
    public void testUserQueryProcess() throws Exception {
    	UserQuery userQuery = new UserQuery();
        ObjectMapper mapper = new ObjectMapper();
        String userQueryStr = mapper.writeValueAsString(userQuery);


        UserQuery userQueryToProcess = (UserQuery) DataProvider.getGenericObject(userQueryStr, UserQuery.class);
        UserQuery processedUserQuery = userQueryProcessor.process(userQueryToProcess);
        assertNotNull(processedUserQuery);
        assertEquals(userQueryToProcess, processedUserQuery);
    }
}
