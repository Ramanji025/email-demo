package com.svb.gateway.migration.ec2stage.batch.wire.processor;

import static org.junit.Assert.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.svb.gateway.migration.common.DataProvider;
import com.svb.gateway.migration.ec2stage.batch.wire.dto.FreeformWireBene;

@ExtendWith(SpringExtension.class)
@TestInstance(TestInstance.Lifecycle.PER_CLASS)
public class FreeformWireBeneProcessorTest {

	@InjectMocks
	private FreeformWireBeneProcessor wireProcessor;
	
	@Test
	public void testWireProcess() throws Exception {
		FreeformWireBene wire = new FreeformWireBene();
		ObjectMapper mapper = new ObjectMapper();
		String wireStr = mapper.writeValueAsString(wire);
		
		FreeformWireBene wireToProcess = (FreeformWireBene) DataProvider.getGenericObject(wireStr, FreeformWireBene.class);
		FreeformWireBene processedWire = wireProcessor.process(wireToProcess);
		assertNotNull(processedWire);
		assertEquals(wireToProcess, processedWire);
		
	}
}
