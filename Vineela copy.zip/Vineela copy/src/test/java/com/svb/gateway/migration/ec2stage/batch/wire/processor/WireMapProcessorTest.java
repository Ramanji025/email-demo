package com.svb.gateway.migration.ec2stage.batch.wire.processor;

import static org.junit.Assert.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.svb.gateway.migration.common.DataProvider;
import com.svb.gateway.migration.ec2stage.batch.wire.dto.WireMap;

@ExtendWith(SpringExtension.class)
@TestInstance(TestInstance.Lifecycle.PER_CLASS)
public class WireMapProcessorTest {

	@InjectMocks
	private WireMapProcessor wireMapProcessor;
	
	@Test
	public void testWireProcess() throws Exception {
		WireMap wireMap = new WireMap();
		ObjectMapper mapper = new ObjectMapper();
		String wireStr = mapper.writeValueAsString(wireMap);
		
		WireMap wireMapToProcess = (WireMap) DataProvider.getGenericObject(wireStr, WireMap.class);
		WireMap processedWireMap = wireMapProcessor.process(wireMapToProcess);
		assertNotNull(processedWireMap);
		assertEquals(wireMapToProcess, processedWireMap);
		
	}
}
