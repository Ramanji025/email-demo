package com.svb.gateway.migration.ec2stage.batch.wire.processor;

import static org.junit.Assert.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.svb.gateway.migration.common.DataProvider;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.svb.gateway.migration.ec2stage.batch.wire.dto.WireTemplate;

@ExtendWith(SpringExtension.class)
@TestInstance(TestInstance.Lifecycle.PER_CLASS)
class WireTemplateProcessorTest {

	@InjectMocks
	private WireTemplateProcessor wireProcessor;
	
	@Test
	public void testWireProcess() throws Exception {
		WireTemplate wire = new WireTemplate();
		ObjectMapper mapper = new ObjectMapper();
		String wireStr = mapper.writeValueAsString(wire);
		
		WireTemplate wireToProcess = (WireTemplate) DataProvider.getGenericObject(wireStr, WireTemplate.class);
		WireTemplate processedWire = wireProcessor.process(wireToProcess);
		assertNotNull(processedWire);
		assertEquals(wireToProcess, processedWire);
		
	}
	
}
