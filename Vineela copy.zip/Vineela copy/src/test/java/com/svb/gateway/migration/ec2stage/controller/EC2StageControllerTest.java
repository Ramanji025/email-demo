package com.svb.gateway.migration.ec2stage.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.svb.gateway.migration.common.exception.BadRequestException;
import com.svb.gateway.migration.common.exception.ServiceException;
import com.svb.gateway.migration.common.utility.MigrationConstants;
import com.svb.gateway.migration.ec2stage.model.Ec2StageMigrationRequest;
import com.svb.gateway.migration.ec2stage.service.ECService;
import com.svb.gateway.migration.job.model.CreateJobResponse;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentMatchers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersInvalidException;
import org.springframework.batch.core.configuration.JobRegistry;
import org.springframework.batch.core.job.SimpleJob;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.batch.core.launch.NoSuchJobException;
import org.springframework.batch.core.repository.JobExecutionAlreadyRunningException;
import org.springframework.batch.core.repository.JobInstanceAlreadyCompleteException;
import org.springframework.batch.core.repository.JobRestartException;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.ResponseEntity;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.util.ReflectionTestUtils;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import static com.svb.gateway.migration.TestUtil.*;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.Mockito.*;

@ExtendWith(SpringExtension.class)
@TestInstance(TestInstance.Lifecycle.PER_CLASS)
class EC2StageControllerTest {

	@Mock
	private JobLauncher jobLauncher;

	@Mock
	private JobRegistry jobRegistry;

	@InjectMocks
	private EC2StageController EC2StageController;

	@MockBean
	private ECService ecService;

	@Test
	@WithMockUser(username = TEST_USER_USER1, password = TEST_USER1_VALID_PASSWORD, authorities = TEST_USER1_ROLE_EXECUTE)
	public void testMigrateEc2Stage() throws Exception {

		Ec2StageMigrationRequest request = new Ec2StageMigrationRequest();
		request.setJobId(1L);
		List<String> clientIds = new ArrayList<String>(Arrays.asList("acb12345", "def45678"));
		request.setClientIds(clientIds);
		
		ResponseEntity<Object> responseEntity = EC2StageController.migrateEc2Stage(request);
		assertNull(((CreateJobResponse)responseEntity.getBody()).getErrors());
	}

	@Test
	@WithMockUser(username = TEST_USER_USER1, password = TEST_USER1_VALID_PASSWORD, authorities = TEST_USER1_ROLE_EXECUTE)
	public void testMigrateEc2Stage_validationError() throws Exception {

		Ec2StageMigrationRequest request = new Ec2StageMigrationRequest();
		request.setJobId(1L);
		List<String> clientIds = new ArrayList<String>(Arrays.asList("abcd1234", "def45678"));
		request.setClientIds(clientIds);

		doReturn(new ArrayList<>(Arrays.asList("abcd1234"))).when(ecService).validateECMigrationStatus(anyList());
		Exception exception = assertThrows(BadRequestException.class, () -> {
			EC2StageController.migrateEc2Stage(request);
		});
		assertNotNull(exception);
	}
	
	@Test
	@WithMockUser(username = TEST_USER_USER1, password = TEST_USER1_VALID_PASSWORD, authorities = TEST_USER1_ROLE_EXECUTE)
	public void testMigrateEc2StageFailure() throws Exception {

		Ec2StageMigrationRequest request = new Ec2StageMigrationRequest();
		request.setJobId(1L);
		List<String> clientIds = new ArrayList<String>();
		request.setClientIds(clientIds);
		ResponseEntity<Object> responseEntity = EC2StageController.migrateEc2Stage(request);
		assertNotNull(((CreateJobResponse)responseEntity.getBody()).getErrors());
	}

	@BeforeEach
	public void before() throws JobParametersInvalidException, JobExecutionAlreadyRunningException,
			JobRestartException, JobInstanceAlreadyCompleteException, JsonProcessingException, ServiceException {
		EC2StageController.setEcService(ecService);
		try {
			when(jobRegistry.getJob(MigrationConstants.MIGRATE_EC_DATA_JOB)).thenReturn(mock(SimpleJob.class));
		} catch (NoSuchJobException e) {
			e.printStackTrace();
		}
		when(jobLauncher.run(ArgumentMatchers.any(Job.class), ArgumentMatchers.any(JobParameters.class)))
				.thenReturn(new JobExecution(new Date().getTime()));
		doNothing().when(ecService).updateClientDetailsEc(anyList(), anyInt());
		doReturn(new ArrayList<>()).when(ecService).validateECMigrationStatus(anyList());
		ReflectionTestUtils.setField(EC2StageController, "EC_CLIENT_ID_LENGTH", 8);
	}
	
	@Test
	@WithMockUser(username = TEST_USER_USER1, password = TEST_USER1_VALID_PASSWORD, authorities = TEST_USER1_ROLE_EXECUTE)
	public void createJobTestWithEmptyValues() throws JobParametersInvalidException, JobExecutionAlreadyRunningException, JobRestartException, JobInstanceAlreadyCompleteException {
		List<String> clientIds = new ArrayList<String>();
		clientIds.add("");
		Assertions.assertThrows(ServiceException.class, () -> { EC2StageController.validateClientIds(clientIds); });
	}
	 
	@Test
	@WithMockUser(username = TEST_USER_USER1, password = TEST_USER1_VALID_PASSWORD, authorities = TEST_USER1_ROLE_EXECUTE)
	public void createJobTestWithDuplicateValues() throws JobParametersInvalidException, JobExecutionAlreadyRunningException, JobRestartException, JobInstanceAlreadyCompleteException {
		List<String> clientIds = new ArrayList<String>();
		clientIds.add("konk1806");
		clientIds.add("konk1806");
		Assertions.assertThrows(ServiceException.class, () -> { EC2StageController.validateClientIds(clientIds); });
	}
	 
	@Test
	@WithMockUser(username = TEST_USER_USER1, password = TEST_USER1_VALID_PASSWORD, authorities = TEST_USER1_ROLE_EXECUTE)
	public void createJobTestWithInvalidLength() throws JobParametersInvalidException, JobExecutionAlreadyRunningException, JobRestartException, JobInstanceAlreadyCompleteException {
		List<String> clientIds = new ArrayList<String>();
		clientIds.add("konk180");
		Assertions.assertThrows(ServiceException.class, () -> { EC2StageController.validateClientIds(clientIds); });
	}
}
