package com.svb.gateway.migration.ec2stage.service;

import com.svb.gateway.migration.common.exception.ServiceException;
import com.svb.gateway.migration.ec2stage.dao.ECDao;
import com.svb.gateway.migration.ec2stage.model.ClientDetail;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.Spy;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.client.RestTemplate;

import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doReturn;

@SpringBootTest
@ExtendWith(SpringExtension.class)
class ECServiceTest {

    @Mock
    RestTemplate restTemplate;

    @InjectMocks
    @Spy
    ECService ecService;

    @Mock
    ECDao ecDao;

    @Value("${ec.updateStatus.url}")
    String ecClientUrl;

    @Test
    public void test_eCUpdateStatusAPI() throws ServiceException {
        List<String> clientIds = new ArrayList<String>(Arrays.asList("acb12345", "def45678"));
        Map<String, Object> response = new HashMap<>();
        Map<String, Object> data = new HashMap<>();
        data.put("status", "Success");
        response.put("data", data);
        ResponseEntity<Object> responseObject = new ResponseEntity<>(response, HttpStatus.OK);

        doReturn(responseObject).when(restTemplate).exchange(Mockito.anyString(), Mockito.any(HttpMethod.class), Mockito.any(HttpEntity.class), eq(Object.class));
        ecService.updateClientDetailsEc(clientIds, 2);
        assertTrue(true);
    }

    @Test
    public void test_eCUpdateStatusAPI_error() {
        List<String> clientIds = new ArrayList<String>(Arrays.asList("acb12345", "def45678"));
        Map<String, Object> response = new HashMap<>();
        response.put("messages", new HashMap<>());
        ResponseEntity<Object> responseObject = new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);

        doReturn(responseObject).when(restTemplate).exchange(Mockito.anyString(), Mockito.any(HttpMethod.class), Mockito.any(HttpEntity.class), eq(Object.class));
        Exception exception = assertThrows(ServiceException.class, () -> {
            ecService.updateClientDetailsEc(clientIds, 2);
        });
    }

    @Test
    public void test_eCUpdateStatusAPI_error_2() {
        List<String> clientIds = new ArrayList<String>(Arrays.asList("acb12345", "def45678"));
        Map<String, Object> response = new HashMap<>();
        response.put("messages", new HashMap<>());
        ResponseEntity<Object> responseObject = new ResponseEntity<>(response, HttpStatus.OK);

        doReturn(responseObject).when(restTemplate).exchange(Mockito.anyString(), Mockito.any(HttpMethod.class), Mockito.any(HttpEntity.class), eq(Object.class));
        Exception exception = assertThrows(ServiceException.class, () -> {
            ecService.updateClientDetailsEc(clientIds, 2);
        });
    }

    @Test
    public void test_eCECStatusValidation_no_clients() {
        List<String> clientIds = new ArrayList<String>(Arrays.asList("acb12345", "def45678"));
        doReturn(new ArrayList<>()).when(ecDao).getECMigrationStatus(anyList());
        List<String> clientLoginNames = ecService.validateECMigrationStatus(clientIds);
        assertEquals(0, clientLoginNames.size());
    }

    /*@Test
    public void test_eCECStatusValidation_one_client() {
        List<String> clientIds = new ArrayList<String>(Arrays.asList("acb12345", "def45678"));
        ClientDetail clientDetail = new ClientDetail();
        clientDetail.setMigrationStatus(2);
        clientDetail.setClientLoginName("acb12345");
        List<ClientDetail> clientDetails = new ArrayList<>();
        clientDetails.add(clientDetail);

        doReturn(clientDetails).when(ecDao).getECMigrationStatus(anyList());
        List<String> clientLoginNames = ecService.validateECMigrationStatus(clientIds);
        assertEquals(1, clientLoginNames.size());
    }*/

    @BeforeEach
    public void before() {
        ReflectionTestUtils.setField(ecService, "ecClientUrl", "test");
        ReflectionTestUtils.setField(ecService, "enableECValidation", true);
    }
}