package com.svb.gateway.migration.ipay.batch.util;

import com.svb.gateway.migration.common.utility.FrequencyPeriod;
import org.junit.Assert;
import org.junit.jupiter.api.Test;

import java.util.List;

class IPayConstantsTest {

    @Test
    void getValidFrequencies() {
        List<Character> validFrequencyCodes=IPayConstants.getValidFrequencies();
        for(FrequencyPeriod fp:FrequencyPeriod.values()){
            Assert.assertTrue(validFrequencyCodes.contains(fp.getCode()));
        }
    }
}
