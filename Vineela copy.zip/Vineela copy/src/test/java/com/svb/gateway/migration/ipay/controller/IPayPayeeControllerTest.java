package com.svb.gateway.migration.ipay.controller;

import com.svb.gateway.migration.common.exception.ServiceException;
import com.svb.gateway.migration.ipay.service.IPayPayeesService;
import com.svb.gateway.migration.job.model.CreateJobResponse;
import com.svb.gateway.migration.job.model.CreateJobResponseData;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentMatchers;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.web.util.NestedServletException;

import static com.svb.gateway.migration.TestUtil.*;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.doNothing;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@AutoConfigureMockMvc
public class IPayPayeeControllerTest {

    @Autowired
    private MockMvc mockMvc;
    @Mock
    private IPayPayeesService payeesService;


    @Test
    @WithMockUser(username = TEST_USER_USER1, password = TEST_USER1_VALID_PASSWORD, authorities = TEST_USER1_ROLE_EXECUTE)
    public void ipayControllerTest3() throws Exception {
        Mockito.when(payeesService.ipay2stageJobLauncher(ArgumentMatchers.anyString(), ArgumentMatchers.anyLong())).thenReturn(new CreateJobResponse(
                new CreateJobResponseData(3L, "Completed")));
        try {
            this.mockMvc.perform(post("/api/ipay/ipay2Stage").contentType(MediaType.APPLICATION_JSON_VALUE)
                    .header("Authorization", "Basic Y3JtdXNlcjI6QWNjZXNzMTIz")
                    .param("ecClientId", "").param("jobId", "0"))
                    .andExpect(result -> {
                        assertTrue(result.getResolvedException() instanceof ServiceException);
                    });
        } catch (Exception se) {

        }
    }

    @Test
    @WithMockUser(username = TEST_USER_USER1, password = TEST_USER1_VALID_PASSWORD, authorities = TEST_USER1_ROLE_EXECUTE)
    public void ipayControllerTest() throws Exception {
        Mockito.when(payeesService.ipay2stageJobLauncher(ArgumentMatchers.anyString(), ArgumentMatchers.anyLong())).thenReturn(new CreateJobResponse(
                new CreateJobResponseData(3L, "Completed")));
        try {
            this.mockMvc.perform(post("/api/ipay/ipay2Stage").contentType(MediaType.APPLICATION_JSON_VALUE)
                    .header("Authorization", "Basic Y3JtdXNlcjI6QWNjZXNzMTIz")
                    .param("ecClientId", "test").param("jobId", "25"))
                    .andExpect(status().isAccepted());
        } catch (Exception se) {

        }
    }


    @Test
    @WithMockUser(username = TEST_USER_USER1, password = TEST_USER1_VALID_PASSWORD, authorities = TEST_USER1_ROLE_EXECUTE)
    public void ipayControllerCleanUp() throws Exception {
        doNothing().when(payeesService).truncateIPaySrcTables();

        this.mockMvc.perform(get("/api/ipay/cleanupIPaySrc").contentType(MediaType.APPLICATION_JSON_VALUE)
                .header("Authorization", "Basic Y3JtdXNlcjI6QWNjZXNzMTIz"))
                .andExpect(status().isOk());

    }
}
