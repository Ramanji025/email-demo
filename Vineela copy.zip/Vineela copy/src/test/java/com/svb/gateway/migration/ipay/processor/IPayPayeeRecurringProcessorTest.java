package com.svb.gateway.migration.ipay.processor;

import com.svb.gateway.migration.common.DataProvider;
import com.svb.gateway.migration.ipay.batch.dto.IPayRecurringPayments;
import com.svb.gateway.migration.ipay.batch.processors.IPayRecurringProcessor;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

@SpringBootTest
@ExtendWith(SpringExtension.class)
public class IPayPayeeRecurringProcessorTest {

    private IPayRecurringProcessor payRecurringProcessor;
    static String dataM = "{\"subscriberId\":\"4079954\",\"payeeRelationshipNumber\":\"20\",\"payeeAmount\":\"17000\",\"" +
            "paymentDate\":\"24/Dec/20\",\"paymentDate2\":\"31/Dec/20\",\"paymentEndDate\":null,\"paymentFrequency\":\"M\"," +
            "\"ecClientId\":\"acci4777\",\"beneficiaryId\":\"97\",\"subscriberAccountNumber\":\"3302834564\"," +
            "\"transactionType\":\"ACH\",\"numberOccurencesRemaing\":null,\"createdBy\":\"MIGRATION_BANKUSER\",\"jobId\":1612799739552}";
    static String dataW= "{\"subscriberId\":\"4079954\",\"payeeRelationshipNumber\":\"20\",\"payeeAmount\":\"17000\",\"" +
            "paymentDate\":\"24/Dec/20\",\"paymentDate2\":\"31/Dec/20\",\"paymentEndDate\":null,\"paymentFrequency\":\"W\"," +
            "\"ecClientId\":\"acci4777\",\"beneficiaryId\":\"97\",\"subscriberAccountNumber\":\"3302834564\"," +
            "\"transactionType\":\"ACH\",\"numberOccurencesRemaing\":null,\"createdBy\":\"MIGRATION_BANKUSER\",\"jobId\":1612799739552}";
    static String dataB = "{\"subscriberId\":\"4079954\",\"payeeRelationshipNumber\":\"20\",\"payeeAmount\":\"17000\",\"" +
            "paymentDate\":\"24/Dec/20\",\"paymentDate2\":\"31/Dec/20\",\"paymentEndDate\":null,\"paymentFrequency\":\"B\"," +
            "\"ecClientId\":\"acci4777\",\"beneficiaryId\":\"97\",\"subscriberAccountNumber\":\"3302834564\"," +
            "\"transactionType\":\"ACH\",\"numberOccurencesRemaing\":null,\"createdBy\":\"MIGRATION_BANKUSER\",\"jobId\":1612799739552}";
    static String dataT = "{\"subscriberId\":\"4079954\",\"payeeRelationshipNumber\":\"20\",\"payeeAmount\":\"17000\",\"" +
            "paymentDate\":\"24/Dec/20\",\"paymentDate2\":\"31/Dec/20\",\"paymentEndDate\":null,\"paymentFrequency\":\"T\"," +
            "\"ecClientId\":\"acci4777\",\"beneficiaryId\":\"97\",\"subscriberAccountNumber\":\"3302834564\"," +
            "\"transactionType\":\"ACH\",\"numberOccurencesRemaing\":null,\"createdBy\":\"MIGRATION_BANKUSER\",\"jobId\":1612799739552}";
    static String dataQ = "{\"subscriberId\":\"4079954\",\"payeeRelationshipNumber\":\"20\",\"payeeAmount\":\"17000\",\"" +
            "paymentDate\":\"24/Dec/20\",\"paymentDate2\":\"31/Dec/20\",\"paymentEndDate\":null,\"paymentFrequency\":\"Q\"," +
            "\"ecClientId\":\"acci4777\",\"beneficiaryId\":\"97\",\"subscriberAccountNumber\":\"3302834564\"," +
            "\"transactionType\":\"ACH\",\"numberOccurencesRemaing\":null,\"createdBy\":\"MIGRATION_BANKUSER\",\"jobId\":1612799739552}";



    @BeforeEach
    public void beforeEach() {

        payRecurringProcessor = new IPayRecurringProcessor();
    }

   @Test
    public  void testProcessWithFreqTypeM()  throws Exception{

       IPayRecurringPayments dataProcessor = (IPayRecurringPayments) DataProvider.getGenericObject(dataM, IPayRecurringPayments.class);
       IPayRecurringPayments payees  = payRecurringProcessor.process(dataProcessor);
        assertEquals(payees.getPaymentFrequency(),"M");
    }

    @Test
    public  void testProcessWithFreqTypeW()  throws Exception{

        IPayRecurringPayments dataProcessor = (IPayRecurringPayments) DataProvider.getGenericObject(dataW, IPayRecurringPayments.class);
        IPayRecurringPayments payees  = payRecurringProcessor.process(dataProcessor);
        assertEquals(payees.getPaymentFrequency(),"W");
    }

    @Test
    public  void testProcessWithFreqTypeB()  throws Exception{

        IPayRecurringPayments dataProcessor = (IPayRecurringPayments) DataProvider.getGenericObject(dataB, IPayRecurringPayments.class);
        IPayRecurringPayments payees  = payRecurringProcessor.process(dataProcessor);
        assertEquals(payees.getPaymentFrequency(),"B");
    }

    @Test
    public  void testProcessWithFreqTypeT()  throws Exception{

        IPayRecurringPayments dataProcessor = (IPayRecurringPayments) DataProvider.getGenericObject(dataT, IPayRecurringPayments.class);
        IPayRecurringPayments payees  = payRecurringProcessor.process(dataProcessor);
        assertEquals(payees.getPaymentFrequency(),"T");
    }

    @Test
    public  void testProcessWithFreqTypeQ()  throws Exception{

        IPayRecurringPayments dataProcessor = (IPayRecurringPayments) DataProvider.getGenericObject(dataQ, IPayRecurringPayments.class);
        IPayRecurringPayments payees  = payRecurringProcessor.process(dataProcessor);
        assertEquals(payees.getPaymentFrequency(),"Q");
    }
}
