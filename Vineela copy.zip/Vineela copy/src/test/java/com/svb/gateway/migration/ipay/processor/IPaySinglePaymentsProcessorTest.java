package com.svb.gateway.migration.ipay.processor;

import com.svb.gateway.migration.common.DataProvider;
import com.svb.gateway.migration.ipay.batch.dto.IPaySinglePayments;
import com.svb.gateway.migration.ipay.batch.processors.IPaySinglePaymentsProcessor;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import static org.junit.jupiter.api.Assertions.assertNotNull;

@SpringBootTest
@ExtendWith(SpringExtension.class)
public class IPaySinglePaymentsProcessorTest {

    private IPaySinglePaymentsProcessor payPayeeProcessor;

    static String data = "{\"subscriberId\":3696054,\"payeeRelationshipNumber\":\"32\",\"paymentId\":\"**** Systems\"," +
            "\"paymentAmount\":\"95400017188\",\"paymentDate\":\"**** SYSTEMS\"," +
            "\"subscriberBankAcctId\":null,\"createdBy\":null,\"transactionType\":null,\"jobId\":\"08838\"," +
            "\"beneficiaryId\":\"MIGRATION_BANKUSER \"}";

    @BeforeEach
    public void beforeEach() {
        payPayeeProcessor = new IPaySinglePaymentsProcessor();
    }

    @Test
    public  void testProcess()  throws Exception{

        IPaySinglePayments dataProcessor = (IPaySinglePayments) DataProvider.getGenericObject(data, IPaySinglePayments.class);
        IPaySinglePayments payees  = payPayeeProcessor.process(dataProcessor);
        assertNotNull(payees);
    }

}
