package com.svb.gateway.migration.job.controller;

import com.svb.gateway.migration.client.entity.MigClient;
import com.svb.gateway.migration.common.exception.ServiceException;
import com.svb.gateway.migration.job.entity.ClientEntity;
import com.svb.gateway.migration.job.entity.JobEntity;
import com.svb.gateway.migration.job.entity.MigJob;
import com.svb.gateway.migration.job.mapper.ClientMapper;
import com.svb.gateway.migration.job.mapper.JobMapper;
import com.svb.gateway.migration.job.model.ClientEntityList;
import com.svb.gateway.migration.job.model.CreateJobResponse;
import com.svb.gateway.migration.job.model.JobResponse;
import com.svb.gateway.migration.job.repository.MigClientrepository;
import com.svb.gateway.migration.job.repository.MigJobRepository;
import com.svb.gateway.migration.job.service.JobService;
import com.svb.gateway.migration.job.service.LoadService;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentMatchers;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.exceptions.base.MockitoException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.web.client.RestTemplate;

import java.util.*;

import static com.svb.gateway.migration.TestUtil.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@AutoConfigureMockMvc
@Slf4j
@WithMockUser(authorities = TEST_USER1_ROLE_EXECUTE)
public class JobControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private JobMapper jobMapper;

    @MockBean
    private ClientMapper clientMapper;
    @MockBean
    private MigClientrepository clientRepository;
    @MockBean
    private JobService jobService;
    @Mock
    private RestTemplate restTemplate;
    @MockBean
    private LoadService loadService;
    @MockBean
    private MigJobRepository migJobRepository;

    @BeforeEach
    public void setup() {
        Mockito.when(jobMapper.insertJob(ArgumentMatchers.any())).thenReturn(1);
        Mockito.when(clientMapper.InsertMigratingClient(ArgumentMatchers.any())).thenReturn(1);
        Mockito.when(clientRepository.saveAll(ArgumentMatchers.anyCollection())).thenReturn(Collections.EMPTY_LIST);
    }

    @Test
    @WithMockUser(username = TEST_USER_USER1, password = TEST_USER1_VALID_PASSWORD, authorities = TEST_USER1_ROLE_EXECUTE)
    public void createJobTestWithValidFile() throws Exception {

        MockMultipartFile csvFile = new MockMultipartFile("test.csv", "", "text/csv",
                ("EC_CLIENT_ID,COMPANY_ID\n" +
                        "konk1806,KONKLAB\n" +
                        "dalt5842,DALTFRESH\n").getBytes());
        Mockito.when(restTemplate
                .postForEntity(ArgumentMatchers.any(), ArgumentMatchers.any(), ArgumentMatchers.any()))
                .thenReturn(new ResponseEntity<Object>(new CreateJobResponse(), HttpStatus.ACCEPTED));
        JobEntity je = new JobEntity();
        je.setJobId(123l);
        Mockito.when(jobService.createJob(ArgumentMatchers.anyList())).thenReturn(je);
        mockMvc.perform(MockMvcRequestBuilders.multipart("/v1/api/job")
                .file("file", csvFile.getBytes()).header("Authorization", "Basic Y3JtdXNlcjI6QWNjZXNzMTIz")
                .characterEncoding("UTF-8"))
                .andExpect(status().isAccepted());

    }

    @Test
    @WithMockUser(username = TEST_USER_USER1, password = TEST_USER1_VALID_PASSWORD, authorities = TEST_USER1_ROLE_EXECUTE)
    public void createJobTestWithValidFileWithException() throws Exception {
        Mockito.when(restTemplate
                .postForEntity(ArgumentMatchers.any(), ArgumentMatchers.any(), ArgumentMatchers.any()))
                .thenThrow(MockitoException.class);
        MockMultipartFile csvFile = new MockMultipartFile("test.csv", "", "text/csv",
                ("EC_CLIENT_ID,COMPANY_ID\n" +
                        "konk1806,KONKLAB\n" +
                        "dalt5842,DALTFRESH\n" +
                        "veri8547,VERIBET\n" +
                        "viva5198,VIVA\n" +
                        "tree5468,TREEFLEX\n" +
                        "jobs4512,JOB\n" +
                        "viva6733,VIVA\n" +
                        "cook8601,COOKLEY\n" +
                        "fint5212,FINTONE\n" +
                        "trip0128,TRIPPLEDEX").getBytes());
        Mockito.when(jobService.parseCSVFile(csvFile)).thenReturn(Collections.nCopies(5, new ClientEntity()));
        JobEntity je = new JobEntity();
        je.setJobId(123l);
        Mockito.when(jobService.createJob(ArgumentMatchers.anyList())).thenReturn(je);
        mockMvc.perform(MockMvcRequestBuilders.multipart("/v1/api/job")
                .file("file", csvFile.getBytes()).header("Authorization", "Basic Y3JtdXNlcjI6QWNjZXNzMTIz")
                .characterEncoding("UTF-8"))
                .andExpect(status().isAccepted());

    }

    @Test
    @WithMockUser(username = TEST_USER_USER1, password = TEST_USER1_VALID_PASSWORD, authorities = TEST_USER1_ROLE_EXECUTE)
    public void createJobTestWithInvalidFile() throws Exception {
        Mockito.when(restTemplate
                .postForEntity(ArgumentMatchers.any(), ArgumentMatchers.any(), ArgumentMatchers.any()))
                .thenThrow(MockitoException.class);
        MockMultipartFile csvFile = new MockMultipartFile("test.pdf", "", "text/csv",
                ("").getBytes());
        Mockito.when(jobService.parseCSVFile(ArgumentMatchers.any())).thenThrow(ServiceException.class);
        JobEntity je = new JobEntity();
        je.setJobId(123l);
        Mockito.when(jobService.createJob(ArgumentMatchers.anyList())).thenReturn(je);
        mockMvc.perform(MockMvcRequestBuilders.multipart("/v1/api/job")
                .file("file", csvFile.getBytes()).header("Authorization", "Basic Y3JtdXNlcjI6QWNjZXNzMTIz")
                .characterEncoding("UTF-8"))
                .andExpect(status().isBadRequest());

    }

    @Test
    @WithMockUser(username = TEST_USER_USER1, password = TEST_USER1_VALID_PASSWORD, authorities = TEST_USER1_ROLE_EXECUTE)
    public void createJobTestWith400Status() throws Exception {
        Mockito.when(restTemplate
                .postForEntity(ArgumentMatchers.any(), ArgumentMatchers.any(), ArgumentMatchers.any()))
                .thenReturn(ResponseEntity.ok(new Object()));
        MockMultipartFile csvFile = new MockMultipartFile("test.csv", "", "text/csv",
                ("EC_CLIENT_ID,COMPANY_ID\n" +
                        "konk1806,KONKLAB\n" +
                        "dalt5842,DALTFRESH\n" +
                        "veri8547,VERIBET\n" +
                        "viva5198,VIVA\n" +
                        "tree5468,TREEFLEX\n" +
                        "jobs4512,JOB\n" +
                        "viva6733,VIVA\n" +
                        "cook8601,COOKLEY\n" +
                        "fint5212,FINTONE\n" +
                        "trip0128,TRIPPLEDEX").getBytes());
        Mockito.when(jobService.parseCSVFile(csvFile)).thenReturn(Collections.nCopies(5, new ClientEntity()));
        JobEntity je = new JobEntity();
        je.setJobId(123l);
        Mockito.when(jobService.createJob(ArgumentMatchers.anyList())).thenReturn(je);
        mockMvc.perform(MockMvcRequestBuilders.multipart("/v1/api/job")
                .file("file", csvFile.getBytes()).header("Authorization", "Basic Y3JtdXNlcjI6QWNjZXNzMTIz")
                .characterEncoding("UTF-8"))
                .andExpect(status().isAccepted());

    }

    @Test
    @WithMockUser(username = TEST_USER_USER1, password = TEST_USER1_VALID_PASSWORD, authorities = TEST_USER1_ROLE_EXECUTE)
    public void createJobTest() throws Exception {
        Mockito.when(restTemplate
                .postForEntity(ArgumentMatchers.any(), ArgumentMatchers.any(), ArgumentMatchers.any()))
                .thenReturn(ResponseEntity.ok(new Object()));
        MockMultipartFile csvFile = new MockMultipartFile("test.csv", "", "text/csv",
                ("EC_CLIENT_ID,COMPANY_ID\n"
                ).getBytes());
        Mockito.when(jobService.parseCSVFile(csvFile)).thenThrow(new ServiceException("Something error"));
        JobEntity je = new JobEntity();
        je.setJobId(123l);
        Mockito.when(jobService.createJob(ArgumentMatchers.anyList())).thenReturn(je);
        mockMvc.perform(MockMvcRequestBuilders.multipart("/v1/api/job")
                .file("file", csvFile.getBytes()).header("Authorization", "Basic Y3JtdXNlcjI6QWNjZXNzMTIz")
                .characterEncoding("UTF-8"))
                .andExpect(status().isAccepted());
    }


    @Test
    @WithMockUser(username = TEST_USER_USER1, password = TEST_USER1_VALID_PASSWORD, authorities = TEST_USER1_ROLE_EXECUTE)
    public void createJobTestWith201Clients() throws Exception {
        Resource file = new ClassPathResource("JobAPI201ClientsData.csv");
        MockMultipartFile jsonFile = new MockMultipartFile("test.csv", file.getInputStream());
        ClientEntity el = new ClientEntity();
        el.setCompanyId("String");
        el.setECClientId("String");
        Mockito.when(jobService.parseCSVFile(ArgumentMatchers.any())).thenReturn(Collections.nCopies(201, el));
        mockMvc.perform(MockMvcRequestBuilders.multipart("/v1/api/job")
                .file("file", jsonFile.getBytes()).header("Authorization", "Basic Y3JtdXNlcjI6QWNjZXNzMTIz")
                .characterEncoding("UTF-8"))
                .andExpect(status().isBadRequest());
    }

    @Test
    @WithMockUser(username = TEST_USER_USER1, password = TEST_USER1_VALID_PASSWORD, authorities = TEST_USER1_ROLE_EXECUTE)
    public void getJobTest() throws Exception {
        Mockito.when(jobService.getJobById(248)).thenReturn(new JobResponse());
        this.mockMvc.perform(get("/v1/api/job").param("jobId", "248")
                .header("Authorization", "Basic Y3JtdXNlcjQ6QWNjZXNzMTIz")).andExpect(status().isOk());
    }

    @Test
    public void getJobTestWithInvalidJobId() throws Exception {
        Mockito.when(jobService.getJobById(000)).thenReturn(null);
        this.mockMvc.perform(get("/v1/api/job")
                .param("jobId", "000")).andExpect(status().isNotFound());
    }


    @Test
    public void getJobMigrationTest() throws Exception {
        Mockito.when(jobService.getJobById(000)).thenReturn(null);
        Map<MigJob, List<MigClient>> processResponse = new HashMap<>();
        MigJob job = new MigJob();
        job.setJobId(569L);
        job.setStatus("Completed");
        MigClient client = new MigClient();
        client.setJobId(569L);
        client.setStatus("Completed");
        List<MigClient> clients = new ArrayList<>();
        clients.add(client);
        processResponse.put(job, clients);
        Mockito.when(loadService.validateAndPersistLoadRequest(ArgumentMatchers.anyLong(), ArgumentMatchers.anyList())).thenReturn(processResponse);
        this.mockMvc.perform(post("/v1/api/job/load/125")).andExpect(status().isAccepted());
    }

    @Test
    public void getJobMigrationTest01() throws Exception {
        Mockito.when(jobService.getJobById(000)).thenReturn(null);
        MigJob job = new MigJob();
        job.setStatus("Completed");
        Mockito.when(migJobRepository.findByJobIdStatsExtractionProgress(ArgumentMatchers.anyLong())).thenReturn(job);
        this.mockMvc.perform(post("/v1/api/job/load/125")).andExpect(status().isAccepted());
    }

    @Test
    public void getJobMigrationTest02() throws Exception {
        Mockito.when(jobService.getJobById(000)).thenReturn(null);
        Map<MigJob, List<MigClient>> processResponse = new HashMap<>();
        MigJob job = new MigJob();
        job.setStatus("Completed");
        Mockito.when(migJobRepository.findByJobIdStatsExtractionProgress(ArgumentMatchers.anyLong())).thenReturn(job);
        this.mockMvc.perform(post("/v1/api/job/load/125")).andExpect(status().isAccepted());
    }

    @Test
    public void getJobMigrationTest2() throws Exception {
        Mockito.when(jobService.getJobById(000)).thenReturn(null);
        Map<MigJob, List<MigClient>> processResponse = new HashMap<>();
        MigJob job = new MigJob();
        job.setJobId(569L);
        job.setStatus("Completed");
        MigClient client = new MigClient();
        client.setJobId(569L);
        client.setStatus("Completed");
        List<MigClient> clients = new ArrayList<>();
        clients.add(client);
        processResponse.put(job, clients);
        Mockito.when(loadService.validateAndPersistLoadRequest(ArgumentMatchers.anyLong(), ArgumentMatchers.anyList())).thenReturn(processResponse);
        log.info("[\"test\",\"test2\"] ");
        this.mockMvc.perform(post("/v1/api/job/load/125?clientEntityList=test&clientEntityList=tes2")
                .content("[\"test\",\"test2\"]")
                .contentType(MediaType.APPLICATION_JSON)).andExpect(status().isAccepted());
    }

    @Test
    public void getJobMigrationTest21() throws Exception {
        Mockito.when(jobService.getJobById(000)).thenReturn(null);
        Map<MigJob, List<MigClient>> processResponse = new HashMap<>();
        MigJob job = new MigJob();
        job.setJobId(569L);
        job.setStatus("Completed");
        MigClient client = new MigClient();
        client.setJobId(569L);
        client.setStatus("Completed");
        List<MigClient> clients = new ArrayList<>();
        clients.add(client);
        processResponse.put(job, clients);
        Mockito.when(loadService.validateAndPersistLoadRequest(ArgumentMatchers.anyLong(), ArgumentMatchers.anyList())).thenReturn(processResponse);
        log.info("[\"test\",\"test2\"] ");
        this.mockMvc.perform(post("/v1/api/job/load/125?null")
                .content("[\"test\",\"test2\"]")
                .contentType(MediaType.APPLICATION_JSON)).andExpect(status().isAccepted());
    }

    @Test
    public void getJobMigrationTest3() throws Exception {
        Mockito.when(jobService.getJobById(000)).thenReturn(null);
        List<String> entityList = new ArrayList<>();
        entityList.add("test");
        ClientEntityList clientEntityList = new ClientEntityList();
        clientEntityList.setClientEntityList(entityList);
        Map<MigJob, List<MigClient>> processResponse = new HashMap<>();
        MigJob job = new MigJob();
        job.setJobId(569L);
        job.setStatus("Completed");
        processResponse.put(job, null);
        Mockito.when(loadService.validateAndPersistLoadRequest(ArgumentMatchers.anyLong(), ArgumentMatchers.anyList())).thenReturn(processResponse);
        this.mockMvc.perform(post("/v1/api/job/load/125?clientEntityList=test&clientEntityList=tes2")
                .contentType(MediaType.APPLICATION_JSON)).andExpect(status().isAccepted());
    }

    @Test
    public void getJobMigrationTest5() throws Exception {
        Mockito.when(jobService.getJobById(125)).thenReturn(null);
        Map<MigJob, List<MigClient>> processResponse = new HashMap<>();
        Mockito.when(loadService.validateAndPersistLoadRequest(ArgumentMatchers.anyLong(), ArgumentMatchers.anyList())).thenReturn(processResponse);
        this.mockMvc.perform(post("/v1/api/job/load/125?clientEntityList=test&clientEntityList=tes2")
                .content("[\"test\",\"test2\"]")
                .contentType(MediaType.APPLICATION_JSON)).andExpect(status().isAccepted());
    }
}
