package com.svb.gateway.migration.job.service;

import com.svb.gateway.migration.common.exception.ServiceException;
import com.svb.gateway.migration.common.model.CsvClient;
import com.svb.gateway.migration.common.service.RetryService;
import com.svb.gateway.migration.common.utility.JobStatusEnum;
import com.svb.gateway.migration.ipay.service.IPayPayeesService;
import com.svb.gateway.migration.job.entity.ClientEntity;
import com.svb.gateway.migration.job.entity.JobEntity;
import com.svb.gateway.migration.job.mapper.ClientMapper;
import com.svb.gateway.migration.job.mapper.JobMapper;
import com.svb.gateway.migration.job.model.CreateJobResponse;
import com.svb.gateway.migration.job.model.CreateJobResponseData;
import com.svb.gateway.migration.job.repository.MigClientrepository;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.mockito.*;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.retry.support.RetryTemplate;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.client.RestTemplate;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;

@SpringBootTest
@RunWith(MockitoJUnitRunner.class)
class JobServiceTest {
    @Mock
    private RetryService retryService;
    @Mock
    private RestTemplate restTemplate;
    @Mock
    private JobMapper jobMapper;
    @Mock
    private MigClientrepository clientrepository;
    @InjectMocks
    @Spy
    private JobService jobService;
    private List<ClientEntity> clientEntities;
    @Mock
    private ClientMapper clientMapper;
    @Mock
    private IPayPayeesService iPayPayeesService;

    @BeforeEach
    public void before() {
        Mockito.when(jobMapper.insertJob(ArgumentMatchers.any())).thenReturn(1);
        Mockito.when(clientrepository.saveAll(ArgumentMatchers.anyCollection())).thenReturn(Collections.EMPTY_LIST);
        doNothing().when(clientMapper).InsertMigratingClients(ArgumentMatchers.anyList());
        clientEntities = new ArrayList<>();
        ClientEntity entity = new ClientEntity();
        entity.setECClientId("mig23498");
        clientEntities.add(entity);
        ReflectionTestUtils.setField(jobService, "COMPANY_ID_LENGTH_MAX", 10);
        ReflectionTestUtils.setField(jobService, "COMPANY_ID_LENGTH_MIN", 3);
        ReflectionTestUtils.setField(jobService, "EC_CLIENT_ID_LENGTH", 8);
        ReflectionTestUtils.setField(jobService, "maxCompanyIdAttempts", 2);
        ReflectionTestUtils.setField(jobService, "admextBaseHost", "host");
        ResponseEntity<String> response = new ResponseEntity<>("true", HttpStatus.ACCEPTED);
        doReturn(response).when(retryService).exchange(anyString(),
                Mockito.any(HttpMethod.class), Mockito.any(HttpEntity.class),Mockito.any(ParameterizedTypeReference.class));
        jobService.retryService = retryService;
    }

    @Test
    void testGenerateRandomClientId() {
        String companyId = jobService.generateCompanyId("abcd1234");
        assertTrue(companyId.startsWith("abcd"));
        assertEquals(8,companyId.length());
    }

    @Test
    void testGetCompanyIdNoExistingCompanyIds() throws ServiceException {
        ResponseEntity<String> response = new ResponseEntity<>("true", HttpStatus.ACCEPTED);
        doReturn(response).when(retryService).exchange(Mockito.anyString(),
                Mockito.any(HttpMethod.class), Mockito.any(HttpEntity.class),Mockito.any(ParameterizedTypeReference.class));
        String companyId = jobService.getCompanyId("abcd1234");
        assertEquals("abcd1234",companyId);
        assertEquals(8,companyId.length());
    }

    @Test
    void testGetCompanyIdExistingCompanyIdsOneRetry() throws ServiceException {
        ResponseEntity<String> response = new ResponseEntity<>("true", HttpStatus.ACCEPTED);
        doReturn(response).when(retryService).exchange(eq(jobService.protocol+"://"+jobService.admextBaseHost+jobService.companyIdCheckEndpoint+"abcd1234"),
                Mockito.any(HttpMethod.class), Mockito.any(HttpEntity.class),Mockito.any(ParameterizedTypeReference.class));
        String companyId = jobService.getCompanyId("abcd1234");
        assertTrue(companyId.startsWith("abcd"));
        assertEquals(8,companyId.length());
    }

    @Test
    void testGetCompanyIdExistingCompanyIdsTooManyTries() {
        ResponseEntity<String> response = new ResponseEntity<>("false", HttpStatus.ACCEPTED);
        doReturn(response).when(retryService).exchange(Mockito.anyString(),
                Mockito.any(HttpMethod.class), Mockito.any(HttpEntity.class),Mockito.any(ParameterizedTypeReference.class));
        try {
            jobService.getCompanyId("abcd1234");
        } catch (ServiceException e) {
            assertEquals("too many attempts to produce a companyId for abcd1234",e.getErrorMessage());
        }
    }

    @Test
    void testValidClients() {
        ResponseEntity<CreateJobResponse> response = new ResponseEntity<>(new CreateJobResponse(), HttpStatus.ACCEPTED);
        doReturn(response).when(restTemplate).exchange(Mockito.anyString(),
                Mockito.any(HttpMethod.class), Mockito.any(HttpEntity.class),eq(CreateJobResponse.class));
        jobService.migStageUrl = "TestUrl";
            jobService.createJob(clientEntities);
    }

    @Test
    void testValidClients_2() {
        ResponseEntity<CreateJobResponse> response = new ResponseEntity<>(new CreateJobResponse(), HttpStatus.ACCEPTED);
        doReturn(response).when(restTemplate).exchange(Mockito.anyString(),
                Mockito.any(HttpMethod.class), Mockito.any(HttpEntity.class),eq(CreateJobResponse.class));
        jobService.migStageUrl = "TestUrl";
        JobEntity je = new JobEntity();
        je.setJobId(123L);
        jobService.createClients(clientEntities,"", je);
    }

    @Test
    void testValidClients400() {
        ResponseEntity<CreateJobResponse> response = new ResponseEntity<>(null, HttpStatus.UNAUTHORIZED);
        doReturn(response).when(restTemplate).exchange(Mockito.anyString(),
                Mockito.any(HttpMethod.class), Mockito.any(HttpEntity.class),eq(CreateJobResponse.class));
        jobService.migStageUrl = "TestUrl";
        jobService.createJob(clientEntities);
    }

    @Test
    void testValidClients500() {
        CreateJobResponse request = new CreateJobResponse(new CreateJobResponseData()
                .status(JobStatusEnum.EXTRACTION_INPROCESS.toString()));
        ResponseEntity<CreateJobResponse> response = new ResponseEntity<>(request, HttpStatus.INTERNAL_SERVER_ERROR);
        doReturn(response).when(restTemplate).exchange(Mockito.anyString(),
                Mockito.any(HttpMethod.class), Mockito.any(HttpEntity.class),eq(CreateJobResponse.class));
        jobService.migStageUrl = "TestUrl";
        jobService.createJob(clientEntities);
    }

    @Test
    void testValidClientsThrowException() {
        doThrow(new NullPointerException()).when(restTemplate).exchange(Mockito.anyString(),
                Mockito.any(HttpMethod.class), Mockito.any(HttpEntity.class),eq(CreateJobResponse.class));
        jobService.migStageUrl = "TestUrl";
        jobService.createJob(clientEntities);
    }

    @Test
    void testValidClientsThrowException_2() {
        doThrow(new NullPointerException()).when(restTemplate).exchange(Mockito.anyString(),
                Mockito.any(HttpMethod.class), Mockito.any(HttpEntity.class),eq(CreateJobResponse.class));
        jobService.migStageUrl = "TestUrl";
        JobEntity je = new JobEntity();
        je.setJobId(123L);
        jobService.createClients(clientEntities,"", je);
    }

    @Test
    void testGetJobId() {
        jobService.getJobById(0000);
    }

    @Test
    void createJobTestWithValidFile() throws Exception {

        MockMultipartFile csvFile = new MockMultipartFile("test.csv", "", "text/csv",
                (
                "konk1806\n" +
                "dalt5842").getBytes());
        when(clientrepository.findClientEntities(Mockito.anySet(),  Mockito.anyString()))
                .thenReturn(0L);
        jobService.parseCSVFile(csvFile);
    }
    @Test
    void createJobTestWithInvalidEcId() {

        MockMultipartFile csvFile = new MockMultipartFile("test.csv", "", "text/csv",
                ("EC_CLIENT_ID\n").getBytes());
        when(clientrepository.findClientEntities(Mockito.anySet(), Mockito.anyString()))
                .thenReturn(0L);
        Assertions.assertThrows(ServiceException.class, () ->{jobService.parseCSVFile(csvFile);});
    }

    @Test
    void createJobTestWithEmptyValues() {

        MockMultipartFile csvFile = new MockMultipartFile("test.csv", "", "text/csv",
                (
                " ").getBytes());
        when(clientrepository.findClientEntities(Mockito.anySet(), Mockito.anyString()))
                .thenReturn(0L);
        Assertions.assertThrows(ServiceException.class, () ->{jobService.parseCSVFile(csvFile);});
    }

    @Test
    void createJobTestWithDuplicateValues() {

        MockMultipartFile csvFile = new MockMultipartFile("test.csv", "", "text/csv",
                (
                        "konk1806\n" +
                        "konk1806").getBytes());
        when(clientrepository.findClientEntities(Mockito.anySet(), Mockito.anyString()))
                .thenReturn(0L);
        Assertions.assertThrows(ServiceException.class, () ->{jobService.parseCSVFile(csvFile);});
    }

    @Test
    void createJobTestWithExistingValues() {

        MockMultipartFile csvFile = new MockMultipartFile("test.csv", "", "text/csv",
                (
                        "konk1806").getBytes());
        ClientEntity cl = new ClientEntity();
        cl.setECClientId("konk1806"); cl.setCompanyId("KONKLAB");
        when(clientrepository.findClientEntities(Mockito.anySet(), Mockito.anyString()))
                .thenReturn(1L);
        Assertions.assertThrows(ServiceException.class, () ->{jobService.parseCSVFile(csvFile);});
    }

    @Test
    void createJobTestWithInvalidLength() {

        MockMultipartFile csvFile = new MockMultipartFile("test.csv", "", "text/csv",
                (
                        "konk18").getBytes());
        ClientEntity cl = new ClientEntity();
        cl.setECClientId("konk1806"); cl.setCompanyId("KONKLAB");
        when(clientrepository.findClientEntities(Mockito.anySet(), Mockito.anyString()))
                .thenReturn(1L);
        Assertions.assertThrows(ServiceException.class, () ->{jobService.parseCSVFile(csvFile);});
    }
}
