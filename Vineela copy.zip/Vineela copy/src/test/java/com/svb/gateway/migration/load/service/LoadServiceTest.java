package com.svb.gateway.migration.load.service;

import com.svb.gateway.migration.beneficiaries.service.BeneficiariesService;
import com.svb.gateway.migration.cards.service.CardsService;
import com.svb.gateway.migration.client.entity.MigClient;
import com.svb.gateway.migration.client.model.EnrollClientResponse;
import com.svb.gateway.migration.client.model.EnrollClientResponseData;
import com.svb.gateway.migration.client.repository.MigClientRepository;
import com.svb.gateway.migration.client.service.ClientService;
import com.svb.gateway.migration.common.exception.ServiceException;
import com.svb.gateway.migration.common.utility.JobStatusEnum;
import com.svb.gateway.migration.job.entity.MigJob;
import com.svb.gateway.migration.job.repository.MigJobRepository;
import com.svb.gateway.migration.job.service.LoadService;
import com.svb.gateway.migration.payments.service.IpayPaymentService;
import com.svb.gateway.migration.payments.service.TransferService;
import com.svb.gateway.migration.user.service.UserService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import static com.svb.gateway.migration.common.constants.MigrationConstants.STATUS_SUCCESS;
import static junit.framework.TestCase.assertTrue;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@SpringBootTest
@ExtendWith(SpringExtension.class)
public class LoadServiceTest {

    @Mock
    MigJobRepository migJobRepository;

    @Mock
    MigClientRepository migClientRepository;

    @Mock
    ClientService clientService;

    @Mock
    UserService userService;

    @Mock
    CardsService cardsService;

    @Mock
    BeneficiariesService beneficiariesService;

    @Mock
    TransferService transferService;

    @Mock
    IpayPaymentService ipayPaymentService;

    @InjectMocks
    @Spy
    LoadService loadService;

    @Test
    public void processJobSuccess() throws Exception {

        Long jobId = 123L;
        MigJob je = new MigJob();
        je.setStatus(JobStatusEnum.MIGRATION_COMPLETED.name());
        doReturn(je).when(migJobRepository).findByJobId(any());
        doReturn(je).when(migJobRepository).findByJobIdProgress(any());
        doReturn(je).when(migJobRepository).saveAndFlush(any());
        doReturn(je).when(migJobRepository).findByJobIdOkToLoad(any());

        List<String> clients = new ArrayList<>();
        doReturn(clients).when(migClientRepository).findByJobId(any());
        doReturn(null).when(migClientRepository).findByEcClientIdandJobIdStatus(anyString(), anyLong(), anyString());

        List<EnrollClientResponse> lecr = new ArrayList<>();

        doNothing().when(loadService).startLoad(anyMap());

        Map ilr = loadService.validateAndPersistLoadRequest(jobId, clients);

        assertNotNull(ilr);

    }

    @Test
    public void processJobError_jobId() throws Exception {

        List<String> clients = new ArrayList<>();

        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            loadService.validateAndPersistLoadRequest(null, clients);
        });

        String expectedMessage = "jobId must not be null";
        String actualMessage = exception.getMessage();

        assertTrue(actualMessage.contains(expectedMessage));

    }

    @Test
    public void processJobSuccess_jobNull() throws Exception {

        Long jobId = 123L;

        doReturn(null).when(migJobRepository).findByJobId(any());
        doReturn(null).when(migJobRepository).findByJobIdProgress(any());
        List<String> clients = new ArrayList<>();

        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            loadService.validateAndPersistLoadRequest(jobId, clients);
        });
    }

    @Test
    public void processJobSuccess_clientFilter() throws Exception {
        Long jobId = 123L;
        MigJob je = new MigJob();
        je.setStatus(JobStatusEnum.MIGRATION_COMPLETED.name());

        doReturn(je).when(migJobRepository).findByJobId(any());
        doReturn(je).when(migJobRepository).findByJobIdOkToLoad(any());
        List<String> clients = new ArrayList<>();

        clients.add("addr1234");
        List<MigClient> migClients = new ArrayList<>();
        MigClient migClient = new MigClient();
        migClient.setEcClientId("addr1234");
        migClients.add(migClient);
        doReturn(migClients).when(migClientRepository).findByJobId(any());

        doReturn(null).when(migJobRepository).saveAndFlush(any());
        Map ilr = loadService.validateAndPersistLoadRequest(jobId, clients);
        assertNotNull(ilr);
    }

    @Test
    public void test_startLoad() throws Exception {

        MigJob job = new MigJob();
        job.setJobId(123L);
        job.setStatus("Completed");
        List<MigClient> migClients = new ArrayList<>();
        MigClient migClient = new MigClient();
        migClient.setEcClientId("addr1234");
        migClient.setCompanyId("cmpnyId");
        migClients.add(migClient);

        doReturn(job).when(migJobRepository).save(any());
        EnrollClientResponse enrollClientResponse = new EnrollClientResponse();
        EnrollClientResponseData data = new EnrollClientResponseData();

        data.setStatus(STATUS_SUCCESS);
        enrollClientResponse.setData(data);
        doReturn(enrollClientResponse).when(clientService).enrollClient(anyString(), anyString(), anyLong());
        doThrow(new ServiceException("Errored")).when(userService).createUsers(anyLong(), any());
        doThrow(new ServiceException("Errored")).when(userService).updateCardUserId(anyLong(), anyString());
        doThrow(new ServiceException("Errored")).when(cardsService).addCardProgramToClient(anyLong(), any());
        doReturn(null).when(beneficiariesService).addBeneficiaries(anyLong(), any(), any());
        doThrow(new ServiceException("Errored")).when(transferService).wireTransfer(anyLong(), any());
        doThrow(new ServiceException("Errored")).when(transferService).internalTransfer(anyLong(), any());
        doThrow(new ServiceException("Errored")).when(ipayPaymentService).createPayments(anyLong(), anyString());

        loadService.startLoad(Map.of(job, migClients));
    }

    @Test
    public void test_startLoad_exe() throws Exception {
        MigJob job = new MigJob();
        job.setJobId(123L);
        job.setStatus("Completed");
        List<MigClient> migClients = new ArrayList<>();
        MigClient migClient = new MigClient();
        migClient.setEcClientId("addr1234");
        migClient.setCompanyId("cmpnyId");
        migClients.add(migClient);

        doReturn(job).when(migJobRepository).save(any());
        EnrollClientResponse enrollClientResponse = new EnrollClientResponse();
        EnrollClientResponseData data = new EnrollClientResponseData();
        data.setStatus(STATUS_SUCCESS);
        enrollClientResponse.setData(data);
        doReturn(enrollClientResponse).when(clientService).enrollClient(anyString(), anyString(), anyLong());
        doThrow(new ServiceException("Errored")).when(userService).createUsers(anyLong(), any());
        doThrow(new ServiceException("Errored")).when(userService).updateCardUserId(anyLong(), anyString());
        doThrow(new ServiceException("Errored")).when(cardsService).addCardProgramToClient(anyLong(), any());
        doThrow(new ServiceException("Errored")).when(transferService).wireTransfer(anyLong(), any());
        doThrow(new ServiceException("Errored")).when(transferService).internalTransfer(anyLong(), any());
        doThrow(new ServiceException("Errored")).when(ipayPaymentService).createPayments(anyLong(), anyString());

        loadService.startLoad(Map.of(job, migClients));
    }

    @Test
    public void test_startLoad_exe2() throws Exception {

        MigJob job = new MigJob();
        job.setJobId(123L);
        job.setStatus("Completed");
        List<MigClient> migClients = new ArrayList<>();
        MigClient migClient = new MigClient();
        migClient.setEcClientId("addr1234");
        migClient.setCompanyId("cmpnyId");
        migClients.add(migClient);

        doReturn(job).when(migJobRepository).save(any());
        EnrollClientResponse enrollClientResponse = new EnrollClientResponse();
        EnrollClientResponseData data = new EnrollClientResponseData();

        data.setStatus(STATUS_SUCCESS);
        enrollClientResponse.setData(data);
        doReturn(enrollClientResponse).when(clientService).enrollClient(anyString(), anyString(), anyLong());
        doReturn(null).when(userService).createUsers(anyLong(), any());
        doReturn(null).when(userService).updateCardUserId(anyLong(), anyString());
        doReturn(null).when(cardsService).addCardProgramToClient(anyLong(), any());
        doReturn(null).when(beneficiariesService).addBeneficiaries(anyLong(), any(), any());
        doReturn(null).when(transferService).wireTransfer(anyLong(), any());
        doReturn(null).when(transferService).internalTransfer(anyLong(), any());
        doReturn(null).when(ipayPaymentService).createPayments(anyLong(), anyString());

        loadService.startLoad(Map.of(job, migClients));

    }

    @Test
    public void test_startLoad_exe3() throws Exception {
        MigJob job = new MigJob();
        job.setJobId(123L);
        job.setStatus("Completed");
        List<MigClient> migClients = new ArrayList<>();
        MigClient migClient = new MigClient();
        migClient.setEcClientId("addr1234");
        migClient.setCompanyId("cmpnyId");
        migClients.add(migClient);

        doReturn(job).when(migJobRepository).save(any());

        doThrow(new ServiceException("Errored")).when(clientService).enrollClient(anyString(), anyString(), anyLong());

        loadService.startLoad(Map.of(job, migClients));

        loadService.startLoad(Map.of(job, migClients));
    }

}
