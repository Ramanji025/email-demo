package com.svb.gateway.migration.payments.controller;

import com.svb.gateway.migration.payments.model.PaymentResponse;
import com.svb.gateway.migration.payments.service.IpayPaymentService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentMatchers;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import static org.mockito.ArgumentMatchers.anyLong;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@AutoConfigureMockMvc
class PaymentsControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    IpayPaymentService ipayPaymentService;

    PaymentResponse paymentResponse=new PaymentResponse();

    public static String clientId="acc1234";

    @BeforeEach
    public void setup() throws Exception {

        Mockito.when(ipayPaymentService.createPayments(anyLong(), ArgumentMatchers.anyString())).
                thenReturn(paymentResponse);
    }

    @Test
    public void testEnrollClient() throws Exception {

        this.mockMvc.perform(post("/api/payments/ipay/{jobId}/{clientId}","1","GWaddr9768")
                .contentType(MediaType.APPLICATION_JSON_VALUE)
                .header("Authorization","Basic Y3JtdXNlcjI6QWNjZXNzMTIz"))
                .andExpect(status().isOk());
    }
}
