package com.svb.gateway.migration.payments.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.svb.gateway.migration.client.model.MigClientDTO;
import com.svb.gateway.migration.payments.model.TransferResponse;
import com.svb.gateway.migration.payments.service.TransferService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentMatchers;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import static org.mockito.ArgumentMatchers.anyLong;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@AutoConfigureMockMvc
class TransferControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    @MockBean
    TransferService transferService;

    public static String clientId="acc1234";
    MigClientDTO migClientDTO=new MigClientDTO();

    @BeforeEach
    public void setup() throws Exception {
        migClientDTO.setEcClientId(clientId);
        TransferResponse transferResponse =new TransferResponse();
        Mockito.when(transferService.internalTransfer(anyLong(), ArgumentMatchers.any())).
                thenReturn(transferResponse);
        Mockito.when(transferService.wireTransfer(anyLong(), ArgumentMatchers.any())).
                thenReturn(transferResponse);
    }

    @Test
    public void testInternalTransfer() throws Exception {

        this.mockMvc.perform(post("/transfer/scheduled/{jobId}","1")
                .contentType(MediaType.APPLICATION_JSON_VALUE)
                .content(objectMapper.writeValueAsString(migClientDTO))
                .header("Authorization","Basic Y3JtdXNlcjI6QWNjZXNzMTIz"))
                .andExpect(status().isOk());
    }

    @Test
    public void testWireOutgoing() throws Exception {
        this.mockMvc.perform(post("/transfer/wireoutgoing/{jobId}/{clientId}","1","GWaddr9768")
                .contentType(MediaType.APPLICATION_JSON_VALUE)
                .header("Authorization","Basic Y3JtdXNlcjI6QWNjZXNzMTIz"))
                .andExpect(status().isOk());
    }

}
