package com.svb.gateway.migration.payments.mapper;

import com.svb.gateway.migration.common.utility.FrequencyPeriod;
import com.svb.gateway.migration.ipay.batch.util.IPayConstants;
import com.svb.gateway.migration.payments.entity.Payment;

import org.junit.jupiter.api.Test;

import static com.svb.gateway.migration.common.constants.MigrationConstants.STATUS_FAILURE;
import static com.svb.gateway.migration.common.constants.MigrationConstants.STATUS_IGNORE;
import static org.junit.jupiter.api.Assertions.assertEquals;


class MigrationPaymentModelMapperTest {

    @Test
    void determineStatus_Returns_DefaultDuplicateStatus() {
        Payment payment=new Payment();
        payment.setPaymentFrequency(FrequencyPeriod.MONTHLY.getCode());
        String status=MigrationPaymentModelMapper.INSTANCE.determineStatus(payment);
        assertEquals(STATUS_IGNORE, status);
    }

    @Test
    void determineStatus_Returns_InvalidFrequency_Failure() {
        Payment payment=new Payment();

        payment.setPaymentFrequency('A');
        String status=MigrationPaymentModelMapper.INSTANCE.determineStatus(payment);
        assertEquals(STATUS_FAILURE, status);

        payment.setPaymentFrequency('S');
        status=MigrationPaymentModelMapper.INSTANCE.determineStatus(payment);
        assertEquals(STATUS_FAILURE, status);

        payment.setPaymentFrequency('E');
        status=MigrationPaymentModelMapper.INSTANCE.determineStatus(payment);
        assertEquals(STATUS_FAILURE, status);

        payment.setPaymentFrequency('F');
        status=MigrationPaymentModelMapper.INSTANCE.determineStatus(payment);
        assertEquals(STATUS_FAILURE, status);


    }

    @Test
    void determineStatus_Returns_DefaultFailureStatus() {
        Payment payment=new Payment();
        payment.setOverrideAmount("123");
        String status=MigrationPaymentModelMapper.INSTANCE.determineStatus(payment);
        assertEquals(STATUS_FAILURE, status);

        payment.setOverrideAmount(null);
        payment.setSkippedPayment("1");
        status=MigrationPaymentModelMapper.INSTANCE.determineStatus(payment);
        assertEquals(STATUS_FAILURE, status);

        payment.setSkippedPayment("0");
        payment.setOverrideSubsidaryBankId("ABC123");
        status=MigrationPaymentModelMapper.INSTANCE.determineStatus(payment);
        assertEquals(STATUS_FAILURE, status);
    }

    @Test
    void addComments() {

        Payment payment=new Payment();
        payment.setOverrideAmount("123");
        String comments=MigrationPaymentModelMapper.INSTANCE.addComments(payment);
        assertEquals(IPayConstants.OVERRIDE_AMOUNT, comments);

        payment.setOverrideAmount(null);
        payment.setSkippedPayment("1");
        comments=MigrationPaymentModelMapper.INSTANCE.addComments(payment);
        assertEquals(IPayConstants.SKIPPED_PAYMENT, comments);

        payment.setSkippedPayment("0");
        payment.setOverrideSubsidaryBankId("ABC123");
        comments=MigrationPaymentModelMapper.INSTANCE.addComments(payment);
        assertEquals(IPayConstants.OVERRIDE_SUBS_BANK_ID, comments);

        payment.setOverrideSubsidaryBankId(null);
        payment.setPaymentFrequency('A');
        comments=MigrationPaymentModelMapper.INSTANCE.addComments(payment);
        assertEquals(IPayConstants.FREQUENCY_NOT_SUPPORTED + payment.getPaymentFrequency(), comments);

    }
}
