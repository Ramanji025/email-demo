package com.svb.gateway.migration.payments.service;

import com.svb.gateway.migration.common.exception.ServiceException;
import com.svb.gateway.migration.payments.entity.MigrationPayment;
import com.svb.gateway.migration.payments.entity.Payment;
import com.svb.gateway.migration.payments.model.NickName;
import com.svb.gateway.migration.payments.model.PaymentResponse;
import com.svb.gateway.migration.payments.repository.ACMXRepository;
import com.svb.gateway.migration.payments.repository.IpayPaymentsRepository;
import com.svb.gateway.migration.payments.repository.MigrationEntityRepository;
import com.svb.gateway.migration.payments.repository.MigrationPaymentsRepository;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.time.Instant;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.TimeZone;

import static com.svb.gateway.migration.common.constants.MigrationConstants.STATUS_FAILURE;
import static com.svb.gateway.migration.common.constants.MigrationConstants.STATUS_SUCCESS;
import static org.junit.Assert.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.when;

@Slf4j
@SpringBootTest
@ExtendWith(SpringExtension.class)
class IpayPaymentServiceTest {

    @Mock
    private OchPaymentService ochPaymentService;

    @Mock
    private MigrationPaymentsRepository migrationPaymentsRepository;

    @Mock
    private IpayPaymentsRepository ipayPaymentsRepository;

    @Mock
    private MigrationEntityRepository migrationEntityRepository;

    @Mock
    private ACMXRepository acmxRepository;

    @Mock
    NickName nickName;

    @InjectMocks
    @Spy
    IpayPaymentService ipayPaymentService;

    public String clientId="test0005";

    Payment payment=new Payment();

    MigrationPayment successPayment=new MigrationPayment();
    MigrationPayment newPayment=new MigrationPayment();
    MigrationPayment failurePayment=new MigrationPayment();
    List<MigrationPayment> successMigrationPaymentList=new ArrayList<>();


    @BeforeEach
    void setUp() {
        payment.setPaymentId(1000);

        failurePayment.setStatus(STATUS_FAILURE);
        failurePayment.setPaymentId(1000);
        newPayment.setEcClientId(clientId);
        newPayment.setPaymentId(1000);


        successPayment.setStatus(STATUS_SUCCESS);
        successPayment.setPaymentId(1000);
        successPayment.setEcClientId(clientId);
        successMigrationPaymentList.add(successPayment);


    }


    @Test
    void createPayments()  {
        try {
            List<Payment> paymentList=new ArrayList<>();
            paymentList.add(payment);
            when(ipayPaymentsRepository.findByEcClientId(1L, clientId)).thenReturn(paymentList);
            when(migrationPaymentsRepository.findByJobId(anyLong())).thenReturn(successMigrationPaymentList);
            when(ochPaymentService.insert(anyLong(), any(Payment.class))).thenReturn(successPayment);
            PaymentResponse response= ipayPaymentService.createPayments(1L, clientId);

            assertNotNull(response);
        } catch (ServiceException e) {
            fail();
        }
    }

    @Test
    void createPayments_ThrowsServiceException_WhenPaymentsNull()  {
        try {
            List<Payment> paymentList=new ArrayList<>();
            when(ipayPaymentsRepository.findByEcClientId(1L, clientId)).thenReturn(paymentList);

            when(migrationPaymentsRepository.findByJobId(anyLong())).thenReturn(successMigrationPaymentList);
            when(ochPaymentService.insert(anyLong(), any(Payment.class))).thenReturn(successPayment);
            PaymentResponse response= ipayPaymentService.createPayments(1L, clientId);
            fail();
        } catch (ServiceException e) {

        }
    }

    @Test
    void createPayments_ThrowsServiceException_WhenMigrationPaymentNull()  {
        try {
            List<Payment> paymentList=new ArrayList<>();
            paymentList.add(payment);

            when(ipayPaymentsRepository.findByEcClientId(1L, clientId)).thenReturn(paymentList);
            when(migrationPaymentsRepository.findByJobId(anyLong())).thenReturn(successMigrationPaymentList);
            when(ochPaymentService.insert(anyLong(), any(Payment.class))).thenReturn(successPayment);
            PaymentResponse response= ipayPaymentService.createPayments(1L, clientId);
        } catch (ServiceException e) {
            fail();
        }
    }

    @Test
    void process() {
        try {
            List<Payment> paymentList=new ArrayList<>();
            paymentList.add(payment);
            when(ipayPaymentsRepository.findByEcClientId(1L, clientId)).thenReturn(paymentList);
            when(migrationPaymentsRepository.findByJobId(anyLong())).thenReturn(null);
            when(ochPaymentService.insert(anyLong(), any(Payment.class))).thenReturn(successPayment);
            PaymentResponse paymentResponse = ipayPaymentService.process(1L, clientId);
            assertEquals(1, (int)paymentResponse.getPaymentResponseData().getRecordCount().getSuccess());
            assertEquals(0, (int)paymentResponse.getPaymentResponseData().getRecordCount().getFailure());
            assertEquals(1, (int)paymentResponse.getPaymentResponseData().getRecordCount().getTotal());
            assertEquals(STATUS_SUCCESS, paymentResponse.getPaymentResponseData().getStatus());
        } catch (ServiceException e) {
            fail();
        }
    }

    @Test
    void processWithExisiting() {
        try {
            List<Payment> paymentList=new ArrayList<>();
            paymentList.add(payment);
            when(ipayPaymentsRepository.findByEcClientId(1L, clientId)).thenReturn(paymentList);
            when(migrationPaymentsRepository.findByJobId(anyLong())).thenReturn(successMigrationPaymentList);
            when(ochPaymentService.insert(anyLong(), any(Payment.class))).thenReturn(successPayment);
            PaymentResponse paymentResponse = ipayPaymentService.process(1L, clientId);
            assertEquals(0, (int)paymentResponse.getPaymentResponseData().getRecordCount().getSuccess());
            assertEquals(0, (int)paymentResponse.getPaymentResponseData().getRecordCount().getFailure());
            assertEquals(0, (int)paymentResponse.getPaymentResponseData().getRecordCount().getTotal());
            assertEquals(STATUS_SUCCESS, paymentResponse.getPaymentResponseData().getStatus());
        } catch (ServiceException e) {
            fail(e.getMessage());
        }
    }

    @Test
    void processReRun() {
        try {
            List<MigrationPayment> newMigrationPaymentList=new ArrayList<>();
            newMigrationPaymentList.add(newPayment);

            List<Payment> paymentList=new ArrayList<>();
            paymentList.add(payment);
            when(ipayPaymentsRepository.findByEcClientId(1L, clientId)).thenReturn(paymentList);


            when(migrationPaymentsRepository.findByJobId(anyLong())).thenReturn(newMigrationPaymentList);
            when(ochPaymentService.insert(anyLong(), any(Payment.class))).thenReturn(successPayment);
            PaymentResponse paymentResponse = ipayPaymentService.process(1L, clientId);
            assertEquals(1, (int)paymentResponse.getPaymentResponseData().getRecordCount().getSuccess());
            assertEquals(0, (int)paymentResponse.getPaymentResponseData().getRecordCount().getFailure());
            assertEquals(1, (int)paymentResponse.getPaymentResponseData().getRecordCount().getTotal());
            assertEquals(STATUS_SUCCESS, paymentResponse.getPaymentResponseData().getStatus());
        } catch (ServiceException e) {
            fail(e.getMessage());
        }
    }

    @Test
    void processInvalidPayment() {
        try {
            List<Payment> paymentList=new ArrayList<>();
            payment.setOverrideAmount("100");
            paymentList.add(payment);

            List<MigrationPayment> migrationPaymentList=new ArrayList<>();
            migrationPaymentList.add(successPayment);

            when(ipayPaymentsRepository.findByEcClientId(1L, clientId)).thenReturn(paymentList);
            when(migrationPaymentsRepository.findByJobId(anyLong())).thenReturn(migrationPaymentList);
            when(ochPaymentService.insert(anyLong(), any(Payment.class))).thenReturn(successPayment);
            PaymentResponse paymentResponse = ipayPaymentService.process(1L, clientId);
            assertEquals(0, (int)paymentResponse.getPaymentResponseData().getRecordCount().getSuccess());
            assertEquals(1, (int)paymentResponse.getPaymentResponseData().getRecordCount().getFailure());
            assertEquals(1, (int)paymentResponse.getPaymentResponseData().getRecordCount().getTotal());
            assertEquals(STATUS_SUCCESS, paymentResponse.getPaymentResponseData().getStatus());
        } catch (ServiceException e) {
            fail(e.getMessage());
        }
    }

    @Test
    void processException() {
        try {
            List<Payment> paymentList=new ArrayList<>();
            paymentList.add(payment);
            when(ipayPaymentsRepository.findByEcClientId(1L, clientId)).thenReturn(paymentList);
            List<MigrationPayment> payments=new ArrayList<>();
            payments.add(failurePayment);
            when(migrationPaymentsRepository.findByJobId(anyLong())).thenReturn(payments);
            when(ochPaymentService.insert(anyLong(), any(Payment.class))).thenThrow(new ServiceException(""));
            PaymentResponse paymentResponse = ipayPaymentService.process(1L, clientId);
            assertEquals(0, (int)paymentResponse.getPaymentResponseData().getRecordCount().getSuccess());
            assertEquals(1, (int)paymentResponse.getPaymentResponseData().getRecordCount().getFailure());
            assertEquals(1, (int)paymentResponse.getPaymentResponseData().getRecordCount().getTotal());
            assertEquals(STATUS_FAILURE, paymentResponse.getPaymentResponseData().getStatus());
        } catch (ServiceException e) {
            fail(e.getMessage());
        }
    }

    @Test
    void process_nullPayment() {
        try {
            List<Payment> paymentList=new ArrayList<>();
            paymentList.add(payment);
            when(ipayPaymentsRepository.findByEcClientId(1L, clientId)).thenReturn(paymentList);
            when(migrationPaymentsRepository.findByJobId(anyLong())).thenReturn(null);
            when(ochPaymentService.insert(anyLong(), any(Payment.class))).thenReturn(successPayment);
            ipayPaymentService.process(1L, clientId);
        } catch (ServiceException e) {
            fail();
        }
    }

    private static final String PST_TIME_ZONE="America/Los_Angeles";
    private static final String TIME_ZONE= TimeZone.getTimeZone(PST_TIME_ZONE).getDisplayName(Boolean.TRUE, 0);

    @Test
    public void getPSTTime(){
        log.info("TIME ZONE is {}",TIME_ZONE);
        log.info(ZonedDateTime.ofInstant(Instant.now(), ZoneId.of(PST_TIME_ZONE)).toString());
    }
}
