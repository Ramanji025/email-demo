package com.svb.gateway.migration.payments.service;

import com.svb.gateway.migration.beneficiaries.entity.MigBeneficiary;
import com.svb.gateway.migration.beneficiaries.repository.MigBeneficiaryRepository;
import com.svb.gateway.migration.common.exception.ServiceException;

import com.svb.gateway.migration.payments.entity.*;
import com.svb.gateway.migration.payments.mapper.*;
import com.svb.gateway.migration.payments.model.NickName;

import com.svb.gateway.migration.payments.repository.*;
import com.svb.gateway.migration.payments.utils.PaymentsUtils;
import com.svb.gateway.migration.payments.entity.PAYMTransfers;
import com.svb.gateway.migration.payments.repository.PAYMRepository;
import lombok.extern.slf4j.Slf4j;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.*;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.when;
import static org.mockito.Mockito.*;

@Slf4j
@SpringBootTest
@ExtendWith(SpringExtension.class)
class OchPaymentServiceTest {

    @Mock
    TransactionRequestHeaderRepository transactionRequestHeaderRepository;

    @Mock
    TransactionRequestDetailsRepository transactionRequestDetailsRepository;

    @Mock
    CustomRequestDetailsRepository customRequestDetailsRepository;

    @Mock
    MigrationUserRepository migrationUserRepository;

    @Mock
    private MigrationPaymentsRepository migrationPaymentsRepository;

    @Mock
    private MigBeneficiaryRepository migBeneficiaryRepository;

    @Mock
    private MigrationTransferRepository migrationTransferRepository;

    @Mock MigrationWireTransferRepository migrationWireTransferRepository;

    @Mock OchTransactionHeaderRepository ochTransactionHeaderRepository;

    @Mock
    TransferMapper transferMapper;

    @Mock
    PAYMRepository paymRepository;

    @InjectMocks
    @Spy
    OchPaymentService ochPaymentService;

    MigrationUser migrationUser=new MigrationUser();
    MigBeneficiary beneficiary=new MigBeneficiary();

    PAYMTransfers paymTransfers=new PAYMTransfers();

    @BeforeEach
    void setUp() {
        migrationUser.setEcClientId("test0005");
        migrationUser.setFirstName("ABC");
        paymTransfers.setBankIdentifier("ABC");
        paymTransfers.setPaymAcctId("bene");

        beneficiary.setBeneficiaryId("123");
    }

    @Test
    void insert_throws_ServiceException() {
        try {
            ochPaymentService.insert(1L, PaymentsUtils.createPayment());
            fail();
        } catch (ServiceException e) {
        }
    }

    @Test
    void insert_IpayPayment() {
        try {
            when(migrationUserRepository.findByEcClientAndPrimaryUser(any())).thenReturn(migrationUser);
            when(migBeneficiaryRepository.findByBeneSourceForIpayMigrated(anyLong(), any())).thenReturn(beneficiary);
            MigrationPayment migrationPayment= ochPaymentService.insert(1L, PaymentsUtils.createPayment());

        } catch (ServiceException e) {
            e.printStackTrace();
            fail();
        }
    }

    @Test
    void insert_TransferPayment() {
        try {
            when(migrationUserRepository.findByEcUserLoginId(any())).thenReturn(migrationUser);
            when(migBeneficiaryRepository.findByBeneSourceForIpayMigrated(anyLong(), any())).thenReturn(beneficiary);
            MigrationInternalTransfer migrationPayment= ochPaymentService.insert(PaymentsUtils.createInternalTransfer());
            assertEquals(migrationPayment.getEcClientId(),"test0005");
        } catch (ServiceException e) {
            e.printStackTrace();
            fail();
        }
    }

    @Test
    void insert_TransferPayment_nullUser()  {
        try {
            when(migrationUserRepository.findByEcUserLoginId(any())).thenReturn(null);
            when(migBeneficiaryRepository.findByBeneSourceForIpayMigrated(anyLong(), any())).thenReturn(beneficiary);
            MigrationInternalTransfer migrationPayment = ochPaymentService.insert(PaymentsUtils.createInternalTransfer());
        } catch (ServiceException e) {
        }
    }
    @Test
    void wire_throws_ServiceException() {
        try {
            ochPaymentService.insert(1L, PaymentsUtils.createWireTransfer());
            fail();
        } catch (ServiceException e) {
        }
    }

    @Test
    void insert_WireTransferPayment() {
        try {
            when(migrationUserRepository.findByEcUserLoginId(any())).thenReturn(migrationUser);
            when(migBeneficiaryRepository.findByBeneSourceForIpayMigrated(anyLong(), any())).thenReturn(beneficiary);
            when(paymRepository.findByBnfId(any())).thenReturn(paymTransfers);
            when(migBeneficiaryRepository.findByTemplateIdandAndEcClientId(anyLong(), any(), any())).thenReturn(beneficiary);
            MigrationWireTransfer migrationPayment= ochPaymentService.insert(1L, PaymentsUtils.createWireTransfer());
            assertEquals(migrationPayment.getEcClientId(),"test0005");

        } catch (ServiceException e) {
            e.printStackTrace();
            fail();
        }
    }

    @Test
    void test_PaymentToOCH_Mapper(){
       OchTransactionRequestHeader ochTransactionRequestHeader= PaymentToOchMapper.INSTANCE.convertSinglePastPaymentToTRQH(PaymentsUtils.createPayment(), migrationUser);
        log.info(ochTransactionRequestHeader.getTxnType());
        OchTransactionRequestHeader transactionRequestHeader = TransferToOchMapper.INSTANCE.convertPastTransferToTRQH(PaymentsUtils.createInternalTransfer(), migrationUser);
    }

    @Test
    void test_convertPastTransferToTRQD(){
        OchTransactionRequestDetails transactionRequestDetails= TransferToOchMapper.INSTANCE.convertPastTransferToTRQD(PaymentsUtils.createInternalTransfer(), migrationUser);
        OchCustomRequestDetails customRequestDetails=TransferToOchMapper.INSTANCE.convertPastInternalTransferToCTRD(migrationUser);
    }

    @Test
    void test_convertWireTransferToTRQH(){
        OchTransactionRequestHeader transactionRequestHeader= WireTransferToOchMapper.INSTANCE.convertPastWireTransferToTRQH(PaymentsUtils.createWireTransfer(), migrationUser);
        assertEquals(transactionRequestHeader.getTxnType(), "FED");
        OchTransactionRequestDetails transactionRequestDetails= WireTransferToOchMapper.INSTANCE.convertPastWireTransferToTRQD(PaymentsUtils.createWireTransfer(), migrationUser);
        assertEquals(transactionRequestDetails.getNetworkId(), "FED");
    }

    @Mock
    MigrationWireTransfer migrationWireTransfer;

    @Mock
    ACMXRepository acmxRepository;
    @Mock
    NickName nickName;


    @Test
    void test_insertWireTransfer_pastDated() throws ServiceException {
        WireTransfer wireTransfer=new WireTransfer();
       wireTransfer= PaymentsUtils.createWireTransfer();

        wireTransfer.setEntryopId("user1541609");
        Calendar c = Calendar.getInstance();
        c.setTime(new Date());
        c.add(Calendar.DATE, -5);//setting past date
        Date dt = new Date();
        dt = c.getTime();

        wireTransfer.setValueDate(dt);
        when(migrationUserRepository.findByEcUserLoginId(any())).thenReturn(migrationUser);

        OchTransactionHeader ochTransactionHeader=new OchTransactionHeader();
        ochTransactionHeader.setReqId(1);
        ochTransactionHeader.setTxnId(123);
        when(ochTransactionHeaderRepository.findByReqId(any())).thenReturn(ochTransactionHeader);
        when(migBeneficiaryRepository.findByTemplateIdandAndEcClientId(anyLong(), any(),any())).thenReturn(beneficiary);
        when(paymRepository.findByBnfId(any())).thenReturn(paymTransfers);
        when(acmxRepository.findByAccId(any(),any())).thenReturn(nickName);
        migrationWireTransfer=ochPaymentService.insert(1L, wireTransfer);

    }

    @Test
    void test_insertWireTransfer_nullTemplateId() throws ServiceException {
        WireTransfer wireTransfer=new WireTransfer();
        wireTransfer= PaymentsUtils.createWireTransfer();
        wireTransfer.setTemplateId(null);
        wireTransfer.setEntryopId("user1541609");
        Calendar c = Calendar.getInstance();
        c.setTime(new Date());
        c.add(Calendar.DATE, 5);//setting past date
        Date dt = new Date();
        dt = c.getTime();

        wireTransfer.setValueDate(dt);
        when(migrationUserRepository.findByEcUserLoginId(any())).thenReturn(migrationUser);

        OchTransactionHeader ochTransactionHeader=new OchTransactionHeader();
        ochTransactionHeader.setReqId(1);
        ochTransactionHeader.setTxnId(123);
        when(ochTransactionHeaderRepository.findByReqId(any())).thenReturn(ochTransactionHeader);
        when(migBeneficiaryRepository.findByTemplateIdandAndEcClientId(anyLong(), any(),any())).thenReturn(beneficiary);
        when(paymRepository.findByBnfId(any())).thenReturn(paymTransfers);
        when(acmxRepository.findByAccId(any(),any())).thenReturn(nickName);
        migrationWireTransfer=ochPaymentService.insert(1L, wireTransfer);

    }

    @Test
    void test_insertWireTransfer() throws ServiceException {
        WireTransfer wireTransfer=new WireTransfer();
        wireTransfer= PaymentsUtils.createWireTransfer();
        wireTransfer.setTemplateId(1559733);
        wireTransfer.setEntryopId("user1541609");
        Calendar c = Calendar.getInstance();
        c.setTime(new Date());
        c.add(Calendar.DATE, 5);//setting past date
        Date dt = new Date();
        dt = c.getTime();

        wireTransfer.setValueDate(dt);
        when(migrationUserRepository.findByEcUserLoginId(any())).thenReturn(migrationUser);

        OchTransactionHeader ochTransactionHeader=new OchTransactionHeader();
        ochTransactionHeader.setReqId(1);
        ochTransactionHeader.setTxnId(123);
        when(ochTransactionHeaderRepository.findByReqId(any())).thenReturn(ochTransactionHeader);
        when(migBeneficiaryRepository.findByTemplateIdandAndEcClientId(anyLong(), any(),any())).thenReturn(beneficiary);
        when(paymRepository.findByBnfId(any())).thenReturn(paymTransfers);
        when(acmxRepository.findByAccId(any(),any())).thenReturn(nickName);
        migrationWireTransfer=ochPaymentService.insert(1L, wireTransfer);

    }

    @Test
    void test_rollbackPayments_Failure() throws ServiceException{
//        List<Long> reqIds=new ArrayList<>();
//        reqIds.add((long) 12345678);

       ochPaymentService.rollback(null) ;
}
@Mock
OchMapper ochMapper;
    @Test
    void test_rollbackPayments_Success() throws ServiceException{
        List<Long> reqIds=new ArrayList<>();
        reqIds.add((long) 6001);

doNothing().when(ochMapper).deleteTransactionRequests(Mockito.anyList(),anyString());

        ochPaymentService.rollback(reqIds) ;
    }

    @Test
    void test_rollBackPayments_EmptyReqId() {
        List<Long> reqIds= new  ArrayList<>();

        Boolean result=ochPaymentService.rollback(reqIds);
        assertEquals(result, false);
    }


    @Test
    void test_nickName_Success(){
//nickname(Nickname Type) object is going null, so always results in nickname being null
        when(acmxRepository.findByAccId(anyString(),anyString())).thenReturn(nickName);
       String nickNames= ochPaymentService.mapNickName(anyString(),anyString());
       assertNotEquals(nickNames, null);
    }

@Test
    void test_validateAndReturnBene_nonNumeric() throws ServiceException{

        WireTransfer wireTransfer=new WireTransfer();
        wireTransfer= PaymentsUtils.createWireTransfer();
        wireTransfer.setTemplateId(1559733);
        wireTransfer.setEntryopId("user1541609");
        Calendar c = Calendar.getInstance();
        c.setTime(new Date());
        c.add(Calendar.DATE, 5);//setting past date
        Date dt = new Date();
        dt = c.getTime();

        wireTransfer.setValueDate(dt);
        when(migrationUserRepository.findByEcUserLoginId(any())).thenReturn(migrationUser);
        MigBeneficiary beneNonNum=new MigBeneficiary();
        beneNonNum.setBeneficiaryId("TESTBENE");
        OchTransactionHeader ochTransactionHeader=new OchTransactionHeader();
        ochTransactionHeader.setReqId(1);
        ochTransactionHeader.setTxnId(123);
        when(ochTransactionHeaderRepository.findByReqId(any())).thenReturn(ochTransactionHeader);
        when(migBeneficiaryRepository.findByTemplateIdandAndEcClientId(anyLong(), any(),any())).thenReturn(beneNonNum);
        when(paymRepository.findByBnfId(any())).thenReturn(paymTransfers);
        when(acmxRepository.findByAccId(any(),any())).thenReturn(nickName);
        migrationWireTransfer=ochPaymentService.insert(1L, wireTransfer);

}
    @Test
    void test_validateAndReturnBene_null() throws ServiceException{

        WireTransfer wireTransfer=new WireTransfer();
        wireTransfer= PaymentsUtils.createWireTransfer();
        wireTransfer.setTemplateId(1559733);
        wireTransfer.setEntryopId("user1541609");
        Calendar c = Calendar.getInstance();
        c.setTime(new Date());
        c.add(Calendar.DATE, 5);//setting past date
        Date dt = new Date();
        dt = c.getTime();

        wireTransfer.setValueDate(dt);
        when(migrationUserRepository.findByEcUserLoginId(any())).thenReturn(migrationUser);

        OchTransactionHeader ochTransactionHeader=new OchTransactionHeader();
        ochTransactionHeader.setReqId(1);
        ochTransactionHeader.setTxnId(123);
        when(ochTransactionHeaderRepository.findByReqId(any())).thenReturn(ochTransactionHeader);
        when(migBeneficiaryRepository.findByTemplateIdandAndEcClientId(anyLong(), any(),any())).thenReturn(null);
//        when(paymRepository.findByBnfId(any())).thenReturn(paymTransfers);
//        when(acmxRepository.findByAccId(any(),any())).thenReturn(nickName);
        migrationWireTransfer=ochPaymentService.insert(1L, wireTransfer);

    }

}
