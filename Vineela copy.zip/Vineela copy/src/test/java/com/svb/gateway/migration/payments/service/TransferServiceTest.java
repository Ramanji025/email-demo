package com.svb.gateway.migration.payments.service;

import com.svb.gateway.migration.client.entity.MigClient;
import com.svb.gateway.migration.client.repository.MigClientRepository;
import com.svb.gateway.migration.common.exception.ServiceException;
import com.svb.gateway.migration.payments.entity.*;
import com.svb.gateway.migration.payments.mapper.TransferMapper;
import com.svb.gateway.migration.payments.model.TransferResponse;
import com.svb.gateway.migration.payments.repository.*;
import com.svb.gateway.migration.payments.utils.PaymentsUtils;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.util.ArrayList;
import java.util.List;

import static com.svb.gateway.migration.common.constants.MigrationConstants.*;
import static org.junit.Assert.assertEquals;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.when;

@Slf4j
@SpringBootTest
@ExtendWith(SpringExtension.class)
class TransferServiceTest {

    public String clientId="test0005";

    @Mock
    private OchPaymentService ochPaymentService;

    @Mock
    private MigrationEntityRepository migrationEntityRepository;

    @Mock
    MigClientRepository migClientRepository;

    @Mock
    InternalTransferRepository internalTransferRepository;

    @Mock
    MigrationTransferRepository migrationTransferRepository;

    @Mock
    WireTransferRepository wireTransferRepository;

    @Mock
    MigrationWireTransferRepository migrationWireTransferRepository;

    @Mock
    TransferMapper transferMapper;

    @InjectMocks
    @Spy
    TransferService transferService;

    InternalTransfer internalTransfer=new InternalTransfer();

    WireTransfer wireTransfer;
    MigrationWireTransfer migrationWireTransfer=new MigrationWireTransfer();
    MigClient migClient =new MigClient();

    @BeforeEach
    void setUp() {
        migrationWireTransfer.setBeneId("Bene");
        migrationWireTransfer.setStatus("ACH");
        wireTransfer=new WireTransfer();
        wireTransfer.setWireTxnId(123);
        migClient.setEcClientId(clientId);
    }

    @Test
    void internalTransfer_Valid_Insert() {
        try {
            List<InternalTransfer> transferList = new ArrayList<>();
            transferList.add(internalTransfer);

            MigrationInternalTransfer processedRecord=new MigrationInternalTransfer();

            when(internalTransferRepository.findByOlbClientId(anyLong(),any())).thenReturn(transferList);

            when(ochPaymentService.insert(any(InternalTransfer.class))).thenReturn(processedRecord);
            TransferResponse transferResponse=transferService.internalTransfer(1L, migClient);

        }catch (ServiceException se){
            fail("Service exception thrown "+se.getMessage());
        }
    }

    @Test
    void internalTransfer_Empty_transferList() {
        try {
            List<InternalTransfer> transferList = new ArrayList<>();

            MigrationInternalTransfer processedRecord=new MigrationInternalTransfer();


            when(internalTransferRepository.findByOlbClientId(anyLong(), any())).thenReturn(transferList);

            when(ochPaymentService.insert(any(InternalTransfer.class))).thenReturn(processedRecord);
            TransferResponse transferResponse=transferService.internalTransfer(1L, migClient);

        }catch (ServiceException se){
            fail("Service exception thrown "+se.getMessage());
        }
    }

    @Test
    void internalTransfer_Already_Processed_No_Retry() {
        try {
            List<InternalTransfer> transferList = new ArrayList<>();
            internalTransfer.setTrnId(123);
            transferList.add(internalTransfer);

            when(internalTransferRepository.findByOlbClientId(anyLong(), any())).thenReturn(transferList);
            MigrationInternalTransfer existingFailedRecord=new MigrationInternalTransfer();
            existingFailedRecord.setStatus(STATUS_IGNORE);
            existingFailedRecord.setEcClientId(clientId);
            existingFailedRecord.setEcTxnId(123);
            List<MigrationInternalTransfer> records=new ArrayList<>();
            records.add(existingFailedRecord);
            when(migrationTransferRepository.findByJobId(anyLong())).thenReturn(records);
            MigrationInternalTransfer newMigrationInternalTransfer = new MigrationInternalTransfer();
            when( ochPaymentService.insert(any(InternalTransfer.class))).thenReturn(newMigrationInternalTransfer);

            TransferResponse transferResponse=transferService.internalTransfer(1L,migClient);

            assertEquals(0, (int)transferResponse.getPaymentResponseData().getRecordCount().getSuccess());
            assertEquals(0, (int)transferResponse.getPaymentResponseData().getRecordCount().getFailure());
            assertEquals(0, (int)transferResponse.getPaymentResponseData().getRecordCount().getTotal());
            assertEquals(STATUS_SUCCESS, transferResponse.getPaymentResponseData().getStatus());
        }catch (ServiceException se){
            fail("Service exception thrown "+se.getMessage());
        }
    }

    @Test
    void wireTransfer_Valid_Insert() {
        try {
            List<WireTransfer> transferList = new ArrayList<>();
            transferList.add(wireTransfer);

            MigrationWireTransfer processedRecord=new MigrationWireTransfer();
            MigClient migrationClient =new MigClient();
            migrationClient.setEcClientId(clientId);
            when(migClientRepository.findByEcClientId(any())).thenReturn(migrationClient);

            when(wireTransferRepository.findByOlbClientId(anyLong(), any())).thenReturn(transferList);
            when(ochPaymentService.insert(anyLong(), any(WireTransfer.class))).thenReturn(processedRecord);
            when(wireTransferRepository.findByOlbClientId(anyLong(), any())).thenReturn(transferList);
            when( ochPaymentService.insert(anyLong(), any(WireTransfer.class))).thenReturn(migrationWireTransfer);

            TransferResponse transferResponse=transferService.wireTransfer(1L,migrationClient);
        }catch (ServiceException se){
            fail("Service exception thrown "+se.getMessage());
        }
    }

    @Test
    void wireTransfer_Already_Processed_No_Retry() {
        try {
            List<WireTransfer> transferList = new ArrayList<>();
            transferList.add(wireTransfer);

            MigClient migrationClient =new MigClient();
            migrationClient.setEcClientId(clientId);
            when(migClientRepository.findByEcClientId(any())).thenReturn(migrationClient);
            when(wireTransferRepository.findByOlbClientId(anyLong(), any())).thenReturn(transferList);
            MigrationWireTransfer existingFailedRecord=new MigrationWireTransfer();
            existingFailedRecord.setStatus(STATUS_IGNORE);
            existingFailedRecord.setEcTxnId(123);
            List<MigrationWireTransfer> list=new ArrayList<>();
            list.add(existingFailedRecord);
            when(migrationWireTransferRepository.findByJobId(anyLong())).thenReturn(list);

            migrationWireTransfer.setStatus(STATUS_SUCCESS);
            when( ochPaymentService.insert(anyLong(), any(WireTransfer.class))).thenReturn(migrationWireTransfer);

            TransferResponse transferResponse=transferService.wireTransfer(1L,migrationClient);

            assertEquals(0, (int)transferResponse.getPaymentResponseData().getRecordCount().getSuccess());
            assertEquals(0, (int)transferResponse.getPaymentResponseData().getRecordCount().getFailure());
            assertEquals(0, (int)transferResponse.getPaymentResponseData().getRecordCount().getTotal());
            assertEquals(STATUS_SUCCESS, transferResponse.getPaymentResponseData().getStatus());
        }catch (ServiceException se){
            fail("Service exception thrown "+se.getMessage());
        }
    }

    @Test
    void wireTransfer_Valid_Insert_Retry() {
        try {
            List<WireTransfer> transferList = new ArrayList<>();
            transferList.add(wireTransfer);

            MigClient migrationClient =new MigClient();
            migrationClient.setEcClientId(clientId);
            when(migClientRepository.findByEcClientId(any())).thenReturn(migrationClient);
            when(wireTransferRepository.findByOlbClientId(anyLong(), any())).thenReturn(transferList);
            MigrationWireTransfer existingFailedRecord=new MigrationWireTransfer();
            existingFailedRecord.setEcTxnId(123);
            existingFailedRecord.setStatus(STATUS_FAILURE);
            List<MigrationWireTransfer> records=new ArrayList<>();
            records.add(existingFailedRecord);
            when(migrationWireTransferRepository.findByJobId(anyLong())).thenReturn(records);

            migrationWireTransfer.setStatus(STATUS_SUCCESS);
            when( ochPaymentService.insert(anyLong(), any(WireTransfer.class))).thenReturn(migrationWireTransfer);

            TransferResponse transferResponse=transferService.wireTransfer(1L,migrationClient);

            assertEquals(1, (int)transferResponse.getPaymentResponseData().getRecordCount().getSuccess());
            assertEquals(0, (int)transferResponse.getPaymentResponseData().getRecordCount().getFailure());
            assertEquals(1, (int)transferResponse.getPaymentResponseData().getRecordCount().getTotal());
            assertEquals(STATUS_SUCCESS, transferResponse.getPaymentResponseData().getStatus());
        }catch (ServiceException se){
            fail("Service exception thrown "+se.getMessage());
        }
    }

    @Test
    void wireTransfer_Exception() {
        try {
            List<WireTransfer> transferList = new ArrayList<>();
            transferList.add(wireTransfer);

            MigClient migrationClient =new MigClient();
            migrationClient.setEcClientId(clientId);
            when(migClientRepository.findByEcClientId(any())).thenReturn(migrationClient);
            when(wireTransferRepository.findByOlbClientId(anyLong(), any())).thenReturn(transferList);
            MigrationWireTransfer existingFailedRecord=new MigrationWireTransfer();
            existingFailedRecord.setStatus(STATUS_FAILURE);
            existingFailedRecord.setEcClientId(clientId);
            existingFailedRecord.setEcTxnId(123);
            List<MigrationWireTransfer> list=new ArrayList<>();
            list.add(existingFailedRecord);
            when(migrationWireTransferRepository.findByJobId(anyLong())).thenReturn(list);

            migrationWireTransfer.setStatus(STATUS_SUCCESS);
            when(ochPaymentService.insert(anyLong(), any(WireTransfer.class))).thenThrow(new ServiceException(""));

            TransferResponse transferResponse=transferService.wireTransfer(1L,migrationClient);

            assertEquals(0, (int)transferResponse.getPaymentResponseData().getRecordCount().getSuccess());
            assertEquals(1, (int)transferResponse.getPaymentResponseData().getRecordCount().getFailure());
            assertEquals(1, (int)transferResponse.getPaymentResponseData().getRecordCount().getTotal());
            assertEquals(STATUS_FAILURE, transferResponse.getPaymentResponseData().getStatus());
        }catch (ServiceException se){
            fail("Service exception thrown "+se.getMessage());
        }
    }

    @Test
    void wireTransfer_Empty_transferList() {
        try {
            List<WireTransfer> transferList = new ArrayList<>();

            MigrationWireTransfer processedRecord=new MigrationWireTransfer();
            MigClient migrationClient =new MigClient();
            migrationClient.setEcClientId(clientId);
            when(migClientRepository.findByEcClientId(any())).thenReturn(migrationClient);

            when(wireTransferRepository.findByOlbClientId(anyLong(),any())).thenReturn(transferList);
            when(ochPaymentService.insert(anyLong(),any(WireTransfer.class))).thenReturn(processedRecord);
            when(wireTransferRepository.findByOlbClientId(anyLong(),any())).thenReturn(transferList);

            when( ochPaymentService.insert(anyLong(),any(WireTransfer.class))).thenReturn(migrationWireTransfer);

            TransferResponse transferResponse=transferService.wireTransfer(1L, migrationClient);
        }catch (ServiceException se){
            fail("Service exception thrown "+se.getMessage());
        }
    }

    @Test
    void wireTransfer_Throws_ServiceException() {
        try {
            MigClient migrationClient =new MigClient();
            migrationClient.setEcClientId(clientId);
            migrationClient.setEcClientId("abc");
            transferService.wireTransfer(1L, migrationClient);
            fail("Service exception should be throw  ");
        }catch (ServiceException se){

        }
    }
}
