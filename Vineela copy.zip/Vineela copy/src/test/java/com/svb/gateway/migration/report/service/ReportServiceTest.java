package com.svb.gateway.migration.report.service;

import com.svb.gateway.migration.alerts.entity.MigratedAlertsEntity;
import com.svb.gateway.migration.alerts.mapper.MigrationAlertsMapper;
import com.svb.gateway.migration.beneficiaries.entity.MigBeneficiary;
import com.svb.gateway.migration.cards.entity.MigCardProgram;
import com.svb.gateway.migration.cards.repository.MigCardProgramRepository;
import com.svb.gateway.migration.beneficiaries.repository.MigBeneficiaryRepository;
import com.svb.gateway.migration.client.entity.MigClient;
import com.svb.gateway.migration.client.repository.MigClientRepository;
import com.svb.gateway.migration.common.utility.JobIdCheck;
import com.svb.gateway.migration.common.utility.JobStatusEnum;
import com.svb.gateway.migration.job.entity.MigJob;
import com.svb.gateway.migration.job.repository.MigJobRepository;
import com.svb.gateway.migration.nickname.entity.MigratedNicknamesEntity;
import com.svb.gateway.migration.nickname.mapper.MigrationNicknameMapper;
import com.svb.gateway.migration.payments.entity.MigrationInternalTransfer;
import com.svb.gateway.migration.payments.entity.MigrationPayment;
import com.svb.gateway.migration.payments.entity.MigrationWireTransfer;
import com.svb.gateway.migration.payments.repository.MigrationPaymentsRepository;
import com.svb.gateway.migration.payments.repository.MigrationTransferRepository;
import com.svb.gateway.migration.payments.repository.MigrationWireTransferRepository;
import com.svb.gateway.migration.report.model.MigEntitySkipLog;
import com.svb.gateway.migration.report.repository.MigEntitySkipLogRepository;
import com.svb.gateway.migration.common.entity.MigEntity;
import com.svb.gateway.migration.common.entity.MigEntityUser;
import com.svb.gateway.migration.common.repository.MigEntityRepository;
import com.svb.gateway.migration.common.repository.MigEntityUserRepository;
import com.svb.gateway.migration.user.entity.MigUser;
import com.svb.gateway.migration.user.repository.MigUserRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.Spy;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import static com.svb.gateway.migration.common.constants.MigrationConstants.EMAIL_NOTIFICATION;
import static com.svb.gateway.migration.common.constants.ReportConstants.*;

@SpringBootTest
@ExtendWith(SpringExtension.class)
public class ReportServiceTest {

    @Mock
    MigClientRepository migClientRepository;

    @InjectMocks
    @Spy
    ReportService reportService;
    @Mock
    MigUserRepository migUserRepository;

    @Mock
    MigrationTransferRepository migrationTransferRepository;

    @Mock
    MigrationWireTransferRepository migrationWireTransferRepository;

    @Mock
    MigrationNicknameMapper migrationNicknameMapper;

    @Mock
    MigrationAlertsMapper migrationAlertsMapper;

    @Mock
    MigCardProgramRepository migCardProgramRepository;

    @Mock
    MigJobRepository migJobRepository;

    @Mock
    MigEntityRepository migEntityRepository;

    @Mock
    MigEntitySkipLogRepository migEntitySkipLogRepository;

    @Mock
    MigEntityUserRepository migEntityUserRepository;

    @Mock
    MigBeneficiaryRepository migBeneficiaryRepository;

    @Mock
    JobIdCheck jobIdCheck;

    @Mock
    MigrationPaymentsRepository migrationPaymentsRepository;

    @Test
    public void generateMigrationExcelReport() throws Exception {

        String jobId = "1234";

        MigJob migJob = new MigJob();
        migJob.setStatus(JobStatusEnum.MIGRATION_COMPLETED.name());
        migJob.setJobId(1234l);
        migJob.setType("Abc");
        migJob.setStartTime(OffsetDateTime.now());
        migJob.setEndTime(OffsetDateTime.now());
        migJob.setLoadTime(1234l);
        migJob.setExtractionTime(1234l);

        migJob.setCandidateCount(5);
        List<MigClient> migClientList = new ArrayList<>();
        MigClient migClient = new MigClient();
        migClient.setJobId(1234l);
        migClient.setEcClientId("ecCLIENTID");
        migClient.setGwClientId("gwClientId");
        migClient.setClientName("ClientName");
        migClient.setCompanyId("gwClientId");
        migClient.setPrimaryCifUbs(1234);
        migClient.setStatus("Success");
        migClient.setComments("Mig Success");
        migClient.setUpdateDate(new Date());
        migClient.setBdcStatus(12);

        migClientList.add(migClient);

        List<MigUser> migUserList = new ArrayList<>();
        MigUser migUser = new MigUser();
        migUser.setJobId(1234l);
        migUser.setEcClientId("EcClientId");
        migUser.setEcUserLoginId("esLoginUserId");
        migUser.setMigUserId(1);
        migUser.setComments("Failed");
        migUser.setStatus("Success");
        migUser.setTypeOfUser("abc");
        migUser.setUpdateDate(new Date());
        migUser.setGwClientId("gWClientId");
        migUser.setGwUuid("123");
        migUser.setMobileNumber("123");
        migUser.setBdcStatus(12);
        migUser.setFirstName("123");
        migUser.setLastName("123");
        migUser.setIsPrimaryUser(1);

        migUserList.add(migUser);


        Mockito.doReturn(migJob).when(migJobRepository).findByJobIdValue(Mockito.anyLong());
        Mockito.doReturn(migClientList).when(migClientRepository).findByJobIdAndStatus(Mockito.anyLong(), Mockito.anyString());
        Mockito.doReturn(migUserList).when(migUserRepository).findByJobIdandStatus(Mockito.anyLong(), Mockito.anyString());
        Mockito.doReturn(migClientList).when(migClientRepository).findByJobIdAndNotStatus(Mockito.anyLong(), Mockito.anyString());

        List<MigEntity> migEntityList = new ArrayList<>();

        MigEntity migEntityN = new MigEntity();

        migEntityN.setJobId(1234);
        migEntityN.setEcclientId("ecCLIENTID");
        migEntityN.setGwclientId("gwClientId");
        migEntityN.setEntityName(EMAIL_NOTIFICATION);
        migEntityN.setSkipCount(0);
        migEntityN.setReadCount(1234);
        migEntityN.setWriteCount(0);


        migEntityList.add(migEntityN);

        MigEntity migEntity = new MigEntity();

        migEntity.setJobId(1234);
        migEntity.setEcclientId("ecCLIENTID");
        migEntity.setGwclientId("gwClientId");
        migEntity.setEntityName("ClientName");
        migEntity.setSkipCount(0);
        migEntity.setReadCount(1234);
        migEntity.setWriteCount(0);


        migEntityList.add(migEntity);
        List<MigEntityUser> migEntityUserList = new ArrayList<>();
        MigEntityUser migEntityUser = new MigEntityUser();

        migEntityUser.setJobId(1234);
        migEntityUser.setEcclientId("ecCLIENTID");
        migEntityUser.setGwclientId("gwClientId");
        migEntityUser.setEntityName("ClientName");
        migEntityUser.setSkipCount(0);
        migEntityUser.setReadCount(1234);
        migEntityUser.setWriteCount(0);

        migEntityUserList.add(migEntityUser);
        MigEntityUser migEntityUserT = new MigEntityUser();

        migEntityUserT.setJobId(1234);
        migEntityUserT.setEcclientId("ecCLIENTID");
        migEntityUserT.setGwclientId("gwClientId");
        migEntityUserT.setEntityName(INTERNAL_TRANSFER);
        migEntityUserT.setSkipCount(1);
        migEntityUserT.setReadCount(1234);
        migEntityUserT.setWriteCount(0);

        migEntityUserList.add(migEntityUserT);

        MigEntityUser migEntityUserWT = new MigEntityUser();

        migEntityUserWT.setJobId(1234);
        migEntityUserWT.setEcclientId("ecCLIENTID");
        migEntityUserWT.setGwclientId("gwClientId");
        migEntityUserWT.setEntityName(WIRE_TRANSFERS);
        migEntityUserWT.setSkipCount(1);
        migEntityUserWT.setReadCount(123);
        migEntityUserWT.setWriteCount(122);

        migEntityUserList.add(migEntityUserWT);

        MigEntityUser migEntityUserAlert = new MigEntityUser();

        migEntityUserAlert.setJobId(1234);
        migEntityUserAlert.setEcclientId("ecCLIENTID");
        migEntityUserAlert.setGwclientId("gwClientId");
        migEntityUserAlert.setEntityName(ALERT_SUBSCRIPTION);
        migEntityUserAlert.setSkipCount(1);
        migEntityUserAlert.setReadCount(123);
        migEntityUserAlert.setWriteCount(122);

        migEntityUserList.add(migEntityUserAlert);

        MigEntityUser migEntityAccountNickname = new MigEntityUser();

        migEntityAccountNickname.setJobId(1234);
        migEntityAccountNickname.setEcclientId("ecCLIENTID");
        migEntityAccountNickname.setGwclientId("gwClientId");
        migEntityAccountNickname.setEntityName(ACCOUNT_NICKNAME);
        migEntityAccountNickname.setSkipCount(1);
        migEntityAccountNickname.setReadCount(123);
        migEntityAccountNickname.setWriteCount(122);

        migEntityUserList.add(migEntityAccountNickname);

        MigEntityUser migEntityPayments = new MigEntityUser();

        migEntityPayments.setJobId(1234);
        migEntityPayments.setEcclientId("ecCLIENTID");
        migEntityPayments.setGwclientId("gwClientId");
        migEntityPayments.setEntityName(IPAY_PAYMENTS);
        migEntityPayments.setSkipCount(1);
        migEntityPayments.setReadCount(123);
        migEntityPayments.setWriteCount(122);

        migEntityUserList.add(migEntityPayments);

        MigEntityUser migEntityUserBene = new MigEntityUser();

        migEntityUserBene.setJobId(1234);
        migEntityUserBene.setEcclientId("ecCLIENTID");
        migEntityUserBene.setGwclientId("gwClientId");
        migEntityUserBene.setEntityName(BENE_CREATION_TEMPLATE);
        migEntityUserBene.setSkipCount(1);
        migEntityUserBene.setReadCount(123);
        migEntityUserBene.setWriteCount(122);

        migEntityUserList.add(migEntityUserBene);

        Mockito.doReturn(migEntityUserList).when(migEntityUserRepository).findByJobIdAndByEntityNameIn(Mockito.anyInt(), Mockito.any());
        List<MigUser> migUsersList = new ArrayList<>();

        Mockito.doReturn(migUsersList).when(migUserRepository).findByJobIdAndAndEcClientIdAndStatus(Mockito.any(), Mockito.any(), Mockito.anyList());
        List<MigBeneficiary> migBeneList = new ArrayList<>();

        Mockito.doReturn(migBeneList).when(migBeneficiaryRepository).findByEcClientIdAndJobIdAndStatus(Mockito.any(), Mockito.any(), Mockito.any());

        List<MigEntitySkipLog> migEntitySkipLogList = new ArrayList<>();
        MigEntitySkipLog migEntitySkipLog = new MigEntitySkipLog();

        migEntitySkipLog.setJobId("1234");
        migEntitySkipLog.setEcclientId("ecCLIENTID");
        migEntitySkipLog.setGwclientId("gwClientId");
        migEntitySkipLog.setEntityName("ClientName");
        migEntitySkipLog.setExceptionType("Exception");
        migEntitySkipLog.setRecordDetails("Record");

        migEntitySkipLogList.add(migEntitySkipLog);

        Mockito.doReturn(migEntitySkipLogList).when(migEntitySkipLogRepository).findByJobId(Mockito.any());

        List<MigrationInternalTransfer> migTransfersList = new ArrayList<>();
        MigrationInternalTransfer migTransfers = new MigrationInternalTransfer();
        migTransfers.setJobId(1234l);
        migTransfers.setEcClientId("1234");
        migTransfers.setEcTxnId(123);
        migTransfers.setComments("comments");
        migTransfersList.add(migTransfers);

        Mockito.doReturn(migTransfersList).when(migrationTransferRepository).findByEcClientIdAndJobIdAndStatus(Mockito.any(), Mockito.any(), Mockito.any());

        List<MigrationWireTransfer> migWireTransfersList = new ArrayList<>();
        MigrationWireTransfer migWireTransfers = new MigrationWireTransfer();
        migWireTransfers.setJobId(1234l);
        migWireTransfers.setEcClientId("1234");
        migWireTransfers.setEcTxnId(123);
        migWireTransfers.setComments("comments");
        migWireTransfersList.add(migWireTransfers);

        Mockito.doReturn(migWireTransfersList).when(migrationWireTransferRepository).findByEcClientIdAndJobIdAndStatus(Mockito.any(), Mockito.any(), Mockito.any());

        List<MigCardProgram> migCardProgramList = new ArrayList<>();
        MigCardProgram migCardProgram = new MigCardProgram();
        migCardProgram.setOlbClientId("abcd342");
        migCardProgram.setUpdatedBy("migrationUser");
        migCardProgram.setClientProfileName("abc");
        migCardProgram.setCif("1234");
        migCardProgram.setBillingType("123");
        migCardProgram.setAgent("abc");
        migCardProgram.setPrn("abc");
        migCardProgram.setProgramType("abc");
        migCardProgram.setCreditLine("123");
        migCardProgram.setEcStatusCode("12");
        migCardProgram.setStatus("success");
        migCardProgram.setEcClientId("ecor3452");
        migCardProgram.setJobId(123l);
        migCardProgram.setProgramId("123");
        migCardProgram.setUpdatedBy("abc");
        migCardProgram.setComments("abc");
        migCardProgramList.add(migCardProgram);
        Mockito.doReturn(migCardProgramList).when(migCardProgramRepository).findByEcClientIdAndJobIdAndStatus(Mockito.any(), Mockito.any(), Mockito.anyList());

        List<MigratedAlertsEntity> migratedAlertsEntities = new ArrayList<>();
        MigratedAlertsEntity migratedAlertsEntity = new MigratedAlertsEntity();
        migratedAlertsEntity.setJobId(1234l);
        migratedAlertsEntity.setEc_Client_Id("1234");
        migratedAlertsEntity.setGw_Alert_Id("SVB_ALERT");
        migratedAlertsEntity.setComments("comments");
        migratedAlertsEntities.add(migratedAlertsEntity);

        Mockito.doReturn(migratedAlertsEntities).when(migrationAlertsMapper).findByEcClientIdAndJobIdAndStatus(Mockito.any(), Mockito.any());

        List<MigratedNicknamesEntity> migratedNicknamesEntityList = new ArrayList<>();
        MigratedNicknamesEntity migratedNicknamesEntity = new MigratedNicknamesEntity();
        migratedNicknamesEntity.setJobId(1234l);
        migratedNicknamesEntity.setEc_Client_Id("1234");
        migratedNicknamesEntity.setAccount_Number("3434534");
        migratedNicknamesEntity.setComments("comments");
        migratedNicknamesEntityList.add(migratedNicknamesEntity);

        Mockito.doReturn(migratedNicknamesEntityList).when(migrationNicknameMapper).findByEcClientIdAndJobIdAndStatus(Mockito.any(), Mockito.any());

        List<MigrationPayment> migrationPaymentList = new ArrayList<>();
        MigrationPayment migrationPayment = new MigrationPayment();
        migrationPayment.setJobId(1234l);
        migrationPayment.setEcClientId("1234");
        migrationPayment.setPaymentId(1212);
        migrationPayment.setComments("comments");
        migrationPaymentList.add(migrationPayment);

        Mockito.doReturn(migrationPaymentList).when(migrationPaymentsRepository).findByEcClientIdAndJobIdAndStatus(Mockito.any(), Mockito.any(),Mockito.any());


        Mockito.doReturn(migEntityList).when(migEntityRepository).findByJobIdAndByEntityNameNotIn(Mockito.anyInt(), Mockito.any());


        reportService.generateMigrationExcelReport(jobId);

    }

    @Test
    public void generateMigrationExcelReportBeneDetails() throws Exception {

        String jobId = "1234";

        MigJob migJob = new MigJob();
        migJob.setStatus(JobStatusEnum.MIGRATION_COMPLETED.name());
        migJob.setJobId(1234l);
        migJob.setType("Abc");
        migJob.setStartTime(OffsetDateTime.now());
        migJob.setEndTime(OffsetDateTime.now());
        migJob.setLoadTime(1234l);
        migJob.setExtractionTime(1234l);

        migJob.setCandidateCount(5);

        List<MigClient> migClientList = new ArrayList<>();
        MigClient migClient = new MigClient();
        migClient.setJobId(1234l);
        migClient.setEcClientId("ecCLIENTID");
        migClient.setCompanyId("gwClientId");
        migClient.setStatus("Success");
        migClient.setUpdateDate(new Date());
        migClient.setBdcStatus(12);


        migClientList.add(migClient);
        Mockito.doReturn(migJob).when(migJobRepository).findByJobIdValue(Mockito.anyLong());
        Mockito.doReturn(migClientList).when(migClientRepository).findByJobIdAndStatus(Mockito.anyLong(), Mockito.anyString());
        Mockito.doReturn(migClientList).when(migClientRepository).findByJobIdAndNotStatus(Mockito.anyLong(), Mockito.anyString());

        List<MigEntity> migEntityList = new ArrayList<>();
        MigEntity migEntity = new MigEntity();

        migEntity.setJobId(1234);
        migEntity.setEcclientId("ecCLIENTID");
        migEntity.setGwclientId("gwClientId");
        migEntity.setEntityName("ClientName");
        migEntity.setSkipCount(1);
        migEntity.setReadCount(1234);
        migEntity.setWriteCount(0);


        migEntityList.add(migEntity);
        List<MigEntityUser> migEntityUserList = new ArrayList<>();
        MigEntityUser migEntityUserB = new MigEntityUser();

        migEntityUserB.setJobId(1234);
        migEntityUserB.setEntityName("BeneCreation");
        migEntityUserB.setSkipCount(1);
        migEntityUserB.setReadCount(1234);
        migEntityUserB.setWriteCount(0);
        MigEntityUser migEntityUser = new MigEntityUser();

        migEntityUser.setJobId(1234);
        migEntityUser.setEcclientId("ecCLIENTID");
        migEntityUser.setGwclientId("gwClientId");
        migEntityUser.setEntityName(ADDITIONAL_USER_CREATION);
        migEntityUser.setSkipCount(1);
        migEntityUser.setReadCount(1234);
        migEntityUser.setWriteCount(0);
        MigEntityUser migEntityUserT = new MigEntityUser();

        migEntityUserT.setJobId(1234);
        migEntityUserT.setEcclientId("ecCLIENTID");
        migEntityUserT.setGwclientId("gwClientId");
        migEntityUserT.setEntityName(TRANSFERS_CREATION);
        migEntityUserT.setSkipCount(1);
        migEntityUserT.setReadCount(1234);
        migEntityUserT.setWriteCount(0);

        migEntityUserList.add(migEntityUserT);
        migEntityUserList.add(migEntityUserB);
        migEntityUserList.add(migEntityUser);
        Mockito.doReturn(migEntityUserList).when(migEntityUserRepository).findByJobIdAndByEntityNameIn(Mockito.anyInt(), Mockito.any());
        List<MigUser> migUserList = new ArrayList<>();

        MigUser migUser = new MigUser();
        migUser.setJobId(1234l);
        migUser.setEcClientId("EcClientId");
        migUser.setEcUserLoginId("esLoginUserId");
        migUser.setMigUserId(1);
        migUser.setComments("Failed");
        migUser.setStatus("Success");
        migUser.setTypeOfUser("abc");
        migUser.setUpdateDate(new Date());
        migUser.setGwClientId("gWClientId");
        migUser.setGwUuid("123");
        migUser.setMobileNumber("123");
        migUser.setBdcStatus(12);
        migUser.setFirstName("123");
        migUser.setLastName("123");
        migUser.setIsPrimaryUser(1);

        migUserList.add(migUser);

        Mockito.doReturn(migUserList).when(migUserRepository).findByJobIdAndAndEcClientIdAndStatus(Mockito.any(), Mockito.any(), Mockito.anyList());

        List<MigBeneficiary> migBeneList = new ArrayList<>();

        MigBeneficiary migBene = new MigBeneficiary();
        migBene.setJobId(1234l);
        migBene.setEcClientId("EcClientId");
        migBene.setBeneSourceId("esLoginUserId");
        migBene.setComments("Failed");

        migBeneList.add(migBene);

        Mockito.doReturn(migBeneList).when(migBeneficiaryRepository).findByEcClientIdAndJobIdAndStatus(Mockito.any(), Mockito.any(), Mockito.any());


        List<MigEntitySkipLog> migEntitySkipLogList = new ArrayList<>();
        MigEntitySkipLog migEntitySkipLog = new MigEntitySkipLog();

        migEntitySkipLog.setJobId("1234");
        migEntitySkipLog.setEcclientId("ecCLIENTID");
        migEntitySkipLog.setGwclientId("gwClientId");
        migEntitySkipLog.setEntityName("ClientName");
        migEntitySkipLog.setExceptionType("Exception");
        migEntitySkipLog.setRecordDetails("Record");

        migEntitySkipLogList.add(migEntitySkipLog);

        Mockito.doReturn(migEntitySkipLogList).when(migEntitySkipLogRepository).findByJobId(Mockito.any());

        List<MigrationInternalTransfer> migTransfersList = new ArrayList<>();
        MigrationInternalTransfer migTransfers = new MigrationInternalTransfer();
        migTransfers.setJobId(1234l);
        migTransfers.setEcClientId("1234");
        migTransfers.setEcTxnId(123);
        migTransfers.setComments("comments");
        migTransfersList.add(migTransfers);

        Mockito.doReturn(migTransfersList).when(migrationTransferRepository).findByEcClientIdAndJobIdAndStatus(Mockito.any(), Mockito.any(), Mockito.any());

        Mockito.doReturn(migEntityList).when(migEntityRepository).findByJobIdAndByEntityNameNotIn(Mockito.anyInt(), Mockito.any());


        reportService.generateMigrationExcelReport(jobId);

    }


}
