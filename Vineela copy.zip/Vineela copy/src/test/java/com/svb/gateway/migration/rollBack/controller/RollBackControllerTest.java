package com.svb.gateway.migration.rollBack.controller;

import com.svb.gateway.migration.rollBack.model.RollBackResponse;
import com.svb.gateway.migration.rollBack.service.RollBackService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import static org.mockito.ArgumentMatchers.any;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@AutoConfigureMockMvc
public class RollBackControllerTest {

    @Autowired
    private MockMvc mockMvc;


    @MockBean
    private RollBackService rollBackService;

    private RollBackResponse rollbackResponse=new RollBackResponse();

    @BeforeEach
    public void setup() throws Exception {
        Mockito.when(rollBackService.rollback(any())).
                thenReturn(rollbackResponse);
    }

    @Test
    public void client_resp() throws Exception {
        this.mockMvc.perform(delete("/v1/api/rollback/{clientId}", 1233L,"ench6060")
                .contentType(MediaType.APPLICATION_JSON_VALUE)
                .header("Authorization","Basic Y3JtdXNlcjI6QWNjZXNzMTIz"))
                .andExpect(status().isOk());
    }
}
