package com.svb.gateway.migration.rollBack.service;

import com.svb.gateway.migration.alerts.service.AlertsService;
import com.svb.gateway.migration.beneficiaries.mapper.MigBeneficiaryMapper;
import com.svb.gateway.migration.cards.service.CardsService;
import com.svb.gateway.migration.client.entity.MigClient;
import com.svb.gateway.migration.client.model.DeleteClientResponse;
import com.svb.gateway.migration.client.repository.MigClientRepository;
import com.svb.gateway.migration.client.service.ClientService;
import com.svb.gateway.migration.common.constants.MigrationConstants;
import com.svb.gateway.migration.common.exception.BadRequestException;
import com.svb.gateway.migration.common.exception.ServiceException;
import com.svb.gateway.migration.ec2stage.service.ECService;
import com.svb.gateway.migration.job.entity.MigJob;
import com.svb.gateway.migration.job.repository.MigJobRepository;
import com.svb.gateway.migration.nickname.service.NicknameService;
import com.svb.gateway.migration.payments.entity.TransactionEntity;
import com.svb.gateway.migration.payments.utils.PaymentsUtils;
import com.svb.gateway.migration.rollBack.mapper.RollBackMapper;
import com.svb.gateway.migration.rollBack.model.RollBackResponse;
import com.svb.gateway.migration.user.mapper.UserMapper;
import com.svb.gateway.migration.user.model.CardUserResponse;
import com.svb.gateway.migration.user.service.UserService;
import lombok.extern.slf4j.Slf4j;
import org.apache.ibatis.exceptions.IbatisException;
import org.junit.Assert;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.when;

@Slf4j
@SpringBootTest
@ExtendWith(SpringExtension.class)
public class RollBackServiceTest {

    @InjectMocks
    @Spy
    RollBackService rollBackService;

    @Mock
    MigClientRepository migClientRepository;

    @Mock
    MigJobRepository migJobRepository;

    @Mock
    RollBackMapper rollbackMapper;

    @Mock
    ClientService clientService;

    @Mock
    AlertsService alertsService;

    @Mock
    NicknameService nicknameService;

    @Mock
    CardsService cardsService;

    @Mock
    UserService userService;

    @Mock
    UserMapper userMapper;

    @Mock
    MigBeneficiaryMapper migBeneficiaryMapper;

    @Mock
    ECService ecService;

    @Test
    void rollback_processes_Sucessfully() {
        try {
            String clientId = "ench6060";
            Long jobId = 123L;
            MigClient migrationClient =new MigClient();
            migrationClient.setEcClientId("ench6060");
            migrationClient.setGwClientId("GWaddr7550");
            List<MigClient> migrationClients = new ArrayList<>();
            migrationClients.add(migrationClient);
            when(rollbackMapper.getTransfers(clientId,  MigrationConstants.INTERNAL_TRANSFERS_TABLE_NAME)).thenReturn(new ArrayList<TransactionEntity>());
            when(rollbackMapper.getTransfers(clientId,  MigrationConstants.WIRE_TRANSFERS_TABLE_NAME)).thenReturn(new ArrayList<TransactionEntity>());
            when(rollbackMapper.getPayments(clientId)).thenReturn(new ArrayList<TransactionEntity>());
            when(migClientRepository.findByEcClientIdStatusNotRollback(clientId)).thenReturn(migrationClients);
            when(userService.rollbackCardUserId(clientId)).thenReturn(new CardUserResponse("123", "Success", "Success"));
            DeleteClientResponse deleteClientResponse = new DeleteClientResponse();
            deleteClientResponse.setStatus(MigrationConstants.STATUS_SUCCESS);
            when(clientService.inactiveAndDeleteClient(any())).thenReturn(deleteClientResponse);

            RollBackResponse rollbackResponse = rollBackService.rollback(clientId);
            assertEquals(MigrationConstants.STATUS_SUCCESS, rollbackResponse.getStatus());
        }catch (ServiceException se){
            Assert.fail("Not expected");
        }
    }

    @Test
    void rollback_Payments_successfully() {
        try {
            String clientId = "ench6060";
            Long jobId = 123L;
            MigClient migrationClient =new MigClient();
            migrationClient.setEcClientId("ench6060");
            migrationClient.setGwClientId("GWaddr7550");
            List<TransactionEntity> list=new ArrayList<TransactionEntity>();
            list.add(PaymentsUtils.createTransactionEntity());

            List<MigClient> migrationClients = new ArrayList<>();
            migrationClients.add(migrationClient);

            when(rollbackMapper.getTransfers(clientId, MigrationConstants.INTERNAL_TRANSFERS_TABLE_NAME)).thenReturn(list);
            when(rollbackMapper.getTransfers(clientId, MigrationConstants.WIRE_TRANSFERS_TABLE_NAME)).thenReturn(list);
            when(rollbackMapper.getPayments(clientId)).thenReturn(list);
            when(migClientRepository.findByEcClientIdStatusNotRollback(clientId)).thenReturn(migrationClients);
            DeleteClientResponse deleteClientResponse = new DeleteClientResponse();
            deleteClientResponse.setStatus(MigrationConstants.STATUS_SUCCESS);
            when(clientService.inactiveAndDeleteClient(any())).thenReturn(deleteClientResponse);

            RollBackResponse rollbackResponse = rollBackService.rollback(clientId);
            assertEquals(MigrationConstants.STATUS_SUCCESS, rollbackResponse.getStatus());
        }catch (ServiceException se){
            Assert.fail("Not expected");
        }
    }

    @Test
    void rollback_fails() {
        try {
            String clientId = "ench6060";
            Long jobId = 123L;
            MigClient migrationClient =new MigClient();
            migrationClient.setEcClientId("ench6060");
            migrationClient.setGwClientId("GWaddr7550");

            when(migClientRepository.findByEcClientIdAndJobId(clientId, jobId)).thenReturn(migrationClient);
            when(rollbackMapper.getTransfers(clientId, MigrationConstants.INTERNAL_TRANSFERS_TABLE_NAME)).thenThrow(IbatisException.class);

            RollBackResponse rollbackResponse = rollBackService.rollback(clientId);
            assertEquals(MigrationConstants.STATUS_FAILURE, rollbackResponse.getStatus());
        }catch (ServiceException se){
            Assert.fail("Not expected");
        }
        catch (BadRequestException be) {
            assertEquals( "No valid Migration entity to roll back for :: ench6060", be.getMessage());
        }
    }

    @Test
    void rollback_when_GWClient_is_null() {
        try {
            String clientId = "";
            Long jobId = 123L;
            MigClient migrationClient =new MigClient();

            List<MigClient> migrationClients = new ArrayList<>();
            migrationClients.add(migrationClient);

            when(migClientRepository.findByEcClientIdStatusNotRollback(clientId)).thenReturn(migrationClients);
            RollBackResponse rollbackResponse=rollBackService.rollback(clientId);
            rollbackResponse.getMessages().stream().forEach(m->log.info(m));
            Assert.fail("Service exception expected as GWCLiendId is null");
        }catch (ServiceException se){
            log.info("Exception is expected");
        }
    }

    @Test
    void rollback_when_Migration_is_inprocess() {
        try {
            String clientId = "";
            Long jobId = 123L;
            MigClient migrationClient =new MigClient();

            List<MigClient> migrationClients = new ArrayList<>();
            migrationClients.add(migrationClient);

            when(migJobRepository.findByJobIdProgress(any())).thenReturn(new MigJob());
            RollBackResponse rollbackResponse=rollBackService.rollback(clientId);
            Assert.fail("Service exception as Migration job is still running");
        }catch (ServiceException se){
            log.debug("Exception is expected");
        }
    }

    @Test
    void rollback_throws_Exception() {
        try {
            String clientId = "";
            Long jobId = 123L;

            RollBackResponse rollbackResponse=rollBackService.rollback(clientId);

            rollbackResponse.getMessages().stream().forEach(m->log.info(m));
            Assert.fail("Service exception expected");
        }catch (ServiceException se){

        }
    }
}
