package com.svb.gateway.migration.statements.controller;

import com.svb.gateway.migration.statements.service.AccStmtsService;
import com.svb.gateway.migration.job.model.CreateJobResponse;
import com.svb.gateway.migration.job.model.CreateJobResponseData;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentMatchers;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.web.servlet.MockMvc;
import static com.svb.gateway.migration.TestUtil.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@AutoConfigureMockMvc
public class AccountStatementsControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private AccStmtsService accStmtsService;

    @BeforeEach
    public void setup() throws Exception {
        Mockito.when(accStmtsService.accStmtsJobLauncher(ArgumentMatchers.any(),
                ArgumentMatchers.any(),ArgumentMatchers.any())).thenReturn(new CreateJobResponse(
                new CreateJobResponseData(3L,"Completed")));
    }

    @Test
    @WithMockUser(username = TEST_USER_USER1, password = TEST_USER1_VALID_PASSWORD, authorities = TEST_USER1_ROLE_EXECUTE)
    public void withMockUser() throws Exception {
        this.mockMvc.perform(post("/api/job/moveAccStmtsData").contentType(MediaType.APPLICATION_JSON_VALUE)
                .content("[2000013276]")
                .header("Authorization","Basic Y3JtdXNlcjI6QWNjZXNzMTIz")
                .param("from", "2020-01-01")
                .param("to","2020-01-01"))
                .andExpect(status().isAccepted());
    }
}
