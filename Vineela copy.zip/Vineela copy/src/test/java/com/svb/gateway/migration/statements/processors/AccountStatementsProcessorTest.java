package com.svb.gateway.migration.statements.processors;

import com.svb.gateway.migration.statements.batch.processors.AccStmtsProcessor;
import com.svb.gateway.migration.common.DataProvider;
import com.svb.gateway.migration.statements.batch.dto.source.AccStmtsSourceDTO;
import com.svb.gateway.migration.statements.batch.dto.target.AccStmtsTargetDTO;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import static org.junit.jupiter.api.Assertions.assertNotNull;

@SpringBootTest
@ExtendWith(SpringExtension.class)
public class AccountStatementsProcessorTest {

    private AccStmtsProcessor accStmtsProcessor;

    private static final String data  = "{\n" +
            "  \"accNum\": \"3300947818\",\n" +
            "  \"cbsStmtDate\": 1430352000,\n" +
            "  \"stmtAvailConfTstamp\": 1430611200,\n" +
            "  \"stmtAvailable\": 1,\n" +
            "  \"stmtFirstRetrSuccTstamp\": 1430784000,\n" +
            "  \"stmtCycleDate\": 1430352000,\n" +
            "  \"statementType\": null,\n" +
            "  \"accTyp\": \"6\",\n" +
            "  \"acName\": \"Analysis Checking\",\n" +
            "  \"stmtProdType\": \"DDA\",\n" +
            "  \"prodDesc\": \"Current Plus Account\"\n" +
            "}";

    private static final String dataForLengthCheck  = "{\n" +
            "  \"accNum\": \"3300947818\",\n" +
            "  \"cbsStmtDate\": 1430352000,\n" +
            "  \"stmtAvailConfTstamp\": 1430611200,\n" +
            "  \"stmtAvailable\": 1,\n" +
            "  \"stmtFirstRetrSuccTstamp\": 1430784000,\n" +
            "  \"stmtCycleDate\": 1430352000,\n" +
            "  \"statementType\": null,\n" +
            "  \"accTyp\": null,\n" +
            "  \"acName\": \"Analysis Checking acc modifier greater than 20\",\n" +
            "  \"stmtProdType\": \"DDA\",\n" +
            "  \"prodDesc\": \"Current Plus Account\"\n" +
            "}";

    private static final String dataForStatementType  = "{\n" +
            "  \"accNum\": \"3300947818\",\n" +
            "  \"cbsStmtDate\": 1430352000,\n" +
            "  \"stmtAvailConfTstamp\": 1430611200,\n" +
            "  \"stmtAvailable\": 1,\n" +
            "  \"stmtFirstRetrSuccTstamp\": 1430784000,\n" +
            "  \"stmtCycleDate\": 1430352000,\n" +
            "  \"statementType\": \"BILLING_ST\",\n" +
            "  \"accTyp\": \"0\",\n" +
            "  \"acName\": \"Analysis Checking acc modifier greater than 20\",\n" +
            "  \"stmtProdType\": \"DDA\",\n" +
            "  \"prodDesc\": \"Current Plus Account\"\n" +
            "}";

    @BeforeEach
    public void beforeEach() {
        accStmtsProcessor = new AccStmtsProcessor();
    }

    @Test
    public  void testProcessWithAccountStatements()  throws Exception{

        AccStmtsSourceDTO accStmtsSourceDTO = (AccStmtsSourceDTO) DataProvider.getGenericObject(data, AccStmtsSourceDTO.class);
        AccStmtsTargetDTO accStmtsTargetDTO  = accStmtsProcessor.process(accStmtsSourceDTO);
        assertNotNull(accStmtsTargetDTO);
    }

    @Test
    public  void testProcessWithAccStmtsAccModLength()  throws Exception{

        AccStmtsSourceDTO accStmtsSourceDTO = (AccStmtsSourceDTO) DataProvider.getGenericObject(dataForLengthCheck, AccStmtsSourceDTO.class);
        AccStmtsTargetDTO accStmtsTargetDTO  = accStmtsProcessor.process(accStmtsSourceDTO);
        assertNotNull(accStmtsTargetDTO);
    }

    @Test
    public  void testProcessWithAccStmtsStmtType()  throws Exception{

        AccStmtsSourceDTO accStmtsSourceDTO = (AccStmtsSourceDTO) DataProvider.getGenericObject(dataForStatementType, AccStmtsSourceDTO.class);
        AccStmtsTargetDTO accStmtsTargetDTO  = accStmtsProcessor.process(accStmtsSourceDTO);
        assertNotNull(accStmtsTargetDTO);
    }
}
