package com.svb.gateway.migration.statements.service;

import com.svb.gateway.migration.common.exception.InvalidInputException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentMatchers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobParametersInvalidException;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.batch.core.repository.JobExecutionAlreadyRunningException;
import org.springframework.batch.core.repository.JobInstanceAlreadyCompleteException;
import org.springframework.batch.core.repository.JobRestartException;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.batch.core.*;

import java.util.*;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

@SpringBootTest
@RunWith(MockitoJUnitRunner.class)
public class AccountStatementsServiceTest {

    @InjectMocks
    private AccStmtsServiceImpl accStmtsService;
    @Mock
    private JobLauncher jobLauncher;

    private static List<Long> cifIds = new  ArrayList<>(Arrays.asList(20000L));

    @BeforeEach
    public void beforeTest() throws JobParametersInvalidException, JobExecutionAlreadyRunningException, JobRestartException, JobInstanceAlreadyCompleteException {
        Long jobid = new Date().getTime();
        JobExecution jobExecution =  new JobExecution(jobid);
        jobExecution.setStatus(BatchStatus.COMPLETED);
        Mockito.when(jobLauncher.run(ArgumentMatchers.any(), ArgumentMatchers.any())).thenReturn(jobExecution);
    }


    @Test
    public void launchJob() throws Exception {
        accStmtsService
                .accStmtsJobLauncher(new Date(), new Date(), cifIds);
    }
    @Test
    public void launchJobWithInvalidDate() {
        Exception ex = assertThrows( InvalidInputException.class
                , () -> accStmtsService.accStmtsJobLauncher(new Date(), new Date(new Date().getTime()-10000), cifIds));
        assertEquals("Invalid Date Range!", ex.getMessage());
    }

    @Test
    public void launchJobWithNullDates() throws Exception {
        accStmtsService.accStmtsJobLauncher(null, null, cifIds);
    }

    @Test
    public void launchJobWithWithEmptyCif() throws Exception {
        Exception ex = assertThrows( InvalidInputException.class
                , () -> accStmtsService.accStmtsJobLauncher(new Date(), new Date(), Collections.EMPTY_LIST));
        assertEquals("Minimum one CIF Id is required!", ex.getMessage());
    }

}
