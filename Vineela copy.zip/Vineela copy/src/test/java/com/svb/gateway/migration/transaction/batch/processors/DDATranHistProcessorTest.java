package com.svb.gateway.migration.transaction.batch.processors;


import com.svb.gateway.migration.common.DataProvider;
import com.svb.gateway.migration.transaction.batch.dto.DDATransaction;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.batch.core.StepExecution;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.mock;

@SpringBootTest
@ExtendWith(SpringExtension.class)
public class DDATranHistProcessorTest {

    private DDATranHistProcessor ddaTranHistProcessor;


    @BeforeEach
    public void beforeEach() {
        ddaTranHistProcessor = new DDATranHistProcessor();
    }

    @Test
    public  void testProcessWithCreditTrnType()  throws Exception{

        DDATransaction ddaHist = (DDATransaction) DataProvider.getGenericObject(DataProvider.DATA_TRANSACTION, DDATransaction.class);
        DDATransaction txndetails  = ddaTranHistProcessor.process(ddaHist);
        assertNotNull(txndetails);
    }

    @Test
    public  void testProcessWithCreditMemoTrue()  throws Exception{

        DDATransaction ddaHist = (DDATransaction) DataProvider.getGenericObject(DataProvider.DATA_TRANSACTION2, DDATransaction.class);
        DDATransaction txndetails  = ddaTranHistProcessor.process(ddaHist);
        assertNotNull(txndetails);
    }

    @Test
    public  void testProcessBeforeStep()  throws Exception{

        StepExecution execution = mock(StepExecution.class);
        ddaTranHistProcessor.beforeStep(execution);
        ddaTranHistProcessor.afterStep(execution);
    }

}
