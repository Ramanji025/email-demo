package com.svb.gateway.migration.transaction.batch.processors;

import com.svb.gateway.migration.MigrationApplication;
import com.svb.gateway.migration.common.DataProvider;
import com.svb.gateway.migration.common.config.KafkaConfigurationProperties;
import com.svb.gateway.migration.transaction.batch.dto.DDATransaction;
import org.apache.kafka.clients.producer.RecordMetadata;
import org.apache.kafka.common.TopicPartition;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentMatchers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.PropertySource;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.SendResult;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.util.concurrent.ListenableFuture;
import org.springframework.util.concurrent.ListenableFutureCallback;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.*;

@SpringBootTest
@PropertySource("file:config/application-${environment}.properties")
@ContextConfiguration(classes = MigrationApplication.class)
public class DDATrnsKafkaWriterTest {


    @InjectMocks
    private TransactionKafkaWriter transactionKafkaWriter;
    @Mock
    private KafkaTemplate<String,String> kafkaTemplate;
    @Mock
    private KafkaConfigurationProperties properties;

   @Value("accounts.payment-tran.ir.in")
    private String jsonTopic;

    @Test
    public void kafkaWriterTest() throws Exception {
        String key = "130887";
        long offset = 1;
        int partition = 1;
        jsonTopic = "topic";
        SendResult<String, Object> sendResult = mock(SendResult.class);
        ListenableFuture<SendResult<String, String>> responseFuture = mock(ListenableFuture.class);
        RecordMetadata recordMetadata = new RecordMetadata(new TopicPartition(jsonTopic, partition), offset, 0L, 0L, 0L, 0, 0);

        given(sendResult.getRecordMetadata()).willReturn(recordMetadata);
        when(kafkaTemplate.send(ArgumentMatchers.any(), ArgumentMatchers.any(), ArgumentMatchers.any())).thenReturn(responseFuture);
        doAnswer(invocationOnMock -> {
            ListenableFutureCallback listenableFutureCallback = invocationOnMock.getArgument(0);
            listenableFutureCallback.onSuccess(sendResult);
            assertEquals(sendResult.getRecordMetadata().offset(), offset);
            assertEquals(sendResult.getRecordMetadata().partition(), partition);
            return null;
        }).when(responseFuture).addCallback(any(ListenableFutureCallback.class));
        List<DDATransaction> txndetails = new ArrayList<>(
                Arrays.asList((DDATransaction) DataProvider.getGenericObject(DataProvider.DATA_TRANSACTION2, DDATransaction.class),
                        (DDATransaction) DataProvider.getGenericObject(DataProvider.DATA_TRANSACTION2, DDATransaction.class),
                        (DDATransaction) DataProvider.getGenericObject(DataProvider.DATA_TRANSACTION2, DDATransaction.class)
                ));

         transactionKafkaWriter.write(txndetails);
    }


    @Test
    public void kafkaWriterTestFailure() throws Exception {

        jsonTopic = "topic";
        SendResult<String, Object> sendResult = mock(SendResult.class);
        ListenableFuture<SendResult<String, String>> responseFuture = mock(ListenableFuture.class);
        Throwable throwable = mock(Throwable.class);
        given(throwable.getMessage()).willReturn("Exception");

        when(kafkaTemplate.send(ArgumentMatchers.any(), ArgumentMatchers.any(), ArgumentMatchers.any())).thenReturn(responseFuture);

        doAnswer(invocationOnMock -> {
            ListenableFutureCallback listenableFutureCallback = invocationOnMock.getArgument(0);
            listenableFutureCallback.onFailure(throwable);
            return null;
        }).when(responseFuture).addCallback(any(ListenableFutureCallback.class));

        List<DDATransaction> txndetails = new ArrayList<>(
                Arrays.asList((DDATransaction) DataProvider.getGenericObject(DataProvider.DATA_TRANSACTION2, DDATransaction.class),
                        (DDATransaction) DataProvider.getGenericObject(DataProvider.DATA_TRANSACTION2, DDATransaction.class),
                        (DDATransaction) DataProvider.getGenericObject(DataProvider.DATA_TRANSACTION2, DDATransaction.class)
                ));

        transactionKafkaWriter.write(txndetails);
    }
}
