package com.svb.gateway.migration.transaction.controller;

import com.svb.gateway.migration.job.model.CreateJobResponse;
import com.svb.gateway.migration.job.model.CreateJobResponseData;
import com.svb.gateway.migration.transaction.service.DDATransactionService;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentMatchers;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.web.servlet.MockMvc;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static com.svb.gateway.migration.TestUtil.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@AutoConfigureMockMvc
public class DDATranscationJobControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private DDATransactionService ddaTransactionService;

    @Test
    @WithMockUser(username = TEST_USER_USER1, password = TEST_USER1_VALID_PASSWORD, authorities = TEST_USER1_ROLE_EXECUTE)
    public void ddaTransactionValid() throws Exception {

        Mockito.when(ddaTransactionService.ddaTransactionJobLauncher(ArgumentMatchers.any(),
                ArgumentMatchers.any(),ArgumentMatchers.any())).thenReturn(new CreateJobResponse(
                new CreateJobResponseData(3L,"Completed")));
        List<String> cifs= new ArrayList<>(Arrays.asList("56982","5896574"));
        this.mockMvc.perform(post("/api/job/moveDDATransactionData").contentType(MediaType.APPLICATION_JSON_VALUE)
                .content("[2000123417,2000114351]")
                .header("Authorization","Basic Y3JtdXNlcjI6QWNjZXNzMTIz")
                .param("from", "2020-01-01")
                .param("to","2020-01-01"))
                .andExpect(status().isAccepted());
    }

    @Test
    @WithMockUser(username = TEST_USER_USER1, password = TEST_USER1_VALID_PASSWORD, authorities = TEST_USER1_ROLE_EXECUTE)
    public void ddaTransactionInvalid() throws Exception {
        Mockito.when(ddaTransactionService.ddaTransactionJobLauncher(ArgumentMatchers.any(),
                ArgumentMatchers.any(),ArgumentMatchers.any())).thenThrow(new Exception("Internal Server Error"));
        List<String> cifs= new ArrayList<>(Arrays.asList("56982","5896574"));
        this.mockMvc.perform(post("/api/job/moveDDATransactionData").contentType(MediaType.APPLICATION_JSON_VALUE)
                .content("[2000123417,2000114351]")
                .header("Authorization","Basic Y3JtdXNlcjI6QWNjZXNzMTIz")
                .param("from", "2020-01-01")
                .param("to","2020-01-01"))
                .andExpect(status().is5xxServerError());
    }
}
