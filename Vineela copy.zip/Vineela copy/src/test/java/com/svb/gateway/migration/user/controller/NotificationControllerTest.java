package com.svb.gateway.migration.user.controller;

import com.svb.gateway.migration.common.exception.ServiceException;
import com.svb.gateway.migration.user.service.NotificationService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentMatchers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

@SpringBootTest
@AutoConfigureMockMvc
public class NotificationControllerTest {

    @Mock
    private NotificationService notificationService;
    @InjectMocks
    private NotificationController notificationController;

    @BeforeEach
    public void setup() throws Exception {

        Mockito.doNothing().when(notificationService)
                .sendEmailNotification(ArgumentMatchers.anyString(), ArgumentMatchers.anyInt());
    }

    @Test
    public void testWelcomeEmail() throws Exception {
        notificationController.sendNotification(234,"test");
    }

    @Test
    public void testWelcomeEmailIf1() throws Exception {

        Exception ex = assertThrows( ServiceException.class
                , () -> notificationController.sendNotification(234, ""));
        assertEquals(ex.getMessage(),"Invalid ClientId");

    }
    @Test
    public void testWelcomeEmailIf2() throws Exception {
        Exception ex = assertThrows( ServiceException.class
                , () -> notificationController.sendNotification(0, "vsv"));
        assertEquals(ex.getMessage(),"Invalid Job Id");
    }

    @Test
    public void testWelcomeEmailIf2Null() throws Exception {
        Exception ex = assertThrows( ServiceException.class
                , () -> notificationController.sendNotification(null, "vsv"));
        assertEquals(ex.getMessage(),"Invalid Job Id");
    }
}
