package com.svb.gateway.migration.user.controller;

import com.svb.gateway.migration.client.entity.MigClient;
import com.svb.gateway.migration.user.model.AddUserResponse;
import com.svb.gateway.migration.user.model.CardUserResponse;
import com.svb.gateway.migration.user.service.UserService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentMatchers;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.web.servlet.MockMvc;

import static com.svb.gateway.migration.TestUtil.*;
import static com.svb.gateway.migration.user.service.UserServiceTest.migratingClientId;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@AutoConfigureMockMvc
public class UserControllerTest {

    @MockBean
    private UserService userService;
    @Autowired
    private MockMvc mockMvc;

    @BeforeEach
    public void setup() throws Exception {
        AddUserResponse addUserResponse =new AddUserResponse();
        Mockito.when(userService.createUsers(123L,new MigClient())).thenReturn(addUserResponse);
    }


    @Test
    @WithMockUser(username = TEST_USER_USER1, password = TEST_USER1_VALID_PASSWORD, authorities = TEST_USER1_ROLE_EXECUTE)
    public void withMockUser() throws Exception {
        CardUserResponse response = new CardUserResponse("test", "true", null);
        Mockito.when(userService.updateCardUserId(ArgumentMatchers.anyLong(), ArgumentMatchers.anyString())).thenReturn(response);
        this.mockMvc.perform(post("/migration/api/user/card/{jobId}/{ecClientId}", 123L, "test").contentType(MediaType.ALL_VALUE)
                .header("Authorization","Basic Y3JtdXNlcjI6QWNjZXNzMTIz"))
                .andExpect(status().isOk());
    }

}

