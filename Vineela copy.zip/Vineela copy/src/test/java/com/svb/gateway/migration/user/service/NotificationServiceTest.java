package com.svb.gateway.migration.user.service;

import com.svb.gateway.migration.common.exception.ServiceException;
import com.svb.gateway.migration.common.utility.CacheManagerUtility;
import com.svb.gateway.migration.common.utility.EntityLogUtility;
import com.svb.gateway.migration.user.mapper.UserMapper;
import com.svb.gateway.migration.user.model.UserNotification;
import com.svb.gateway.migration.user.repository.MigUserRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.*;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.web.client.RestTemplate;

import java.util.Collections;

import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;

@SpringBootTest
@ExtendWith(SpringExtension.class)
public class NotificationServiceTest {

    @InjectMocks
    @Spy
    private NotificationService notificationService;
    @Mock
    private RestTemplate restTemplate;
    @Mock
    private MigUserRepository migUserRepository;
    @Mock
    private CacheManagerUtility cacheManagerUtility;
    @Mock
    private UserMapper userMapper;
    @Mock
    EntityLogUtility entityLogUtility;

    @Test
    public void validJobId() throws ServiceException {
        ResponseEntity<String> response = new ResponseEntity<>("", HttpStatus.INTERNAL_SERVER_ERROR);
        doReturn(response).when(restTemplate).exchange(Mockito.anyString(),
                Mockito.any(HttpMethod.class), Mockito.any(HttpEntity.class),eq(Object.class));
        UserNotification un = new UserNotification() {
            @Override
            public String getEcClientId() {
                return "Test";
            }

            @Override
            public String getGwUid() {
                return "bbvdfbvfb";
            }

            @Override
            public String getGwClientId() {
                return null;
            }

            @Override
            public String getPrimaryCifUbs() {
                return null;
            }

            @Override
            public String getUserStatus() {
                return "Success";
            }

            @Override
            public String getClientStatus() {
                return "Success";
            }

            @Override
            public Integer getMigUserId() {return null;}
        };
        Mockito.when(migUserRepository.getMigratedUsers(ArgumentMatchers.anyString(),
                ArgumentMatchers.anyInt())).thenReturn(Collections.singletonList(un));
        Mockito.when(migUserRepository.findByJobIdActive(ArgumentMatchers.anyString(),
                ArgumentMatchers.anyInt())).thenReturn(Collections.singletonList(un));
        doNothing().when(userMapper).updateUserStatus(any());
        notificationService.sendEmailNotification("test",876);
    }

    @Test
    public void validFailedStatus() throws ServiceException {
        ResponseEntity<String> response = new ResponseEntity<>("", HttpStatus.INTERNAL_SERVER_ERROR);
        doReturn(response).when(restTemplate).exchange(Mockito.anyString(),
                Mockito.any(HttpMethod.class), Mockito.any(HttpEntity.class),eq(Object.class));
        UserNotification un = new UserNotification() {
            @Override
            public String getEcClientId() {
                return "Test";
            }

            @Override
            public String getGwUid() {
                return "bbvdfbvfb";
            }

            @Override
            public String getGwClientId() {
                return null;
            }

            @Override
            public String getPrimaryCifUbs() {
                return null;
            }

            @Override
            public String getUserStatus() {
                return "Failed";
            }

            @Override
            public String getClientStatus() {
                return "Success";
            }

            @Override
            public Integer getMigUserId() {return null;}
        };
        Mockito.when(migUserRepository.getMigratedUsers(ArgumentMatchers.anyString(),
                ArgumentMatchers.anyInt())).thenReturn(Collections.singletonList(un));
        Mockito.when(migUserRepository.findByJobIdActive(ArgumentMatchers.anyString(),
                ArgumentMatchers.anyInt())).thenReturn(Collections.singletonList(un));
        doNothing().when(userMapper).updateUserStatus(any());
        notificationService.sendEmailNotification("test",876);
    }

    @Test
    public void validFailedStatus2() throws ServiceException {
        ResponseEntity<String> response = new ResponseEntity<>("", HttpStatus.INTERNAL_SERVER_ERROR);
        doReturn(response).when(restTemplate).exchange(Mockito.anyString(),
                Mockito.any(HttpMethod.class), Mockito.any(HttpEntity.class),eq(Object.class));
        UserNotification un = new UserNotification() {
            @Override
            public String getEcClientId() {
                return "Test";
            }

            @Override
            public String getGwUid() {
                return "bbvdfbvfb";
            }

            @Override
            public String getGwClientId() {
                return null;
            }

            @Override
            public String getPrimaryCifUbs() {
                return null;
            }

            @Override
            public String getUserStatus() {
                return "Failed";
            }

            @Override
            public String getClientStatus() {
                return "Failed";
            }

            @Override
            public Integer getMigUserId() {return null;}
        };
        Mockito.when(migUserRepository.getMigratedUsers(ArgumentMatchers.anyString(),
                ArgumentMatchers.anyInt())).thenReturn(Collections.singletonList(un));
        Mockito.when(migUserRepository.findByJobIdActive(ArgumentMatchers.anyString(),
                ArgumentMatchers.anyInt())).thenReturn(Collections.singletonList(un));
        doNothing().when(userMapper).updateUserStatus(any());

        notificationService.sendEmailNotification("test",876);
    }

    @Test
    public void validFailedStatus3() throws ServiceException {
        ResponseEntity<String> response = new ResponseEntity<>("", HttpStatus.INTERNAL_SERVER_ERROR);
        doReturn(response).when(restTemplate).exchange(Mockito.anyString(),
                Mockito.any(HttpMethod.class), Mockito.any(HttpEntity.class),eq(Object.class));
        UserNotification un = new UserNotification() {
            @Override
            public String getEcClientId() {
                return "Test";
            }

            @Override
            public String getGwUid() {
                return "bbvdfbvfb";
            }

            @Override
            public String getGwClientId() {
                return null;
            }

            @Override
            public String getPrimaryCifUbs() {
                return null;
            }

            @Override
            public String getUserStatus() {
                return "Success";
            }

            @Override
            public String getClientStatus() {
                return "Failed";
            }

            @Override
            public Integer getMigUserId() {return null;}
        };
        Mockito.when(migUserRepository.getMigratedUsers(ArgumentMatchers.anyString(),
                ArgumentMatchers.anyInt())).thenReturn(Collections.singletonList(un));
        Mockito.when(migUserRepository.findByJobIdActive(ArgumentMatchers.anyString(),
                ArgumentMatchers.anyInt())).thenReturn(Collections.singletonList(un));
        doNothing().when(userMapper).updateUserStatus(any());
        notificationService.sendEmailNotification("test",876);
    }

    @Test
    public void validFailedStatusException() throws ServiceException {
        doThrow(new RuntimeException("test")).when(cacheManagerUtility).getOauthToken();
        UserNotification un = new UserNotification() {
            @Override
            public String getEcClientId() {
                return "Test";
            }

            @Override
            public String getGwUid() {
                return "bbvdfbvfb";
            }

            @Override
            public String getGwClientId() {
                return null;
            }

            @Override
            public String getPrimaryCifUbs() {
                return null;
            }

            @Override
            public String getUserStatus() {
                return "Success";
            }

            @Override
            public String getClientStatus() {
                return "Success";
            }

            @Override
            public Integer getMigUserId() {return null;}
        };
        Mockito.when(migUserRepository.getMigratedUsers(ArgumentMatchers.anyString(),
                ArgumentMatchers.anyInt())).thenReturn(Collections.singletonList(un));
        Mockito.when(migUserRepository.findByJobIdActive(ArgumentMatchers.anyString(),
                ArgumentMatchers.anyInt())).thenReturn(Collections.singletonList(un));
        doNothing().when(userMapper).updateUserStatus(any());
        notificationService.sendEmailNotification("test",876);
    }
}
