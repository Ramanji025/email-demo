import requests
import sys

# sample usage - python ./Cyberark-automation/Cyberark_automation.py 'APP-Gateway3-PP' 'MA-GATEWAY3-PP' 'gateway-authms' 'perf' 'APP-Gateway3 ''MA-GATEWAY3' 'client_secret,DISTRIBUTED_PASSWORD,VIRTUAL_PASSOWRD,DB_PWD_SEED,LOGS_DB_PWD_SEED,DB_PWD_RANDOM_KEY,FACEBOOK_APP_SECRET,LOCALTSAPRIVATECERTPASSWORD,STOREPASSWORD,PORTAL_PASSWORD,OTP_CRYPT_SEED' 'ExternalConfig/${env}/CommonCredential.json,ExternalConfig/${env}/Credential.json'


def getPassword(objectName):
        r = requests.get(objectName)
        output = r.json()
        return output['Content']

def replaceText(fileName, token, value):
        f = open(fileName,'r')
        filedata = f.read()
        f.close()
        newdata = filedata.replace('cyberark_{}_token'.format(token), value)
        f = open(fileName,'w')
        f.write(newdata)
        f.close()


AppId = sys.argv[1]
print("this is AppId "+AppId)
Safe = sys.argv[2]
print("this is Safe "+Safe)
componentName = sys.argv[3]
print("this is componentName "+componentName)
environment = sys.argv[4]
print("this is environment "+environment)
properties =  sys.argv[5].split(',')
print("this is properties ")
print(properties)
filePaths =  sys.argv[6].split(',')
print("this is filePaths ")
print(filePaths)
objectFormat = 'https://ccp.corp.svbank.com/AIMWebService/api/Accounts?AppID={}&Query=Safe={};Object=Operating System-GenericPlatform-{}-{}-{}'
print("this is objectformat line 30 "+objectFormat)
for property in properties:
        print("this is objectformat line 32 "+objectFormat)
        objectName = objectFormat.format(AppId, Safe, componentName, environment, property)
    	print(objectName)
        objectValue = getPassword(objectName)
        for filePath in filePaths:
                replaceText(filePath, property, objectValue)
