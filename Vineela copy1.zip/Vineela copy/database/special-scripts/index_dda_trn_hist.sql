CREATE INDEX gwdmg.dda_trn_hist_trn_cd_idx ON gwdmg.dda_trn_hist(trn_cd);
CREATE INDEX gwdmg.account_prod_typ_idx ON gwdmg.account(prod_typ);
CREATE INDEX gwdmg.prod_typ_prod_typ_idx ON gwdmg.prod_typ(prod_typ);