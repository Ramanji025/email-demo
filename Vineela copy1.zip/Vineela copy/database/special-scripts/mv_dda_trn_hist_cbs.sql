CREATE MATERIALIZED VIEW gwdmg.dda_trn_hist_cbs_mv
BUILD IMMEDIATE
REFRESH FORCE
ON DEMAND
AS

SELECT
    acc_num  accountId,
    '***'||substr(th.acc_num,-4) maskedAccNum,
    rnk,
    NUM_TRN_DY transactionId,
    ACC_TYP,
    PST_DT transactionDate,
    NUM_TRN_DY timeOfDay,
    DECODE(dr_cr_cd, '6', '05', '7', '05', '8', '05', '04') amountCode,
    DECODE(dr_cr_cd, '6', 'Debit', '7', 'Debit', '8', 'Debit', 'Credit')  as amtCodeDescription,
    TO_CHAR(to_date(PST_DT, 'DD-MON-YY HH24:mi:ss'), 'YYYY-Q') AS tranQuarter ,
    curr_bal balanceOfPosting,
    TRN_AMT transactionAmount,
    TRN_DESC transactionTypeDesc,
    SUM(reverse_signed_amount) OVER(PARTITION BY acc_num order by rnk)-reverse_signed_amount+curr_bal runningBalance,
    SUM(reverse_signed_amount) OVER(PARTITION BY acc_num, pst_dt order by PST_DT desc, NUM_TRN_DY desc)-reverse_signed_amount+ledg_bk_bal runningBalance_From_Trend,
    ledg_bk_bal,
    CASE WHEN REGEXP_LIKE(SRL_CHK_NUM, '^[-+]?[0-9]+$') THEN CAST(SRL_CHK_NUM AS NUMBER) ELSE 0 END instrumentId,
    SRL_CHK_NUM,
    DESC_1 || DESC_2 || DESC_3 transactionRemarks,
    CASE WHEN TRN_CD = 82 THEN ('Check paid' || '#' || SRL_CHK_NUM)
    ELSE nvl(DESC_1 || DESC_2 || DESC_3, TRN_DESC) END transactionRemarks_UI,
    RVSL_FLG rvslFlag,
    DESC_1 transactionTypeDesc1,
    DESC_2,
    Desc_3,
    TRN_CD transactionTypeCode,
    BANK_REF bankReferenceNumber,
    NVL(upper(business_unit), 'SB0')  businessUnit,
    'SVB'   bankId,
    NVL(currency_code   , 'USD') currency,
    0 runNumber,
    GROUP_ID transactionGrp,
    FILE_SEQ_ID,
    appl_num applNum,
    DECODE(appl_num, 20, 'CAA', 50, 'LAA', 'CAA') as applNumCode,
    account_info_source_id accountInfoSourceId,
    DECODE(account_info_source_id, 1, 'SVB DDA', 2, 'SVB MCA', 'SVB DDA') as accountInfoSourceDesc,
    PROD_DESC accountTitle,
    PROD_TYP prodType,
    PROD_DESC prodTypeDesc,
    SVB_UPDT_TIMESTAMP,
    to_char(TRN_AMT) transactionAmountStr,
    CONV_RATE,
    LCY_CODE,
    SORT_CD sortCode,
    'POS'   transStatusCode,
    'POSTED'    transStatusDescription,
    account_identifier
FROM (SELECT a.acc_num, dsc.TRN_DESC, td.GROUP_ID, pt.PROD_DESC,pt.PROD_TYP, curr_bal, d.PST_DT, d.num_trn_dy, d.account_identifier,a.appl_num,a.account_info_source_id,
        CASE WHEN d.dr_cr_cd not in (6,7,8) then -1*d.TRN_AMT ELSE D.TRN_AMT end reverse_signed_amount, TRN_ID, d.ACC_TYP, d.DR_CR_CD, d.TRN_AMT, d.SRL_CHK_NUM,
        d.RVSL_FLG, d.DESC_1, d.DESC_2, d.DESC_3, d.TRN_CD, d.BANK_REF, d.FILE_SEQ_ID, d.SVB_UPDT_TIMESTAMP, d.TRAN_AMT_LCY, d.CONV_RATE, d.LCY_CODE, d.SORT_CD,
        RANK() OVER(PARTITION BY d.account_identifier ORDER BY PST_DT desc, NUM_TRN_DY desc) rnk, tr.ledg_bk_bal, a.business_unit, a.currency_code
        from gwdmg.dda_trn_hist d
            inner join gwdmg.account a on d.account_identifier = a.account_identifier
            inner join gwdmg.dda_acc da on d.account_identifier = da.account_identifier
            left join gwdmg.dda_acc_trend tr on d.account_identifier = tr.account_identifier and d.pst_dt = tr.as_of_dt
            left join gwdmg.TRN_DESC dsc on d.trn_cd=dsc.trn_cd
            left join gwdmg.dda_trn_desc td on d.trn_cd = td.Internal_trn_cd
            left join gwdmg.prod_typ pt on a.prod_typ = pt.prod_typ and pt.appl_num = 20
            where a.ACCOUNT_INFO_SOURCE_ID = 1 and NVL(a.BUSINESS_UNIT,'SB0') = 'SB0'

        ) th
;

