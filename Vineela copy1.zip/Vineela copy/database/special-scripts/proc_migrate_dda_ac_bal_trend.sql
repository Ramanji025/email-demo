CREATE OR REPLACE PROCEDURE migrateDdaAcBalTrend (
    p_fromDate           IN Date,
    p_toDate             IN Date
)
IS
BEGIN

    MERGE INTO OCHADM.AC_BAL_TREND D
       USING (SELECT AC.ACC_NUM, AC.CUST_NUM, AC.BUSINESS_UNIT, LEDG_BK_BAL,  OPENING_AVL_BAL,
                    LAG (DT.ledg_bk_bal, 1) OVER (PARTITION BY DT.account_identifier ORDER BY DT.as_of_dt) AS OPENING_LEDG_BAL,
                    LAG (DT.opening_avl_bal, 1) OVER (PARTITION BY DT.account_identifier ORDER BY DT.as_of_dt) AS CURR_OPENING_AVL_BAL,
                    DT.COLLECTED_BAL, DT.ONE_DY_FLT, DT.TWO_PLS_DY_FLT, DT.TOTEL_NUM_CR,
                    DT.TOTAL_AMT_CR, DT.TOTEL_NUM_DB, DT.TOTAL_AMT_DB, DT.AS_OF_DT, DT.AVAILABLE_AMOUNT_OF_LINE_TCY, DT.LINE_AMOUNT_TCY
                FROM GWDMG.DDA_ACC_TREND DT
                    INNER JOIN GWDMG.ACCOUNT AC on DT.ACCOUNT_IDENTIFIER = AC.ACCOUNT_IDENTIFIER
                WHERE AC.ACCOUNT_INFO_SOURCE_ID = 1 and NVL(AC.BUSINESS_UNIT,'SB0') = 'SB0'
                    AND DT.AS_OF_DT BETWEEN p_fromDate AND p_toDate
             ) S
       ON (D.AS_OF_DT = S.AS_OF_DT and D.ACID = S.ACC_NUM)
       WHEN NOT MATCHED THEN INSERT (DB_TS,
                                     BANK_ID,
                                     BRANCH_ID,
                                     ACID,
                                     LEDG_BK_BAL,
                                     COLLECTED_BAL,
                                     OPENING_AVL_BAL,
                                     AVAILABLE_AMT_OF_LINE_TCY,
                                     ONE_DY_FLT,
                                     TWO_PLS_DY_FLT,
                                     TOTEL_NUM_CR,
                                     TOTAL_AMT_CR,
                                     TOTEL_NUM_DB,
                                     TOTAL_AMT_DB,
                                     AS_OF_DT,
                                     LINE_AMT_TCY,
                                     DEL_FLG,
                                     R_CRE_ID,
                                     R_CRE_TIME,
                                     OPENING_LEDG_BAL,
                                     CURR_OPENING_AVL_BAL)
                                 VALUES (1,
                                         'SVB',
                                         NVL(S.BUSINESS_UNIT,'SB0'),
                                         S.ACC_NUM,
                                         S.LEDG_BK_BAL,
                                         S.COLLECTED_BAL,
                                         S.OPENING_AVL_BAL,
                                         S.AVAILABLE_AMOUNT_OF_LINE_TCY,
                                         S.ONE_DY_FLT,
                                         S.TWO_PLS_DY_FLT,
                                         S.TOTEL_NUM_CR,
                                         S.TOTAL_AMT_CR,
                                         S.TOTEL_NUM_DB,
                                         S.TOTAL_AMT_DB,
                                         S.AS_OF_DT,
                                         S.LINE_AMOUNT_TCY,
                                         'N',
                                         'SVB.svc.migration',
                                         sysdate,
                                         OPENING_LEDG_BAL,
                                         CURR_OPENING_AVL_BAL);

dbms_output.put_line( sql%rowcount || ' rows affected...' );

 END;



