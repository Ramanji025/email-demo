create or replace PROCEDURE migrateOnlineStatementInfo(
    p_fromDate           IN Date,
    p_toDate             IN Date
)
IS
BEGIN
MERGE INTO GWREPORTING.ONLINE_STATEMENTS_INFO D
    USING (SELECT AC.ACC_NUM, ST.CBS_STMT_DATE, ST.STMT_AVAIL_CONF_TSTAMP, ST.STMT_AVAILABLE,
                  ST.STMT_FIRST_RETR_SUCC_TSTAMP, ST.STMT_CYCLE_DATE, ST.STATEMENT_TYPE,
                  CASE AC.ACC_TYP
                      WHEN 6 THEN 'CAA'
                      WHEN 0 THEN 'LAA'
                      END AC_TYPE,
                  CASE
                      WHEN LENGTH(DA.ACC_MODIFIER) > 20 THEN PT.PROD_DESC
                      ELSE DA.ACC_MODIFIER
                      END AC_NAME,
                  CASE ST.STATEMENT_TYPE
                      WHEN 'BILLING_ST' THEN 'AA'
                      ELSE 'DDA'
                      END STMT_PROD_TYPE
           FROM GWDMG.ONLINE_STATEMENTS_INFO ST
                    INNER JOIN GWDMG.ACCOUNT AC ON ST.ACCOUNT_IDENTIFIER = AC.ACCOUNT_IDENTIFIER
                    INNER JOIN GWDMG.DDA_ACC DA ON ST.ACCOUNT_IDENTIFIER = DA.ACCOUNT_IDENTIFIER
                    INNER JOIN GWDMG.PROD_TYP PT ON AC.PROD_TYP = PT.PROD_TYP AND PT.APPL_NUM = 20
           WHERE AC.ACCOUNT_INFO_SOURCE_ID = 1 and NVL(AC.BUSINESS_UNIT,'SB0') = 'SB0'
             AND ST.CBS_STMT_DATE BETWEEN p_fromDate AND p_toDate
    ) S
    ON (D.CBS_STMT_DATE = S.CBS_STMT_DATE and D.ACID = S.ACC_NUM and D.STMT_PROD_TYPE = S.STMT_PROD_TYPE)
    WHEN NOT MATCHED THEN INSERT (ACID,
                                  CBS_STMT_DATE,
                                  STMT_AVAIL_CONF_TSTAMP,
                                  STMT_AVAILABLE,
                                  STMT_FIRST_RETR_SUCC_TSTAMP,
                                  STMT_CYCLE_DATE,
                                  STATEMENT_TYPE,
                                  AC_TYPE,
                                  AC_NAME,
                                  STMT_PROD_TYPE,
                                  CREATED_BY,
                                  CREATED_TIME,
                                  MODIFIED_BY,
                                  MODIFIED_TIME)
        VALUES (S.ACC_NUM,
                S.CBS_STMT_DATE,
                S.STMT_AVAIL_CONF_TSTAMP,
                S.STMT_AVAILABLE,
                S.STMT_FIRST_RETR_SUCC_TSTAMP,
                S.STMT_CYCLE_DATE,
                S.STATEMENT_TYPE,
                S.AC_TYPE,
                S.AC_NAME,
                S.STMT_PROD_TYPE,
                'SVB.svc.migration',
                SYSDATE,
                'SVB.svc.migration',
                SYSDATE);

dbms_output.put_line( sql%rowcount || ' rows affected...' );

END;