
export JAVA_OPTS="$JAVA_OPTS -DGATEWAY-MIGRATION-HOME_DIR=/u01/apps/gateway-migration-service"
export JAVA_OPTS="$JAVA_OPTS -Dspring.profiles.active=${environment}"
export JAVA_OPTS="$JAVA_OPTS -Dspring.config.additional-location=file:/u01/apps/gateway-migration-service/config/config-${environment}.properties"
export JAVA_OPTS="$JAVA_OPTS -Djavax.net.ssl.trustStore=/etc/pki/java/cacerts"