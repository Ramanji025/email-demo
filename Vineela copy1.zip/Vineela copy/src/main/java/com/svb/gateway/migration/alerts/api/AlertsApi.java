package com.svb.gateway.migration.alerts.api;

import com.svb.gateway.migration.client.model.MigClientDTO;
import com.svb.gateway.migration.common.exception.ServiceException;
import com.svb.gateway.migration.alerts.model.AlertsResponse;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

@Api(value = "Alerts")
@RequestMapping("api/alerts")
public interface AlertsApi {
    @ApiOperation(value = "Endpoint for migrating signup alerts from eC to Gateway", nickname = "registerAlerts", notes = "Register Alerts")
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Alerts migrated successfully"),
            @ApiResponse(code = 401, message = "Unauthorized"),
            @ApiResponse(code = 400, message = "Invalid Client Id "),
            @ApiResponse(code = 403, message = "Forbidden"),
            @ApiResponse(code = 500, message = "Service unavailable ")})
    @PostMapping(value = "/{jobId}",
            produces = {"application/json"},
            consumes = {"application/json"})
    @ResponseStatus(HttpStatus.OK)
    @PreAuthorize("hasAuthority(@migrationServiceConfig.getAuthExecute())")
    public ResponseEntity<AlertsResponse> registerAlerts(@PathVariable Long jobId,@RequestBody MigClientDTO migClientDTO) throws ServiceException;
}
