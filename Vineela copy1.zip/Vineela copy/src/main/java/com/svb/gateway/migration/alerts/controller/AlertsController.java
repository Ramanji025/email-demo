package com.svb.gateway.migration.alerts.controller;

import com.svb.gateway.migration.alerts.service.AlertsService;
import com.svb.gateway.migration.client.entity.MigClient;
import com.svb.gateway.migration.client.model.MigClientDTO;
import com.svb.gateway.migration.common.exception.ServiceException;
import com.svb.gateway.migration.alerts.api.AlertsApi;
import com.svb.gateway.migration.alerts.model.AlertsResponse;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;
import springfox.documentation.annotations.ApiIgnore;

@RestController
@ApiIgnore
public class AlertsController implements AlertsApi {

    AlertsService alertsService;

    @Autowired
    public AlertsController(AlertsService alertsService){
        this.alertsService = alertsService;
    }

    @Override
    public ResponseEntity<AlertsResponse> registerAlerts(Long jobId, MigClientDTO migClientDTO)  {
        try {
            MigClient migClient=new MigClient();
            BeanUtils.copyProperties(migClientDTO, migClient);
            return new ResponseEntity<>(alertsService.registerAlerts(jobId,migClient), HttpStatus.OK);
        } catch (ServiceException e) {
            return new ResponseEntity<>(toErrorMessage(e.getMessage()), HttpStatus.BAD_REQUEST);
        }
    }

    private AlertsResponse toErrorMessage(String message) {
        AlertsResponse alertsResponse = new AlertsResponse();
        alertsResponse.setMessage(message);
        return alertsResponse;
    }
}
