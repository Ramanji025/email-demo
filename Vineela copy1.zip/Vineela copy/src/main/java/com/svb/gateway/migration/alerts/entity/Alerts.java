package com.svb.gateway.migration.alerts.entity;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import javax.persistence.*;
 
@ToString
@Getter
@Setter
@Entity
@Table(schema = "GWDMG", name = "MIG_STG_USER_SIGNUP_ALERTS")
@Data
public class Alerts {

    @Column(name = "EC_CLIENT_ID")
    private String ecClientId;

    @Column(name = "EC_USER_LOGIN_ID")
    private String ecUserLoginId;

    @Id
    @Column(name ="ALERTS_CLIENT_CONFIG_ID")
    private Integer alertsClientConfigId;

    @Column(name = "ALERT_TYPE_ID")
    private Integer alertTypeId;

    @Column(name = "ALERT_TYPE_NAME")
    private String alertTypeName;

    @Column(name = "EC_ALERT_TYPE")
    private String ecAlertType;

    @Column(name = "ALERT_STATUS")
    private String alertStatus;

    @Column(name = "JOB_ID")
    private String jobId;

    @Column(name = "REMARKS")
    private String remarks ;

    @Column(name = "GW_ALERT_ID")
    private String gwAlertId;

    @Column(name = "GW_ALERT_TYPE")
    private String gwAlertType ;

    @Column(name = "GW_ALERT_NAME")
    private String gwAlertName;

    @Column(name = "EC_SOURCE")
    private String eCSource;

    @Column(name = "EC_ALERT_ACCOUNT_ID")
    private String ecAlertAccountId;

    @Column(name = "EC_ALERT_DELIVERY_TYPE")
    private Integer ecAlertDeliveryType;

    @Column(name = "THRESHOLD_AMOUNT")
    private Integer thresholdAmount;

}
