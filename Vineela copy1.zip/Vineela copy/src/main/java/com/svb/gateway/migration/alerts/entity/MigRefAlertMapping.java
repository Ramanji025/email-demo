package com.svb.gateway.migration.alerts.entity;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@ToString
@Getter
@Setter
@Entity
@Table(schema = "GWDMG", name = "MIG_REF_ALERT_MAPPING")
@Data
public class MigRefAlertMapping {

    @Id
    @Column(name = "ID")
    private Integer id;

    @Column(name = "EC_ALERT_TYPE_ID")
    private Integer ecAlertTypeId;

    @Column(name = "EC_ALERT_NAME")
    private String ecAlertName;

    @Column(name = "GW_ALERT_ID")
    private String gwAlertId;

    @Column(name = "GW_ALERT_TYPE")
    private String gwAlertType;
}
