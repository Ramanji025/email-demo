package com.svb.gateway.migration.alerts.entity;

import com.svb.gateway.migration.common.processors.IRetry;
import lombok.*;

import java.time.LocalDateTime;

@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode
@ToString
@Setter
@Getter
public class MigratedAlertsEntity implements IRetry {

    private Long id;
    private Long jobId;
    private String ec_Client_Id;
    private String gw_Client_Id;
    private String ec_UserLogin_Id;
    private String cif_Number;
    private String gw_Uuid;
    private String gw_Alert_Id;
    private String gw_Alert_Account_Id;
    private String status;
    private String comments;
    private String updatedBy;
    private LocalDateTime updatedDate;
}
