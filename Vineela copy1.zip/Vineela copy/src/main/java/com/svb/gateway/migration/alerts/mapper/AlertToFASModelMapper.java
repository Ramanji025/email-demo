package com.svb.gateway.migration.alerts.mapper;

import com.svb.gateway.migration.alerts.entity.Alerts;
import com.svb.gateway.migration.alerts.entity.MigRefAlertMapping;
import com.svb.gateway.migration.alerts.model.AlertsFasRequest;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

@Mapper(componentModel="spring")
public interface AlertToFASModelMapper {
    AlertToFASModelMapper INSTANCE = Mappers.getMapper(AlertToFASModelMapper.class);

    public static String IS_SUBSCRIBED="true";
    public static String CHANNEL_REQUIRED_FLAG="Y";
    public static String CHANNEL_NOT_REQUIRED_FLAG="N";
    public static String ACCT_NUM="ACCT_NUM";
    public static String AMOUNT="AMOUNT";
    public static String AMOUNT_HEADER="AMOUNT_HEADER";
    public static String AMOUNT_AT_OR_ABOVE="Amount at or above";
    public static String EMAIL="EMAIL";
    public static String PUSH="PUSH";

    default String setEmailChannelFlag(Alerts alert){
        return alert.getEcAlertDeliveryType()==1||alert.getEcAlertDeliveryType()==3 ? CHANNEL_REQUIRED_FLAG:CHANNEL_NOT_REQUIRED_FLAG;
    }

    default String setPushChannelFlag(Alerts alert){
        return alert.getEcAlertDeliveryType()==2||alert.getEcAlertDeliveryType()==3 ? CHANNEL_REQUIRED_FLAG:CHANNEL_NOT_REQUIRED_FLAG;
    }

    default String setAmount(Alerts alert){
        return alert.getThresholdAmount()==null? "0":String.valueOf(alert.getThresholdAmount());
    }

    @Mapping(source="migRefAlertMapping.gwAlertId", target="alertId")
    @Mapping(constant = IS_SUBSCRIBED, target="isSubscribed")
    @Mapping(source="alert.ecAlertAccountId", target="accountNumber")
    @Mapping(source="fields", target="alertCriteriaRecord")
    @Mapping(source="channelDetails", target="channelDetails")
    AlertsFasRequest.Alerts convertSingleAlertToAPIRequestData(Alerts alert, MigRefAlertMapping migRefAlertMapping, AlertsFasRequest.Alerts.Field[] fields, AlertsFasRequest.Alerts.ChannelDetails[] channelDetails);

    @Mapping(constant = ACCT_NUM, target = "name")
    @Mapping(source="alert.ecAlertAccountId", target="value")
    AlertsFasRequest.Alerts.Field addAccountNumberToAlertCriteriaRecord(Alerts alert);

    @Mapping(constant = AMOUNT, target = "name")
    @Mapping(expression="java(setAmount(alert))", target="value")
    AlertsFasRequest.Alerts.Field addAmountToAlertCriteriaRecord(Alerts alert);

    @Mapping(constant = AMOUNT_HEADER, target = "name")
    @Mapping(constant = AMOUNT_AT_OR_ABOVE, target="value")
    AlertsFasRequest.Alerts.Field addAmountHeaderToAlertCriteriaRecord(Alerts alert);

    @Mapping(constant = EMAIL, target = "id")
    @Mapping(constant = EMAIL, target="name")
    @Mapping(expression="java(setEmailChannelFlag(alert))" , target = "isChannelRequiredFlag")
    AlertsFasRequest.Alerts.ChannelDetails setEmailChannelDetailsToRequest(Alerts alert);

    @Mapping(constant = PUSH, target = "id")
    @Mapping(constant = PUSH, target="name")
    @Mapping(expression="java(setPushChannelFlag(alert))" , target = "isChannelRequiredFlag")
    AlertsFasRequest.Alerts.ChannelDetails setPushChannelDetailsToRequest(Alerts alert);

}

