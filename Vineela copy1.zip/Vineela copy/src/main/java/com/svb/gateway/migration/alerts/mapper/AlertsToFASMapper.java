package com.svb.gateway.migration.alerts.mapper;

import com.svb.gateway.migration.alerts.entity.AlertUserLinkageEntity;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

@Mapper
@Repository
public interface AlertsToFASMapper {

    @Insert(value = {
            "INSERT INTO",
            "ALERTUSER.ALERT_USER_LINK_TBL",
            "(DB_TS,BANK_ID,ALERT_ID,CORP_ID,CUST_ID,ALRT_ACCT_ID,RELATED_PARTY_ID,HOST_ID,USER_CATEGORY_NAME,CHANNEL1,CHANNEL2,CHANNEL3,CHANNEL4,CHANNEL5,CHANNEL6,CHANNEL7,CHANNEL8,CHANNEL9,CHANNEL10,CHANNEL11,CHANNEL12,AMOUNT1,AMOUNT2,AMOUNT3,AMOUNT4,AMOUNT5,NUMBER1,NUMBER2,NUMBER3,NUMBER4,NUMBER5,ENTITY_CRE_FLG,DEL_FLG,R_MOD_USER_ID,R_MOD_TIME,R_CRE_USER_ID,R_CRE_TIME,SUBSCRIPTION_TYPE,FREQ_ID,ALERT_START_DATE,ALERT_END_DATE,NEXT_GEN_DATE,SUBSCRIPTION_NATURE)",
            "VALUES",
            "(#{dbTs}, #{bankId}, #{alertId}, #{corpId}, #{custId}, #{alrtAcctId}, #{relatedPartyId}, #{hostId}, #{userCategoryName}, #{channel1,jdbcType=CHAR}, #{channel2,jdbcType=CHAR}, #{channel3,jdbcType=CHAR}, #{channel4,jdbcType=CHAR}, #{channel5,jdbcType=CHAR}, #{channel6,jdbcType=CHAR}, #{channel7,jdbcType=CHAR}, #{channel8,jdbcType=CHAR}, #{channel9,jdbcType=CHAR}, #{channel10,jdbcType=CHAR}, #{channel11,jdbcType=CHAR}, #{channel12,jdbcType=CHAR}, #{amount1}, #{amount2}, #{amount3}, #{amount4}, #{amount5}, #{number1}, #{number2}, #{number3}, #{number4}, #{number5}, #{entityCreFlg}, #{delFlg}, #{rModUserId}, #{rModTime}, #{rCreUserId}, #{rCreTime}, #{subscriptionType}, #{freqId}, #{alertStartDate}, #{alertEndDate}, #{nextGenDate}, #{subscriptionNature})"
    })
    Integer insertSignedUpAlertsToFAS(AlertUserLinkageEntity alertUserLinkageEntity);
}
