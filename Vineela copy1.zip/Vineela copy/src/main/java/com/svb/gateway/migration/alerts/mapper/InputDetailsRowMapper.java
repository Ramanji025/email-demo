package com.svb.gateway.migration.alerts.mapper;

import com.svb.gateway.migration.alerts.entity.AlertsIPDTForAULTEntity;
import org.springframework.jdbc.core.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;

public class InputDetailsRowMapper implements RowMapper<AlertsIPDTForAULTEntity> {

    @Override
    public AlertsIPDTForAULTEntity mapRow(ResultSet rs, int rowNum) throws SQLException {

        AlertsIPDTForAULTEntity alertsIPDTForAULTEntity = new AlertsIPDTForAULTEntity();
        alertsIPDTForAULTEntity.setAlertId(rs.getString("ALERT_ID"));
        alertsIPDTForAULTEntity.setFieldName(rs.getString("FIELD_NAME"));
        alertsIPDTForAULTEntity.setDefaultValue(rs.getString("DEFAULT_VALUE"));

        return alertsIPDTForAULTEntity;

    }
}
