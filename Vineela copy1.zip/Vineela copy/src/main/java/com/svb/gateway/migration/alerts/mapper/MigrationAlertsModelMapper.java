package com.svb.gateway.migration.alerts.mapper;

import com.svb.gateway.migration.alerts.entity.Alerts;
import com.svb.gateway.migration.alerts.entity.MigratedAlertsEntity;
import com.svb.gateway.migration.alerts.entity.MigrationAlerts;
import com.svb.gateway.migration.alerts.model.MigAlertUser;
import com.svb.gateway.migration.common.utility.DateUtility;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import java.time.LocalDateTime;


@Mapper(componentModel="spring")
public interface MigrationAlertsModelMapper {

    MigrationAlertsModelMapper INSTANCE = Mappers.getMapper(MigrationAlertsModelMapper.class);
    public static final String ONE="1";

    @Mapping(source="alert.ecClientId",target="ecClientId")
    @Mapping(source="migrationUser.gwClientId",target="gwClientId")
    @Mapping(source="migrationUser.gwUid",target="gwUuid")
    @Mapping(source="migrationUser.ecUserLoginId",target="ecUserLoginId")
    @Mapping(source="alert.gwAlertId",target="gwAlertId")
    @Mapping(source="alert.jobId",target="jobId")
    @Mapping(source="alert.ecAlertAccountId",target="gwAlertAccountId")
    MigrationAlerts mapSignedUpAlertToEntity(Alerts alert, MigAlertUser migrationUser);

    @Mapping(source="alert.ecClientId",target="ecClientId")
    @Mapping(source="alert.jobId",target="jobId")
    @Mapping(source="alert.ecAlertAccountId",target="gwAlertAccountId")
    @Mapping(source="alert.ecUserLoginId",target="ecUserLoginId")
    MigrationAlerts mapFailedSignedUpAlertToEntity(Alerts alert);

    default public LocalDateTime getPSTDate(){
        return DateUtility.getTimeZoneDate("America/Los_Angeles");
    }

    default public String determineDuplicateStatus(MigratedAlertsEntity migratedAlerts){
        if(migratedAlerts!=null){
            return "Duplicate";
        }
        return "Failure";
    }

    default public String addComments(MigratedAlertsEntity migratedAlerts){

        if(migratedAlerts!=null){
            return "Already migrated in the previous job id: "+migratedAlerts.getJobId();
        }
        return "";
    }
}
