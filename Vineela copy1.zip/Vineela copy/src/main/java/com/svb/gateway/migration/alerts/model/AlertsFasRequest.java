package com.svb.gateway.migration.alerts.model;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class AlertsFasRequest {

    private Alerts[] alerts;

    @Getter
    @Setter
    @ToString
    public static class Alerts {
        private Field[] alertCriteriaRecord;
        private ChannelDetails[] channelDetails;
        private String isSubscribed;
        private String accountNumber;
        private String uniqueId;
        private String alertId;

        @Getter
        @Setter
        @ToString
        public static class ChannelDetails {
            private String id;
            private String name;
            private String isChannelRequiredFlag;
        }


        @Getter
        @Setter
        @ToString
        public static class Field {
            private String name;
            private String value;
        }
    }


}
