package com.svb.gateway.migration.alerts.model;

public interface MigAlertUser {
    String getEcClientId();
    String getEcUserLoginId();
    String getGwUid();
    String getGwClientId();
    String getPrimaryCifUbs();
    String getUserStatus();
    String getClientStatus();
}
