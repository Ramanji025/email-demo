package com.svb.gateway.migration.alerts.service;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.svb.gateway.migration.alerts.entity.*;
import com.svb.gateway.migration.alerts.mapper.AlertToFASModelMapper;
import com.svb.gateway.migration.alerts.mapper.AlertsToFASMapper;
import com.svb.gateway.migration.alerts.mapper.MigrationAlertsModelMapper;
import com.svb.gateway.migration.alerts.model.AlertsFasRequest;
import com.svb.gateway.migration.alerts.model.MigAlertUser;
import com.svb.gateway.migration.alerts.repository.MigAlertUserRepository;
import com.svb.gateway.migration.cards.entity.MigCardProgram;
import com.svb.gateway.migration.cards.repository.MigCardProgramRepository;
import com.svb.gateway.migration.common.constants.MigrationConstants;
import com.svb.gateway.migration.common.exception.ServiceException;

import com.svb.gateway.migration.common.logging.Message;
import com.svb.gateway.migration.common.service.RetryService;
import com.svb.gateway.migration.common.utility.CacheManagerUtility;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;


import static com.svb.gateway.migration.common.constants.MigrationConstants.*;
import static com.svb.gateway.migration.common.constants.MigrationConstants.ERROR_MESSAGE;

@Log4j2
@Service
@Transactional(rollbackFor = Exception.class)
public class AlertMigrationService {

    private static final String CARD_PROGRAM_NOT_ASSOCIATED_ERROR = "Client is not associated with the card program id: ";

    @Autowired
    AlertsToFASMapper alertsToFASMapper;

    @Autowired
    private MigAlertUserRepository migAlertUserRepository;

    @Autowired
    private MigCardProgramRepository migCardProgramRepository;

    @Autowired
    RetryService retryService;

    @Autowired
    CacheManagerUtility cacheManagerUtility;

    @Value(value = "${mig.alerts.url}")
    String alertsUrl;

    @Value(value = "${mig.vtUsername}")
    String vtUsername;

    public MigrationAlerts insert(Alerts alert, MigRefAlertMapping migRefAlertMapping) throws ServiceException {
        Message logMessage = Message.create().clientId(alert.getEcClientId()).descr("Registering alert for client id : "+ alert.getEcClientId()+" GWAlertId : "+migRefAlertMapping.getGwAlertId()).entityName(Message.Entity.alert).srcId(String.valueOf(alert.getAlertsClientConfigId()));
        log.info(logMessage);
        MigrationAlerts migrationAlerts;
        MigAlertUser migAlertUser=migAlertUserRepository.getMigratedAlertUser(alert.getEcClientId(),alert.getEcUserLoginId());
        if (migAlertUser == null) {
            String errorMessage="User is not migrated for client Id having EcUserLoginId: "+alert.getEcUserLoginId();
            log.info(logMessage.summary().descr("User is not migrated for record having alertsConfigId: "+alert.getAlertsClientConfigId()));
            migrationAlerts=setResponseForNonMigUser(alert,migRefAlertMapping,MigrationConstants.STATUS_FAILURE,errorMessage);
            return migrationAlerts;
        }

        try{
            validateClientCardProgramEnrollment(migAlertUser,alert);

            AlertsFasRequest.Alerts.Field[] fields= new AlertsFasRequest.Alerts.Field[3];
            fields[0]=AlertToFASModelMapper.INSTANCE.addAccountNumberToAlertCriteriaRecord(alert);
            fields[1]=AlertToFASModelMapper.INSTANCE.addAmountToAlertCriteriaRecord(alert);
            fields[2]=AlertToFASModelMapper.INSTANCE.addAmountHeaderToAlertCriteriaRecord(alert);

            AlertsFasRequest.Alerts.ChannelDetails[] channelDetails=new AlertsFasRequest.Alerts.ChannelDetails[2];
            channelDetails[0]=AlertToFASModelMapper.INSTANCE.setEmailChannelDetailsToRequest(alert);
            channelDetails[1]=AlertToFASModelMapper.INSTANCE.setPushChannelDetailsToRequest(alert);

            AlertsFasRequest.Alerts[] alerts= new AlertsFasRequest.Alerts[1];
            alerts[0]=AlertToFASModelMapper.INSTANCE.convertSingleAlertToAPIRequestData(alert,migRefAlertMapping,fields,channelDetails);

            AlertsFasRequest alertsFasRequest=new AlertsFasRequest();
            alertsFasRequest.setAlerts(alerts);
            invokeAlertsSubscription(alertsFasRequest,migAlertUser);

            log.info(logMessage.summary().descr("Alert registered in FAS completed successfully for alert Id: "+ migRefAlertMapping.getGwAlertId()));
            migrationAlerts=setResponse(alert, migAlertUser, migRefAlertMapping, MigrationConstants.STATUS_SUCCESS,MigrationConstants.MIGRATED_SUCCESS);

        }
        catch(Exception e){
            log.error(logMessage.summary().descr(e.getMessage()));
            migrationAlerts=setResponse(alert, migAlertUser, migRefAlertMapping, MigrationConstants.STATUS_FAILURE, e.getMessage());
        }
        return migrationAlerts;
    }

    private MigrationAlerts setResponse(Alerts alert, MigAlertUser migrationUser, MigRefAlertMapping migRefAlertMapping, String status, String message) {
        MigrationAlerts migrationAlerts= MigrationAlertsModelMapper.INSTANCE.mapSignedUpAlertToEntity(alert, migrationUser);
        migrationAlerts.setGwAlertId(migRefAlertMapping.getGwAlertId());
        if(null != migrationUser.getPrimaryCifUbs()){
            migrationAlerts.setCifNumber(migrationUser.getPrimaryCifUbs());
        }
        migrationAlerts.setStatus(status);
        migrationAlerts.setComments(message);
        return migrationAlerts;
    }

    private MigrationAlerts setResponseForNonMigUser(Alerts alert, MigRefAlertMapping migRefAlertMapping, String status, String message) {
        MigrationAlerts migrationAlerts= MigrationAlertsModelMapper.INSTANCE.mapFailedSignedUpAlertToEntity(alert);
        migrationAlerts.setGwAlertId(migRefAlertMapping.getGwAlertId());
        migrationAlerts.setStatus(status);
        migrationAlerts.setComments(message);
        return migrationAlerts;
    }

    private void validateClientCardProgramEnrollment(MigAlertUser migrationUser, Alerts alert) throws ServiceException {
        Message logMessage = Message.create().clientId(alert.getEcClientId()).entityName(Message.Entity.alert).operation("validateClientCardProgramEnrollment").srcId(String.valueOf(alert.getAlertsClientConfigId()));
        log.info(logMessage.descr("Checking if the alert is Card alert type"));
        if(alert.getAlertTypeName().startsWith("CAM_")){
            log.info(logMessage.descr("Fetching card program details as the alert is of Card type"));
            MigCardProgram migCardProgram=migCardProgramRepository.findByOlbIdAndCardProgram(migrationUser.getGwClientId(),alert.getEcAlertAccountId(),alert.getJobId(),MigrationConstants.STATUS_SUCCESS);
            if(migCardProgram==null){
                log.info(logMessage.summary().descr(CARD_PROGRAM_NOT_ASSOCIATED_ERROR+alert.getEcAlertAccountId()));
                throw new ServiceException(CARD_PROGRAM_NOT_ASSOCIATED_ERROR+alert.getEcAlertAccountId());
            }
            log.info(logMessage.summary().descr("Validated if the client is enrolled to the card program-"+migCardProgram.getProgramId()));
        }
    }

    private Object invokeAlertsSubscription(AlertsFasRequest alertsFasRequest,MigAlertUser migAlertUser) throws ServiceException, JsonProcessingException {
        String operation="InvokeAlertsMSForSubscription";
        Message logMessage=Message.create().gwClientId(migAlertUser.getGwClientId()).operation(operation);

        if(null==migAlertUser.getGwClientId()){
            log.info(logMessage.descr(" GwClientId is null, throwing Service Exception"));
            throw new ServiceException(" gwClientId is null");
        }

        log.info(logMessage.descr("Subscribing signup alerts via Alerts MS").summary());

        if(alertsFasRequest==null){
            log.info(logMessage.descr(" alertsFasRequest is null, throwing Service Exception"));
            throw new ServiceException(" alertsFasRequest is null");
        }
        Object objectResponse;
        String alertsSubscriptionUrl = alertsUrl +migAlertUser.getGwClientId()+ ALERTS_USERS +migAlertUser.getGwUid();
        ObjectMapper objMapper = new ObjectMapper();
        objMapper.setSerializationInclusion(JsonInclude.Include.NON_NULL);

        try {

            log.info(logMessage.descr(" Request for Alerts Subscription").url(alertsSubscriptionUrl));
            HttpHeaders headers = new HttpHeaders();
            headers.add(MigrationConstants.AUTHORIZATION_HEADER_NAME, cacheManagerUtility.getVTToken());
            headers.add(MigrationConstants.CONTENT_TYPE, MigrationConstants.APPLICATION_HEADER_JSON);

            HttpEntity<AlertsFasRequest> requestEntity = new HttpEntity<>(alertsFasRequest, headers);

            ResponseEntity<Object> alertsResponseHttpResponse  =
                    retryService.exchange(alertsSubscriptionUrl, HttpMethod.PUT, requestEntity, new ParameterizedTypeReference<Object>() {
                    });

            if (alertsResponseHttpResponse.getStatusCode() != HttpStatus.OK) {
                String errorResponse="Submit alerts subscription call failed with a non 200 response for request="+
                        alertsSubscriptionUrl +ERROR_CODE + alertsResponseHttpResponse.getStatusCode() + ERROR_MESSAGE +
                        alertsResponseHttpResponse.getBody();
                log.info(logMessage.descr(errorResponse));
                throw new ServiceException(operation+" : "+errorResponse);
            }
            objectResponse= alertsResponseHttpResponse.getBody();
        }
        catch (Exception e) {
            log.error(logMessage.descr("Error during alert migration : "+e.getMessage()));
            throw new ServiceException(operation+" : "+e.getMessage());
        }
        log.info(logMessage.descr("Alerts subscribed in FAS : "+objMapper.writeValueAsString(objectResponse)).summary());
        return objectResponse;
    }

}
