package com.svb.gateway.migration.alerts.service;

import com.svb.gateway.migration.alerts.entity.*;
import com.svb.gateway.migration.alerts.mapper.MigrationAlertsMapper;
import com.svb.gateway.migration.alerts.model.AlertsResponse;
import com.svb.gateway.migration.alerts.model.AlertsResponseData;
import com.svb.gateway.migration.alerts.repository.MigRefAlertMappingRepository;
import com.svb.gateway.migration.alerts.repository.SignUpAlertsRepository;
import com.svb.gateway.migration.client.entity.MigClient;
import com.svb.gateway.migration.common.constants.MigrationConstants;
import com.svb.gateway.migration.common.exception.ServiceException;
import com.svb.gateway.migration.common.logging.Message;
import com.svb.gateway.migration.common.mapper.MigrationEntityMapper;
import com.svb.gateway.migration.common.utility.EntityLogUtility;
import com.svb.gateway.migration.common.utility.RecordCount;
import com.svb.gateway.migration.rollback.model.RollBackResponse;
import lombok.extern.log4j.Log4j2;
import org.apache.commons.collections4.MultiValuedMap;
import org.apache.commons.collections4.multimap.ArrayListValuedHashMap;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.Collection;
import java.util.List;
import java.util.concurrent.atomic.AtomicReference;


@Log4j2
@Service
public class AlertsService {

    public static final String NO_DATA_TO_MIGRATE = "No alerts to migrate for provided client Id";
    public static final String NO_ALERTS_TO_MIGRATE = "No alerts to migrate";
    public static final String ENTITY_NAME = "Alert Subscription";

    @Value("${migration.service.userid}")
    public String migrationUserId;

    @Autowired
    private SignUpAlertsRepository signUpAlertsRepository;

    @Autowired
    private MigRefAlertMappingRepository migRefAlertMappingRepository;

    @Autowired
    private MigrationAlertsMapper migrationAlertsMapper;

    @Autowired
    private AlertMigrationService alertMigrationService;

    @Autowired
    EntityLogUtility entityLogUtility;

    public AlertsResponse registerAlerts(Long jobId,MigClient migClient) throws ServiceException {
        return process(migClient,jobId);
    }

    protected AlertsResponse process(MigClient migClient,Long jobId)  throws ServiceException {
        AlertsResponse alertsResponse = new AlertsResponse();
        Message logMessage = Message.create().jobId(jobId).clientId(migClient.getEcClientId()).gwClientId(migClient.getGwClientId()).entityName(Message.Entity.alert);
        log.info(logMessage.summary().descr("Entry: Registering alerts into Gateway"));
        final RecordCount recordCount=new RecordCount();
        recordCount.setStartTime(new Timestamp(System.currentTimeMillis()));

        final MigClient migratedClient = migClient;

        List<MigRefAlertMapping> migRefAlertMappingList = migRefAlertMappingRepository.findGWMappingDetails();
        MultiValuedMap<Integer, MigRefAlertMapping> eCtoGwReferenceMap = new ArrayListValuedHashMap<>();
        migRefAlertMappingList.forEach(migReference -> eCtoGwReferenceMap.put(migReference.getEcAlertTypeId(),migReference));
        log.info(logMessage.summary().descr("Fetched the details from Alerts reference mapping table"));

        List<Alerts> alertsList = signUpAlertsRepository.findByEcClientId(migClient.getEcClientId());
        log.info(logMessage.summary().descr("Fetching SignUp alerts for migration" ));
        if (alertsList.isEmpty()) {
            log.info(logMessage.summary().descr(NO_DATA_TO_MIGRATE));
            recordCount.setEndTime(new Timestamp(System.currentTimeMillis()));
            entityLogUtility.saveEntityCountAndTimeLog(MigrationEntityMapper.INSTANCE.convertNoAlertsToMigEntity(migratedClient, recordCount, ENTITY_NAME));
            alertsResponse.setAdditionalProperty(NO_ALERTS_TO_MIGRATE,NO_DATA_TO_MIGRATE);
           return alertsResponse;
        }
        log.info(logMessage.summary().descr("No.of Signup Alerts fetched from staging : "+alertsList.size()));

        alertsList.stream().forEach(alert -> {

            log.info(logMessage.summary().descr("Registering alert with alertTypeId - "+alert.getAlertTypeId()).srcId(String.valueOf(alert.getAlertsClientConfigId())));
            Collection<MigRefAlertMapping> noOfGwAlertsToBeMapped=eCtoGwReferenceMap.get(alert.getAlertTypeId());
            noOfGwAlertsToBeMapped.stream().forEach(migReference -> {
                recordCount.setTotal(recordCount.getTotal()+1);
                AtomicReference<MigrationAlerts> newAlert= new AtomicReference<>(new MigrationAlerts());

                MigratedAlertsEntity migratedAlert= migrationAlertsMapper.checkIfMigratedIgnoredOrRolledBack(jobId,migReference.getGwAlertId(),alert.getEcClientId(),alert.getEcUserLoginId());
                if (migratedAlert!=null && !migratedAlert.canRunAgain()){
                    recordCount.setTotal(recordCount.getTotal()-1);
                    log.info(logMessage.descr("Record is not eligible for run because of the presence of record in staging with status - "+migratedAlert.getStatus()));
                }
                else {
                    try{
                        newAlert.set(alertMigrationService.insert(alert,migReference));
                        updateCounter(recordCount, newAlert.get());
                        insertOrUpdateMigAlert(logMessage, newAlert, migratedAlert);
                    }
                    catch (ServiceException e) {
                        log.error(logMessage.descr("Error occurred while processing alert "+ alert.getAlertsClientConfigId() +" reason : "+ e.getMessage()));
                        alertsResponse.setAdditionalProperty(e.getErrorCode(), e.getErrorMessage());
                    }
                }
            });
        });
        recordCount.setEndTime(new Timestamp(System.currentTimeMillis()));
        createResponse(alertsResponse,recordCount,migClient);
        if(recordCount.getTotal()>0){
            log.info(logMessage.summary().descr("Entity logging done as there were records that underwent alert migration during this run"));
            entityLogUtility.saveEntityCountAndTimeLog(MigrationEntityMapper.INSTANCE.convertAlertsToMigEntity(alertsResponse, recordCount));
        }

        log.info(logMessage.descr("Alerts migration is completed for clientId "+ migClient.getEcClientId() + ".Response is "+ alertsResponse.toString()).timeTaken(recordCount.getTotalStepTime()));

        return alertsResponse;
    }

    private void insertOrUpdateMigAlert(Message logMessage, AtomicReference<MigrationAlerts> newAlert, MigratedAlertsEntity migratedAlert) {
        if(migratedAlert !=null && migratedAlert.getStatus().equalsIgnoreCase(MigrationConstants.STATUS_FAILURE)){
            log.info(logMessage.summary().descr("Updated alerts entity table with the migration status"));
            newAlert.get().setUpdatedBy(migrationUserId);
            newAlert.get().setUpdatedDate(LocalDateTime.now());
            migrationAlertsMapper.updateSignedUpAlerts(newAlert.get());
        }else{
            log.info(logMessage.summary().descr("Inserted alerts entity table with the migration status"));
            migrationAlertsMapper.insertSignedUpAlerts(newAlert.get());
        }
    }

    private void updateCounter(RecordCount recordCount, MigrationAlerts newAlert) {
        if (MigrationConstants.STATUS_SUCCESS.equalsIgnoreCase(newAlert.getStatus())) {
            recordCount.setSuccess(recordCount.getSuccess() + 1);
        } else {
            recordCount.setFailure(recordCount.getFailure() + 1);
        }
    }

    private void createResponse(AlertsResponse alertsResponse, RecordCount recordCount, MigClient migClient) {
        alertsResponse.setAlertsResponseData(AlertsResponseData.builder()
                .gwClientId(migClient.getGwClientId())
                .ecClientId(migClient.getEcClientId())
                .cifNumber(migClient.getPrimaryCifUbs()==null?null:migClient.getPrimaryCifUbs().toString())
                .jobId(migClient.getJobId()==null?0:migClient.getJobId().intValue())
                .recordCount(recordCount).build());
        alertsResponse.setAdditionalProperty("Total Records for client: " + migClient.getEcClientId() + " is: ", recordCount.getTotal());
        alertsResponse.setAdditionalProperty("Total Successfully registered alert Records: ", recordCount.getSuccess());
        alertsResponse.setAdditionalProperty("Total Failed alert Records :", recordCount.getFailure());
    }

    public void rollBackAlerts(String ecClientId, String gwClientId, RollBackResponse rollBackResponse) {
        var logMessage = Message.create().summary().clientId(ecClientId).gwClientId(gwClientId).entityName(Message.Entity.alert);
        try {
            migrationAlertsMapper.rollback(ecClientId);
            rollBackResponse.addSuccess("Alerts");
        }catch (Exception e) {
            log.error(logMessage.descr(e.getMessage()));
            rollBackResponse.addFailure("Alerts");
        }
    }
}
