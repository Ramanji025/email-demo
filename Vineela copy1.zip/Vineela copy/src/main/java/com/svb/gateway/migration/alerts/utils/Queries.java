package com.svb.gateway.migration.alerts.utils;

public final class Queries {

    public static final String FAS_IPDT_SELECT = "SELECT ALERT_ID,FIELD_NAME,DEFAULT_VALUE FROM ALERTUSER.IPDT WHERE BANK_ID='SVB' AND DEL_FLG='N'";
    public static final String FAS_AULT_INSERT = "INSERT INTO " +
            "ALERTUSER.ALERT_USER_LINK_TBL " +
            "(DB_TS,BANK_ID,ALERT_ID,CORP_ID,CUST_ID,ALRT_ACCT_ID,RELATED_PARTY_ID,HOST_ID,USER_CATEGORY_NAME,CHANNEL1,CHANNEL2,CHANNEL3,CHANNEL4,CHANNEL5,CHANNEL6,CHANNEL7,CHANNEL8,CHANNEL9,CHANNEL10,CHANNEL11,CHANNEL12,AMOUNT1,AMOUNT2,AMOUNT3,AMOUNT4,AMOUNT5,NUMBER1,NUMBER2,NUMBER3,NUMBER4,NUMBER5,ENTITY_CRE_FLG,DEL_FLG,R_MOD_USER_ID,R_MOD_TIME,R_CRE_USER_ID,R_CRE_TIME,SUBSCRIPTION_TYPE,FREQ_ID,ALERT_START_DATE,ALERT_END_DATE,NEXT_GEN_DATE,SUBSCRIPTION_NATURE,STRING1,STRING2,STRING3,STRING4) " +
            "VALUES " +
            "(:dbTs, :bankId, :alertId, :corpId, :custId, :alrtAcctId, :relatedPartyId, :hostId, :userCategoryName, :channel1, :channel2, :channel3, :channel4, :channel5, :channel6, :channel7, :channel8, :channel9, :channel10, :channel11, :channel12, :amount1, :amount2, :amount3, :amount4, :amount5, :number1, :number2, :number3, :number4, :number5, :entityCreFlg, :delFlg, :rmodUserId, sysdate, :rcreUserId, sysdate, :subscriptionType, :freqId, sysdate, to_date('31-DEC-2099','DD-MON-YYYY'), sysdate, :subscriptionNature, :string1, :string2, :string3, :string4) ";
    public static final String FAS_AULT_DELETE = "DELETE FROM ALERTUSER.ALERT_USER_LINK_TBL WHERE CORP_ID = :id";

    private Queries() {
    }

}
