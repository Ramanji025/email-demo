package com.svb.gateway.migration.beneficiaries.api;

import com.svb.gateway.migration.beneficiaries.entity.StgToTargetBeneEntity;
import com.svb.gateway.migration.beneficiaries.model.MigBeneResponse;
import com.svb.gateway.migration.common.exception.ServiceException;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Pattern;

import static com.svb.gateway.migration.common.constants.RegexConstants.EC_CLIENT_ID_PATTERN;


@Api(value = "Beneficiary")
@RequestMapping("api/beneficiaries")
@Validated
public interface BeneficiaryApi {


    @ApiOperation(value = "Endpoint for adding beneficiary in Gateway", nickname = "addBeneficiary", notes = "Add Beneficiary. PayeeType is PAST, TEMPLATE, FUTURE, CHECK, ACH or ACH_LARGE")
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Add Beneficiary is Successful"),
            @ApiResponse(code = 401, message = "Unauthorized"),
            @ApiResponse(code = 400, message = "Invalid Client Id"),
            @ApiResponse(code = 403, message = "Forbidden"),
            @ApiResponse(code = 500, message = "Service unavailable")})

    @PostMapping(value = "/addBeneficiaries/{jobId}/{clientId}/{payeeType}",
            produces = {"application/json"},
            consumes = MediaType.ALL_VALUE)
    @ResponseStatus(HttpStatus.OK)
    @PreAuthorize("hasAuthority(@migrationServiceConfig.getAuthExecute())")
    default ResponseEntity<MigBeneResponse> addBeneficiaries(@PathVariable
                                                             @Min(1) Long jobId,
                                                             @PathVariable
                                                             @NotEmpty
                                                             @Pattern(regexp = EC_CLIENT_ID_PATTERN) String clientId,
                                                             @PathVariable StgToTargetBeneEntity.PAYEE_TYPE payeeType) throws ServiceException {
        return new ResponseEntity<>(HttpStatus.NOT_IMPLEMENTED);
    }
}
