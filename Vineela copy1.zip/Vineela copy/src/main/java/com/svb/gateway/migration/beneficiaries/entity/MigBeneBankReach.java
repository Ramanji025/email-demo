package com.svb.gateway.migration.beneficiaries.entity;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Getter
@Setter
@ToString
@Entity
@Table(schema = "OCHADM", name = "BANK_ROUTING_ATTRIB_TABLE")
public class MigBeneBankReach {

    @Id
    @Column(name = "ROUTING_CODE")
    private String routingCode;

    @Column(name = "ROUTING_TYPE")
    private String routingType;

    @Column(name = "ROUTING_CODE_STATUS")
    private String routingCodeStatus;

    @Column(name = "CLEARING_SYSTEM")
    private String clearingSystem;
}
