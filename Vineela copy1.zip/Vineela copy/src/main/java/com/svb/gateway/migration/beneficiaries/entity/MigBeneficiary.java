package com.svb.gateway.migration.beneficiaries.entity;

import com.svb.gateway.migration.common.processors.IRetry;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import javax.persistence.*;
import java.util.Date;

@Getter
@Setter
@ToString
@Entity
@Table(name = "MIG_BENEFICIARY")
public class MigBeneficiary implements IRetry {

    @GeneratedValue(strategy=GenerationType.IDENTITY)
    @Id
    @Column(name = "CLIENTMIGID")
    private Integer clientMigId;

    @Column(name = "JOBID")
    private Long jobId;

    @Column(name = "ECCLIENTID")
    private String ecClientId;

    @Column(name = "GWCLIENTID")
    private String gwClientId;

    @Column(name = "BENEFICIARYID")
    private String beneficiaryId;

    @Column(name = "GROUPID")
    private String groupId;

    @Column(name = "BENESOURCETYPE")
    private String beneSourceType;

    @Column(name = "BENESOURCEID")
    private String beneSourceId;

    @Column(name = "RETRIED")
    private Integer retried;

    @Column(name = "COMMENTS")
    private String comments;

    @Column(name = "STATUS")
    private String status;

    @Column(name = "CREATEDBY")
    private String createdBy;

    @Column(name = "CREATEDDATE")
    private Date createdDt;

    @Column(name = "UPDATEDBY")
    private String updatedBy;

    @Column(name = "UPDATEDDATE")
    private Date updatedDt;

    @Column(name = "PENDING_BENEFICIARY_ID")
    private Long pendingRecipientId=null;

}
