package com.svb.gateway.migration.beneficiaries.entity;


import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import javax.persistence.*;
import java.time.LocalDate;

@Getter
@Setter
@ToString
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "sourceType",
        "sourceId",
        "clientId",
        "templateName",
        "paymentType",
        "entryopName",
        "entryDate",
        "approveLvl1Date",
        "currentState",
        "approveLvl1OpName",
        "nextState",
        "approveLvl2OpName",
        "cancelopName",
        "currencyCode",
        "forexAmount",
        "beneficiaryBankIdentifier",
        "approveLvl2Date",
        "beneficiaryAccount",
        "cancelDate",
        "beneficiaryName",
        "beneficiaryAddress2",
        "beneficiaryAddress1",
        "beneficiaryAddress3",
        "beneficiaryInstructions",
        "furtherApprovals",
        "totalApprovals",
        "beneficiaryBankName",
        "beneficiaryBankAddress",
        "beneficiaryBankCity",
        "beneficiaryBankCityZip",
        "beneficiaryBankState",
        "beneficiaryBankCountry",
        "entryopId",
        "approveLvl1OpId",
        "approveLvl2OpId",
        "cancelopId",
        "bankToBankInstructions",
        "beneficiaryBankSearchMode",
        "isTemplateImported",
        "fromAccountNumber",
        "enteredAmtInDebitCurrency",
        "debitingAmount",
        "debitingCurrencyCode",
        "isDeleted",
        "deleteopName",
        "deleteDate",
        "deleteopId",
        "templateCode",
        "importFileInfoId",
        "chargeCodeId",
        "beneficiaryBankRegion",
        "intermediaryId",
        "intermediaryName",
        "intermediaryAddress",
        "isBeneficiaryAccSvb",
        "isBeneficiaryAccSvbDda",
        "paymentUrgency",
        "routingCode"
})
@Entity
@Table(name = "MIG_STG_WIRE_TEMPLATE")
public class StgBeneficiary {

    @Id
    @Column(name = "TEMPLATE_ID")
    private Integer templateId;

    @Column(name = "OLB_CLIENT_ID")
    private String olbClientId;

    @Column(name = "PAYMENT_TYPE")
    private String paymentType;

    @Column(name = "CURRENCY_CODE")
    private String bnfCurrencyCode;

    @Column(name = "CURRENT_STATE")
    private Integer currentState;

    @Column(name = "BENEFICIARY_BANK_IDENTIFIER")
    private String bnfBankIdentifier;

    @Column(name = "BENEFICIARY_BANK_CITY")
    private String bnfBankCity;

    @Column(name = "BENEFICIARY_NAME")
    private String bnfName;

    @Column(name = "BENEFICIARY_ACCOUNT")
    private String bnfAccountId;

    @Column(name = "BENEFICIARY_ADDRESS_1")
    private String bnfAddressLine1;

    @Column(name = "JOB_ID")
    private String jobId;

    @Column(name = "CREATED_BY")
    private String createdBy;

    @Column(name = "CREATED_DT")
    private LocalDate createdDt;

    @Column(name = "TEMPLATE_CODE")
    private String templateCode;
}
