package com.svb.gateway.migration.beneficiaries.entity;

import com.svb.gateway.migration.beneficiaries.service.BeneficiaryValidationUtility;
import com.svb.gateway.migration.common.logging.Message;
import lombok.*;
import lombok.extern.log4j.Log4j2;

import javax.persistence.Column;
import java.sql.Date;
import java.util.HashMap;
import java.util.Map;

@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode
@ToString
@Setter
@Getter
@Log4j2
public class StgToTargetBeneEntity {

    public static final String E_CONNECT_TEMPLATE = "eConnectTemplate";
    public static final String E_CONNECT_WIRE = "eConnectWire";

    public enum PAYEE_TYPE {
        PAST(-1),
        TEMPLATE(0),
        FUTURE(1),
        CHECK(2),
        ACH(3),
        ACH_LARGE(4);


        private static Map<Integer,PAYEE_TYPE> map = new HashMap<>();
        static {
            for (PAYEE_TYPE type : PAYEE_TYPE.values()) {
                map.put(type.code, type);
            }
        }
        private int code ;

        PAYEE_TYPE (int code)
        {
            this.code = code ;
        }

        public int getCode(){
            return code;
        }

        public static PAYEE_TYPE valueOf(int code) {
            return map.get(code);
        }

        public static PAYEE_TYPE fromString(String text) {
            for (PAYEE_TYPE payeeType : PAYEE_TYPE.values()) {
                if (payeeType.name().equalsIgnoreCase(text)) {
                    return payeeType;
                }
            }
            return null;
        }
    }

    // for MIG_STG_FREEFORM_TO_BENE and MIG_STG_WIRE_OUTGOING tables
    private Integer WIRE_TRANSACTION_ID;

    // for MIG_STG_WIRE_TEMPLATE table
    private Integer TEMPLATE_ID;
    private String OLB_CLIENT_ID;
    private String TEMPLATE_NAME;
    private String PAYMENT_TYPE;
    private String ENTRYOP_NAME;
    private Date ENTRY_DATE;
    private Date APPROVE_LVL1_DATE;
    private String CURRENT_STATE;
    private String APPROVE_LVL1OP_NAME;
    private Integer NEXT_STATE;
    private String APPROVE_LVL2OP_NAME;
    private String CANCELOP_NAME;
    private String CURRENCY_CODE;
    private Integer FOREX_AMOUNT;
    private String BENEFICIARY_BANK_IDENTIFIER;
    private Date APPROVE_LVL2_DATE;
    private String BENEFICIARY_ACCOUNT;
    private Date CANCEL_DATE;
    private String BENEFICIARY_NAME;
    private String BENEFICIARY_ADDRESS_1;
    private String BENEFICIARY_ADDRESS_2;
    private String BENEFICIARY_ADDRESS_3;
    private String BENEFICIARY_INSTRUCTIONS;
    private Integer FURTHER_APPROVALS;
    private Integer TOTAL_APPROVALS;
    private String BENEFICIARY_BANK_NAME;
    private String BENEFICIARY_BANK_ADDRESS;
    private String BENEFICIARY_BANK_CITY;
    private String BENEFICIARY_BANK_CITY_ZIP;
    private String BENEFICIARY_BANK_STATE;
    private String BENEFICIARY_BANK_COUNTRY;
    private String ENTRYOP_ID;
    private String APPROVE_LVL1OP_ID;
    private Integer APPROVE_LVL2OP_ID;
    private Integer CANCELOP_ID;
    private String BANK_TO_BANK_INSTRUCTIONS;
    private Boolean BENEFICIARY_BANK_SEARCH_MODE;
    @Column(name = "IS_TEMPLATE_IMPORTED")
    private String IS_TEMPLATE_IMPORTED;
    private Integer ACCOUNT_IDENTIFIER;
    private Boolean ENTERED_AMT_IN_DEBIT_CURRENCY;
    private Double DEBITING_AMOUNT;
    private String DEBITING_CURRENCY_CODE;
    private Boolean IS_DELETED;
    private String DELETEOP_NAME;
    private Date DELETE_DATE;
    private Integer DELETEOP_ID;
    private String TEMPLATE_CODE;
    private Integer IMPORT_FILE_INFO_ID;
    private Integer CHARGE_CODE_ID;
    private String BENEFICIARY_BANK_REGION;
    private String INTERMEDIARY_ID;
    private String INTERMEDIARY_NAME;
    private String INTERMEDIARY_ADDRESS;
    private Boolean IS_BENEFICIARY_ACC_SVB;
    private Boolean IS_BENEFICIARY_ACC_SVB_DDA;
    private Boolean PAYMENT_URGENCY;
    private String ROUTING_CODE;


    private Long JOB_ID;
    private String CREATED_BY;
    private String CREATED_DT;
    private String MODIFIED_DT;

    // for MIG_STG_IPAY_PAYEES table
    private String EC_CLIENT_ID;
    private Integer IPAYEE_BENE_ID;
    private String SUBSCRIBER_ID;
    private String PAYEE_RELTNSHP_NUM;
    private String PAYEE_CITY;
    private String PAYEE_ZIP_CODE;
    private String ELECTRONIC_INDICATOR;
    private String BENEFICIARY_NICKNAME;
    private String PAYEE_PHONE_NUM;
    private String MERCHANT_CATEGORY;

    public Integer getSourceBeneId(PAYEE_TYPE type){
        switch (type){
            case TEMPLATE:
                return TEMPLATE_ID;
            case PAST: case FUTURE:
                return WIRE_TRANSACTION_ID;
            case CHECK: case ACH: case ACH_LARGE:
                return IPAYEE_BENE_ID;
            default:
                throw new IllegalArgumentException("Illegal value of PAYEE_TYPE");
        }
    }

    public String getSourceType(PAYEE_TYPE type){
        switch (type) {
            case TEMPLATE:
                return E_CONNECT_TEMPLATE;
            case FUTURE:
                return E_CONNECT_WIRE;
            default:
                throw new IllegalArgumentException("SourceType not supported for payee type " + type);
        }
    }

    public String getBENEFICIARY_BANK_IDENTIFIER() {
        BeneficiaryValidationUtility beneficiaryValidationUtility = new BeneficiaryValidationUtility();

        if(null!=BENEFICIARY_BANK_IDENTIFIER && BENEFICIARY_BANK_IDENTIFIER.length()==11 && BENEFICIARY_BANK_IDENTIFIER.endsWith("XXX")){
            log.info(Message.create().descr("Corrected the beneficiary Bank Identifier by removing XXX suffix for : "+BENEFICIARY_BANK_IDENTIFIER));

            return beneficiaryValidationUtility.removeSpecialChars(BENEFICIARY_BANK_IDENTIFIER).substring(0,8);
        }
        else{
            return beneficiaryValidationUtility.removeSpecialChars(BENEFICIARY_BANK_IDENTIFIER);
        }
    }
}
