package com.svb.gateway.migration.beneficiaries.mapper;


import com.svb.gateway.migration.beneficiaries.entity.StgToTargetBeneEntity;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;
import org.springframework.stereotype.Repository;


import java.util.List;

@Mapper
@Repository
public interface BeneficiaryMapper {
    @Select(value = {
            "SELECT",
            "TEMPLATE_ID,OLB_CLIENT_ID,PAYMENT_TYPE,CURRENCY_CODE,CURRENT_STATE,BENEFICIARY_BANK_IDENTIFIER,BENEFICIARY_BANK_CITY,BENEFICIARY_NAME,BENEFICIARY_ACCOUNT,BENEFICIARY_ADDRESS_1,BENEFICIARY_ADDRESS_2,BENEFICIARY_ADDRESS_3,TEMPLATE_CODE,JOB_ID,CREATED_BY,CREATED_DT",
            "FROM",
            "MIG_STG_WIRE_TEMPLATE",
            "WHERE",
            "OLB_CLIENT_ID = #{benfClientId} AND CURRENT_STATE=5 AND IS_DELETED!=1"
    })
    List<StgToTargetBeneEntity> findByOlbClientIdTemplates(String benfClientId);

    @Select(value = {
            "SELECT",
            "WIRE_TRANSACTION_ID,OLB_CLIENT_ID,PAYMENT_TYPE,CURRENCY_CODE,CURRENT_STATE,BENEFICIARY_BANK_IDENTIFIER,BENEFICIARY_BANK_CITY,BENEFICIARY_NAME,BENEFICIARY_ACCOUNT,BENEFICIARY_ADDRESS_1,BENEFICIARY_ADDRESS_2,JOB_ID,CREATED_BY,CREATED_DT",
            "FROM",
            "MIG_STG_FREEFORM_TO_BENE",
            "WHERE",
            "OLB_CLIENT_ID = #{benfClientId} AND CURRENT_STATE=4 AND NEXT_STATE=4 AND CANCEL_DATE IS NULL AND SETTLEMENT_DATE IS NOT NULL"
    })
    List<StgToTargetBeneEntity> findByOlbClientIdPastFreeForm(String benfClientId);

    @Select(value = {
            "SELECT",
            "WIRE_TRANSACTION_ID,OLB_CLIENT_ID,PAYMENT_TYPE,CURRENCY_CODE,CURRENT_STATE,BENEFICIARY_BANK_IDENTIFIER,BENEFICIARY_BANK_CITY,BENEFICIARY_NAME,BENEFICIARY_ACCOUNT,BENEFICIARY_ADDRESS_1,BENEFICIARY_ADDRESS_2,JOB_ID,CREATED_BY,CREATED_DT",
            "FROM",
            "MIG_STG_WIRE_OUTGOING",
            "WHERE",
            "OLB_CLIENT_ID = #{benfClientId} AND NEXT_STATE=5 AND CANCEL_DATE IS NULL AND TEMPLATE_ID IS NULL"
    })
    List<StgToTargetBeneEntity> findByOlbClientIdFutureFreeForm(String benfClientId);

    @Select(value = {
            "SELECT",
            "SUBSCRIBER_ID,PAYEE_RELTNSHP_NUM,BENEFICIARY_NICKNAME,BENEFICIARY_ACCOUNT,BENEFICIARY_NAME,BENEFICIARY_ADDRESS_1,BENEFICIARY_ADDRESS_2,BENEFICIARY_ADDRESS_3,",
            "PAYEE_CITY,PAYEE_ZIP_CODE,PAYEE_PHONE_NUM,MERCHANT_CATEGORY,ELECTRONIC_INDICATOR,BENEFICIARY_BANK_IDENTIFIER,EC_CLIENT_ID,JOB_ID,IPAYEE_BENE_ID",
            "FROM",
            "MIG_STG_IPAY_PAYEES",
            "WHERE",
            "EC_CLIENT_ID = #{payeeClientId} AND ELECTRONIC_INDICATOR = #{electronicIndicator} AND ( NVL2( BENEFICIARY_BANK_IDENTIFIER, 1, 0 ) = #{hasBankId} )"
    })
    List<StgToTargetBeneEntity> findByOlbClientIdIpayPayees(SelectConditions selectConditions);
}





