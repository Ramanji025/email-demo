package com.svb.gateway.migration.beneficiaries.mapper;

import com.svb.gateway.migration.beneficiaries.entity.MigBeneficiary;
import com.svb.gateway.migration.beneficiaries.entity.MigratedBeneficiaryEntity;
import com.svb.gateway.migration.common.constants.MigrationConstants;
import org.apache.ibatis.annotations.*;
import org.springframework.stereotype.Repository;

import java.util.List;

@Mapper
@Repository
public interface MigBeneficiaryMapper {

    @Select(value = {
            "SELECT",
            "CLIENTMIGID,JOBID,ECCLIENTID,GWCLIENTID,BENEFICIARYID,GROUPID,BENESOURCETYPE,BENESOURCEID,RETRIED,COMMENTS,STATUS,CREATEDBY,CREATEDDATE,UPDATEDBY,UPDATEDDATE",
            "FROM",
            "MIG_BENEFICIARY",
            "WHERE",
            "JOBID = #{jobId}"
    })
    List<MigratedBeneficiaryEntity> findByJobId(Long jobId);

    @Select(value = {
            "SELECT",
            "CLIENTMIGID,JOBID,ECCLIENTID,GWCLIENTID,BENEFICIARYID,GROUPID,BENESOURCETYPE,BENESOURCEID,RETRIED,COMMENTS,STATUS,CREATEDBY,CREATEDDATE,UPDATEDBY,UPDATEDDATE",
            "FROM",
            "MIG_BENEFICIARY",
            "WHERE",
            " JOBID = #{jobId} AND BENESOURCEID = #{beneSourceId} "
    })
    List<MigratedBeneficiaryEntity> findByJobIdAndBeneId(@Param("jobId")Long jobId, @Param("beneSourceId")String beneSourceId);

    @Insert(value = {
            "INSERT INTO",
            "MIG_BENEFICIARY",
            "(JOBID,ECCLIENTID,GWCLIENTID,BENEFICIARYID,GROUPID,BENESOURCETYPE,BENESOURCEID,COMMENTS,STATUS,PENDING_BENEFICIARY_ID)",
            "VALUES",
            "(#{jobId}, #{ecClientId}, #{gwClientId}, #{beneficiaryId}, #{groupId}, #{beneSourceType}, #{beneSourceId}, #{comments}, #{status}, #{pendingRecipientId,jdbcType=NUMERIC})"
    })
    @Options(useGeneratedKeys = true, keyProperty = "clientMigId", keyColumn = "CLIENTMIGID")
    Integer insertMigratedBene(MigBeneficiary migBeneficiary);

    @Update(value = "update MIG_BENEFICIARY set ECCLIENTID=#{ecClientId}, GWCLIENTID=#{gwClientId}, BENEFICIARYID=#{beneficiaryId}, GROUPID=#{groupId}, comments=#{comments}, BENESOURCETYPE=#{beneSourceType}, PENDING_BENEFICIARY_ID=#{pendingRecipientId,jdbcType=NUMERIC}, status=#{status}, UPDATEDBY=#{updatedBy}, UPDATEDDATE=#{updatedDt} where BENESOURCEID=#{beneSourceId} AND JOBID=#{jobId}")
    void updateBeneficiary(MigBeneficiary entity);

    @Update(value = "update MIG_BENEFICIARY set status='"+ MigrationConstants.STATUS_ROLLED_BACK+"', UPDATEDBY='SVB.svc.migration', UPDATEDDATE=systimestamp where ECCLIENTID=#{ecClientId} ")
    void rollbackByEcClientId(@Param("ecClientId") String ecClientId);
}
