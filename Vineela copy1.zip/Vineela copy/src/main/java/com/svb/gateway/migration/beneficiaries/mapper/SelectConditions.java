package com.svb.gateway.migration.beneficiaries.mapper;

public class SelectConditions {
    String payeeClientId;
    String electronicIndicator;
    int hasBankId;

    public SelectConditions(String payeeClientId, String electronicIndicator, boolean hasBankId) {
        this.payeeClientId = payeeClientId;
        this.electronicIndicator = electronicIndicator;
        this.hasBankId = hasBankId?1:0;
    }

    public String getPayeeClientId() {
        return payeeClientId;
    }

    public void setPayeeClientId(String payeeClientId) {
        this.payeeClientId = payeeClientId;
    }

    public String getElectronicIndicator() {
        return electronicIndicator;
    }

    public void setElectronicIndicator(String electronicIndicator) {
        this.electronicIndicator = electronicIndicator;
    }

    public int getHasBankId() {
        return hasBankId;
    }

    public void setHasBankId(boolean hasBankId) {
        this.hasBankId = hasBankId?1:0;
    }
}
