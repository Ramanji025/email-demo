package com.svb.gateway.migration.beneficiaries.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "accountId",
        "isInternationalBankAccountNumber",
        "isPersonalAccount",
        "accountCurrency"
})
public class AccountDetails {

    @JsonProperty("accountId")
    private String accountId;

    @JsonProperty("isInternationalBankAccountNumber")
    private String isInternationalBankAccountNumber;

    @JsonProperty("isPersonalAccount")
    private String isPersonalAccount;

    @JsonProperty("accountCurrency")
    private String accountCurrency;

    @Override
    public String toString() {
        return "AccountDetails{" +
                "accountId='" + accountId + '\'' +
                ", isInternationalBankAccountNumber='" + isInternationalBankAccountNumber + '\'' +
                ", isPersonalAccount='" + isPersonalAccount + '\'' +
                ", accountCurrency='" + accountCurrency + '\'' +
                '}';
    }
}
