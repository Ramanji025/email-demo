package com.svb.gateway.migration.beneficiaries.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import lombok.Getter;
import lombok.Setter;

import java.util.List;
import java.util.Objects;

@Getter
@Setter
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "counterpartyName",
        "counterpartyNickname",
        "beneficiaryAddress",
        "contactDetails",
        "paymentDetails"
})
public class AddBeneficiaryRequest {

    @JsonProperty("counterpartyName")
    private String counterpartyName;

    @JsonProperty("counterpartyNickname")
    private String counterpartyNickname=null;

    @JsonProperty("addressDetails")
    private BeneficiaryAddress beneficiaryAddress=null;

    @JsonProperty("contactDetails")
    private ContactDetails contactDetails=null;

    @JsonProperty("paymentDetails")
    private List<PaymentDetail> paymentDetails;

    @JsonProperty("corporateId")
    private String corporateId=null;


    @Override
    public String toString() {
        return "AddBeneficiaryRequest{" +
                "counterpartyName='" + counterpartyName + '\'' +
                ", counterpartyNickname='" + counterpartyNickname + '\'' +
                ", beneficiaryAddress=" + beneficiaryAddress +
                ", contactDetails=" + contactDetails +
                ", paymentDetails=" + paymentDetails +
                '}';
    }

    @Override
    public int hashCode() {
        return Objects.hash(counterpartyName, counterpartyNickname, beneficiaryAddress, contactDetails, paymentDetails);
    }
}
