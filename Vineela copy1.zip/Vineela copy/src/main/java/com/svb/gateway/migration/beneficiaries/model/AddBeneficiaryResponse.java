package com.svb.gateway.migration.beneficiaries.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;

import java.util.HashMap;
import java.util.Map;

@Getter
@Setter
@JsonInclude(JsonInclude.Include.NON_NULL)
public class AddBeneficiaryResponse {

    @JsonProperty("data")
    private AddBeneficiaryResponseData data = null;

    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<>();

    @Override
    public String toString() {
        return "AddBeneficiaryResponse{" +
                "data=" + data +
                ", additionalProperties=" + additionalProperties +
                '}';
    }
}
