package com.svb.gateway.migration.beneficiaries.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "address",
        "bankIdentifier",
        "bankName",
        "bankRefNum",
        "branchName",
        "city",
        "counterpartyBank",
        "country",
        "isExistingBank",
        "localRoutingCode",
        "networkType",
        "zipCode"
})
public class BankDetails {

    @JsonProperty("address")
    private String address;

    @JsonProperty("bankIdentifier")
    private String bankIdentifier;

    @JsonProperty("bankName")
    private String bankName;

    @JsonProperty("bankRefNum")
    private String bankRefNum;

    @JsonProperty("branchName")
    private String branchName;

    @JsonProperty("city")
    private String city;

    @JsonProperty("counterpartyBank")
    private String counterpartyBank;

    @JsonProperty("country")
    private String country;

    @JsonProperty("isExistingBank")
    private String isExistingBank;

    @JsonProperty("localRoutingCode")
    private String localRoutingCode;

    @JsonProperty("networkType")
    private String networkType;

    @JsonProperty("zipCode")
    private String zipCode;

}
