package com.svb.gateway.migration.beneficiaries.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ClearingSystemDetail {

    @JsonProperty("routingType")
    private String routingType;

    @JsonProperty("routingCodeAlt")
    private String routingCodeAlt;

    @JsonProperty("overrideRoutingCode")
    private String overrideRoutingCode;

    @JsonProperty("overrideRoutingCodeAlt")
    private String overrideRoutingCodeAlt;

    @JsonProperty("clearingSystem")
    private String clearingSystem;

    @JsonProperty("routingTypeExt")
    private String routingTypeExt;

    @JsonProperty("routingCodeStatus")
    private String routingCodeStatus;

    @JsonProperty("achFlag")
    private String achFlag;

    @JsonProperty("fedwireFundStatus")
    private String fedwireFundStatus;

    @JsonProperty("fedwireSecurityStatus")
    private String fedwireSecurityStatus;

}
