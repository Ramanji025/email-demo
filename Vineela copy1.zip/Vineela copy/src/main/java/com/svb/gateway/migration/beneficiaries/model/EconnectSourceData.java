package com.svb.gateway.migration.beneficiaries.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "sourceType",
        "sourceId",
        "clientId",
        "templateName",
        "paymentType",
        "entryopName",
        "entryDate",
        "approveLvl1Date",
        "currentState",
        "approveLvl1OpName",
        "nextState",
        "approveLvl2OpName",
        "cancelopName",
        "currencyCode",
        "forexAmount",
        "beneficiaryBankIdentifier",
        "approveLvl2Date",
        "beneficiaryAccount",
        "cancelDate",
        "beneficiaryName",
        "beneficiaryAddress1",
        "beneficiaryAddress2",
        "beneficiaryAddress3",
        "beneficiaryInstructions",
        "furtherApprovals",
        "totalApprovals",
        "beneficiaryBankName",
        "beneficiaryBankAddress",
        "beneficiaryBankCity",
        "beneficiaryBankCityZip",
        "beneficiaryBankState",
        "beneficiaryBankCountry",
        "entryopId",
        "approveLvl1OpId",
        "approveLvl2OpId",
        "cancelopId",
        "bankToBankInstructions",
        "beneficiaryBankSearchMode",
        "isTemplateImported",
        "fromAccountNumber",
        "enteredAmtInDebitCurrency",
        "debitingAmount",
        "debitingCurrencyCode",
        "isDeleted",
        "deleteopName",
        "deleteDate",
        "deleteopId",
        "templateCode",
        "importFileInfoId",
        "chargeCodeId",
        "beneficiaryBankRegion",
        "intermediaryId",
        "intermediaryName",
        "intermediaryAddress",
        "isBeneficiaryAccSvb",
        "isBeneficiaryAccSvbDda",
        "paymentUrgency",
        "routingCode"
})
public class EconnectSourceData {

    @JsonProperty("sourceType")
    private String sourceType;
    @JsonProperty("sourceId")
    private Integer sourceId;
    @JsonProperty("clientId")
    private String clientId;
    @JsonProperty("templateName")
    private String templateName;
    @JsonProperty("paymentType")
    private String paymentType;
    @JsonProperty("entryopName")
    private String entryopName;
    @JsonProperty("entryDate")
    private String entryDate;
    @JsonProperty("approveLvl1Date")
    private String approveLvl1Date;
    @JsonProperty("currentState")
    private String currentState;
    @JsonProperty("approveLvl1OpName")
    private String approveLvl1OpName;
    @JsonProperty("nextState")
    private String nextState;
    @JsonProperty("approveLvl2OpName")
    private String approveLvl2OpName;
    @JsonProperty("cancelopName")
    private String cancelopName;
    @JsonProperty("currencyCode")
    private String currencyCode;
    @JsonProperty("forexAmount")
    private String forexAmount;
    @JsonProperty("beneficiaryBankIdentifier")
    private String beneficiaryBankIdentifier;
    @JsonProperty("approveLvl2Date")
    private String approveLvl2Date;
    @JsonProperty("beneficiaryAccount")
    private String beneficiaryAccount;
    @JsonProperty("cancelDate")
    private String cancelDate;
    @JsonProperty("beneficiaryName")
    private String beneficiaryName;
    @JsonProperty("beneficiaryAddress2")
    private String beneficiaryAddress2;
    @JsonProperty("beneficiaryAddress1")
    private String beneficiaryAddress1;
    @JsonProperty("beneficiaryAddress3")
    private String beneficiaryAddress3;
    @JsonProperty("beneficiaryInstructions")
    private String beneficiaryInstructions;
    @JsonProperty("furtherApprovals")
    private String furtherApprovals;
    @JsonProperty("totalApprovals")
    private String totalApprovals;
    @JsonProperty("beneficiaryBankName")
    private String beneficiaryBankName;
    @JsonProperty("beneficiaryBankAddress")
    private String beneficiaryBankAddress;
    @JsonProperty("beneficiaryBankCity")
    private String beneficiaryBankCity;
    @JsonProperty("beneficiaryBankCityZip")
    private String beneficiaryBankCityZip;
    @JsonProperty("beneficiaryBankState")
    private String beneficiaryBankState;
    @JsonProperty("beneficiaryBankCountry")
    private String beneficiaryBankCountry;
    @JsonProperty("entryopId")
    private String entryopId;
    @JsonProperty("approveLvl1OpId")
    private String approveLvl1OpId;
    @JsonProperty("approveLvl2OpId")
    private String approveLvl2OpId;
    @JsonProperty("cancelopId")
    private String cancelopId;
    @JsonProperty("bankToBankInstructions")
    private String bankToBankInstructions;
    @JsonProperty("beneficiaryBankSearchMode")
    private String beneficiaryBankSearchMode;
    @JsonProperty("isTemplateImported")
    private String isTemplateImported;
    @JsonProperty("fromAccountNumber")
    private String fromAccountNumber;
    @JsonProperty("enteredAmtInDebitCurrency")
    private String enteredAmtInDebitCurrency;
    @JsonProperty("debitingAmount")
    private String debitingAmount;
    @JsonProperty("debitingCurrencyCode")
    private String debitingCurrencyCode;
    @JsonProperty("isDeleted")
    private String isDeleted;
    @JsonProperty("deleteopName")
    private String deleteopName;
    @JsonProperty("deleteDate")
    private String deleteDate;
    @JsonProperty("deleteopId")
    private String deleteopId;
    @JsonProperty("templateCode")
    private String templateCode;
    @JsonProperty("importFileInfoId")
    private String importFileInfoId;
    @JsonProperty("chargeCodeId")
    private String chargeCodeId;
    @JsonProperty("beneficiaryBankRegion")
    private String beneficiaryBankRegion;
    @JsonProperty("intermediaryId")
    private String intermediaryId;
    @JsonProperty("intermediaryName")
    private String intermediaryName;
    @JsonProperty("intermediaryAddress")
    private String intermediaryAddress;
    @JsonProperty("isBeneficiaryAccSvb")
    private String isBeneficiaryAccSvb;
    @JsonProperty("isBeneficiaryAccSvbDda")
    private String isBeneficiaryAccSvbDda;
    @JsonProperty("paymentUrgency")
    private String paymentUrgency;
    @JsonProperty("routingCode")
    private String routingCode;

}
