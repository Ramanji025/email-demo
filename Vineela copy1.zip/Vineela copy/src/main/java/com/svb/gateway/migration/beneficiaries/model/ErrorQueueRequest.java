package com.svb.gateway.migration.beneficiaries.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "econnectSourceData",
        "gatewayTargetData",
        "exceptionData",
        "metaData",
})
public class ErrorQueueRequest {
    @JsonProperty("econnectSourceData")
    private EconnectSourceData econnectSourceData=null;

    @JsonProperty("gatewayTargetData")
    private AddBeneficiaryRequest gatewayTargetData=null;

    @JsonProperty("exceptionData")
    private List<ValidationError> exceptionData;

    @JsonProperty("metaData")
    private MetaData metaData=null;
}
