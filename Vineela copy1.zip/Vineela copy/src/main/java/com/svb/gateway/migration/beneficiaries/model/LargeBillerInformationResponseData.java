package com.svb.gateway.migration.beneficiaries.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class LargeBillerInformationResponseData {

    @JsonProperty("addressId")
    private String addressId;

    @JsonProperty("largeBillerId")
    private String largeBillerId;

    @JsonProperty("address1")
    private String address1;

    @JsonProperty("addressCity")
    private String addressCity;

    @JsonProperty("addressState")
    private String addressState;

    @JsonProperty("addressCountry")
    private String addressCountry;

    @JsonProperty("addressZip")
    private String addressZip;

}
