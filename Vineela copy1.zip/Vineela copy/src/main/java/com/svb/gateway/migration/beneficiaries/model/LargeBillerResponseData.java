package com.svb.gateway.migration.beneficiaries.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class LargeBillerResponseData {

    @JsonProperty("displayName")
    private String displayName;

    @JsonProperty("networkId")
    private String networkId;

    @JsonProperty("type")
    private String type;

}
