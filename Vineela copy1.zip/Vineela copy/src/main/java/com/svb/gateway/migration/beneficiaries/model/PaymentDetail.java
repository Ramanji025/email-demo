package com.svb.gateway.migration.beneficiaries.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "requestType",
        "billerInformation",
        "customerAccountNumber",
        "bankDetails",
        "accountDetails",
        "paymentMethod",
        "preferredFlag",
        "isLargeBiller"
})
public class PaymentDetail {

    @JsonProperty("requestType")
    private String requestType;

    @JsonProperty("customerAccountNumber")
    private String customerAccountNumber;

    @JsonProperty("bankDetails")
    private BankDetails bankDetails;

    @JsonProperty("accountDetails")
    private AccountDetails accountDetails;

    @JsonProperty("paymentMethod")
    private String paymentMethod;

    @JsonProperty("preferredFlag")
    private String preferredFlag;

    @JsonProperty("isLargeBiller")
    private String isLargeBiller;

    @JsonProperty("billerInformation")
    private BillerInformation billerInformation;

    public BillerInformation getBillerInformation() {
        return billerInformation;
    }

    public void setBillerInformation(BillerInformation billerInformation) {
        this.billerInformation = billerInformation;
    }

    @Override
    public String toString() {
        return "PaymentDetail{" +
                "requestType='" + requestType + '\'' +
                ", customerAccountNumber='" + customerAccountNumber + '\'' +
                ", bankDetails=" + bankDetails +
                ", accountDetails=" + accountDetails +
                ", paymentMethod='" + paymentMethod + '\'' +
                ", preferredFlag='" + preferredFlag + '\'' +
                ", isLargeBiller='" + isLargeBiller + '\'' +
                '}';
    }
}
