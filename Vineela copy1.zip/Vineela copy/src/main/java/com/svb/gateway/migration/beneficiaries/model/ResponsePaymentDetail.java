package com.svb.gateway.migration.beneficiaries.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ResponsePaymentDetail {

    @JsonProperty("counterpartyId")
    private String counterpartyId="";

    @JsonProperty("payeeListId")
    private String payeeListId="";

    @JsonProperty("bankDetails")
    private ResponseBankDetails bankDetails=null;

    @JsonProperty("accountDetails")
    private AccountDetails accountDetails=null;

    @JsonProperty("paymentMethod")
    private String paymentMethod;

    @JsonProperty("preferredFlag")
    private String preferredFlag;

    @Override
    public String toString() {
        return "ResponsePaymentDetail{" +
                "counterpartyId='" + counterpartyId + '\'' +
                ", payeeListId='" + payeeListId + '\'' +
                ", bankDetails=" + bankDetails +
                ", accountDetails=" + accountDetails +
                ", paymentMethod='" + paymentMethod + '\'' +
                ", preferredFlag='" + preferredFlag + '\'' +
                '}';
    }
}
