package com.svb.gateway.migration.beneficiaries.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import lombok.Getter;
import lombok.Setter;


@Getter
@Setter
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "templateId",
        "wireTxnId",
        "status",
        "beneId",
        "comments"
})
public class ResultRecords {

    @JsonProperty("templateId")
    private Integer templateId;

    @JsonProperty("wireTxnId")
    private Integer wireTxnId;

    @JsonProperty("iPayBeneId")
    private Integer iPayBeneId;

    @JsonProperty("status")
    private String status;

    @JsonProperty("beneId")
    private String beneId;

    @JsonProperty("comments")
    private String comments;
}
