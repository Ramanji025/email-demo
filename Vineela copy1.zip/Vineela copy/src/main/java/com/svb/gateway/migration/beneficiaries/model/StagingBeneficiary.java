package com.svb.gateway.migration.beneficiaries.model;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class StagingBeneficiary {

    private Integer WIRE_TRANSACTION_ID;
    private Integer TEMPLATE_ID;
    private String OLB_CLIENT_ID;
    private String PAYMENT_TYPE;
    private String CURRENCY_CODE;
    private String CURRENT_STATE;
    private String BENEFICIARY_BANK_IDENTIFIER;
    private String BENEFICIARY_BANK_CITY;
    private String BENEFICIARY_NAME;
    private String BENEFICIARY_ACCOUNT;
    private String BENEFICIARY_ADDRESS_1;
    private String BENEFICIARY_ADDRESS_2;
    private String JOB_ID;
    private String CREATED_BY;
    private String CREATED_DT;
}
