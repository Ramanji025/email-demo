package com.svb.gateway.migration.beneficiaries.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class State {

    @JsonProperty("countryCode")
    private String countryCode;

    @JsonProperty("stateCode")
    private String stateCode;

    @JsonProperty("stateDescription")
    private String stateDescription;

    @Override
    public String toString() {
        return "State{" +
                "countryCode='" + countryCode + '\'' +
                ", stateCode='" + stateCode + '\'' +
                ", stateDescription='" + stateDescription + '\'' +
                '}';
    }
}
