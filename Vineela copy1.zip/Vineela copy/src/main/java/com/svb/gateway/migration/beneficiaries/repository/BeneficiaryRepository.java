package com.svb.gateway.migration.beneficiaries.repository;

import com.svb.gateway.migration.beneficiaries.entity.StgBeneficiary;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface BeneficiaryRepository extends JpaRepository<StgBeneficiary, String> {

    @Query(value = "select * from MIG_STG_WIRE_TEMPLATE  where OLB_CLIENT_ID = ?1 and CURRENT_STATE=5 and IS_DELETED!=1",nativeQuery=true)
    List<StgBeneficiary> findByOlbClientIdTemplates(String benfClientId);

    List<StgBeneficiary> findByOlbClientId(String benfClientId);

    StgBeneficiary findByOlbClientIdAndTemplateIdAndJobId(String ecClientId, Integer templateId, String jobId);

    }
