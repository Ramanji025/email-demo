package com.svb.gateway.migration.beneficiaries.repository;

import com.svb.gateway.migration.beneficiaries.entity.MigBeneBankReach;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;


@Repository
public interface MigBeneBankNetworkReachRepository extends JpaRepository<MigBeneBankReach, String> {

    @Query(value = "SELECT * FROM OCHADM.BANK_ROUTING_ATTRIB_TABLE  WHERE ROUTING_CODE = ?1 AND DEL_FLG='N' AND ROUTING_CODE_STATUS='A' AND upper(CLEARING_SYSTEM) = 'FEDWIRE' FETCH FIRST 1 ROWS ONLY",nativeQuery=true)
    MigBeneBankReach findByBankIdentifier(String bankIdentifier);
}