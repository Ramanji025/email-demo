package com.svb.gateway.migration.beneficiaries.repository;

import com.svb.gateway.migration.beneficiaries.entity.MigBeneficiary;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface MigBeneficiaryRepository extends JpaRepository<MigBeneficiary, String> {


    @Query(value = "select * from MIG_BENEFICIARY  where JOBID = ?1 AND BENESOURCEID = ?2 and BENESOURCETYPE = 'eConnectTemplate' and ( lower(STATUS)='success' or lower(STATUS)='ignore' ) order by createddate desc", nativeQuery = true)
    List<MigBeneficiary> findByTemplateIdMigratedOrIgnored(Long jobId, Integer templateId);

    /**
     * Only beneficiaries with beneficiaryid are useful for payment processing of wire transfers
     */
    @Query(value = "select * from MIG_BENEFICIARY  where JOBID = ?1 AND BENESOURCEID = ?2 and ECCLIENTID=?3 and BENEFICIARYID is not null order by createddate desc", nativeQuery = true)
    MigBeneficiary findByTemplateIdandAndEcClientId(Long jobId, Integer templateId, String olbClientId);

    @Query(value = "select * from MIG_BENEFICIARY  where JOBID = ?1 AND ECCLIENTID=?2", nativeQuery = true)
    List<MigBeneficiary> findByEcClientId(Long jobId, String olbClientId);

    @Query(value = "select * from MIG_BENEFICIARY  where JOBID = ?1 AND BENESOURCEID = ?2 and BENESOURCETYPE = 'eConnectWire' and ( lower(STATUS)='success' or lower(STATUS)='ignore' ) order by createddate desc", nativeQuery = true)
    List<MigBeneficiary> findByWireTxnIdMigratedOrIgnored(Long jobId, Integer wireTxnId);

    @Query(value = "select * from MIG_BENEFICIARY  where JOBID = ?1 AND ECCLIENTID=?2 and STATUS in ?3 order by createddate desc", nativeQuery = true)
    List<MigBeneficiary> findByEcClientIdAndJobIdAndStatus(Long jobId, String olbClientId, List<String> status);

    @Query(value = "select * from MIG_BENEFICIARY  where JOBID = ?1 AND ECCLIENTID=?2 and STATUS in ?3 and BENESOURCETYPE=?4 order by createddate desc", nativeQuery = true)
    List<MigBeneficiary> findByEcClientIdAndJobIdAndStatusAndBeneSourceType(Long jobId, String olbClientId, List<String> status, String beneSourceType);

    /**
     * Only succesful beneficiaries are useful for iPay processing
     */
    @Query(value = "select * from MIG_BENEFICIARY  where JOBID = ?1 AND BENESOURCEID = ?2 and BENESOURCETYPE like '%IPAY%' and lower(STATUS)='success' order by createddate desc", nativeQuery = true)
    MigBeneficiary findByBeneSourceForIpayMigrated(Long jobId, Integer beneSourceId);

    @Query(value = "select * from MIG_BENEFICIARY  where JOBID = ?1 AND BENESOURCEID = ?2 and BENESOURCETYPE like '%IPAY%' and  ( lower(STATUS)='success' or lower(STATUS)='ignore' ) order by createddate desc", nativeQuery = true)
    List<MigBeneficiary> findByIpayBeneIDMigratedOrIgnored(Long jobId, Integer beneSourceId);
}
