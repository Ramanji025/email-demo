package com.svb.gateway.migration.beneficiaries.service;

import static com.svb.gateway.migration.beneficiaries.entity.StgToTargetBeneEntity.PAYEE_TYPE.ACH_LARGE;
import static com.svb.gateway.migration.beneficiaries.model.ValidationError.ERR1002;
import static com.svb.gateway.migration.beneficiaries.model.ValidationError.FIELD_LENGTH_EXCEEDED;
import static com.svb.gateway.migration.common.constants.MigrationConstants.*;
import static com.svb.gateway.migration.common.utility.LengthValidationEnum.*;
import static com.svb.gateway.migration.common.utility.LengthValidationEnum.BENE_ACCOUNT_NUMBER_US;

import com.svb.gateway.migration.beneficiaries.entity.MigBeneficiary;
import com.svb.gateway.migration.beneficiaries.entity.StgToTargetBeneEntity;
import com.svb.gateway.migration.beneficiaries.mapper.MigBeneficiaryMapper;
import com.svb.gateway.migration.beneficiaries.mapper.SelectConditions;
import com.svb.gateway.migration.beneficiaries.model.*;
import com.svb.gateway.migration.beneficiaries.repository.BeneficiaryRepository;
import com.svb.gateway.migration.beneficiaries.repository.MigBeneficiaryRepository;
import com.svb.gateway.migration.client.entity.MigClient;
import com.svb.gateway.migration.common.exception.ServiceException;
import com.svb.gateway.migration.common.exception.SkipAheadServiceException;
import com.svb.gateway.migration.common.logging.Message;
import com.svb.gateway.migration.common.model.AddressResponse;
import com.svb.gateway.migration.common.utility.AddressDoctor;
import com.svb.gateway.migration.common.utility.CacheManagerUtility;
import com.svb.gateway.migration.common.service.RetryService;
import org.springframework.core.ParameterizedTypeReference;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
@Log4j2
@Service
public class ACHLargePayeeManager extends BeneficiaryBaseManager {
    private static final String IS_LARGEBILLER_Y = "Y";
    private static final String OLB_CLIENT_ID = "olbClientId";
    private static final String ADDRESS_ZIP = "addressZip";
    private static final String SEARCH_STRING = "searchString";
    private static final String ADDRESSES = "addresses";

    @Value(value = "Fetch Biller Info API CorrelationId")
    String migLargeBillerCorrelationId;

    @Value("${header.service.token}")
    String token;

    @Value("${mig.largebillerNetworkFetch.url}")
    String fetchBillerNetworkUrl;

    public ACHLargePayeeManager(MigBeneficiaryMapper migBeneficiaryMapper, MigBeneficiaryRepository migBeneficiaryRepository, BeneficiaryRepository beneficiaryRepository, CacheManagerUtility cacheManagerUtility, BeneficiaryValidationUtility beneficiaryValidationUtility, AddressDoctor addressDoctor, RetryService retryService) {
        super(migBeneficiaryMapper, migBeneficiaryRepository, beneficiaryRepository, cacheManagerUtility, beneficiaryValidationUtility, addressDoctor, retryService);
    }

    @Override
    protected StgToTargetBeneEntity.PAYEE_TYPE payeeType(){return ACH_LARGE;}

    @Override
    public String getNickName(StgToTargetBeneEntity entity) {
        return entity.getBENEFICIARY_NICKNAME();
    }

    @Override
    public boolean hasPayeePhoneNumber() { return true; }

    @Autowired
    public void setRetryService( RetryService retryService){
        super.retryService = retryService;
    }

    public RetryService getRetryService(){
        return super.retryService;
    }

    @Override
    protected void validateAddressResponseAndSetAddressInRequest(BeneficiaryAddress beneficiaryAddress, AddressResponse addressResponse, EntityWrapper entityWrapper) {
        if (addressResponse==null || !(VALIDATED_ADDRESS_RESPONSE.equalsIgnoreCase(addressResponse.getValidationscore())||CORRECTED_ADDRESS_RESPONSE.equalsIgnoreCase(addressResponse.getValidationscore()))) {
            // No validation required for ACH Large
            beneficiaryAddress.setAddressLine1("");
            beneficiaryAddress.setAddressLine2("");
            beneficiaryAddress.setCity("");
            beneficiaryAddress.setZipCode("");
            beneficiaryAddress.setState("");
        }
        else{
            beneficiaryAddress.setAddressLine1(addressResponse.getCleansedaddrln1());
            beneficiaryAddress.setAddressLine2(addressResponse.getCleansedaddrln2()+SPACE+addressResponse.getCleansedaddrln3());
            beneficiaryAddress.setCity(addressResponse.getCleansedcitynm());
            if (addressResponse.getCleansedzipcd() != null){
                beneficiaryAddress.setZipCode(addressResponse.getCleansedzipcd().substring(0,5));
            }else{
                beneficiaryAddress.setZipCode("");
            }
            beneficiaryAddress.setState(addressResponse.getCleansedstatecd());
            beneficiaryAddress.setCountry(DEFAULT_COUNTRY_CODE);
        }
    }

    /**
     * This method intentionally returns null because we do not validate the bank branch for ACH Large.
     * @param entityWrapper
     * @return
     */
    @Override
    public BankBranchResponse validateBankBranch(EntityWrapper entityWrapper, AccountDetails a, MigClient m) {
        // do not validate for ACH Large
        return null;
    }

    /**
     * This method intentionally does not do anything because we do not set bank details for ACH Large.
     * @param entityWrapper
     * @param bankBranchResponse
     */
    @Override
    BankDetails setBankDetails(EntityWrapper entityWrapper, BankBranchResponse bankBranchResponse){return null;}


    @Override
    public List<PaymentDetail> getPaymentDetails(EntityWrapper entityWrapper, MigClient migClient, AccountDetails accountDetails, BankDetails bankDetails)
    {

        LargeBillerInformationResponse largeBillerInformationResponse;
        PaymentDetail paymentDetail=new PaymentDetail();
        paymentDetail.setRequestType(REQUEST_TYPE);
        paymentDetail.setPreferredFlag(PREFERRED_FLAG);
        accountDetails.setAccountId(entityWrapper.getEntity().getBENEFICIARY_ACCOUNT());
        largeBillerInformationResponse = fetchLargeBillerInfo(entityWrapper, migClient);
        BillerInformation billerInformation = new BillerInformation();
        if(largeBillerInformationResponse!=null && largeBillerInformationResponse.getData()!=null
                && largeBillerInformationResponse.getData().get(0)!=null) {
            billerInformation.setBilleraddressId(largeBillerInformationResponse.getData().get(0).getAddressId());
            billerInformation.setLargeBillerId(largeBillerInformationResponse.getData().get(0).getLargeBillerId());
            billerInformation.setBillerType(largeBillerInformationResponse.getBillerType());
        }
        paymentDetail.setPaymentMethod(PAYMENT_METHOD_ACH);
        paymentDetail.setAccountDetails(accountDetails);
        paymentDetail.setCustomerAccountNumber(entityWrapper.getEntity().getBENEFICIARY_ACCOUNT());
        paymentDetail.setBillerInformation(billerInformation);
        paymentDetail.setIsLargeBiller(IS_LARGEBILLER_Y);
        List<PaymentDetail> paymentDetails = new ArrayList<>();
        paymentDetails.add(paymentDetail);
        return paymentDetails;
    }

    private LargeBillerInformationResponse fetchLargeBillerInfo(EntityWrapper entityWrapper, MigClient migClient) {
        Message message = Message.create().entityName(Message.Entity.beneficiary).clientId(migClient.getEcClientId()).gwClientId(migClient.getGwClientId()).jobId(entityWrapper.getEntity().getJOB_ID()).operation("Fetch large biller info");
        //Fetch Largebiller network id
        log.info(message.summary().descr("Fetch large biller info started"));
        try{
            ResponseEntity<LargeBillerResponse> largeBillerResponseEntity;
            LargeBillerResponse largeBillerResponse = new LargeBillerResponse();

            ResponseEntity<LargeBillerInformationResponse> largeBillerInformationResponseEntity;
            LargeBillerInformationResponse largeBillerInformationResponse = new LargeBillerInformationResponse();

            HttpHeaders billerNetworkheaders = new HttpHeaders();
            billerNetworkheaders.add(CONTENT_TYPE, APPLICATION_HEADER_JSON);

            HttpEntity<?> requestEntity = new HttpEntity<>(billerNetworkheaders);

            String queryPart = "?" + OLB_CLIENT_ID + "="
                    + migClient.getGwClientId()+ "&" + ADDRESS_ZIP + "=" +entityWrapper.getEntity().getPAYEE_ZIP_CODE()
                    + "&" + SEARCH_STRING + "=" +entityWrapper.getEntity().getBENEFICIARY_NAME();
            String finalFetchBillerNetworkInfoUrl = fetchBillerNetworkUrl + queryPart;
            message.url(finalFetchBillerNetworkInfoUrl);
            log.info(message);
            largeBillerResponseEntity = retryService.exchange(finalFetchBillerNetworkInfoUrl, HttpMethod.GET, requestEntity, new ParameterizedTypeReference<LargeBillerResponse>() {});
            LargeBillerResponse largeBillerBody = largeBillerResponseEntity.getBody();
            if(largeBillerBody!=null) {
                List<LargeBillerResponseData> data = largeBillerBody.getData();
                String finalFetchBillerInformationUrl = fetchBillerNetworkUrl + SLASH + data.get(0).getNetworkId()
                        + SLASH + ADDRESSES + queryPart;
                log.info(message.url(finalFetchBillerInformationUrl).descr("largeBillerInformation"));
                if (HttpStatus.OK.equals(largeBillerResponseEntity.getStatusCode())) {
                    largeBillerResponse.setData(data);
                    if (null != largeBillerResponse.getData() && null != largeBillerResponse.getData().get(0).getNetworkId()) {
                        //FetchBillerAddress Information

                        largeBillerInformationResponseEntity = retryService.exchange(finalFetchBillerInformationUrl, HttpMethod.GET, requestEntity, new ParameterizedTypeReference<LargeBillerInformationResponse>() {});
                        if (HttpStatus.OK.equals(largeBillerInformationResponseEntity.getStatusCode())) {
                            List<LargeBillerInformationResponseData> largeBillerInformationResponseDataList = largeBillerInformationResponseEntity.getBody().getData();
                            largeBillerInformationResponse.setData(largeBillerInformationResponseDataList);
                            largeBillerInformationResponse.setBillerType(largeBillerResponse.getData().get(0).getType());
                        } else {
                            log.error(message.summary().descr("Error in fetching large biller info, error code - "+largeBillerInformationResponseEntity.getStatusCode()));
                            entityWrapper.addUnexpectedError("fethcing information for large biller", "error code "+largeBillerInformationResponseEntity.getStatusCode());
                        }
                    }
                } else {
                    log.error(message.summary().descr("Error in fetching large biller, error code - "+largeBillerResponseEntity.getStatusCode()));
                    entityWrapper.addUnexpectedError("fethcing large biller", "error code "+largeBillerResponseEntity.getStatusCode());
                }
            }
            log.info(message.summary().descr("Large biller information fetch completed."));
            return largeBillerInformationResponse;
        }
        catch(Exception e){
            String source = "fetching large biller";
            log.error(message.summary().errorSource(source).descr(e.getMessage()));
            entityWrapper.addUnexpectedError(source, e.getMessage());
        }
        return null;
    }

    @Override
    public void setPaymentMethodAndIsPersonalAccount(PaymentDetail paymentDetail) {
        paymentDetail.setPaymentMethod(PAYMENT_METHOD_ACH);
        paymentDetail.setIsLargeBiller(IS_LARGEBILLER_Y);
    }

    protected void setBeneSourceIdAndTypeForEntityLogging(MigBeneficiary migBeneficiary, StgToTargetBeneEntity stgBeneficiary) {
        migBeneficiary.setBeneSourceId(stgBeneficiary.getIPAYEE_BENE_ID().toString());
        migBeneficiary.setBeneSourceType(BENE_SOURCE_TYPE_IPAY_ACH_LARGE);
    }

    @Override
    public void setBeneSourceIdInResponse(ResultRecords resultRecords, EntityWrapper entityWrapper) {
        resultRecords.setIPayBeneId(entityWrapper.getEntity().getSourceBeneId(ACH_LARGE));
    }

    @Override
    public EntityWrapper fetchListIfAlreadyMigratedBene(EntityWrapper entityWrapper, ProcessingContext processingContext) {
        entityWrapper.migratedRecords = migBeneficiaryRepository.findByIpayBeneIDMigratedOrIgnored( processingContext.getJobId(), entityWrapper.getEntity().getSourceBeneId(ACH_LARGE));
        log.info(Message.create().descr("No of records that are already migrated or ignored in previous runs if any : "+entityWrapper.migratedRecords.size()).jobId(processingContext.getJobId()).clientId(processingContext.migClient.getEcClientId()).gwClientId(processingContext.migClient.getGwClientId()).entityName(Message.Entity.beneficiary));
        return entityWrapper;
    }

    @Override
    public List<StgToTargetBeneEntity> getDataFromStaging(MigClient migClient, StgToTargetBeneEntity.PAYEE_TYPE type) throws ServiceException {
        Message logMessage = Message.create().jobId(migClient.getJobId()).entityName(Message.Entity.beneficiary).clientId(migClient.getEcClientId()).gwClientId(migClient.getGwClientId()).operation("Get the records from staging table based on bene type").payeeType(payeeType());
        List<StgToTargetBeneEntity> stgToTargetBeneEntities = beneficiaryMapper.findByOlbClientIdIpayPayees(new SelectConditions(migClient.getEcClientId(), "Y", false));
        if (stgToTargetBeneEntities == null || stgToTargetBeneEntities.isEmpty()) {
            log.info(logMessage.descr(NO_BENES_PRESENT_FOR_PROVIDED_CLIENT_ID));
            throw new SkipAheadServiceException(NO_BENES_CODE, NO_BENES_PRESENT_FOR_PROVIDED_CLIENT_ID);
        }
        log.info(logMessage.summary().descr("No of records fetched from staging for the given client id is : "+stgToTargetBeneEntities.size()));
        return stgToTargetBeneEntities;
    }

    @Override
    public void lengthCheckValidation(EntityWrapper entityWrapper, MigClient migClient, StgToTargetBeneEntity.PAYEE_TYPE payeeType, AddBeneficiaryRequest addBeneficiaryRequest) {
        Message logMessage = Message.create().jobId(migClient.getJobId()).clientId(migClient.getEcClientId()).gwClientId(migClient.getGwClientId()).operation("lengthCheckValidation").srcId(String.valueOf(entityWrapper.entity.getSourceBeneId(payeeType)));
        log.info(logMessage.descr("Length check started for Bene name, nickname and customer account number"));
        if(addBeneficiaryRequest!=null && (addBeneficiaryRequest.getCounterpartyName().length() > BENE_NAME.getLength())){
            entityWrapper.addValidationError(ERR1002,FIELD_LENGTH_EXCEEDED,BENE_NAME.getField());
        }

        if(addBeneficiaryRequest!=null && (addBeneficiaryRequest.getCounterpartyNickname().length() > BENE_NICKNAME.getLength())){
            entityWrapper.addValidationError(ERR1002,FIELD_LENGTH_EXCEEDED,BENE_NICKNAME.getField());
        }

        if(addBeneficiaryRequest!=null && (addBeneficiaryRequest.getPaymentDetails().get(0).getCustomerAccountNumber().length() > BENE_ACCOUNT_NUMBER_US.getLength())) {
            entityWrapper.addValidationError(ERR1002, FIELD_LENGTH_EXCEEDED, BENE_ACCOUNT_NUMBER_US.getField());
        }

        log.info(logMessage.descr("Length check completed for Bene name, nickname and customer account number"));

    }
}
