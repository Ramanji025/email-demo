package com.svb.gateway.migration.beneficiaries.service;

import com.svb.gateway.migration.beneficiaries.entity.MigBeneficiary;
import com.svb.gateway.migration.beneficiaries.entity.StgToTargetBeneEntity;
import com.svb.gateway.migration.beneficiaries.mapper.MigBeneficiaryMapper;
import com.svb.gateway.migration.beneficiaries.mapper.SelectConditions;
import com.svb.gateway.migration.beneficiaries.model.*;
import com.svb.gateway.migration.beneficiaries.repository.BeneficiaryRepository;
import com.svb.gateway.migration.beneficiaries.repository.MigBeneficiaryRepository;
import com.svb.gateway.migration.client.entity.MigClient;
import com.svb.gateway.migration.common.exception.ServiceException;
import com.svb.gateway.migration.common.exception.SkipAheadServiceException;
import com.svb.gateway.migration.common.logging.Message;
import com.svb.gateway.migration.common.model.AddressResponse;
import com.svb.gateway.migration.common.service.RetryService;
import com.svb.gateway.migration.common.utility.AddressDoctor;
import com.svb.gateway.migration.common.utility.CacheManagerUtility;
import lombok.extern.log4j.Log4j2;
import org.springframework.stereotype.Service;

import java.util.List;

import static com.svb.gateway.migration.beneficiaries.entity.StgToTargetBeneEntity.PAYEE_TYPE.*;
@Log4j2
@Service
public class ACHPayeeManager extends BeneficiaryBaseManager {
    private static final String IS_LARGEBILLER_N = "N";
    private static final String IS_PERSONAL_ACCOUNT_YES= "Y";

    public ACHPayeeManager(MigBeneficiaryMapper migBeneficiaryMapper, MigBeneficiaryRepository migBeneficiaryRepository,
                           BeneficiaryRepository beneficiaryRepository, CacheManagerUtility cacheManagerUtility,
                            BeneficiaryValidationUtility beneficiaryValidationUtility,
                           AddressDoctor addressDoctor, RetryService retryService) {
        super(migBeneficiaryMapper, migBeneficiaryRepository, beneficiaryRepository, cacheManagerUtility,
                beneficiaryValidationUtility, addressDoctor, retryService);
    }


    @Override
    protected void validateAddressResponseAndSetAddressInRequest(BeneficiaryAddress beneficiaryAddress, AddressResponse addressResponse, EntityWrapper entityWrapper) {
        // No validation for ACH
        beneficiaryAddress.setAddressLine1("");
        beneficiaryAddress.setAddressLine2("");
        beneficiaryAddress.setCity("");
        beneficiaryAddress.setZipCode("");
        beneficiaryAddress.setState("");
    }

    @Override
    protected StgToTargetBeneEntity.PAYEE_TYPE payeeType(){return ACH;}

    @Override
    public String getNickName(StgToTargetBeneEntity entity) {
        return entity.getBENEFICIARY_NICKNAME();
    }

    @Override
    public boolean hasPayeePhoneNumber() { return true; }

    @Override
    public void setPaymentMethodAndIsPersonalAccount(PaymentDetail paymentDetail) {
        paymentDetail.setPaymentMethod(PAYMENT_METHOD_ACH);
        paymentDetail.setIsLargeBiller(IS_LARGEBILLER_N);
        paymentDetail.getAccountDetails().setIsPersonalAccount(IS_PERSONAL_ACCOUNT_YES);
    }

    protected void setBeneSourceIdAndTypeForEntityLogging(MigBeneficiary migBeneficiary, StgToTargetBeneEntity stgBeneficiary) {
        migBeneficiary.setBeneSourceId(stgBeneficiary.getIPAYEE_BENE_ID().toString());
        migBeneficiary.setBeneSourceType(BENE_SOURCE_TYPE_IPAY_ACH);
    }

    @Override
    public void setBeneSourceIdInResponse(ResultRecords resultRecords, EntityWrapper entityWrapper) {
        resultRecords.setIPayBeneId(entityWrapper.getEntity().getSourceBeneId(ACH));
    }

    @Override
    public EntityWrapper fetchListIfAlreadyMigratedBene(EntityWrapper entityWrapper, ProcessingContext processingContext) {
        entityWrapper.migratedRecords = migBeneficiaryRepository.findByIpayBeneIDMigratedOrIgnored(processingContext.getJobId(), entityWrapper.getEntity().getSourceBeneId(ACH));
        log.info(Message.create().descr("No of records that are already migrated or ignored in previous runs if any : "+entityWrapper.migratedRecords.size()).jobId(processingContext.getJobId()).clientId(processingContext.migClient.getEcClientId()).gwClientId(processingContext.migClient.getGwClientId()).entityName(Message.Entity.beneficiary));
        return entityWrapper;
    }

    @Override
    String getBankCity(EntityWrapper entityWrapper) {
        return entityWrapper.getEntity().getPAYEE_CITY();
    }

    @Override
    public List<StgToTargetBeneEntity> getDataFromStaging(MigClient migClient, StgToTargetBeneEntity.PAYEE_TYPE type) throws ServiceException {
        Message logMessage = Message.create().jobId(migClient.getJobId()).entityName(Message.Entity.beneficiary).clientId(migClient.getEcClientId()).gwClientId(migClient.getGwClientId()).operation("Get the records from staging table based on bene type").payeeType(payeeType());
        List<StgToTargetBeneEntity> stgToTargetBeneEntities=beneficiaryMapper.findByOlbClientIdIpayPayees(new SelectConditions(migClient.getEcClientId(), "Y", true));
        if (stgToTargetBeneEntities == null || stgToTargetBeneEntities.isEmpty()) {
            log.info(logMessage.descr(NO_BENES_PRESENT_FOR_PROVIDED_CLIENT_ID));
            throw new SkipAheadServiceException(NO_BENES_PRESENT_FOR_PROVIDED_CLIENT_ID, NO_BENES_PRESENT_FOR_PROVIDED_CLIENT_ID);
        }
        log.info(logMessage.summary().descr("No of records fetched from staging for the given client id is : "+stgToTargetBeneEntities.size()));
        return stgToTargetBeneEntities;
    }
}
