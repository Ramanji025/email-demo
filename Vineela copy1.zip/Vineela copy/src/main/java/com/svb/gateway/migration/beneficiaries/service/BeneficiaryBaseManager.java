package com.svb.gateway.migration.beneficiaries.service;

import static com.svb.gateway.migration.beneficiaries.entity.StgToTargetBeneEntity.PAYEE_TYPE.*;
import static com.svb.gateway.migration.beneficiaries.model.ValidationError.*;
import static com.svb.gateway.migration.beneficiaries.service.BeneficiaryValidationUtility.*;
import static com.svb.gateway.migration.common.constants.MigrationConstants.*;
import static com.svb.gateway.migration.common.utility.LengthValidationEnum.*;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.svb.gateway.migration.beneficiaries.entity.MigBeneficiary;
import com.svb.gateway.migration.beneficiaries.entity.MigratedBeneficiaryEntity;
import com.svb.gateway.migration.beneficiaries.entity.StgToTargetBeneEntity;
import com.svb.gateway.migration.beneficiaries.mapper.BeneficiaryMapper;
import com.svb.gateway.migration.beneficiaries.mapper.EntityToModelMapper;
import com.svb.gateway.migration.beneficiaries.mapper.MigBeneficiaryMapper;
import com.svb.gateway.migration.beneficiaries.model.*;
import com.svb.gateway.migration.beneficiaries.repository.BeneficiaryRepository;
import com.svb.gateway.migration.beneficiaries.repository.MigBeneBankRepository;
import com.svb.gateway.migration.beneficiaries.repository.MigBeneficiaryRepository;
import com.svb.gateway.migration.client.entity.MigClient;
import com.svb.gateway.migration.common.constants.MigrationConstants;
import com.svb.gateway.migration.common.exception.ServiceException;
import com.svb.gateway.migration.common.logging.Message;
import com.svb.gateway.migration.common.model.AddressResponse;
import com.svb.gateway.migration.common.service.RetryService;
import com.svb.gateway.migration.common.utility.AddressDoctor;
import com.svb.gateway.migration.common.utility.CacheManagerUtility;
import lombok.extern.log4j.Log4j2;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestClientResponseException;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Log4j2
public abstract class BeneficiaryBaseManager implements IBeneficiaryManager{
    protected static final Logger logger = LoggerFactory.getLogger(BeneficiaryBaseManager.class);
    public static final int FIRST = 0;

    private static final String EXISTING_BANK = "Y";
    private static final String COUNTER_PARTY_BANK = "OBK";
    private static final String LOG_REQUEST_PAYLOAD= "Add Beneficiary request payload: {}";
    private static final String LOG_SUCCESS_VALUE= "Bene created at target with beneId : {} groupId : {}";
    private static final String BENEFICIARY_MIGRATED_TO_GATEWAY = "Beneficiary migrated to gateway";
    private static final String ERRORS_REPORTED_TO_GATEWAY = "Beneficiary data errors reported to gateway";
    private static final String IS_INTERNATIONAL_BANK_ACCOUNT_FLAG_ABA = "N";
    private static final String IS_INTERNATIONAL_BANK_ACCOUNT_FLAG_NON_ABA = "Y";
    private static final String IBAN_VALIDATION_FAILED = "Iban validation failed in target for Bene Account Number : ";
    private static final String CHANNEL_CONTEXT = "ChannelContext";
    private static final String CM_CODE_SUC = "SUC";
    private static final String UNEXPECTED_CODE_PATH = "unexpected code path";

    protected static final String CORRECTED_ADDRESS_RESPONSE="c4";
    protected static final String VALIDATED_ADDRESS_RESPONSE="v4";
    protected static final String NO_BENES_CODE = "No Benes";
    protected static final String NO_BENES_PRESENT_FOR_PROVIDED_CLIENT_ID = "No Benes present for provided client Id";
    protected static final String REQUEST_TYPE = "A";
    protected static final String PREFERRED_FLAG = "Y";
    protected static final String PAYMENT_METHOD_WIRE = "WIRE";
    protected static final String PAYMENT_METHOD_ACH = "ACH";
    protected static final String BENE_SOURCE_TYPE_IPAY_ACH = "IPAY ACH";
    protected static final String BENE_SOURCE_TYPE_IPAY_ACH_LARGE = "IPAY ACH_LARGE";
    protected static final String DEFAULT_COUNTRY_CODE="US";
    protected static final String ADDRESS_DOCTOR_VALIDATION_MESSAGE="Address Validation Score not meeting the V4 or C4 criteria. ";
    protected static final String SPACE=" ";
    protected static final String COMMA=",";

    @Value(value = "AddBeneficiary CorrelationId 123")
    String migCorrelationId;

    @Value("${migration.service.userid}")
    public String migrationUserId;

    @Value(value = "${mig.report.error.url}")
    String reportErrorUrl;

    @Autowired
    MigBeneficiaryRepository migBeneficiaryRepository;

    @Autowired
    BeneficiaryRepository beneficiaryRepository;

    @Autowired
    MigBeneBankRepository migBeneBankRepository;

    @Autowired
    protected AddressDoctor addressDoctor;

    @Autowired
    protected BeneficiaryValidationUtility beneficiaryValidationUtility;

    @Autowired
    protected MigBeneficiaryMapper migBeneficiaryMapper;

    @Autowired
    BeneficiaryMapper beneficiaryMapper;

    @Autowired
    protected RetryService retryService;

    @Autowired
    private final CacheManagerUtility cacheManagerUtility;

    private static final ObjectMapper objectMapper = new ObjectMapper();

    protected BeneficiaryBaseManager(MigBeneficiaryMapper migBeneficiaryMapper, MigBeneficiaryRepository migBeneficiaryRepository, BeneficiaryRepository beneficiaryRepository, CacheManagerUtility cacheManagerUtility, BeneficiaryValidationUtility beneficiaryValidationUtility, AddressDoctor addressDoctor, RetryService retryService) {
        this.migBeneficiaryMapper = migBeneficiaryMapper;
        this.migBeneficiaryRepository = migBeneficiaryRepository;
        this.beneficiaryRepository = beneficiaryRepository;
        this.cacheManagerUtility = cacheManagerUtility;
        this.beneficiaryValidationUtility = beneficiaryValidationUtility;
        this.retryService = retryService;
        this.addressDoctor = addressDoctor;
    }

    protected abstract StgToTargetBeneEntity.PAYEE_TYPE payeeType();

    @Override
    public EntityWrapper prepareRequest(EntityWrapper entityWrapper, ProcessingContext processingContext) {
        Message logMessage=Message.create().jobId(processingContext.getJobId()).clientId(processingContext.migClient.getEcClientId()).gwClientId(processingContext.migClient.getGwClientId()).entityName(Message.Entity.beneficiary).srcId(String.valueOf(entityWrapper.getEntity().getTEMPLATE_ID()));
        if( ! entityWrapper.isAlreadySentToGateway() ) {
            log.info(logMessage.summary().descr("Starting bene validation and creation for a record that has source id : "+entityWrapper.getEntity().getTEMPLATE_ID()));
            StgToTargetBeneEntity entity = entityWrapper.getEntity();
            processingContext.uniqNonMigBene.put(entity.getSourceBeneId(processingContext.payeeType), entity);
            try {
                if(isIpayAccNumOrRoutingNumNull(entityWrapper,processingContext)){
                    entityWrapper.setStatus(STATUS_IGNORE);
                    entityWrapper.addValidationError("","Incorrect data - Payee Account number And Routing Number is either NA or NULL","");
                    return entityWrapper;
                }
                AddBeneficiaryRequest addBeneficiaryRequest = new AddBeneficiaryRequest();
                addBeneficiaryRequest.setCounterpartyName(beneficiaryValidationUtility.removeSwift(entity.getBENEFICIARY_NAME()));
                addBeneficiaryRequest.setCounterpartyNickname(getNickName(entity));

                ContactDetails contactDetails = new ContactDetails();
                contactDetails.setEmailId("");
                contactDetails.setMobileNumber(hasPayeePhoneNumber() ? entity.getPAYEE_PHONE_NUM() : "");
                addBeneficiaryRequest.setContactDetails(contactDetails);

                // HTTP call for Bank Reachability or Iban Verification
                AccountDetails accountDetails = new AccountDetails();

                accountDetails.setAccountId(beneficiaryValidationUtility.removeSpecialChars(entity.getBENEFICIARY_ACCOUNT()));

                // HTTP Call to validate bank branch
                BankBranchResponse bankBranchResponse = validateBankBranch(entityWrapper, accountDetails, processingContext.migClient);

                BankDetails bankDetails = setBankDetails(entityWrapper, bankBranchResponse);

                addBeneficiaryRequest.setBeneficiaryAddress(getAddress(entityWrapper, processingContext.migClient, bankBranchResponse, accountDetails,processingContext.jobId));

                // populating payment details with an inherited method  getPaymentDetails
                List<PaymentDetail> paymentDetails = getPaymentDetails(entityWrapper, processingContext.migClient, accountDetails, bankDetails);
                addBeneficiaryRequest.setPaymentDetails(paymentDetails);

                entityWrapper.setGatewayMigrationRequest(addBeneficiaryRequest);

                lengthCheckValidation(entityWrapper,processingContext.migClient,processingContext.payeeType,addBeneficiaryRequest);

                return entityWrapper;
            } catch (Exception e) {
                handleException(e, entityWrapper, "", "BeneficiaryBaseManager prepareRequest");
                return entityWrapper;
            }
        }
        else{
            return entityWrapper;
        }
    }

    /**
     * Sets bank details. Note, this method is overridden by some payee managers
     * @param entityWrapper for the entity
     * @param bankBranchResponse response containing the data
     */
    BankDetails setBankDetails(EntityWrapper entityWrapper, BankBranchResponse bankBranchResponse) {
        Message message = Message.create().jobId(entityWrapper.getEntity().getJOB_ID()).entityName(Message.Entity.beneficiary).operation("setting bank details").descr("Using the first branch as a default");
        BankDetails bankDetails = new BankDetails();
        bankDetails.setIsExistingBank(EXISTING_BANK);
        bankDetails.setCounterpartyBank(COUNTER_PARTY_BANK);
        bankDetails.setBankIdentifier(entityWrapper.getEntity().getBENEFICIARY_BANK_IDENTIFIER());
        bankDetails.setLocalRoutingCode("");
        if(bankBranchResponse !=null && bankBranchResponse.getData()!=null && !bankBranchResponse.getData().isEmpty()){
            int branchNum = FIRST;
            // If eC BankCity doesn't match with bankbranch response for bankRefNum mapping then default it to FIRST record in the response list.
            BankBranchResponseData data = bankBranchResponse.getData().get(branchNum);
            // search in in the response list for if BankCity match with bank branch city.
            while(branchNum < bankBranchResponse.getData().size()){
                BankBranchResponseData tmpData = bankBranchResponse.getData().get(branchNum);
                if(tmpData.getBranchAddress().getCity().equals(getBankCity(entityWrapper))){
                    data = tmpData;
                    message.descr("Using branch num "+(branchNum+1)+" for city "+data.getBranchAddress().getCity());
                    break;
                }
                branchNum++;
            }
            bankDetails.setBankRefNum(data.getBankRefNo());
            bankDetails.setBankName(data.getBankName());
            bankDetails.setBranchName(data.getBranchName());
            if(data.getBranchAddress()!=null) {
                bankDetails.setAddress(data.getBranchAddress().getAddress());
                bankDetails.setCity(data.getBranchAddress().getCity());
                bankDetails.setZipCode(data.getBranchAddress().getZipCode());
                if(data.getBranchAddress().getCountry()!=null) {
                    bankDetails.setCountry(data.getBranchAddress().getCountry().getCmCode());
                }
            }
            if(data.getNetwork()!=null){
                bankDetails.setNetworkType(data.getNetwork().getCmCode());
            }
            log.info(message);
        }
        else{
            String errorMessage = "Can't set all the bank details in request payload because bankBranchResponse is empty";
            log.warn(message.descr(errorMessage));
        }
        return bankDetails;
    }

    String getBankCity(EntityWrapper entityWrapper) {
        return entityWrapper.getEntity().getBENEFICIARY_BANK_CITY();
    }

    public void handleException(Exception e, EntityWrapper entityWrapper, String url, String errorSource){
        handleException(e, entityWrapper, e instanceof ServiceException?((ServiceException) e).getErrorMessage():e.getMessage(), url, errorSource);
    }

    public void handleException(Exception e, EntityWrapper entityWrapper, String errorMessage, String url, String errorSource){
        Message message = Message.create().errorSource(errorSource).descr(e.getMessage()+"-"+errorMessage).entityName(Message.Entity.beneficiary).payeeType(payeeType()).url(url);        if(entityWrapper.getEntity()!=null){
            message.jobId(entityWrapper.getEntity().getJOB_ID()).clientId(entityWrapper.getEntity().getOLB_CLIENT_ID());
        }
        log.error(message);
        entityWrapper.setStatus(STATUS_FAILURE);
        entityWrapper.addUnexpectedError(errorSource, errorMessage);
    }

    protected BankBranchResponse validateBankBranch(EntityWrapper entityWrapper, AccountDetails accountDetails, MigClient migClient){
        BankBranchResponse bankBranchResponse = beneficiaryValidationUtility.validateBankBranchAndFetchList(entityWrapper);
        if(null != bankBranchResponse && DEFAULT_COUNTRY_CODE.equalsIgnoreCase(getCountryCode(bankBranchResponse))) {
            beneficiaryValidationUtility.reachabilityCheck(entityWrapper, migClient.getGwClientId());
            accountDetails.setIsInternationalBankAccountNumber(IS_INTERNATIONAL_BANK_ACCOUNT_FLAG_ABA);
        }
        return bankBranchResponse;
    }

    protected BeneficiaryAddress getAddress(EntityWrapper entityWrapper, MigClient migClient, BankBranchResponse bankBranchResponse, AccountDetails accountDetails, Long jobId) {
        Message getAddressMessage = Message.create().jobId(migClient.getJobId()).clientId(migClient.getEcClientId()).gwClientId(migClient.getGwClientId()).entityName(Message.Entity.beneficiary).payeeType(payeeType()).operation("Validating address and Iban validation if required");
        log.info(getAddressMessage);
        BeneficiaryAddress beneficiaryAddress = new BeneficiaryAddress();
        StgToTargetBeneEntity stgBeneficiary = entityWrapper.getEntity();
        if(null == getCountryCode(bankBranchResponse)){
            log.info(getAddressMessage.descr("Setting Error code - ERR1005 and ERR1001 as bank-branch response had no Bank details,no Country details"));
            if(payeeType().getCode()!=4){
                entityWrapper.addValidationError(ERR1005, ROUTING_NUMBER_INCORRECT, ROUTING_NUMBER_FIELD);
            }
            validateAddressResponseAndSetAddressInRequest(beneficiaryAddress,null, entityWrapper);
            beneficiaryAddress.setCountry("");
            return beneficiaryAddress;
        }
        else if (!(DEFAULT_COUNTRY_CODE.equalsIgnoreCase(getCountryCode(bankBranchResponse)))){
            log.info(getAddressMessage.descr("Iban related validations to be carried out as the record is of non US country"));
            IbanCountryRulesResponse ibanCountryRulesResponse;
            ibanCountryRulesResponse = beneficiaryValidationUtility.validateIbanCountrySpecificRulesAndValidation(entityWrapper,
                    getCountryCode(bankBranchResponse), jobId, migClient.getEcClientId());
            if (null == ibanCountryRulesResponse || !ibanCountryRulesResponse.isValidated()) {
                log.info(getAddressMessage.descr(IBAN_VALIDATION_FAILED).srcId(stgBeneficiary.getBENEFICIARY_ACCOUNT()));
                if (isValidLocalRountingCode(ibanCountryRulesResponse)) {
                    log.info(getAddressMessage.descr("Setting Error code - ERR1007 as Local routing code is mandatory and is not available from staging"));
                    entityWrapper.addValidationError(ERR1007, LOCAL_ROUTING_CODE_REQUIRED, LOCAL_ROUTING_CODE_FIELD);
                } else {
                    entityWrapper.addValidationError(ERR1003, INVALID_IBAN, ACCOUNT_NUMBER_FIELD);
                }
            }
            else if (canValidateAccount(stgBeneficiary, ibanCountryRulesResponse)) {
                log.info(getAddressMessage.descr("IBAN Required is "+ibanCountryRulesResponse.getData().getBeneficaryAccount().getIbanRequired()+" and regex is available, Account number regex validation to be carried out for pattern - "+ibanCountryRulesResponse.getData().getBeneficaryAccount().getAccountNumberRegex()));
                Pattern regExPattern = Pattern.compile(ibanCountryRulesResponse.getData().getBeneficaryAccount().getAccountNumberRegex());
                Matcher allowedCharacterMatcher = regExPattern.matcher(stgBeneficiary.getBENEFICIARY_ACCOUNT());
                if (!allowedCharacterMatcher.matches()) {
                    log.warn(getAddressMessage.descr("Setting Error code ERR1004 as Account Number regex "
                            + ibanCountryRulesResponse.getData().getBeneficaryAccount().getAccountNumberRegex() + " validation failed"));
                    entityWrapper.addValidationError(ERR1004, ACCOUNT_NUMBER_INCORRECT, ACCOUNT_NUMBER_FIELD);
                }
            }

            setInternationalBankAccountNumberFlag(stgBeneficiary, accountDetails, ibanCountryRulesResponse);
        }
        String completeAddr = getCompleteAddr(stgBeneficiary);
        AddressResponse addressResponse = addressDoctor.validateAddress(getCountryCode(bankBranchResponse), completeAddr, entityWrapper);
        validateAddressResponseAndSetAddressInRequest(beneficiaryAddress, addressResponse, entityWrapper);
        setCountry(beneficiaryAddress, bankBranchResponse);
        addressFieldLengthCheck(addressResponse,entityWrapper,getAddressMessage);
        return beneficiaryAddress;
    }

    private boolean isValidLocalRountingCode(IbanCountryRulesResponse ibanCountryRulesResponse) {
        return ibanCountryRulesResponse != null
                && ibanCountryRulesResponse.getData() != null
                && ibanCountryRulesResponse.getData().getBeneficiaryBankInfo() != null
                && ibanCountryRulesResponse.getData().getBeneficiaryBankInfo().getLocalRoutingCodeRequired() != null
                && ibanCountryRulesResponse.getData().getBeneficaryAccount() != null
                && ibanCountryRulesResponse.getData().getBeneficaryAccount().getIbanRequired() != null
                && ibanCountryRulesResponse.getData().getBeneficiaryBankInfo().getLocalRoutingCodeRequired().equalsIgnoreCase(MANDATORY) && ibanCountryRulesResponse.getData().getBeneficaryAccount().getIbanRequired().equalsIgnoreCase(NOT_APPLICABLE);
    }

    private boolean canValidateAccount(StgToTargetBeneEntity stgBeneficiary, IbanCountryRulesResponse ibanCountryRulesResponse) {
        return ibanCountryRulesResponse.getData() != null
                && ibanCountryRulesResponse.getData().getBeneficaryAccount() != null
                && ibanCountryRulesResponse.getData().getBeneficaryAccount().getIbanRequired() != null
                && ibanCountryRulesResponse.getData().getBeneficaryAccount().getAccountNumberRegex() != null
                && (ibanCountryRulesResponse.getData().getBeneficaryAccount().getIbanRequired().equalsIgnoreCase(NOT_APPLICABLE) ||
                    (ibanCountryRulesResponse.getData().getBeneficaryAccount().getIbanRequired().equalsIgnoreCase(OPTIONAL)
                    && ibanCountryRulesResponse.getData().getBeneficaryAccount().getIban() != null
                    && !(ibanCountryRulesResponse.getData().getBeneficaryAccount().getIban().getIbanISOCountryCode().equalsIgnoreCase(stgBeneficiary.getBENEFICIARY_ACCOUNT().substring(0, 2)))));
    }


    @Override
    public List<PaymentDetail> getPaymentDetails(EntityWrapper entityWrapper, MigClient migClient,
             AccountDetails accountDetails, BankDetails bankDetails) {

        PaymentDetail paymentDetail=new PaymentDetail();
        paymentDetail.setRequestType(REQUEST_TYPE);
        paymentDetail.setPreferredFlag(PREFERRED_FLAG);
        paymentDetail.setBankDetails(bankDetails);

        accountDetails.setAccountCurrency(entityWrapper.getEntity().getCURRENCY_CODE());
        paymentDetail.setAccountDetails(accountDetails);

        setPaymentMethodAndIsPersonalAccount(paymentDetail);

        List<PaymentDetail> paymentDetails= new ArrayList<>();
        paymentDetails.add(paymentDetail);
        return paymentDetails;
    }


    /**
     * Override this method for other payment types than wire
     * @param paymentDetail the object to update
     */
    protected void setPaymentMethodAndIsPersonalAccount(PaymentDetail paymentDetail){
        // Default is Wire
        paymentDetail.setPaymentMethod(PAYMENT_METHOD_WIRE);
    }

    private void setInternationalBankAccountNumberFlag(StgToTargetBeneEntity stgBeneficiary, AccountDetails accountDetails, IbanCountryRulesResponse ibanCountryRulesResponse) {
        if (ibanCountryRulesResponse==null
                || ibanCountryRulesResponse.getData()==null
                || ibanCountryRulesResponse.getData().getBeneficaryAccount() == null
                || ibanCountryRulesResponse.getData().getBeneficaryAccount().getIbanRequired() == null
                ){
            accountDetails.setIsInternationalBankAccountNumber(IS_INTERNATIONAL_BANK_ACCOUNT_FLAG_ABA);
        }
        else if(ibanCountryRulesResponse.getData().getBeneficaryAccount().getIbanRequired().equalsIgnoreCase(MANDATORY) && ibanCountryRulesResponse.isValidated()){
            accountDetails.setIsInternationalBankAccountNumber(IS_INTERNATIONAL_BANK_ACCOUNT_FLAG_NON_ABA);
        }
        else if(   ibanCountryRulesResponse.getData().getBeneficaryAccount().getIban() != null
                && ibanCountryRulesResponse.getData().getBeneficaryAccount().getIban().getIbanISOCountryCode() != null
                && stgBeneficiary.getBENEFICIARY_ACCOUNT() != null
                && ibanCountryRulesResponse.getData().getBeneficaryAccount().getIbanRequired().equalsIgnoreCase(OPTIONAL) && !(ibanCountryRulesResponse.getData().getBeneficaryAccount().getIban().getIbanISOCountryCode().equalsIgnoreCase(stgBeneficiary.getBENEFICIARY_ACCOUNT().substring(0,2)))){
            accountDetails.setIsInternationalBankAccountNumber(IS_INTERNATIONAL_BANK_ACCOUNT_FLAG_ABA);
        }
        else if (ibanCountryRulesResponse.getData().getBeneficaryAccount().getIbanRequired().equalsIgnoreCase(OPTIONAL) && ibanCountryRulesResponse.isValidated()){
            accountDetails.setIsInternationalBankAccountNumber(IS_INTERNATIONAL_BANK_ACCOUNT_FLAG_NON_ABA);
        }
        else{
            accountDetails.setIsInternationalBankAccountNumber(IS_INTERNATIONAL_BANK_ACCOUNT_FLAG_ABA);
        }
        log.info(Message.create().summary().descr("InternationalBankAccountNumberFlag is set - "+accountDetails.getIsInternationalBankAccountNumber()).jobId(stgBeneficiary.getJOB_ID()).entityName(Message.Entity.beneficiary));
    }

    @Override
    public EntityWrapper migrateBeneficiaryToGateway(EntityWrapper entityWrapper, ProcessingContext processingContext) {
        if(entityWrapper.isAlreadySentToGateway() || entityWrapper.hasUnexpectedErrors()) {
            return entityWrapper;
        }

        // if no errors, migrate, otherwise report to error endpoint
        if (entityWrapper.hasValidationErrors()){
            callGatewayForInvalidBeneficiary(entityWrapper, processingContext);
        }
        else{
            setCountryIfEmpty(entityWrapper);
            callGatewayForValidatedBeneficiary(entityWrapper, processingContext);
        }
        return entityWrapper;
    }

    private EntityWrapper callGatewayForValidatedBeneficiary(EntityWrapper entityWrapper, ProcessingContext processingContext) {
        AddBeneficiaryResponseData addBeneficiaryResponseData = new AddBeneficiaryResponseData();
        Message logMessage = Message.create().jobId(processingContext.getJobId()).clientId(entityWrapper.entity.getOLB_CLIENT_ID()).payeeType(processingContext.payeeType)
                .entityName(Message.Entity.beneficiary).srcId(String.valueOf(entityWrapper.getEntity().getSourceBeneId(processingContext.payeeType))).operation("Call Gateway to create Bene after all Validation");
        log.info(logMessage.summary().descr("Bene creation in Gateway for the record started"));
        BeneficiaryInfo beneficiaryInfo;
        try {
            HttpHeaders headers = new HttpHeaders();
            headers.add(MigrationConstants.AUTHORIZATION_HEADER_NAME, cacheManagerUtility.getOauthToken());
            headers.add(MigrationConstants.CONTENT_TYPE, MigrationConstants.APPLICATION_HEADER_JSON);


            log.debug(Message.create().descr("Service URL: "+ processingContext.serviceUrl));
            log.debug(Message.create().descr("Headers= "+ headers));
            log.debug(Message.create().descr(LOG_REQUEST_PAYLOAD + entityWrapper.getGatewayMigrationRequest()));

            HttpEntity<AddBeneficiaryRequest> requestEntity = new HttpEntity<>(entityWrapper.getGatewayMigrationRequest(), headers);

            ResponseEntity<BeneficiaryInfo> beneficiaryInfoResponseEntity = retryService.exchange(processingContext.serviceUrl, HttpMethod.POST, requestEntity, new ParameterizedTypeReference<BeneficiaryInfo>() {});
            beneficiaryInfo = beneficiaryInfoResponseEntity.getBody();
        } catch (RestClientResponseException restClientResponseException) {
            handleRestException(entityWrapper, restClientResponseException, processingContext.serviceUrl, "OCH add beneficiary");
            return entityWrapper;
        } catch (Exception exception) {
            handleException(exception, entityWrapper, processingContext.serviceUrl, "OCH add beneficiary");
            return entityWrapper;
        }

        if ( null != beneficiaryInfo && null != beneficiaryInfo.getPaymentDetails() && null != beneficiaryInfo.getStatus().getCmCode()
                && beneficiaryInfo.getStatus().getCmCode().equalsIgnoreCase(CM_CODE_SUC)) {
            log.info(logMessage.summary().descr(LOG_SUCCESS_VALUE +
                    beneficiaryInfo.getPaymentDetails().get(FIRST).getCounterpartyId() + " "+
                            beneficiaryInfo.getGroupId()).payeeType(processingContext.payeeType).targetId(beneficiaryInfo.getPaymentDetails().get(FIRST).getCounterpartyId()));

            addBeneficiaryResponseData.setCounterpartyName(beneficiaryInfo.getCounterpartyName());
            addBeneficiaryResponseData.setGroupId(beneficiaryInfo.getGroupId());
            addBeneficiaryResponseData.setPaymentDetails(beneficiaryInfo.getPaymentDetails());
            addBeneficiaryResponseData.setStatus(beneficiaryInfo.getStatus());
            entityWrapper.setStatus(mapStatus(beneficiaryInfo.getStatus()));
            log.info(logMessage.summary().descr("Successfully completed migration of this record to Gateway"));
        }
        else{
            log.error(Message.create().descr("Please check beneficiaryInfoResponseEntity."));
            entityWrapper.setStatus(STATUS_FAILURE);
            entityWrapper.addUnexpectedError("OCH counterparty endpoint", "Please check beneficiaryInfo ResponseEntity.");
        }
        AddBeneficiaryResponse addBeneficiaryResponse = new AddBeneficiaryResponse();
        addBeneficiaryResponse.setData(addBeneficiaryResponseData);
        entityWrapper.setGatewayMigrationResponse(addBeneficiaryResponse);
        return entityWrapper;
    }

    public EntityWrapper callGatewayForInvalidBeneficiary(EntityWrapper entityWrapper, ProcessingContext processingContext){
        Message logMessage = Message.create().jobId(processingContext.getJobId()).clientId(entityWrapper.entity.getOLB_CLIENT_ID()).payeeType(processingContext.payeeType)
                .entityName(Message.Entity.beneficiary).operation("callGatewayForInvalidBeneficiary").descr("Based on payeeType and validation errors we will "+((shouldReportErrorsToGateway(processingContext))?"":"not ")+"report validation errors to Gateway");
        log.info(logMessage);
        if(shouldReportErrorsToGateway(processingContext)){
            // generateBodyWithExceptions
            StgToTargetBeneEntity entity = entityWrapper.entity;
            EconnectSourceData econnectSourceData = EntityToModelMapper.INSTANCE.convertPaymentToMigEntity(entity, processingContext.getPayeeType());
            ErrorQueueRequest errorQueueRequest = new ErrorQueueRequest();
            errorQueueRequest.setEconnectSourceData(econnectSourceData);

            //CorporateId corresponds to the GatewayId. It should only be set here for invalid beneficiaries, not for successfully validated in the OCH request
            entityWrapper.getGatewayMigrationRequest().setCorporateId(processingContext.migClient.getGwClientId());

            errorQueueRequest.setGatewayTargetData(entityWrapper.getGatewayMigrationRequest());
            errorQueueRequest.setExceptionData(entityWrapper.getValidationErrorList());
            MetaData metaData = new MetaData();
            metaData.setMigrationJobId(processingContext.getJobId());
            metaData.setSourceType(entity.getSourceType(processingContext.getPayeeType()));
            errorQueueRequest.setMetaData(metaData);

            // send request with exceptions to payments API
            try {
                HttpHeaders headers = new HttpHeaders();
                headers.add(MigrationConstants.AUTHORIZATION_HEADER_NAME, cacheManagerUtility.getOauthToken());
                headers.add(MigrationConstants.CONTENT_TYPE, MigrationConstants.APPLICATION_HEADER_JSON);

                log.debug(Message.create().descr("Error reporting service URL: " + reportErrorUrl));
                log.debug(Message.create().descr("Headers= " + headers));
                log.debug(Message.create().descr(LOG_REQUEST_PAYLOAD + entityWrapper.getGatewayMigrationRequest()));

                HttpEntity<ErrorQueueRequest> requestEntity = new HttpEntity<>(errorQueueRequest, headers);

                ResponseEntity<ErrorQueueResponse> responseEntity = retryService.exchange(reportErrorUrl, HttpMethod.POST, requestEntity, new ParameterizedTypeReference<ErrorQueueResponse>() {});
                ErrorQueueResponse apiResponse = responseEntity.getBody();
                if (apiResponse != null) {
                    entityWrapper.setErrorQueueResponse(apiResponse);
                    if (STATUS_SUCCESS.equals(apiResponse.getStatus())) {
                        entityWrapper.setStatus(STATUS_SUCCESS);
                        log.info(logMessage.descr("successfully reported "+entityWrapper.getValidationErrorList().size()+" errors to Gateway").targetId(String.valueOf(apiResponse.getPendingRecipientId())));
                    } else {
                        entityWrapper.setStatus(STATUS_FAILURE);
                        log.info(logMessage.descr("failed to  report errors to Gateway: "+ apiResponse));
                    }
                    if (!entityWrapper.getEntity().getJOB_ID().equals(apiResponse.getMigrationJobId())) {
                        throw new ServiceException("the jobId " + entityWrapper.getEntity().getJOB_ID() + " was not matching the response " + apiResponse.getMigrationJobId() + " from payment error service");
                    }
                }
            } catch (RestClientResponseException restClientResponseException) {
                handleRestException(entityWrapper, restClientResponseException, reportErrorUrl, "Payment's beneficiary error reporting API");
                return entityWrapper;
            } catch (Exception exception) {
                handleException(exception, entityWrapper, reportErrorUrl, "Payment's beneficiary error reporting API");
                return entityWrapper;
            }
        }
        return entityWrapper;
    }

    protected String mapStatus(Status status) {
        if (status==null || status.getCodeDescription()==null){
            return STATUS_FAILURE;
        }
        String ochStatus = status.getCodeDescription();
        if(ochStatus.equalsIgnoreCase(STATUS_SUCCESS)){
            return STATUS_SUCCESS;
        }
        else{
            return STATUS_IGNORE;
        }
    }

    private void handleRestException(EntityWrapper entityWrapper, RestClientResponseException restClientResponseException, String url, String errorSource) {
        assert restClientResponseException != null;
        if (null == restClientResponseException.getResponseHeaders() || restClientResponseException.getResponseHeaders().getValuesAsList(CHANNEL_CONTEXT).isEmpty()) {
            handleException(restClientResponseException, entityWrapper, url, errorSource);
        } else {
            try {
                String dataJson = objectMapper.writeValueAsString(restClientResponseException.getResponseHeaders().getValuesAsList(CHANNEL_CONTEXT));
                dataJson=dataJson.replaceAll("\\\\", "");
                dataJson=dataJson.replaceAll("\"", "");
                handleException(restClientResponseException, entityWrapper, dataJson, url, errorSource);
            } catch (JsonProcessingException e) {
                handleException(e, entityWrapper, url, errorSource);
            }
        }
    }

    /**
     * Note, this method is not really updating. It is inserting a new record while keeping the historical previous records
     * @param entityWrapper holds the state of the entity
     * @param processingContext holds the state of the run
     * @return the entityWrapper with updated status
     */
    @Override
    public EntityWrapper updateBeneficiaryDBRecord(EntityWrapper entityWrapper, ProcessingContext processingContext){
        Message updateMigBene=Message.create().entityName(Message.Entity.beneficiary).clientId(processingContext.getMigClient().getEcClientId()).gwClientId(processingContext.migClient.getGwClientId()).srcId(String.valueOf(entityWrapper.getEntity().getSourceBeneId(processingContext.getPayeeType())));
        if(entityWrapper.isAlreadySentToGateway()) {
            return entityWrapper;
        }
        log.info(updateMigBene.descr("Updating record migration status in Mig Bene"));
        MigBeneficiary migBeneficiary = new MigBeneficiary();
        migBeneficiary.setEcClientId(processingContext.getMigClient().getEcClientId());
        migBeneficiary.setGwClientId(processingContext.migClient.getGwClientId().toUpperCase());
        setBeneSourceIdAndTypeForEntityLogging(migBeneficiary, entityWrapper.getEntity());
        migBeneficiary.setJobId(processingContext.migClient.getJobId());
        migBeneficiary.setBeneSourceId(String.valueOf(entityWrapper.getEntity().getSourceBeneId(processingContext.getPayeeType())));
        migBeneficiary.setBeneficiaryId("");
        migBeneficiary.setGroupId("");
        Date dt = new Date();

        if(entityWrapper.hasUnexpectedErrors()) {
            // unexpected error
            migBeneficiary.setStatus(STATUS_FAILURE);
            entityWrapper.setStatus(STATUS_FAILURE);
            migBeneficiary.setComments(entityWrapper.getFirstUnexpectedErrorMessage());
        }
        else if (entityWrapper.hasErrorApiResponse()){
            // errors were reported to gateway
            migBeneficiary.setStatus(entityWrapper.getStatus());
            migBeneficiary.setComments(ERRORS_REPORTED_TO_GATEWAY);
            migBeneficiary.setPendingRecipientId(entityWrapper.getErrorQueueResponse().getPendingRecipientId());
        }
        else if (entityWrapper.hasMigrationResponse()) {
            // it was migrated to gateway
            migBeneficiary.setBeneficiaryId(entityWrapper.getGatewayMigrationResponse().getData().getPaymentDetails().get(FIRST).getPayeeListId());
            migBeneficiary.setGroupId(entityWrapper.getGatewayMigrationResponse().getData().getGroupId());
            migBeneficiary.setStatus(entityWrapper.getStatus());
            migBeneficiary.setComments(BENEFICIARY_MIGRATED_TO_GATEWAY);
        }
        else if(entityWrapper.hasValidationErrors()) {
            // it has validation errors not migrated to gateway. For payee types PAST, CHECK, ACH and ACHLarge
            migBeneficiary.setStatus(STATUS_IGNORE);
            entityWrapper.setStatus(STATUS_IGNORE);
            migBeneficiary.setComments(entityWrapper.getValidationErrorList().get(FIRST).getDescription()); // Only first error?
        }
        else
        {
            // unexpected code path
            entityWrapper.setStatus(STATUS_FAILURE);
            migBeneficiary.setStatus(STATUS_FAILURE);
            migBeneficiary.setComments(UNEXPECTED_CODE_PATH);
        }

        List<MigratedBeneficiaryEntity> existingMigratedBeneficiaryEntity = migBeneficiaryMapper.findByJobIdAndBeneId(migBeneficiary.getJobId(), migBeneficiary.getBeneSourceId());
        if(existingMigratedBeneficiaryEntity.isEmpty()){
            log.info(updateMigBene.summary().descr("Inserted record migration status during its first run in Mig Bene"));
            migBeneficiaryMapper.insertMigratedBene(migBeneficiary);
        }
        else{
            migBeneficiary.setUpdatedBy(migrationUserId);
            migBeneficiary.setUpdatedDt(dt);
            log.info(updateMigBene.summary().descr("Updated record migration status during re-runs in Mig Bene"));
            migBeneficiaryMapper.updateBeneficiary(migBeneficiary);
        }
        return entityWrapper;
    }


    private boolean shouldReportErrorsToGateway(ProcessingContext processingContext) {
        return processingContext.getPayeeType()==TEMPLATE
                || processingContext.getPayeeType()==FUTURE;
    }

    protected String getCompleteAddr(StgToTargetBeneEntity stgBeneficiary) {
        StringBuilder builder = new StringBuilder();
        appendIfExists(builder, stgBeneficiary.getBENEFICIARY_ADDRESS_1());
        appendIfExists(builder, stgBeneficiary.getBENEFICIARY_ADDRESS_2());
        appendIfExists(builder, stgBeneficiary.getBENEFICIARY_ADDRESS_3());
        return builder.toString();
    }

    private void appendIfExists(StringBuilder builder, String s) {
        if (StringUtils.isNotBlank(s)) {
            builder.append(builder.length()>0?COMMA:"");
            builder.append(s);
        }
    }

    protected void validateAddressResponseAndSetAddressInRequest(BeneficiaryAddress beneficiaryAddress, AddressResponse addressResponse, EntityWrapper entityWrapper) {
        Message addressSetMessage = Message.create().clientId(entityWrapper.getEntity().getOLB_CLIENT_ID()).jobId(entityWrapper.getEntity().getJOB_ID()).entityName(Message.Entity.beneficiary);
        if (addressResponse==null || !(VALIDATED_ADDRESS_RESPONSE.equalsIgnoreCase(addressResponse.getValidationscore())||CORRECTED_ADDRESS_RESPONSE.equalsIgnoreCase(addressResponse.getValidationscore()))) {
            if(addressResponse!=null && !ADDRESS_DOCTOR_COUNTRY_NOT_SUPPORTED.equalsIgnoreCase(addressResponse.getValidationdesc())){
                entityWrapper.addValidationError(ERR1001, RECIPIENT_ADDRESS_INCORRECT, ADDRESS_FIELD);
            }
            log.warn(addressSetMessage.summary().descr(ADDRESS_DOCTOR_VALIDATION_MESSAGE+((addressResponse==null || addressResponse.getValidationscore()==null)?"Address Doctor not called/Address response is null":addressResponse.getValidationscore()+"-"+addressResponse.getValidationdesc())));

            if("".equals(entityWrapper.getEntity().getBENEFICIARY_ADDRESS_2()) || null == entityWrapper.getEntity().getBENEFICIARY_ADDRESS_2()){
                beneficiaryAddress.setAddressLine1(entityWrapper.getEntity().getBENEFICIARY_ADDRESS_1());
            }else{
                beneficiaryAddress.setAddressLine1(entityWrapper.getEntity().getBENEFICIARY_ADDRESS_1()+SPACE+entityWrapper.getEntity().getBENEFICIARY_ADDRESS_2());
            }
            beneficiaryAddress.setCity(entityWrapper.getEntity().getBENEFICIARY_ADDRESS_3());
            beneficiaryAddress.setZipCode("");
            beneficiaryAddress.setState("");
        }
        else{
            beneficiaryAddress.setAddressLine1(addressResponse.getCleansedaddrln1());

            beneficiaryAddress.setAddressLine2(concatenateAddressLines(addressResponse.getCleansedaddrln2(), addressResponse.getCleansedaddrln3()));
            beneficiaryAddress.setCity(addressResponse.getCleansedcitynm());
            setZipCodeAfterAddressDoctorValidation(beneficiaryAddress, addressResponse);
            beneficiaryAddress.setState(addressResponse.getCleansedstatecd());
            log.info(addressSetMessage.summary().descr("Address doctor validation completed and validated address is set for address fields."));
        }
    }

    protected void setZipCodeAfterAddressDoctorValidation(BeneficiaryAddress beneficiaryAddress, AddressResponse addressResponse) {
        if(addressResponse.getCleansedcntrycd() != null && DEFAULT_COUNTRY_CODE.equalsIgnoreCase(addressResponse.getCleansedcntrycd())){
            beneficiaryAddress.setZipCode(addressResponse.getCleansedzipcd().substring(0,5));
        }else if(addressResponse.getCleansedcntrycd() != null){
            beneficiaryAddress.setZipCode(addressResponse.getCleansedzipcd());
        } else {
            beneficiaryAddress.setZipCode("");
        }
    }

    protected String concatenateAddressLines(String l1, String l2) {
        if(l1 == null && l2 == null){
            return "";
        }else if(l1 != null && l2 == null){
            return l1;
        }else if(l1 == null){
            return l2;
        }else{
            return l1+" "+l2;
        }
    }

    protected abstract void setBeneSourceIdAndTypeForEntityLogging(MigBeneficiary migInvalidBeneficiary, StgToTargetBeneEntity stgBeneficiary);

    private BankBranchResponseData getFirstBranch(BankBranchResponse bankBranchResponse){
        return (bankBranchResponse!=null && bankBranchResponse.getData()!=null)?
            bankBranchResponse.getData().get(FIRST):null;
    }

    private String getCountryCode(BankBranchResponse bankBranchResponse){
        BankBranchResponseData branch = getFirstBranch( bankBranchResponse);
        return (branch!=null  && branch.getBranchAddress() !=null && branch.getBranchAddress().getCountry()!=null )?
                branch.getBranchAddress().getCountry().getCmCode():null;
    }

    protected void setCountry(BeneficiaryAddress beneficiaryAddress, BankBranchResponse bankBranchResponse) {
        if(bankBranchResponse==null || bankBranchResponse.getData()==null || bankBranchResponse.getData().isEmpty() || beneficiaryAddress.getCountry()==null){
            beneficiaryAddress.setCountry("");
        }
        else if(!bankBranchResponse.getData().isEmpty()){
            beneficiaryAddress.setCountry(bankBranchResponse.getData().get(FIRST).getBranchAddress().getCountry().getCmCode());
        }
    }

    protected void addressFieldLengthCheck(AddressResponse addressResponse, EntityWrapper entityWrapper,Message addressMessage) {
        addressMessage.operation("addressFieldLengthCheck");
        if(addressResponse==null || !(VALIDATED_ADDRESS_RESPONSE.equalsIgnoreCase(addressResponse.getValidationscore())||CORRECTED_ADDRESS_RESPONSE.equalsIgnoreCase(addressResponse.getValidationscore()))){
            log.info(addressMessage.descr("Address field length check was not carried out as Address doctor validation was not done successfully"));
        }
        else if(DEFAULT_COUNTRY_CODE.equalsIgnoreCase(addressResponse.getCleansedcntrycd())){
            log.info(addressMessage.descr("Address field length check of US address started"));
            validateStreetAddressLength(addressResponse,entityWrapper);
            validateUSAddressLength(addressResponse,entityWrapper);
            log.info(addressMessage.descr("Address field length check of US address completed"));
        }
        else{
            log.info(addressMessage.descr("Address field length check of Non US address started"));
            validateStreetAddressLength(addressResponse,entityWrapper);
            validateNonUSAddressLength(addressResponse,entityWrapper);
            log.info(addressMessage.descr("Address field length check of Non US address completed"));
        }
    }

    protected void validateStreetAddressLength(AddressResponse addressResponse,EntityWrapper entityWrapper){
        int cleansedStreetAddressLength=addressResponse.getCleansedaddrln1().length()+addressResponse.getCleansedaddrln2().length()+addressResponse.getCleansedaddrln3().length();
        if(cleansedStreetAddressLength> BENE_STREET.getLength()){
            entityWrapper.addValidationError(ERR1002,FIELD_LENGTH_EXCEEDED,BENE_STREET.getField());
        }
    }

    protected void validateUSAddressLength(AddressResponse addressResponse,EntityWrapper entityWrapper){
        if(addressResponse.getCleansedcitynm().length()> BENE_CITY_US.getLength()){
            entityWrapper.addValidationError(ERR1002,FIELD_LENGTH_EXCEEDED,BENE_CITY_US.getField());
        }
        if(addressResponse.getCleansedstatecd().length() != BENE_STATE_US.getLength()){
            entityWrapper.addValidationError(ERR1002,FIELD_LENGTH_EXCEEDED,BENE_STATE_US.getField());
        }
        if(addressResponse.getCleansedzipcd().length() > BENE_ZIP_US.getLength()){
            entityWrapper.addValidationError(ERR1002,FIELD_LENGTH_EXCEEDED,BENE_ZIP_US.getField());
        }
    }

    protected void validateNonUSAddressLength(AddressResponse addressResponse,EntityWrapper entityWrapper){
        if(addressResponse.getCleansedcitynm().length() > BENE_CITY_NON_US.getLength()){
            entityWrapper.addValidationError(ERR1002,FIELD_LENGTH_EXCEEDED,BENE_CITY_NON_US.getField());
        }
        if(addressResponse.getCleansedstatecd().length() > BENE_STATE_NON_US.getLength()){
            entityWrapper.addValidationError(ERR1002,FIELD_LENGTH_EXCEEDED,BENE_STATE_NON_US.getField());
        }
        if(addressResponse.getCleansedzipcd().length() > BENE_ZIP_NON_US.getLength()){
            entityWrapper.addValidationError(ERR1002,FIELD_LENGTH_EXCEEDED,BENE_ZIP_NON_US.getField());
        }
    }

    @Override
    public void lengthCheckValidation(EntityWrapper entityWrapper, MigClient migClient, StgToTargetBeneEntity.PAYEE_TYPE payeeType, AddBeneficiaryRequest addBeneficiaryRequest) {
        Message logMessage = Message.create().jobId(migClient.getJobId()).clientId(migClient.getEcClientId()).gwClientId(migClient.getGwClientId()).operation("lengthCheckValidation").srcId(String.valueOf(entityWrapper.entity.getSourceBeneId(payeeType)));
        BankDetails bankDetails = addBeneficiaryRequest.getPaymentDetails().get(0).getBankDetails();
        AccountDetails accountDetails = addBeneficiaryRequest.getPaymentDetails().get(0).getAccountDetails();
        log.info(logMessage.descr("Length check started for Bene name, nickname, account number and bank identifier"));
        if( null!=addBeneficiaryRequest.getCounterpartyName() && (addBeneficiaryRequest.getCounterpartyName().length() > BENE_NAME.getLength())){
            entityWrapper.addValidationError(ERR1002,FIELD_LENGTH_EXCEEDED,BENE_NAME.getField());
        }

        if( null!=addBeneficiaryRequest.getCounterpartyNickname() && (addBeneficiaryRequest.getCounterpartyNickname().length() > BENE_NICKNAME.getLength())){
            entityWrapper.addValidationError(ERR1002,FIELD_LENGTH_EXCEEDED,BENE_NICKNAME.getField());
        }

        accountAndRoutingNumberCheck(entityWrapper, bankDetails, accountDetails);

        log.info(logMessage.descr("Length check completed for Bene name, nickname, account number and bank identifier"));

    }

    public void accountAndRoutingNumberCheck(EntityWrapper entityWrapper, BankDetails bankDetails, AccountDetails accountDetails) {
        if(bankDetails !=null && DEFAULT_COUNTRY_CODE.equalsIgnoreCase(bankDetails.getCountry())){
            if(accountDetails.getAccountId().length() > BENE_ACCOUNT_NUMBER_US.getLength()) {
                entityWrapper.addValidationError(ERR1002, FIELD_LENGTH_EXCEEDED, BENE_ACCOUNT_NUMBER_US.getField());
            }
            if(bankDetails.getBankIdentifier().length() != BENE_ROUTING_NUMBER.getLength()) {
                entityWrapper.addValidationError(ERR1002, FIELD_LENGTH_EXCEEDED, BENE_ROUTING_NUMBER.getField());
            }
        }
        else if(bankDetails !=null && !DEFAULT_COUNTRY_CODE.equalsIgnoreCase(bankDetails.getCountry())){
            if(accountDetails.getAccountId().length() > BENE_ACCOUNT_NUMBER_NON_US.getLength()) {
                entityWrapper.addValidationError(ERR1002, FIELD_LENGTH_EXCEEDED, BENE_ACCOUNT_NUMBER_NON_US.getField());
            }
            if(!(bankDetails.getBankIdentifier().length() != BENE_SWIFT.getLength() || bankDetails.getBankIdentifier().length() != BENE_BIC.getLength())) {
                entityWrapper.addValidationError(ERR1002, FIELD_LENGTH_EXCEEDED, BENE_SWIFT.getField());
            }
        }
    }

    protected void setCountryIfEmpty(EntityWrapper entityWrapper){
        if(null==entityWrapper.getGatewayMigrationRequest().getBeneficiaryAddress().getCountry() ||
                "".equalsIgnoreCase(entityWrapper.getGatewayMigrationRequest().getBeneficiaryAddress().getCountry())){
            entityWrapper.getGatewayMigrationRequest().getBeneficiaryAddress().setCountry(DEFAULT_COUNTRY_CODE);
        }
    }

    protected boolean isIpayAccNumOrRoutingNumNull(EntityWrapper entityWrapper,ProcessingContext processingContext){
        if(processingContext.getPayeeType()==CHECK
                || processingContext.getPayeeType()==ACH || processingContext.getPayeeType()==ACH_LARGE){
            StgToTargetBeneEntity entity=entityWrapper.getEntity();
            if((null==entity.getBENEFICIARY_ACCOUNT() || "NA".equalsIgnoreCase(entity.getBENEFICIARY_ACCOUNT())) && null==entity.getBENEFICIARY_BANK_IDENTIFIER()){
                return true;
            }
        }
        return false;
    }
}

