package com.svb.gateway.migration.beneficiaries.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.svb.gateway.migration.beneficiaries.model.*;
import com.svb.gateway.migration.common.constants.MigrationConstants;
import com.svb.gateway.migration.common.logging.Message;
import com.svb.gateway.migration.common.service.RetryService;
import com.svb.gateway.migration.common.utility.CacheManagerUtility;
import lombok.extern.log4j.Log4j2;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.*;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestClientResponseException;
import org.springframework.web.client.RestTemplate;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

import static com.svb.gateway.migration.beneficiaries.model.ValidationError.*;
import static com.svb.gateway.migration.common.constants.MigrationConstants.CHANNEL_CONTEXT;

@Log4j2
@Component
public class BeneficiaryValidationUtility {
    public static final int SWIFT_MIN_LENGTH = 8;
    public static final String SUCCESSFULLY_VALIDATED_IBAN = "0";
    public static final String WARNING_VALIDATING_IBAN = "2";

    private static final ObjectMapper objectMapper = new ObjectMapper();

    @Autowired
    RetryService retryService;

    @Autowired
    RestTemplate restTemplate;

    @Value(value ="${mig.bankBranchFetch.url}")
    String bankBranchUrl;

    @Value(value ="${mig.ibanCountrySpecificRule.url}")
    String ibanRuleUrl;

    @Value(value ="${mig.ibanValidation.url}")
    String ibanValidationUrl;

    @Value(value ="${mig.reachabilityCheck.url}")
    String reachabilityUrl;

    @Value("${header.service.token}")
    String token;


    @Autowired
    CacheManagerUtility cacheManagerUtility;

    public static final String MANDATORY = "M";
    public static final String OPTIONAL = "O";
    public static final String NOT_APPLICABLE = "NA";
    private static final String VALIDATION_ERROR_CODE = "\"103627";//The bank details do not exist.

    public static final Pattern regexNumChar = Pattern.compile("[^a-zA-Z0-9]");
    public static final Pattern regexSwift = Pattern.compile("[^a-zA-Z0-9-/?:().,'+ ]");

    public String removeSpecialChars(String value) {
        return removePattern(regexNumChar, value);
    }

    public String removeSwift(String value) {
        return removePattern(regexSwift, value);
    }
    private String removePattern(Pattern pattern,String value)
    {
        if(StringUtils.isBlank(value)) {
            return value;
        }

        var matcher = pattern.matcher(value);
        if(matcher.find()) {

            return matcher.replaceAll("");
        } else {
            return value;
        }
    }
    public  BankBranchResponse validateBankBranchAndFetchList(EntityWrapper entityWrapper)  {

        ResponseEntity<List<BankBranchResponseData>> bankBranchResponseEntity = null;

        BankBranchResponse bankBranchResponse = new BankBranchResponse();

        Message logMessage = Message.create().entityName(Message.Entity.beneficiary).jobId(entityWrapper.getEntity().getJOB_ID()).clientId(entityWrapper.getEntity().getOLB_CLIENT_ID()).bankId(entityWrapper.getEntity().getBENEFICIARY_BANK_IDENTIFIER()).operation("Bank branch list fetch for bank identifier");

        try{
            HttpHeaders headers = new HttpHeaders();
            headers.add(MigrationConstants.AUTHORIZATION_HEADER_NAME, cacheManagerUtility.getVTToken());
            headers.add(MigrationConstants.CONTENT_TYPE, MigrationConstants.APPLICATION_HEADER_JSON);

            HttpEntity<?> requestEntity = new HttpEntity<>(headers);
            String finalBankBranchUrl = bankBranchUrl+entityWrapper.getEntity().getBENEFICIARY_BANK_IDENTIFIER();

            log.info(logMessage.descr("Bank branch list fetch call for bank identifier").url(finalBankBranchUrl));

            bankBranchResponseEntity = retryService.exchange(finalBankBranchUrl, HttpMethod.GET, requestEntity, new ParameterizedTypeReference<List<BankBranchResponseData>>() {});

        }
        catch (RestClientResponseException restClientResponseException) {
            // If we get a special response including validationErrorCode, we treat it as a validation error for "The bank details do not exist."
            handleRestException(restClientResponseException,entityWrapper, logMessage, "Bank Branch fetch Endpoint for routing no. "+entityWrapper.getEntity().getBENEFICIARY_BANK_IDENTIFIER()+ " failed -");
            return bankBranchResponse;
        }
        catch (Exception e){
            // treating Generic Exception as unexpected FAILURE
            log.error(logMessage.summary().descr("Generic Exception occurred while fetching bank branch list : "+e.getMessage()));
            entityWrapper.addUnexpectedError("Get bank branch endpoint for routing no "+entityWrapper.getEntity().getBENEFICIARY_BANK_IDENTIFIER()+" failed -", e.getMessage());
            return bankBranchResponse;
        }

        if(HttpStatus.OK.equals(bankBranchResponseEntity.getStatusCode())) {
            bankBranchResponse.setData(bankBranchResponseEntity.getBody());
            List<BankBranchResponseData> filteredBankBranchResponseData = new ArrayList<>();
            for(BankBranchResponseData bankBranchResponseData : bankBranchResponse.getData()){
                if(bankBranchResponseData.getBankClearingCode().equalsIgnoreCase(entityWrapper.getEntity().getBENEFICIARY_BANK_IDENTIFIER())){
                    filteredBankBranchResponseData.add(bankBranchResponseData);
                }
            }
            log.info(logMessage.descr("Filtered bank-branch list to size "+filteredBankBranchResponseData.size()+" based on staging clearing code"));
            bankBranchResponse.setData(filteredBankBranchResponseData);
            bankBranchResponse.setValidated(true);
            logMessage.descr("Bank branch list fetch call completed successfully.");
        } else {
            bankBranchResponse.setValidated(false);
            logMessage.descr("Bank branch list fetch call unsuccessful. Returned error code "+bankBranchResponseEntity.getStatusCode());
        }
        log.info(logMessage.summary());
        return bankBranchResponse;
    }

    public  IbanCountryRulesResponse validateIbanCountrySpecificRulesAndValidation(EntityWrapper entityWrapper, String countryCode, Long jobId, String ecClientId) {

        ResponseEntity<IbanCountryRulesResponse> ibanResponseEntity = null;

        IbanCountryRulesResponse ibanCountryRulesResponse = new IbanCountryRulesResponse();

        Message logMessage = Message.create().entityName(Message.Entity.beneficiary).jobId(jobId).clientId(ecClientId).accountNumber(entityWrapper.getEntity().getBENEFICIARY_ACCOUNT()).operation("Iban country rules fetch and validation");

        HttpHeaders headers = new HttpHeaders();
        headers.add(MigrationConstants.CONTENT_TYPE, MigrationConstants.APPLICATION_HEADER_JSON);

        HttpEntity<?> requestEntity = new HttpEntity<>(headers);

        String finalIbanRuleUrl = ibanRuleUrl+countryCode;

        log.info(logMessage.descr("Iban country rules fetch call for "+countryCode).url(finalIbanRuleUrl));
        try {
            ibanResponseEntity = retryService.exchange(finalIbanRuleUrl, HttpMethod.GET, requestEntity, new ParameterizedTypeReference<IbanCountryRulesResponse>(){});
        }
        catch(RestClientException e){
            log.error(logMessage.descr("Iban country rules fetch call "+e.getMessage()));
            entityWrapper.addUnexpectedError("Payment validation rules endpoint for IBAN country", e.getMessage());
        }
        if(ibanResponseEntity != null && ibanResponseEntity.getBody() !=null && HttpStatus.OK.equals(ibanResponseEntity.getStatusCode())) {
            ibanCountryRulesResponse.setData(ibanResponseEntity.getBody().getData());
            String accountPrefix = entityWrapper.getEntity().getBENEFICIARY_ACCOUNT().substring(0,2);
            if(!(ibanCountryRulesResponse.getData().getBeneficaryAccount().getIbanRequired().equalsIgnoreCase(NOT_APPLICABLE)) && ibanCountryRulesResponse.getData().getBeneficaryAccount().getIban().getIbanISOCountryCode().equalsIgnoreCase(accountPrefix)){
                log.info(logMessage.descr("Iban validation needed based on country rules and account number format"));
                validateIbanAndSetTrueIfSuccess(entityWrapper, ecClientId, ibanCountryRulesResponse);
            }
            // Leave it invalid as default and log it, when Iban required is mandatory but account number not having prefix of IbanISOCountryCode
            else if(ibanCountryRulesResponse.getData().getBeneficaryAccount().getIbanRequired().equalsIgnoreCase(MANDATORY) && !ibanCountryRulesResponse.getData().getBeneficaryAccount().getIban().getIbanISOCountryCode().equalsIgnoreCase(accountPrefix)) {
                log.info(logMessage.descr("Iban required is mandatory but account number not having prefix of IbanISOCountryCode - "+ibanCountryRulesResponse.getData().getBeneficaryAccount().getIban().getIbanISOCountryCode()));
            }
            //Optional and user has provided some account number
            else if(ibanCountryRulesResponse.getData().getBeneficaryAccount().getIbanRequired().equalsIgnoreCase(OPTIONAL) && !(ibanCountryRulesResponse.getData().getBeneficaryAccount().getIban().getIbanISOCountryCode().equalsIgnoreCase(accountPrefix))){
                log.info(logMessage.descr("Iban validation is not needed as it is Optional and user has provided normal account number"));
                ibanCountryRulesResponse.setValidated(true);
            }
            //For Iban countries those which do not require Iban as mandate, setting the flag true to proceed with bene creation
            else if(ibanCountryRulesResponse.getData().getBeneficiaryBankInfo()!=null &&
                    ibanCountryRulesResponse.getData().getBeneficiaryBankInfo().getLocalRoutingCodeRequired()!=null &&
                    ibanCountryRulesResponse.getData().getBeneficiaryBankInfo().getLocalRoutingCodeRequired().equalsIgnoreCase(MANDATORY) && ibanCountryRulesResponse.getData().getBeneficaryAccount().getIbanRequired().equalsIgnoreCase(NOT_APPLICABLE)){
                // no action, it is already invalid by default
            }
            else if(ibanCountryRulesResponse.getData().getBeneficaryAccount().getIbanRequired().equalsIgnoreCase(NOT_APPLICABLE)){
                log.info(logMessage.descr("Iban validation is not applicable based on country rules"));
                ibanCountryRulesResponse.setValidated(true);
            }
        }
        log.info(logMessage.summary().descr("Iban country rules fetch and validation is completed"));
        return ibanCountryRulesResponse;
    }

    private void validateIbanAndSetTrueIfSuccess(EntityWrapper entityWrapper, String ecClientId, IbanCountryRulesResponse ibanCountryRulesResponse) {
        IbanValidationResponse ibanValidationResponse = validateIBAN(entityWrapper, ecClientId);
        if(ibanValidationResponse.isValidated()){
            ibanCountryRulesResponse.setValidated(true);
        }
    }

    public IbanValidationResponse validateIBAN(EntityWrapper entityWrapper, String ecClientId){

        IbanValidationRequest ibanValidationRequest = new IbanValidationRequest();
        ibanValidationRequest.setIbanToValidate(entityWrapper.getEntity().getBENEFICIARY_ACCOUNT());

        Message logMessage = Message.create().entityName(Message.Entity.beneficiary).jobId(entityWrapper.getEntity().getJOB_ID()).clientId(ecClientId).accountNumber(entityWrapper.getEntity().getBENEFICIARY_ACCOUNT()).url(ibanValidationUrl).operation("Iban Number validation");

        ResponseEntity<IbanValidationResponse> ibanValidationResponseEntity = null;
        IbanValidationResponse ibanValidationResponse = new IbanValidationResponse();


        HttpHeaders headers = new HttpHeaders();
        headers.add(MigrationConstants.CONTENT_TYPE, MigrationConstants.APPLICATION_HEADER_JSON);
        headers.add(MigrationConstants.HEADER_SERVICE_TOKEN, token);
        HttpEntity<?> requestEntity = new HttpEntity<>(ibanValidationRequest, headers);

        log.info(logMessage.descr("Iban validation call"));
        try{
            ibanValidationResponseEntity = retryService.exchange(ibanValidationUrl, HttpMethod.POST, requestEntity, new ParameterizedTypeReference<IbanValidationResponse>(){});
        }
        catch(RestClientException e){
            log.error(logMessage.descr("Iban validation call "+e.getMessage()));
            entityWrapper.addUnexpectedError("Payment validation rules endpoint for IBAN country", e.getMessage());
        }
        if(ibanValidationResponseEntity!=null && ibanValidationResponseEntity.getBody() != null && HttpStatus.OK.equals(ibanValidationResponseEntity.getStatusCode())
                && null != ibanValidationResponseEntity.getBody().getData()){
            ibanValidationResponse.setData(ibanValidationResponseEntity.getBody().getData());
            String validationCode = ibanValidationResponse.getData().getResponseCode().getCode();
            log.info(logMessage.descr("validation response code :: " + validationCode + "-"+ibanValidationResponse.getData().getResponseCode().getDescription()));
            if((SUCCESSFULLY_VALIDATED_IBAN.equalsIgnoreCase(validationCode) || WARNING_VALIDATING_IBAN.equalsIgnoreCase(validationCode))
                    && isBicEqualToBeneBankId(entityWrapper, ibanValidationResponse)){
                ibanValidationResponse.setValidated(true);
            }
        }
        log.info(logMessage.summary().descr("Iban Number validation completed."));

        return ibanValidationResponse;
    }

    private boolean isBicEqualToBeneBankId(EntityWrapper entityWrapper, IbanValidationResponse ibanValidationResponse) {
        return ibanValidationResponse.getData().getInstitutionDetails().getSwiftBIC().length() >= SWIFT_MIN_LENGTH
                && entityWrapper.getEntity().getBENEFICIARY_BANK_IDENTIFIER().length() >= SWIFT_MIN_LENGTH
                && ibanValidationResponse.getData().getInstitutionDetails().getSwiftBIC().substring(0, SWIFT_MIN_LENGTH).equalsIgnoreCase(entityWrapper.getEntity().getBENEFICIARY_BANK_IDENTIFIER().substring(0, SWIFT_MIN_LENGTH));
    }

    ReachabilityCheckResponse reachabilityCheck(EntityWrapper entityWrapper, String gwClientId) {

        ResponseEntity<ReachabilityCheckResponseData> reachabilityCheckResponseEntity = null;
        Message logMessage = Message.create().entityName(Message.Entity.beneficiary).jobId(entityWrapper.getEntity().getJOB_ID()).clientId(entityWrapper.getEntity().getOLB_CLIENT_ID()).gwClientId(gwClientId).operation("Network reachability check");

        ReachabilityCheckResponse reachabilityCheckResponse = new ReachabilityCheckResponse();

        try{
            HttpHeaders headers = new HttpHeaders();
            headers.add(MigrationConstants.AUTHORIZATION_HEADER_NAME, cacheManagerUtility.getVTToken());
            headers.add(MigrationConstants.CONTENT_TYPE, MigrationConstants.APPLICATION_HEADER_JSON);

            HttpEntity<?> requestEntity = new HttpEntity<>(headers);
            String finalReachabilityUrl = reachabilityUrl+ gwClientId + MigrationConstants.FETCH_CLEARING_SYSTEM_DETAILS +entityWrapper.getEntity().getBENEFICIARY_BANK_IDENTIFIER();
            log.info(logMessage.descr("Network reachability for ABA :: "+entityWrapper.getEntity().getBENEFICIARY_BANK_IDENTIFIER()).url(finalReachabilityUrl));

            reachabilityCheckResponseEntity = /*don't retry for this call:*/restTemplate.exchange(finalReachabilityUrl, HttpMethod.GET, requestEntity, new ParameterizedTypeReference<ReachabilityCheckResponseData>(){});

        }
        catch (Exception exception){
            //treat all exceptions as validation error because of a bug in the called endpoint that always throws 500 errors even for validation issues
            log.warn(logMessage.summary().descr("Currently treating all exceptions to this Network reachability endpoint as a data validation error for incorrect routing number "+exception.getMessage()));
            entityWrapper.addValidationError(ERR1006, ROUTING_NUMBER_INCORRECT, ROUTING_NUMBER_FIELD);
            return reachabilityCheckResponse;
        }

        if(HttpStatus.OK.equals(reachabilityCheckResponseEntity.getStatusCode())) {
            reachabilityCheckResponse.setData(reachabilityCheckResponseEntity.getBody());
            if(!reachabilityCheckResponse.getData().getClearingSystemDetails().isEmpty()){
                log.info(logMessage.descr("Network reachability check is validated and clearing system is reachable"));
                reachabilityCheckResponse.setValidated(true);
            }
        }

        if(!reachabilityCheckResponse.isValidated()){
            log.info(logMessage.descr("Network reachability check is done and clearing system is NOT reachable"));
            entityWrapper.addValidationError(ERR1006, ROUTING_NUMBER_INCORRECT, ROUTING_NUMBER_FIELD);
        }
        log.info(logMessage.summary().descr("Network reachability check completed"));
        return reachabilityCheckResponse;
    }


    private void handleRestException( RestClientResponseException restClientResponseException,EntityWrapper entityWrapper, Message logMessage, String errorSource) {
        assert restClientResponseException != null;
        logMessage.errorSource(errorSource);
        if (null == restClientResponseException.getResponseHeaders() || restClientResponseException.getResponseHeaders().getValuesAsList(CHANNEL_CONTEXT).isEmpty()) {
            entityWrapper.addUnexpectedError(errorSource, restClientResponseException.getMessage());
            log.error(logMessage.summary().descr(errorSource + restClientResponseException.getMessage()));
        } else {
            try {
                String dataJson = objectMapper.writeValueAsString(restClientResponseException.getResponseHeaders().getValuesAsList(CHANNEL_CONTEXT));
                log.warn(logMessage.descr("Och Channel Context message :: "+dataJson));
                if(dataJson!=null && dataJson.contains(VALIDATION_ERROR_CODE)){
                    dataJson=dataJson.replace("\\\\", "");
                    dataJson=dataJson.replace("\"", "");
                    log.warn(logMessage.descr("Matched with Bank details donot exist message - Och Channel Context message :: "+dataJson));
                } else{
                    log.error(logMessage.summary().descr(errorSource + restClientResponseException.getMessage()));
                    entityWrapper.addUnexpectedError(errorSource, restClientResponseException.getMessage());
                }
            } catch (JsonProcessingException e) {
                log.error(logMessage.descr(e.getMessage()));
                entityWrapper.addUnexpectedError(errorSource, restClientResponseException.getMessage());
            }
        }
    }

}
