package com.svb.gateway.migration.beneficiaries.service;

import com.svb.gateway.migration.beneficiaries.entity.MigBeneficiary;
import com.svb.gateway.migration.beneficiaries.entity.StgToTargetBeneEntity;
import com.svb.gateway.migration.beneficiaries.mapper.MigBeneficiaryMapper;
import com.svb.gateway.migration.beneficiaries.mapper.SelectConditions;
import com.svb.gateway.migration.beneficiaries.model.*;
import com.svb.gateway.migration.beneficiaries.repository.BeneficiaryRepository;
import com.svb.gateway.migration.beneficiaries.repository.MigBeneficiaryRepository;
import com.svb.gateway.migration.client.entity.MigClient;
import com.svb.gateway.migration.common.exception.ServiceException;
import com.svb.gateway.migration.common.exception.SkipAheadServiceException;
import com.svb.gateway.migration.common.logging.Message;
import com.svb.gateway.migration.common.model.AddressResponse;
import com.svb.gateway.migration.common.service.RetryService;
import com.svb.gateway.migration.common.utility.AddressDoctor;
import com.svb.gateway.migration.common.utility.CacheManagerUtility;
import lombok.extern.log4j.Log4j2;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

import static com.svb.gateway.migration.beneficiaries.entity.StgToTargetBeneEntity.PAYEE_TYPE.*;
import static com.svb.gateway.migration.beneficiaries.model.ValidationError.ERR1002;
import static com.svb.gateway.migration.beneficiaries.model.ValidationError.FIELD_LENGTH_EXCEEDED;
import static com.svb.gateway.migration.common.utility.LengthValidationEnum.*;

@Log4j2
@Service
public class CheckPayeeManager extends BeneficiaryBaseManager  {
    private static final String BENE_SOURCE_TYPE_IPAY_CHK = "IPAY Check";
    private static final String PAYMENT_METHOD_CHK = "CHK";

    public CheckPayeeManager(MigBeneficiaryMapper migBeneficiaryMapper, MigBeneficiaryRepository migBeneficiaryRepository, BeneficiaryRepository beneficiaryRepository, CacheManagerUtility cacheManagerUtility, BeneficiaryValidationUtility beneficiaryValidationUtility, AddressDoctor addressDoctor, RetryService retryService) {
        super(migBeneficiaryMapper, migBeneficiaryRepository, beneficiaryRepository, cacheManagerUtility, beneficiaryValidationUtility, addressDoctor, retryService);
    }

    @Override
    protected StgToTargetBeneEntity.PAYEE_TYPE payeeType(){return CHECK;}

    @Override
    protected BeneficiaryAddress getAddress(EntityWrapper entityWrapper, MigClient migClient, BankBranchResponse bankBranchResponse, AccountDetails accountDetails, Long jobId) {
        Message getAddressMessage = Message.create().jobId(migClient.getJobId()).clientId(migClient.getEcClientId()).gwClientId(migClient.getGwClientId()).entityName(Message.Entity.beneficiary).payeeType(payeeType()).operation("Validating address for IPAY Check Payee");
        BeneficiaryAddress beneficiaryAddress = new BeneficiaryAddress();
        String completeAddr = getCompleteAddr(entityWrapper.getEntity());
        AddressResponse addressResponse = addressDoctor.validateAddress(DEFAULT_COUNTRY_CODE,completeAddr, entityWrapper);
        validateAddressResponseAndSetAddressInRequest(beneficiaryAddress, addressResponse, entityWrapper);
        beneficiaryAddress.setCountry(DEFAULT_COUNTRY_CODE);
        addressFieldLengthCheck(addressResponse,entityWrapper,getAddressMessage);
        return beneficiaryAddress;
    }

    @Override
    public List<PaymentDetail> getPaymentDetails(EntityWrapper entityWrapper, MigClient migClient, AccountDetails accountDetails, BankDetails bankDetails) {
        PaymentDetail paymentDetail = new PaymentDetail();
        paymentDetail.setRequestType(REQUEST_TYPE);
        paymentDetail.setPreferredFlag(PREFERRED_FLAG);
        paymentDetail.setPaymentMethod(PAYMENT_METHOD_CHK);
        paymentDetail.setCustomerAccountNumber(entityWrapper.getEntity().getBENEFICIARY_ACCOUNT());
        List<PaymentDetail> paymentDetails = new ArrayList<>();
        paymentDetails.add(paymentDetail);
        return paymentDetails;
    }

    /**
     * This method intentionally returns null because we do not validate the bank branch for checks.
     * @param entityWrapper not used
     * @return null
     */
    @Override
    public BankBranchResponse validateBankBranch(EntityWrapper entityWrapper, AccountDetails a, MigClient m) {
        // do not validate for Checks
        return null;
    }

    /**
     * This method intentionally does not do anything because we do not set bank details for checks.
     * @param entityWrapper not used
     * @param bankBranchResponse not used
     */
    @Override
    BankDetails setBankDetails(EntityWrapper entityWrapper, BankBranchResponse bankBranchResponse){return null;}


    @Override
    public String getNickName(StgToTargetBeneEntity entity) {
        return entity.getBENEFICIARY_NICKNAME();
    }

    @Override
    public boolean hasPayeePhoneNumber() { return true; }

    @Override
    protected void setBeneSourceIdAndTypeForEntityLogging(MigBeneficiary migBeneficiary, StgToTargetBeneEntity stgBeneficiary) {
        migBeneficiary.setBeneSourceId(stgBeneficiary.getIPAYEE_BENE_ID().toString());
        migBeneficiary.setBeneSourceType(BENE_SOURCE_TYPE_IPAY_CHK);
    }

    @Override
    public void setBeneSourceIdInResponse(ResultRecords resultRecords, EntityWrapper entityWrapper) {
        resultRecords.setIPayBeneId(entityWrapper.getEntity().getSourceBeneId(CHECK));
    }

    @Override
    protected void setPaymentMethodAndIsPersonalAccount(PaymentDetail paymentDetail){
        // Default is Wire
        paymentDetail.setPaymentMethod(PAYMENT_METHOD_CHK);
    }

    @Override
    public EntityWrapper fetchListIfAlreadyMigratedBene(EntityWrapper entityWrapper, ProcessingContext processingContext) {
        entityWrapper.migratedRecords = migBeneficiaryRepository.findByIpayBeneIDMigratedOrIgnored(processingContext.getJobId(), entityWrapper.getEntity().getSourceBeneId(CHECK));
        log.info(Message.create().descr("No of records that are already migrated or ignored in previous runs if any : "+entityWrapper.migratedRecords.size()).jobId(processingContext.getJobId()).clientId(processingContext.migClient.getEcClientId()).gwClientId(processingContext.migClient.getGwClientId()).entityName(Message.Entity.beneficiary));
        return entityWrapper;
    }

    @Override
    public List<StgToTargetBeneEntity> getDataFromStaging(MigClient migClient, StgToTargetBeneEntity.PAYEE_TYPE type) throws ServiceException {
        Message logMessage = Message.create().jobId(migClient.getJobId()).entityName(Message.Entity.beneficiary).clientId(migClient.getEcClientId()).gwClientId(migClient.getGwClientId()).operation("Get the records from staging table based on bene type").payeeType(payeeType());
        List<StgToTargetBeneEntity> stgToTargetBeneEntities = beneficiaryMapper.findByOlbClientIdIpayPayees(new SelectConditions(migClient.getEcClientId(), "N", false));
        if (stgToTargetBeneEntities == null || stgToTargetBeneEntities.isEmpty()) {
            log.info(logMessage.descr(NO_BENES_PRESENT_FOR_PROVIDED_CLIENT_ID).payeeType(CHECK));
            throw new SkipAheadServiceException(NO_BENES_PRESENT_FOR_PROVIDED_CLIENT_ID, NO_BENES_PRESENT_FOR_PROVIDED_CLIENT_ID);
        }
        log.info(logMessage.summary().descr("No of records fetched from staging for the given client id is : "+stgToTargetBeneEntities.size()));
        return stgToTargetBeneEntities;
    }

    @Override
    public void accountAndRoutingNumberCheck(EntityWrapper entityWrapper, BankDetails bankDetails, AccountDetails accountDetails) {
        String customerAccountNumber=entityWrapper.getGatewayMigrationRequest().getPaymentDetails()!=null?entityWrapper.getGatewayMigrationRequest().getPaymentDetails().get(0).getCustomerAccountNumber():"";
        if(customerAccountNumber.length() > BENE_ACCOUNT_NUMBER_US.getLength()){
            entityWrapper.addValidationError(ERR1002, FIELD_LENGTH_EXCEEDED, BENE_ACCOUNT_NUMBER_US.getField());
        }
    }
}
