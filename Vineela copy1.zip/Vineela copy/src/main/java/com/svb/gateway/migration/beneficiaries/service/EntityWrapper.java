package com.svb.gateway.migration.beneficiaries.service;

import com.svb.gateway.migration.beneficiaries.entity.MigBeneficiary;
import com.svb.gateway.migration.beneficiaries.entity.StgToTargetBeneEntity;
import com.svb.gateway.migration.beneficiaries.model.AddBeneficiaryRequest;
import com.svb.gateway.migration.beneficiaries.model.AddBeneficiaryResponse;
import com.svb.gateway.migration.beneficiaries.model.ErrorQueueResponse;
import com.svb.gateway.migration.beneficiaries.model.ValidationError;
import com.svb.gateway.migration.common.model.Error;
import lombok.Getter;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;


/**
 * EntityWrapper keeps track of the current entity being processed
 */
@Setter
@Getter
public class EntityWrapper {
    public EntityWrapper(StgToTargetBeneEntity entity) {
        this.entity = entity;
    }
    String status;
    StgToTargetBeneEntity entity;
    AddBeneficiaryRequest gatewayMigrationRequest;
    AddBeneficiaryResponse gatewayMigrationResponse;
    List<ValidationError> validationErrorList = new ArrayList<>();
    List<Error> unexpectedErrorList = new ArrayList<>();
    List<MigBeneficiary> migratedRecords=new ArrayList<>();
    ErrorQueueResponse errorQueueResponse;

    public void addValidationError(String errorCode, String description, String dataField){
        validationErrorList.add(new ValidationError(errorCode, description, dataField));
    }

    public boolean hasValidationErrors(){
        return ! validationErrorList.isEmpty();
    }

    public void addUnexpectedError(String errorSource, String errorMessage){
        String sourcePrefix = "";
        if(errorSource!=null && !errorSource.isEmpty()){
            sourcePrefix = errorSource + " ";
        }
        unexpectedErrorList.add(new Error("", sourcePrefix + errorMessage));
    }

    public boolean hasUnexpectedErrors(){
        return ! unexpectedErrorList.isEmpty();
    }

    public String getFirstUnexpectedErrorMessage(){
        if(hasUnexpectedErrors()){
            return unexpectedErrorList.get(0).getDescription();
        }
        else return "";
    }

    public boolean isAlreadySentToGateway(){
        return ! migratedRecords.isEmpty();
    }

    public boolean hasMigrationResponse(){
        return gatewayMigrationResponse !=null && gatewayMigrationResponse.getData() != null;
    }

    public boolean hasErrorApiResponse(){
        return errorQueueResponse!=null;
    }
}