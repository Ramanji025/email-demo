package com.svb.gateway.migration.beneficiaries.service;

import com.svb.gateway.migration.beneficiaries.entity.StgToTargetBeneEntity;
import com.svb.gateway.migration.client.entity.MigClient;
import com.svb.gateway.migration.user.entity.MigUser;
import lombok.Getter;
import lombok.Setter;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * ProcessingContext is a request context keeping track of the overall results
 */
@Getter @Setter
public class ProcessingContext{

    public ProcessingContext(Long jobId, IBeneficiaryManager beneManager, String serviceUrl, MigClient migClient, MigUser primaryUserMigrated,  StgToTargetBeneEntity.PAYEE_TYPE payeeType) {
        this.jobId = jobId;
        this.beneManager = beneManager;
        this.serviceUrl = serviceUrl;
        this.migClient = migClient;
        this.primaryUserMigrated = primaryUserMigrated;
        this.payeeType = payeeType;
    }

    Long jobId;
    final long startTime=System.currentTimeMillis();
    AtomicInteger cntSuccess=new AtomicInteger(0);
    AtomicInteger cntFailure=new AtomicInteger(0);
    AtomicInteger cntAlready=new AtomicInteger(0);
    Map<Integer, StgToTargetBeneEntity> uniqNonMigBene = new HashMap<>();
    String serviceUrl;
    MigClient migClient;
    MigUser primaryUserMigrated;
    StgToTargetBeneEntity.PAYEE_TYPE payeeType;
    IBeneficiaryManager beneManager;
    String message;


    @Override
    public String toString() {
        return "ProcessingContext{" +
                "startTime=" + startTime +
                ", cntSuccess=" + cntSuccess +
                ", cntFailure=" + cntFailure +
                ", cntAlready=" + cntAlready +
                ", uniqNonMigBene size=" + uniqNonMigBene.size() +
                ", serviceUrl='" + serviceUrl + '\'' +
                ", migClient=" + migClient +
                ", primaryUserMigrated=" + primaryUserMigrated +
                ", payeeType=" + payeeType +
                ", beneManager=" + beneManager +
                '}';
    }
}