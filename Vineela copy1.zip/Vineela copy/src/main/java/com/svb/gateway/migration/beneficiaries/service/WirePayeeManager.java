package com.svb.gateway.migration.beneficiaries.service;

import com.svb.gateway.migration.beneficiaries.entity.MigBeneficiary;
import com.svb.gateway.migration.beneficiaries.entity.StgToTargetBeneEntity;
import com.svb.gateway.migration.beneficiaries.mapper.MigBeneficiaryMapper;
import com.svb.gateway.migration.beneficiaries.model.ResultRecords;
import com.svb.gateway.migration.beneficiaries.repository.BeneficiaryRepository;
import com.svb.gateway.migration.beneficiaries.repository.MigBeneficiaryRepository;
import com.svb.gateway.migration.client.entity.MigClient;
import com.svb.gateway.migration.common.exception.ServiceException;
import com.svb.gateway.migration.common.exception.SkipAheadServiceException;
import com.svb.gateway.migration.common.logging.Message;
import com.svb.gateway.migration.common.service.RetryService;
import com.svb.gateway.migration.common.utility.AddressDoctor;
import com.svb.gateway.migration.common.utility.CacheManagerUtility;
import lombok.extern.log4j.Log4j2;
import org.springframework.stereotype.Service;

import java.util.List;

import static com.svb.gateway.migration.beneficiaries.entity.StgToTargetBeneEntity.PAYEE_TYPE.*;
@Log4j2
@Service
public class WirePayeeManager extends BeneficiaryBaseManager {
    private static final String BENE_SOURCE_TYPE_WIRE = "eConnectWire";

    StgToTargetBeneEntity.PAYEE_TYPE type;

    public WirePayeeManager(MigBeneficiaryMapper migBeneficiaryMapper, MigBeneficiaryRepository migBeneficiaryRepository, BeneficiaryRepository beneficiaryRepository, CacheManagerUtility cacheManagerUtility, BeneficiaryValidationUtility beneficiaryValidationUtility, AddressDoctor addressDoctor, RetryService retryService) {
        super(migBeneficiaryMapper, migBeneficiaryRepository, beneficiaryRepository, cacheManagerUtility, beneficiaryValidationUtility, addressDoctor, retryService);
    }

    @Override
    protected void setBeneSourceIdAndTypeForEntityLogging(MigBeneficiary migBeneficiary, StgToTargetBeneEntity stgBeneficiary){
        migBeneficiary.setBeneSourceId(stgBeneficiary.getWIRE_TRANSACTION_ID().toString());
        migBeneficiary.setBeneSourceType(BENE_SOURCE_TYPE_WIRE);
    }

    @Override
    protected StgToTargetBeneEntity.PAYEE_TYPE payeeType(){return type;}

    @Override
    public String getNickName(StgToTargetBeneEntity entity) {
        return "";
    }

    @Override
    public boolean hasPayeePhoneNumber() { return false; }

    @Override
    public void setBeneSourceIdInResponse(ResultRecords resultRecords, EntityWrapper entityWrapper) {
        resultRecords.setWireTxnId(entityWrapper.getEntity().getSourceBeneId(PAST));//PAST same sourceid as FUTURE
    }

    @Override
    public EntityWrapper fetchListIfAlreadyMigratedBene(EntityWrapper entityWrapper, ProcessingContext processingContext) {
        entityWrapper.migratedRecords = migBeneficiaryRepository.findByWireTxnIdMigratedOrIgnored(processingContext.getJobId(), entityWrapper.getEntity().getSourceBeneId(PAST));//PAST same sourceid as FUTURE
        log.info(Message.create().descr("No of records that are already migrated or ignored in previous runs if any : "+entityWrapper.migratedRecords.size()).jobId(processingContext.getJobId()).clientId(processingContext.migClient.getEcClientId()).gwClientId(processingContext.migClient.getGwClientId()).entityName(Message.Entity.beneficiary));
        return entityWrapper;
    }

    @Override
    public List<StgToTargetBeneEntity> getDataFromStaging(MigClient migClient, StgToTargetBeneEntity.PAYEE_TYPE type) throws ServiceException{
        Message logMessage = Message.create().jobId(migClient.getJobId()).entityName(Message.Entity.beneficiary).clientId(migClient.getEcClientId()).gwClientId(migClient.getGwClientId()).operation("Get the records from staging table based on bene type").payeeType(payeeType());
        List<StgToTargetBeneEntity> stgToTargetBeneEntities=null;
        if(type==PAST){
            stgToTargetBeneEntities = beneficiaryMapper.findByOlbClientIdPastFreeForm(migClient.getEcClientId());
        }
        else if(type==FUTURE){
            stgToTargetBeneEntities = beneficiaryMapper.findByOlbClientIdFutureFreeForm(migClient.getEcClientId());
        }
        else{
           //do nothing
        }
        if (stgToTargetBeneEntities == null || stgToTargetBeneEntities.isEmpty()) {
            log.info(logMessage.descr(NO_BENES_PRESENT_FOR_PROVIDED_CLIENT_ID));
            throw new SkipAheadServiceException(NO_BENES_CODE, NO_BENES_PRESENT_FOR_PROVIDED_CLIENT_ID);
        }
        log.info(logMessage.summary().descr("No of records fetched from staging for the given client id is : "+stgToTargetBeneEntities.size()));
        return stgToTargetBeneEntities;
    }

}
