package com.svb.gateway.migration.cards.api;

import com.svb.gateway.migration.client.model.ClientInfo;
import com.svb.gateway.migration.common.constants.ErrorMessageConstants;
import com.svb.gateway.migration.common.constants.RegexConstants;
import com.svb.gateway.migration.common.exception.ServiceException;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Pattern;

/**
 * @author bmourya
 */
public interface CardsApi {

    /**
     * Enroll cardService program
     *
     * @param
     * @return
     */
    @ApiOperation(value = "Add card programs", nickname = "Create Card programs for client", notes = "", tags = {"Cards"})
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "OK", response = ClientInfo.class),
            @ApiResponse(code = 403, message = "Forbidden"),
            @ApiResponse(code = 400, message = "Bad Request"),
            @ApiResponse(code = 500, message = "Internal server error"),
            @ApiResponse(code = 401, message = "Unauthorized Request. Invalid Token")})
    @PostMapping(path = "/v1/bankusers/clients/cardPrograms/{jobId}/{clientId}", produces = {"application/json"})
    @ResponseStatus(HttpStatus.OK)
    @PreAuthorize("hasAuthority(@migrationServiceConfig.getAuthExecute())")
    default ResponseEntity<Object> addCardProgram(@PathVariable Long jobId,
                                                  @Valid
                                                  @PathVariable
                                                  @NotEmpty
                                                  @Pattern(regexp = RegexConstants.EC_CLIENT_ID_PATTERN,
                                                           message = ErrorMessageConstants.INVALID_CLIENT_ID_MESSAGE) String clientId) throws ServiceException {

        return new ResponseEntity<>(HttpStatus.NOT_IMPLEMENTED);
    }
}
