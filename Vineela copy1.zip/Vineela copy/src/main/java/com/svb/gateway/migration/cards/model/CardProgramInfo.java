package com.svb.gateway.migration.cards.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

/**
 * @author bmourya
 *
 */

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "billingType",
        "cif",
        "custLineNumber",
        "programId",
        "programName",
        "programType",
        "status"
})
public class CardProgramInfo {

    @JsonProperty("billingType")
    private String billingType;
    @JsonProperty("cif")
    private String cif;
    @JsonProperty("custLineNumber")
    private String custLineNumber;
    @JsonProperty("programId")
    private String programId;
    @JsonProperty("programName")
    private String programName;
    @JsonProperty("programType")
    private String programType;
    @JsonProperty("status")
    private String status;

    public String getBillingType() {
        return billingType;
    }

    public void setBillingType(String billingType) {
        this.billingType = billingType;
    }

    public String getCif() {
        return cif;
    }

    public void setCif(String cif) {
        this.cif = cif;
    }

    public String getCustLineNumber() {
        return custLineNumber;
    }

    public void setCustLineNumber(String custLineNumber) {
        this.custLineNumber = custLineNumber;
    }

    public String getProgramId() {
        return programId;
    }

    public void setProgramId(String programId) {
        this.programId = programId;
    }

    public String getProgramName() {
        return programName;
    }

    public void setProgramName(String programName) {
        this.programName = programName;
    }

    public String getProgramType() {
        return programType;
    }

    public void setProgramType(String programType) {
        this.programType = programType;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
