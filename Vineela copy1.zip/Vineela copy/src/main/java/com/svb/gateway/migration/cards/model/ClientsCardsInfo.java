package com.svb.gateway.migration.cards.model;

import java.util.List;

/**
 * @author bmourya
 */

public class ClientsCardsInfo {

    private List<CardProgramInfo> cardProgramDetails;

    public List<CardProgramInfo> getCardProgramDetails() {
        return cardProgramDetails;
    }

    public void setCardProgramDetails(List<CardProgramInfo> cardProgramDetails) {
        this.cardProgramDetails = cardProgramDetails;
    }

}
