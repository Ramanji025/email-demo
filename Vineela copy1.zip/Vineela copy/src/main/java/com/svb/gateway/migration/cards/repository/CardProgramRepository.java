package com.svb.gateway.migration.cards.repository;

import com.svb.gateway.migration.cards.entity.MigStgCardProgram;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * @author bmourya
 *
 */

@Repository
public interface CardProgramRepository extends JpaRepository<MigStgCardProgram, String> {

    @Query(value = "select * from MIG_STG_CARD_PROGRAM where  JOB_ID = ?1 AND OLB_CLIENT_ID = ?2 ",nativeQuery=true)
    List<MigStgCardProgram> findByOlbId(Long jobId, String olbId);

}
