package com.svb.gateway.migration.cards.repository;

import com.svb.gateway.migration.cards.entity.MigCardProgram;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * @author bmourya
 *
 */

@Repository
public interface MigCardProgramRepository extends JpaRepository<MigCardProgram, String> {

    @Query(value = "select * from MIG_CARD_PROGRAM where OLB_CLIENT_ID = ?1 ",nativeQuery=true)
    List<MigCardProgram> findByOlbId(String olbId);

    @Query(value = "select * from MIG_CARD_PROGRAM where upper(OLB_CLIENT_ID) = ?1 and PROGRAM_ID = ?2 and JOBID = ?3 and STATUS = ?4",nativeQuery=true)
    MigCardProgram findByOlbIdAndCardProgram(String olbId, String programId, String jobId, String status);

    List<MigCardProgram> findAllByEcClientIdAndStatus(String ecClientId, String status);

    @Query(value = "select * from MIG_CARD_PROGRAM  where EC_CLIENT_ID=?1 and JOBID = ?2 and status in ?3", nativeQuery = true)
    List<MigCardProgram> findByEcClientIdAndJobIdAndStatus(String ecClientId, Long jobId, List<String> status);

    @Query(value = "select * from MIG_CARD_PROGRAM where OLB_CLIENT_ID = ?1 and PROGRAM_ID = ?2 and JOBID = ?3",nativeQuery=true)
    MigCardProgram findByOlbIdAndCardProgramAndJobId(String olbId, String programId, Long jobId);

}
