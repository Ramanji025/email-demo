package com.svb.gateway.migration.cards.repository;

import com.svb.gateway.migration.client.entity.StgClient;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface MigStgClientRepository extends JpaRepository<StgClient, String> {

    @Query(value = "select * from MIG_STG_CLIENT where JOB_ID = ?1 and OLB_CLIENT_ID = ?2 ",nativeQuery=true)
    StgClient findByOlbClientId(Long jobId, String ecClientId);
}
