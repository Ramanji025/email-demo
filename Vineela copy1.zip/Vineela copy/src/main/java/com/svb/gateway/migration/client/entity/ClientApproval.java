package com.svb.gateway.migration.client.entity;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
@Getter
@Setter
@Entity
@Table(name = "MIG_INT_CLIENT_APPROVAL_SETTING")
public class ClientApproval {

    @GeneratedValue(strategy=GenerationType.IDENTITY)
    @Id
    @Column(name = "ID")
    private Integer id;


    @Column(name = "EC_CLIENT_ID")
    private String ecClientId;

    @Column(name = "JOB_ID")
    private Long jobId;

    @Column(name = "WIRE_APPROVER_REQUIRED")
    private Integer wireApprReqd;

    @Column(name = "TMPL_WIRE_APPROVER_REQUIRED")
    private Integer tmplWireApprReqd;

    @Column(name = "TEMPLATE_APPROVER_REQUIRED")
    private Integer tmplApprReqd;

    @Column(name = "IPAY_APPROVER_REQUIRED")
    private Integer ipayApprReqd;

}