package com.svb.gateway.migration.client.entity;

import com.svb.gateway.migration.common.processors.IRetry;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.util.Date;

import static com.svb.gateway.migration.common.constants.UserConstants.NO;
import static com.svb.gateway.migration.common.constants.UserConstants.YES;

@Setter
@Getter
@Entity
@Table(name = "MIG_CLIENT")
public class MigClient implements IRetry {

    @GeneratedValue(strategy=GenerationType.IDENTITY)
    @Id
    @Column(name = "MIGCLIENTID")
    private Integer migratingClientId;

    @Column(name = "JOBID")
    private Long jobId;

    @Column(name = "ECCLIENTID")
    private String ecClientId;

    @Column(name = "GWCLIENTID")
    private String gwClientId;

    @Column(name = "CLIENTNAME")
    private String clientName;

    @Column(name = "COMPANYID")
    private String companyId;

    @Column(name = "PRIMARYCIFUBS")
    private Integer primaryCifUbs;

    @Column(name = "PRIMARYCIFCBS")
    private Long primaryCifCbs;

    @Column(name = "COMMENTS")
    private String comments;

    @Column(name = "STATUS")
    private String status;

    @Column(name = "UPDATEDBY")
    private String updatedBy;

    @Column(name = "UPDATEDDATE")
    private Date updateDate;

    @Column(name = "BDCSTATUS")
    private Integer bdcStatus;

    @Column(name = "RDMSTATUS")
    private Integer rdmStatus;

    @Column(name = "FINAL_GW_CLIENT_APPROVAL")
    private Integer finalGwClientAppr;

    @Column(name= "EC_CLIENT_ID_NUM")
    private String ecClientIdNum;

    public String bdcStatusAsString(){
        return determineStatusString(bdcStatus);
    }

    public String rdmStatusAsString(){
       return determineStatusString(rdmStatus);
    }

    public static String determineStatusString(Integer status){
        if(status==null || 0==status){
            return NO;
        }else{
            return YES;
        }
    }

}
