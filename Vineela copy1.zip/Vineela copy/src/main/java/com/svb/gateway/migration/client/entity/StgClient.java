package com.svb.gateway.migration.client.entity;


import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.time.LocalDate;

@ToString
@Entity
@Setter
@Getter
@Table(name = "MIG_STG_CLIENT")
public class StgClient {

    @Id
    @Column(name = "OLB_CLIENT_ID")
    private String olbClinetId;

    @Column(name = "PRIMARY_CIF_CBS")
    private String primaryCifCbs;

    @Column(name = "PRIMARY_CIF_UBS")
    private String primaryCifUbs;

    @Column(name = "CLIENT_NAME")
    private String clientName;

    @Column(name = "CLIENT_TYPE_ID")
    private String clientTypeId;

    @Column(name = "STATUS_FLG")
    private String statusFalg;

    @Column(name = "DUAL_ADMIN_APPROVE")
    private String dualAdminApprove;

   // @Column(name= "MIGRATED_CLIENT")
   // private String migratedClinet;

    @Column(name = "STATUS")
    private String status;

    @Column(name = "JOB_ID")
    private String jobId;

    @Column(name = "REMARKS")
    private String remarks;

    @Column(name = "CREATED_BY")
    private String createdBy;

    @Column(name = "CREATED_DT")
    private LocalDate createdDt;

    @Column(name= "EC_CLIENT_ID_NUM")
    private String ecClientIdNum;

    public String getUsBillAccNum() {
        return usBillAccNum;
    }

    public void setUsBillAccNum(String usBillAccNum) {
        this.usBillAccNum = usBillAccNum;
    }

    @Column(name = "US_BILL_ACC_NUM")
    private String usBillAccNum;

    @Column(name = "EC_CLIENT_CREATED_DATE")
    private LocalDate ecClientCreatedDate;
}
