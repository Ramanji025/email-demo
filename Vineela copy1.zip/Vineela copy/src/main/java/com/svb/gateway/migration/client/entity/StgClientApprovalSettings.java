package com.svb.gateway.migration.client.entity;


import lombok.Getter;
import lombok.Setter;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.time.LocalDate;

@Getter
@Setter
@Entity
@Table(schema = "GWDMG", name = "MIG_STG_CLIENT_ACCOUNT_APPROVAL_SETTING")
public class StgClientApprovalSettings {

    @Id
    @Column(name = "ACCOUNT_NUMBER")
    private String accountNumber;

    @Column(name = "JOB_ID")
    private String jobId;

    @Column(name = "EC_CLIENT_ID")
    private String ecClientId;

    @Column(name = "WIRE_APPROVE_LVL1_REQUIRED")
    private Integer wireApproveLvl1Required;

    @Column(name = "WIRE_APPROVE_LVL2_REQUIRED")
    private Integer wireApproveLvl2Required;

    @Column(name = "TMPL_WIRE_APPROVE1_REQUIRED")
    private Integer tmplWireApprove1Required;

    @Column(name = "TMPL_WIRE_APPROVE2_REQUIRED")
    private Integer tmplWireApprove2Required;

    @Column(name = "TEMPLATE_APPROVE_LVL1_REQUIRED")
    private Integer templateApproveLvl1Required;

    @Column(name = "TEMPLATE_APPROVE_LVL2_REQUIRED")
    private Integer templateApproveLvl2Required;

    @Column(name = "IPAY_DUAL_AUTHENTICATION")
    private String ipayDualAuthentication;

    @Column(name = "IPAY_APPROVAL_REQUIRED")
    private String ipayApprovalRequired;

    @Column(name = "REMARKS")
    private String remarks;

    @Column(name = "CREATED_BY")
    private String createdBy;

    @Column(name = "CREATED_DT")
    private LocalDate createdDt;

    @Column(name = "MODIFIED_DT")
    private LocalDate modifiedDt;
}
