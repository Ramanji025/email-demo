package com.svb.gateway.migration.client.mapper;

import com.svb.gateway.migration.client.model.Account;
import com.svb.gateway.migration.client.model.AccountServices;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import java.util.List;

@Mapper(componentModel="spring")
public interface AccountDetailsMapper {
    AccountDetailsMapper INSTANCE = Mappers.getMapper(AccountDetailsMapper.class);

    @Mapping(target = "accStatus", source = "accStat")
    @Mapping(target = "accType", source = "accountTyp")
    Account map(AccountServices source);
    List<Account> mapAccountDetails(List<AccountServices> source);
}
