package com.svb.gateway.migration.client.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    	"cbsCifNumber",
    	"ubsCifNumber",
    	"name",
    	"addressLine1",
    	"addressLine2",
    	"addressLine3",
    	"city",
    	"state",
    	"country",
    	"zip",
    	"phoneNumber",
    	"teamCode",
    	"dateOpened",
    	"clientId",
    	"cifAccounts",
        "cifNumber",
        "Primary",
        "accountDetails",
        "taxId"
})
@Getter
@Setter
public class Cif {

	@JsonProperty("cbsCifNum")
    private String cbsCifNum;
	@JsonProperty("ubsCifNum")
    private String ubsCifNum;
	@JsonProperty("name")
    private String name;
	@JsonProperty("addressLine1")
    private String addressLine1;
	@JsonProperty("addressLine2")
    private String addressLine2;
	@JsonProperty("addressLine3")
    private String addressLine3;
	@JsonProperty("city")
    private String city;
	@JsonProperty("state")
    private String state;
	@JsonProperty("country")
    private String country;
	@JsonProperty("zip")
    private String zip;
	@JsonProperty("phoneNumber")
    private String phoneNumber;
	@JsonProperty("teamCode")
    private String teamCode;
	@JsonProperty("teamName")
	private String teamName;
	@JsonProperty("teamCodeEmail")
	private String teamCodeEmail;
	@JsonProperty("dateOpened")
    private String dateOpened;
	@JsonProperty("clientId")
    private String clientId;
	@JsonProperty("cifAccounts")
    private List< AccountServices > cifAccounts;
    @JsonProperty("cifNumber")
    private String cifNumber;
    @JsonProperty("Primary")
    private String primary;
    @JsonProperty("accountDetails")
    private List< Account > accountDetails = null;
    @JsonProperty("taxId")
    private String taxId;

}
