
package com.svb.gateway.migration.client.model;

import java.util.List;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "sericeId",
    "serviceGroup",
    "serviceName",
    "accounts"
})
public class ClientService {

    @JsonProperty("serviceId")
    private String serviceId;
    @JsonProperty("serviceName")
    private String serviceName;
    @JsonProperty("serviceDisplayName")
    private String serviceDisplayName;
    @JsonProperty("serviceGroup")
    private String serviceGroup;
    @JsonProperty("accounts")
    private List<String> accounts = null;
    
    

    @JsonProperty("serviceId")
    public String getServiceId() {
        return serviceId;
    }

    @JsonProperty("serviceId")
    public void setServiceId(String serviceId) {
        this.serviceId = serviceId;
    }

    @JsonProperty("serviceName")
    public String getServiceName() {
        return serviceName;
    }

    @JsonProperty("serviceName")
    public void setServiceName(String serviceName) {
        this.serviceName = serviceName;
    }

    @JsonProperty("accounts")
    public List<String> getAccounts() {
        return accounts;
    }

    @JsonProperty("accounts")
    public void setAccounts(List<String> accounts) {
        this.accounts = accounts;
    }
    
    @JsonProperty("serviceDisplayName")
    public String getServiceDisplayName() {
		return serviceDisplayName;
	}

    @JsonProperty("serviceDisplayName")
	public void setServiceDisplayName(String serviceDisplayName) {
		this.serviceDisplayName = serviceDisplayName;
	}

    public String getServiceGroup() {
        return serviceGroup;
    }

    public void setServiceGroup(String serviceGroup) {
        this.serviceGroup = serviceGroup;
    }
}
