package com.svb.gateway.migration.client.repository;

import com.svb.gateway.migration.client.entity.StgClientApprovalSettings;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ClientApprovalRepository extends JpaRepository<StgClientApprovalSettings, String> {

    @Query(value = "select * from MIG_STG_CLIENT_ACCOUNT_APPROVAL_SETTING where JOB_ID= ?1 and EC_CLIENT_ID = ?2 ", nativeQuery = true)
    List<StgClientApprovalSettings> findByJobIdAndEcClientId(String jobId, String ecClientId);

}
