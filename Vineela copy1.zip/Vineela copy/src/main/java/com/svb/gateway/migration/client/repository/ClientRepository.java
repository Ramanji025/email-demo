package com.svb.gateway.migration.client.repository;

import com.svb.gateway.migration.client.entity.StgClient;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ClientRepository extends JpaRepository<StgClient, Integer> {

	StgClient findByOlbClinetId(String olbClinetId);

}
