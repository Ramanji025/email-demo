package com.svb.gateway.migration.client.repository;

import com.svb.gateway.migration.client.entity.ClientApproval;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface IntClientApprovalRepository extends JpaRepository<ClientApproval, Integer> {

    @Query(value = "select * from MIG_INT_CLIENT_APPROVAL_SETTING where JOB_ID= ?1 and EC_CLIENT_ID = ?2 ", nativeQuery = true)
    ClientApproval findClientApprovalByJobIdAndAndEcClientId(Long jobId, String ecClientId);

}
