package com.svb.gateway.migration.client.repository;

import com.svb.gateway.migration.client.entity.MigClient;
import com.svb.gateway.migration.user.model.CardUserMigrationData;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Set;

@Repository
public interface MigClientRepository extends JpaRepository<MigClient, String> {

    @Query(value = "select * from mig_client  where ecClientId = ?1 and lower(status)='success' ", nativeQuery = true)
    MigClient findByEcClientIdSuccess(String ecClintId);

    @Query(value = "select * from mig_client  where ecClientId = ?1 and JOBID=?2 and upper(status)=?3 ", nativeQuery = true)
    MigClient findByEcClientIdandJobIdStatus(String ecClintId, Long jobId, String status);

    @Query(value = "select * from mig_client  where ecClientId = ?1 and JOBID=?2 ", nativeQuery = true)
    MigClient findByEcClientIdAndJobId(String ecClintId, Long jobId);

    @Query(value = "select mc.ecclientid as ecClientId from mig_client mc where JOBID = ?1 and upper(status)=?2 and GWCLIENTID is not null", nativeQuery = true)
    List<String> findByJobIdAndStatus(Long jobId, String status);

    @Query(value = "select mc.ecclientid as ecClientId from mig_client mc where JOBID = ?1 and upper(status)=?2", nativeQuery = true)
    List<String> findByJobIdAndStatusFalse(Long jobId, String status);

    List<MigClient> findByJobId(Long jobId);

    List<MigClient> findByEcClientId(String ecClientId);

    MigClient findByGwClientId(String gwClientId);

    @Query(value = "SELECT * FROM mig_client WHERE ECCLIENTID= ?1 ORDER BY MIGCLIENTID DESC fetch first row only", nativeQuery = true)
    MigClient findByEcClientIdLatest(String ecClientId);

    @Query(value = "SELECT * FROM mig_client  WHERE GWCLIENTID = ?1 and lower(status) = lower(?2) ", nativeQuery = true)
    MigClient findByGwClientIdAndStatus(String gwClintId, String status);

    @Query(value = "select mc.ecclientid as ecClientId, mu.gwuuid as gwUid, mu.gwClientId as gwClientId," +
            " mu.ecUserLoginId as ecUserLoginId,  mcp.program_id AS programId, mu.jobid AS jobId from mig_user mu inner join mig_client mc" +
            " on mc.ecclientid = mu.ecclientid inner join mig_card_program   mcp ON mcp.olb_client_id = mc.gwclientid" +
            " where mu.status = 'SUCCESS' and mc.status= 'SUCCESS' AND mcp.status='SUCCESS'  AND mu.ecclientid = ?1 and  mu.jobid = ?2",nativeQuery = true)
    List<CardUserMigrationData> getClientsByClientIdAndJob(String ecClientId, Long jobId);

    @Query(value = " select mu.ec_client_id as ecClientId, mu.gw_uuid as gwUid, mu.gw_Client_Id as gwClientId," +
            "    mu.ec_user_login_id as ecUserLoginId,  mu.program_id AS programId, mu.jobid AS jobId" +
            "    from mig_card_user mu join mig_card_program mp on mp.ec_client_id = mu.ec_client_id where " +
            " mu.status ='SUCCESS' and mp.status='SUCCESS' and mu.ec_client_Id= ?1",nativeQuery = true )
    List<CardUserMigrationData> getCardUsersDataForMigrationRollback(String ecClientId);

    @Query(value = "select * from mig_client c where ecClientId = ?1 and lower(status)<> 'rollback'", nativeQuery = true)
    List<MigClient> findByEcClientIdStatusNotRollback(String ecClintId);

    boolean existsMigClientByEcClientId(String ecClientId);

    boolean existsMigClientByGwClientId(String gwClientId);

    @Query(value = "SELECT count(X) FROM MigClient X WHERE X.status <> ?2 AND X.ecClientId IN ?1")
    Long findClientEntities(Set<String> ecClientIds, String status);

    @Query(value = "SELECT X FROM MigClient X WHERE X.status <> ?2 AND X.ecClientId IN ?1")
    List<MigClient> findClientsNotRollback(Set<String> ecClientIds, String status);

    @Query("SELECT X FROM MigClient  X WHERE X.ecClientId IN (:ecClientId) and X.status='SUCCESS'")
    List<MigClient> getAllByEcClientIdInAndStatus(@Param("ecClientId") List<String> ecClientId);

    @Query("SELECT X FROM MigClient  X WHERE X.jobId = :jobId and X.status='SUCCESS'")
    List<MigClient> getAllByJobIdAndStatus(@Param("jobId") Long jobId);
}
