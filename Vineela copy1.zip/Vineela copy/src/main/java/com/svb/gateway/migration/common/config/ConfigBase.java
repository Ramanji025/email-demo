package com.svb.gateway.migration.common.config;

import com.svb.gateway.migration.common.exception.ExceptionSkipPolicy;
import com.svb.gateway.migration.common.listeners.MigrationSkipListener;
import com.svb.gateway.migration.common.listeners.MigrationStepListener;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;

public abstract class ConfigBase {

    @Autowired
    protected StepBuilderFactory stepBuilderFactory;

    @Autowired
    protected MigrationSkipListener migrationSkipListener;

    @Autowired
    protected ExceptionSkipPolicy exceptionSkipPolicy;

    @Autowired
    protected MigrationStepListener migrationStepListener;

    @Value("#{new Integer('${skipLimit}')}")
    protected Integer skipLimit;

    @Value("#{new Integer('${chunkSize}')}")
    protected Integer chunkSize;
}
