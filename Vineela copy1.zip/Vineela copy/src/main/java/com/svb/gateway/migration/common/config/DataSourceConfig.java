package com.svb.gateway.migration.common.config;

import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.core.env.Environment;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;

import javax.sql.DataSource;

@Configuration
public class DataSourceConfig {

    @Bean(name="migrationDataSource")
    @Primary
    DataSource migrationDataSource(Environment env) {
        HikariConfig migrationDataSourceConfig = new HikariConfig();

        migrationDataSourceConfig.setDriverClassName(env.getRequiredProperty("app.datasource.migration.driver-class-name"));
        migrationDataSourceConfig.setJdbcUrl(env.getRequiredProperty("app.datasource.migration.url"));
        migrationDataSourceConfig.setUsername(env.getRequiredProperty("app.datasource.migration.username"));
        migrationDataSourceConfig.setPassword(env.getRequiredProperty("app.datasource.migration.password"));

        return new HikariDataSource(migrationDataSourceConfig);
    }

    @Bean(name= "migrationJdbcTemplate")
    @Primary
    public JdbcTemplate migrationJdbcTemplate(@Qualifier("migrationDataSource") final DataSource migrationDataSource) {
        return new JdbcTemplate(migrationDataSource);
    }

    @Bean(name= "migrationNamedParameterJdbcTemplate")
    public NamedParameterJdbcTemplate migrationNamedParameterJdbcTemplate(@Qualifier("migrationDataSource") final DataSource migrationDataSource) {
        return new NamedParameterJdbcTemplate(migrationDataSource);
    }

    @Bean(name="eConnectDataSource")
    DataSource eConnectDataSource(Environment env) {
        HikariConfig eConnectDataSourceConfig = new HikariConfig();
        eConnectDataSourceConfig.setDriverClassName(env.getRequiredProperty("app.datasource.eConnect.driver-class-name"));
        eConnectDataSourceConfig.setJdbcUrl(env.getRequiredProperty("app.datasource.eConnect.url"));
        eConnectDataSourceConfig.setUsername(env.getRequiredProperty("app.datasource.eConnect.username"));
        eConnectDataSourceConfig.setPassword(env.getRequiredProperty("app.datasource.eConnect.password"));

        return new HikariDataSource(eConnectDataSourceConfig);
    }

    @Bean(name= "eConnectJdbcTemplate")
    public JdbcTemplate eConnectJdbcTemplate(@Qualifier("eConnectDataSource") final DataSource sourceDataSource) {
        return new JdbcTemplate(sourceDataSource);
    }



}

