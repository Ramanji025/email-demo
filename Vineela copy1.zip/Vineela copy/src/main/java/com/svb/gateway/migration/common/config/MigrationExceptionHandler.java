package com.svb.gateway.migration.common.config;

import com.svb.gateway.migration.common.exception.BadRequestException;
import com.svb.gateway.migration.common.exception.ServiceException;
import com.svb.gateway.migration.common.exception.dto.ErrorDetail;
import com.svb.gateway.migration.common.exception.dto.ErrorResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;


@ControllerAdvice
public class MigrationExceptionHandler {

    private static final Logger LOGGER = LoggerFactory.getLogger(MigrationExceptionHandler.class);


    @ExceptionHandler({BadRequestException.class})
    @ResponseBody
    public ResponseEntity<ErrorResponse> handleBadRequestException(BadRequestException exception) {
        List<ErrorDetail> obErrors = new ArrayList<>();
        ErrorDetail obError = new ErrorDetail().errorCode(exception.getErrorCode())
                .message(exception.getErrorDescription());
        obErrors.add(obError);

        ErrorResponse errorResponse = constructErrorResponse(Optional.of(HttpStatus.BAD_REQUEST),
                Optional.empty(),
                Optional.of("Invalid request parameters."),
                Optional.of(obErrors));

        LOGGER.error("Request Validation failed ", exception);

        return new ResponseEntity<>(errorResponse, HttpStatus.BAD_REQUEST);
    }

    @ExceptionHandler(ServiceException.class)
    @ResponseBody
    public ResponseEntity<ErrorResponse> serviceExceptionHandler(ServiceException exception) {
        List<ErrorDetail> obErrors = new ArrayList<>();

        ErrorDetail obError = new ErrorDetail().errorCode(exception.getError()).message(exception.getErrorMessage());
        obErrors.add(obError);

        ErrorResponse errorResponse = constructErrorResponse(Optional.of(HttpStatus.INTERNAL_SERVER_ERROR),
                Optional.empty(),
                Optional.of("Service Exception "),
                Optional.of(obErrors));

        LOGGER.error("Service Exception occurred ", exception);

        return new ResponseEntity<>(errorResponse, HttpStatus.INTERNAL_SERVER_ERROR);
    }

    private static ErrorResponse constructErrorResponse(Optional<HttpStatus> errorCode,
                                                        Optional<String> id,
                                                        Optional<String> message,
                                                        Optional<List<ErrorDetail>> errors) {

        ErrorResponse errorResponse = new ErrorResponse();
        String errorCodeText = "";
        if (errorCode.isPresent()) {
            errorCodeText = new StringBuilder(String.valueOf(errorCode.get().value())).append(" ").append(errorCode.get().getReasonPhrase()).toString();
        }

        errorResponse.setCode(errorCodeText);
        errorResponse.setId(id.isPresent() ? id.get() : null);
        errorResponse.setMessage(message.isPresent() ? message.get() : null);
        errorResponse.setErrors(errors.isPresent() ? errors.get() : null);

        return errorResponse;
    }
}

