package com.svb.gateway.migration.common.config;

import com.svb.gateway.migration.common.interceptor.RestTemplateClientInterceptor;
import com.svb.gateway.migration.common.utility.MigrationConstants;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.PropertySources;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.web.client.RestTemplate;

import java.time.Duration;
import java.util.Collections;

@Configuration
@EnableJpaRepositories(transactionManagerRef = "jpaTransactionManager",
		basePackages={"com.svb.gateway.migration.client.repository",
		"com.svb.gateway.migration.common.repository",
		"com.svb.gateway.migration.user.repository",
		"com.svb.gateway.migration.job.repository",
		"com.svb.gateway.migration.beneficiaries.repository",
		"com.svb.gateway.migration.cards.repository",
		"com.svb.gateway.migration.report.repository",
		"com.svb.gateway.migration.payments.repository",
		"com.svb.gateway.migration.alerts.repository",
		"com.svb.gateway.migration.nickname.repository"})
@PropertySources({
	@PropertySource("classpath:application.properties")
})
@EnableTransactionManagement
@Slf4j
public class MigrationServiceConfig {

	@Value("${httpConnectionTimeOutInSec}")
	private int httpConnectionTimeOut;

	@Value("${readTimeOutInSec}")
	private int readTimeOut;

	@Value("${ldap.migration.authorities.view}")
	private String authView;

	@Value("${ldap.migration.authorities.execute}")
	private String authExecute;

	@Bean(name = "migrationRestTemplateClientInterceptor")
	public RestTemplateClientInterceptor migrationRestTemplateClientInterceptor() {
		return new RestTemplateClientInterceptor();
	}

	@Bean
	public RestTemplate restTemplate(RestTemplateBuilder builder)
	{
		return builder
				.setConnectTimeout(Duration.ofSeconds(httpConnectionTimeOut))
				.setReadTimeout(Duration.ofSeconds(readTimeOut))
				.interceptors(Collections.singletonList(migrationRestTemplateClientInterceptor()))
				.build();
	}

	public String getAuthView() {

		return authView;
	}

	public String getAuthExecute() {
		return authExecute;
	}

	public String getViewAndExecute() {
		return authView + MigrationConstants.COMMA + authExecute;
	}

}
