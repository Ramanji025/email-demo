package com.svb.gateway.migration.common.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.http.MediaType;
import springfox.bean.validators.configuration.BeanValidatorPluginsConfiguration;
import springfox.documentation.builders.PathSelectors;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.service.Contact;
import springfox.documentation.service.ParameterType;
import springfox.documentation.service.VendorExtension;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;

@Configuration
@EnableSwagger2
@Import(BeanValidatorPluginsConfiguration.class)
public class SwaggerConfig {

    @Value("${gateway.project.version}")
    private String version;

    @Value("${spring.application.name}")
    private String title;

    @Value("${info.app.description}")
    private String description;

    @Bean
    public Docket api() {
        Collection<VendorExtension> vendorExtensionCollection=new ArrayList<>();
        ApiInfo apiInfo=new ApiInfo(title, description, version, "", new Contact("SVB","",""), "", "", vendorExtensionCollection);
        return new Docket(DocumentationType.SWAGGER_2)
                .apiInfo(apiInfo)
                .globalRequestParameters(
                        Arrays.asList(new springfox.documentation.builders.RequestParameterBuilder()
                                .name("Authorization")
                                .description("Enter the basic Authorization")
                                .in(ParameterType.HEADER)
                                .required(true)
                                .build()))
                .select()
                .apis(RequestHandlerSelectors.basePackage("com.svb.gateway.migration"))
                .paths(PathSelectors.any())
                .build();
    }


}
