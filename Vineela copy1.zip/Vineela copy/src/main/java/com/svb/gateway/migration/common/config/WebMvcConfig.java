package com.svb.gateway.migration.common.config;

import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;
import com.svb.gateway.migration.common.filter.MDCFilter;

@Configuration
public class WebMvcConfig implements WebMvcConfigurer {
    @Bean
    FilterRegistrationBean<MDCFilter> mdcFilter() {
        FilterRegistrationBean<MDCFilter> filterRegistrationBean = new FilterRegistrationBean<>();
        filterRegistrationBean.setFilter(new MDCFilter());
        // match all urls
        filterRegistrationBean.addUrlPatterns("*");
        return filterRegistrationBean;
    }
}
