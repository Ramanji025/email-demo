package com.svb.gateway.migration.common.constants;

public class ClientConstants {

    public static final String COUNTRY_CODE = "1";
    public static final String CONTACT_LABEL = "MOBILE";
    public static final String SIGNER = "Y";
    public static final String PRIMARY = "Y";
    public static final String INACTIVE = "I";
    public static final String ACCOUNT_SPECIFIC_TRANSACTION = "Y";
    public static final String MIGRATION_FLAG = "Y";
    public static final String DISABLED_USER = "0";
    public static final String DELETED_USER = "2";
    public static final String FROZEN_USER = "3";
    public static final String ADDED = "ADDED";
    public static final String CLIENT_ADDED = "Client Added";
    public static final String PRIMARY_USER_ADDED = "Primary User Added";
    public static final String PRIMARY_USER_DISABLED = "Primary User Disabled";
    public static final String PRIMARY_USER_DELETED = "Primary User Deleted";
    public static final String PRIMARY_USER_FROZEN = "Primary User Frozen";
    public static final String PRIMARY_USER_LAST_LOGIN_DATE_BEYOND_THRESHOLD = "Primary User Last login date is beyond threshold";
    public static final String PRIMARY_USER_LAST_LOGIN_DATE_NULL = "Primary User Last login date is Null";
    public static final String ALREADY_PROCESSED = "Already processed";
    public static final String PARTNERS = "partners";
    public static final String PARTNER = "partner";
    public static final String CLIENT_USERS = "clientusers";
    public static final String CLIENT = "client";
    public static final String CLIENTS = "clients";
    public static final String NOT_PRIMARY_CONTACT = "N";
    public static final String IS_PRIMARY_CONTACT = "Y";
    public static final String ANALYSIS_CHECKING = "011";
    public static final String EURO_DOLLAR_CHECKING_ACCOUNT = "229";
    public static final String ACC_STATUS_OPEN = "Open";
    public static final String ACC_STATUS_NO_CHECK = "No check";
    public static final String INVALID_COUNTRYCODE_PHONENUMBER = "Invalid Country Code/Phone Number";
}
