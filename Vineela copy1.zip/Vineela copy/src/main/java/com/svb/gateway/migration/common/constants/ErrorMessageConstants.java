package com.svb.gateway.migration.common.constants;

public class ErrorMessageConstants {
    public static final String INVALID_CLIENT_ID_MESSAGE = "Invalid Client ID entered.";
    public static final String INVALID_COMPANY_LOGIN_ID_MESSAGE = "Invalid Company Login ID entered.";
}
