package com.svb.gateway.migration.common.constants;

public class RegexConstants {
    public static final String EC_CLIENT_ID_PATTERN = "[a-zA-Z]{4}[0-9]{4}";
    public static final String GW_CLIENT_LOGIN_ID_PATTERN = "[a-zA-Z0-9]{3,10}";
    public static final String GW_CLIENT_ID_PATTERN = "GW[a-z]{4}[0-9]{4}";
}
