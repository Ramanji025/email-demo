package com.svb.gateway.migration.common.constants;

import java.util.regex.Pattern;

public class ReportConstants {

    public static final String CLIENT_NOT_PRESENT = "Client Not Present";
    public static final String ENTITY_NOT_PRESENT = "Entity record Not Present";
    public static final String REPORTEXCEPTION = "report with exception";
    public static final String SERVICEREPORTEXCEPTION = "Service could not produce, report with exception";
    public static final String ECCLIENTID = "EcClientId";
    public static final String GWCLIENTID = "GwClientId";
    public static final String COMMENTS = "Comments";
    public static final String APPROVAL_SETTING = "Approval Setting Required";
    public static final String SRNO = "Sr No";
    public static final String JOBID = "Job Id";
    public static final String STATUS = "Status";
    public static final String JOB_TYPE = "Job Type";
    public static final String EXTRACTION_TIME = "Extraction Time(sec)";
    public static final String STARTTIME = "Start Time";
    public static final String ENDTIME = "End Time";
    public static final String LOAD_TIME = "Load Time(sec)";
    public static final String CLIENT_COUNT = "Client Count";
    public static final String STAGING_COUNT = "Staging Count";
    public static final String CLIENT_NAME = "Client Name";
    public static final String COMPANY_ID = "Company Id";
    public static final String TARGET_SUCCESS_COUNT = "Target Success Count";
    public static final String TARGET_PENDING_COUNT = "Target Pending Count";
    public static final String PRIMARY_CIF_UBS = "Primary Cif Ubs";
    public static final String UPDATED_DATE = "Updated Date";
    public static final String BDC_REGISTRATION_STATUS = "BDC Registration status";
    public static final String RDM_REGISTRATION_STATUS = "Mobile Deposit Registration";
    public static final String EC_CLIENT_ID_NUM = "Backend eConnect client ID";
    public static final String EC_USER_ID_NUM = "Backend eConnect User ID";
    public static final String STEP_NAME = "Step Name";
    public static final String EC_USER_LOGIN_ID = "EcUser Login Id";
    public static final String GW_UUID = "GwUuid";
    public static final String FIRST_NAME = "First Name";
    public static final String LAST_NAME = "Last Name";
    public static final String MOBILE_NUMBER = "Mobile Number";
    public static final String EMAIL_ID = "Email Id";
    public static final String USER_TYPE = "User Type";
    public static final String BDC_STATUS = "BDC Status";
    public static final String IS_PRIMARY_USER = "Is Primary User";
    public static final String WC_EMAIL_SNT_FLAG = "WC_EMAIL_SNT_FLAG";


    public static final String BENE_CREATION_TEMPLATE = "BeneCreation TEMPLATE";
    public static final String BENE_CREATION_FUTURE = "BeneCreation FUTURE";
    public static final String BENE_CREATION_CHECK = "BeneCreation CHECK";
    public static final String BENE_CREATION_ACH_LARGE = "BeneCreation ACH_LARGE";
    public static final String BENE_CREATION_ACH = "BeneCreation ACH";

    public static final String ADDITIONAL_USER_CREATION = "AdditionalUserCreation";
    public static final String ENROLL_CARD_PROGRAM = "Enroll-Card-Program";
    public static final String TRANSFERS_CREATION = "TransfersCreation";
    public static final String WIRE_TRANSFERS_CREATION = "WireTransfersCreation";
    public static final String WIRE_TRANSFERS = "Wire Transfer";
    public static final String INTERNAL_TRANSFER = "Internal Transfer";
    public static final String CLIENT_CREATION = "ClientCreation";
    public static final String PRIMARY_USER_CREATION = "PrimaryUserCreation";

    public static final String JOB_REPORT = "Job";
    public static final String CLIENT_REPORT = "Client";
    public static final String USER_REPORT = "User";
    public static final String EXTRACTION_REPORT = "Extraction";
    public static final String TARGET_LOAD_REPORT = "Target Load";
    public static final String BENEFICIARY_REPORT = "Beneficiary";
    public static final String EXCEPTION = "Exception";
    public static final String USER_ROLE = "User Role";
    public static final String ISAPPROVER = "Is Approver";
    public static final String USER_ACCESS = "User Access";
    public static final String USER_STATUS = "User Status";
    public static final String BLANK = "-";
    public static final String VALIDATION_FAILED = "Validation failed";
    public static final String MIG_BENEFICIARY = "Mig Beneficiary";
    public static final String MIG_STG_SKIP_LOG = "Mig Stg Skip Log";
    public static final String SOURCE_COUNT = "Source Count";
    public static final String TARGET_COUNT = "Target Count";
    public static final String SKIP_COUNT = "Skip Count";
    public static final String STEP_ENTITY_NAME = "Step Entity Name";
    public static final String ENTITY_NAME = "Entity Name";
    public static final String SOURCE_SYSTEM_TYPE = "Source System Type";
    public static final String SOURCE_SYSTEM_ID = "Source System Id";
    public static final String EXCEPTION_DETAILS = "Exception Details";
    public static final String ACCOUNT_NICKNAME = "Account Nickname";
    public static final String MIG_CARD_USER_UPDATE = "MigCardUserUpdate";
    public static final String MIG_CARD_USER_ROLLBACK = "MigCardUserRollback";
    public static final String ALERT_SUBSCRIPTION = "Alert Subscription";
    public static final String IPAY_PAYMENTS= "Ipay-Payments";
    public static final String IPAY_SOURCE= "iPay";
    public static final String ECONNECT_SOURCE= "eConnect";
    public static final Pattern regexSpecialChar = Pattern.compile("[*+='\\s-]");
}
