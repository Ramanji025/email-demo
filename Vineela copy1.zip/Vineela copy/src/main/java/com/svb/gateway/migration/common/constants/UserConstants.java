package com.svb.gateway.migration.common.constants;

public class UserConstants {

    public static final String DELETED = "D";
    public static final String FROZEN = "F";
    public static final String INACTIVE = "I";
    public static final String DELETED_USER = "2";
    public static final String FROZEN_USER = "3";
    public static final String DISABLED_USER = "0";
    public static final String PRIMARY_USER_SUCCESS = "Primary User Added";
    public static final String DELETED_USER_FAILURE = "Deleted User, not migrated";
    public static final String FROZEN_USER_FAILURE = "Frozen User, not migrated";
    public static final String ACTIVE_USER_SUCCESS = "Active User, Migration Success";
    public static final String DISABLED_USER_SUCCESS = "Disabled User, Migration Success";
    public static final String USER_ENTITY_FAILED = "user Entity insert/Update Failed";
    public static final String ADD_USER_FAILED = "Add User Failed";
    public static final String LAST_LOGIN_DATE_BEYOND_THRESHOLD = "Last login date beyond threshold, not migrated";
    public static final String N_FLAG = "N";
    public static final String Y_FLAG = "Y";
    public static final Integer BDC_NOT_SET = null;
    public static final Integer RDM_NOT_SET = null;

    public static final Integer BDC_DISABLED = 0;
    public static final Integer BDC_ENABLED = 1;
    public static final Integer RDM_DISABLED = 0;
    public static final Integer RDM_ENABLED = 1;
    public static final Integer PRIMARY_USER_FLAG_TRUE = 1;
    public static final Integer PRIMARY_USER_FLAG_FALSE = 0;
    public static final String ADDITIONAL_USER_SUCCESS = "Additional User created successfully";

    public static final String YES="YES";
    public static final String NO="NO";
    public static final String PRIMARY_ADMIN = "PRIMARY ADMIN";
    public static final String ADMIN = "ADMIN";
    public static final String TRANSACT="TRANSACT";
}
