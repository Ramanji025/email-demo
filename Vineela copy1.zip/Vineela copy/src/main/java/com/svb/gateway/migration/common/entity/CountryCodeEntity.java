package com.svb.gateway.migration.common.entity;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;

@Getter
@Setter
@Entity
@Table(schema = "GWDMG", name = "MIG_REF_COUNTRY_CODE_MAPPING")
public class CountryCodeEntity {

    @GeneratedValue(strategy= GenerationType.IDENTITY)
    @Id
    @Column(name = "ID")
    private Integer id;

    @Column(name = "COUNTRY")
    private String country;

    @Column(name = "ISO_CODE")
    private String isoCode;

    public String getCountry() {
        return country==null?"":country.toUpperCase();
    }

    public String getIsoCode() {
        return isoCode==null?"":isoCode.toUpperCase();
    }

}
