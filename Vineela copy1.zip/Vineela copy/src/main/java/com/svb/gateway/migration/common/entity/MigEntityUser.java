package com.svb.gateway.migration.common.entity;


import javax.persistence.*;
import java.sql.Timestamp;

@Entity
@IdClass(MigEntityUserId.class)
@Table(schema = "GWDMG", name = "MIG_ENTITY")
public class MigEntityUser {

    @Id
    @Column(name = "JOB_ID")
    private Integer jobId;

    @Id
    @Column(name = "ECCLIENT_ID")
    private String ecclientId;

    @Column(name = "GWCLIENT_ID")
    private String gwclientId;

    @Column(name = "CIF_NUMBER")
    private String CIF_NUMBER;

    @Id
    @Column(name = "ENTITY_NAME")
    private String entityName;

    @Column(name = "READCOUNT")
    private Integer readCount;

    @Column(name = "WRITECOUNT")
    private Integer writeCount;

    @Column(name = "SKIPCOUNT")
    private Integer skipCount;

    @Column(name = "START_TIME")
    private Timestamp startTime;

    @Column(name = "END_TIME")
    private Timestamp endTime;

    @Column(name = "TOTAL_STEP_TIME")
    private Integer totalStepTime;

    @Column(name = "CREATED_DATETIME")
    private Timestamp createdDateTime;

    @Transient
    private String sourceType;

    public Integer getJobId() {
        return jobId;
    }

    public void setJobId(Integer jobId) {
        this.jobId = jobId;
    }

    public String getEcclientId() {
        return ecclientId;
    }

    public void setEcclientId(String ecclientId) {
        this.ecclientId = ecclientId;
    }

    public String getGwclientId() {
        return gwclientId;
    }

    public void setGwclientId(String gwclientId) {
        this.gwclientId = gwclientId;
    }

    public String getEntityName() {
        return entityName;
    }

    public void setEntityName(String entityName) {
        this.entityName = entityName;
    }

    public Integer getReadCount() {
        return readCount;
    }

    public void setReadCount(Integer readCount) {
        this.readCount = readCount;
    }

    public Integer getWriteCount() {
        return writeCount;
    }

    public void setWriteCount(Integer writeCount) {
        this.writeCount = writeCount;
    }

    public Integer getSkipCount() {
        return skipCount;
    }

    public void setSkipCount(Integer skipCount) {
        this.skipCount = skipCount;
    }

    public Timestamp getStartTime() {
        return startTime;
    }

    public void setStartTime(Timestamp startTime) {
        this.startTime = startTime;
    }

    public Timestamp getEndTime() {
        return endTime;
    }

    public void setEndTime(Timestamp endTime) {
        this.endTime = endTime;
    }

    public Integer getTotalStepTime() {
        return totalStepTime;
    }

    public void setTotalStepTime(Integer totalStepTime) {
        this.totalStepTime = totalStepTime;
    }

    public Timestamp getCreatedDateTime() {
        return createdDateTime;
    }

    public void setCreatedDateTime(Timestamp createdDateTime) {
        this.createdDateTime = createdDateTime;
    }

    public String getCIF_NUMBER() {
        return CIF_NUMBER;
    }

    public void setCIF_NUMBER(String CIF_NUMBER) {
        this.CIF_NUMBER = CIF_NUMBER;
    }

    public String getSourceType() {
        return sourceType;
    }

    public void setSourceType(String sourceType) {
        this.sourceType = sourceType;
    }
}

