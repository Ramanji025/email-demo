package com.svb.gateway.migration.common.entity;

import java.sql.Timestamp;

public class MigEntityUserId implements java.io.Serializable {

    Integer jobId;
    String entityName;
    String ecclientId;
    Timestamp createdDateTime;
}
