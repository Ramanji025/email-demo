package com.svb.gateway.migration.common.exception;


import com.svb.gateway.migration.common.utility.MigrationErrorCodeEnum;
import org.springframework.http.HttpStatus;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class AuthenticationException extends RuntimeException {

    private static final long serialVersionUID = 1L;

    private List<MigrationErrorCodeEnum> errors = new ArrayList<>();
    private final String message;
    private final HttpStatus httpStatus;

    public AuthenticationException(MigrationErrorCodeEnum error) {
        this.errors.add(error);
        this.message = "";
        this.httpStatus = HttpStatus.UNAUTHORIZED;
    }

    public AuthenticationException(MigrationErrorCodeEnum... errors) {
        this.errors.addAll(Arrays.asList(errors));
        this.message = "";
        this.httpStatus = HttpStatus.UNAUTHORIZED;
    }

    @Override
    public String getMessage() {
        return message;
    }

    public HttpStatus getHttpStatus() {
        return httpStatus;
    }

    public List<MigrationErrorCodeEnum> getErrors() {
        return errors;
    }
}
