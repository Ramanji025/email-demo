package com.svb.gateway.migration.common.exception;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.step.skip.SkipLimitExceededException;
import org.springframework.batch.core.step.skip.SkipPolicy;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.stereotype.Component;

import java.sql.SQLIntegrityConstraintViolationException;
import java.util.ArrayList;
import java.util.List;

@Component
public class ExceptionSkipPolicy implements SkipPolicy {
    private List<Class<? extends Exception>> exceptionClassToSkipList;
    private static final Logger log = LoggerFactory.getLogger(ExceptionSkipPolicy.class);

    public ExceptionSkipPolicy()
    {
        List<Class<? extends Exception>> exceptionList = new ArrayList<Class<? extends Exception>>();
        exceptionList.add(SQLIntegrityConstraintViolationException.class);
        exceptionList.add(DuplicateKeyException.class);

        exceptionClassToSkipList = exceptionList;
    }

    @Override
    public boolean shouldSkip(Throwable curException, int skipCount) throws SkipLimitExceededException {
        curException.printStackTrace();
        if(curException instanceof SQLIntegrityConstraintViolationException)
        {
            SQLIntegrityConstraintViolationException caughtException = (SQLIntegrityConstraintViolationException) curException;
            //log.error("Exception in SQL Integrity Constraint : " + caughtException.toString());

        }
        if(curException instanceof DuplicateKeyException)
        {
            DuplicateKeyException caughtException = (DuplicateKeyException) curException;
            //log.error("Duplicate Key Constraint Exception: " + caughtException.toString());

        }

        return true;
    }


}
