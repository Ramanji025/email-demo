package com.svb.gateway.migration.common.exception;

import com.svb.gateway.migration.common.utility.MigrationErrorCodeEnum;
import org.springframework.http.HttpStatus;

import java.io.Serializable;

public class ServiceException extends Exception implements Serializable {
    private static final long serialVersionUID = 1L;

    private MigrationErrorCodeEnum error;
    private String errorCode;
    private String errorMessage;
    HttpStatus httpStatus;

    public ServiceException(MigrationErrorCodeEnum error) {
        super();
        this.error = error;
    }

    public ServiceException(MigrationErrorCodeEnum error, String message) {
        super(message);
        this.error = error;
        this.errorMessage = message;
    }

    public ServiceException(String errorCode, String message) {
        super(message);
        this.errorCode = errorCode;
        this.errorMessage = message;
    }
    public ServiceException(HttpStatus httpStatus, MigrationErrorCodeEnum errorCode) {
        super(errorCode.toString());
        this.httpStatus = httpStatus;
    }

    public ServiceException(HttpStatus httpStatus, MigrationErrorCodeEnum errorCode, Throwable throwable) {
        super(errorCode.toString());
        this.httpStatus = httpStatus;
    }
    public ServiceException(MigrationErrorCodeEnum error, Throwable cause) {
        super(cause);
        this.error = error;
    }

    public ServiceException(String errorMessage) {
        super(errorMessage);
        this.errorMessage = errorMessage;
    }

    public MigrationErrorCodeEnum getError() {
		return error;
	}

	public String getErrorCode() {
		return errorCode;
	}

	public String getErrorMessage() {
		return errorMessage;
	}

	@Override
	public String toString() {
		return "ServiceException [error=" + error + ", errorCode=" + errorCode + ", errorMessage=" + errorMessage + "]";
	}
}
