package com.svb.gateway.migration.common.exception;

public class SkipAheadServiceException extends ServiceException{

    public SkipAheadServiceException(String errorCode, String message) {
        super(errorCode, message);
    }

    public SkipAheadServiceException(String errorMessage) {
        super(errorMessage);
    }
}
