package com.svb.gateway.migration.common.exception;

import com.svb.gateway.migration.common.utility.MigrationErrorCodeEnum;
import org.springframework.http.HttpStatus;

import java.io.Serializable;

public class ValidationException extends ServiceException {

    public ValidationException(MigrationErrorCodeEnum error) {
        super(error);
    }

    public ValidationException(MigrationErrorCodeEnum error, String message) {
        super(error, message);
    }

    public ValidationException(String errorCode, String message) {
        super(errorCode, message);
    }

    public ValidationException(HttpStatus httpStatus, MigrationErrorCodeEnum errorCode) {
        super(httpStatus, errorCode);
    }

    public ValidationException(HttpStatus httpStatus, MigrationErrorCodeEnum errorCode, Throwable throwable) {
        super(httpStatus, errorCode, throwable);
    }

    public ValidationException(MigrationErrorCodeEnum error, Throwable cause) {
        super(error, cause);
    }

    public ValidationException(String errorMessage) {
        super(errorMessage);
    }
}
