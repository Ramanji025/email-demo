package com.svb.gateway.migration.common.filter;

import com.svb.gateway.migration.common.constants.MigrationConstants;
import io.micrometer.core.instrument.util.StringUtils;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.MDC;
import org.springframework.core.annotation.Order;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.filter.OncePerRequestFilter;

import javax.servlet.*;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Map;
import java.util.UUID;

@Slf4j
@Order(-999999999)
public class MDCFilter extends OncePerRequestFilter {
    public static final String ACTUATOR_PATH = "/actuator/";

    @Override
    public void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain chain) throws IOException, ServletException {

        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if (authentication != null) {
            MDC.put(MigrationConstants.MDC_USER_ID, authentication.getName());
        }
        String correlationId = String.valueOf(UUID.randomUUID());
        MDC.put(MigrationConstants.MDC_CORRELATION_ID, correlationId);

        long startTime = System.currentTimeMillis();
        MDC.put(MigrationConstants.MDC_START_TIME, Long.toString(startTime));
        String requestURI = request.getRequestURI();
        String queryString = request.getQueryString() != null ? "?" + request.getQueryString() : "";
        MDC.put(MigrationConstants.MDC_REQUEST_URI, requestURI + queryString);
        MDC.put(MigrationConstants.MDC_REQUEST_METHOD, request.getMethod());
        MDC.put(MigrationConstants.MDC_USER_AGENT, request.getHeader(MigrationConstants.USER_AGENT_HEADER));
        if(null != request.getSession()){
            MDC.put(MigrationConstants.MDC_SESSION_ID, request.getSession().getId());
        }
        if(StringUtils.isNotBlank(request.getHeader(MigrationConstants.ORIGINATING_IP_HEADER)))
            MDC.put(MigrationConstants.MDC_REQUEST_IP, request.getHeader(MigrationConstants.ORIGINATING_IP_HEADER));
        else
            MDC.put(MigrationConstants.MDC_REQUEST_IP, request.getRemoteAddr());

        Map<String,String> mdcMap = MDC.getCopyOfContextMap();
        long endTime=0;
        try {
            chain.doFilter(request, response);
            MDC.setContextMap(mdcMap);
            endTime = System.currentTimeMillis();

        } catch (Exception e) {
            endTime = System.currentTimeMillis();
            response.setStatus(HttpStatus.INTERNAL_SERVER_ERROR.value());
        } finally {
            log.info("Response status: {} Elapsed time: {} ms", response.getStatus(), (endTime - startTime));
            MDC.clear();
        }
    }

    @Override
    protected boolean shouldNotFilter(HttpServletRequest request) throws ServletException {
        String requestURI = request.getRequestURI();
        if (requestURI != null && requestURI.contains(ACTUATOR_PATH)) {
            return true;
        } else {
            return super.shouldNotFilter(request);
        }
    }
}