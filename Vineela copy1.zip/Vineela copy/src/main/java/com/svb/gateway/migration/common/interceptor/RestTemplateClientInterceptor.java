package com.svb.gateway.migration.common.interceptor;

import com.svb.gateway.migration.common.logging.Message;
import lombok.extern.log4j.Log4j2;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpRequest;
import org.springframework.http.client.ClientHttpRequestExecution;
import org.springframework.http.client.ClientHttpRequestInterceptor;
import org.springframework.http.client.ClientHttpResponse;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.util.UUID;

import static com.svb.gateway.migration.common.constants.MigrationConstants.*;

@Log4j2
@Component
public class RestTemplateClientInterceptor implements ClientHttpRequestInterceptor {

    @Value("${header.service.token}")
    private String serviceToken;

    @Value("${header.bankuser.group}")
    private String bankUserGroup;

    @Value("${header.client.loginid}")
    private String clientLoginId;

    @Value("${header.client.name}")
    private String clientName;

    @Value("${header.client.id}")
    private String clientId;

    @Value("${header.user.emulated}")
    private String isEmulatedUser;

    @Value("${header.channel}")
    private String channel;

    @Value("${header.oob.auth}")
    private String oObAuth;

    @Value("${header.userid}")
    private String userId;

    @Value("${header.user.loginid}")
    private String userLoginId;

    @Value("${header.username}")
    private String userName;


    @Override
    public ClientHttpResponse intercept(HttpRequest request, byte[] body, ClientHttpRequestExecution execution) throws IOException
    {
        Message logMessage = Message.create();
        //To set the sleuth MDC Header values.
        request.getHeaders().add(HEADER_SERVICE_TOKEN, serviceToken);
        request.getHeaders().add(HEADER_USER_INFO_BANK_USER_GROUP_NAME, bankUserGroup);
        request.getHeaders().add(HEADER_USER_INFO_CLIENT_LOGIN_ID, clientLoginId);
        request.getHeaders().add(HEADER_USER_INFO_CLIENT_NAME, clientName);
        request.getHeaders().add(HEADER_USER_INFO_CLIENT_ID, clientId);
        request.getHeaders().add(HEADER_IS_EMULATED_USER, isEmulatedUser);
        request.getHeaders().add(HEADER_DEVICE_INFO_CHANNEL, channel);
        request.getHeaders().add(HEADER_SESSION_INFO_OOB_AUTH, oObAuth);
        request.getHeaders().add(HEADER_USER_INFO_USER_ID, userId);
        request.getHeaders().add(HEADER_USER_INFO_USER_LOGIN_ID, userLoginId);
        request.getHeaders().add(HEADER_USER_INFO_USER_NAME, userName);
        request.getHeaders().add(HEADER_REQUEST_ID, String.valueOf(UUID.randomUUID()));

        request.getHeaders().add(HEADER_CORRELATION_ID, null != MDC.get(HEADER_CORRELATION_ID) ? MDC.get(HEADER_CORRELATION_ID) : "");
        request.getHeaders().add(HEADER_USER_INFO_IP_ADDRESS, null != MDC.get(HEADER_USER_INFO_IP_ADDRESS) ? MDC.get(HEADER_USER_INFO_IP_ADDRESS) : "");
        request.getHeaders().add(HEADER_DEVICE_INFO_USER_AGENT, null != MDC.get(HEADER_DEVICE_INFO_USER_AGENT) ? MDC.get(HEADER_DEVICE_INFO_USER_AGENT) : "");
        request.getHeaders().add(HEADER_SESSION_INFO_SESSION_ID, null != MDC.get(HEADER_SESSION_INFO_SESSION_ID) ? MDC.get(HEADER_SESSION_INFO_SESSION_ID) : "");

        logRequest(request, new String(body));
        long startTime = System.currentTimeMillis();
        ClientHttpResponse response = execution.execute(request, body);
        long endTime = System.currentTimeMillis();
        long duration = (endTime - startTime);
        log.info(logMessage.descr("Outbound HTTP call [tt unit Milli Seconds]").url(request.getURI().toString()).timeTaken(duration));
        logResponse(response);
        return response;
    }


    private void logRequest(HttpRequest request, String strBody) {
        if (log.isDebugEnabled()) {
            log.debug(Message.create().descr("===========================request begin================================================"));
            log.debug(Message.create().descr("URI         : " +request.getURI()));
            log.debug(Message.create().descr("Method      : " +request.getMethod()));
            log.debug(Message.create().descr("Request body: " +strBody));
            log.debug(Message.create().descr("==========================request end================================================"));
        }
    }

    private void logResponse(ClientHttpResponse response) throws IOException {
        if (null != response && log.isDebugEnabled()) {
            log.debug(Message.create().descr("============================response begin=========================================="));
            log.debug(Message.create().descr("Status code  : " +response.getStatusCode()));
            log.debug(Message.create().descr("Status text  : " +response.getStatusText()));
            log.debug(Message.create().descr("Headers      : " +response.getHeaders()));
            log.debug(Message.create().descr("=======================response end================================================="));
        }
    }
}



