package com.svb.gateway.migration.common.listeners;

import com.svb.gateway.migration.common.logging.Message;
import com.svb.gateway.migration.common.utility.JobStatusEnum;
import com.svb.gateway.migration.common.utility.MigrationConstants;
import com.svb.gateway.migration.job.entity.JobEntity;
import com.svb.gateway.migration.job.mapper.JobMapper;

import lombok.extern.log4j.Log4j2;

import org.springframework.batch.core.BatchStatus;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.listener.JobExecutionListenerSupport;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.time.*;

@Component
@Log4j2
public class MigrationJobListener extends JobExecutionListenerSupport {


    @Autowired
    private final JobMapper jobMapper;

    public MigrationJobListener(JobMapper jobMapper) {
        super();
        this.jobMapper = jobMapper;
    }

    @Override
    public void beforeJob(JobExecution jobExecution) {
        super.beforeJob(jobExecution);
    }

    @Override
    public void afterJob(JobExecution jobExecution) {
        if(jobExecution.getStatus() == BatchStatus.COMPLETED) {
        	String jobID = jobExecution.getJobParameters().getParameters().get(MigrationConstants.JOB_ID_KEY).getValue().toString();
        	Message logMessage = Message.create().jobId(Long.valueOf(jobID)).entityName(Message.Entity.client).operation("Job Execution");
        	
        	log.info(logMessage.descr("!!! JOB FINISHED! Time to verify the results with JOBID >> "+jobID));
            // update ec2Stage job completion
            if(MigrationConstants.MIGRATE_EC_DATA_JOB.equals(jobExecution.getJobInstance().getJobName())) {
                JobEntity e = jobMapper.readMigrationJob(Integer.parseInt(jobID));
                OffsetDateTime now = OffsetDateTime.now().withOffsetSameInstant(ZoneOffset.UTC);
                e.setEndTime(now);
                e.setExtractionTime(Duration.between(e.getStartTime(), now).toSeconds());
                e.setUpdatedDate(now);
                e.setStatus(JobStatusEnum.EXTRACTION_COMPLETED);
                jobMapper.updateJob(e);
            }
        }
    }
}
