package com.svb.gateway.migration.common.listeners;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.svb.gateway.migration.common.logging.Message;
import com.svb.gateway.migration.common.utility.BatchMetaDataQueries;
import lombok.SneakyThrows;
import lombok.extern.log4j.Log4j2;

import org.codehaus.jettison.json.JSONException;
import org.codehaus.jettison.json.JSONObject;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.StepExecutionListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Component;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import static com.svb.gateway.migration.common.utility.MigrationConstants.*;


@Component
@Log4j2
public class MigrationStepListener implements StepExecutionListener {

    private ThreadLocal<StepExecution> thlStepExecution = new ThreadLocal<StepExecution>();

    private Date startTime;

    private Date endTime;

    @Autowired
    @Qualifier("migrationNamedParameterJdbcTemplate")
    private NamedParameterJdbcTemplate jdbcTemplate;
    private ObjectMapper objectMapper = new ObjectMapper();

    public StepExecution getStepExecution() {
        return thlStepExecution.get();
    }

    @Override
    public void beforeStep(StepExecution stepExecution) {

        thlStepExecution.set(stepExecution);
        this.startTime = new Date();
        Message logMessage = Message.create().operation(stepExecution.getStepName()).jobId(stepExecution.getJobExecutionId()).entityName(Message.Entity.client).operation("Step Execution");
        log.debug(logMessage.descr("Before starting the step [" + stepExecution.getStepName() + "], time is: " + startTime));
    }

    @SneakyThrows
    @Override
    public ExitStatus afterStep(StepExecution stepExecution) {
    	
    	Message logMessage = Message.create().operation(stepExecution.getStepName()).jobId(stepExecution.getJobExecutionId()).entityName(Message.Entity.client).operation("Step Execution");
    	
        log.info(logMessage.descr("Skipped Records ==> "+stepExecution.getSkipCount()));
        log.info(logMessage.descr("Read Records ==> "+stepExecution.getReadCount()));;
        log.info(logMessage.descr("Write Records ==> "+stepExecution.getWriteCount()));
        log.info(logMessage.descr("WriteSkip Records ==> "+ stepExecution.getWriteSkipCount()));
        log.info(logMessage.descr("ReadSkip Records ==> "+stepExecution.getReadSkipCount()));
        log.info(logMessage.descr("Step Name ==> "+stepExecution.getStepName()));
        log.info(logMessage.descr("Job Status ==> "+stepExecution.getStatus()));
  
        endTime = new Date();
        String stepName = stepExecution.getStepName();
        log.info(logMessage.descr("Total time taken by the step " + stepName + " is: "
                + ((endTime.getTime() - startTime.getTime()) / 1000) + " secs"));
        log.info(logMessage.descr("Finished step: [" + stepName + "]"));

        saveStepLog(stepExecution,startTime,endTime);
        return null;
    }

    private void saveStepLog(StepExecution stepExecution, Date startTime, Date endTime) throws JsonProcessingException, JSONException {
        Map<String, Object> parameters = new HashMap<>();
        parameters.put(MIG_ENTITY_ID,stepExecution.getJobExecution().getJobConfigurationName());
        parameters.put(ENTITY_NAME, stepExecution.getStepName());
        parameters.put(JOB_ID, stepExecution.getJobExecution().getJobParameters().getLong(JOB_ID_KEY));
        parameters.put(START_TIME,startTime);
        parameters.put(END_TIME,endTime);
        parameters.put(TOTAL_STEP_TIME,((endTime.getTime() - startTime.getTime())/1000 ));
        if (stepExecution != null) {
            String dataJson = objectMapper.writeValueAsString(stepExecution.getJobExecution().getJobParameters());
            JSONObject data = new JSONObject(dataJson);
            if (data.has(PARAMETERS)) {
                JSONObject param=data.getJSONObject(PARAMETERS);
                if(param.has(CIF_ID)) {
                    JSONObject cifIds=param.getJSONObject(CIF_ID);
                    parameters.put(CIF_NUMBER, cifIds.getString(VALUE));
                } else {
                    parameters.put(CIF_NUMBER, null);
                }

            } else {
                parameters.put(CIF_NUMBER, null);
            }
        }
        parameters.put(ECCLIENT_ID, null);
        parameters.put(GWCLIENT_ID, null);
        parameters.put(READCOUNT, stepExecution.getReadCount());
        parameters.put(WRITECOUNT, stepExecution.getWriteCount());
        parameters.put(SKIPCOUNT, stepExecution.getSkipCount());
        jdbcTemplate.update(BatchMetaDataQueries.ENTITY_LOG_QUERY_INSERT, parameters);
    }

}
