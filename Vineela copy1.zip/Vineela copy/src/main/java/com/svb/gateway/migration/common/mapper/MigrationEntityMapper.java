package com.svb.gateway.migration.common.mapper;

import com.svb.gateway.migration.alerts.model.AlertsResponse;
import com.svb.gateway.migration.client.entity.MigClient;
import com.svb.gateway.migration.common.model.EntityRecordCount;
import com.svb.gateway.migration.common.utility.RecordCount;
import com.svb.gateway.migration.nickname.model.NicknameResponse;
import com.svb.gateway.migration.payments.entity.MigrationEntity;
import com.svb.gateway.migration.payments.model.PaymentResponse;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import java.sql.Timestamp;

@Mapper(componentModel="spring")
public interface MigrationEntityMapper {

    MigrationEntityMapper INSTANCE = Mappers.getMapper(MigrationEntityMapper.class);

    @Mapping(source="paymentResponse.paymentResponseData.gwClientId",target="gwClientId")
    @Mapping(source="paymentResponse.paymentResponseData.ecClientId",target="ecClientId")
    @Mapping(source="recordCount.failure",target="skipCount")
    @Mapping(source="recordCount.success",target="writeCount")
    @Mapping(source="recordCount.total",target="readCount")
    @Mapping(source="recordCount.startTime",target="startTime")
    @Mapping(source="recordCount.endTime",target="endTime")
    @Mapping(source="recordCount.totalStepTime",target="totalStepTime")
    @Mapping(expression="java(getDateFromLong(System.currentTimeMillis()))",target="createdDateTime")
    @Mapping(constant="Ipay-Payments",target="entityName")
    @Mapping(source="paymentResponse.paymentResponseData.jobId",target="jobId")
    MigrationEntity convertPaymentToMigEntity(PaymentResponse paymentResponse, RecordCount recordCount);

    @Mapping(source="migClient.gwClientId",target="gwClientId")
    @Mapping(source="migClient.ecClientId",target="ecClientId")
    @Mapping(expression="java(String.valueOf(migClient.getPrimaryCifUbs()))",target="CIF_NUMBER")
    @Mapping(source="recordCount.failure",target="skipCount")
    @Mapping(source="recordCount.success",target="writeCount")
    @Mapping(source="recordCount.total",target="readCount")
    @Mapping(source="recordCount.startTime",target="startTime")
    @Mapping(source="recordCount.endTime",target="endTime")
    @Mapping(source="recordCount.totalStepTime",target="totalStepTime")
    @Mapping(expression="java(getDateFromLong(System.currentTimeMillis()))",target="createdDateTime")
    @Mapping(source="entity", target="entityName")
    @Mapping(source="migClient.jobId",target="jobId")
    MigrationEntity convertTransferToMigEntity(MigClient migClient, RecordCount recordCount, String entity);

    @Mapping(source="migClient.gwClientId",target="GWCLIENT_ID")
    @Mapping(source="migClient.ecClientId",target="ECCLIENT_ID")
    @Mapping(expression="java(String.valueOf(migClient.getPrimaryCifUbs()))",target="CIF_NUMBER")
    @Mapping(expression="java(Integer.valueOf(0))",target="SKIPCOUNT")
    @Mapping(expression="java(Integer.valueOf(0))",target="WRITECOUNT")
    @Mapping(expression="java(Integer.valueOf(0))",target="READCOUNT")
    @Mapping(source="recordCount.startTime",target="START_TIME")
    @Mapping(source="recordCount.endTime",target="END_TIME")
    @Mapping(source="recordCount.totalStepTime",target="TOTAL_STEP_TIME")
    @Mapping(source="entity", target="ENTITY_NAME")
    @Mapping(source="migClient.jobId",target="JOB_ID")
    EntityRecordCount convertNoAlertsToMigEntity(MigClient migClient, RecordCount recordCount, String entity);

    @Mapping(source="alertsResponse.alertsResponseData.gwClientId",target="GWCLIENT_ID")
    @Mapping(source="alertsResponse.alertsResponseData.ecClientId",target="ECCLIENT_ID")
    @Mapping(source="alertsResponse.alertsResponseData.cifNumber",target="CIF_NUMBER")
    @Mapping(source="recordCount.failure",target="SKIPCOUNT")
    @Mapping(source="recordCount.success",target="WRITECOUNT")
    @Mapping(source="recordCount.total",target="READCOUNT")
    @Mapping(source="recordCount.startTime",target="START_TIME")
    @Mapping(source="recordCount.endTime",target="END_TIME")
    @Mapping(source="recordCount.totalStepTime",target="TOTAL_STEP_TIME")
    @Mapping(constant="Alert Subscription",target="ENTITY_NAME")
    @Mapping(source="alertsResponse.alertsResponseData.jobId",target="JOB_ID")
    EntityRecordCount convertAlertsToMigEntity(AlertsResponse alertsResponse, RecordCount recordCount);

    @Mapping(source="migClient.gwClientId",target="GWCLIENT_ID")
    @Mapping(source="migClient.ecClientId",target="ECCLIENT_ID")
    @Mapping(expression="java(String.valueOf(migClient.getPrimaryCifUbs()))",target="CIF_NUMBER")
    @Mapping(expression="java(Integer.valueOf(0))",target="SKIPCOUNT")
    @Mapping(expression="java(Integer.valueOf(0))",target="WRITECOUNT")
    @Mapping(expression="java(Integer.valueOf(0))",target="READCOUNT")
    @Mapping(source="recordCount.startTime",target="START_TIME")
    @Mapping(source="recordCount.endTime",target="END_TIME")
    @Mapping(source="recordCount.totalStepTime",target="TOTAL_STEP_TIME")
    @Mapping(source="entity", target="ENTITY_NAME")
    @Mapping(source="migClient.jobId",target="JOB_ID")
    EntityRecordCount convertNoNicknamesToMigEntity(MigClient migClient, RecordCount recordCount, String entity);

    @Mapping(source="migClient.gwClientId",target="GWCLIENT_ID")
    @Mapping(source="migClient.ecClientId",target="ECCLIENT_ID")
    @Mapping(expression="java(String.valueOf(migClient.getPrimaryCifUbs()))",target="CIF_NUMBER")
    @Mapping(expression="java(Integer.valueOf(0))",target="SKIPCOUNT")
    @Mapping(expression="java(Integer.valueOf(0))",target="WRITECOUNT")
    @Mapping(expression="java(Integer.valueOf(0))",target="READCOUNT")
    @Mapping(source="recordCount.startTime",target="START_TIME")
    @Mapping(source="recordCount.endTime",target="END_TIME")
    @Mapping(source="recordCount.totalStepTime",target="TOTAL_STEP_TIME")
    @Mapping(source="entity", target="ENTITY_NAME")
    @Mapping(source="migClient.jobId",target="JOB_ID")
    EntityRecordCount convertNoUsersToMigEntity(MigClient migClient, RecordCount recordCount, String entity);

    @Mapping(source="nicknameResponse.nicknameResponseData.gwClientId",target="GWCLIENT_ID")
    @Mapping(source="nicknameResponse.nicknameResponseData.ecClientId",target="ECCLIENT_ID")
    @Mapping(source="nicknameResponse.nicknameResponseData.cifNumber",target="CIF_NUMBER")
    @Mapping(source="recordCount.failure",target="SKIPCOUNT")
    @Mapping(source="recordCount.success",target="WRITECOUNT")
    @Mapping(source="recordCount.total",target="READCOUNT")
    @Mapping(source="recordCount.startTime",target="START_TIME")
    @Mapping(source="recordCount.endTime",target="END_TIME")
    @Mapping(source="recordCount.totalStepTime",target="TOTAL_STEP_TIME")
    @Mapping(source="entity",target="ENTITY_NAME")
    @Mapping(source="nicknameResponse.nicknameResponseData.jobId",target="JOB_ID")
    EntityRecordCount convertNicknamesToMigEntity(NicknameResponse nicknameResponse, RecordCount recordCount, String entity);

    @Mapping(source="migClient.gwClientId",target="GWCLIENT_ID")
    @Mapping(source="migClient.ecClientId",target="ECCLIENT_ID")
    @Mapping(expression="java(String.valueOf(migClient.getPrimaryCifUbs()))",target="CIF_NUMBER")
    @Mapping(source="recordCount.failure",target="SKIPCOUNT")
    @Mapping(source="recordCount.success",target="WRITECOUNT")
    @Mapping(source="recordCount.total",target="READCOUNT")
    @Mapping(source="recordCount.startTime",target="START_TIME")
    @Mapping(source="recordCount.endTime",target="END_TIME")
    @Mapping(source="recordCount.totalStepTime",target="TOTAL_STEP_TIME")
    @Mapping(source="entity",target="ENTITY_NAME")
    @Mapping(source="migClient.jobId",target="JOB_ID")
    EntityRecordCount convertUsersToMigEntity(MigClient migClient, RecordCount recordCount, String entity);

    @Mapping(source="migClient.gwClientId",target="gwClientId")
    @Mapping(source="migClient.ecClientId",target="ecClientId")
    @Mapping(expression="java(String.valueOf(migClient.getPrimaryCifUbs()))",target="CIF_NUMBER")
    @Mapping(source="recordCount.failure",target="skipCount")
    @Mapping(source="recordCount.success",target="writeCount")
    @Mapping(source="recordCount.total",target="readCount")
    @Mapping(source="recordCount.startTime",target="startTime")
    @Mapping(source="recordCount.endTime",target="endTime")
    @Mapping(source="recordCount.totalStepTime",target="totalStepTime")
    @Mapping(expression="java(getDateFromLong(System.currentTimeMillis()))",target="createdDateTime")
    @Mapping(source="entity", target="entityName")
    @Mapping(source="migClient.jobId",target="jobId")
    MigrationEntity convertStopPaymentToMigEntity(MigClient migClient, RecordCount recordCount, String entity);


    default Timestamp getDateFromLong(Long ts) {
        return new Timestamp(ts);
    }
}
