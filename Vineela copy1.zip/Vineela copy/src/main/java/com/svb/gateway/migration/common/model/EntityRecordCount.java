package com.svb.gateway.migration.common.model;


import lombok.*;

import java.sql.Timestamp;

@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode
@ToString
@Setter
@Getter
public class EntityRecordCount {

    private String MIG_ENTITY_ID;
    private String ENTITY_NAME;
    private String JOB_ID;
    private Timestamp START_TIME;
    private Timestamp END_TIME;
    private Long TOTAL_STEP_TIME;
    private String CIF_NUMBER;
    private String ECCLIENT_ID;
    private String GWCLIENT_ID;
    private int READCOUNT;
    private int WRITECOUNT;
    private int SKIPCOUNT;

}