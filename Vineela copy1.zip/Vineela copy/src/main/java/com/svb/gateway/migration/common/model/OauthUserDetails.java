package com.svb.gateway.migration.common.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import java.io.Serializable;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    	"userId",
        "userType",
        "corporateId",
        "isTermsandConditionsAcceptanceRequired",
        "forceSecurityQuestionChangeFlag",
        "isUnifiedLoginAllowed",
        "uniqueId",
		"forceUSSDPinChangeFlag",
		"forceModeChangeFlag"
})

public class OauthUserDetails implements Serializable {

	@JsonProperty("userId")
	private String userId;
	@JsonProperty("userType")
	private String userType;
	@JsonProperty("corporateId")
	private String corporateId;
	@JsonProperty("isTermsandConditionsAcceptanceRequired")
	private String isTermsandConditionsAcceptanceRequired;
	@JsonProperty("forceSecurityQuestionChangeFlag")
	private String forceSecurityQuestionChangeFlag;
	@JsonProperty("isUnifiedLoginAllowed")
	private String isUnifiedLoginAllowed;
	@JsonProperty("uniqueId")
	private String uniqueId;
	@JsonProperty("forceUSSDPinChangeFlag")
	private String forceUSSDPinChangeFlag;
	@JsonProperty("forceModeChangeFlag")
	private String forceModeChangeFlag;
	
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getUserType() {
		return userType;
	}
	public void setUserType(String userType) {
		this.userType = userType;
	}
	public String getCorporateId() {
		return corporateId;
	}
	public void setCorporateId(String corporateId) {
		this.corporateId = corporateId;
	}
	public String getIsTermsandConditionsAcceptanceRequired() {
		return isTermsandConditionsAcceptanceRequired;
	}
	public void setIsTermsandConditionsAcceptanceRequired(String isTermsandConditionsAcceptanceRequired) {
		this.isTermsandConditionsAcceptanceRequired = isTermsandConditionsAcceptanceRequired;
	}
	public String getForceSecurityQuestionChangeFlag() {
		return forceSecurityQuestionChangeFlag;
	}
	public void setForceSecurityQuestionChangeFlag(String forceSecurityQuestionChangeFlag) {
		this.forceSecurityQuestionChangeFlag = forceSecurityQuestionChangeFlag;
	}
	public String getIsUnifiedLoginAllowed() {
		return isUnifiedLoginAllowed;
	}
	public void setIsUnifiedLoginAllowed(String isUnifiedLoginAllowed) {
		this.isUnifiedLoginAllowed = isUnifiedLoginAllowed;
	}
	public String getUniqueId() {
		return uniqueId;
	}
	public void setUniqueId(String uniqueId) {
		this.uniqueId = uniqueId;
	}

	public String getForceUSSDPinChangeFlag() {
		return forceUSSDPinChangeFlag;
	}

	public void setForceUSSDPinChangeFlag(String forceUSSDPinChangeFlag) {
		this.forceUSSDPinChangeFlag = forceUSSDPinChangeFlag;
	}

	public String getForceModeChangeFlag() {
		return forceModeChangeFlag;
	}

	public void setForceModeChangeFlag(String forceModeChangeFlag) {
		this.forceModeChangeFlag = forceModeChangeFlag;
	}
}
