package com.svb.gateway.migration.common.processors;

import static com.svb.gateway.migration.common.constants.MigrationConstants.*;

/**
 * Entities or responses should implement this interface to encapsulate retry checks. The default implementation does
 * this check provided the status from the implementing object
 */
public interface IRetry {

    String getStatus();

    /**
     * Checks if this entity can be processed, either for the first time or subsequent times.
     * If the status is SUCCESS or IGNORE it will not run again, But if it is some other state it can.
     * @return true if it can be processed
     */
    default boolean canRunAgain() {
        String status = getStatus();
        return ! (STATUS_SUCCESS.equals(status) || STATUS_IGNORE.equals(status) || STATUS_ROLLED_BACK.equals(status));
    }

}
