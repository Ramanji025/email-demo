package com.svb.gateway.migration.common.processors;

import com.svb.gateway.migration.common.exception.ServiceException;
import com.svb.gateway.migration.common.utility.RequestData;

public abstract class ProcessHandler< T > {

    protected ProcessHandler< T > next;

    public void setNext(ProcessHandler< T > next) {
        if (this.next != null) {
            ProcessHandler< T > nextHandler = this.next;

            while (nextHandler.next != null) {
                nextHandler = nextHandler.next;
            }

            nextHandler.next = next;

        } else
            this.next = next;

    }

    public abstract boolean handleRequest(RequestData< T > request) throws ServiceException;
}
