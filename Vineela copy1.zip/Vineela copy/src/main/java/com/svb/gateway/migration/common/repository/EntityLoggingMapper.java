package com.svb.gateway.migration.common.repository;

import com.svb.gateway.migration.common.model.EntityRecordCount;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;


@Mapper
@Repository
public interface EntityLoggingMapper {


    @Insert(value = {
            "INSERT INTO",
            "MIG_ENTITY",
            "(JOB_ID,ECCLIENT_ID,GWCLIENT_ID,CIF_NUMBER,ENTITY_NAME,READCOUNT,WRITECOUNT,SKIPCOUNT,START_TIME,END_TIME,TOTAL_STEP_TIME)",
            "VALUES",
            "(#{JOB_ID}, #{ECCLIENT_ID}, #{GWCLIENT_ID,jdbcType=VARCHAR}, #{CIF_NUMBER,jdbcType=VARCHAR}, #{ENTITY_NAME}, #{READCOUNT}, #{WRITECOUNT}, #{SKIPCOUNT}, #{START_TIME}, #{END_TIME}, #{TOTAL_STEP_TIME})"
    })

    Integer insertCountAndTime(EntityRecordCount entityRecordCount);
}
