package com.svb.gateway.migration.common.repository;

import com.svb.gateway.migration.common.entity.MigEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface MigEntityRepository extends JpaRepository<MigEntity, Integer> {

    @Query(value = "SELECT * from MIG_ENTITY where JOB_ID = ?1 and ENTITY_NAME NOT IN ?2 ", nativeQuery = true)
    List<MigEntity> findByJobIdAndByEntityNameNotIn(Long jobId, String[] entityNames);

    @Query(value = "SELECT * from MIG_ENTITY where JOB_ID = ?1 and ECCLIENT_ID =?2 and ENTITY_NAME NOT IN ?3 ", nativeQuery = true)
    List<MigEntity> findByJobIdAndEcClientIdAndByEntityNameNotIn(Long jobId, String ecClientId, List<String> entityNames);
}
