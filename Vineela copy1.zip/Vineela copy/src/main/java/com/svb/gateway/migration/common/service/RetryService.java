package com.svb.gateway.migration.common.service;

import lombok.Setter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.retry.annotation.Backoff;
import org.springframework.retry.annotation.EnableRetry;
import org.springframework.retry.annotation.Retryable;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.RestTemplate;

@Setter
@Service
@EnableRetry
public class RetryService {

    @Autowired
    private RestTemplate restTemplate;

    @Value("${retryDelayInMillis}")
    private long retryDelayInMillis;

    @Value("${noOfAttempts}")
    private int noOfAttempts;

    @Retryable(value = {HttpServerErrorException.class}, maxAttemptsExpression = "#{${noOfAttempts}}", backoff = @Backoff( delayExpression= "#{${retryDelayInMillis}}"))
    public <T> ResponseEntity<T> exchange(String uri, HttpMethod httpMethod,HttpEntity<?> requestEntity, ParameterizedTypeReference<T> responseType) {
        return restTemplate.exchange(uri, httpMethod, requestEntity, responseType);
    }
}
