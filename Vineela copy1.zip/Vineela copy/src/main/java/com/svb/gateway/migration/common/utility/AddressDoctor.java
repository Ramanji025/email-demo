package com.svb.gateway.migration.common.utility;

import com.svb.gateway.migration.beneficiaries.service.EntityWrapper;
import static com.svb.gateway.migration.beneficiaries.model.ValidationError.*;
import static com.svb.gateway.migration.common.constants.MigrationConstants.*;

import com.svb.gateway.migration.common.constants.MigrationConstants;
import com.svb.gateway.migration.common.logging.Message;
import com.svb.gateway.migration.common.model.AddressRequest;
import com.svb.gateway.migration.common.model.AddressResponse;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.RestTemplate;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

@Log4j2
@Component
public class AddressDoctor {

    public static final String ADDRESS_DOCTOR = "Address Doctor: ";
    @Autowired
    RestTemplate restTemplate;

    @Value(value ="${mig.addressDoctor.url}")
    String addressDoctorUrl;

    @Value(value ="${addressDoctor.allowed.country.list}")
    private String allowedCountryList;

    @Value(value ="${addressDoctor.apiKey}")
    private String addressDoctorApiKey;

    public AddressResponse validateAddress(String country, String completeAddress, EntityWrapper entityWrapper) {
        ResponseEntity<AddressResponse> addressResponseEntity = null;
        Message addressDoctorMessage=Message.create().jobId(entityWrapper.getEntity().getJOB_ID()).operation("Address Validation").srcId(entityWrapper.getEntity().getTEMPLATE_ID()!=null?String.valueOf(entityWrapper.getEntity().getTEMPLATE_ID()):String.valueOf(entityWrapper.getEntity().getWIRE_TRANSACTION_ID()));
        AddressResponse addressResponse=new AddressResponse();
        log.info(addressDoctorMessage.descr("Address doctor validation for country - "+country));
        if(isAllowed(country)){
            log.info(addressDoctorMessage.descr("Address doctor validation to be carried out as it belongs to one of the supported country list"));
            AddressRequest addressRequest = new AddressRequest();
            addressRequest.setOrignlcompleteaddr(completeAddress);
            addressRequest.setOrignlcntrycd(country);
            addressRequest.setOrignladdrln1("");
            addressRequest.setOrignladdrln2("");
            addressRequest.setOrignladdrln3("");
            addressRequest.setOrignlcitynm("");
            addressRequest.setOrignlstatecd("");
            addressRequest.setOrignlzipcd("");

            HttpHeaders headers = new HttpHeaders();
            headers.add(CONTENT_TYPE, MigrationConstants.APPLICATION_HEADER_JSON);
            headers.add(AUTHORIZATION_HEADER_NAME,addressDoctorApiKey);

            HttpEntity<AddressRequest> requestEntity = new HttpEntity<>(addressRequest, headers);

            restTemplate = new RestTemplate();

            try {
                addressResponseEntity = restTemplate.exchange(addressDoctorUrl, HttpMethod.POST, requestEntity, AddressResponse.class);
                if (addressResponseEntity.getStatusCode().equals(HttpStatus.OK)) {
                    addressResponse = addressResponseEntity.getBody();
                } else {
                    addressResponse.setValidationdesc(ADDRESS_DOCTOR+addressResponseEntity.getBody().toString());
                }
            }
            catch(HttpServerErrorException e){
                addressResponse.setValidationdesc(ADDRESS_DOCTOR+e.getMessage());
                entityWrapper.addUnexpectedError(ADDRESS_DOCTOR,e.getMessage());
            }
        }
        else{
            log.info(addressDoctorMessage.descr("Address doctor validation will not be carried out as it do not belong to one of the supported country list"));
            log.info(addressDoctorMessage.descr("Setting warning code WAR1001 as address validation was not performed"));
            addressResponse.setValidationdesc(ADDRESS_DOCTOR_COUNTRY_NOT_SUPPORTED);
            entityWrapper.addValidationError(WAR1001,RECIPIENT_ADDRESS_TO_BE_REVIEWED,ADDRESS_FIELD);
        }

        return addressResponse;
    }

    private boolean isAllowed(String country){
        Set<String> convertedCountriesList= new HashSet<String>(Arrays.asList(allowedCountryList.split(",")));
        return convertedCountriesList.contains(country);
    }

}
