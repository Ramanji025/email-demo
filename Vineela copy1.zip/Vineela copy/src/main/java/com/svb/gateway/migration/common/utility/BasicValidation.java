package com.svb.gateway.migration.common.utility;

import com.svb.gateway.migration.client.entity.MigClient;
import com.svb.gateway.migration.client.entity.StgClient;
import com.svb.gateway.migration.common.exception.ServiceException;
import com.svb.gateway.migration.user.entity.MigUser;
import com.svb.gateway.migration.user.entity.StgUser;

import java.util.List;

public class BasicValidation {

    public static void clientNullCheck(StgClient client) throws ServiceException {

        if (client == null) {
            throw new ServiceException("No Client present for provided client Id", "Client not present");
        }
    }

    public static void usersNullCheck(List<StgUser> users) throws ServiceException {

        if (users == null || users.isEmpty()) {
            throw new ServiceException("No users present for provided client Id", "Users are not present");
        }
    }

    public static void companyIdNullCheck(String newCompanyLoginId) throws ServiceException {

        if (newCompanyLoginId == null) {
            throw new ServiceException("Company Id not set", "Company id not passed");
        }
    }

    public static void oAuthNullCheck(String oAuth) throws ServiceException {

        if (oAuth == null) {
            throw new ServiceException("oAuth is null", "unable to retrieve Oauth");
        }
    }

    public static void beneClientIdNullCheck(MigClient beneClientId) throws ServiceException {

        if (beneClientId == null) {
            throw new ServiceException("Client migration is pending for which this beneficiary would be created.", "benfClientId is not migrated yet");
        }
    }

    public static void benePrimaryUserNullCheck(MigUser migUser) throws ServiceException {

        if (migUser == null) {
            throw new ServiceException("Primary user is not created for the clientId in Gateway", "benfClientId has no primary user");
        }
    }

    public static void transfersClientIdNullCheck(MigClient txnClientId) throws ServiceException {

        if (txnClientId == null) {
            throw new ServiceException("Client migration is pending for which these txns would be migrated.", "ecClientId is not migrated yet");
        }
    }

}
