package com.svb.gateway.migration.common.utility;

public interface BatchMetaDataQueries {

    String SKIP_LOG_QUERY_INSERT = "INSERT INTO mig_entity_skip_log (" +
            "        JOB_ID," +
            "        ECCLIENT_ID," +
            "        GWCLIENT_ID," +
            "        CIF_NUMBER," +
            "        ENTITY_NAME," +
            "        RECORD_DETAILS," +
            "        FAILURE_REASON," +
            "        EXCEPTION_TYPE," +
            "        CREATED_DATETIME) " +
            "        VALUES (" +
            "        :jobId," +
            "        :ecclientId," +
            "        :gwclientId," +
            "        :cifNumber," +
            "        :entityName," +
            "        :recordDetails," +
            "        :failureReason," +
            "        :exceptionType," +
            "        sysdate)";

    String ENTITY_LOG_QUERY_INSERT = "INSERT INTO MIG_ENTITY (" +
            "        MIGENTITYID," +
            "        JOB_ID," +
            "        ECCLIENT_ID," +
            "        GWCLIENT_ID," +
            "        CIF_NUMBER," +
            "        ENTITY_NAME," +
            "        READCOUNT," +
            "        WRITECOUNT," +
            "        SKIPCOUNT," +
            "        START_TIME," +
            "        END_TIME," +
            "        TOTAL_STEP_TIME," +
            "        CREATED_DATETIME) " +
            "        VALUES (" +
            "        :migEntityId," +
            "        :jobId," +
            "        :ecclientId," +
            "        :gwclientId," +
            "        :cifNumber," +
            "        :entityName," +
            "        :readCount," +
            "        :writeCount," +
            "        :skipCount," +
            "        :startTime," +
            "        :endTime," +
            "        :totalStepTime," +
            "        sysdate)";
}
