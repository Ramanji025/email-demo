package com.svb.gateway.migration.common.utility;

import com.opencsv.CSVReader;
import com.opencsv.exceptions.CsvException;
import com.svb.gateway.migration.common.exception.ServiceException;
import org.apache.commons.lang3.StringUtils;
import org.springframework.web.multipart.MultipartFile;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class CSVUtilities {

    @SuppressWarnings("unchecked")
    public static List<String[]> csvtoBeans(final MultipartFile file) throws IOException, CsvException {
        try (CSVReader csvReader = new CSVReader(new BufferedReader(new InputStreamReader(file.getInputStream())))){
            return csvReader.readAll();
        }//  readers closed automatically
    }
    public static List<String> parseSingleColumnCSV(final MultipartFile csvFile) throws ServiceException, IOException, CsvException {
        if (!(Objects.requireNonNull(csvFile.getOriginalFilename()).endsWith(".csv"))) {
            throw new ServiceException("FILE IS NOT OF CSV FORMAT");
        }
        List<String[]> csvBeans = CSVUtilities.csvtoBeans(csvFile);
        final List<String> clientsList = new ArrayList<>();
        if (csvBeans.isEmpty()) {
            throw new ServiceException("CSV_FILE_SHOULD_NOT_BE_EMPTY");
        }
        for (String[] cs : csvBeans) {
            String ecClientId = cs[0];
            if (StringUtils.isBlank(ecClientId)) {
                throw new ServiceException("Error record EcclientId -->" + ecClientId);
            }
            //Preparing a map to identify the duplicate ecClientId
            if (clientsList.contains(ecClientId)) {
                throw new ServiceException("Duplicate record in CSV file " + ecClientId);
            } else {
                clientsList.add(ecClientId.trim());
            }
        }
        return  clientsList;
    }
}
