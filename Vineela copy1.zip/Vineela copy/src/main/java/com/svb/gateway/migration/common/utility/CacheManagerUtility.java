package com.svb.gateway.migration.common.utility;

import com.svb.gateway.migration.common.exception.ServiceException;
import com.svb.gateway.migration.common.logging.Message;
import com.svb.gateway.migration.common.model.OauthResponse;
import com.svb.gateway.migration.common.repository.GatewayOAuthRepository;
import lombok.extern.log4j.Log4j2;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cache.Cache;
import org.springframework.cache.CacheManager;
import org.springframework.stereotype.Component;

import javax.validation.constraints.NotNull;
import java.util.Objects;

@Component
@Log4j2
public class CacheManagerUtility {

    private static final String GDO_USER = "GDO";
    private static final String MIGRATION_VT_USER = "VTUSER";

    @Value("${oAuth.cache.name}")
    private String authCacheName;
    @Autowired
    private GatewayOAuthRepository authRepository;

    @Autowired
    private CacheManager cacheManager;

    public String getValueOnlyString(@NotNull final String cacheName, @NotNull final String key) {
        Cache cache = cacheManager.getCache(cacheName);
        return cache.get(key, String.class);
    }

    public boolean put(@NotNull final String cacheName, @NotNull final Object key, final Object value) {
        try {
            Cache cache = cacheManager.getCache(cacheName);
            cache.put(key, value);
            return true;
        } catch (Exception e) {
            log.info(e.getMessage());
            return false;
        }
    }

    public String getOauthToken() throws ServiceException {
        Message logMessage = Message.create().operation("oAuth token");
        Cache cache = cacheManager.getCache(authCacheName);
        OauthResponse token = cache.get(MigrationConstants.TOKEN, OauthResponse.class);
        if (Objects.nonNull(token)) {
            log.info(logMessage.descr("oAuth token of GDO user fetched from cache"));
            return token.getAccess_token();
        } else {
            OauthResponse oauthResponse = authRepository.getUserAccessToken(GDO_USER);
            cache.put(MigrationConstants.TOKEN, oauthResponse);
            log.info(logMessage.descr("oAuth token of GDO user returned with newly generated value"));
            return oauthResponse.getAccess_token();
        }
    }

    public String getVTToken() throws ServiceException {
        Message logMessage = Message.create().operation("oAuth token");
        Cache cache = cacheManager.getCache(authCacheName);
        OauthResponse vtToken = cache.get(MigrationConstants.VT_TOKEN, OauthResponse.class);
        if (Objects.nonNull(vtToken)) {
            log.info(logMessage.descr("oAuth token of VT user fetched from cache"));
            return vtToken.getAccess_token();
        } else {
            OauthResponse oauthVtResponse = authRepository.getUserAccessToken(MIGRATION_VT_USER);
            cache.put(MigrationConstants.VT_TOKEN, oauthVtResponse);
            log.info(logMessage.descr("oAuth token of VT user returned with newly generated value"));
            return oauthVtResponse.getAccess_token();
        }
    }
}
