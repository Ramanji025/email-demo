package com.svb.gateway.migration.common.utility;

import com.svb.gateway.migration.common.exception.ServiceException;
import com.svb.gateway.migration.common.logging.Message;
import lombok.extern.log4j.Log4j2;
import org.apache.commons.lang3.math.NumberUtils;
import org.apache.commons.text.StringEscapeUtils;

import java.util.List;
import java.util.Objects;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Log4j2
public class CommonValidator {
    private static final Pattern ecClientIdPattern = Pattern.compile("[a-zA-Z]{4}[0-9]{4}");
    private static final Pattern gwClientPattern = Pattern.compile("GW[a-z]{4}[0-9]{4}");
    private static final Pattern gwValidAbaPattern = Pattern.compile("[0-9]{8}|[0-9]{9}");
    private static final Pattern gwValidSwiftBicPattern = Pattern.compile("[a-zA-Z0-9]{8}|[a-zA-Z0-9]{11}");

    public static boolean isEcClientIdFormatValid(String ecClientId){
        if (ecClientId == null) return false;
        Matcher m = ecClientIdPattern.matcher(ecClientId);
        return m.matches();
    }

    public static void ecClientIdCheck(String ecClientId) throws ServiceException{
        if (!isEcClientIdFormatValid(ecClientId)) {
            ecClientId = StringEscapeUtils.escapeJava(ecClientId);
            String error = "ecClient id " + ecClientId + " has Invalid Format";
            log.error(Message.create().descr(error).clientId(ecClientId));
            throw new ServiceException("invalid ecClientId", error);
        }
    }

    public static void jobIdCheck(Long jobId) throws ServiceException {
        if (NumberUtils.LONG_ZERO.equals(jobId) || jobId == null) {
            String error = "job id " + jobId + " is Invalid";
            log.error(Message.create().descr(error).jobId(jobId));
            throw new ServiceException("invalid jobId", error);
        }
    }


    public static boolean isGwClientIdFormatValid(String gwClientId){
        if (gwClientId == null) return false;
        Matcher m = gwClientPattern.matcher(gwClientId);
        return m.matches();
    }

    public static void gwClientIdCheck(String gwClientId) throws ServiceException{
        if (!isGwClientIdFormatValid(gwClientId)) {
            gwClientId = StringEscapeUtils.escapeJava(gwClientId);
            String error = "gwClient id " + gwClientId + " has Invalid Format";
            log.error(Message.create().descr(error).clientId(gwClientId));
            throw new ServiceException("invalid gwClientId", error);
        }
    }

    public static boolean isBankIdentifierAba(String bankIdentifier){
        if (bankIdentifier == null) return false;
        Matcher m = gwValidAbaPattern.matcher(bankIdentifier);
        return m.matches();
    }

    public static boolean isBankIdentifierSwiftBic(String bankIdentifier){
        if (bankIdentifier == null) return false;
        Matcher m = gwValidSwiftBicPattern.matcher(bankIdentifier);
        return m.matches();
    }
}
