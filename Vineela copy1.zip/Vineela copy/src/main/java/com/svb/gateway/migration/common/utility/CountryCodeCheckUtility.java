package com.svb.gateway.migration.common.utility;

import com.svb.gateway.migration.common.entity.CountryCodeEntity;
import com.svb.gateway.migration.common.repository.CountryCodeRepository;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Log4j2
@Component
public class CountryCodeCheckUtility {

    @Autowired
    CountryCodeRepository countryCodeRepository;

    public static Map<String, String> countryCodeMap=new HashMap<>();

    public Map<String, String> getCountryCodeMap(){
        if(countryCodeMap.isEmpty()){
            List<CountryCodeEntity> countryCodeEntityList=countryCodeRepository.findAll();
            countryCodeMap=countryCodeEntityList.stream().collect(Collectors.toMap(CountryCodeEntity::getCountry,CountryCodeEntity::getIsoCode));
        }
        return countryCodeMap;
    }

}
