package com.svb.gateway.migration.common.utility;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.svb.gateway.migration.client.entity.MigClient;

import java.util.List;
import java.util.stream.Collectors;

import static com.svb.gateway.migration.common.utility.MigrationConstants.*;

public class GlobalUtilty {

    //TODO: remove this and use what is configured in ApplicationConfig
    // Unit tests were failing because the correct mocked object is not getting injected
    public static ObjectMapper getObjectMapper() {
        ObjectMapper objectMapper = new ObjectMapper();
        objectMapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
        return objectMapper;
    }

    public static String getClientIds(List<MigClient> migratingClients) {

        return migratingClients.stream().map(
                clientId -> PARANTHESIS_OPEN
                        + SINGLE_QUOTE
                        + clientId.getEcClientId()
                        + SINGLE_QUOTE
                        + COMMA
                        + ZERO
                        + PARANTHESIS_CLOSE)
                .collect(Collectors.joining(COMMA));
    }
}
