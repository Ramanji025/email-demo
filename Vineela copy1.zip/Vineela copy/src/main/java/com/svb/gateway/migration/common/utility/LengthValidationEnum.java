package com.svb.gateway.migration.common.utility;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.svb.gateway.migration.beneficiaries.entity.StgToTargetBeneEntity;

import java.util.HashMap;
import java.util.Map;

public enum LengthValidationEnum {
    BENE_NAME(70,"recipientName"),
    BENE_NICKNAME(40, "recipientNickname"),
    BENE_ACCOUNT_NUMBER_US(17, "accountNumber"),
    BENE_ACCOUNT_NUMBER_NON_US(34, "accountNumber"),
    BENE_STREET(70,"streetAddress"),
    BENE_CITY_US(25,"streetAddress"),
    BENE_STATE_US(2,"streetAddress"),
    BENE_ZIP_US(10,"streetAddress"),
    BENE_CITY_NON_US(32,"streetAddress"),
    BENE_STATE_NON_US(20,"streetAddress"),
    BENE_ZIP_NON_US(10,"streetAddress"),
    BENE_ROUTING_NUMBER(9,"routingNumber"),
    BENE_SWIFT(8,"routingNumber"),
    BENE_BIC(11,"routingNumber");


    private int length;
    private String field;
    LengthValidationEnum(int length, String field) {
        this.length = length;
        this.field = field;
    }

    public int getLength(){
        return length;
    }
    public String getField(){
        return field;
    }

//    private static Map<Integer, StgToTargetBeneEntity.PAYEE_TYPE> map = new HashMap<>();
//    static {
//        for (StgToTargetBeneEntity.PAYEE_TYPE type : StgToTargetBeneEntity.PAYEE_TYPE.values()) {
//            map.put(type.code, type);
//        }
//    }
//    private int code ;
//
//    LengthValidationEnum (int code)
//    {
//        this.code = code ;
//    }
//
//    public int getCode(){
//        return code;
//    }
//
//    public static StgToTargetBeneEntity.PAYEE_TYPE valueOf(int code) {
//        return map.get(code);
//    }


    @JsonCreator
    public static LengthValidationEnum fromLength(String text) {
        for (LengthValidationEnum b : LengthValidationEnum.values()) {
            if (String.valueOf(b.length).equals(text)) {
                return b;
            }
        }
        return null;
    }
}
