package com.svb.gateway.migration.common.utility;

import com.svb.gateway.migration.ipay.batch.util.IPayConstants;
import com.svb.gateway.migration.payments.entity.IpayStagingPayment;
import org.springframework.util.StringUtils;

public class PaymentUtils {

    public static boolean inValidRecurringPayment(IpayStagingPayment ipayStagingPayment) {
        if(IPayConstants.SKIPPED_PAYMENT_VALUE.equals(ipayStagingPayment.getSkippedPayment()) || !StringUtils.isEmpty(ipayStagingPayment.getOverrideAmount())
                || !StringUtils.isEmpty(ipayStagingPayment.getOverrideSubsidaryBankId())){
            return true;
        }
        boolean flag= ipayStagingPayment.getPaymentFrequency()!= null && !IPayConstants.getValidFrequencies().contains(ipayStagingPayment.getPaymentFrequency());
        return flag;
    }
}
