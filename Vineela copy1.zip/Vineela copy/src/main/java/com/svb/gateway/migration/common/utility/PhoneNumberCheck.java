package com.svb.gateway.migration.common.utility;

public class PhoneNumberCheck {

    public static boolean isInvalidPhoneNumber(String phoneNumber){
        boolean isInvalid =false;

        if(null == phoneNumber){
            isInvalid = true;
            return isInvalid;
        }

        return isInvalid;

    }
}
