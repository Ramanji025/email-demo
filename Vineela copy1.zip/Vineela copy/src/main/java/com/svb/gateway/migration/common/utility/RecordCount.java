package com.svb.gateway.migration.common.utility;

import lombok.Getter;
import lombok.Setter;

import java.sql.Timestamp;

import static com.svb.gateway.migration.common.constants.MigrationConstants.STATUS_SUCCESS;

@Getter
@Setter
public class RecordCount {
    Integer total = 0;
    Integer success = 0;
    Integer failure = 0;
    private Timestamp startTime;
    private Timestamp endTime;
    private Long totalStepTime;


    public RecordCount() {
        startTime=new Timestamp(System.currentTimeMillis());
    }

    public Long getTotalStepTime(){
        if(endTime==null || startTime==null)
            return -1l;

        return (endTime.getTime()-startTime.getTime())/1000;
    }

    public void addSuccess(){
        success++;
        total++;
    }

    public void addFailure(){
        failure++;
        total++;
    }

    public void updateCounter(boolean isSuccess) {
        if (isSuccess) {
            addSuccess();
        } else {
            addFailure();
        }
    }

    public void updateCounter(String status) {
        if (STATUS_SUCCESS.equalsIgnoreCase(status)) {
            addSuccess();
        } else {
            addFailure();
        }
    }

    public void stopTime(){
        endTime = new Timestamp(System.currentTimeMillis());
    }
}
