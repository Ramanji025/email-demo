/**
 * 
 */
package com.svb.gateway.migration.ec2stage.controller;

import com.svb.gateway.migration.common.exception.BadRequestException;
import com.svb.gateway.migration.common.exception.ServiceException;
import com.svb.gateway.migration.common.logging.Message;
import com.svb.gateway.migration.common.model.Error;
import com.svb.gateway.migration.common.utility.CommonValidator;
import com.svb.gateway.migration.common.utility.MigrationConstants;
import com.svb.gateway.migration.common.utility.MigrationErrorCodeEnum;
import com.svb.gateway.migration.ec2stage.api.EC2StageApi;
import com.svb.gateway.migration.ec2stage.model.Ec2StageMigrationRequest;
import com.svb.gateway.migration.ec2stage.service.ECService;
import com.svb.gateway.migration.job.model.CreateJobResponse;
import com.svb.gateway.migration.job.model.CreateJobResponseData;
import lombok.extern.log4j.Log4j2;
import org.apache.commons.lang3.StringUtils;
import org.springframework.batch.core.*;
import org.springframework.batch.core.configuration.JobRegistry;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.batch.core.repository.JobRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;
import springfox.documentation.annotations.ApiIgnore;

import javax.validation.Valid;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * @author suvaidya
 *
 */
@Log4j2
@ApiIgnore
@RestController
public class EC2StageController implements EC2StageApi {

	Message message=Message.create().operation("EC2Stage");
	@Autowired
	@Qualifier("migJobLauncher")
	private JobLauncher jobLauncher;
	
	@Autowired
	private JobRegistry jobRegistry;

	@Autowired
	JobRepository jobRepository;

	private ECService ecService;

	@Value("${migration.ecclient.id.length}")
	private Integer ecClientIdLength;

	@Autowired
	public void setEcService(ECService ecService) {
		this.ecService = ecService;
	}

	@Override
	public ResponseEntity<Object> migrateEc2Stage(@Valid Ec2StageMigrationRequest request, String enable, String overrideFlag) throws Exception {
		return migrateEc2StageInternal(request);
	}

	public ResponseEntity<Object> migrateEc2StageInternal(Ec2StageMigrationRequest request) throws JobExecutionException, ServiceException {

		log.info(message.descr("migrateEc2Stage() started Job Id --> {}").jobId(request.getJobId()));
		CreateJobResponse jobRes = launchJob(request.getClientIds(), request.getJobId());
		log.info(message.descr("migrateEc2Stage() scheduled").jobId(request.getJobId()));
		return ResponseEntity.accepted().body(jobRes);
	}

	/**
	 * Method launch migration job passing the job parameters i.e., list of client
	 * Ids and job id
	 * 
	 * @param clientIds
	 * @param jobId
	 * @return
	 * @throws Exception
	 */
	private CreateJobResponse launchJob(List<String> clientIds, long jobId)
			throws ServiceException, JobExecutionException {

		JobParametersBuilder builder = new JobParametersBuilder();
		builder.addLong(MigrationConstants.JOB_ID_KEY, jobId);
		CreateJobResponse response = null;

		if (!clientIds.isEmpty()) {
			log.info(message.descr("launchJob() request for client ID's Count :: "+ clientIds.size()));

			validateClientIds(clientIds);

			// Validate if clients have migration status set to "Due for migration in eC"
			List<String> clientNames = ecService.validateECMigrationStatus(clientIds);
			if(!clientNames.isEmpty()) {
				log.info(message.descr(" Following eC clients have incorrect migration status :: "+ clientNames));
				throw new BadRequestException(MigrationErrorCodeEnum.MIGRATION_INVALID_EC_MIGRATION_STATUS, " Incorrect Migration Status for clients :: " + clientNames);
			}
			// get client Ids list as comma separated values
			builder.addString(MigrationConstants.CLIENT_IDS,
					clientIds.stream()
							.map(clientId -> MigrationConstants.PARANTHESIS_OPEN + MigrationConstants.SINGLE_QUOTE
									+ clientId + MigrationConstants.SINGLE_QUOTE + MigrationConstants.COMMA
									+ MigrationConstants.ZERO + MigrationConstants.PARANTHESIS_CLOSE)
							.collect(Collectors.joining(MigrationConstants.COMMA)));

			Job job = jobRegistry.getJob(MigrationConstants.MIGRATE_EC_DATA_JOB);
			JobExecution jobExecution = jobLauncher.run(job, builder.toJobParameters());
			String status = jobExecution.getStatus().name();
			log.info(message.descr("launchJob() - SCHEDULED").jobId(jobId).status(status));
			response = new CreateJobResponse(new CreateJobResponseData(jobId, status));
		} else {
			response = buildErrorResponse();
		}
		return response;
	}



	// This method is to validate clientId if it's empty or null or duplicate or
	// length is not 8
	public void validateClientIds(List<String> clientIds) throws ServiceException {
		final Set<String> clientsSet = new HashSet<>();
		for (String clientId : clientIds) {
			if (StringUtils.isBlank(clientId)) {
				throw new ServiceException("Empty ClientId exists in the list.");
			}
			
			//Sanitize check
			CommonValidator.ecClientIdCheck(clientId); 
			
			
			// Preparing a set to identify the duplicate ClientId
			if (clientsSet.contains(clientId)) {
				throw new ServiceException("Duplicate record exist -> " + clientId);
			} else {
				clientsSet.add(clientId);
			}

			if (clientId.length() != ecClientIdLength) {
				throw new ServiceException("Client Id length should be " + ecClientIdLength);
			}
		}
		clientsSet.clear();
	}

	private CreateJobResponse buildErrorResponse() {

		List<Error> errList = new ArrayList<>();
		Error error = new Error("1", "Minimum one client Id is required!");
		errList.add(error);

		CreateJobResponse response = new CreateJobResponse();
		response.setErrors(errList);
		return response;
	}
}
