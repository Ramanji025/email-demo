package com.svb.gateway.migration.ec2stage.dao;

import com.svb.gateway.migration.common.utility.MigrationConstants;
import com.svb.gateway.migration.common.utility.MigrationQueries;
import com.svb.gateway.migration.ec2stage.model.ClientDetail;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.MessageFormat;
import java.util.List;
import java.util.stream.Collectors;

@Repository
public class ECDao {

    @Qualifier("eConnectJdbcTemplate")
    @Autowired
    private JdbcTemplate eConnectJdbcTemplate;

    public List<ClientDetail> getECMigrationStatus(List<String> clientIds) {
        String stringClientIds = clientIds.stream()
                .map(clientId -> MigrationConstants.PARANTHESIS_OPEN + MigrationConstants.SINGLE_QUOTE
                        + clientId + MigrationConstants.SINGLE_QUOTE + MigrationConstants.COMMA
                        + MigrationConstants.ZERO + MigrationConstants.PARANTHESIS_CLOSE)
                .collect(Collectors.joining(MigrationConstants.COMMA));
        String query = MessageFormat.format(MigrationQueries.SELECT_EC_CLIENT_MIGRATION_STATUS, stringClientIds);
        return eConnectJdbcTemplate.query(query, new ClientDetailsRowMapper());
    }

    public class ClientDetailsRowMapper implements RowMapper<ClientDetail> {

        @Override
        public ClientDetail mapRow(ResultSet rs, int rowNum) throws SQLException {
            ClientDetail clientDetail = new ClientDetail();
            clientDetail.setClientLoginName(rs.getString("CLIENT_LOGIN_NAME"));
            clientDetail.setMigrationStatus(rs.getInt("MIGRATION_STATUS"));
            return clientDetail;
        }
    }
}
