package com.svb.gateway.migration.ec2stage.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@ToString
public class ClientDetail {
    private String clientLoginName;
    private Integer migrationStatus;
}
