package com.svb.gateway.migration.ec2stage.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.svb.gateway.migration.common.exception.ServiceException;
import com.svb.gateway.migration.common.logging.Message;
import com.svb.gateway.migration.common.utility.MigrationConstants;
import com.svb.gateway.migration.ec2stage.dao.ECDao;
import com.svb.gateway.migration.ec2stage.model.ClientDetail;
import org.apache.commons.lang3.ObjectUtils;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
@Log4j2
@Service
public class ECService {

    public static final String ERROR_IN_UPDATING_THE_CLIENT_STATUS_IN_E_C = "Error in updating the client status in eC";
    Message message=Message.create().operation("updatingClientStatus");
    public static final String CREATE_JOB = "createJob";
    private RestTemplate restTemplate;
    private static final String EC_STATUS_SUCCESS_CODE="17000";

    @Autowired
    private ECDao ecDao;

    @Value("${ec.updateStatus.url}")
    private String ecClientUrl;

    @Value("${ec.enable.validation}")
    private boolean enableECValidation;

    @Autowired
    public void setRestTemplate(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    }


    public List<String> validateECMigrationStatus(List<String> clientIds) {
        if(!enableECValidation) {
            return new ArrayList<>();
        }

        List<ClientDetail> clientDetails = ecDao.getECMigrationStatus(clientIds);
        return clientDetails.stream()
                .filter(c -> c.getMigrationStatus() != MigrationConstants.EC_MIGRATION_STATUS_IN_PROGRESS)
                .map(ClientDetail::getClientLoginName)
                .collect(Collectors.toList());
    }

    public String updateClientDetailsEc(List<String> clientIds, String enable, String overrideFlag) throws ServiceException, JsonProcessingException {

        ObjectMapper objMapper = new ObjectMapper();
        boolean responseStatus = false;
        String statusMessage="";
        Map<String, Object> data = new HashMap<>();
        data.put(MigrationConstants.EC_CLIENT_NAME_JSON_KEY, clientIds);
        data.put(MigrationConstants.ENABLE_CLIENT, enable);
        data.put(MigrationConstants.IS_OVERRIDE, overrideFlag);

        Map<String, Object> eCUpdateStatusRequest = new HashMap<>();
        eCUpdateStatusRequest.put("data", data);
        eCUpdateStatusRequest.put("meta", new HashMap<>());

        HttpHeaders headers = new HttpHeaders();
        ResponseEntity<Object> responseObject;
        headers.setContentType(MediaType.APPLICATION_JSON);
        HttpEntity<?> requestEntity = new HttpEntity<>(eCUpdateStatusRequest, headers);

        try {
            responseObject = restTemplate.exchange(ecClientUrl, HttpMethod.POST, requestEntity, Object.class);

            if((responseObject.hasBody()) && (responseObject.getStatusCode() == HttpStatus.OK)
                    && (ObjectUtils.isNotEmpty(responseObject))) {
                Map<String, Object> response = new HashMap<>((Map<String, Object>) responseObject.getBody());

                if(!response.isEmpty() && response.get("data") != null ) {
                    Map<String, Object> dataResponse = (HashMap<String, Object>) response.get("data");
                    responseStatus = EC_STATUS_SUCCESS_CODE.equalsIgnoreCase(String.valueOf(dataResponse.get("statusCode")));
                  	if(!responseStatus){
                        return objMapper.writeValueAsString(response);
                    }
                    statusMessage = (String) dataResponse.get("statusMessage");
                    log.info(Message.create().descr("Econnect API call for disabling/Enabling Client success with status: "+responseStatus+ ": "+statusMessage).operation(CREATE_JOB));
                    return "SUCCESS";
                }
                else if(!response.isEmpty() && response.get("messages")!=null ) {

                    return objMapper.writeValueAsString(response);

                }
                else{
                    return ERROR_IN_UPDATING_THE_CLIENT_STATUS_IN_E_C;
                }
            } else {
                return ERROR_IN_UPDATING_THE_CLIENT_STATUS_IN_E_C;
            }

        } catch (Exception exception) {
            log.error(message.descr(ERROR_IN_UPDATING_THE_CLIENT_STATUS_IN_E_C + "::"+exception));

            return exception.getMessage().toString().replaceAll("\\\"", "'");
        }
    }
}
