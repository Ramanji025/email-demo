package com.svb.gateway.migration.healthcheck.api;

import com.svb.gateway.migration.common.exception.ServiceException;
import com.svb.gateway.migration.healthcheck.model.HealthCheckResponse;
import io.swagger.annotations.Api;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Api(value= "HealthCheck", tags = "HealthCheck Controller")
@RequestMapping("/v1/api/")
public interface HealthCheckApi {

    @GetMapping(value = "/health",
            produces = {"application/json"},
            consumes = {"*/*"})
    @PreAuthorize("hasAnyAuthority(@migrationServiceConfig.getViewAndExecute())")
    ResponseEntity<HealthCheckResponse> healthCheck() throws ServiceException;
}
