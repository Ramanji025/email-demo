package com.svb.gateway.migration.healthcheck.controller;

import com.svb.gateway.migration.common.exception.ServiceException;
import com.svb.gateway.migration.healthcheck.api.HealthCheckApi;
import com.svb.gateway.migration.healthcheck.model.HealthCheckResponse;
import com.svb.gateway.migration.healthcheck.service.HealthCheckService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class HealthCheckController implements HealthCheckApi {

    private final HealthCheckService healthCheckService;

    @Autowired
    public HealthCheckController(HealthCheckService healthCheckService){
        this.healthCheckService=healthCheckService;
    }

    @Override
    public ResponseEntity<HealthCheckResponse> healthCheck() throws ServiceException {
        return new ResponseEntity<>(healthCheckService.preValidate(), HttpStatus.OK);
    }
}
