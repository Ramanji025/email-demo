package com.svb.gateway.migration.healthcheck.service;

import com.svb.gateway.migration.beneficiaries.entity.StgToTargetBeneEntity;
import com.svb.gateway.migration.beneficiaries.model.BankBranchResponse;
import com.svb.gateway.migration.beneficiaries.model.IbanCountryRulesResponse;
import com.svb.gateway.migration.beneficiaries.service.BeneficiaryValidationUtility;
import com.svb.gateway.migration.beneficiaries.service.EntityWrapper;
import com.svb.gateway.migration.client.model.Bundles;
import com.svb.gateway.migration.client.service.ClientService;
import com.svb.gateway.migration.common.constants.MigrationConstants;
import com.svb.gateway.migration.common.exception.ServiceException;
import com.svb.gateway.migration.common.logging.Message;
import com.svb.gateway.migration.common.model.AddressResponse;
import com.svb.gateway.migration.common.utility.AddressDoctor;
import com.svb.gateway.migration.common.utility.CacheManagerUtility;
import com.svb.gateway.migration.healthcheck.model.HealthCheckResponse;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Log4j2
@Transactional
public class HealthCheckService {

    private static final String COUNTRY = "US";
    private static final String IBAN_COUNTRY = "DE";
    private static final String VALID_ADDRESS = "3003 Tasman Dr. Santa Clara, CA 95054";

    @Value(value = "${gateway.healthCheck.iban}")
    String healthCheckSvbIban;

    @Value(value = "${gateway.healthCheck.nonUSBankIdentifier}")
    String healthCheckSvbNonUsBankIdentifier;

    @Value(value = "${gateway.healthCheck.svbUSBankIdentifier}")
    String healthCheckSvbUsBankIdentifier;

    @Autowired
    BeneficiaryValidationUtility beneficiaryValidationUtility;

    @Autowired
    AddressDoctor addressDoctor;

    @Autowired
    ClientService clientService;

    @Autowired
    CacheManagerUtility cacheManagerUtility;

    public HealthCheckResponse preValidate() throws ServiceException {

        Message logMessage=Message.create().operation("Pre-validation of endpoint reachability");
        HealthCheckResponse healthCheckResponse=new HealthCheckResponse();
        try {
        //Create EntityWrapper
        EntityWrapper entityWrapper=setUpPreRequisiteData();

        //Get bankUser oAuth token needed for Admin ext
        String oAuth = cacheManagerUtility.getOauthToken();

        preValidateAddressDoctor(healthCheckResponse,COUNTRY, VALID_ADDRESS,entityWrapper,logMessage);

        preValidateAdminExt(healthCheckResponse,oAuth,logMessage);

        preValidateOCHEndPoint(healthCheckResponse,entityWrapper,logMessage);

        preValidateIbanEndPoints(healthCheckResponse,entityWrapper,IBAN_COUNTRY, logMessage);

        setHealthCheckStatus(healthCheckResponse);


        } catch (Exception exception) {
            String errorMessage = "Error during preValidate endpoint reachability : "+exception.getMessage();
            log.error(logMessage.descr(errorMessage));
            healthCheckResponse.addMessage(errorMessage);
            healthCheckResponse.setStatus(MigrationConstants.STATUS_FAILURE);
        }
        return healthCheckResponse;
    }

    private void preValidateAddressDoctor(HealthCheckResponse healthCheckResponse,String country, String address, EntityWrapper entityWrapper,Message logMessage){
        //validate Address doctor
        AddressResponse addressResponse = addressDoctor.validateAddress(country,address,entityWrapper);
        if(addressResponse!=null && "C4".equalsIgnoreCase(addressResponse.getValidationscore())){
            String successMessage="Address doctor endpoint reachable.";
            log.info(logMessage.descr(successMessage));
            healthCheckResponse.addMessage(successMessage);
        }
        else if(addressResponse!=null && addressResponse.getValidationdesc()!=null){
            String errorMessage="Address doctor endpoint has issues : "+addressResponse.getValidationdesc();
            log.info(logMessage.descr(errorMessage));
            healthCheckResponse.addMessage(errorMessage);
            healthCheckResponse.setStatus(MigrationConstants.STATUS_FAILURE);
        }
        else{
            String errorMessage="Address doctor endpoint has unknown exceptions, check logs";
            log.info(logMessage.descr(errorMessage));
            healthCheckResponse.addMessage(errorMessage);
            healthCheckResponse.setStatus(MigrationConstants.STATUS_FAILURE);
        }

    }

    private void preValidateAdminExt(HealthCheckResponse healthCheckResponse, String oAuth, Message logMessage){
        Bundles bundles = clientService.getBundles(oAuth,null,null);
        if(bundles==null){
            String errorMessage="Admin Ext endpoint has issues ";
            log.info(logMessage.descr(errorMessage));
            healthCheckResponse.addMessage(errorMessage);
            healthCheckResponse.setStatus(MigrationConstants.STATUS_FAILURE);
        }
        else{
            String successMessage="Admin Ext endpoint reachable.";
            log.info(logMessage.descr(successMessage));
            healthCheckResponse.addMessage(successMessage);
        }
    }

    private void preValidateOCHEndPoint(HealthCheckResponse healthCheckResponse, EntityWrapper entityWrapper, Message logMessage){
        BankBranchResponse bankBranchResponse = beneficiaryValidationUtility.validateBankBranchAndFetchList(entityWrapper);
        if(!bankBranchResponse.isValidated()){
            String errorMessage="OCH endpoint has issues.";
            log.info(logMessage.descr(errorMessage));
            healthCheckResponse.addMessage(errorMessage);
            healthCheckResponse.setStatus(MigrationConstants.STATUS_FAILURE);
        }
        else{
            String successMessage="OCH endpoint reachable.";
            log.info(logMessage.descr(successMessage));
            healthCheckResponse.addMessage(successMessage);
        }
    }

    private void preValidateIbanEndPoints(HealthCheckResponse healthCheckResponse, EntityWrapper entityWrapper, String country, Message logMessage){
        entityWrapper.getEntity().setBENEFICIARY_BANK_IDENTIFIER(healthCheckSvbNonUsBankIdentifier);
        IbanCountryRulesResponse ibanCountryRulesResponse = beneficiaryValidationUtility.validateIbanCountrySpecificRulesAndValidation(entityWrapper,country,null,null);
        if(!ibanCountryRulesResponse.isValidated()){
            String errorMessage="IBAN endpoint has issues.";
            log.info(logMessage.descr(errorMessage));
            healthCheckResponse.addMessage(errorMessage);
            healthCheckResponse.setStatus(MigrationConstants.STATUS_FAILURE);
        }
        else{
            String successMessage="IBAN endpoint reachable.";
            log.info(logMessage.descr(successMessage));
            healthCheckResponse.addMessage(successMessage);
        }
    }

    private void setHealthCheckStatus(HealthCheckResponse healthCheckResponse){
        if(null != healthCheckResponse && !MigrationConstants.STATUS_FAILURE.equalsIgnoreCase(healthCheckResponse.getStatus())){
            healthCheckResponse.setStatus(MigrationConstants.STATUS_SUCCESS);
        }
    }

    private EntityWrapper setUpPreRequisiteData(){
        StgToTargetBeneEntity stgToTargetBeneEntity = new StgToTargetBeneEntity();
        stgToTargetBeneEntity.setBENEFICIARY_BANK_IDENTIFIER(healthCheckSvbUsBankIdentifier);
        stgToTargetBeneEntity.setBENEFICIARY_ACCOUNT(healthCheckSvbIban);
        return new EntityWrapper(stgToTargetBeneEntity);
    }
}
