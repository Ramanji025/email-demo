package com.svb.gateway.migration.ipay.api;

import com.svb.gateway.migration.common.constants.ErrorMessageConstants;
import com.svb.gateway.migration.common.constants.RegexConstants;
import com.svb.gateway.migration.common.exception.ServiceException;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import org.springframework.batch.core.JobExecutionException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Pattern;

@Api(value = "iPay Cleanup", tags = "iPay Cleanup Controller")
@RequestMapping("/v1/api/ipay")
public interface IPayApi {

    @ApiOperation(value = "Endpoint for triggering the IPay Recurring Payments Batch Job",
            nickname = "migrateIPaySinglePayments", notes = "Migrate IPay Recurring Payments")
    @ApiResponses(value = {
            @ApiResponse(code = 201, message = "Job Request Accepted "),
            @ApiResponse(code = 401, message = "Unauthorized"),
            @ApiResponse(code = 400, message = "Invalid Client Id"),
            @ApiResponse(code = 403, message = "Forbidden"),
            @ApiResponse(code = 500, message = "Service unavailable ")})
    @PostMapping("/ipay2Stage")
    @ResponseStatus(HttpStatus.ACCEPTED)
    @PreAuthorize("hasAuthority(@migrationServiceConfig.getAuthExecute())")
    ResponseEntity<Object> migrateIPay2Stage(@Valid
                                             @RequestParam
                                             @NotEmpty
                                             @Pattern(regexp = RegexConstants.EC_CLIENT_ID_PATTERN,
                                                     message = ErrorMessageConstants.INVALID_CLIENT_ID_MESSAGE) String ecClientId,
                                             @RequestParam
                                             Integer jobId) throws JobExecutionException, ServiceException;

    @ApiOperation(value = "Endpoint for triggering the IPay Truncate tables",
            nickname = "truncateIpayTab;es", notes = "IPay Src tables data clean up")
    @ApiResponses(value = {
            @ApiResponse(code = 201, message = " Request Accepted "),
            @ApiResponse(code = 401, message = "Unauthorized"),
            @ApiResponse(code = 400, message = "Invalid request"),
            @ApiResponse(code = 403, message = "Forbidden"),
            @ApiResponse(code = 500, message = "Service unavailable ")})
    @PostMapping("/cleanupIPaySrc")
    @ResponseStatus(HttpStatus.ACCEPTED)
    @PreAuthorize("hasAuthority(@migrationServiceConfig.getAuthExecute())")
    ResponseEntity<Object> truncateIPaySourceTables() throws ServiceException;
}
