package com.svb.gateway.migration.ipay.service;

import com.svb.gateway.migration.job.model.CreateJobResponse;
import org.springframework.batch.core.JobExecutionException;

public interface IPayPayeesService {

    CreateJobResponse ipay2stageJobLauncher(String ecClientId, Long jobId) throws JobExecutionException;

    void truncateIPaySrcTables();
}
