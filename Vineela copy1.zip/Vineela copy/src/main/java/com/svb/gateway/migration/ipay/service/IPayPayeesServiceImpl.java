package com.svb.gateway.migration.ipay.service;

import com.svb.gateway.migration.common.utility.MigrationConstants;
import com.svb.gateway.migration.common.utility.MigrationQueries;
import com.svb.gateway.migration.job.model.CreateJobResponse;
import com.svb.gateway.migration.job.model.CreateJobResponseData;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobExecutionException;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import static com.svb.gateway.migration.common.utility.MigrationConstants.JOB_ID_KEY;

@Service
@Slf4j
public class IPayPayeesServiceImpl implements IPayPayeesService {

    @Autowired
    @Qualifier("migJobLauncher")
    private JobLauncher jobLauncher;
    @Autowired
    private Job moveIPay2Stage;
    @Autowired
    @Qualifier("migrationJdbcTemplate")
    private JdbcTemplate jdbcTemplate;


    @Override
    public CreateJobResponse ipay2stageJobLauncher(String ecClientId, Long jobId) throws JobExecutionException {
        JobParametersBuilder builder = new JobParametersBuilder();
        builder.addLong(JOB_ID_KEY, jobId);
        builder.addString(MigrationConstants.CLIENT_IDS, ecClientId);
        JobExecution jobExecution = jobLauncher.run(moveIPay2Stage, builder.toJobParameters());
        String status = jobExecution.getStatus().name();
        log.info("ipaySinglePaymentsJobLauncher() - COMPLETE!.");
        return new CreateJobResponse(new CreateJobResponseData(jobId, status));
    }

    @Override
    public void truncateIPaySrcTables() {

        try {
            jdbcTemplate.batchUpdate(MigrationQueries.TRUNCATE_I_PAY_SRC_TABLEQUERIES);
        } catch (Exception e) {
            log.error("Error while truncating the src ipay tables {}", e.getMessage());
        }
    }
}
