package com.svb.gateway.migration.job.api;

import com.svb.gateway.migration.common.exception.ServiceException;
import com.svb.gateway.migration.job.model.ClientEntityList;
import com.svb.gateway.migration.job.model.CreateJobResponse;
import com.svb.gateway.migration.job.model.JobResponse;
import io.swagger.annotations.*;
import io.swagger.v3.oas.annotations.parameters.RequestBody;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.validation.Valid;
import javax.validation.constraints.Max;
import javax.validation.constraints.NotEmpty;
import java.io.IOException;

@Api(value = "Job", tags = "Job Controller")
@RequestMapping("/v1/api")
public interface JobApi {


    @ApiOperation(value = "Endpoint for creating a migration job to migrate clients from eConnect to Gateway", nickname = "createJob", notes = "Create Job")
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Job is Successfully created "),
            @ApiResponse(code = 400, message = "Invalid Client Id or Company Id "),
            @ApiResponse(code = 500, message = "Service unavailable ")})
    @PostMapping(value = "/job",
            produces = {"application/json"},
            consumes = {MediaType.MULTIPART_FORM_DATA_VALUE})
    @ResponseStatus(HttpStatus.OK)
    @PreAuthorize("hasAuthority(@migrationServiceConfig.getAuthExecute())")
    ResponseEntity<CreateJobResponse> createJob(@Valid
            @ApiParam(required = true, value = "Csv file should have header row and with two columns - EC_CLIENT_ID and COMPANY_ID")
            @RequestPart(value = "file", required = true) MultipartFile files, @RequestHeader("Authorization") final String authorization,
                @RequestParam
                @NotEmpty
                @Max(2) String EnableFlag,
                                                @RequestParam
                                                @NotEmpty
                                                @Max(2) String OverrideFlag)
            throws ServiceException, IOException;

    @GetMapping(value = "/job",
            produces = {"application/json"},
            consumes = {"*/*"})
    @PreAuthorize("hasAnyAuthority(@migrationServiceConfig.getViewAndExecute())")
    ResponseEntity<JobResponse> getJob(
            @ApiParam(value = "jobId to search job")
            @RequestParam(value = "jobId", required = true) Integer jobId) throws ServiceException;

    @ApiOperation(value = "Endpoint for loading", nickname = "loadStart", notes = "Load Start")
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "load is Successful "),
            @ApiResponse(code = 401, message = "Unauthorized"),
            @ApiResponse(code = 400, message = "Invalid JobId "),
            @ApiResponse(code = 403, message = "Forbidden"),
            @ApiResponse(code = 404, message = "Not Found"),
            @ApiResponse(code = 500, message = "Service unavailable ")})
    @PostMapping(path = "/job/load/{jobId}",
            consumes = MediaType.ALL_VALUE, produces = {"application/json"})
    @ResponseStatus(HttpStatus.OK)
    @PreAuthorize("hasAuthority(@migrationServiceConfig.getAuthExecute())")
    default ResponseEntity<CreateJobResponse> loadStart(@PathVariable Long jobId, @RequestBody ClientEntityList clientIds) throws ServiceException {
        return new ResponseEntity<>(HttpStatus.NOT_IMPLEMENTED);

    }


    @DeleteMapping(value = "/job",
            produces = {"application/json"},
            consumes = {"*/*"})
    @ApiOperation(value = "Endpoint for stopping a load job", nickname = "stop job", notes = "Stop the given load job. It still lets the currently running client finish, but does not go on the the next client")
    @PreAuthorize("hasAnyAuthority(@migrationServiceConfig.getViewAndExecute())")
    ResponseEntity<JobResponse> stopJob(
            @ApiParam(value = "jobId to stop")
            @RequestParam(value = "jobId", required = true) Integer jobId) throws ServiceException;
}
