package com.svb.gateway.migration.job.controller;

import com.opencsv.exceptions.CsvException;
import com.svb.gateway.migration.client.entity.MigClient;
import com.svb.gateway.migration.client.repository.MigClientRepository;
import com.svb.gateway.migration.common.exception.ServiceException;
import com.svb.gateway.migration.common.logging.Message;
import com.svb.gateway.migration.common.model.Error;
import com.svb.gateway.migration.common.utility.CommonValidator;
import com.svb.gateway.migration.common.utility.JobStatusEnum;
import com.svb.gateway.migration.common.utility.MigrationConstants;
import com.svb.gateway.migration.ec2stage.service.ECService;
import com.svb.gateway.migration.job.api.JobApi;
import com.svb.gateway.migration.job.entity.JobEntity;
import com.svb.gateway.migration.job.entity.MigJob;
import com.svb.gateway.migration.job.mapper.JobMapper;
import com.svb.gateway.migration.job.model.ClientEntityList;
import com.svb.gateway.migration.job.model.CreateJobResponse;
import com.svb.gateway.migration.job.model.CreateJobResponseData;
import com.svb.gateway.migration.job.model.JobResponse;
import com.svb.gateway.migration.job.repository.MigJobRepository;
import com.svb.gateway.migration.job.service.JobService;
import com.svb.gateway.migration.job.service.LoadService;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.*;

@RestController
@Log4j2
public class JobController implements JobApi {
    public static final String CREATE_JOB = "createJob";
    private final JobService jobService;
    private final LoadService loadService;
    private final ECService ecService;
    @Autowired
    MigJobRepository migJobRepository;
    @Autowired
    MigClientRepository migClientRepository;
    @Autowired
    JobMapper jobMapper;
    @Value("${ec.enable.validation}")
    private boolean enableECValidation;
    @Value("${clients.threshold}")
    private int threshold;
    @Autowired
    public JobController(JobService jobService, LoadService loadService, ECService ecService) {
        this.jobService = jobService;
        this.loadService = loadService;
        this.ecService = ecService;
    }


    @Override
    public ResponseEntity<CreateJobResponse> createJob(MultipartFile file, final String authorization, final String enable, final String overrideFlag) throws ServiceException, IOException {
        List<MigClient> migratingClients;
        CreateJobResponse response;
        Date startTime = Calendar.getInstance().getTime();
        try {
            migratingClients = jobService.parseCSVFile(file);
        }
        catch (CsvException e) {
            return handleCreateJobResponseException("Error while parsing CSV File  ==> ", e.getMessage());
        }
        catch (ServiceException  e) {
            return handleCreateJobResponseException("Service Error starting the job  ==> ", e.getErrorMessage());
        }
        catch (Exception e) {
            return handleCreateJobResponseException("Internal Server Error when starting the job  ==> ", e.getMessage());
        }
        if (migratingClients.size() > threshold) {
            Error error = new Error(HttpStatus.BAD_REQUEST.toString(), MigrationConstants.MAX_CLIENT_ERROR_MESSAGE + " " + threshold);
            response = new CreateJobResponse();
            response.setErrors(Collections.singletonList(error));
            log.warn(Message.create().descr(MigrationConstants.MAX_CLIENT_ERROR_MESSAGE + " " + threshold).operation(CREATE_JOB));
            return ResponseEntity.badRequest().body(response);
        }

        log.info(Message.create().descr("Calling EConnect API to disable clients").operation(CREATE_JOB));
        List<String> migClientsList=new ArrayList<>();
        migratingClients.forEach(client -> {
            migClientsList.add(client.getEcClientId());
        });

        String ecResponse = null;
        if (!enableECValidation) {
            log.warn(Message.create().descr("EC Validation Not Enabled").operation(CREATE_JOB));
        } else {
            ecResponse = ecService.updateClientDetailsEc(migClientsList, enable, overrideFlag);

        }

        if(ecResponse!=null && !ecResponse.equals("SUCCESS")){
            CreateJobResponse response1= new CreateJobResponse();
            response1.setAdditionalProperty("Error :", ecResponse);
            log.info(Message.create().descr("EConnect API call failure").operation(CREATE_JOB));
            return ResponseEntity.badRequest().body(response1);
        }

        JobEntity jobEntity = jobService.createJob(migratingClients);
        jobService.createClients(migratingClients, authorization, jobEntity, enable, overrideFlag);
        Date endTime = Calendar.getInstance().getTime();
        long duration = (endTime.getTime() - startTime.getTime()) / 1000;
        jobEntity.setExtractionTime(duration);
        jobMapper.updateMigExtractionTime(jobEntity);
        CreateJobResponse jobResponse = new CreateJobResponse();
        jobResponse.setData(new CreateJobResponseData().jobId(jobEntity.getJobId()).status(JobStatusEnum.EXTRACTION_INPROCESS.name()));
        log.info(Message.create().descr("Successfully created job").jobId(jobEntity.getJobId()).status(JobStatusEnum.EXTRACTION_INPROCESS.name()).operation(CREATE_JOB));
        return new ResponseEntity<>(jobResponse, HttpStatus.ACCEPTED);
    }

    private List getErrorList(String description, String errorMessage){
        Error error = new Error(HttpStatus.BAD_REQUEST.toString(), description + errorMessage);
        return Collections.singletonList(error);
    }

    private ResponseEntity<CreateJobResponse> handleCreateJobResponseException(String description, String errorMessage) {
        CreateJobResponse response;
        response = new CreateJobResponse();
        response.setErrors(getErrorList(description, errorMessage));
        log.warn(Message.create().descr(description + errorMessage).operation(CREATE_JOB));
        return ResponseEntity.badRequest().body(response);
    }

    private ResponseEntity<JobResponse> handleJobResponseException(String description, String errorMessage) {
        JobResponse response;
        response = new JobResponse();
        response.setErrors(getErrorList(description, errorMessage));
        return ResponseEntity.badRequest().body(response);
    }


    @Override
    public ResponseEntity<JobResponse> getJob(Integer jobId) throws ServiceException {
        JobResponse jobResponse = jobService.getJobById(jobId);
        if (jobResponse != null) {
            return new ResponseEntity<>(jobResponse, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }


    @Override
    public ResponseEntity<CreateJobResponse> loadStart(Long jobId, ClientEntityList clientIds) throws ServiceException {

        CommonValidator.jobIdCheck(jobId);
        log.debug(Message.create().descr("loadService.processJob, processJob: ").jobId(jobId));
        CreateJobResponse jobResponse = new CreateJobResponse();

        try {
            Map<MigJob, List<MigClient>> processResponse = loadService.validateAndPersistLoadRequest(jobId, clientIds.getClientEntityList());
            loadService.startLoad(processResponse);
            jobResponse.setData(new CreateJobResponseData().jobId(jobId).status(JobStatusEnum.LOAD_INPROGRESS.name()));
            return new ResponseEntity<>(jobResponse, HttpStatus.ACCEPTED);
        }
        catch(ServiceException e){
            return handleCreateJobResponseException("", e.getMessage());
        }
    }

    @Override
    public ResponseEntity<JobResponse> stopJob(Integer jobId) throws ServiceException {
        JobResponse jobResponse = null;
        try {
            jobResponse = jobService.stopJobById(jobId);
        }catch(ServiceException e){
            log.warn(Message.create().descr(e.getMessage()).operation("stopJob"));
            return handleJobResponseException("", e.getMessage());
        }
        if (jobResponse != null) {
            return new ResponseEntity<>(jobResponse, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }
}