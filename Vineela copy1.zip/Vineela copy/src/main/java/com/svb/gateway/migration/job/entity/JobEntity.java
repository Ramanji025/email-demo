package com.svb.gateway.migration.job.entity;

import com.svb.gateway.migration.common.utility.JobStatusEnum;
import com.svb.gateway.migration.common.utility.MigrationTypeEnum;
import lombok.*;

import java.time.OffsetDateTime;

@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode
@ToString
@Setter
@Getter
public class JobEntity {
    private long jobId;

    private MigrationTypeEnum type;

    private OffsetDateTime startTime;

    private Long ExtractionTime;

    private Long LoadTime;

    private OffsetDateTime endTime;

    private Integer candidateCount;

    private JobStatusEnum status;

    private String updatedBy;

    private OffsetDateTime updatedDate;

}