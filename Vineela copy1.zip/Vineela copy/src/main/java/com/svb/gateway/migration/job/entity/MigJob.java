package com.svb.gateway.migration.job.entity;

import lombok.*;

import javax.persistence.*;
import java.time.OffsetDateTime;

@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode
@ToString
@Setter
@Getter
@Entity
@Table(name = "MIG_JOB")
public class MigJob {

    @GeneratedValue(strategy= GenerationType.IDENTITY)
    @Id
    @Column(name = "JOBID")
    private Long jobId;

    @Column(name="TYPE")
    private String type;

    @Column(name="EXTRACTIONTIME")
    private Long ExtractionTime;

    @Column(name="LOADTIME")
    private Long LoadTime;

    @Column(name="STARTTIME")
    private OffsetDateTime startTime;

    @Column(name="ENDTIME")
    private OffsetDateTime endTime;

    @Column(name="CANDIDATECOUNT")
    private Integer candidateCount;

    @Column(name="STATUS")
    private String status;

    @Column(name="UPDATEDBY")
    private String updatedBy;

    @Column(name="UPDATEDDATE")
    private OffsetDateTime updatedDate;

}
