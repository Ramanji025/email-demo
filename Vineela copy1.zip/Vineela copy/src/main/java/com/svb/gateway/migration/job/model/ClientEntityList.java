package com.svb.gateway.migration.job.model;

import com.svb.gateway.migration.common.constants.RegexConstants;

import javax.validation.constraints.Pattern;
import java.util.List;

public class ClientEntityList {

    List<@Pattern(regexp= RegexConstants.EC_CLIENT_ID_PATTERN) String> clientEntityIdList ;

    public List<String> getClientEntityList() {
        return clientEntityIdList;
    }

    public void setClientEntityList(List<String> clientEntityIdList) {
        this.clientEntityIdList = clientEntityIdList;
    }
}