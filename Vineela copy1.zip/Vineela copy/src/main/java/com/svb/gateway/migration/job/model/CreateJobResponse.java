package com.svb.gateway.migration.job.model;

import com.fasterxml.jackson.annotation.*;
import com.svb.gateway.migration.common.model.Error;
import io.swagger.annotations.ApiModelProperty;
import lombok.NoArgsConstructor;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@JsonInclude(JsonInclude.Include.NON_NULL)
@NoArgsConstructor
public class CreateJobResponse {
    @JsonProperty("Data")
    private CreateJobResponseData data = null;

    @JsonProperty("Errors")
    private List<Error> errors = null;

    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<>();

    public CreateJobResponse(CreateJobResponseData createJobResponseData) {
        this.data = createJobResponseData;
    }

    public CreateJobResponse data(CreateJobResponseData data) {
        this.data = data;
        return this;
    }

    @ApiModelProperty(required = true, value = "")
    @NotNull
    @Valid
    public CreateJobResponseData getData() {
        return data;
    }

    public void setData(CreateJobResponseData data) {
        this.data = data;
    }

    @ApiModelProperty(required = true, value = "")
    @Valid
    public List<Error> getErrors() {
        return errors;
    }

    public void setErrors(List<Error> errors) {
        this.errors = errors;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

}
