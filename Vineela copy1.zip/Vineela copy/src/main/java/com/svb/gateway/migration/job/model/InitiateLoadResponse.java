package com.svb.gateway.migration.job.model;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class InitiateLoadResponse {
    private int clientCount;

}
