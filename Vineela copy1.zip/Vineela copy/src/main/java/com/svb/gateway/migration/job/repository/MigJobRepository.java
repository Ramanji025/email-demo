package com.svb.gateway.migration.job.repository;

import com.svb.gateway.migration.job.entity.MigJob;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface MigJobRepository extends JpaRepository<MigJob, Integer> {

    @Query(value = "select * from MIG_JOB where JOBID = ?1 and STATUS ='EXTRACTION_COMPLETED'", nativeQuery = true)
    MigJob findByJobId(Long jobId);

    @Query(value = "select * from MIG_JOB where JOBID = ?1 and STATUS in ('EXTRACTION_COMPLETED','LOAD_INPROGRESS')", nativeQuery = true)
    MigJob findByJobIdProgress(Long jobId);

    @Query(value = "select * from MIG_JOB where JOBID = ?1 and STATUS in ('LOAD_INPROGRESS')", nativeQuery = true)
    MigJob findByJobMigrationInProgress(Long jobId);

    @Query(value = "select * from MIG_JOB where JOBID = ?1 and STATUS ='EXTRACTION_INPROCESS'", nativeQuery = true)
    MigJob findByJobIdStatsExtractionProgress(Long jobId);

    Boolean existsMigJobByJobId(Long jobId);

    @Query(value = "select * from MIG_JOB where JOBID = ?1", nativeQuery = true)
    MigJob findByJobIdValue(Long jobId);
}
