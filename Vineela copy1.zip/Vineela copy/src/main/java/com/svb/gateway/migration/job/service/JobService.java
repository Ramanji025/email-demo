package com.svb.gateway.migration.job.service;

import com.opencsv.exceptions.CsvException;
import com.svb.gateway.migration.client.repository.ClientRepository;
import com.svb.gateway.migration.client.repository.MigClientRepository;
import com.svb.gateway.migration.client.service.ClientExtensionService;
import com.svb.gateway.migration.common.constants.MigrationConstants;
import com.svb.gateway.migration.common.exception.ServiceException;
import com.svb.gateway.migration.common.logging.Message;
import com.svb.gateway.migration.common.service.RetryService;
import com.svb.gateway.migration.common.utility.*;
import com.svb.gateway.migration.ec2stage.controller.EC2StageController;
import com.svb.gateway.migration.ec2stage.model.Ec2StageMigrationRequest;
import com.svb.gateway.migration.client.entity.MigClient;
import com.svb.gateway.migration.job.entity.JobEntity;
import com.svb.gateway.migration.job.mapper.ClientMapper;
import com.svb.gateway.migration.job.mapper.JobMapper;
import com.svb.gateway.migration.job.model.JobResponse;
import com.svb.gateway.migration.job.model.JobResponseData;
import lombok.extern.log4j.Log4j2;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.security.SecureRandom;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.util.*;
import java.util.stream.Collectors;

@Service
@Log4j2
public class JobService {

    private final JobMapper jobMapper;
    private final MigClientRepository clientrepository;
    private final ClientMapper clientMapper;
    private final SecureRandom secureRandomGenerator = new SecureRandom();
    @Value("${migration.service.user-id}")
    public String migrationUserId;
    @Value("${mig.ec.stage.url}")
    public String migStageUrl;
    @Value("${mig.admext.base.host}")
    public String admextBaseHost;
    @Value("${mig.companyIdCheck.url}")
    public String companyIdCheckUrl;
    @Autowired
    protected RetryService retryService;
    @Autowired
    ClientRepository stgClientRepository;
    @Autowired
    ClientExtensionService clientExtensionService;
    @Value("${migration.ecclient.id.length}")
    private Integer ecClientIdLength;
    @Autowired
    private EC2StageController eC2StageController;

    @Autowired
    public JobService(JobMapper jobMapper, MigClientRepository clientRepository, ClientMapper clientMapper) {
        this.jobMapper = jobMapper;
        this.clientrepository = clientRepository;
        this.clientMapper = clientMapper;
    }

    @Transactional(rollbackFor = {RuntimeException.class, ServiceException.class})
    public JobEntity createJob(List<MigClient> migratingClients) {
        JobEntity jobEntity = new JobEntity();
        jobEntity.setType(MigrationTypeEnum.CLIENT_MIGRATION);
        jobEntity.setCandidateCount(migratingClients.size());
        jobEntity.setStatus(JobStatusEnum.EXTRACTION_INPROCESS);
        jobEntity.setUpdatedBy(migrationUserId);
        jobEntity.setStartTime(OffsetDateTime.now().withOffsetSameInstant(ZoneOffset.UTC));
        jobMapper.insertJob(jobEntity);
        return jobEntity;
    }

    @Async
    public void createClients(List<MigClient> migratingClients, String authorization, JobEntity jobEntity, String enable, String overrideFlag) {
        migratingClients.parallelStream().forEach(entity -> {
            entity.setJobId(jobEntity.getJobId());
            entity.setStatus(MigrationConstants.STATUS_CREATED);
        });
        clientMapper.InsertMigratingClients(migratingClients);
        Ec2StageMigrationRequest ec2Request = new Ec2StageMigrationRequest(migratingClients.stream()
                .map(MigClient::getEcClientId).collect(Collectors.toList()), jobEntity.getJobId());
        try {
            eC2StageController.migrateEc2StageInternal(ec2Request);
        } catch (Exception exception) {
            log.error(Message.create().descr("Exception occurred while extraction API invocation reason" + exception.getMessage()));
        }
    }

    public JobResponse getJobById(Integer jobId) {
        JobResponse jobResponse = new JobResponse();
        JobResponseData jobResponseData = new JobResponseData();
        JobEntity job = jobMapper.readMigrationJob(jobId);
        if (null != job) {
            jobResponseData.setJobId(job.getJobId());
            jobResponseData.setJobType(job.getType().name());
            if (null != job.getEndTime()) jobResponseData.setEndTime(job.getEndTime().toString());
            jobResponseData.setStartTime(job.getStartTime().toString());
            jobResponseData.setUpdatedBy(job.getUpdatedBy());
            jobResponseData.setUpdatedDate(job.getUpdatedDate().toString());
            jobResponseData.setStatus(job.getStatus().name());
        }
        jobResponse.setData(jobResponseData);
        return jobResponse;
    }

    public JobResponse stopJobById(Integer jobId) throws ServiceException {
        Message message = Message.create().operation("stopJobById").descr("Stopping job").jobId((long) jobId).summary();
        JobResponse jobResponse = new JobResponse();
        JobResponseData jobResponseData = new JobResponseData();
        JobEntity job = jobMapper.readMigrationJob(jobId);
        if (null != job) {
            OffsetDateTime now = OffsetDateTime.now().withOffsetSameInstant(ZoneOffset.UTC);
            job.setStatus(JobStatusEnum.STOPPED);
            job.setEndTime(now);
            job.setUpdatedDate(now);
            jobResponseData.setJobId(job.getJobId());
            jobResponseData.setJobType(job.getType().name());
            if (null != job.getEndTime()) jobResponseData.setEndTime(job.getEndTime().toString());
            jobResponseData.setStartTime(job.getStartTime().toString());
            jobResponseData.setUpdatedBy(job.getUpdatedBy());
            jobResponseData.setUpdatedDate(now.toString());
            jobResponseData.setStatus(job.getStatus().name());
            jobMapper.updateJobStatus(job);
            log.info(message);
        } else {
            String error = "could not find the jobId";
            log.error(message.descr(error));
            throw new ServiceException(error);
        }
        jobResponse.setData(jobResponseData);
        return jobResponse;
    }

    public List<MigClient> parseCSVFile(final MultipartFile file) throws ServiceException, IOException, CsvException {
        Message message = Message.create();
        if (!(Objects.requireNonNull(file.getOriginalFilename()).endsWith(".csv"))) {
            throw new ServiceException("FILE IS NOT OF CSV FORMAT");
        }
        List<String[]> csvBeans = CSVUtilities.csvtoBeans(file);
        final List<MigClient> clients = new ArrayList<>();
        final Map<String, String> clientsMap = new HashMap<>();
        if (csvBeans.isEmpty()) {
            throw new ServiceException("CSV_FILE_SHOULD_NOT_BE_EMPTY");
        }
        for (String[] cs : csvBeans) {
            String ecClientId = cs[0];
            if (StringUtils.isBlank(ecClientId)) {
                throw new ServiceException("Error record EcclientId -->" + ecClientId);
            }

            CommonValidator.ecClientIdCheck(ecClientId);

            //Preparing a map to identify the duplicate ecClientId
            if (clientsMap.containsKey(ecClientId)) {
                throw new ServiceException("Duplicate record in CSV file " + ecClientId);
            } else {
                clientsMap.put(ecClientId, "");
            }
            final MigClient client = new MigClient();
            client.setEcClientId(ecClientId);
            clients.add(client);
        }
        List<MigClient> existing = clientrepository.findClientsNotRollback(clientsMap.keySet(), MigrationConstants.STATUS_ROLLED_BACK);
        if (!existing.isEmpty()) {
            String existingClients = existing.stream().map(MigClient::getEcClientId).collect(Collectors.joining(","));
            log.info(message.descr("client(s) is/are already migrated or not rolled back :: " + existingClients));
            throw new ServiceException(existing.size() + " client(s) is/are already migrated or not rolled back :: "
                    + existingClients);
        }

        return clients;
    }
}
