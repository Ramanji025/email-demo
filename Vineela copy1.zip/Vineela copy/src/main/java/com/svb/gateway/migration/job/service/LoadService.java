package com.svb.gateway.migration.job.service;

import com.svb.gateway.migration.alerts.service.AlertsService;
import com.svb.gateway.migration.beneficiaries.repository.BeneficiaryRepository;
import com.svb.gateway.migration.beneficiaries.service.BeneficiariesService;
import com.svb.gateway.migration.cards.service.CardsService;
import com.svb.gateway.migration.client.entity.MigClient;
import com.svb.gateway.migration.client.entity.StgClient;
import com.svb.gateway.migration.client.model.CompanyIdRequest;
import com.svb.gateway.migration.client.model.CompanyIdResponse;
import com.svb.gateway.migration.client.model.EnrollClientResponse;
import com.svb.gateway.migration.client.repository.ClientRepository;
import com.svb.gateway.migration.client.repository.MigClientRepository;
import com.svb.gateway.migration.client.service.ClientExtensionService;
import com.svb.gateway.migration.client.service.ClientService;
import com.svb.gateway.migration.client.service.PartnerService;
import com.svb.gateway.migration.common.exception.ServiceException;
import com.svb.gateway.migration.common.exception.SkipAheadServiceException;
import com.svb.gateway.migration.common.logging.Message;
import com.svb.gateway.migration.common.utility.CommonValidator;
import com.svb.gateway.migration.common.utility.JobStatusEnum;
import com.svb.gateway.migration.ec2stage.service.ECService;
import com.svb.gateway.migration.healthcheck.model.HealthCheckResponse;
import com.svb.gateway.migration.healthcheck.service.HealthCheckService;
import com.svb.gateway.migration.job.entity.JobEntity;
import com.svb.gateway.migration.job.entity.MigJob;
import com.svb.gateway.migration.job.mapper.JobMapper;
import com.svb.gateway.migration.job.repository.MigJobRepository;
import com.svb.gateway.migration.nickname.service.NicknameService;
import com.svb.gateway.migration.payments.service.IpayPaymentService;
import com.svb.gateway.migration.payments.service.EconnectService;
import com.svb.gateway.migration.payments.service.StopPaymentService;
import com.svb.gateway.migration.user.repository.StgUserRepository;
import com.svb.gateway.migration.user.service.UserService;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.stereotype.Service;

import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.util.*;
import java.util.stream.Collectors;

import static com.svb.gateway.migration.beneficiaries.entity.StgToTargetBeneEntity.PAYEE_TYPE.*;
import static com.svb.gateway.migration.common.constants.MigrationConstants.*;

@Service
@EnableAsync
@Log4j2
public class LoadService {

    private static final Set<String> jobStatusesAllowedToLoad = new HashSet<>();

    static {
        jobStatusesAllowedToLoad.add("EXTRACTION_COMPLETED");
        jobStatusesAllowedToLoad.add("LOAD_COMPLETED");
        jobStatusesAllowedToLoad.add("STOPPED");
    }

    @Value("${gateway.healthCheck.required}")
    public boolean healthCheckRequired;
    @Autowired
    MigJobRepository migJobRepository;
    @Autowired
    MigClientRepository migClientRepository;
    @Autowired
    StgUserRepository stgUserRepository;
    @Autowired
    ClientService clientService;
    @Autowired
    PartnerService partnerService;
    @Autowired
    UserService userService;
    @Autowired
    CardsService cardsService;
    @Autowired
    AlertsService alertsService;
    @Autowired
    NicknameService nicknameService;
    @Autowired
    StopPaymentService stopPaymentService;
    @Autowired
    BeneficiariesService beneficiariesService;
    @Autowired
    BeneficiaryRepository beneficiaryRepository;
    @Autowired
    JobMapper jobMapper;
    @Value("${mig.bdc.reRegister.sleepInterval}")
    int sleepInterval;
    @Autowired
    ECService ecService;
    @Autowired
    ClientRepository stgClientRepository;
    @Autowired
    ClientExtensionService clientExtensionService;
    @Autowired
    private IpayPaymentService ipayPaymentService;
    @Autowired
    private EconnectService econnectService;
    @Value("${migration.company.id.length.max}")
    private Integer companyIdLengthMax;
    @Value("${migration.company.id.length.min}")
    private Integer companyIdLengthMin;
    @Autowired
    private HealthCheckService healthCheckService;
    

    public Map<MigJob, List<MigClient>> validateAndPersistLoadRequest(Long jobId, List<String> selectClients) throws ServiceException {

        if (jobId == null) {
            throw new ServiceException("jobId must not be null");
        }
        MigJob job = migJobRepository.findByJobIdValue(jobId);

        if (job == null) {
            throw new ServiceException("invalid jobId provided");
        }

        if (!jobStatusesAllowedToLoad.contains(job.getStatus())) {
            throw new ServiceException("the job " + job.getJobId() + " can't run because its status is " + job.getStatus());
        }

        //Retrieve all the Clients from MIG_CLIENT table for that JOB-ID
        List<MigClient> jobClients = migClientRepository.findByJobId(jobId);
        if (jobClients == null || jobClients.isEmpty()) {
            throw new ServiceException("job does not have any associated client");
        }

        List<MigClient> filteredClients = null;
        if (null != selectClients) {
            filteredClients = jobClients.stream()
                    .filter(client -> selectClients.contains(client.getEcClientId()))
                    .collect(Collectors.toList());
            for (String ecClientId : selectClients) {
                CommonValidator.ecClientIdCheck(ecClientId);
            }
        } else
            filteredClients = jobClients;
        //If the Job Status is extraction Extraction-Complete, change the status to "Migration-Inprogress"
        job.setStatus(JobStatusEnum.LOAD_INPROGRESS.name());
        migJobRepository.save(job);
        return Map.of(job, filteredClients);
    }


    @Async
    public void startLoad(Map<MigJob, List<MigClient>> jobClients) {
        Message logMessage = Message.create().descr("Job Load process started");
        log.info(logMessage);
        MigJob job = jobClients.keySet().stream().findFirst().orElse(null);
        if (null == job) {
            log.warn(Message.create().descr("exiting load as job is null / invalid"));
            return;
        }

        Date startTime = Calendar.getInstance().getTime();
        boolean healthCheckOk = false;
        try {
            healthCheckOk = isHealthCheckOk(job);
            if (!healthCheckOk) {
                throw new ServiceException("Health check - Gateway service reachability issues.");
            }

            List<MigClient> selectClients = null;
            selectClients = jobClients.get(job);
            for (MigClient client : selectClients) {
                if (isJobCancelled(job)) {
                    break;
                }
                log.info(logMessage.jobId(job.getJobId()).clientId(client.getEcClientId()).descr("Client Load process started"));
                createCompanyID(job.getJobId(), client);
                loadClientDataToGateway(job, client);
                log.info(logMessage.descr("Client Load process end"));
            }

        } catch (Exception e){
            log.error(Message.create().descr("Load job encountered exception, reason: "+ e.getMessage()));
            job.setStatus(JobStatusEnum.STOPPED.name());

        } finally {
            if (isJobCancelled(job)) {
                job.setStatus(JobStatusEnum.STOPPED.name());
            } else if (healthCheckOk) {
                job.setStatus(JobStatusEnum.LOAD_COMPLETED.name());
            }
            OffsetDateTime now = OffsetDateTime.now().withOffsetSameInstant(ZoneOffset.UTC);
            job.setEndTime(now);
            Date endTime = Calendar.getInstance().getTime();
            long duration = (endTime.getTime() - startTime.getTime()) / 1000;
            job.setLoadTime(duration);
            job.setUpdatedDate(now);

            migJobRepository.save(job);
            log.info(logMessage.clientId("").descr("Migration Completed for job ").timeTaken(duration));
        }
    }

    private void loadClientDataToGateway(MigJob job, MigClient client) throws InterruptedException, ServiceException {

        log.info(Message.create().clientId(client.getEcClientId()).descr("Loading Client Data to gateway"));
        if (enrollClient(job.getJobId(), client)) {
            Long startTime = System.currentTimeMillis();
            // only continue with a client if the client enrollment is successful
            processAddCardProgram(job.getJobId(), client);
            processNickName(job.getJobId(), client);
            processWireBeneficiaries(job.getJobId(), client);
            processTransfers(job.getJobId(), client);
            processWireOutgoing(job.getJobId(), client);

            //pause for a total of the sleepIntervals secs so that BDC registration is completed.
            pauseProcessing(startTime, job, client);

            processAddUser(job.getJobId(), client);
            processAddCardUserUpdate(job.getJobId(), client);
            processAlerts(job.getJobId(), client);
            processStopPay(job.getJobId(), client);
            processPartnerPayments(job, client);
        }
    }

    private void processPartnerPayments(MigJob job, MigClient client) throws InterruptedException {
        if (validateAndProcessPartnerRegistration(client, job.getJobId())) {
            processIpayBeneficiaries(job.getJobId(), client);
            processIpayPayments(job.getJobId(), client);
        }
    }

    public void pauseProcessing(Long startTime, MigJob job, MigClient client) throws InterruptedException {
        Message timerLog = Message.create().clientId(client.getEcClientId()).jobId(job.getJobId());
        Long diff = Long.valueOf(sleepInterval) - (System.currentTimeMillis() - startTime);

        if (diff > 0L) {
            log.info(timerLog.descr("Will sleep for " + diff + " ms"));
            Thread.sleep(diff);
            log.info(timerLog.descr("Resume processing now"));
        }
    }

    private boolean isJobCancelled(MigJob job) {
        if (job != null) {
            JobEntity jobEntity = jobMapper.readMigrationJob(job.getJobId().intValue());
            return jobEntity.getStatus() == JobStatusEnum.STOPPED;
        }
        return false;
    }

    private boolean validateAndProcessPartnerRegistration(MigClient migClient, Long jobId) {
        Message bdcLog = Message.create().clientId(migClient.getEcClientId()).jobId(jobId);
        boolean status = false;
        try {
            status = partnerService.processPartnerRegistrationStatus(migClient.getEcClientId(), jobId);
        } catch (Exception e) {
            log.error(Message.create().descr("enrollClient failed reason" + e.getMessage()).clientId(migClient.getEcClientId()).jobId(jobId));
        }
        if (!status) {
            //update BDC status for client and User
            log.warn(bdcLog.descr(" validateAndProcessPartnerRegistration is not completed, cannot process Ipay bene and Payments"));
        }
        return status;
    }

    private boolean enrollClient(Long jobId, MigClient client) {
        try {
            EnrollClientResponse enrollClientResponse = clientService.enrollClient(client, jobId);
            return enrollClientResponse.getData().getStatus().equals(STATUS_SUCCESS);
        } catch (Exception e) {
            log.error(Message.create().descr("enrollClient failed reason" + e.getMessage()).clientId(client.getEcClientId()).jobId(jobId));

        }
        return false;
    }

    private void processAddCardProgram(Long jobId, MigClient mc) {
        try {
            cardsService.addCardProgramToClient(jobId, mc);
        } catch (Exception e) {
            log.error(Message.create().descr("Add cardProgram Errored " + e.getMessage()).clientId(mc.getEcClientId()).jobId(jobId));
        }
    }

    private void processAddUser(Long jobId, MigClient mc) {
        try {
            userService.createUsers(jobId, mc);
        } catch (SkipAheadServiceException e) {
            log.info(Message.create().descr("Add user migration skipped due to - " + e.getMessage()).clientId(mc.getEcClientId()).jobId(jobId));
        } catch (Exception e) {
            log.error(Message.create().descr("Add Users Errored  " + e.getMessage()).clientId(mc.getEcClientId()).jobId(jobId));
        }
    }

    private void processAddCardUserUpdate(Long jobId, MigClient mc) {
        try {
            userService.updateCardUserId(jobId, mc.getEcClientId());
        } catch (Exception e) {
            log.error(Message.create().descr("Update Card User Id Errored  " + e.getMessage()).clientId(mc.getEcClientId()).jobId(jobId));
        }
    }

    private List<String> processWireBeneficiaries(Long jobId, MigClient mc) {
        List<String> statusList = new ArrayList<>();
        Message beneWireMessage = Message.create().jobId(jobId).clientId(mc.getEcClientId()).entityName(Message.Entity.beneficiary);
        try {
            log.info(beneWireMessage.descr("Wire template beneficiaries migration started").payeeType(TEMPLATE));
            beneficiariesService.addBeneficiaries(jobId, mc, TEMPLATE);
            log.info(beneWireMessage.descr("Wire template beneficiaries migration completed").payeeType(TEMPLATE));
        } catch (Exception e) {
            log.error(beneWireMessage.descr("Wire beneficiaries migration failed with unexpected error - " + e.getMessage()));
            statusList.add(STATUS_FAILURE);
        }
        return statusList;
    }

    private List<String> processIpayBeneficiaries(Long jobId, MigClient mc) {
        List<String> statusList = new ArrayList<>();
        try {
            beneficiariesService.addBeneficiaries(jobId, mc, CHECK);
            beneficiariesService.addBeneficiaries(jobId, mc, ACH);
            beneficiariesService.addBeneficiaries(jobId, mc, ACH_LARGE);

        } catch (Exception e) {
            log.error(Message.create().descr("Beneficiary's insertion errored ").clientId(mc.getEcClientId()).jobId(jobId));
            statusList.add(STATUS_FAILURE);
        }
        return statusList;
    }

    private void processWireOutgoing(Long jobId, MigClient migClient) {
        try {
            econnectService.wireTransfer(jobId, migClient);

        } catch (Exception e) {
            log.error(Message.create().descr("wireoutgoing insertion errored  " + e.getMessage()).clientId(migClient.getEcClientId()).jobId(migClient.getJobId()));
        }
    }

    private void processNickName(Long jobId, MigClient migClient) {
        try {
            nicknameService.migrateAccountNickname(jobId, migClient);

        } catch (Exception e) {
            log.error(Message.create().descr("NickName insertion errored  " + e.getMessage()).clientId(migClient.getEcClientId()).jobId(migClient.getJobId()));
        }
    }

    private void processAlerts(Long jobId, MigClient migClient) {
        try {
            alertsService.registerAlerts(jobId, migClient);

        } catch (Exception e) {
            log.error(Message.create().descr("Alerts insertion errored  " + e.getMessage()).clientId(migClient.getEcClientId()).jobId(migClient.getJobId()));
        }
    }

    private void processTransfers(Long jobId, MigClient migClient) {
        try {
            econnectService.internalTransfer(jobId, migClient);

        } catch (Exception e) {
            log.error(Message.create().descr("transfer's insertion errored  " + e.getMessage()).clientId(migClient.getEcClientId()).jobId(migClient.getJobId()));
        }
    }

    private void processIpayPayments(Long jobId, MigClient migClient) {
        try {
            ipayPaymentService.createPayments(jobId, migClient);
        } catch (Exception e) {
            log.error(Message.create().descr("IPay Payments insertion errored ").clientId(migClient.getEcClientId()).jobId(migClient.getJobId()));
        }
    }

    public boolean isHealthCheckOk(MigJob job) throws ServiceException {
        Message logMessage = Message.create().jobId(job.getJobId()).operation("Pre-validate various Gateway endpoints reachability");
        boolean continueToLoad = true;
        if (healthCheckRequired) {
            log.info(logMessage.descr("Pre-validation of Gateway services started."));
            HealthCheckResponse healthCheckResponse = healthCheckService.preValidate();
            if (null != healthCheckResponse && STATUS_FAILURE.equalsIgnoreCase(healthCheckResponse.getStatus())) {
                continueToLoad = false;
            }
        } else {
            log.info(logMessage.descr("Skipping Pre-validation of Gateway services as the feature is turned off."));
        }
        return continueToLoad;
    }

    private void processStopPay(Long jobId, MigClient migClient) {
        try {
            stopPaymentService.migrateStopPay(jobId, migClient);

        } catch (Exception e) {
            log.error(Message.create().descr("Stop Pay migration errored  " + e.getMessage()).clientId(migClient.getEcClientId()).jobId(migClient.getJobId()));
        }
    }

    public void createCompanyID(Long jobId, MigClient migClient) throws ServiceException {

        Message logMessage = Message.create().jobId(jobId).operation("Generating companyId for list of clients based on jobId");

        List<MigClient> clientList = migClientRepository.findByJobId(jobId);
        if (null != clientList) {
            String companyId;

            companyId = getCompanyId(migClient.getEcClientId());
            if (companyId.length() > companyIdLengthMax || companyId.length() < companyIdLengthMin) {
                throw new ServiceException("Company Id length should be between "
                        + companyIdLengthMin + " and " + companyIdLengthMax);
            }
            migClient.setCompanyId(companyId);
            migClientRepository.save(migClient);

            log.info(logMessage.descr("companyId is set for list of clients in migClient table"));
        } else {
            log.info(logMessage.descr("unable to generate companyId for clients based on jobId"));
            throw new ServiceException("clientList is empty ", "unable to generate companyId for clients based on jobId");

        }
    }

    public String getCompanyId(String ecClientId) throws ServiceException {

        String companyId;

        StgClient stgClient = stgClientRepository.findByOlbClinetId(ecClientId);
        CompanyIdResponse companyIdResponse = null;
        CompanyIdRequest companyIdRequest = new CompanyIdRequest();
        if (null != stgClient && null != stgClient.getClientName()) {
            companyIdRequest.setCompanyName(stgClient.getClientName());
            companyIdResponse = clientExtensionService.generateCompanyId(companyIdRequest);
        } else {
            throw new ServiceException("Staging Record is null: " + ecClientId);
        }
        if (null != companyIdResponse && null != companyIdResponse.getCompanyId()) {
            companyId = companyIdResponse.getCompanyId();
        } else {
            throw new ServiceException("CompanyID generation failed" + ecClientId + companyIdRequest.getCompanyName());
        }
        return companyId;
    }

}



