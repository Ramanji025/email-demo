package com.svb.gateway.migration.nickname.api;

import com.svb.gateway.migration.client.model.MigClientDTO;
import com.svb.gateway.migration.common.exception.ServiceException;
import com.svb.gateway.migration.nickname.model.NicknameResponse;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

@Api(value = "Nickname")
@RequestMapping("api/nickname")
public interface NicknameApi {
    @ApiOperation(value = "Endpoint for migrating account nickname from eC to Gateway", nickname = "migrateAccountNicknames", notes = "Migrate Account Nicknames")
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Account nicknames migrated successfully"),
            @ApiResponse(code = 401, message = "Unauthorized"),
            @ApiResponse(code = 400, message = "Invalid Client Id "),
            @ApiResponse(code = 403, message = "Forbidden"),
            @ApiResponse(code = 500, message = "Service unavailable ")})
    @PostMapping(value = "/{jobId}",
            produces = {"application/json"},
            consumes = {"application/json"})
    @ResponseStatus(HttpStatus.OK)
    @PreAuthorize("hasAuthority(@migrationServiceConfig.getAuthExecute())")
    public ResponseEntity<NicknameResponse> migrateAccountNicknames(@PathVariable Long jobId,@RequestBody MigClientDTO migClientDTO) throws ServiceException;
}
