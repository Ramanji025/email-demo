package com.svb.gateway.migration.nickname.entity;

import com.svb.gateway.migration.common.processors.IRetry;
import lombok.*;

import java.time.LocalDateTime;

@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode
@ToString
@Setter
@Getter
public class MigratedNicknamesEntity implements IRetry {

    private Long id;
    private Long jobId;
    private String ec_Client_Id;
    private String gw_Client_Id;
    private String cif_Number;
    private String account_Number;
    private String account_Nickname;
    private String status;
    private String comments;
    private String updatedBy;
    private LocalDateTime updatedDate;
}
