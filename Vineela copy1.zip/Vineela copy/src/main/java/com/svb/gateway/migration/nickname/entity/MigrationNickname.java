package com.svb.gateway.migration.nickname.entity;

import lombok.Getter;
import lombok.Setter;
import org.springframework.beans.factory.annotation.Value;

import javax.persistence.*;
import java.time.LocalDateTime;

@Getter
@Setter
@Entity
@Table(schema = "GWDMG", name = "MIG_NICKNAME")
public class MigrationNickname {

    @GeneratedValue(strategy= GenerationType.IDENTITY)
    @Id
    @Column(name = "ID")
    private Long id;

    @Column(name = "JOBID")
    private Long jobId;

    @Column(name = "EC_CLIENT_ID")
    private String ecClientId;

    @Column(name = "GW_CLIENT_ID")
    private String gwClientId;

    @Column(name ="CIF_NUMBER")
    private String cifNumber;

    @Column(name = "ACCOUNT_NUMBER")
    private String accountNumber;

    @Column(name ="ACCOUNT_NICKNAME")
    private String accountNickname;

    @Column(name = "STATUS")
    private String status;

    @Column(name = "COMMENTS")
    private String comments;

    @Column(name = "UPDATEDBY")
    private String updatedBy;

    @Column(name = "UPDATEDDATE")
    private LocalDateTime updatedDate;


    public MigrationNickname updateFrom(MigrationNickname other) {
        if (other != null) {
            setUpdatedDate(LocalDateTime.now());
            // update existing object with everything except
            setId(other.getId());
            setJobId(other.getJobId());
            setEcClientId(other.getEcClientId());
            setGwClientId(other.getGwClientId());
        }
        return this;
    }

}
