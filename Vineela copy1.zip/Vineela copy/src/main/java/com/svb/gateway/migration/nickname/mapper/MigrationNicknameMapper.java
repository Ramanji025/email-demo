package com.svb.gateway.migration.nickname.mapper;

import com.svb.gateway.migration.common.constants.MigrationConstants;
import com.svb.gateway.migration.nickname.entity.MigratedNicknamesEntity;
import com.svb.gateway.migration.nickname.entity.MigrationNickname;
import org.apache.ibatis.annotations.*;
import org.springframework.stereotype.Repository;

import java.util.List;

@Mapper
@Repository
public interface MigrationNicknameMapper {
    @Select(value = {
            "SELECT",
            "ID,JOBID,EC_CLIENT_ID,GW_CLIENT_ID,CIF_NUMBER,ACCOUNT_NUMBER,ACCOUNT_NICKNAME,COMMENTS,STATUS,UPDATEDBY,UPDATEDDATE",
            "FROM",
            "GWDMG.MIG_NICKNAME",
            "WHERE",
            "JOBID=#{jobId} AND EC_CLIENT_ID=#{olbClientId} AND ACCOUNT_NUMBER=#{accountNumber} ORDER BY UPDATEDDATE DESC FETCH FIRST 1 ROWS ONLY"
    })
    MigratedNicknamesEntity checkIfMigratedIgnoredOrRolledBack(@Param("jobId") Long jobId, @Param("olbClientId") String olbClientId, @Param("accountNumber") String accountNumber);

    @Insert(value = {
            "INSERT INTO",
            "GWDMG.MIG_NICKNAME",
            "(JOBID,EC_CLIENT_ID,GW_CLIENT_ID,CIF_NUMBER,ACCOUNT_NUMBER,ACCOUNT_NICKNAME,COMMENTS,STATUS)",
            "VALUES",
            "(#{jobId}, #{ecClientId}, #{gwClientId}, #{cifNumber}, #{accountNumber}, #{accountNickname}, #{comments}, #{status})"
    })
    @Options(useGeneratedKeys = true, keyProperty = "id", keyColumn = "ID")
    Integer insertMigratedAccountNicknames(MigrationNickname migrationNickname);

    @Select(value = {
            "SELECT",
            "ID,JOBID,EC_CLIENT_ID,GW_CLIENT_ID,CIF_NUMBER,ACCOUNT_NUMBER,ACCOUNT_NICKNAME,COMMENTS,STATUS,UPDATEDBY,UPDATEDDATE",
            "FROM",
            "GWDMG.MIG_NICKNAME",
            "WHERE",
            "JOBID=#{jobId} AND EC_CLIENT_ID=#{olbClientId} AND STATUS IN ('"+ MigrationConstants.STATUS_FAILURE+"','"+MigrationConstants.STATUS_IGNORE+"')"
    })
    List<MigratedNicknamesEntity> findByEcClientIdAndJobIdAndStatus(@Param("jobId") Long jobId, @Param("olbClientId") String olbClientId);

}
