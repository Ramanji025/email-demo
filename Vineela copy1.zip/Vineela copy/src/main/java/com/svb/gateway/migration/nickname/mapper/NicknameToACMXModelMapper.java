package com.svb.gateway.migration.nickname.mapper;

import com.svb.gateway.migration.common.utility.DateUtility;
import com.svb.gateway.migration.nickname.entity.AccountMasterExtensionEntity;
import com.svb.gateway.migration.nickname.entity.Nicknames;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;
import org.mapstruct.factory.Mappers;

import java.time.LocalDateTime;

@Mapper(componentModel="spring")
public interface NicknameToACMXModelMapper {
    NicknameToACMXModelMapper INSTANCE = Mappers.getMapper(NicknameToACMXModelMapper.class);

    public static String ZERO="0";
    public static String BANK_ID="SVB";
    public static String BRANCH_ID="SB0";
    public static String TRACE_AC="N";
    public static String DEL_FLG="N";


    public static final String PST_TIME_ZONE="America/Los_Angeles";

    @Mapping(constant = "1",target="dbTs")
    @Mapping(constant=BANK_ID, target="bankId")
    @Mapping(constant=BRANCH_ID, target="branchId")
    @Mapping(source="nickname.accountNumber", target="acid")
    @Mapping(source="gwClientId", target="bayUserId")
    @Mapping(source="nickname.accTitle", target="acNicName")
    @Mapping(constant=ZERO, target="minPrefBal")
    @Mapping(constant=ZERO, target="largeCreditBal")
    @Mapping(constant=ZERO, target="largeDebitBal")
    @Mapping(constant=TRACE_AC, target="traceAc")
    @Mapping(constant=DEL_FLG, target="delFlg")
    @Mapping(expression="java(getMigrationUser(bankUserUuid))", target="RModId")
    @Mapping(expression="java(getPSTDate())", target="RModTime")
    @Mapping(expression="java(getMigrationUser(bankUserUuid))", target="RCreId")
    @Mapping(expression="java(getPSTDate())", target="RCreTime")
    @Mapping(constant=BANK_ID, target="userBankId")
    AccountMasterExtensionEntity convertSingleAccountNicknameToACMXData(Nicknames nickname, String gwClientId, String bankUserUuid);

    @Named("formattedClient")
    default String getMigrationUser(String bankUserUuid){
        return BANK_ID + "." + bankUserUuid;
    }

    default LocalDateTime getPSTDate(){
        return DateUtility.getTimeZoneDate("America/Los_Angeles");
    }
}

