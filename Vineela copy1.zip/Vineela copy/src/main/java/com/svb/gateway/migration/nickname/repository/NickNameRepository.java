package com.svb.gateway.migration.nickname.repository;

import com.svb.gateway.migration.nickname.entity.MigrationNickname;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface NickNameRepository extends JpaRepository<MigrationNickname, Long> {

    List<MigrationNickname> findAllByEcClientIdAndStatus(String ecClientId, String status);

    @Query(value = "select * from MIG_NICKNAME where GW_CLIENT_ID=?1 and ACCOUNT_NUMBER=?2 and JOBID=?3 and CIF_NUMBER=?4", nativeQuery = true)
    MigrationNickname findByGwClientIdAndAccountNumberAndJobIdAndCifNumber(String gwClientId, String accountNumber, Long jobId, String cif);
}

