package com.svb.gateway.migration.nickname.repository;

import com.svb.gateway.migration.nickname.entity.Nicknames;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface StgAccountNicknameRepository extends JpaRepository<Nicknames, String> {

    @Query(value = "SELECT * FROM MIG_STG_ACCOUNT_NICK_NAME where OLB_CLIENT_ID= ?1 and lower(MODIFIED_BY_USER)='true'", nativeQuery = true)
    List<Nicknames> findByEcClientId(String ecClientId);

}
