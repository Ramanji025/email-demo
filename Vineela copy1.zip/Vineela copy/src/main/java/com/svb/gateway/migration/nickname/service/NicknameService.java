package com.svb.gateway.migration.nickname.service;

import com.svb.gateway.migration.client.entity.MigClient;
import com.svb.gateway.migration.common.exception.ServiceException;
import com.svb.gateway.migration.common.logging.Message;
import com.svb.gateway.migration.common.mapper.MigrationEntityMapper;
import com.svb.gateway.migration.common.utility.EntityLogUtility;
import com.svb.gateway.migration.common.utility.RecordCount;
import com.svb.gateway.migration.nickname.entity.MigratedNicknamesEntity;
import com.svb.gateway.migration.nickname.entity.MigrationNickname;
import com.svb.gateway.migration.nickname.entity.Nicknames;
import com.svb.gateway.migration.nickname.mapper.MigrationNicknameMapper;
import com.svb.gateway.migration.nickname.mapper.MigrationNicknameModelMapper;
import com.svb.gateway.migration.nickname.model.NicknameResponse;
import com.svb.gateway.migration.nickname.model.NicknameResponseData;
import com.svb.gateway.migration.nickname.repository.NickNameRepository;
import com.svb.gateway.migration.nickname.repository.StgAccountNicknameRepository;
import com.svb.gateway.migration.rollback.model.RollBackResponse;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static com.svb.gateway.migration.common.constants.MigrationConstants.*;

@Log4j2
@Service
public class NicknameService {
    @Value("${migration.service.userid}")
    public String migrationUserId;

    public static final String NO_DATA_TO_MIGRATE = "No account nicknames available to migrate for provided client Id";
    public static final String NO_NICKNAME_TO_MIGRATE = "No account nicknames to migrate";
    public static final String ENTITY_NAME = "Account Nickname";
    public static final String SPECIAL_CHARACTER_ALLOWED = "^[a-zA-Z0-9\\s]+$";
    @Autowired
    EntityLogUtility entityLogUtility;
    @Autowired
    private StgAccountNicknameRepository stgAccountNicknameRepository;
    @Autowired
    private MigrationNicknameMapper migrationNicknameMapper;

    @Autowired
    private NicknameMigrationService nicknameMigrationService;
    @Autowired
    private NickNameRepository nickNameRepository;

    public NicknameResponse migrateAccountNickname(Long jobId, MigClient migClient) throws ServiceException {
        return process(migClient, jobId);
    }

    protected NicknameResponse process(MigClient migClient, Long jobId) throws ServiceException {
        NicknameResponse nicknameResponse = new NicknameResponse();
        Message logMessage = Message.create().jobId(jobId).clientId(migClient.getEcClientId()).gwClientId(migClient.getGwClientId()).entityName(Message.Entity.nickName);
        log.info(logMessage.summary().descr("Migration of account nickname started"));
        final RecordCount recordCount = new RecordCount();
        recordCount.setStartTime(new Timestamp(System.currentTimeMillis()));

        final MigClient migratedClient = migClient;

        log.info(logMessage.descr("Fetching Account nicknames for migration"));
        List<Nicknames> nicknamesList = stgAccountNicknameRepository.findByEcClientId(migClient.getEcClientId());

        if (nicknamesList.isEmpty()) {
            log.info(logMessage.summary().descr(NO_DATA_TO_MIGRATE));
            recordCount.setEndTime(new Timestamp(System.currentTimeMillis()));
            entityLogUtility.saveEntityCountAndTimeLog(MigrationEntityMapper.INSTANCE.convertNoNicknamesToMigEntity(migratedClient, recordCount, ENTITY_NAME));
            nicknameResponse.setAdditionalProperty(NO_NICKNAME_TO_MIGRATE,NO_DATA_TO_MIGRATE);
            return nicknameResponse;
        }
        log.info(logMessage.summary().descr("No.of Account nicknames fetched from staging : "+nicknamesList.size()));

        nicknamesList.stream().forEach(nickName -> {
            recordCount.setTotal(recordCount.getTotal() + 1);
            log.info(logMessage.summary().descr("Migrating account nickName with nickname - "+nickName.getAccTitle()).accountNumber(nickName.getAccountNumber()));
            MigrationNickname oldAccountNickname = nickNameRepository.findByGwClientIdAndAccountNumberAndJobIdAndCifNumber(migratedClient.getGwClientId(), nickName.getAccountNumber(), jobId, String.valueOf(migratedClient.getPrimaryCifUbs()));
            MigrationNickname newAccountNickname = new MigrationNickname();

            try {
                MigratedNicknamesEntity migratedNickname = migrationNicknameMapper.checkIfMigratedIgnoredOrRolledBack(jobId, migratedClient.getEcClientId(), nickName.getAccountNumber());
                if (migratedNickname != null && !migratedNickname.canRunAgain()) {
                    recordCount.setTotal(recordCount.getTotal() - 1);
                    if (migratedNickname.getStatus().equalsIgnoreCase(STATUS_IGNORE)) {
                        recordCount.setFailure(recordCount.getFailure() + 1);
                    }
                    log.info(logMessage.summary().descr("Record is not eligible for run because of the presence of record in staging with status - "+migratedNickname.getStatus()));
                } else if (isInvalidNickname(nickName)) {
                    recordCount.setFailure(recordCount.getFailure() + 1);
                    MigrationNickname ignoredNickname = MigrationNicknameModelMapper.INSTANCE.mapIgnoredNicknameToEntity(nickName, migratedClient);
                    nickNameRepository.save(ignoredNickname);
                    log.info(logMessage.summary().descr("Record is not eligible for run because of the presence of special characters in staging record - "+nickName.getAccTitle()));
                } else {
                    newAccountNickname = nicknameMigrationService.insert(nickName, migratedClient);
                    if(oldAccountNickname !=null){
                        newAccountNickname.updateFrom(oldAccountNickname);
                        newAccountNickname.setUpdatedBy(migrationUserId);
                    }
                    updateCounter(recordCount, newAccountNickname);
                    nickNameRepository.save(newAccountNickname);
                    log.info(logMessage.summary().descr("Updated nickname entity table with the migration status"));
                }

            } catch (ServiceException e) {
                log.error(logMessage.descr("Error occurred while processing " + e.getMessage()));
                nicknameResponse.setAdditionalProperty(e.getErrorCode(), e.getErrorMessage());
            }

        });
        recordCount.setEndTime(new Timestamp(System.currentTimeMillis()));
        createResponse(nicknameResponse,recordCount,migClient);
        if (recordCount.getTotal() > 0) {
            log.info(logMessage.summary().descr("Entity logging done as there were records that underwent account nickname migration during this run"));
            entityLogUtility.saveEntityCountAndTimeLog(MigrationEntityMapper.INSTANCE.convertNicknamesToMigEntity(nicknameResponse, recordCount, ENTITY_NAME));
        }

        log.info(logMessage.descr("Nickname migration is completed for clientId "+migClient.getEcClientId()+".Response is" + nicknameResponse.toString()).timeTaken(recordCount.getTotalStepTime()));

        return nicknameResponse;
    }

    private boolean isInvalidNickname(Nicknames nickname) {
        boolean isIvalid = false;
        if (null == nickname.getAccTitle()) {
            isIvalid = true;
        } else {
            Pattern regExPattern = Pattern.compile(SPECIAL_CHARACTER_ALLOWED);
            Matcher allowedCharacterMatcher = regExPattern.matcher(nickname.getAccTitle());
            if (!allowedCharacterMatcher.matches()) {
                isIvalid = true;
            }
        }
        return isIvalid;
    }

    private void updateCounter(RecordCount recordCount, MigrationNickname newNickname) {
        if (STATUS_SUCCESS.equalsIgnoreCase(newNickname.getStatus())) {
            recordCount.setSuccess(recordCount.getSuccess() + 1);
        } else {
            recordCount.setFailure(recordCount.getFailure() + 1);
        }
    }

    private void createResponse(NicknameResponse nicknameResponse, RecordCount recordCount, MigClient migClient) {
        nicknameResponse.setNicknameResponseData(NicknameResponseData.builder()
                .gwClientId(migClient.getGwClientId())
                .ecClientId(migClient.getEcClientId())
                .cifNumber(migClient.getPrimaryCifUbs() == null ? null : migClient.getPrimaryCifUbs().toString())
                .jobId(migClient.getJobId() == null ? 0 : migClient.getJobId().intValue())
                .recordCount(recordCount).build());
        nicknameResponse.setAdditionalProperty("Total Records for client: " + migClient.getEcClientId() + " is: ", recordCount.getTotal());
        nicknameResponse.setAdditionalProperty("Total Successfully registered alert Records: ", recordCount.getSuccess());
        nicknameResponse.setAdditionalProperty("Total Failed alert Records :", recordCount.getFailure());
    }

    public void rollback(String ecClientId, RollBackResponse rollBackResponse) {
        try {
            List<MigrationNickname> migrationNicknames = nickNameRepository.findAllByEcClientIdAndStatus(ecClientId, STATUS_SUCCESS);
            log.info("After record fetch");
            if (!migrationNicknames.isEmpty()) {
                migrationNicknames.forEach(nickName -> {
                            nickName.setStatus(STATUS_ROLLED_BACK);
                            nickName.setUpdatedBy(migrationUserId);
                            nickName.setUpdatedDate(LocalDateTime.now());
                        }
                );
                nickNameRepository.saveAll(migrationNicknames);
            }
            rollBackResponse.addSuccess("Nickname");
        } catch (Exception e) {
            rollBackResponse.addFailure("Nickname");
            log.error(Message.create().descr("Nickname Rollback failed").clientId(ecClientId));
        }
    }
}
