package com.svb.gateway.migration.payments.api;

import com.svb.gateway.migration.client.model.MigClientDTO;
import com.svb.gateway.migration.common.exception.ServiceException;
import com.svb.gateway.migration.payments.model.PaymentResponse;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;


@Api(value = "Payments")
@RequestMapping("api/payments")
public interface PaymentsApi {
    @ApiOperation(value = "Endpoint for creating future dated payments on Gateway", nickname = "createPayments", notes = "Create Payments")
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Future payment is Successful "),
            @ApiResponse(code = 401, message = "Unauthorized"),
            @ApiResponse(code = 400, message = "Invalid Client Id "),
            @ApiResponse(code = 403, message = "Forbidden"),
            @ApiResponse(code = 500, message = "Service unavailable ")})
    @RequestMapping(value = "/ipay/{jobId}",
            produces = {"application/json"},
            consumes = {"application/json"},
            method = RequestMethod.POST)
    @ResponseStatus(HttpStatus.OK)
    @PreAuthorize("hasAuthority(@migrationServiceConfig.getAuthExecute())")
    public ResponseEntity<PaymentResponse> createPayments( @PathVariable  Long jobId, @RequestBody MigClientDTO migClientDTO) throws ServiceException;
}
