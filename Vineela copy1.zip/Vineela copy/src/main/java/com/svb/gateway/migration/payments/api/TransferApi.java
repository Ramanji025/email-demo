package com.svb.gateway.migration.payments.api;


import com.svb.gateway.migration.client.model.MigClientDTO;
import com.svb.gateway.migration.common.exception.ServiceException;
import com.svb.gateway.migration.payments.model.TransferResponse;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

@Api(value = "Transfers")
@RequestMapping("api/transfers")
public interface TransferApi {

    @ApiOperation(value = "Endpoint for migrating Internal Transfers for client on Gateway", nickname = "intTransfers", notes = "Internal Transfers")
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Client Transaction data migration Successful "),
            @ApiResponse(code = 401, message = "Unauthorized"),
            @ApiResponse(code = 400, message = "Invalid Client Id "),
            @ApiResponse(code = 403, message = "Forbidden"),
            @ApiResponse(code = 500, message = "Service unavailable ")})
    @RequestMapping(value = "/scheduled/{jobId}",
            produces = {"application/json"},
            consumes = {"application/json"},
            method = RequestMethod.POST)
    @ResponseStatus(HttpStatus.OK)
    @PreAuthorize("hasAuthority(@migrationServiceConfig.getAuthExecute())")
    default ResponseEntity<TransferResponse> internalTransfer(@PathVariable Long jobId,
            @RequestBody MigClientDTO migClientDTO) throws ServiceException {
        return new ResponseEntity<>(HttpStatus.NOT_IMPLEMENTED);
    }


    @RequestMapping(value = "/rollback/{clientId}",
            produces = {"application/json"},
            consumes = {"application/json"},
            method = RequestMethod.POST)
    @ResponseStatus(HttpStatus.OK)
    @PreAuthorize("hasAuthority(@migrationServiceConfig.getAuthExecute())")
    default ResponseEntity<TransferResponse> rollback(
            @PathVariable String clientId) {
        return new ResponseEntity<>(HttpStatus.NOT_IMPLEMENTED);
    }


    @RequestMapping(value = "/wireoutgoing/{jobId}/{clientId}",
            produces = {"application/json"},
            consumes = {"application/json"},
            method = RequestMethod.POST)
    @ResponseStatus(HttpStatus.OK)
    @PreAuthorize("hasAuthority(@migrationServiceConfig.getAuthExecute())")
    default ResponseEntity<TransferResponse> wireTransfer(@PathVariable Long jobId,
            @PathVariable String clientId) throws ServiceException {
        return new ResponseEntity<>(HttpStatus.NOT_IMPLEMENTED);
    }
}

