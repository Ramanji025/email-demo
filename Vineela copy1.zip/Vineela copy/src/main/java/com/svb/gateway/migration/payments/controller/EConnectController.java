package com.svb.gateway.migration.payments.controller;

import com.svb.gateway.migration.client.entity.MigClient;
import com.svb.gateway.migration.client.model.MigClientDTO;
import com.svb.gateway.migration.client.service.ClientService;
import com.svb.gateway.migration.common.exception.ServiceException;
import com.svb.gateway.migration.payments.api.TransferApi;
import com.svb.gateway.migration.payments.model.TransferResponse;
import com.svb.gateway.migration.payments.service.EconnectService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import springfox.documentation.annotations.ApiIgnore;

@ApiIgnore
@Slf4j
@RestController
@RequestMapping("transfer")
public class EConnectController implements TransferApi {

    private final EconnectService econnectService;
    private final ClientService clientService;

    @Autowired
    public EConnectController(EconnectService econnectService, ClientService clientService) {
        this.econnectService = econnectService;
        this.clientService = clientService;
    }

    @Override
    public ResponseEntity<TransferResponse> internalTransfer(Long jobId,MigClientDTO migClientDTO) throws ServiceException {
        log.debug("TransfersController.transfers, clientId: " + migClientDTO.getEcClientId());
        MigClient migClient=new MigClient();
        BeanUtils.copyProperties(migClientDTO, migClient);
        return new ResponseEntity<>(econnectService.internalTransfer(jobId, migClient), HttpStatus.OK);
    }


    @Override
    public ResponseEntity<TransferResponse> wireTransfer(Long jobId, String clientId) throws ServiceException {

        log.debug("TransfersController.wireOutgoing, clientId: " + clientId);
        MigClient migClient = clientService.getMigClient(clientId, jobId);
        return new ResponseEntity<>(econnectService.wireTransfer(jobId, migClient), HttpStatus.OK);
    }

}
