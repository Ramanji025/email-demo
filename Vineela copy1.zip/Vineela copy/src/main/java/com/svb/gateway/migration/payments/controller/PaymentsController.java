package com.svb.gateway.migration.payments.controller;

import com.svb.gateway.migration.client.entity.MigClient;
import com.svb.gateway.migration.client.model.MigClientDTO;
import com.svb.gateway.migration.common.exception.ServiceException;
import com.svb.gateway.migration.common.utility.CommonValidator;
import com.svb.gateway.migration.payments.api.PaymentsApi;
import com.svb.gateway.migration.payments.model.PaymentResponse;
import com.svb.gateway.migration.payments.service.IpayPaymentService;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;
import springfox.documentation.annotations.ApiIgnore;

@ApiIgnore
@RestController
public class PaymentsController implements PaymentsApi {

    IpayPaymentService ipayPaymentService;

    @Autowired
    public PaymentsController(IpayPaymentService ipayPaymentService){
        this.ipayPaymentService = ipayPaymentService;
    }

    @Override
    public ResponseEntity<PaymentResponse> createPayments(Long jobId, MigClientDTO migClientDTO)  {
        try {
        MigClient migClient=new MigClient();
        //Sanitize check
        CommonValidator.ecClientIdCheck(migClientDTO.getEcClientId());
        CommonValidator.gwClientIdCheck(migClientDTO.getGwClientId());

        BeanUtils.copyProperties(migClientDTO, migClient);
            return new ResponseEntity<>(ipayPaymentService.createPayments(jobId, migClient), HttpStatus.OK);
        } catch (ServiceException e) {
            return new ResponseEntity<>(toErrorMessage(e.getMessage()), HttpStatus.BAD_REQUEST);
        }
    }

    private PaymentResponse toErrorMessage(String message) {
        PaymentResponse paymentResponse = new PaymentResponse();
        paymentResponse.setMessage(message);
        return paymentResponse;
    }
}
