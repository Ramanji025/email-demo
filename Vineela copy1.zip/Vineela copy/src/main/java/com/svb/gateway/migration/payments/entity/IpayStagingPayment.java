package com.svb.gateway.migration.payments.entity;


import com.svb.gateway.migration.payments.model.RecurringType;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import javax.persistence.*;
import java.time.LocalDate;

@ToString
@Getter
@Setter
@Entity
@Table(schema = "GWDMG", name = "MIG_STG_IPAY_PAYMENTS")
@Data
public class IpayStagingPayment {

    @Id
    @Column(name = "PAYMENT_ID")
    private Integer paymentId;

    @Column(name = "SUBSCRIBER_ID")
    private Integer subscriberId;

    @Column(name ="BENEFICIARY_ID")
    private Integer beneficiaryId;

    @Column(name = "PAYEE_RELATIONSHIP_NUMBER")
    private String payeeRelationshipNumber;

    @Column(name = "PAYMENT_AMOUNT")
    private Double paymentAmount;

    @Column(name = "PAYMENT_DATE")
    private LocalDate paymentDate;

    @Column(name = "EC_CLIENT_ID")
    private String ecClientId;

    @Column(name = "JOB_ID")
    private String jobId;

    @Column(name = "TRANSACTION_TYPE")
    private String transactionType;

    @Column(name = "SUBSCRIBER_ACCOUNT_NUMBER")
    private String subscriberAccountNumber;

    @Column(name = "NUM_OF_OCCURENCE_REM")
    private String occurencesRemaining;

    @Column(name = "PAYMENT_END_DATE")
    private LocalDate paymentEndDate;

    @Column(name = "PAYMENT_FREQUENCY")
    private Character paymentFrequency;

    @Column(name = "SKIPPED_PAYMENT")
    private String skippedPayment;

    @Column(name ="OVERRIDE_AMOUNT")
    private String overrideAmount;

    @Column(name = "OVERRIDE_SUBS_BANK_ID")
    private String overrideSubsidaryBankId;

    @Transient
    private Integer targetBeneficiaryId;

    @Transient
    private RecurringType recurringType;

    @Transient
    private String accNickName;

    @Transient
    private Integer targetGroupId;
}
