package com.svb.gateway.migration.payments.entity;

public class MigrationEntityId implements java.io.Serializable{

    Integer migEntityId;
    Integer jobId;
    String entityName;
}
