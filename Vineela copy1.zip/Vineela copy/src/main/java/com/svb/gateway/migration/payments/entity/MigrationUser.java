package com.svb.gateway.migration.payments.entity;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.util.Date;

@Entity
@Table(schema = "GWDMG", name = "MIG_USER")
@Getter
@Setter
public class MigrationUser {

    @Id
    @Column(name ="MIGUSERID")
    private Integer migUserId;

    @Column(name="JOBID")
    private Long jobId;

    @Column(name="ECCLIENTID")
    private String ecClientId;

    @Column(name="GWCLIENTID")
    private String gwClientId;

    @Column(name = "ECUSERLOGINID")
    private String ecUserLoginId;

    @Column(name="GWUUID")
    private String gwUuid;

    @Column(name="FIRSTNAME")
    private String firstName;

    @Column(name="LASTNAME")
    private String lastName;

    @Column(name="MOBILENUMBER")
    private String mobileNumber;

    @Column(name="EMILID")
    private String emailId;

    @Column(name="COMMENTS")
    private String comments;

    @Column(name="STATUS")
    private String status;

    @Column(name="UPDATEDBY")
    private String updateBy;

    @Column(name="UPDATEDDATE")
    private Date updateDate;



    public String getGwClientId() {
        return gwClientId==null?"":gwClientId.toUpperCase();
    }

    public String getGwUuid() {
        return gwUuid==null?"":gwUuid.toUpperCase();
    }
}
