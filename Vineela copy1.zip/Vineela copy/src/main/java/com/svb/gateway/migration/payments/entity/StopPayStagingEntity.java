package com.svb.gateway.migration.payments.entity;

import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.sql.Date;

@Slf4j
@Getter
@Setter
@Entity
@Table(schema = "GWDMG", name = "MIG_STG_STOP_PAYMENT_REQ")
public class StopPayStagingEntity {

    @Id
    @Column(name = "REQ_ID")
    private Long reqId;

    @Column(name = "CLIENT_ID")
    private String clientId;

    @Column(name = "USER_LOGIN_ID")
    private String userLoginId;

    @Column(name = "USER_FIRST_NAME")
    private String userFirstName;

    @Column(name = "USER_LAST_NAME")
    private String userLastName;

    @Column(name = "REQ_DT")
    private Date req_Dt;

    @Column(name = "REQ_STAT")
    private Integer reqStat;

    @Column(name = "REQ_TYPE")
    private Integer reqType;

    @Column(name = "ACC_NUM")
    private String accNum;

    @Column(name = "CHK_NUM")
    private String chkNum;

    @Column(name = "CHK_AMT")
    private Double chkAmt;

    @Column(name = "CHK_PYE_NM")
    private String chkPyeNm;

    @Column(name = "CHK_ISS_DT")
    private Date chkIssDt;

    @Column(name = "REC_NUM")
    private Integer recNum;

    @Column(name = "RETRY_COUNT")
    private Integer retryCount;

    @Column(name = "SP_RSNCD")
    private Integer spRsncd;

    @Column(name = "STOP_REASON_CD")
    private String stopReasonCd;

    @Column(name = "CURRENCY_CODE")
    private String currencyCode;

    @Column(name = "ACC_TITLE")
    private String accTitle;

    @Column(name = "EXPIRY_DATE")
    private Date expiryDate;

    @Column(name = "JOB_ID")
    private Long jobId;

    @Column(name = "REMARKS")
    private String remarks;

    @Column(name = "CREATED_BY")
    private String createdBy;

    @Column(name = "CREATED_DT")
    private Date createdDt;

    @Column(name = "MODIFIED_DT")
    private Date modifiedDt;

}
