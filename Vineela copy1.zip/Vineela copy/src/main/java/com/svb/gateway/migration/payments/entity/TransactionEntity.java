package com.svb.gateway.migration.payments.entity;


import lombok.*;

@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode
@ToString
@Setter
@Getter
public class TransactionEntity {

    private String EC_CLIENT_ID;
    private String GW_CLIENT_ID;
    private String GW_UUID;
    private String EC_USERLOGIN_ID;
    private Integer EC_TXN_ID;
    private Long GW_REQ_ID;
    private String STATUS;
    private String JOBID;
    private String PAYMENT_ID;
}
