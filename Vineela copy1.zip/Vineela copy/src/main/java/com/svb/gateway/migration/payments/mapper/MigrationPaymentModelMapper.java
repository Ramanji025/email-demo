package com.svb.gateway.migration.payments.mapper;

import com.svb.gateway.migration.client.entity.MigClient;
import com.svb.gateway.migration.common.utility.DateUtility;
import com.svb.gateway.migration.common.utility.PaymentUtils;
import com.svb.gateway.migration.ipay.batch.util.IPayConstants;
import com.svb.gateway.migration.payments.entity.*;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;
import org.springframework.util.StringUtils;

import java.time.*;

import static com.svb.gateway.migration.common.constants.MigrationConstants.STATUS_FAILURE;
import static com.svb.gateway.migration.common.constants.MigrationConstants.STATUS_IGNORE;


@Mapper(componentModel="spring")
public interface MigrationPaymentModelMapper {

    MigrationPaymentModelMapper INSTANCE = Mappers.getMapper(MigrationPaymentModelMapper.class);
    public static final String ONE="1";
    public static final String migrationUserId="SVB.svc.migration";

    @Mapping(source="ipayStagingPayment.paymentId",target="paymentId")
    @Mapping(source="ipayStagingPayment.ecClientId",target="ecClientId")
    @Mapping(expression="java(determineStatus(ipayStagingPayment))",target="status" )
    @Mapping(expression="java(addComments(ipayStagingPayment))",target="comments" )
    @Mapping(constant= migrationUserId,target="updatedby")
    @Mapping(expression= "java(getPSTDate())",target="updatedDate")
    @Mapping(source="migratedPayment.gwClientId",target="gwClientId")
    @Mapping(source="migratedPayment.gwReqId",target="gwReqId")
    @Mapping(source="migratedPayment.jobId",target="jobId")
    @Mapping(source="ipayStagingPayment.beneficiaryId",target="beneficiaryId")
    MigrationIpayPayment convertIpayPaymentToEntity(IpayStagingPayment ipayStagingPayment, MigrationIpayPayment migratedPayment);

    @Mapping(source="ipayStagingPayment.paymentId",target="paymentId")
    @Mapping(source="ipayStagingPayment.ecClientId",target="ecClientId")
    @Mapping(source="migClient.gwClientId",target="gwClientId")
    @Mapping(source="ipayStagingPayment.jobId",target="jobId")
    @Mapping(source="ipayStagingPayment.targetBeneficiaryId",target="beneficiaryId")
    MigrationIpayPayment convertIpayPaymentToEntity(IpayStagingPayment ipayStagingPayment, MigClient migClient);

    @Mapping(source="transfer.trnId",target="ecTxnId")
    @Mapping(source="migClient.ecClientId",target="ecClientId")
    @Mapping(constant= migrationUserId,target="updatedby")
    @Mapping(expression= "java(new java.util.Date())",target="updatedDate")
    @Mapping(source="migClient.gwClientId",target="gwClientId")
    @Mapping(source="transfer.jobId",target="jobId")
    MigrationInternalTransfer convertTransferToEntity(InternalTransfer transfer, MigClient migClient);

    @Mapping(source="migClient.ecClientId",target="ecClientId")
    @Mapping(constant= migrationUserId,target="updatedby")
    @Mapping(expression= "java(new java.util.Date())",target="updatedDate")
    @Mapping(source="migClient.gwClientId",target="gwClientId")
    @Mapping(source="transfer.jobId",target="jobId")
    @Mapping(source="transfer.wireTxnId",target="ecTxnId")
    MigrationWireTransfer convertTransferToEntity(WireTransfer transfer, MigClient migClient);

    default public LocalDateTime getPSTDate(){
        return DateUtility.getTimeZoneDate("America/Los_Angeles");
    }

    default public String determineStatus(IpayStagingPayment ipayStagingPayment){
        if(PaymentUtils.inValidRecurringPayment(ipayStagingPayment)){
            return STATUS_FAILURE;
        }
        return STATUS_IGNORE;
    }

    default public String addComments(IpayStagingPayment ipayStagingPayment){

        if(PaymentUtils.inValidRecurringPayment(ipayStagingPayment)){
            if(ONE.equals(ipayStagingPayment.getSkippedPayment())){
                return IPayConstants.SKIPPED_PAYMENT;
            }

            if(!StringUtils.isEmpty(ipayStagingPayment.getOverrideSubsidaryBankId())){
                return IPayConstants.OVERRIDE_SUBS_BANK_ID;
            }

            if(!StringUtils.isEmpty(ipayStagingPayment.getOverrideAmount())){
                return IPayConstants.OVERRIDE_AMOUNT;
            }
            if(!IPayConstants.getValidFrequencies().contains(ipayStagingPayment.getPaymentFrequency())){
                return IPayConstants.FREQUENCY_NOT_SUPPORTED + ipayStagingPayment.getPaymentFrequency();
            }
        }
        return "";
    }
}
