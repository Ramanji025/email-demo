package com.svb.gateway.migration.payments.mapper;


import com.svb.gateway.migration.payments.entity.TransactionEntity;
import org.apache.ibatis.annotations.*;
import org.springframework.stereotype.Repository;

import java.util.List;

@Mapper
@Repository
public interface OchMapper {
    @Select(value = {
            "SELECT",
            "i.EC_CLIENT_ID, i.GW_CLIENT_ID, i.GW_UUID, i.EC_USERLOGIN_ID, i.EC_TXN_ID, i.GW_REQ_ID, i.STATUS, i.JOBID",
            "FROM",
            "GWDMG.MIG_INT_TRANSFERS i",
            "WHERE",
            "i.EC_CLIENT_ID = #{olbClientId} and lower(i.STATUS) = 'success'",
            "UNION",
            "SELECT",
            "w.EC_CLIENT_ID, w.GW_CLIENT_ID, w.GW_UUID, w.EC_USERLOGIN_ID, w.EC_TXN_ID, w.GW_REQ_ID, w.STATUS, w.JOBID",
            "FROM",
            "GWDMG.MIG_WIRE_OUTGOING w",
            "WHERE",
            "w.EC_CLIENT_ID = #{olbClientId} and lower(w.STATUS) = 'success'"
    })
    List<TransactionEntity> getReqIdWithClientId(String olbClientId);

    @Select(value = {
            "SELECT",
            "EC_CLIENT_ID, GW_CLIENT_ID, GW_UUID, EC_USERLOGIN_ID, EC_TXN_ID, GW_REQ_ID, STATUS, JOBID",
            "FROM ${tableName}",
            "WHERE",
            "i.EC_CLIENT_ID = #{olbClientId}  and JOBID= #{jobId}"
    })
    List<TransactionEntity> getTransfers(@Param("olbClientId") String olbClientId,@Param("jobId") Long jobId, @Param("tableName") String tableName);

    @Select(value = {
            "SELECT",
            "EC_CLIENT_ID, GW_CLIENT_ID, GW_UUID, EC_USERLOGIN_ID, PAYMENT_ID, GW_REQ_ID, STATUS, JOBID",
            "FROM GWDMG.MIG_IPAY_PAYMENTS ",
            "WHERE",
            "EC_CLIENT_ID = #{olbClientId} and JOBID= #{jobId}"
    })
    List<TransactionEntity> getPayments(@Param("olbClientId") String olbClientId,@Param("jobId") Long jobId);

    @Select(value = {
            "<script> SELECT REQ_ID from OCHADM.TRANSACTION_HEADER",
            " WHERE req_id IN  ",
            "<foreach item='item' index='index' collection='reqIds'",
            "open='(' separator=',' close=')'>",
            "#{item}",
            "</foreach>",
            "</script>"
    })
    List<Long> findByReqIds(@Param("reqIds") List<Long> reqIds);

    @Update(value = {
            "<script> UPDATE OCHADM.${tableName}",
            " set DEL_FLG='Y', R_MOD_TIME=SYSDATE WHERE req_id IN  ",
            "<foreach item='item' index='index' collection='reqIds'",
            "open='(' separator=',' close=')'>",
            "#{item}",
            "</foreach>",
            "</script>"
    })
    void deleteTransactionRequests(@Param("reqIds") List<Long> reqIds, @Param("tableName") String tableName);
}
