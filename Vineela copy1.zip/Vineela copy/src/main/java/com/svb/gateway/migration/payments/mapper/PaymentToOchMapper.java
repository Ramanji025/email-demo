package com.svb.gateway.migration.payments.mapper;

import com.svb.gateway.migration.common.exception.ServiceException;
import com.svb.gateway.migration.common.utility.FrequencyPeriod;
import com.svb.gateway.migration.payments.entity.*;
import com.svb.gateway.migration.payments.model.OchPaymentRequest;
import com.svb.gateway.migration.payments.model.RecurringType;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;
import org.mapstruct.factory.Mappers;

import com.svb.gateway.migration.common.utility.DateUtility;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import static com.svb.gateway.migration.common.constants.MigrationConstants.*;

@Mapper(componentModel="spring")
public interface PaymentToOchMapper {
    PaymentToOchMapper INSTANCE = Mappers.getMapper(PaymentToOchMapper.class);

    public static String ZERO="0";
    public static final String USD = "USD";
    public static final String COUNTER_PARTY_TYPE="P";

    @Mapping(constant = "groupId", target="fieldKey")
    @Mapping(source = "payment.targetGroupId", target="fieldValue")
    OchPaymentRequest.EntryDetails.Field mapTargetGroupIdToExtraFields(IpayStagingPayment payment);

    @Mapping(constant = "accountNickName", target="fieldKey")
    @Mapping(source = "payment.accNickName", target="fieldValue")
    OchPaymentRequest.EntryDetails.Field mapDebitAccountNickNameToExtraFields(IpayStagingPayment payment);

    @Mapping(constant = ZERO,target = "entryID")
    @Mapping(source = "payment.subscriberAccountNumber",target = "initiatorAccount")
    @Mapping(source = "payment.paymentAmount",target = "amount")
    @Mapping(constant =USD ,target = "accountCurrency")
    @Mapping(constant = COUNTER_PARTY_TYPE,target = "counterpartyType")
    @Mapping(source = "payment.transactionType",target = "network")
    @Mapping(constant = "",target = "remarks")
    @Mapping(source = "payment.targetBeneficiaryId",target = "payeeAccountDetails.counterpartyAccount")
    @Mapping(constant = NW_COMMISSION_INDICATOR,target = "additionalCounterpartyDetails.commissionIndicator")
    @Mapping(source = "extraTransactionDetails", target = "extraTransactionDetails")
    OchPaymentRequest.EntryDetails convertFutureIpayPaymentToEntryDetails(IpayStagingPayment payment, OchPaymentRequest.EntryDetails.Field[] extraTransactionDetails);

    @Mapping(constant = "",target = "transactionReferenceName")
    @Mapping(source = "ipayStagingPayment.paymentFrequency",target = "frequencyType", qualifiedByName = "determineFrequency")
    @Mapping(expression = "java(getOCHTransferDate(ipayStagingPayment))", target = "transactionDate")
    @Mapping(constant = USD,target = "transactionCurrency")
    @Mapping(source="ipayStagingPayment.transactionType",target = "transactionType")
    @Mapping(source="entryDetails", target="entryDetails")
    @Mapping(constant = VALIDITY_INDICATOR,target = "recurringDetails.validityIndicator")
    @Mapping(source= "ipayStagingPayment",target = "recurringDetails.recurringFrequency", qualifiedByName = "ochFrequencyCode")
    @Mapping(source="ipayStagingPayment", target = "recurringDetails.numberOfInstallments", qualifiedByName = "getTotalInstances")
    @Mapping(source="ipayStagingPayment", target = "recurringDetails.lastPaymentDate", qualifiedByName = "lastPaymentDate")
    OchPaymentRequest convertFutureIpayPaymentToPayments(IpayStagingPayment ipayStagingPayment, OchPaymentRequest.EntryDetails[] entryDetails) throws ServiceException;

    @Named("determineFrequency")
    default String determineFrequency(Character paymentFrequency){
        return paymentFrequency==null || paymentFrequency==' '? FREQ_TYPE_O: FREQ_TYPE_R;
    }
    @Named("ochFrequencyCode")
    default String ochFrequencyCode(IpayStagingPayment ipayStagingPayment){
        if(ipayStagingPayment.getPaymentFrequency()==null){
            return null;
        }
        FrequencyPeriod fp=FrequencyPeriod.fromValue(ipayStagingPayment.getPaymentFrequency());
        return fp!=null?String.valueOf(fp.getOchCode()):null;
    }

    @Named("getTotalInstances")
    default String getTotalInstances(IpayStagingPayment ipayStagingPayment){
        int totalInstances=0;
        if(ipayStagingPayment.getRecurringType()== RecurringType.NONE) return "1";
        if(ipayStagingPayment.getRecurringType()==RecurringType.OCCURENCE) {
            totalInstances= Integer.valueOf(ipayStagingPayment.getOccurencesRemaining());
        }else if(ipayStagingPayment.getRecurringType() == RecurringType.ENDDATE){
           return "";
        }
        return String.valueOf(totalInstances);
    }

    @Named("lastPaymentDate")
    default String lastPaymentDate(IpayStagingPayment ipayStagingPayment) throws ServiceException {
        String lastPaymentDate="";
        if(ipayStagingPayment.getRecurringType()== RecurringType.NONE) return lastPaymentDate;
        if(ipayStagingPayment.getRecurringType()==RecurringType.OCCURENCE) {
            //do nothing, send this empty
            return lastPaymentDate;
        }else if(ipayStagingPayment.getRecurringType() == RecurringType.ENDDATE){
            lastPaymentDate=getLastPaymentDate(ipayStagingPayment);
        }
        return lastPaymentDate;
    }

    default String getOCHTransferDate(IpayStagingPayment ipayStagingPayment) throws ServiceException {
        String formattedDate="";
        try{
            formattedDate=DateUtility.getTranDateInOchFormat(new SimpleDateFormat("yyyy-MM-dd").parse(ipayStagingPayment.getPaymentDate().toString()));
        }
        catch(ParseException pe){
            throw new ServiceException("Payment date formatting error","Could not convert the payment date to required format");
        }

        return   formattedDate;  }

    default String getLastPaymentDate(IpayStagingPayment ipayStagingPayment) throws ServiceException {
        String formattedDate="";
        try{
            formattedDate=DateUtility.getTranDateInOchFormat(new SimpleDateFormat("yyyy-MM-dd").parse(ipayStagingPayment.getPaymentEndDate().toString()));
        }
        catch(ParseException pe){
            throw new ServiceException("Payment end date formatting error","Could not convert the payment end date to required format");
        }

        return   formattedDate;  }

}



