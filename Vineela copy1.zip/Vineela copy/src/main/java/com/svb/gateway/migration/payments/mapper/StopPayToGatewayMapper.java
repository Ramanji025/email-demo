package com.svb.gateway.migration.payments.mapper;

import com.svb.gateway.migration.payments.entity.StopPayStagingEntity;
import com.svb.gateway.migration.payments.model.StopPayMigrationRequest;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

@Mapper(componentModel="spring")
public interface StopPayToGatewayMapper {

    StopPayToGatewayMapper INSTANCE = Mappers.getMapper(StopPayToGatewayMapper.class);

    public static final String CURRENCY="USD";
    public static final String CONTEXT_ALERT_SUBSCRIBE_FLAG = "N";

    @Mapping(source = "stgStopPayment.currencyCode", target = "accountCurrency")
    @Mapping(source = "stgStopPayment.accNum", target = "initiatorAccount")
    @Mapping(source = "stgStopPayment.accTitle", target = "name")
    StopPayMigrationRequest.PayFrom convertEcPayFromToGWRequest(StopPayStagingEntity stgStopPayment);

    @Mapping(source = "stgStopPayment.chkAmt", target = "amount")
    @Mapping(source = "stgStopPayment.chkIssDt", target = "issuedDate")
    @Mapping(source = "stgStopPayment.chkNum", target = "checkNumber")
    @Mapping(constant = CURRENCY, target = "currency")
    @Mapping(source = "stgStopPayment.chkPyeNm", target = "payeeName")
    StopPayMigrationRequest.SingleCheck convertEcSingleCheckToGWRequest(StopPayStagingEntity stgStopPayment);

    @Mapping(source = "stgStopPayment.recNum", target = "cspRefId")
    @Mapping(constant = CONTEXT_ALERT_SUBSCRIBE_FLAG, target = "contextAlertSubscribe")
    @Mapping(source = "stgStopPayment.req_Dt", target = "effectiveDate")
    @Mapping(source = "stgStopPayment.expiryDate", target = "expiryDate")
    @Mapping(constant = "", target = "otherReason")
    @Mapping(source = "gWClientId", target = "clientId")
    @Mapping(source = "gWUuid", target = "userId")
    @Mapping(source = "stgStopPayment.userFirstName", target = "userFirstName")
    @Mapping(source = "stgStopPayment.userLastName", target = "userLastName")
    @Mapping(source = "stgStopPayment.stopReasonCd", target = "reason")
    @Mapping(source = "payFrom", target = "payFrom")
    @Mapping(source = "singleCheck", target = "singleCheck")
    StopPayMigrationRequest convertEcStopPayToGWRequest(StopPayStagingEntity stgStopPayment, String gWClientId, String gWUuid, StopPayMigrationRequest.PayFrom payFrom, StopPayMigrationRequest.SingleCheck singleCheck);

}
