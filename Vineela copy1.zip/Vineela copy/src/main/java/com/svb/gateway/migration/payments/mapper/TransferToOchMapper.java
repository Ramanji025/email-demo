package com.svb.gateway.migration.payments.mapper;

import com.svb.gateway.migration.common.utility.DateUtility;
import com.svb.gateway.migration.payments.entity.*;
import com.svb.gateway.migration.payments.model.OchPaymentRequest;
import com.svb.gateway.migration.payments.model.RecurringType;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;
import org.mapstruct.factory.Mappers;

import java.time.LocalDateTime;

import static com.svb.gateway.migration.common.constants.MigrationConstants.*;

@Mapper(componentModel="spring")
public interface TransferToOchMapper {
    TransferToOchMapper INSTANCE = Mappers.getMapper(TransferToOchMapper.class);

    public static String ZERO="0";
    public static final String TRANSFER_TXN_TYPE = "XFR";

    @Mapping(constant = ZERO,target = "entryID")
    @Mapping(source = "transfer.fromAccountNumber",target = "initiatorAccount")
    @Mapping(source = "transfer.transferAmount",target = "amount")
    @Mapping(source = "transfer.trnAcCrn",target = "accountCurrency")
    @Mapping(constant = "T",target = "counterpartyType")
    @Mapping(constant = NETWORK_ID,target = "network")
    @Mapping(constant = "migration",target = "remarks")
    @Mapping(source = "transfer.toAccountNumber",target = "payeeAccountDetails.counterpartyAccount")
    OchPaymentRequest.EntryDetails convertFutureInternalTransferToEntryDetails(InternalTransfer transfer);

    @Mapping(constant = "",target = "transactionReferenceName")
    @Mapping(source = "transfer",target = "frequencyType", qualifiedByName = "determineFrequency")
    @Mapping(expression = "java(getOCHTransferDate(transfer))", target = "transactionDate")
    @Mapping(source = "transfer.trnAcCrn",target = "transactionCurrency")
    @Mapping(constant = TRANSFER_TXN_TYPE,target = "transactionType")
    @Mapping(source="entryDetails", target="entryDetails")
    @Mapping(constant = VALIDITY_INDICATOR,target = "recurringDetails.validityIndicator")
    @Mapping(source="transfer.frequencyId",target = "recurringDetails.recurringFrequency")
    @Mapping(source="transfer", target = "recurringDetails.numberOfInstallments", qualifiedByName = "numberOfInstallments")
    @Mapping(source="transfer", target = "recurringDetails.lastPaymentDate", qualifiedByName = "lastPaymentDate")
    OchPaymentRequest convertFutureInternalTransferToTransfers(InternalTransfer transfer, OchPaymentRequest.EntryDetails[] entryDetails);


    @Named("determineFrequency")
    default String determineFrequency(InternalTransfer transfer){
        return transfer.getRecurringType().name().equals(RecurringType.NONE.name())? FREQ_TYPE_O:FREQ_TYPE_R;
    }

    @Named("numberOfInstallments")
    default String numberOfInstallments(InternalTransfer transfer){
        int totalInstances=0;
        if(transfer.getRecurringType()== RecurringType.NONE) return "1";
        if(transfer.getRecurringType()==RecurringType.OCCURENCE) {
            totalInstances= transfer.getScheduleOccurrences() - transfer.getNthOccurrence();
            totalInstances=totalInstances+1;
        }else if(transfer.getRecurringType() == RecurringType.ENDDATE){
            return "";
        }
        return String.valueOf(totalInstances);
    }

    @Named("lastPaymentDate")
    default String lastPaymentDate(InternalTransfer transfer){
        String lastPaymentDate="";
        if(transfer.getRecurringType()== RecurringType.NONE) return lastPaymentDate;
        if(transfer.getRecurringType()==RecurringType.OCCURENCE) {
            //do nothing, send this empty
            return lastPaymentDate;
        }else if(transfer.getRecurringType() == RecurringType.ENDDATE){
            lastPaymentDate=DateUtility.getTranDateInOchFormat(transfer.getScheduleEndDate());
        }
        return lastPaymentDate;
    }


    public default LocalDateTime getPSTDate(){
        return DateUtility.getTimeZoneDate("America/Los_Angeles");
    }

    public default String getOCHTransferDate(InternalTransfer transfer){
        return DateUtility.getTranDateInOchFormat(transfer.getTransferDate());
    }
}

