package com.svb.gateway.migration.payments.mapper;

import com.svb.gateway.migration.common.utility.DateUtility;
import com.svb.gateway.migration.payments.entity.*;
import com.svb.gateway.migration.payments.model.OchPaymentRequest;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import java.time.LocalDateTime;

import static com.svb.gateway.migration.common.constants.MigrationConstants.*;

@Mapper(componentModel="spring")
public interface WireTransferToOchMapper {
    WireTransferToOchMapper INSTANCE = Mappers.getMapper(WireTransferToOchMapper.class);

    public static String ZERO="0";
    public static final String SAVE_TO_PERSONAL_PAYEE_FLAG="N";
    public static final String ADHOC_COUNTER_PARTY_TYPE="H";
    public static final String ADHOC_ACCOUNT_IDENTIFIER="A";
    public static final String ADHOC_PAYEE_BANK="ABK";
    public static final String ADHOC_PAYEE_NETWORK="ABA";


    public default LocalDateTime getPSTDate(){
        return DateUtility.getTimeZoneDate("America/Los_Angeles");
    }



    @Mapping(constant = ZERO,target = "entryID")
    @Mapping(source = "transfer.fromAccountNumber",target = "initiatorAccount")
    @Mapping(source = "transfer.debitAmt",target = "amount")
    @Mapping(source = "transfer.debitCrncyCode",target = "accountCurrency")
    @Mapping(constant = ADHOC_COUNTER_PARTY_TYPE,target = "counterpartyType")
    @Mapping(expression = "java(transfer.getNetworkId())",target = "network")
    @Mapping(source = "transfer.beneInstructions",target = "remarks")
    @Mapping(source = "transfer.beneAccount",target = "payeeAccountDetails.counterpartyAccount")
    @Mapping(source = "transfer.beneName",target = "payeeAccountDetails.adhocPayeeDetails.payeeName")
    @Mapping(constant = SAVE_TO_PERSONAL_PAYEE_FLAG,target = "payeeAccountDetails.adhocPayeeDetails.saveToPersonalPayee")
    @Mapping(constant = "",target = "payeeAccountDetails.adhocPayeeDetails.payeeNickName")
    @Mapping(constant = ADHOC_ACCOUNT_IDENTIFIER,target = "payeeAccountDetails.adhocPayeeDetails.accountIdentifier")
    @Mapping(source = "transfer.crncyCode",target = "payeeAccountDetails.adhocPayeeDetails.accountCurrency")
    @Mapping(source = "transfer.beneBankId",target = "payeeAccountDetails.adhocPayeeDetails.payeeBankIdentifier")
    @Mapping(constant = ADHOC_PAYEE_BANK,target = "payeeAccountDetails.adhocPayeeDetails.payeeBank")
    @Mapping(constant = ADHOC_PAYEE_NETWORK,target = "payeeAccountDetails.adhocPayeeDetails.payeeNetwork")
    @Mapping(source = "transfer.beneAdd1",target = "payeeAccountDetails.adhocPayeeDetails.counterpartyAddressVO.addressLine1")
    @Mapping(source = "transfer.beneAdd2",target = "payeeAccountDetails.adhocPayeeDetails.counterpartyAddressVO.addressLine2")
    @Mapping(source = "transfer.beneAdd3",target = "payeeAccountDetails.adhocPayeeDetails.counterpartyAddressVO.addressLine3")
    @Mapping(constant = "",target = "payeeAccountDetails.adhocPayeeDetails.counterpartyAddressVO.zipCode")
    @Mapping(constant = "",target = "payeeAccountDetails.adhocPayeeDetails.counterpartyAddressVO.state")
    @Mapping(constant = "",target = "payeeAccountDetails.adhocPayeeDetails.counterpartyAddressVO.country")
    @Mapping(constant = NW_COMMISSION_INDICATOR,target = "additionalCounterpartyDetails.commissionIndicator")
    @Mapping(source = "extraTransactionDetails", target = "extraTransactionDetails")
    OchPaymentRequest.EntryDetails convertFutureWireTransferToEntryDetails(WireTransfer transfer, OchPaymentRequest.EntryDetails.Field[] extraTransactionDetails);

    @Mapping(constant = "",target = "transactionReferenceName")
    @Mapping(constant = FREQ_TYPE_O,target = "frequencyType")
    @Mapping(expression = "java(getOCHTransferDate(transfer))", target = "transactionDate")
    @Mapping(source = "transfer.crncyCode",target = "transactionCurrency")
    @Mapping(expression="java(transfer.getTransactionType())",target = "transactionType")
    @Mapping(source="entryDetails", target="entryDetails")
    @Mapping(constant = VALIDITY_INDICATOR,target = "recurringDetails.validityIndicator")
    OchPaymentRequest convertFutureWireTransferToPayments(WireTransfer transfer, OchPaymentRequest.EntryDetails[] entryDetails);

    @Mapping(constant = "payeeBankCountryCode", target="fieldKey")
    @Mapping(source = "isoCountryCode", target="fieldValue")
    OchPaymentRequest.EntryDetails.Field mapMandatoryBeneficiaryBankCountryToExtraFields(String isoCountryCode);

    @Mapping(constant = "intermediaryBankRoutingCode", target="fieldKey")
    @Mapping(source = "transfer.intrmId", target="fieldValue")
    OchPaymentRequest.EntryDetails.Field mapOptionalIntermediaryBankRoutingCode(WireTransfer transfer);

    @Mapping(constant = "intermediaryBankName", target="fieldKey")
    @Mapping(source = "transfer.intrmName", target="fieldValue")
    OchPaymentRequest.EntryDetails.Field mapOptionalIntermediaryBankName(WireTransfer transfer);

    @Mapping(constant = "intermediaryBankAddress", target="fieldKey")
    @Mapping(source = "transfer.intrmAddress", target="fieldValue")
    OchPaymentRequest.EntryDetails.Field mapOptionalIntermediaryBankAddress(WireTransfer transfer);

    @Mapping(constant = "payeeBankName", target="fieldKey")
    @Mapping(source = "transfer.beneBankName", target="fieldValue")
    OchPaymentRequest.EntryDetails.Field mapOptionalPayeeBankName(WireTransfer transfer);

    @Mapping(constant = "payeeBankAddressLine1", target="fieldKey")
    @Mapping(source = "transfer.beneBankCity", target="fieldValue")
    OchPaymentRequest.EntryDetails.Field mapOptionalPayeeBankAddressLine1(WireTransfer transfer);

    @Mapping(constant = "bankToBankInstructions", target="fieldKey")
    @Mapping(source = "transfer.bankToBankInstructions", target="fieldValue")
    OchPaymentRequest.EntryDetails.Field mapOptionalBankToBankInstructions(WireTransfer transfer);


    public default String getOCHTransferDate(WireTransfer transfer) {
        return DateUtility.getTranDateInOchFormat(transfer.getValueDate());
    }

}

