package com.svb.gateway.migration.payments.model;

public interface MigStopPayUser {
    String getEcClientId();
    String getEcUserLoginId();
    String getGwUid();
    String getGwClientId();
    String getPrimaryCifUbs();
    String getUserStatus();
    String getClientStatus();
}
