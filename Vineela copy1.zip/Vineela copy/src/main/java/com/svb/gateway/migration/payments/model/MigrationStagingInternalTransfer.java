package com.svb.gateway.migration.payments.model;


import lombok.Data;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.time.LocalDate;
import java.util.Date;

@Entity
@Table(schema = "GWDMG", name = "MIG_STG_INTERNAL_XFER")
@Data
public class MigrationStagingInternalTransfer {

    @Id
    @Column(name = "TRN_ID")
    private Integer trnId;

    @Column(name = "OLB_CLIENT_ID")
    private String olbClientId;

    @Column(name = "TRANSFER_DATE")
    private Date trnsDate;

    @Column(name = "USER_LOGIN_ID")
    private String userLoginId;

    @Column(name = "TRN_AMT")
    private Double trnAmt;

    @Column(name = "TRN_DT")
    private LocalDate trnDate;

    @Column(name = "TRN_STAT")
    private Integer trnStat;

    @Column(name = "FR_ACC_NUM")
    private String frAccNum;

    @Column(name = "TO_ACC_NUM")
    private String toAccNum;

    @Column(name = "DESCR")
    private String desc;

    @Column(name = "TRAN_ACT_CRN")
    private String trnAcCrn;

    @Column(name = "JOB_ID")
    private String jobId;

    @Column(name = "CREATED_BY")
    private String createdBy;

    @Column(name = "CREATED_DT")
    private LocalDate createdDt;

    @Column(name = "MODIFIED_DT")
    private LocalDate modifiedDt;

    @Column(name = "FREQUENCY_ID")
    private Integer frequencyId;

    @Column(name = "CREATED_DATE")
    private LocalDate createdDate;

    @Column(name = "START_DATE")
    private LocalDate startDate;

    @Column(name = "DAY_OF_THE_WEEK")
    private Integer dayOfTheWeek;

    @Column(name = "RECURRING_STATUS")
    private Integer recurringStatus;

    @Column(name = "DAY_OF_MONTH")
    private String dayOfTheMonth;

    @Column(name = "OCCURRENCE_DATE")
    private LocalDate occurrenceDate;

    @Column(name = "NTH_OCCURRENCE")
    private Integer nthOccurrence;

    @Column(name = "SCHEDULE_DETAILS_ID")
    private Integer scheduleDetailsId;

    @Column(name = "OCCURRENCE_ID")
    private Integer occurrenceId;

    @Column(name = "SCHEDULE_ID")
    private Integer scheduleId;

    @Column(name = "SCHEDULE_END_TYPE_ID")
    private Integer scheduleEndTypeId;

    @Column(name = "SCHEDULE_END_DATE")
    private LocalDate scheduleEndDate;

    @Column(name = "SCHEDULE_OCCURANCES")
    private Integer scheduleOccurrences;
}
