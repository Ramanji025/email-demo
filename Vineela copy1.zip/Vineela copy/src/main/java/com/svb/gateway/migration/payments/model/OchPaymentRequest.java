package com.svb.gateway.migration.payments.model;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class OchPaymentRequest {
    private String transactionReferenceName;
    private String transactionDate;
    private String transactionCurrency;
    private String transactionType;
    private String frequencyType;
    private RecurringDetails recurringDetails;
    private EntryDetails[] entryDetails;

    @Getter
    @Setter
    @ToString
    public static class RecurringDetails {
        private String firstPaymentAmount;
        private String firstPaymentDate;
        private String frequencyInDays;
        private String lastPaymentAmount;
        private String lastPaymentDate;
        private String lastPaymentDateFlag;
        private String numberOfInstallments;
        private String recurringFrequency;
        private String validityIndicator;
        private String modifySingleInstance;
    }

    @Getter
    @Setter
    @ToString
    public static class EntryDetails {
        private String accountCurrency;
        private Field[] extraTransactionDetails;
        private AdditionalCounterpartyDetails additionalCounterpartyDetails;

        public void setExtraTransactionDetails(Field[] filteredArray) {
            extraTransactionDetails=filteredArray;
        }

        public Field[] getExtraTransactionDetails() {
            return extraTransactionDetails;
        }

        @Getter
        @Setter
        @ToString
        public static class AdditionalCounterpartyDetails {
            private String commissionIndicator;
        }

        private String amount;
        private String counterpartyType;
        private Integer entryID;
        private PayeeAccountDetails payeeAccountDetails;

        @Getter
        @Setter
        @ToString
        public static class Field {
            private String fieldKey;
            private String fieldValue;

            public String getFieldValue() {
                return fieldValue;
            }
            public String getFieldKey() {
                return fieldKey;
            }

        }
        private String initiatorAccount;

        @Getter
        @Setter
        @ToString
        public static class IntermediaryBank {
            private String bankAddress;
            private String bankName;
            private String routingCode;
        }

        @Getter
        @Setter
        @ToString
        public static class PayeeAccountDetails {
            private String counterpartyAccount;
            private AdhocPayeeDetails adhocPayeeDetails;
        };

        @Getter
        @Setter
        @ToString
        public static class AdhocPayeeDetails {
            private String payeeName;
            private String saveToPersonalPayee;
            private String payeeNickName;
            private String accountIdentifier;
            private String accountCurrency;
            private String payeeBankIdentifier;
            private String payeeBank;
            private String payeeNetwork;
            private CounterpartyAddressVO counterpartyAddressVO;
        };

        @Getter
        @Setter
        @ToString
        public static class CounterpartyAddressVO {
            private String addressLine1;
            private String addressLine2;
            private String addressLine3;
            private String zipCode;
            private String state;
            private String country;
        };

        private String network;
        private String remarks;
    }

}
