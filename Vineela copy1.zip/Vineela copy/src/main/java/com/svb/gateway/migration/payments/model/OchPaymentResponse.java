package com.svb.gateway.migration.payments.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@JsonIgnoreProperties(ignoreUnknown = true)
public class OchPaymentResponse {
    private RecurringDetails recurringDetails;
    private String transactionReferenceName;
    private FrequencyType frequencyType;

    @Getter
    @Setter
    public static class FrequencyType {
        private String description;
        private String id;
    }

    @Getter
    @Setter
    public static class RecurringDetails {
        private String firstPaymentAmount;
        private String frequencyInDays;
        private String lastPaymentAmount;
        private String lastPaymentDate;
        private String lastPaymentDateFlag;
        private String numberOfInstallments;
        private String modifySingleInstance;
        private RecurringFrequency recurringFrequency;
        private ValidityIndicator validityIndicator;
        @Getter
        @Setter
        public static class RecurringFrequency {
            private String description;
            private String id;
        }

        @Getter
        @Setter
        public static class ValidityIndicator {
            private String description;
            private String id;
        }
    }



    private String nextInstallmentDate;
    private String manualReleaseRequired;
    private String transactionDate;
    private String isPriorityTransaction;

    private OCHCodeReferenceDetails transactionCurrency;
    private OCHCodeReferenceDetails transactionType;
    private String isTransactionConfidential;
    private EntryDetails entryDetails[];

    @Getter
    @Setter
    private static class OCHCodeReferenceDetails {
        private String cmCode;
        private String codeDescription;
        private String codeType;
    }

    @Getter
    @Setter
    public static class EntryDetails {
        private String accountCurrency;

        private String accountName;
        private String accountType;
        private AdditionalCounterpartyDetails additionalCounterpartyDetails;
        private NegotiatedRateDetails negotiatedRateDetails;
        private AdditonalInitiatorDetails additonalInitiatorDetails;
        private String amount;
        private String bankToBankInstructions;
        private String counterpartyType;
        private String creditOrDebit;
        private String emailAddresses;
        private Long entryID;
        private PayeeAccountDetails payeeAccountDetails;
        private Field[] extraTransactionDetails;

        @Setter
        @Getter
        public static class AdditonalInitiatorDetails{
            private String remark;
        }

        @Setter
        @Getter
        public static class NegotiatedRateDetails{
            private int negotiatedRate;
        }

        @Getter
        @Setter
        public static class AdditionalCounterpartyDetails {
            private OCHCodeReferenceDetails commissionIndicator;
        }



        @Getter
        @Setter
        public static class Field {
            private String fieldKey;
            private String fieldValue;
        }
        private String initiatorAccount;

        @Getter
        @Setter
        public static class IntermediaryBank {
            private String bankAddress;
            private String bankName;
            private String routingCode;
        }

        @Getter
        @Setter
        public static class PayeeAccountDetails {
            private String counterpartyAccount;
            private PersonalPayees personalPayees;

            @Getter
            @Setter
            private static class PersonalPayees {
                private String accountNumber;
                private CounterpartyAddressVO counterpartyAddressVO;

                @Getter
                @Setter
                public static class CounterpartyAddressVO {
                    private Country country;
                    private State state;
                    @Getter
                    @Setter
                    public static class Country {
                        private String codeType;
                    }
                    @Getter
                    @Setter
                    public static class State{
                        private String codeType;
                    }

                }
                private String payeeNickname;
            }
        }

        private OCHCodeReferenceDetails network;
        private String payeeReference;
        private String noteToPayee;
        private String purposeOfPaymentCode;
        private String purposeOfPaymentDescription;
        private String purposeOfPaymentFreeForm;
        private String remarks;
        private String markForDelete;
    }
        private CommonSection commonSection;

    @Setter
    @Getter
    public static class CommonSection {
        private int chargeAmount;
        private int highestEntryAmount;
        private String markedForStop;
        private int numberOfEntries;
        private int requestReferenceId;
        private String tentativeCreditDate;
        private int totalAmount;
        private int totalTransactionAmount;
        private int transactionReferenceId;
        private OCHCodeReferenceDetails transactionStatus;
    }

    private String userId;
    private String parentReferenceID;
    private int templateId;

}
