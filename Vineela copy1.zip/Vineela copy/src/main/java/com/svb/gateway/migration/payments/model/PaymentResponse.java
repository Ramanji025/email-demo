package com.svb.gateway.migration.payments.model;

import com.fasterxml.jackson.annotation.*;
import com.svb.gateway.migration.common.model.Error;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;


import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Getter
@Setter
@ToString
public class PaymentResponse {

    @JsonProperty("Data")
    private PaymentResponseData paymentResponseData = PaymentResponseData.builder().build();

    @JsonProperty("Error Message")
    private String message;

    @JsonProperty("Errors")
    private List<Error> errors = new ArrayList<>();

    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }
}
