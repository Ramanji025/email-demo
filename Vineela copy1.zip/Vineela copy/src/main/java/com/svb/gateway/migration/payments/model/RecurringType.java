package com.svb.gateway.migration.payments.model;

import com.svb.gateway.migration.payments.entity.InternalTransfer;
import com.svb.gateway.migration.payments.entity.IpayStagingPayment;
import lombok.Getter;

@Getter
public enum RecurringType {
    NONE(0, 1),
    UNLIMITED(1,1),
    OCCURENCE(0,1),
    ENDDATE(0,1);

    private int instancesProcessed;
    private int entries;


    RecurringType(int instancesProcessed, int entries){
        this.instancesProcessed=instancesProcessed;
        this.entries=entries;
    }
    public static RecurringType fromPayment(IpayStagingPayment ipayStagingPayment) {
        if (ipayStagingPayment.getPaymentFrequency() == null) {
            return NONE;
        }
        if (ipayStagingPayment.getOccurencesRemaining() != null) {
            return OCCURENCE;
        }
        if (ipayStagingPayment.getPaymentEndDate() == null) {
            return UNLIMITED;
        }
        return ENDDATE;
    }

    public static RecurringType fromTransfer(InternalTransfer transfer) {
        if (transfer.getScheduleEndTypeId() == null) {
            return NONE;
        }
        if (transfer.getScheduleEndTypeId() ==1) {
            return UNLIMITED;
        }
        if (transfer.getScheduleEndTypeId() ==2) {
            return OCCURENCE;
        }
        return ENDDATE;
    }
}
