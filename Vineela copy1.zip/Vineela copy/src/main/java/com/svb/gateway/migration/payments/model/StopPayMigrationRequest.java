package com.svb.gateway.migration.payments.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import java.util.Date;

@ToString
@JsonInclude(JsonInclude.Include.NON_NULL)
@Getter
@Setter
@NoArgsConstructor
public class StopPayMigrationRequest {
    private String cspRefId;

    private Integer status;

    private String contextAlertSubscribe;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd-MMM-yy 00:00:00")
    private Date effectiveDate;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd-MMM-yy 00:00:00")
    private Date expiryDate;

    private String otherReason;

    private String clientId;

    private String userId;

    private String userFirstName;

    private String userLastName;

    private PayFrom	payFrom;

    private SingleCheck singleCheck;

    private String reason;

    @Getter
    @Setter
    public static class PayFrom {
        private String accountCurrency;

        private String initiatorAccount;

        private String name;
    }

    @Getter
    @Setter
    public static class SingleCheck {
        private String amount;

        @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd-MMM-yy 00:00:00")
        private Date issuedDate;

        private String checkNumber;

        private String currency;

        private String payeeName;

    }
}
