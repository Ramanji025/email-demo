package com.svb.gateway.migration.payments.model;

import com.fasterxml.jackson.annotation.*;
import com.svb.gateway.migration.common.model.Error;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

import javax.validation.Valid;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Setter
@Getter
public class TransferResponse {

    @JsonProperty("Data")
    private PaymentResponseData paymentResponseData = null;

    @JsonProperty("Errors")
    private List<Error> errors = null;

    @JsonIgnore
    private final Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @ApiModelProperty(required = true, value = "")
    @Valid
    public List<Error> getErrors() {
        return errors;
    }

    public void setErrors(List<Error> errors) {
        this.errors = errors;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    @JsonIgnore
    private Integer rollbackClient;

    public void setRollbackClient(Integer rollbackClient){
        this.rollbackClient=rollbackClient;
    }

    public Integer getRollbackClient(){
        return rollbackClient;
    }

}
