package com.svb.gateway.migration.payments.repository;

import com.svb.gateway.migration.payments.entity.ACMXEntity;
import com.svb.gateway.migration.payments.model.NickName;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface ACMXRepository extends JpaRepository<ACMXEntity, String> {

    @Query(value= "select acmt.ac_name as acmtAcName, (select acmx.ac_nic_name from  OCHADM.ACCT_MASTER_EXTENSION acmx where acmx.acId=?1 and upper(acmx.bay_user_id)=upper(?2)) as acmxNicName from OCHADM.ACCT_MASTER acmt where acmt.acId=?1", nativeQuery=true)
    NickName findByAccId(String acId, String gwClientId);
}
