package com.svb.gateway.migration.payments.repository;

import com.svb.gateway.migration.payments.entity.InternalTransfer;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface InternalTransferRepository extends JpaRepository<InternalTransfer, Integer> {

    @Query(value = "SELECT * FROM MIG_STG_INTERNAL_XFER m where  m.job_id= ?1 and m.olb_client_id like ?2 ", nativeQuery = true)
    List<InternalTransfer> findByOlbClientId(Long jobId, String olbClientId);

    List<InternalTransfer> findByOlbClientIdAfter(String olbClientId);


}
