package com.svb.gateway.migration.payments.repository;

import com.svb.gateway.migration.payments.entity.MigrationIpayPayment;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface MigrationPaymentsRepository extends JpaRepository<MigrationIpayPayment, Integer> {

    @Query(value = "SELECT * FROM MIG_IPAY_PAYMENTS m where m.jobid= ?1 and m.ec_client_id=?2 ", nativeQuery = true)
    List<MigrationIpayPayment> findByJobIdAndEcClientId(Long jobId, String ecClientId);

    @Query(value = "select * from MIG_IPAY_PAYMENTS  where EC_CLIENT_ID=?1 and JOBID = ?2 and STATUS in ?3", nativeQuery = true)
    List<MigrationIpayPayment> findByEcClientIdAndJobIdAndStatus(String olbClientId, Long jobId, List<String> status);

}
