package com.svb.gateway.migration.payments.repository;

import com.svb.gateway.migration.payments.entity.MigrationStopPayments;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface MigrationStopPaymentRepository extends JpaRepository<MigrationStopPayments, Integer> {

    List<MigrationStopPayments> findMigrationStopPaymentsByEcClientId(String ecClientId);

    @Query
            (value = "SELECT * FROM MIG_STOP_PAYMENTS m where m.jobid= ?1 and m.ec_client_id= ?2 and m.ec_req_id= ?3", nativeQuery = true)
    MigrationStopPayments findByJobIdAndEcClientIdAndEcReqId(Long jobId, String ecClientId,Long ecReqId);

    List<MigrationStopPayments> findByEcClientIdAndJobIdAndStatus(String ecClientId, Long jobId, String status);
}
