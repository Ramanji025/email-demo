package com.svb.gateway.migration.payments.repository;

import com.svb.gateway.migration.payments.entity.MigrationUser;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface MigrationUserRepository extends JpaRepository<MigrationUser, String> {
     @Query
           (value = "SELECT * FROM MIG_USER m where m.ecuserloginid = ?1  and lower(m.status)='success' ", nativeQuery = true)
     MigrationUser findByEcUserLoginId(String ecUserLoginId);

     @Query
             (value = "SELECT * FROM MIG_USER m where m.ecclientid = ?1  and lower(m.status)='success'  and isPrimaryUser=1", nativeQuery = true)
     MigrationUser findByEcClientAndPrimaryUser(String ecUserLoginId);
}
