package com.svb.gateway.migration.payments.repository;



import com.svb.gateway.migration.payments.entity.PAYMTransfers;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface PAYMRepository extends JpaRepository<PAYMTransfers, Integer> {

    @Query
            (value = "SELECT * FROM OCHADM.PAYEE_MASTER  where bnf_id = ?1 and del_flg='N' ", nativeQuery = true)
    PAYMTransfers findByBnfId(String bnfId);

}
