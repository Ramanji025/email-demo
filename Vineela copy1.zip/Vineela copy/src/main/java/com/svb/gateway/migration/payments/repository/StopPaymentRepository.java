package com.svb.gateway.migration.payments.repository;

import com.svb.gateway.migration.payments.entity.StopPayStagingEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface StopPaymentRepository extends JpaRepository<StopPayStagingEntity, Integer> {

    @Query(value = "SELECT * FROM MIG_STG_STOP_PAYMENT_REQ WHERE JOB_ID= ?1 AND CLIENT_ID= ?2 ", nativeQuery = true)
    List<StopPayStagingEntity> findByOlbClientIdAndJobId(Long jobId, String eCClientId);

    @Query(value = "SELECT * FROM MIG_STG_STOP_PAYMENT_REQ where REQ_ID not in (SELECT EC_REQ_ID FROM MIG_STOP_PAYMENTS WHERE STATUS IN ('SUCCESS','IGNORE','ROLLBACK') AND JOBID= ?1 AND EC_CLIENT_ID= ?2) AND JOB_ID= ?1 AND CLIENT_ID= ?2", nativeQuery = true)
    List<StopPayStagingEntity> findByStatusAndEcClientIdAndJobId(Long jobId, String ecClientId);

}