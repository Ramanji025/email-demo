package com.svb.gateway.migration.payments.service;

import com.svb.gateway.migration.client.entity.MigClient;
import com.svb.gateway.migration.client.repository.MigClientRepository;
import com.svb.gateway.migration.common.exception.ServiceException;
import com.svb.gateway.migration.common.logging.Message;
import com.svb.gateway.migration.common.mapper.MigrationEntityMapper;
import com.svb.gateway.migration.common.utility.BasicValidation;
import com.svb.gateway.migration.common.utility.CommonValidator;
import com.svb.gateway.migration.common.utility.RecordCount;
import com.svb.gateway.migration.payments.entity.*;
import com.svb.gateway.migration.payments.mapper.TransferMapper;
import com.svb.gateway.migration.payments.model.PaymentResponseData;
import com.svb.gateway.migration.payments.model.RecurringType;
import com.svb.gateway.migration.payments.model.TransferResponse;
import com.svb.gateway.migration.payments.repository.*;
import lombok.extern.log4j.Log4j2;
import org.apache.commons.lang3.ObjectUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.sql.Timestamp;
import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

import static com.svb.gateway.migration.common.constants.MigrationConstants.*;

@Log4j2
@Service
public class EconnectService {

    @Value("${migration.service.userid}")
    public String migrationUserId;

    @Autowired
    private GatewayPaymentService gatewayPaymentService;

    @Autowired
    private MigrationEntityRepository migrationEntityRepository;

    @Autowired
    MigClientRepository migClientRepository;

    @Autowired
    InternalTransferRepository internalTransferRepository;

    @Autowired
    MigrationTransferRepository migrationTransferRepository;

    @Autowired
    WireTransferRepository wireTransferRepository;

    @Autowired
    MigrationWireTransferRepository migrationWireTransferRepository;

    @Autowired
    TransferMapper transferMapper;

    private static final String NO_TRANSACTIONS_PRESENT = "No Transactions present for provided client Id: ";



    public TransferResponse internalTransfer(Long jobId, MigClient migClient) throws ServiceException {

        TransferResponse transferResponse = new TransferResponse();
        final RecordCount recordCount = new RecordCount();
        recordCount.setStartTime(new Timestamp(System.currentTimeMillis()));
        Message logMessage = Message.create().jobId(jobId).clientId(migClient.getEcClientId()).gwClientId(migClient.getGwClientId()).operation(INTERNAL_TRANSFER);

            List<InternalTransfer> transferList = internalTransferRepository.findByOlbClientId(jobId, migClient.getEcClientId());
            log.debug(logMessage.descr("TransfersService. Internal transfers for : " + transferList));

            log.info(logMessage.descr("Internal transfer staging records fetched, list size :"+transferList.size()));

            if (transferList.isEmpty()) {
                recordCount.setEndTime(new Timestamp(System.currentTimeMillis()));
                migrationEntityRepository.save(MigrationEntityMapper.INSTANCE.convertTransferToMigEntity(migClient, recordCount, INTERNAL_TRANSFER));
                log.info(logMessage.descr(NO_TRANSACTIONS_PRESENT));
                transferResponse.setAdditionalProperty(NO_TRANSACTIONS_PRESENT, NO_TRANSACTIONS_PRESENT+migClient.getEcClientId());
                return transferResponse;
            }
            applyRecurringType(transferList);

            List<MigrationInternalTransfer> migrationInternalTransferList = new ArrayList<>();
            Map<Integer, MigrationInternalTransfer> processedRecords = currentMigratedInternalTransfers(jobId,migClient.getEcClientId());

            log.info(logMessage.descr("Internal transfer Processed records list size :"+processedRecords.size()));

            transferList.forEach(transferRec -> {
                log.debug(logMessage.descr("processing record with ecTxnId").srcId(String.valueOf(transferRec.getTrnId())).toString());
                MigrationInternalTransfer migrationTransfer = null;
                MigrationInternalTransfer processedRecord = null;

                try {
                    processedRecord = processedRecords.get(transferRec.getTrnId());
                    if (processedRecord != null && !processedRecord.canRunAgain()) {
                        log.info(Message.create().descr("Record already processed with req id: " + processedRecord.getGwReqId()).srcId(String.valueOf(transferRec.getTrnId())));
                    } else {
                        log.debug(Message.create().descr("Processing record for EcTxnID").srcId(String.valueOf(transferRec.getTrnId())).toString());
                        migrationTransfer = gatewayPaymentService.insertInternalTransfer(transferRec, migClient);
                        migrationTransfer.updateFrom(processedRecord);
                        updateAuditColumns(migrationTransfer, processedRecord);
                        migrationInternalTransferList.add(migrationTransfer);  // insert or update
                        recordCount.updateCounter(migrationTransfer.getStatus());
                        log.debug(logMessage.descr("Audit data written to MIG_INTERNAL_TRANSFERS").srcId(String.valueOf(transferRec.getTrnId())));
                    }

                } catch (ServiceException e) {
                    recordCount.addFailure();
                    log.error(logMessage.descr(e.getErrorMessage()));
                    transferResponse.setAdditionalProperty(e.getErrorCode(), e.getErrorMessage());
                }
            });
            if (!migrationInternalTransferList.isEmpty()) {
                migrationTransferRepository.saveAll(migrationInternalTransferList);
            }
            recordCount.stopTime();
            MigrationEntity migEntity = MigrationEntityMapper.INSTANCE.convertTransferToMigEntity(migClient, recordCount, INTERNAL_TRANSFER);
            if (recordCount.getTotal() > 0) {
                migrationEntityRepository.save(migEntity);
                log.info(logMessage.descr("Data committed to MIG_ENTITY table for Internal transfer"));
            }

        createResponse(transferResponse, recordCount, migClient);
        return transferResponse;
    }

    private void updateAuditColumns(MigrationInternalTransfer migrationTransfer, MigrationInternalTransfer processedRecord) {
        if(processedRecord !=null){
            migrationTransfer.setUpdatedby(migrationUserId);
            migrationTransfer.setUpdatedDate(new Date());
        }
    }


    public TransferResponse wireTransfer(Long jobId, MigClient migClient) throws ServiceException {
        Message logMessage = Message.create().clientId(migClient.getEcClientId()).jobId(jobId);
        log.debug(logMessage.descr("Migration Initiated").operation("WIRES"));
        CommonValidator.ecClientIdCheck(migClient.getEcClientId());

        TransferResponse transferResponse = new TransferResponse();
        final RecordCount recordCount = new RecordCount();
        recordCount.setStartTime(new Timestamp(System.currentTimeMillis()));


            BasicValidation.transfersClientIdNullCheck(migClient);

//        Step1: Load transaction records based on Client details from the Staging Database
            List<WireTransfer> transferList = wireTransferRepository.findByOlbClientId(jobId, migClient.getEcClientId());
            log.debug("Wire Transfer Service, for transfers : " + transferList);

            log.info(logMessage.descr("Wire transfer staging records fetched, list size :"+transferList.size()));

            if (transferList.isEmpty()) {
                recordCount.setEndTime(new Timestamp(System.currentTimeMillis()));
                migrationEntityRepository.save(MigrationEntityMapper.INSTANCE.convertTransferToMigEntity(migClient, recordCount, WIRE_TRANSFER));
                transferResponse.setAdditionalProperty(NO_TRANSACTIONS_PRESENT, NO_TRANSACTIONS_PRESENT+migClient.getEcClientId());
                return transferResponse;
            }

            List<MigrationWireTransfer> migrationWireTransferList = new ArrayList<>();
            Map<Integer, MigrationWireTransfer> processedRecords = currentMigratedWireTransfers(jobId, migClient);

        log.info(logMessage.descr("Wire transfer Processed records list size :"+processedRecords.size()));


        transferList.forEach(transferRec -> {
                log.debug(Message.create().descr("Processing transaction record with EcTxnID:").srcId(String.valueOf(transferRec.getWireTxnId())).toString());
                MigrationWireTransfer migrationWireTransfer = null;
                MigrationWireTransfer processedRecord = null;
                try {
                    processedRecord = processedRecords.get(transferRec.getWireTxnId());
                    if (processedRecord != null && !processedRecord.canRunAgain()) {
                        log.error(Message.create().descr("Record already processed for EcClientId").srcId(String.valueOf(processedRecord.getEcTxnId())).toString());
                    } else {
                        migrationWireTransfer= gatewayPaymentService.insertWireAdhocPayment(jobId, transferRec, migClient);
                        migrationWireTransfer.updateFrom(processedRecord);
                        updateAuditColumns(migrationWireTransfer, processedRecord);
                        recordCount.updateCounter(migrationWireTransfer.getStatus());
                        migrationWireTransferList.add(migrationWireTransfer);
                        log.info(Message.create().descr("Transaction has been migrated with Req Id").targetId(String.valueOf(migrationWireTransfer.getGwReqId())).toString()); //record now processed with req Id:
                    }
                    log.debug(logMessage.descr("Data written into Wire Audit table"));

                } catch (ServiceException e) {
                    recordCount.addFailure();
                    log.error(logMessage.descr(e.getErrorMessage()));
                    transferResponse.setAdditionalProperty(e.getErrorCode(), e.getErrorMessage());
                }
            });
            if (!migrationWireTransferList.isEmpty()) {
                migrationWireTransferRepository.saveAll(migrationWireTransferList);
            }
            recordCount.stopTime();
            if (recordCount.getTotal() > 0) {
                migrationEntityRepository.save(MigrationEntityMapper.INSTANCE.convertTransferToMigEntity(migClient, recordCount, WIRE_TRANSFER));
                log.info(logMessage.descr("Data committed to MIG_ENTITY table for Wire Transfer records"));
            }
        createResponse(transferResponse, recordCount, migClient);
        return transferResponse;
    }

    private void updateAuditColumns(MigrationWireTransfer migrationWireTransfer, MigrationWireTransfer processedRecord) {
        if(processedRecord !=null){
            migrationWireTransfer.setUpdatedby(migrationUserId);
            migrationWireTransfer.setUpdatedDate(new Date());
        }
    }

    private Map<Integer, MigrationInternalTransfer> currentMigratedInternalTransfers(Long jobId, String ecClientId) {
        return Optional.ofNullable(migrationTransferRepository.findByJobId(jobId,ecClientId)).orElse(new ArrayList<>()).stream().filter(ObjectUtils::isNotEmpty)
                .collect(Collectors.toMap(MigrationInternalTransfer::getEcTxnId, Function.identity()));

    }

    private Map<Integer, MigrationWireTransfer> currentMigratedWireTransfers(Long jobId, MigClient migClient) {
        return Optional.ofNullable(migrationWireTransferRepository.findByJobId(jobId, migClient.getEcClientId())).orElse(new ArrayList<>()).stream().filter(ObjectUtils::isNotEmpty)
                .collect(Collectors.toMap(MigrationWireTransfer::getEcTxnId, Function.identity()));

    }

    private void applyRecurringType(List<InternalTransfer> transferList) {
        transferList.stream().forEach(transfer -> transfer.setRecurringType(RecurringType.fromTransfer(transfer)));
    }

    private void createResponse(TransferResponse transferResponse, RecordCount recordCount, MigClient migClient) {

            transferResponse.setPaymentResponseData(PaymentResponseData.builder()
                    .gwClientId(migClient.getGwClientId())
                    .ecClientId(migClient.getEcClientId())
                    .jobId(migClient.getJobId() == null ? 0 : migClient.getJobId().intValue())
                    .recordCount(recordCount).build());

        transferResponse.setAdditionalProperty("Total Records Total is: ", recordCount.getTotal());
        transferResponse.setAdditionalProperty("Total Succesfully migrated txn Records: ", recordCount.getSuccess());
        transferResponse.setAdditionalProperty("Total Failed Records :", recordCount.getFailure());
    }


}

