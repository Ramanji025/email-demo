package com.svb.gateway.migration.payments.service;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.svb.gateway.migration.beneficiaries.entity.MigBeneficiary;
import com.svb.gateway.migration.beneficiaries.entity.StgBeneficiary;
import com.svb.gateway.migration.beneficiaries.repository.BeneficiaryRepository;
import com.svb.gateway.migration.beneficiaries.repository.MigBeneficiaryRepository;
import com.svb.gateway.migration.client.entity.MigClient;
import com.svb.gateway.migration.common.constants.MigrationConstants;
import com.svb.gateway.migration.common.exception.ServiceException;
import com.svb.gateway.migration.common.logging.Message;
import com.svb.gateway.migration.common.utility.CacheManagerUtility;
import com.svb.gateway.migration.common.utility.CommonValidator;
import com.svb.gateway.migration.common.utility.CountryCodeCheckUtility;
import com.svb.gateway.migration.payments.entity.*;
import com.svb.gateway.migration.payments.mapper.*;
import com.svb.gateway.migration.payments.model.NickName;
import com.svb.gateway.migration.payments.model.OchPaymentRequest;
import com.svb.gateway.migration.payments.model.OchPaymentResponse;
import com.svb.gateway.migration.payments.repository.*;
import com.svb.gateway.migration.payments.repository.ACMTRepository;
import com.svb.gateway.migration.payments.repository.PAYMRepository;
import lombok.extern.log4j.Log4j2;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.client.RestClientResponseException;
import org.springframework.web.client.RestTemplate;

import java.util.*;

import static com.svb.gateway.migration.common.constants.MigrationConstants.*;
import static com.svb.gateway.migration.common.constants.UserConstants.N_FLAG;
import static com.svb.gateway.migration.common.logging.Message.Entity;
import static com.svb.gateway.migration.common.logging.Message.SourceType.*;


@Log4j2
@Service
@Transactional(rollbackFor = Exception.class)
public class GatewayPaymentService {

    private static final String BENE_NOT_MIGRATED_ERROR = "No Migrated Beneficiary found for SourceBeneficiaryId : ";
    private static final String ACCOUNT_NICKNAME_FETCH_ERROR = "Account nickname fetch from och table failed : ";
    private static final String PAYMENT_DATE_NULL_ERROR = "Payment date for wire transfer is null for transaction id - ";
    private static final String PAYMENT_DATE_NOT_FUTURE_ERROR = "This is not a scheduled Wire Payment as payment date is past date.";
    private static final String WIRE_PAYMENT_BENE_BANK_COUNTRY = "United States of America";
    private static final String MESSAGE_CODE="messageCode";
    private static final String RECURRENCE_ERROR_CODE_1="100765";
    private static final String RECURRENCE_ERROR_CODE_2="42004";

    @Value(value = "${mig.och.url}")
    String ochUrl;

    @Value(value = "${mig.vtUsername}")
    String vtUsername;

    @Autowired
    MigrationUserRepository migrationUserRepository;

    @Autowired
    CacheManagerUtility cacheManagerUtility;

    @Autowired
    PAYMRepository paymRepository;

    @Autowired
    MigBeneficiaryRepository migBeneficiaryRepository;

    @Autowired
    RestTemplate restTemplate;

    @Autowired
    OchMapper ochMapper;

    @Autowired
    ACMXRepository acmxRepository;

    @Autowired
    ACMTRepository acmtRepository;

    @Autowired
    CountryCodeCheckUtility countryCodeCheckUtility;

    @Autowired
    BeneficiaryRepository beneficiaryRepository;

    @Value("#{'${recurrenceErrorCodes}'.split(',')}")
    Set<String> recurrenceErrorCodeSet;

    /**
     * it will make a recursive call when count=0 only, here is the sequence of events
     * Method: createOchPayment
     * set count=1
     * @param ochPaymentRequest
     * @param gwClientId
     * @return
     * @throws ServiceException
     */
    private OchPaymentResponse createOchPayment(OchPaymentRequest ochPaymentRequest, String gwClientId) throws ServiceException {
        //initiate count=0 as it is first call, call OCH to create payment
        return createOchPayment(ochPaymentRequest, gwClientId, 0);
    }

    private OchPaymentResponse createOchPayment(OchPaymentRequest ochPaymentRequest, String gwClientId, int count) throws ServiceException {
        String source="createOchPayment";
        Message logMessage=Message.create().gwClientId(gwClientId).operation(source);

        if(gwClientId==null){
            log.info(logMessage.descr(" GwClientId is null, throwing Service Exception"));
            throw new ServiceException(" gwClientId is null");
        }

        log.info(logMessage.descr("Creating new OCH Payment").summary());

        OchPaymentResponse ochPaymentResponse=new OchPaymentResponse();
        if(ochPaymentRequest==null){
            log.info(logMessage.descr(" OchPaymentRequest is null, throwing Service Exception"));
            throw new ServiceException(" OchPaymentRequest is null");
        }
        String ochPaymentUrl = ochUrl+ vtUsername + OCH_CONTEXT +gwClientId.toUpperCase()+ OCH_PAYMENT_API;
        ObjectMapper objMapper = new ObjectMapper();
        objMapper.setSerializationInclusion(JsonInclude.Include.NON_NULL);

        try {
            filterEmptyFields(ochPaymentRequest);

            log.info(logMessage.descr(" Request for OCH submit payment").url(ochPaymentUrl));
            HttpHeaders headers = new HttpHeaders();
            headers.add(MigrationConstants.AUTHORIZATION_HEADER_NAME, cacheManagerUtility.getVTToken());
            headers.add(OCH_IS_MIGRATION_HEADER,  IS_MIGRATION_VALUE);
            headers.add(MigrationConstants.CONTENT_TYPE, MigrationConstants.APPLICATION_HEADER_JSON);

            HttpEntity<OchPaymentRequest> requestEntity = new HttpEntity<>(ochPaymentRequest, headers);

            ResponseEntity<OchPaymentResponse> ochPaymentResponseHttpResponse  =
                    restTemplate.exchange(ochPaymentUrl, HttpMethod.POST, requestEntity, OchPaymentResponse.class);

            if (ochPaymentResponseHttpResponse.getStatusCode() != HttpStatus.CREATED) {
                String errorResponse="Submit payments call failed with a non 200 response for request="+
                        ochPaymentUrl +ERROR_CODE + ochPaymentResponseHttpResponse.getStatusCode() + ERROR_MESSAGE +
                        ochPaymentResponseHttpResponse.getBody();
                log.info(logMessage.descr(errorResponse));
                throw new ServiceException(source+" : "+errorResponse);
            }
            ochPaymentResponse= ochPaymentResponseHttpResponse.getBody();
        }
        catch (RestClientResponseException restClientResponseException){
            //fetch Channel context information from the Response header
            Map<String, String> channelContext=getChannelContext(restClientResponseException, logMessage);
            //check if it is an invalid RECURRING type of request(messageCode) was caused
            // count should be 0 to retry to convert recurring as single payment
            if(invalidRecurringOccurrences(channelContext) && count<1){
                log.info(logMessage.descr("converting Recurrence to Single payment as there is just one instance remaining."));
                convertToSinglePayment(ochPaymentRequest);
                return createOchPayment(ochPaymentRequest, gwClientId,1);
            }else{
                //handle non recurring type requests or if count is more than 0 (retried once  already)
                handleRestException(channelContext, logMessage, "Create Och Payment");
            }
        }
        catch (Exception e) {
            log.error(logMessage.descr("Error during payment migration : "+e.getMessage()));
            throw new ServiceException(source+" : "+e.getMessage());
        }
        log.info(logMessage.descr("OCH payment created ").summary());
        return ochPaymentResponse;
    }

    private void convertToSinglePayment(OchPaymentRequest ochPaymentRequest) {
        ochPaymentRequest.setFrequencyType(FREQ_TYPE_O);
        OchPaymentRequest.RecurringDetails recurringDetails=new OchPaymentRequest.RecurringDetails();
        recurringDetails.setValidityIndicator(N_FLAG);
        recurringDetails.setRecurringFrequency(null);
        recurringDetails.setNumberOfInstallments(String.valueOf(ONE));
        recurringDetails.setLastPaymentDate("");
        ochPaymentRequest.setRecurringDetails(recurringDetails);
    }

    private boolean invalidRecurringOccurrences(Map<String, String> channelContext) {
        //check if recurrence type payment failed since there was 1 recurring payment or the payment end date was too early.
        return channelContext!=null &&
                channelContext.containsKey(MESSAGE_CODE) &&
                recurrenceErrorCodeSet.contains(channelContext.get(MESSAGE_CODE).replaceAll("([^\\d]+)", ""));
    }

    public MigrationIpayPayment insertIpayPayment(IpayStagingPayment ipayStagingPayment, MigClient migClient) throws ServiceException {
        Message logMessage=Message.create().entityName(Entity.payment).descr("Inserting IpayStagingPayment data for:").clientId(ipayStagingPayment.getEcClientId())
                .srcType(iPay).srcId(String.valueOf(ipayStagingPayment.getPaymentId()));
        log.info(logMessage.summary());
        String source="insertIpayPayment";

        MigrationIpayPayment migrationIpayPayment;
        Long ochRequestId=null;
        try{
            // set dependency on Beneficiary
            getAndSetBeneficiary(migClient.getJobId(), ipayStagingPayment);

            ipayStagingPayment.setAccNickName(mapNickName(ipayStagingPayment.getSubscriberAccountNumber(),migClient.getGwClientId() ));

            OchPaymentRequest.EntryDetails.Field[] fields=new OchPaymentRequest.EntryDetails.Field[2];
            fields[0]=PaymentToOchMapper.INSTANCE.mapTargetGroupIdToExtraFields(ipayStagingPayment);
            fields[1]=PaymentToOchMapper.INSTANCE.mapDebitAccountNickNameToExtraFields(ipayStagingPayment);

            OchPaymentRequest.EntryDetails[]  entryDetails=new OchPaymentRequest.EntryDetails[1];
            entryDetails[0]=PaymentToOchMapper.INSTANCE.convertFutureIpayPaymentToEntryDetails(ipayStagingPayment,fields);
            OchPaymentRequest ochPaymentRequest= PaymentToOchMapper.INSTANCE.convertFutureIpayPaymentToPayments(ipayStagingPayment,entryDetails);

            log.info(logMessage.descr("Posting OCH payment request with payment date : "+ochPaymentRequest.getTransactionDate()));

            OchPaymentResponse ochPaymentResponse=createOchPayment(ochPaymentRequest,migClient.getGwClientId());
            ochRequestId = ochPaymentResponse!=null && ochPaymentResponse.getCommonSection()!=null?Long.valueOf(ochPaymentResponse.getCommonSection().getRequestReferenceId()):null;

            log.info(logMessage.descr(PAYMENT_SUCCESS_MESSAGE).srcId(String.valueOf(ipayStagingPayment.getPaymentId())).targetId(ochRequestId));

            migrationIpayPayment = setResponse(ipayStagingPayment, ochRequestId, MigrationConstants.STATUS_SUCCESS,"", migClient);
            log.info(logMessage.descr("Insert Ipay payment completed").summary());
        }catch(Exception e){
            log.error(Message.create().descr(e.getMessage()).clientId(ipayStagingPayment.getEcClientId()).operation("Payments").entityName(Message.Entity.payment).errorSource(source));
            migrationIpayPayment = setResponse(ipayStagingPayment, ochRequestId, MigrationConstants.STATUS_FAILURE, e.getMessage(), migClient);
        }
        return migrationIpayPayment;
    }

    private void checkFutureDatedPayment(WireTransfer transfer, Message logMessage) throws ServiceException{
        if(transfer.getValueDate()==null){
            log.error(logMessage.descr(PAYMENT_DATE_NULL_ERROR+transfer.getWireTxnId()));
            throw new ServiceException(PAYMENT_DATE_NULL_ERROR+transfer.getWireTxnId());
        }
        if(transfer.getValueDate().compareTo(new Date()) < 0){
            log.error(logMessage.descr(PAYMENT_DATE_NOT_FUTURE_ERROR));
            throw new ServiceException(PAYMENT_DATE_NOT_FUTURE_ERROR);
        }
    }

    public String mapNickName(String accNumber, String gwClientId) throws ServiceException {
    try {
        NickName nickName = acmxRepository.findByAccId(accNumber, gwClientId);
        if (nickName != null && nickName.getAcmxNicName() != null) {
            return nickName.getAcmxNicName();
        } else if (nickName != null && nickName.getAcmtAcName() != null) {
            return nickName.getAcmtAcName();
        }
    }
    catch(Exception ex){
        log.error(Message.create().descr(ACCOUNT_NICKNAME_FETCH_ERROR+ex.getMessage()).gwClientId(gwClientId));
        throw new ServiceException(ACCOUNT_NICKNAME_FETCH_ERROR+ex.getMessage());
    }
        return "";
    }

    private MigrationIpayPayment setResponse(IpayStagingPayment ipayStagingPayment, Long ochRequestId, String status, String message, MigClient migClient) {
        MigrationIpayPayment migrationIpayPayment = MigrationPaymentModelMapper.INSTANCE.convertIpayPaymentToEntity(ipayStagingPayment, migClient);
        migrationIpayPayment.setGwReqId(ochRequestId);
        migrationIpayPayment.setStatus(status);
        migrationIpayPayment.setComments(message);
        return migrationIpayPayment;
    }

    private MigrationInternalTransfer setResponse(InternalTransfer transfer, Long ochRequestId, String status, String message, MigClient migClient) {
        MigrationInternalTransfer migrationTransfer= MigrationPaymentModelMapper.INSTANCE.convertTransferToEntity(transfer, migClient);
        migrationTransfer.setGwReqId(ochRequestId);
        migrationTransfer.setStatus(status);
        migrationTransfer.setComments(message);
        return migrationTransfer;
    }

    private MigrationWireTransfer setResponse(WireTransfer transfer,  Long ochRequestId, String status, String message,MigClient migClient) {
        MigrationWireTransfer migrationTransfer= MigrationPaymentModelMapper.INSTANCE.convertTransferToEntity(transfer, migClient);
        migrationTransfer.setGwReqId(ochRequestId);
        migrationTransfer.setStatus(status);
        migrationTransfer.setComments(message);
        migrationTransfer.setBeneId(transfer.getBnfId());
        return migrationTransfer;
    }

    private void getAndSetBeneficiary(Long jobId, IpayStagingPayment ipayStagingPayment) throws ServiceException {
        MigBeneficiary migBeneficiary=migBeneficiaryRepository.findByBeneSourceForIpayMigrated(jobId, ipayStagingPayment.getBeneficiaryId());
        Message logMessage=Message.create().jobId(jobId).clientId(ipayStagingPayment.getEcClientId()).srcId(String.valueOf(ipayStagingPayment.getBeneficiaryId()));
        if(migBeneficiary==null || migBeneficiary.getBeneficiaryId()==null){
            log.error(logMessage.descr(BENE_NOT_MIGRATED_ERROR+ipayStagingPayment.getBeneficiaryId()));
            throw new ServiceException(BENE_NOT_MIGRATED_ERROR+ipayStagingPayment.getBeneficiaryId().toString());
        }else{
            ipayStagingPayment.setTargetBeneficiaryId(Integer.valueOf(migBeneficiary.getBeneficiaryId()));
            ipayStagingPayment.setTargetGroupId(Integer.valueOf(migBeneficiary.getGroupId()));
        }
    }

    public boolean rollback(List<Long> requestIds) {
        try {
            if(requestIds.isEmpty()){
                log.info("OCH RequestIds list is empty, nothing to soft delete here.");
                return false;
            }

            ochMapper.deleteTransactionRequests(requestIds, "TRANSACTION_REQUEST_HEADER");
            ochMapper.deleteTransactionRequests(requestIds, "TRANSACTION_REQUEST_DETAILS");
            ochMapper.deleteTransactionRequests(requestIds, "CUSTOM_TRANSACTION_REQUEST_DETAILS");
            log.info("Soft delete successful in OCH for requestIds = {}", requestIds);

        }catch (Exception e){
            log.error("OCH could not be updated for {} due to {}", requestIds, e.getMessage());
            return false;
        }
        return true;
    }

    private void filterEmptyFields(OchPaymentRequest paymentDraftRequest){
        int entryDetailsIndex=0;
        OchPaymentRequest.EntryDetails[] entryDetails=paymentDraftRequest.getEntryDetails();
        if(entryDetails!=null && entryDetails.length!=0){
            for(OchPaymentRequest.EntryDetails entryDetails1:entryDetails){
                OchPaymentRequest.EntryDetails.Field[] fields=entryDetails1.getExtraTransactionDetails();
                List<OchPaymentRequest.EntryDetails.Field> fieldsList=new ArrayList<>();
                populateFieldsList(fields, fieldsList);

                OchPaymentRequest.EntryDetails.Field[] newFields=new OchPaymentRequest.EntryDetails.Field[fieldsList.size()];
                int index=0;
                for(OchPaymentRequest.EntryDetails.Field field:fieldsList){
                    newFields[index]=field;
                    index++;
                }
                entryDetails[entryDetailsIndex].setExtraTransactionDetails(newFields);
                entryDetailsIndex++;
            }
        }
    }

    private void populateFieldsList(OchPaymentRequest.EntryDetails.Field[] fields, List<OchPaymentRequest.EntryDetails.Field> fieldsList) {
        if(null !=fields){
            for(OchPaymentRequest.EntryDetails.Field field: fields){
                if(!"".equals(field.getFieldValue()) && null!=field.getFieldValue()){
                    fieldsList.add(field);
                }
            }
        }
    }


    public MigrationWireTransfer insertWireAdhocPayment(Long jobId, WireTransfer transfer, MigClient migClient) throws ServiceException {
        String source="insertWireAdhocPayment";
        Message logMessage=Message.create().jobId(jobId).clientId(transfer.getOlbClientId())
                .srcId(String.valueOf(transfer.getWireTxnId())).operation("Migration of Future Wire payment").srcType(Message.SourceType.wireTransfer);
        log.info(logMessage.summary().descr("Created Wire transfer").summary());

        MigrationWireTransfer migrationTransfer;
        Long ochRequestId=null;

        try {
            checkIfDOMType(transfer,logMessage);
            checkFutureDatedPayment(transfer,logMessage);
            String iSOCountryCode=getBeneBankISOCountryCode(transfer,logMessage);

            OchPaymentRequest.EntryDetails.Field[] fields=new OchPaymentRequest.EntryDetails.Field[7];
            fields[0]= WireTransferToOchMapper.INSTANCE.mapMandatoryBeneficiaryBankCountryToExtraFields(iSOCountryCode);
            fields[1]= WireTransferToOchMapper.INSTANCE.mapOptionalIntermediaryBankRoutingCode(transfer);
            fields[2]= WireTransferToOchMapper.INSTANCE.mapOptionalIntermediaryBankName(transfer);
            fields[3]= WireTransferToOchMapper.INSTANCE.mapOptionalIntermediaryBankAddress(transfer);
            fields[4]= WireTransferToOchMapper.INSTANCE.mapOptionalPayeeBankName(transfer);
            fields[5]= WireTransferToOchMapper.INSTANCE.mapOptionalPayeeBankAddressLine1(transfer);
            fields[6]= WireTransferToOchMapper.INSTANCE.mapOptionalBankToBankInstructions(transfer);

            OchPaymentRequest.EntryDetails[]  entryDetails=new OchPaymentRequest.EntryDetails[1];
            entryDetails[0]=WireTransferToOchMapper.INSTANCE.convertFutureWireTransferToEntryDetails(transfer,fields);
            OchPaymentRequest ochPaymentRequest= WireTransferToOchMapper.INSTANCE.convertFutureWireTransferToPayments(transfer,entryDetails);

            log.info(logMessage.descr("Forming OCH payment request with payment date : "+ochPaymentRequest.getTransactionDate()));

            log.info(logMessage.descr("Deriving Network and Transaction type values for Bene Bank identifier : "+transfer.getBeneBankId()));
            setNetworkAndTxnType(ochPaymentRequest,transfer,logMessage);

            log.info(logMessage.descr("Fetching template Code info if the Transaction is of Template based"));
            setTemplateCodeAsBeneNickNameIfTemplateBased(ochPaymentRequest,transfer,logMessage);

            OchPaymentResponse ochPaymentResponse=createOchPayment(ochPaymentRequest,migClient.getGwClientId());
            ochRequestId=ochPaymentResponse!=null && ochPaymentResponse.getCommonSection()!=null?Long.valueOf(ochPaymentResponse.getCommonSection().getRequestReferenceId()):null;

            log.info(Message.create().descr(PAYMENT_SUCCESS_MESSAGE).clientId(transfer.getOlbClientId()).operation("Wire Transfers Migration").status(STATUS_SUCCESS));

            migrationTransfer= setResponse(transfer, ochRequestId, MigrationConstants.STATUS_SUCCESS,"",migClient);
            log.info(logMessage.summary().descr("Wire transfers created").summary());

        } catch(Exception e){
            log.error(source+" : "+logMessage.descr("Wire transfer insertion failed "+e.getMessage()));
            migrationTransfer = setResponse(transfer, ochRequestId, MigrationConstants.STATUS_FAILURE, e.getMessage(),migClient);
        }
        return migrationTransfer;
    }

    public MigrationInternalTransfer insertInternalTransfer(InternalTransfer transfer, MigClient migClient) throws ServiceException {
        String source="insertInternalTransfer";
        Message logMessage = Message.create().clientId(transfer.getOlbClientId()).srcType(internalTransfer)
                .jobId(Long.valueOf(transfer.getJobId())).srcId(String.valueOf(transfer.getTrnId())).operation(source);
        log.info(logMessage.summary().descr("Creating Internal Transfer"));
        MigrationInternalTransfer migrationTransfer;

        Long ochRequestId=null;
        try {

            OchPaymentRequest.EntryDetails[]  entryDetails=new OchPaymentRequest.EntryDetails[1];
            entryDetails[0]=TransferToOchMapper.INSTANCE.convertFutureInternalTransferToEntryDetails(transfer);
            OchPaymentRequest ochPaymentRequest= TransferToOchMapper.INSTANCE.convertFutureInternalTransferToTransfers(transfer,entryDetails);

            log.info(logMessage.descr("Posting OCH transfer request with transfer date : "+ochPaymentRequest.getTransactionDate()));

            OchPaymentResponse ochPaymentResponse=createOchPayment(ochPaymentRequest,migClient.getGwClientId());
            ochRequestId = ochPaymentResponse!=null && ochPaymentResponse.getCommonSection()!=null?Long.valueOf(ochPaymentResponse.getCommonSection().getRequestReferenceId()):null;
            log.info(logMessage.descr(PAYMENT_SUCCESS_MESSAGE).clientId(transfer.getOlbClientId()));

            migrationTransfer=setResponse(transfer, ochRequestId, MigrationConstants.STATUS_SUCCESS,"",migClient);
            log.info(logMessage.summary().descr("Internal Transfer created"));

        }catch(Exception e){
            log.error(source+" : "+logMessage.descr("Internal transfer failed "+e.getMessage()));
            migrationTransfer=setResponse(transfer, ochRequestId, MigrationConstants.STATUS_FAILURE, e.getMessage(),migClient);
        }

        return migrationTransfer;
    }

    private Map<String, String> getChannelContext(RestClientResponseException restClientResponseException, Message logMessage) throws ServiceException{
        Map<String, String> contextMap=new HashMap<>();

        assert restClientResponseException != null;
            if (null == restClientResponseException.getResponseHeaders() || restClientResponseException.getResponseHeaders().getValuesAsList(CHANNEL_CONTEXT).isEmpty()) {
                log.info(logMessage.descr(UNEXPECTED_PAYMENT_API_ERROR));
                throw new ServiceException(UNEXPECTED_PAYMENT_API_ERROR);
            }
            List<String> list=restClientResponseException.getResponseHeaders().getValuesAsList(CHANNEL_CONTEXT);
            for(String str:list){
                str=str.replace("\\\\", "");
                str=str.replace("\"", "");
                if(str.indexOf(':')!=-1){
                    contextMap.put(str.substring(0,str.indexOf(':')),str.substring(str.indexOf(':')+1));
                }
            }
            return contextMap;
    }

    private void handleRestException( Map<String, String> channelContext, Message logMessage, String errorSource) throws ServiceException {
        logMessage.errorSource(errorSource);
        String errorSourceMessage=" Exception occurred during "+errorSource;
        log.info(logMessage.descr("Och Channel Context message :: "+channelContext.values()));
        String exceptionMessage=errorSourceMessage+ ":"+channelContext.values();
        throw new ServiceException(exceptionMessage);
    }

    private void setNetworkAndTxnType(OchPaymentRequest ochPaymentRequest, WireTransfer wireTransfer, Message logMessage) throws ServiceException {
        if(wireTransfer!=null && wireTransfer.getBeneBankCountry()==null){
            String errorMessage="Cannot identify network type due to bene bank country being null, hence not migrating the transaction.";
            log.error(logMessage.descr(errorMessage));
            throw new ServiceException(errorMessage);
        }
        if(wireTransfer!=null && WIRE_PAYMENT_BENE_BANK_COUNTRY.equalsIgnoreCase(wireTransfer.getBeneBankCountry())){
            if(CommonValidator.isBankIdentifierAba(wireTransfer.getBeneBankId())){
                log.info(logMessage.descr("Setting Network and Transaction type as ABA and FED"));
                ochPaymentRequest.setTransactionType(FED);
                ochPaymentRequest.getEntryDetails()[0].setNetwork(FED);
                ochPaymentRequest.getEntryDetails()[0].getPayeeAccountDetails().getAdhocPayeeDetails().setPayeeNetwork(ABA);
            }
            else if(CommonValidator.isBankIdentifierSwiftBic(wireTransfer.getBeneBankId())){
                log.info(logMessage.descr("Setting Network and Transaction type as SWIFT and FED"));
                ochPaymentRequest.setTransactionType(FED);
                ochPaymentRequest.getEntryDetails()[0].setNetwork(FED);
                ochPaymentRequest.getEntryDetails()[0].getPayeeAccountDetails().getAdhocPayeeDetails().setPayeeNetwork(SWIFT);
            }
            else{
                String warningMessage="Defaulting Network and Transaction type as ABA and FED, as we cannot identify network type due to invalid format of bank identifier - "+wireTransfer.getBeneBankId();
                log.info(logMessage.descr(warningMessage));
                ochPaymentRequest.setTransactionType(FED);
                ochPaymentRequest.getEntryDetails()[0].setNetwork(FED);
                ochPaymentRequest.getEntryDetails()[0].getPayeeAccountDetails().getAdhocPayeeDetails().setPayeeNetwork(ABA);
            }
        }
        else{
            log.info(logMessage.descr("Setting Network and Transaction type as SWIFT and USI as country is Non-USA"));
            ochPaymentRequest.setTransactionType(USI);
            ochPaymentRequest.getEntryDetails()[0].setNetwork(USI);
            ochPaymentRequest.getEntryDetails()[0].getPayeeAccountDetails().getAdhocPayeeDetails().setPayeeNetwork(SWIFT);
        }
    }

    private void checkIfDOMType(WireTransfer transfer,Message logMessage) throws ServiceException{
        if(null!=transfer && transfer.getPmtType().equalsIgnoreCase(INTL)){
            String errorMessage="Payment is of type INTL in eConnect, hence not migrating the transaction";
            log.info(logMessage.descr(errorMessage));
            throw new ServiceException(errorMessage);
        }
    }

    private String getBeneBankISOCountryCode(WireTransfer transfer, Message logMessage) throws ServiceException{
        String isoCode="";
        String cleansedStagingCountry="";
        if(null!=transfer && (transfer.getBeneBankCountry()==null || transfer.getBeneBankCountry().isBlank())){
            String errorMessage="Bene Bank country is not available in eConnect, hence not migrating the transaction";
            log.info(logMessage.descr(errorMessage));
            throw new ServiceException(errorMessage);
        }
        if(null!=transfer && null!=transfer.getBeneBankCountry()){
            cleansedStagingCountry=StringUtils.stripStart(transfer.getBeneBankCountry(),"");
            cleansedStagingCountry=StringUtils.stripEnd(cleansedStagingCountry,"");

            isoCode=countryCodeCheckUtility.getCountryCodeMap().get(cleansedStagingCountry.toUpperCase());
        }
        log.info(logMessage.descr("Derived BeneBankISOCountryCode for the cleansedStagingCountry "+ cleansedStagingCountry +" is : "+isoCode));
        if(isoCode==null || isoCode.isBlank()){
            String errorMessage="Bene Bank country is not available in Staging Reference table, hence not migrating the transaction";
            log.info(logMessage.descr(errorMessage));
            throw new ServiceException(errorMessage);
        }
        return isoCode;
    }

    private void setTemplateCodeAsBeneNickNameIfTemplateBased(OchPaymentRequest ochPaymentRequest, WireTransfer transfer, Message logMessage){
        if(transfer.getTemplateId()!=null){
            log.info(logMessage.descr("The transaction being migrated is template based, hence retrieving template code info from MIG_STG_WIRE_TEMPLATE"));
            StgBeneficiary stgBeneficiary=beneficiaryRepository.findByOlbClientIdAndTemplateIdAndJobId(transfer.getOlbClientId(),transfer.getTemplateId(),transfer.getJobId());
            if(stgBeneficiary!=null){
                log.info(logMessage.descr("Payee Bene Nickname to be set as Template Code - "+stgBeneficiary.getTemplateCode()));
                ochPaymentRequest.getEntryDetails()[0].getPayeeAccountDetails().getAdhocPayeeDetails().setPayeeNickName(stgBeneficiary.getTemplateCode());
            }
        }
    }
}
