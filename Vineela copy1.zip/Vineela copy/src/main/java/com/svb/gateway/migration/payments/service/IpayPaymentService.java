package com.svb.gateway.migration.payments.service;

import com.svb.gateway.migration.client.entity.MigClient;
import com.svb.gateway.migration.common.exception.ServiceException;
import com.svb.gateway.migration.common.logging.Message;
import com.svb.gateway.migration.common.mapper.MigrationEntityMapper;
import com.svb.gateway.migration.common.utility.PaymentUtils;
import com.svb.gateway.migration.common.utility.RecordCount;
import com.svb.gateway.migration.payments.entity.IpayStagingPayment;
import com.svb.gateway.migration.payments.entity.MigrationIpayPayment;
import com.svb.gateway.migration.payments.mapper.MigrationPaymentModelMapper;
import com.svb.gateway.migration.payments.model.PaymentResponse;
import com.svb.gateway.migration.payments.model.PaymentResponseData;
import com.svb.gateway.migration.payments.model.RecurringType;
import com.svb.gateway.migration.payments.repository.MigrationEntityRepository;
import com.svb.gateway.migration.payments.repository.MigrationPaymentsRepository;
import com.svb.gateway.migration.payments.repository.IpayPaymentsRepository;
import lombok.extern.log4j.Log4j2;
import org.apache.commons.lang3.ObjectUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

import static com.svb.gateway.migration.common.constants.MigrationConstants.*;

@Log4j2
@Service
public class IpayPaymentService {

    @Value("${migration.service.userid}")
    public String migrationUserId;

    public static final String NO_DATA_TO_MIGRATE = "No payments to migrate for provided client Id";
    public static final String NO_IPAY_PAYMENTS_TO_MIGRATE = "No payments to migrate";

    @Autowired
    private GatewayPaymentService gatewayPaymentService;

    @Autowired
    private MigrationPaymentsRepository migrationPaymentsRepository;

    @Autowired
    private IpayPaymentsRepository ipayPaymentsRepository;

    @Autowired
    private MigrationEntityRepository migrationEntityRepository;

    public PaymentResponse createPayments(Long jobId, MigClient migClient) throws ServiceException {
        return process(jobId, migClient);
    }

    protected PaymentResponse process(Long jobId, MigClient migClient)  throws ServiceException{
        PaymentResponse paymentResponse=new PaymentResponse();
        Message logMessage = Message.create().jobId(jobId).clientId(migClient.getEcClientId()).entityName(Message.Entity.payment);

        log.info(logMessage.descr("Entry: Processing payments for client"));
        final RecordCount recordCount=new RecordCount();

        List<IpayStagingPayment> stagingPaymentsList = ipayPaymentsRepository.findByEcClientId(jobId, migClient.getEcClientId());
        log.debug(logMessage.descr("PaymentService single payments , for transactions : "+stagingPaymentsList.size()));

        log.info(logMessage.descr("Ipay payments staging records fetched, list size :"+stagingPaymentsList.size()));

        if (stagingPaymentsList.isEmpty()) {
            recordCount.stopTime();
            migrationEntityRepository.save(MigrationEntityMapper.INSTANCE.convertPaymentToMigEntity(paymentResponse, recordCount));
            log.info(logMessage.descr("No payments available for processing for client"));
            paymentResponse.setAdditionalProperty(NO_DATA_TO_MIGRATE, NO_IPAY_PAYMENTS_TO_MIGRATE);
            return paymentResponse;
        }
        applyRecurringType(stagingPaymentsList);

        Map<Integer, MigrationIpayPayment> migrationPaymentMap = currentMigratedPaymentsByPaymentId(jobId, migClient.getEcClientId());
        log.info(logMessage.descr("Ipay payments processed records list size :"+migrationPaymentMap.size()));

        List<MigrationIpayPayment> migrationIpayPaymentList =new ArrayList<>();

        stagingPaymentsList.stream().forEach(ipayStagingPayment -> {

            log.debug(logMessage.descr("Processing IpayStagingPayment:").srcId(String.valueOf(ipayStagingPayment.getPaymentId())));
            MigrationIpayPayment newPayment=null;
            MigrationIpayPayment migratedPayment = null;
            try {
                migratedPayment = migrationPaymentMap.get(ipayStagingPayment.getPaymentId());

                if (PaymentUtils.inValidRecurringPayment(ipayStagingPayment) ) {
                    newPayment = MigrationPaymentModelMapper.INSTANCE.convertIpayPaymentToEntity(ipayStagingPayment, migratedPayment);
                    newPayment.setJobId(jobId);
                    migrationIpayPaymentList.add(newPayment);
                    recordCount.addFailure();
                } else if (migratedPayment != null && !migratedPayment.canRunAgain()  ) {
                    newPayment = MigrationPaymentModelMapper.INSTANCE.convertIpayPaymentToEntity(ipayStagingPayment, migratedPayment);
                    log.error(logMessage.descr(newPayment.getComments()).clientId(migClient.getEcClientId()).srcId(String.valueOf(newPayment.getPaymentId())));
                } else {
                    newPayment = gatewayPaymentService.insertIpayPayment(ipayStagingPayment,migClient );
                    newPayment.updateFrom(migratedPayment);
                    updateAuditColumns(newPayment, migratedPayment);
                    migrationIpayPaymentList.add(newPayment);
                    log.debug(logMessage.descr(newPayment.getComments()+": IpayStagingPayment Insert Done").srcId(String.valueOf(newPayment.getPaymentId())));
                    recordCount.updateCounter(newPayment.getStatus());
                }

                log.debug(logMessage.descr("Successfully inserted the IpayStagingPayment for ").srcId(String.valueOf(newPayment.getPaymentId())));
            }catch (ServiceException e) {
                recordCount.addFailure();
                log.error(logMessage.descr(e.getMessage()).clientId(migClient.getEcClientId()).status(STATUS_FAILURE));
            }

        });
        if(ObjectUtils.isNotEmpty(migrationIpayPaymentList) && !migrationIpayPaymentList.isEmpty()){
            migrationPaymentsRepository.saveAll(migrationIpayPaymentList); // insert or update
        }

        recordCount.stopTime();
        createSuccessResponse(paymentResponse, recordCount, migClient);
        if(recordCount.getTotal()>0){
            migrationEntityRepository.save(MigrationEntityMapper.INSTANCE.convertPaymentToMigEntity(paymentResponse, recordCount));
        }
        log.info(logMessage.descr("Processed all the Payments that were eligible for migration."));

        return paymentResponse;
    }

    private void updateAuditColumns(MigrationIpayPayment newPayment, MigrationIpayPayment migratedPayment) {
        if(migratedPayment !=null){
            newPayment.setUpdatedby(migrationUserId);
            newPayment.setUpdatedDate(LocalDateTime.now());
        }
    }

    private Map<Integer, MigrationIpayPayment> currentMigratedPaymentsByPaymentId(Long jobId, String ecClientId) {
        return Optional.ofNullable(migrationPaymentsRepository.findByJobIdAndEcClientId(jobId, ecClientId)).orElse(new ArrayList<>()).stream()
                    .filter(ObjectUtils::isNotEmpty)
                    .collect(Collectors.toMap(MigrationIpayPayment::getPaymentId, Function.identity()));
    }

    private void applyRecurringType(List<IpayStagingPayment> paymentsList) {
        paymentsList.stream().forEach(payment-> payment.setRecurringType(RecurringType.fromPayment(payment)));
    }

    private void createSuccessResponse(PaymentResponse paymentResponse, RecordCount recordCount, MigClient migClient) {

            paymentResponse.setPaymentResponseData(PaymentResponseData.builder()
                    .gwClientId(migClient.getGwClientId())
                    .ecClientId(migClient.getEcClientId())
                    .jobId(migClient.getJobId()==null?0:migClient.getJobId().intValue())
                    .status(STATUS_SUCCESS)
                    .recordCount(recordCount).build());

        paymentResponse.setAdditionalProperty("Total Records Total is: ", recordCount.getTotal());
        paymentResponse.setAdditionalProperty("Total Succesfully migrated txn Records: ", recordCount.getSuccess());
        paymentResponse.setAdditionalProperty("Total Failed Records :", recordCount.getFailure());
    }
}
