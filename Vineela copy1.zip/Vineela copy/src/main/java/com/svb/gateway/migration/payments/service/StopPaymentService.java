package com.svb.gateway.migration.payments.service;

import com.svb.gateway.migration.client.entity.MigClient;
import com.svb.gateway.migration.client.repository.MigClientRepository;
import com.svb.gateway.migration.common.exception.ServiceException;
import com.svb.gateway.migration.common.logging.Message;
import com.svb.gateway.migration.common.mapper.MigrationEntityMapper;
import com.svb.gateway.migration.common.utility.RecordCount;
import com.svb.gateway.migration.payments.entity.*;
import com.svb.gateway.migration.payments.mapper.StopPayToGatewayMapper;
import com.svb.gateway.migration.payments.model.*;
import com.svb.gateway.migration.payments.repository.*;
import com.svb.gateway.migration.rollback.model.RollBackResponse;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.sql.Timestamp;
import java.util.*;

import static com.svb.gateway.migration.common.constants.MigrationConstants.*;


@Log4j2
@Service
public class StopPaymentService {

    @Value("${mig.stoppay.url}")
    String stpUrl;

    @Autowired
    StopPaymentRepository stopPaymentRepository;

    @Autowired
    StopPayUserRepository stopPayUserRepository;

    @Autowired
    MigrationStopPaymentRepository migrationStopPaymentRepository;

    @Autowired
    MigClientRepository migClientRepository;

    @Autowired
    RestTemplate restTemplate;

    @Autowired
    private MigrationEntityRepository migrationEntityRepository;

    @Value("${migration.service.userid}")
    String updatedBy;

    private static final String NO_STOP_PAYMENTS_PRESENT = "No StopPayments present for provided client Id: ";
    private static final String ADDITIONAL_PROPERTY_KEY = "errorMessage";
    private static final Integer STATUS = 2;


    public StopPayMigrationResponse migrateStopPay(Long jobId, MigClient migClient) throws ServiceException {

        StopPayMigrationResponse stopPayMigrationResponse = new StopPayMigrationResponse();
        final RecordCount recordCount = new RecordCount();
        recordCount.setStartTime(new Timestamp(System.currentTimeMillis()));

        Message logMessage = Message.create().jobId(jobId).clientId(migClient.getEcClientId()).gwClientId(migClient.getGwClientId()).entityName(Message.Entity.stopPay).operation(STOP_PAYMENT);

        List<StopPayStagingEntity> stopPaymentStagingList = stopPaymentRepository.findByOlbClientIdAndJobId(jobId, migClient.getEcClientId());

        if(stopPaymentStagingList.isEmpty()) {
            recordCount.setEndTime(new Timestamp(System.currentTimeMillis()));
            migrationEntityRepository.save(MigrationEntityMapper.INSTANCE.convertTransferToMigEntity(migClient, recordCount, STOP_PAYMENT));
            log.info(logMessage.descr(NO_STOP_PAYMENTS_PRESENT));
            stopPayMigrationResponse.setAdditionalProperty(NO_STOP_PAYMENTS_PRESENT, NO_STOP_PAYMENTS_PRESENT+migClient.getEcClientId());
            return stopPayMigrationResponse;
        }

        log.info(logMessage.descr("Stop Payment staging records fetched, list size :"+stopPaymentStagingList.size()));

        List<StopPayStagingEntity> eligibleStopPayRecordsList = stopPaymentRepository.findByStatusAndEcClientIdAndJobId(jobId, migClient.getEcClientId());

        if(eligibleStopPayRecordsList.isEmpty()) {
            recordCount.setEndTime(new Timestamp(System.currentTimeMillis()));
            migrationEntityRepository.save(MigrationEntityMapper.INSTANCE.convertTransferToMigEntity(migClient, recordCount, STOP_PAYMENT));
            log.info(logMessage.descr(NO_STOP_PAYMENTS_PRESENT));
            stopPayMigrationResponse.setAdditionalProperty(NO_STOP_PAYMENTS_PRESENT, NO_STOP_PAYMENTS_PRESENT+migClient.getEcClientId());
            return stopPayMigrationResponse;
        }

        log.info(logMessage.descr("Stop Payment staging records eligible for migration, list size :"+eligibleStopPayRecordsList.size()));

        List<StopPayMigrationRequest> stopPayMigrationRequestList = prepareStopPaymentRequestPayload(migClient, logMessage, eligibleStopPayRecordsList);

        stopPayMigrationResponse = callStopPaymentService(stopPayMigrationRequestList, stopPayMigrationResponse, logMessage);

        log.info(logMessage.descr("Updating the stop pay response of every record in MIG_STOP_PAYMENTS table."));

        enrichMigStopPaymentAndSave(migClient, eligibleStopPayRecordsList, stopPayMigrationRequestList, stopPayMigrationResponse, recordCount);

        recordCount.stopTime();
        if (recordCount.getTotal() > 0) {
            migrationEntityRepository.save(MigrationEntityMapper.INSTANCE.convertStopPaymentToMigEntity(migClient, recordCount, STOP_PAYMENT));
            log.info(logMessage.descr("Data committed to MIG_ENTITY table for Stop Payment records"));
        }

        log.info(logMessage.summary().descr("Completed stop payment migration for the client."));
        return stopPayMigrationResponse;

    }

    private void enrichMigStopPaymentAndSave(MigClient migClient, List<StopPayStagingEntity> stopPaymentStagingList, List<StopPayMigrationRequest> stopPayMigrationRequestList, StopPayMigrationResponse stopPayMigrationResponse, RecordCount recordCount) {
        List<MigrationStopPayments> migrationStopPaymentsList = new ArrayList<>();
        String errorSource = "Stop Payment request not processed - ";
        StopPayMigrationResponse.Data[] stopPayResultData = (null!=stopPayMigrationResponse && null!=stopPayMigrationResponse.getData())?stopPayMigrationResponse.getData():null;

        for(int i=0; i < stopPaymentStagingList.size(); i++){
            MigrationStopPayments migrationStopPayments = migrationStopPaymentRepository.findByJobIdAndEcClientIdAndEcReqId(migClient.getJobId(),migClient.getEcClientId(),stopPaymentStagingList.get(i).getReqId());
            if(migrationStopPayments==null){
                migrationStopPayments= new MigrationStopPayments();
            }
            else{
                migrationStopPayments.setUpdatedBy(updatedBy);
                migrationStopPayments.setUpdatedDt(new Date());
            }
            migrationStopPayments.setJobId(migClient.getJobId());
            migrationStopPayments.setComments("");
            migrationStopPayments.setEcClientId(migClient.getEcClientId());
            migrationStopPayments.setGwClientId(migClient.getGwClientId());
            migrationStopPayments.setEcUserLoginId(stopPaymentStagingList.get(i).getUserLoginId());
            migrationStopPayments.setGwUuid(stopPayMigrationRequestList.get(i).getUserId());
            migrationStopPayments.setEcReqId(stopPaymentStagingList.get(i).getReqId());

            if(null!=stopPayResultData && stopPayResultData[i].getMigStatus().equalsIgnoreCase(STATUS_SUCCESS)){
                recordCount.addSuccess();
                migrationStopPayments.setStatus(STATUS_SUCCESS);
                migrationStopPayments.setComments(MIGRATED_SUCCESS);
                migrationStopPayments.setGwReqId(Long.valueOf(stopPayResultData[i].getGwReqId()));
            }else if(null!=stopPayResultData){
                recordCount.addFailure();
                migrationStopPayments.setStatus(STATUS_FAILURE);
                migrationStopPayments.setComments(errorSource+"Account num : " +stopPayResultData[i].getAcctNumber() + ", Check num : " +stopPayResultData[i].getCheckNumber() + ", Reason : " +stopPayResultData[i].getMigStatus() );
            }
            else{
                recordCount.addFailure();
                migrationStopPayments.setStatus(STATUS_FAILURE);
                migrationStopPayments.setComments(stopPayMigrationResponse.getAdditionalProperties()==null?STATUS_FAILURE:String.valueOf(stopPayMigrationResponse.getAdditionalProperties().get(ADDITIONAL_PROPERTY_KEY)));
            }

            migrationStopPaymentsList.add(migrationStopPayments);
        }

        if (!migrationStopPaymentsList.isEmpty()) {
            migrationStopPaymentRepository.saveAll(migrationStopPaymentsList);
        }

    }

    private StopPayMigrationResponse callStopPaymentService(List<StopPayMigrationRequest> stopPayMigrationRequestList, StopPayMigrationResponse stopPayMigrationResponse, Message logMessage) {
        try {
            HttpHeaders headers = new HttpHeaders();

            HttpEntity<List<StopPayMigrationRequest>> requestEntity = new HttpEntity<>(stopPayMigrationRequestList, headers);

            ResponseEntity<StopPayMigrationResponse> stopPayMigrationResponseResponseEntity =
                    restTemplate.exchange(stpUrl, HttpMethod.POST, requestEntity, StopPayMigrationResponse.class);

            if (stopPayMigrationResponseResponseEntity.getStatusCode() != HttpStatus.OK) {
                String errorResponse="Submit stop payment call failed with a non 200 response for request="+
                        stpUrl +ERROR_CODE + stopPayMigrationResponseResponseEntity.getStatusCode() + ERROR_MESSAGE +
                        stopPayMigrationResponseResponseEntity.getBody();
                log.info(logMessage.descr(errorResponse));
                stopPayMigrationResponse.setAdditionalProperty(ADDITIONAL_PROPERTY_KEY,errorResponse);
            }

            if(null!=stopPayMigrationResponseResponseEntity.getBody()){
                log.info(logMessage.descr("Stop Pay response recieved with 200 OK"));
                stopPayMigrationResponse=stopPayMigrationResponseResponseEntity.getBody();
            }
            else{
                log.info(logMessage.descr("Response body of stop pay api call is null"));
                stopPayMigrationResponse.setAdditionalProperty(ADDITIONAL_PROPERTY_KEY,"Response body of stop pay api call is null");
            }

            return stopPayMigrationResponse;
        }
        catch (Exception e) {
            String errorResponse="Error during stop payment migration : "+e.getMessage();
            log.error(logMessage.descr(errorResponse));
            stopPayMigrationResponse.setAdditionalProperty(ADDITIONAL_PROPERTY_KEY,errorResponse);
            return stopPayMigrationResponse;
        }
    }

    private List<StopPayMigrationRequest> prepareStopPaymentRequestPayload(MigClient migClient, Message logMessage, List<StopPayStagingEntity> stopPaymentStagingList) {

        List<StopPayMigrationRequest> stopPayMigrationRequestList = new ArrayList<>();
        stopPaymentStagingList.forEach(stgStopPayment -> {
            String stopPayMigratedUser="";
            MigStopPayUser migStopPayUser = stopPayUserRepository.getMigratedStopPayUser(migClient.getEcClientId(),stgStopPayment.getUserLoginId());
            if (migStopPayUser == null) {
                log.info(logMessage.summary().descr("User is not migrated for record having stop pay request id: "+stgStopPayment.getReqId()));
            }
            else{
                stopPayMigratedUser=migStopPayUser.getGwUid();
            }

            StopPayMigrationRequest.PayFrom payFrom = StopPayToGatewayMapper.INSTANCE.convertEcPayFromToGWRequest(stgStopPayment);
            StopPayMigrationRequest.SingleCheck singleCheck = StopPayToGatewayMapper.INSTANCE.convertEcSingleCheckToGWRequest(stgStopPayment);
            StopPayMigrationRequest stopPayMigrationRequest = StopPayToGatewayMapper.INSTANCE.convertEcStopPayToGWRequest(stgStopPayment, migClient.getGwClientId().toUpperCase(), stopPayMigratedUser, payFrom, singleCheck);
            stopPayMigrationRequest.setStatus(STATUS);

            stopPayMigrationRequestList.add(stopPayMigrationRequest);

        });

        return stopPayMigrationRequestList;
    }

    public void rollback(String ecClientId, String gWClientId, RollBackResponse rollBackResponse) {
        Message logMessage = Message.create().clientId(ecClientId).gwClientId(gWClientId).entityName(Message.Entity.stopPay);
        try {
            List<MigrationStopPayments> migrationStopPaymentsList = migrationStopPaymentRepository.findMigrationStopPaymentsByEcClientId(ecClientId);
            log.info(logMessage.descr("After record fetch for rollback of Stop Pay"));
            if (!migrationStopPaymentsList.isEmpty()) {
                migrationStopPaymentsList.forEach(migrationStopPayments -> {
                        migrationStopPayments.setStatus(STATUS_ROLLED_BACK);
                        migrationStopPayments.setUpdatedBy(updatedBy);
                        migrationStopPayments.setUpdatedDt(new Date());
                    }
                );
                migrationStopPaymentRepository.saveAll(migrationStopPaymentsList);
            }
            rollBackResponse.addSuccess("StopPayments");
        } catch (Exception e) {
            rollBackResponse.addFailure("StopPayments");
            log.error(logMessage.descr("StopPayments Rollback failed-"+e.getMessage()));
        }
    }
}