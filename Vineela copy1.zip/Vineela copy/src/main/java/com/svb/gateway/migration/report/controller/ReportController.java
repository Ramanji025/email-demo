package com.svb.gateway.migration.report.controller;

import com.svb.gateway.migration.common.constants.MigrationConstants;
import com.svb.gateway.migration.common.exception.ServiceException;
import com.svb.gateway.migration.report.api.ReportApi;
import com.svb.gateway.migration.report.service.ReportService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;


import static com.svb.gateway.migration.common.utility.ReportUtility.*;

@RestController
public class ReportController implements ReportApi {

    private final ReportService reportService;

    @Autowired
    public ReportController(ReportService reportService) {
        this.reportService = reportService;
    }

    @Override
    public ResponseEntity generateMigrationExcelReport(Long jobId, String clientId) throws ServiceException {
        ByteArrayResource doc;
        try {
            doc = reportService.generateMigrationExcelReport(jobId, clientId);
        } catch (ServiceException e) {
            return new ResponseEntity<>(e.getErrorMessage(), HttpStatus.NOT_FOUND);
        }
        return getResponseEntityForExport(doc, MigrationConstants.XLSX, MigrationConstants.MIGRATION_JOB_REPORT_PREFIX);
    }
}
