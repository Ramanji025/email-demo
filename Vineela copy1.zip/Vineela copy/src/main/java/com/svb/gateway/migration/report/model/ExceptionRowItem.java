package com.svb.gateway.migration.report.model;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ExceptionRowItem {
    Long jobId;
    String ecClientId;
    String gwClientId;
    String entityName;
    String sourceType;
    String sourceId;
    String comments;

    public ExceptionRowItem(Long jobId, String ecClientId, String gwClientId, String entityName, String sourceType, String sourceId, String comments) {
        this.jobId = jobId;
        this.ecClientId = ecClientId;
        this.gwClientId = gwClientId;
        this.entityName = entityName;
        this.sourceType = sourceType;
        this.sourceId = sourceId;
        this.comments = comments;
    }
    public ExceptionRowItem(String jobId, String ecClientId, String gwClientId, String entityName, String sourceType, String sourceId, String comments) {
        this( Long.valueOf(jobId), ecClientId, gwClientId, entityName, sourceType, sourceId, comments);
    }
    public ExceptionRowItem(Integer jobId, String ecClientId, String gwClientId, String entityName, String sourceType, String sourceId, String comments) {
        this( Long.valueOf(jobId), ecClientId, gwClientId, entityName, sourceType, sourceId, comments);
    }
}