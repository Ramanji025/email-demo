package com.svb.gateway.migration.report.model;

import com.svb.gateway.migration.common.entity.MigEntityUser;

public class MigEntityUserWarning extends MigEntityUser {
}
