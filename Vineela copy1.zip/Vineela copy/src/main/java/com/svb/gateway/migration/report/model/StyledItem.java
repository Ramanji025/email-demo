package com.svb.gateway.migration.report.model;

import lombok.Getter;
import lombok.Setter;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.Workbook;

@Getter
@Setter
public class StyledItem {
    private Object value;
    // color can be for example HSSFColor.RED.index
    private short color;
    public StyledItem(Object value){
        this.value = value;
    }
    public StyledItem(Object value, short color){
        this(value);
        this.color = color;
    }
    public CellStyle getStyle(Workbook wb) {
        CellStyle cellStyle = wb.createCellStyle();
        Font font = wb.createFont();
        font.setColor(color);
        cellStyle.setFont(font);
        return cellStyle;
    }
    public String toString(){
        if(value==null){
            return "";
        }
        else{
            return value.toString();
        }
    }
}
