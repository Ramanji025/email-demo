package com.svb.gateway.migration.report.repository;

import com.svb.gateway.migration.beneficiaries.entity.MigBeneficiary;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface MigStgIpayPayeesRepository extends JpaRepository<MigBeneficiary, String> {

    @Query(value = "select count(*) from MIG_STG_IPAY_PAYEES where JOB_ID =?1 AND EC_CLIENT_ID =?2 ", nativeQuery = true)
    Integer countMigStgIpayPayees(Long jobId, String ecClientId);
}