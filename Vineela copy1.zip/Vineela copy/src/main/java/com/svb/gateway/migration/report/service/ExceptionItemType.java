package com.svb.gateway.migration.report.service;

import com.svb.gateway.migration.alerts.entity.MigratedAlertsEntity;
import com.svb.gateway.migration.alerts.mapper.MigrationAlertsMapper;
import com.svb.gateway.migration.beneficiaries.entity.MigBeneficiary;
import com.svb.gateway.migration.beneficiaries.repository.MigBeneficiaryRepository;
import com.svb.gateway.migration.cards.entity.MigCardProgram;
import com.svb.gateway.migration.cards.repository.MigCardProgramRepository;
import com.svb.gateway.migration.common.constants.MigrationConstants;
import com.svb.gateway.migration.common.entity.MigEntityUser;
import com.svb.gateway.migration.nickname.entity.MigratedNicknamesEntity;
import com.svb.gateway.migration.nickname.mapper.MigrationNicknameMapper;
import com.svb.gateway.migration.payments.entity.MigrationInternalTransfer;
import com.svb.gateway.migration.payments.entity.MigrationIpayPayment;
import com.svb.gateway.migration.payments.entity.MigrationStopPayments;
import com.svb.gateway.migration.payments.entity.MigrationWireTransfer;
import com.svb.gateway.migration.payments.repository.MigrationPaymentsRepository;
import com.svb.gateway.migration.payments.repository.MigrationTransferRepository;
import com.svb.gateway.migration.payments.repository.MigrationWireTransferRepository;
import com.svb.gateway.migration.report.model.ExceptionRowItem;
import com.svb.gateway.migration.user.entity.MigCardUserEntity;
import com.svb.gateway.migration.user.entity.MigUser;
import com.svb.gateway.migration.user.repository.MigCardUserRepository;
import com.svb.gateway.migration.user.repository.MigUserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.svb.gateway.migration.common.constants.ReportConstants.*;

public  interface ExceptionItemType {
    List<Object> getExceptionDataList(MigEntityUser entity);
    ExceptionRowItem getExceptionRowItem(MigEntityUser entity, Object o);

    default List<String> getFailureStatuses() {
        List<String> failStatus = new ArrayList<>();
        failStatus.add(MigrationConstants.STATUS_FAILURE);
        failStatus.add(MigrationConstants.STATUS_IGNORE);
        return failStatus;
    }
}
@Component
class UserExceptionItemType implements ExceptionItemType {
    @Autowired
    private MigUserRepository migUserRepository;
    @Override
    public List getExceptionDataList(MigEntityUser entity) {
        return migUserRepository.findByJobIdAndAndEcClientIdAndStatus(Long.valueOf(entity.getJobId()), entity.getEcclientId(), getFailureStatuses(), PRIMARY_USER_CREATION.equals(entity.getEntityName()));
    }
    @Override
    public ExceptionRowItem getExceptionRowItem(MigEntityUser entity, Object o){
        MigUser user = (MigUser)o;
        return new ExceptionRowItem(user.getJobId(), user.getEcClientId(), user.getGwClientId(), ADDITIONAL_USER_CREATION, ECONNECT_SOURCE, user.getEcUserLoginId(), user.getComments());
    }
}
@Component
class BeneExceptionItemType implements ExceptionItemType {
    private static Map<String, String> beneSourceTypeMap = new HashMap<>();

    @Autowired
    MigBeneficiaryRepository migBeneficiaryRepository;

    public BeneExceptionItemType(MigBeneficiaryRepository migBeneficiaryRepository) {
        this.migBeneficiaryRepository = migBeneficiaryRepository;
    }
    @PostConstruct
    void initBeneExceptionTypeMap(){
        beneSourceTypeMap.put(BENE_CREATION_TEMPLATE, "eConnectTemplate");
        beneSourceTypeMap.put(BENE_CREATION_ACH, "IPAY ACH");
        beneSourceTypeMap.put(BENE_CREATION_ACH_LARGE, "IPAY ACH_LARGE");
        beneSourceTypeMap.put(BENE_CREATION_CHECK, "IPAY Check");
    }
    @Override
    public List getExceptionDataList(MigEntityUser entity) {
        return migBeneficiaryRepository.findByEcClientIdAndJobIdAndStatusAndBeneSourceType(Long.valueOf(entity.getJobId()), entity.getEcclientId(), getFailureStatuses(), beneSourceTypeMap.get(entity.getEntityName()));
    }
    @Override
    public ExceptionRowItem getExceptionRowItem(MigEntityUser entity, Object o){
        MigBeneficiary bene = (MigBeneficiary)o;
        return new ExceptionRowItem(bene.getJobId(), bene.getEcClientId(), bene.getGwClientId(), entity.getEntityName(), bene.getBeneSourceType(), bene.getBeneSourceId(), bene.getComments());
    }
}
@Component
class MigrationInternalTransferExceptionItemType implements ExceptionItemType {
    @Autowired
    private MigrationTransferRepository migrationTransferRepository;
    @Override
    public List getExceptionDataList(MigEntityUser entity) {
        return migrationTransferRepository.findByEcClientIdAndJobIdAndStatus(entity.getEcclientId(), Long.valueOf(entity.getJobId()), getFailureStatuses());
    }
    @Override
    public ExceptionRowItem getExceptionRowItem(MigEntityUser entity, Object o){
        MigrationInternalTransfer transfers = (MigrationInternalTransfer)o;
        return new ExceptionRowItem(transfers.getJobId(), transfers.getEcClientId(), transfers.getGwClientId(), INTERNAL_TRANSFER, ECONNECT_SOURCE, String.valueOf(transfers.getEcTxnId()), transfers.getComments());
    }
}
@Component
class MigratedAlertsExceptionItemType implements ExceptionItemType {
    @Autowired
    private MigrationAlertsMapper migrationAlertsMapper;
    @Override
    public List getExceptionDataList(MigEntityUser entity) {
        return migrationAlertsMapper.findByEcClientIdAndJobIdAndStatus(Long.valueOf(entity.getJobId()), entity.getEcclientId());
    }
    @Override
    public ExceptionRowItem getExceptionRowItem(MigEntityUser entity, Object o){
        MigratedAlertsEntity migratedAlertsEntity = (MigratedAlertsEntity)o;
        return new ExceptionRowItem(migratedAlertsEntity.getJobId(), migratedAlertsEntity.getEc_Client_Id(), migratedAlertsEntity.getGw_Client_Id(), ALERT_SUBSCRIPTION, ECONNECT_SOURCE, migratedAlertsEntity.getGw_Alert_Id(), migratedAlertsEntity.getComments());
    }
}
@Component
class MigratedNicknamesExceptionItemType implements ExceptionItemType {
    @Autowired
    private MigrationNicknameMapper migrationNicknameMapper;
    @Override
    public List getExceptionDataList(MigEntityUser entity) {
        return migrationNicknameMapper.findByEcClientIdAndJobIdAndStatus(Long.valueOf(entity.getJobId()), entity.getEcclientId());
    }
    @Override
    public ExceptionRowItem getExceptionRowItem(MigEntityUser entity, Object o){
        MigratedNicknamesEntity migratedNicknamesEntity = (MigratedNicknamesEntity)o;
        return new ExceptionRowItem(migratedNicknamesEntity.getJobId(), migratedNicknamesEntity.getEc_Client_Id(), migratedNicknamesEntity.getGw_Client_Id(), ACCOUNT_NICKNAME, ECONNECT_SOURCE, migratedNicknamesEntity.getAccount_Number(), migratedNicknamesEntity.getComments());
    }
}
@Component
class MigrationIpayPaymentExceptionItemType implements ExceptionItemType {
    @Autowired
    private MigrationPaymentsRepository migrationPaymentsRepository;
    @Override
    public List getExceptionDataList(MigEntityUser entity) {
        return migrationPaymentsRepository.findByEcClientIdAndJobIdAndStatus(entity.getEcclientId(), Long.valueOf(entity.getJobId()), getFailureStatuses());
    }
    @Override
    public ExceptionRowItem getExceptionRowItem(MigEntityUser entity, Object o){
        MigrationIpayPayment migrationPayment = (MigrationIpayPayment)o;
        return new ExceptionRowItem(migrationPayment.getJobId(), migrationPayment.getEcClientId(), migrationPayment.getGwClientId(), IPAY_PAYMENTS, IPAY_SOURCE, String.valueOf(migrationPayment.getPaymentId()), migrationPayment.getComments());
    }
}
@Component
class MigCardProgramExceptionItemType implements ExceptionItemType {
    @Autowired
    private MigCardProgramRepository migCardProgramRepository;
    @Override
    public List getExceptionDataList(MigEntityUser entity) {
        return migCardProgramRepository.findByEcClientIdAndJobIdAndStatus(entity.getEcclientId(), Long.valueOf(entity.getJobId()), getFailureStatuses());
    }
    @Override
    public ExceptionRowItem getExceptionRowItem(MigEntityUser entity, Object o){
        MigCardProgram cardProgram = (MigCardProgram)o;
        return new ExceptionRowItem(cardProgram.getJobId(), cardProgram.getEcClientId(), cardProgram.getOlbClientId(), ENROLL_CARD_PROGRAM, null, cardProgram.getProgramId(), cardProgram.getComments());
    }
}
@Component
class MigrationWireTransferExceptionItemType implements ExceptionItemType {
    @Autowired
    private MigrationWireTransferRepository migrationWireTransferRepository;
    @Override
    public List getExceptionDataList(MigEntityUser entity) {
        return migrationWireTransferRepository.findByEcClientIdAndJobIdAndStatus(entity.getEcclientId(), Long.valueOf(entity.getJobId()), getFailureStatuses());
    }
    @Override
    public ExceptionRowItem getExceptionRowItem(MigEntityUser entity, Object o){
        MigrationWireTransfer wireTransfer = (MigrationWireTransfer)o;
        return new ExceptionRowItem(wireTransfer.getJobId(), wireTransfer.getEcClientId(), wireTransfer.getGwClientId(), WIRE_TRANSFERS, ECONNECT_SOURCE, String.valueOf(wireTransfer.getEcTxnId()), wireTransfer.getComments());
    }
}
@Component
class MigCardUserExceptionItemType implements ExceptionItemType {
    @Autowired
    private MigCardUserRepository migCardUserRepository;
    @Override
    public List getExceptionDataList(MigEntityUser entity) {
        return migCardUserRepository.findByEcClientIdAndJobIdAndStatus(entity.getEcclientId(), Long.valueOf(entity.getJobId()), getFailureStatuses());
    }
    @Override
    public ExceptionRowItem getExceptionRowItem(MigEntityUser entity, Object o){
        MigCardUserEntity migCardUserEntity = (MigCardUserEntity)o;
        return new ExceptionRowItem(migCardUserEntity.getJobId(), migCardUserEntity.getEcClientId(), migCardUserEntity.getGwClientId(), MIG_CARD_USER_UPDATE, ECONNECT_SOURCE, migCardUserEntity.getProgramId(), migCardUserEntity.getStatus());
    }
}

@Component
class MigStopPaymentItemType implements ExceptionItemType {

    @Autowired
    private MigrationPaymentsRepository paymentsRepository;

    @Override
    public List getExceptionDataList(MigEntityUser entity) {

        return paymentsRepository.findByEcClientIdAndJobIdAndStatus(entity.getEcclientId(),
                Long.valueOf(entity.getJobId().toString()), getFailureStatuses());
    }

    @Override
    public ExceptionRowItem getExceptionRowItem(MigEntityUser entity, Object o) {
        MigrationStopPayments stopPayments =  (MigrationStopPayments)o;

        return new ExceptionRowItem(stopPayments.getJobId(), stopPayments.getEcClientId(), stopPayments.getGwClientId(), );
    }
}