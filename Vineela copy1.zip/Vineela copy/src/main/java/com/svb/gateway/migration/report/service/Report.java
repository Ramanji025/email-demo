package com.svb.gateway.migration.report.service;

import com.svb.gateway.migration.beneficiaries.entity.MigBeneficiary;
import com.svb.gateway.migration.beneficiaries.repository.MigBeneficiaryRepository;
import com.svb.gateway.migration.client.entity.MigClient;
import com.svb.gateway.migration.common.constants.ReportConstants;
import com.svb.gateway.migration.common.entity.MigEntity;
import com.svb.gateway.migration.common.entity.MigEntityUser;
import com.svb.gateway.migration.job.entity.MigJob;
import com.svb.gateway.migration.report.model.ExceptionRowItem;
import com.svb.gateway.migration.report.model.MigEntityUserWarning;
import com.svb.gateway.migration.report.model.StyledItem;
import com.svb.gateway.migration.user.entity.MigUser;
import org.apache.commons.lang3.StringUtils;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import static com.svb.gateway.migration.common.constants.MigrationConstants.STATUS_SUCCESS;
import static com.svb.gateway.migration.common.constants.ReportConstants.*;

public interface Report {
    abstract String getSheetName();
    abstract Object[] getEntityHeaders();
    abstract Object[] getEntityCollection(Object entity);

    default void createSheet(XSSFWorkbook wb, Collection<?> list) {
        Sheet sheet = wb.createSheet(getSheetName());
        int count = 0;
        fillRow(sheet, count++, getEntityHeaders());
        for (Object o : list) {
            fillRow(sheet, count, getEntityCollection(o));
            count++;
        }
    }

    default void fillRow(Sheet sheet, int rowNum, Object[] values) {
        if(values!=null && values.length>0) {
            Row data = sheet.createRow(rowNum);
            int colNum = 0;
            Cell serialNumberCol = data.createCell(colNum++);
            serialNumberCol.setCellValue(rowNum);
            for (Object o : values) {
                Cell cell = data.createCell(colNum);
                if (o == null) {
                    cell.setCellValue(ReportConstants.BLANK);
                } else {
                    if(hasStyle(o)){
                        cell.setCellStyle(((StyledItem)o).getStyle(sheet.getWorkbook()));
                    }
                    cell.setCellValue(o.toString());
                }
                colNum++;
            }
        }
    }

    default String removeSpecialChars(String value) {
        if(StringUtils.isBlank(value)) {
            return value;
        }
        var matcher = regexSpecialChar.matcher(value);
        if(matcher.find()) {
          return matcher.replaceAll("");
        } else {
            return value;
        }
    }
    private boolean hasStyle(Object o) {
        return o instanceof StyledItem && ((StyledItem)o).getColor()!=0;
    }
}
@Component
class JobReport implements Report {
    @Override
    public String getSheetName() {
        return JOB_REPORT;
    }
    @Override
    public Object[] getEntityHeaders() {
        return new Object[]{JOBID, JOB_TYPE, STARTTIME, ENDTIME, EXTRACTION_TIME, LOAD_TIME, CLIENT_COUNT, STATUS};
    }
    @Override
    public Object[] getEntityCollection(Object entityObj) {
        MigJob entity = (MigJob)entityObj;
        return new Object[]{entity.getJobId(), entity.getType(), entity.getStartTime(), entity.getEndTime(), entity.getExtractionTime(), entity.getLoadTime(), entity.getCandidateCount(), entity.getStatus()};
    }
}
@Component
class ClientReport implements Report {
    @Override
    public String getSheetName() {
        return CLIENT_REPORT;
    }
    @Override
    public Object[] getEntityHeaders() {
        return new Object[]{JOBID, ECCLIENTID, GWCLIENTID, EC_CLIENT_ID_NUM, CLIENT_NAME, COMPANY_ID, PRIMARY_CIF_UBS, STATUS, UPDATED_DATE, BDC_REGISTRATION_STATUS, RDM_REGISTRATION_STATUS, COMMENTS, APPROVAL_SETTING };
    }
    @Override
    public Object[] getEntityCollection(Object entityObj) {
        MigClient entity = (MigClient)entityObj;
        String updateDate = entity.getUpdateDate()==null?null:new SimpleDateFormat("dd/MM/yyyy HH:mm").format(entity.getUpdateDate());
        return new Object[]{entity.getJobId(), entity.getEcClientId(), entity.getGwClientId(), entity.getEcClientIdNum(), entity.getClientName(), entity.getCompanyId(), entity.getPrimaryCifUbs(), entity.getStatus(), updateDate, entity.bdcStatusAsString(), entity.rdmStatusAsString(), entity.getComments(),entity.getFinalGwClientAppr()};
    }
}
@Component
class UserReport implements Report {
    @Override
    public String getSheetName() {
        return USER_REPORT;
    }
    @Override
    public Object[] getEntityHeaders() {
        return new Object[]{JOBID, ECCLIENTID, GWCLIENTID, EC_CLIENT_ID_NUM, EC_USER_ID_NUM, EC_USER_LOGIN_ID, GW_UUID, FIRST_NAME, LAST_NAME, MOBILE_NUMBER, EMAIL_ID, STATUS, USER_TYPE, BDC_STATUS, RDM_REGISTRATION_STATUS, IS_PRIMARY_USER, WC_EMAIL_SNT_FLAG, COMMENTS, USER_ROLE, ISAPPROVER, USER_ACCESS, USER_STATUS };
    }
    @Override
    public Object[] getEntityCollection(Object entityObj) {
        MigUser entity = (MigUser)entityObj;
        String isPrimaryUser = "N";
        if(entity.getIsPrimaryUser() == 1){
            isPrimaryUser = "Y";
        }
        return new Object[]{entity.getJobId(), entity.getEcClientId(),
                entity.getGwClientId(), entity.getEcClientIdNum(), entity.getEcUserIdNum(), entity.getEcUserLoginId(), entity.getGwUuid(),
                removeSpecialChars(entity.getFirstName()), removeSpecialChars(entity.getLastName()),
                removeSpecialChars(entity.getMobileNumber()), removeSpecialChars(entity.getEmailId()),
                entity.getStatus(), entity.getTypeOfUser(), entity.bdcStatusAsString(), entity.rdmStatusAsString(), isPrimaryUser,
                entity.getEmailFlag(), entity.getComments(), entity.getUserRole(), entity.getIsApprover(), entity.getUserAccess(),
                UserStatusEnum.fromString(entity.getUserStatus())};
    }
}
@Component
class ExtractionReport implements Report {
     public String getSheetName() {
        return EXTRACTION_REPORT;
    }
    @Override
    public Object[] getEntityHeaders() {
        return new Object[]{JOBID, STEP_NAME, SOURCE_COUNT, STAGING_COUNT, SKIP_COUNT};
    }
    @Override
    public Object[] getEntityCollection(Object entityObj) {
        MigEntity entity = (MigEntity)entityObj;
        return new Object[]{entity.getJobId(), entity.getEntityName(), entity.getReadCount(), entity.getWriteCount(), entity.getSkipCount()};
    }
}
@Component
class TargetLoadReport implements Report {
    @Override
    public String getSheetName() {
        return TARGET_LOAD_REPORT;
    }
    @Override
    public Object[] getEntityHeaders() {
        return new Object[]{JOBID, ECCLIENTID, GWCLIENTID, ENTITY_NAME, STAGING_COUNT, TARGET_COUNT, SKIP_COUNT};
    }
    @Override
    public Object[] getEntityCollection(Object entityObj) {
        MigEntityUser entity = (MigEntityUser)entityObj;
        Object entityName;
        if(entity instanceof MigEntityUserWarning){
            entityName = new StyledItem(entity.getEntityName(), HSSFColor.HSSFColorPredefined.RED.getIndex());
        }
        else{
            entityName = entity.getEntityName();
        }
        return new Object[]{entity.getJobId(), entity.getEcclientId(), entity.getGwclientId(), entityName, entity.getReadCount(), entity.getWriteCount(), entity.getSkipCount()};
    }
}
@Component
class BeneficiaryReport implements Report {
    @Autowired
    private MigBeneficiaryRepository migBeneficiaryRepository;

    @Override
    public String getSheetName() {
        return BENEFICIARY_REPORT;
    }
    @Override
    public Object[] getEntityHeaders() {
        return new Object[]{JOBID, ECCLIENTID, GWCLIENTID, TARGET_COUNT, TARGET_SUCCESS_COUNT, TARGET_PENDING_COUNT};
    }
    @Override
    public Object[] getEntityCollection(Object entityObj) {
        MigClient entity = (MigClient)entityObj;
        List<String> statusList = new ArrayList<>();
        statusList.add(STATUS_SUCCESS);
        List<MigBeneficiary> migBeneficiaryList = migBeneficiaryRepository.findByEcClientIdAndJobIdAndStatus(entity.getJobId(), entity.getEcClientId(), statusList);
        Integer countPending = 0;
        Integer countAddedBeneficiary = 0;
        if(!migBeneficiaryList.isEmpty()) {
            for (MigBeneficiary migBeneficiary : migBeneficiaryList) {
                if (migBeneficiary.getBeneficiaryId() != null) {
                    countAddedBeneficiary++;
                } else if (migBeneficiary.getPendingRecipientId() != null) {
                    countPending++;
                }
            }
        }
        return new Object[]{entity.getJobId(), entity.getEcClientId(), entity.getGwClientId(), migBeneficiaryList.size(), countAddedBeneficiary, countPending};
    }
}
@Component
class ExceptionReport implements Report {
    @Override
    public String getSheetName() {
        return EXCEPTION;
    }
    @Override
    public Object[] getEntityHeaders() {
        return new Object[]{JOBID, ECCLIENTID, GWCLIENTID, STEP_ENTITY_NAME, SOURCE_SYSTEM_TYPE, SOURCE_SYSTEM_ID, EXCEPTION_DETAILS};
    }
    @Override
    public Object[] getEntityCollection(Object entityObj) {
        ExceptionRowItem entity = (ExceptionRowItem)entityObj;
        return new Object[]{entity.getJobId(), entity.getEcClientId(), entity.getGwClientId(), entity.getEntityName(), entity.getSourceType(), entity.getSourceId(), entity.getComments()};
    }
}
