package com.svb.gateway.migration.report.service;

import com.svb.gateway.migration.client.entity.MigClient;
import com.svb.gateway.migration.client.repository.MigClientRepository;
import com.svb.gateway.migration.common.constants.MigrationConstants;
import com.svb.gateway.migration.common.entity.MigEntity;
import com.svb.gateway.migration.common.entity.MigEntityUser;
import com.svb.gateway.migration.common.exception.ServiceException;
import com.svb.gateway.migration.common.logging.Message;
import com.svb.gateway.migration.common.repository.MigEntityRepository;
import com.svb.gateway.migration.common.repository.MigEntityUserRepository;
import com.svb.gateway.migration.common.utility.CommonValidator;
import com.svb.gateway.migration.job.entity.MigJob;
import com.svb.gateway.migration.job.repository.MigJobRepository;
import com.svb.gateway.migration.report.model.ExceptionRowItem;
import com.svb.gateway.migration.report.model.MigEntitySkipLog;
import com.svb.gateway.migration.report.model.MigEntityUserWarning;
import com.svb.gateway.migration.report.repository.MigEntitySkipLogRepository;
import com.svb.gateway.migration.report.repository.MigStgIpayPayeesRepository;
import com.svb.gateway.migration.report.repository.MigStgIpayPaymentsRepository;
import com.svb.gateway.migration.user.entity.MigUser;
import com.svb.gateway.migration.user.repository.MigUserRepository;
import lombok.extern.log4j.Log4j2;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.*;
import java.util.stream.Collectors;

import static com.svb.gateway.migration.common.constants.MigrationConstants.EMAIL_NOTIFICATION;
import static com.svb.gateway.migration.common.constants.MigrationConstants.STOP_PAYMENT;
import static com.svb.gateway.migration.common.constants.ReportConstants.*;

@Log4j2
@Service
public class ReportService {

    private static String[] namesList() {
        return new String[]{BENE_CREATION_TEMPLATE, BENE_CREATION_FUTURE, BENE_CREATION_CHECK, BENE_CREATION_ACH_LARGE, BENE_CREATION_ACH, ADDITIONAL_USER_CREATION, PRIMARY_USER_CREATION, CLIENT_CREATION, ENROLL_CARD_PROGRAM, TRANSFERS_CREATION,
                WIRE_TRANSFERS_CREATION, WIRE_TRANSFERS, INTERNAL_TRANSFER, MIG_CARD_USER_UPDATE, MIG_CARD_USER_ROLLBACK, ACCOUNT_NICKNAME, ALERT_SUBSCRIPTION, IPAY_PAYMENTS,STOP_PAYMENT };
    }

    private static Map<String, ExceptionItemType> exceptionItemTypeMap = new HashMap<>();
    @Autowired
    private MigClientRepository migClientRepository;
    @Autowired
    private MigUserRepository migUserRepository;
    @Autowired
    private MigJobRepository migJobRepository;
    @Autowired
    private MigEntityUserRepository migEntityUserRepository;
    @Autowired
    private MigEntityRepository migEntityRepository;
    @Autowired
    private MigEntitySkipLogRepository migEntitySkipLogRepository;
    @Autowired
    private MigStgIpayPayeesRepository migStgIpayPayeesRepository;
    @Autowired
    private MigStgIpayPaymentsRepository migStgIpayPaymentsRepository;
    @Autowired
    private JobReport jobReport;
    @Autowired
    private ClientReport clientReport;
    @Autowired
    private UserReport userReport;
    @Autowired
    private ExtractionReport extractionReport;
    @Autowired
    private TargetLoadReport targetLoadReport;
    @Autowired
    private BeneficiaryReport beneficiaryReport;
    @Autowired
    private ExceptionReport exceptionReport;
    @Autowired
    private BeneExceptionItemType beneExceptionItemType;
    @Autowired
    private UserExceptionItemType userExceptionItemType;
    @Autowired
    private MigrationInternalTransferExceptionItemType migrationInternalTransferExceptionItemType;
    @Autowired
    private MigratedAlertsExceptionItemType migratedAlertsExceptionItemType;
    @Autowired
    private MigratedNicknamesExceptionItemType migratedNicknamesExceptionItemType;
    @Autowired
    private MigrationIpayPaymentExceptionItemType migrationIpayPaymentExceptionItemType;
    @Autowired
    private MigCardProgramExceptionItemType migCardProgramExceptionItemType;
    @Autowired
    private MigrationWireTransferExceptionItemType migrationWireTransferExceptionItemType;
    @Autowired
    private MigCardUserExceptionItemType migCardUserExceptionItemType;

    public ByteArrayResource generateMigrationExcelReport(Long jobId, String clientId) throws ServiceException {
        Message message = Message.create().jobId(jobId).clientId(clientId);
        String ecClientId = parseClient(clientId);
        MigJob migJob = getMigJob(jobId, ecClientId);
        jobId = migJob.getJobId();
        List<MigClient> migClientList = getClientList(jobId, ecClientId);
        List<MigClient> failedClientList = migClientList.stream().filter(migClient -> !migClient.getStatus().equals(MigrationConstants.STATUS_SUCCESS)).collect(Collectors.toList());
        List<MigUser> migUsersList = getUserList(jobId, ecClientId);
        List<MigEntityUser> migEntityList = getMigEntity(jobId, ecClientId);
        List<MigEntity> migEntityExtList = getMigEntityExtList(jobId).stream().filter(entity -> !entity.getEntityName().equals(EMAIL_NOTIFICATION)).collect(Collectors.toList());
        Collection<MigEntityUser> collatedMigEntityList = collateRetries(migEntityList);
        Collection<MigEntityUser> loadReportListList = augmentLoadReportList(migClientList, collatedMigEntityList);
        List<ExceptionRowItem> exceptionList = getExceptionList(jobId, failedClientList, collatedMigEntityList);
        try (XSSFWorkbook wb = new XSSFWorkbook()){
            jobReport.createSheet(wb, Collections.singletonList(migJob));
            clientReport.createSheet(wb, migClientList);
            userReport.createSheet(wb, migUsersList);
            extractionReport.createSheet(wb, migEntityExtList);
            targetLoadReport.createSheet(wb, loadReportListList);
            beneficiaryReport.createSheet(wb, migClientList);
            exceptionReport.createSheet(wb, exceptionList);
            log.info(message.descr("Created report").summary());
            return getByteArrayResource(wb);
        } catch (IOException e) {
            log.error(message.descr(e.getMessage()));
            throw new ServiceException(SERVICEREPORTEXCEPTION);
        }
    }

    private Collection<MigEntityUser> augmentLoadReportList(List<MigClient> migClientList, Collection<MigEntityUser> collatedMigEntityList) {
        for(MigClient migClient : migClientList){
            int numIPayPayees = numIPayPayees(migClient.getJobId(), migClient.getEcClientId());
            if(migClient.getBdcStatus()!=null && migClient.getBdcStatus()==0 && numIPayPayees > 0){
                MigEntityUserWarning item = new MigEntityUserWarning();
                item.setJobId(migClient.getJobId().intValue());
                item.setEcclientId(migClient.getEcClientId());
                item.setEntityName("iPay Payees migration not attempted as BDC Registration was not successful");
                item.setReadCount(numIPayPayees);
                item.setSkipCount(numIPayPayees);
                collatedMigEntityList.add(item);
            }
            int numIPayPayments = numIPayPayments(migClient.getJobId(), migClient.getEcClientId());
            if(migClient.getBdcStatus()!=null && migClient.getBdcStatus()==0 && numIPayPayments > 0){
                MigEntityUserWarning item = new MigEntityUserWarning();
                item.setJobId(migClient.getJobId().intValue());
                item.setEcclientId(migClient.getEcClientId());
                item.setEntityName("iPay Payments migration not attempted as BDC Registration was not successful");
                item.setReadCount(numIPayPayments);
                item.setSkipCount(numIPayPayments);
                collatedMigEntityList.add(item);
            }
        }
        return collatedMigEntityList;
    }

    private int numIPayPayments(Long jobId, String ecClientId) {
        return migStgIpayPaymentsRepository.countMigStgIpayPayments(jobId, ecClientId);
    }

    private int numIPayPayees(Long jobId, String ecClientId) {
        return migStgIpayPayeesRepository.countMigStgIpayPayees(jobId, ecClientId);
    }

    private String parseClient(String clientId) throws ServiceException {
        if (CommonValidator.isEcClientIdFormatValid(clientId)) {
            boolean existsInEconnect = migClientRepository.existsMigClientByEcClientId(clientId);
            if (existsInEconnect) {
                return clientId;
            } else {
                throw new ServiceException(ENTITY_NOT_PRESENT, CLIENT_NOT_PRESENT);
            }
        } else if (CommonValidator.isGwClientIdFormatValid(clientId)) {
            boolean existsInGateway = migClientRepository.existsMigClientByGwClientId(clientId);
            if (existsInGateway) {
                MigClient migClient = migClientRepository.findByGwClientId(clientId);
                return migClient.getEcClientId();
            } else {
                throw new ServiceException(ENTITY_NOT_PRESENT, CLIENT_NOT_PRESENT);
            }
        } else {
            return null;
        }
    }

    private List<MigClient> getClientList(Long jobId, String ecClientId) {
        if (ecClientId == null) {
            return migClientRepository.findByJobId(jobId);
        } else {
            return Collections.singletonList(migClientRepository.findByEcClientIdLatest(ecClientId));
        }
    }

    private MigJob getMigJob(Long jobId, String ecClientId) {
        if (jobId == null) {
            MigClient migClient = migClientRepository.findByEcClientIdLatest(ecClientId);
            return migJobRepository.findByJobIdValue(migClient.getJobId());
        } else {
            return migJobRepository.findByJobIdValue(jobId);
        }
    }

    private List<MigUser> getUserList(Long jobId, String ecClientId) {
        if (ecClientId == null) {
            return migUserRepository.findByJobId(jobId);
        } else {
            return migUserRepository.findByEcClientIdAndJobId(ecClientId, jobId);
        }
    }

    private List<MigEntityUser> getMigEntity(Long jobId, String ecClientId) {
        if (ecClientId == null) {
            return migEntityUserRepository.findByJobIdAndByEntityNameIn(Math.toIntExact(jobId), namesList());
        } else {
            return migEntityUserRepository.findByEcClientIdAndJobIdAndEntityNameIn(ecClientId, Math.toIntExact(jobId), namesList());
        }
    }

    private List<MigEntity> getMigEntityExtList(Long jobId) {
        return migEntityRepository.findByJobIdAndByEntityNameNotIn(jobId, namesList());
    }

    private Collection<MigEntityUser> collateRetries(List<MigEntityUser> migEntityList) {
        Map<String, MigEntityUser> collateMap = new LinkedHashMap<>();
        for (MigEntityUser migEntityUser : migEntityList) {
            String key = migEntityUser.getEcclientId() + ":" + migEntityUser.getEntityName();
            if (collateMap.containsKey(key)) {
                MigEntityUser existingMigEntityUser = collateMap.get(key);
                existingMigEntityUser.setReadCount(Math.max(migEntityUser.getReadCount(), existingMigEntityUser.getReadCount()));
                existingMigEntityUser.setWriteCount(migEntityUser.getWriteCount() + existingMigEntityUser.getWriteCount());
                existingMigEntityUser.setSkipCount(Math.min(migEntityUser.getSkipCount(), existingMigEntityUser.getSkipCount()));
            } else {
                collateMap.put(key, migEntityUser);
            }
        }
        return new ArrayList<>(collateMap.values());
    }

    @PostConstruct
    void initExceptionItemTypeMap(){
        exceptionItemTypeMap.put(PRIMARY_USER_CREATION, userExceptionItemType);
        exceptionItemTypeMap.put(ADDITIONAL_USER_CREATION, userExceptionItemType);
        exceptionItemTypeMap.put(BENE_CREATION_TEMPLATE, beneExceptionItemType);
        exceptionItemTypeMap.put(BENE_CREATION_FUTURE, beneExceptionItemType);
        exceptionItemTypeMap.put(BENE_CREATION_ACH, beneExceptionItemType);
        exceptionItemTypeMap.put(BENE_CREATION_ACH_LARGE, beneExceptionItemType);
        exceptionItemTypeMap.put(BENE_CREATION_CHECK, beneExceptionItemType);
        exceptionItemTypeMap.put(INTERNAL_TRANSFER, migrationInternalTransferExceptionItemType);
        exceptionItemTypeMap.put(ALERT_SUBSCRIPTION, migratedAlertsExceptionItemType);
        exceptionItemTypeMap.put(ACCOUNT_NICKNAME, migratedNicknamesExceptionItemType);
        exceptionItemTypeMap.put(IPAY_PAYMENTS, migrationIpayPaymentExceptionItemType);
        exceptionItemTypeMap.put(ENROLL_CARD_PROGRAM, migCardProgramExceptionItemType);
        exceptionItemTypeMap.put(WIRE_TRANSFERS, migrationWireTransferExceptionItemType);
        exceptionItemTypeMap.put(MIG_CARD_USER_UPDATE, migCardUserExceptionItemType);
    }

    private List<ExceptionRowItem> getExceptionList(Long jobId, List<MigClient> failedClientList, Collection<MigEntityUser> collatedMigEntityList) {
        List<ExceptionRowItem> exceptionList = new ArrayList<>();
        for (MigClient client : failedClientList) {
            exceptionList.add(new ExceptionRowItem(client.getJobId(), client.getEcClientId(), client.getGwClientId(), CLIENT_CREATION, ECONNECT_SOURCE, null, client.getComments()));
        }
        List<MigEntitySkipLog> migEntitySkipLogList = migEntitySkipLogRepository.findByJobId(String.valueOf(jobId));
        for (MigEntitySkipLog entity : migEntitySkipLogList) {
            exceptionList.add(new ExceptionRowItem(entity.getJobId(), null, null, MIG_STG_SKIP_LOG, null, null, entity.getRecordDetails()));
        }
        for (MigEntityUser entity : collatedMigEntityList) {

            ExceptionItemType itemType = exceptionItemTypeMap.get(entity.getEntityName());
            if(itemType!=null) {
                List<Object> rowDataList = itemType.getExceptionDataList(entity);
                for (Object rowData : rowDataList) {
                    exceptionList.add(itemType.getExceptionRowItem(entity, rowData));
                }
            }
        }
        return exceptionList;
    }

    private ByteArrayResource getByteArrayResource(XSSFWorkbook wb) throws ServiceException {
        try {
            int numberOfSheets = wb.getNumberOfSheets();
            for (int i = 0; i < numberOfSheets; i++) {
                Sheet sheet = wb.getSheetAt(i);
                if (sheet.getPhysicalNumberOfRows() > 0) {
                    Row row = sheet.getRow(sheet.getFirstRowNum());
                    Iterator<Cell> cellIterator = row.cellIterator();
                    while (cellIterator.hasNext()) {
                        Cell cell = cellIterator.next();
                        int columnIndex = cell.getColumnIndex();
                        sheet.autoSizeColumn(columnIndex);
                    }
                }
            }
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            wb.write(out);
            return new ByteArrayResource(out.toByteArray());
        } catch (Exception e) {
            throw new ServiceException(REPORTEXCEPTION + " " + e.getMessage());
        }
    }
}
