package com.svb.gateway.migration.report.service;

public enum UserStatusEnum {


    INACTIVE("0"),
    ACTIVE("1"),
    DELETED("2"),
    FROZEN("3");

    private String value;
    UserStatusEnum(String value) {
        this.value = value;
    }
    public static String fromString(String i) {
        for (UserStatusEnum b : UserStatusEnum.values()) {
            if (b.value.equals(i)) {
                return b.name();
            }
        }
        return null;
    }
}
