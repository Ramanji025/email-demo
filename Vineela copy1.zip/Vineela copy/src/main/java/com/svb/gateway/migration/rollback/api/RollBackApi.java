package com.svb.gateway.migration.rollback.api;

import com.fasterxml.jackson.annotation.JsonPropertyDescription;
import com.svb.gateway.migration.common.constants.ErrorMessageConstants;
import com.svb.gateway.migration.common.constants.RegexConstants;
import com.svb.gateway.migration.common.exception.ServiceException;
import com.svb.gateway.migration.rollback.model.RollBackResponse;
import com.svb.gateway.migration.rollback.model.RollBackResponseEntity;
import io.swagger.annotations.*;
import net.bytebuddy.implementation.bind.annotation.Empty;
import org.springframework.context.annotation.Description;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import javax.validation.constraints.Max;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Pattern;
import java.util.List;

/**
 * @author bmourya
 */

@Api(value = "Rollback", tags = "Rollback Controller")
@RequestMapping("/v1/api/")
public interface RollBackApi {

    @ApiOperation(value = "Endpoint for RollBack on Gateway", nickname = "RollBack", notes = "RollBack")
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "RollBack is Successful "),
            @ApiResponse(code = 401, message = "Unauthorized"),
            @ApiResponse(code = 400, message = "Invalid Client Id or Company Id "),
            @ApiResponse(code = 403, message = "Forbidden"),
            @ApiResponse(code = 500, message = "Service unavailable ")})

    @RequestMapping(path = "rollback",
            consumes = {"application/json"}, produces = {"application/json"}, method = RequestMethod.POST)
    @ResponseStatus(HttpStatus.OK)
    @PreAuthorize("hasAuthority(@migrationServiceConfig.getAuthExecute())")
    default ResponseEntity<RollBackResponseEntity> rollback(@RequestBody
                                                          @NotEmpty
                                                            String clientIdString,
                                                            @RequestParam
                                                          @NotEmpty
                                                          @Max(2000) String comments,
                                                            @RequestParam(required = false)
                                                                @ApiParam("Skip Enabling Econnect?- Type TRUE to skip it.")
                                                            String skipEcClientRollback) throws ServiceException {
        return new ResponseEntity<>(HttpStatus.NOT_IMPLEMENTED);
    }
}
