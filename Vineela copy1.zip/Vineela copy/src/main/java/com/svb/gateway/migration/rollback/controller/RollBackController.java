package com.svb.gateway.migration.rollback.controller;

import com.svb.gateway.migration.common.exception.ServiceException;
import com.svb.gateway.migration.common.logging.Message;
import com.svb.gateway.migration.rollback.api.RollBackApi;
import com.svb.gateway.migration.rollback.model.RollBackResponseEntity;
import com.svb.gateway.migration.rollback.service.RollBackService;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;



/**
 * @author psrikanta
 */
@Log4j2
@RestController
public class RollBackController implements RollBackApi {

    private final RollBackService rollBackService;

    @Autowired
    public RollBackController(RollBackService rollBackService) {
        this.rollBackService = rollBackService;
    }

    @Override
    public ResponseEntity<RollBackResponseEntity> rollback(String clientIdString, String comments, String skipEcClientRollback) throws ServiceException {
        Message message= Message.create().descr("Rollback for "+clientIdString+" skipEcClientRollback="+skipEcClientRollback);
        log.info(message);
        String[] clientIds=clientIdString.contains(",")?clientIdString.split(","):clientIdString.split("\n");
        log.info(message.descr("client size "+clientIds.length));
        RollBackResponseEntity rollBackResponseEntity =rollBackService.rollback(clientIds, comments, skipEcClientRollback);
        ResponseEntity<RollBackResponseEntity> responseEntity= new ResponseEntity<>(rollBackResponseEntity, HttpStatus.OK);
        return responseEntity;
    }
}
