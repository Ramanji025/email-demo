package com.svb.gateway.migration.rollback.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.svb.gateway.migration.common.model.Error;
import com.svb.gateway.migration.payments.model.PaymentResponseData;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import javax.validation.constraints.NotEmpty;
import java.util.ArrayList;
import java.util.List;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Getter
@Setter
@ToString
public class RollBackResponse {

    @JsonProperty("jobId")
    private String jobId;

    @JsonProperty("clientId")
    private String clientId;

    @JsonIgnore
    private List<String> success= new ArrayList<>();
    @JsonIgnore
    private List<String> failures= new ArrayList<>();
    @JsonIgnore
    private List<Error> errors = new ArrayList<>();

    @JsonIgnore
    public void addSuccess(String message) {
        success.add(message);
    }
    @JsonIgnore
    public void addFailure(String message) {
        failures.add(message);
    }

    @JsonProperty("Result")
    private String getResult(){
        StringBuilder stringBuilder=new StringBuilder();
        if(!errors.isEmpty()){
            stringBuilder.append("Errors: ").append(errors);
        }
        if(!failures.isEmpty()){
            stringBuilder.append("Failures: ").append(failures);
        }
        if(!success.isEmpty()){
            stringBuilder.append("Success: ").append(success);
        }
        return stringBuilder.toString();
    }
}
