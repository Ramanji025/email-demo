package com.svb.gateway.migration.rollback.model;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.util.List;


@Getter
@Setter
@ToString
public class RollBackResponseEntity {
   private List<RollBackResponse> rollBackResponses;
}
