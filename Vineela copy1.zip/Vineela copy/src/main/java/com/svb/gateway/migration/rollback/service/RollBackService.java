package com.svb.gateway.migration.rollback.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.svb.gateway.migration.alerts.mapper.MigrationAlertsMapper;
import com.svb.gateway.migration.alerts.service.AlertsService;
import com.svb.gateway.migration.beneficiaries.mapper.MigBeneficiaryMapper;
import com.svb.gateway.migration.cards.service.CardsService;
import com.svb.gateway.migration.client.entity.MigClient;
import com.svb.gateway.migration.client.model.DeleteClientResponse;
import com.svb.gateway.migration.client.repository.MigClientRepository;
import com.svb.gateway.migration.client.service.ClientService;
import com.svb.gateway.migration.common.constants.MigrationConstants;
import com.svb.gateway.migration.common.exception.BadRequestException;
import com.svb.gateway.migration.common.exception.ServiceException;
import com.svb.gateway.migration.common.exception.ValidationException;
import com.svb.gateway.migration.common.logging.Message;
import com.svb.gateway.migration.common.model.Error;
import com.svb.gateway.migration.common.utility.CommonValidator;
import com.svb.gateway.migration.common.utility.MigrationErrorCodeEnum;
import com.svb.gateway.migration.ec2stage.service.ECService;
import com.svb.gateway.migration.job.repository.MigJobRepository;
import com.svb.gateway.migration.nickname.service.NicknameService;
import com.svb.gateway.migration.payments.entity.TransactionEntity;
import com.svb.gateway.migration.payments.service.GatewayPaymentService;
import com.svb.gateway.migration.payments.service.StopPaymentService;
import com.svb.gateway.migration.rollback.mapper.RollBackMapper;
import com.svb.gateway.migration.rollback.model.RollBackResponse;
import com.svb.gateway.migration.rollback.model.RollBackResponseEntity;
import com.svb.gateway.migration.user.mapper.UserMapper;
import com.svb.gateway.migration.user.repository.MigUserRepository;
import com.svb.gateway.migration.user.service.UserService;
import lombok.extern.log4j.Log4j2;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import static com.svb.gateway.migration.common.constants.MigrationConstants.*;
import static org.apache.commons.lang3.StringUtils.trim;

/**
 * @author bmourya & psrikanta
 */

/**
 * RollBack Service program
 * <p>
 * The rollback will be implemented for a client Id and a jobId.
 * It should wipe out all the client's data from gateway including the payments, alerts, transfers, etc. 
 * It should change the status of the client in the staging table as rolled back so that we can
 * retry migration for that client.
 */
@Service
@Log4j2
@Transactional("jpaTransactionManager")
public class RollBackService {

    public static final String GATEWAY_CLIENT = "Gateway Client";
    public static final String ECONNECT_ENABLED = "Econnect Enabled";
    public static final String ECONNECT_NOT_ENABLED = "Econnect Not Enabled";
    @Autowired
    MigClientRepository migClientRepository;

    @Autowired
    MigUserRepository migUserRepository;

    @Autowired
    MigJobRepository migJobRepository;

    @Autowired
    GatewayPaymentService gatewayPaymentService;

    @Autowired
    MigBeneficiaryMapper migBeneficiaryMapper;

    @Autowired
    ClientService clientService;

    @Autowired
    AlertsService alertsService;

    @Autowired
    RollBackMapper rollbackMapper;

    @Autowired
    MigrationAlertsMapper migrationAlertsMapper;

    @Autowired
    UserMapper userMapper;

    @Autowired
    UserService userService;

    @Autowired
    NicknameService nicknameService;

    @Autowired
    CardsService cardsService;

    @Autowired
    ECService ecService;

    @Autowired
    StopPaymentService stopPaymentService;

    @Value("${ec.enable.validation}")
    private boolean enableECValidation;

    public RollBackResponseEntity rollback(String[] clientIds, String comments, String skipEcClientRollback) throws ServiceException{
        List<RollBackResponse> rollBackResponseList=new ArrayList<RollBackResponse>();
        Message message=Message.create().descr("Calling rollback for multiple clients "+clientIds);
        log.info(message);
        if(clientIds==null || clientIds.length<1){
            throw new ServiceException("ClientId list is not valid");
        }

        for(String clientId:clientIds){
            rollBackResponseList.add(rollbackClient(trim(clientId), comments, skipEcClientRollback));
        }
        RollBackResponseEntity rollBackResponseEntity=new RollBackResponseEntity();
        rollBackResponseEntity.setRollBackResponses(rollBackResponseList);
        log.info(message.descr("Rollback completed for clients"+rollBackResponseEntity));
        return rollBackResponseEntity;
    }

    private RollBackResponse rollbackClient(String clientId, String comments, String skipEcClientRollback)  {
        RollBackResponse rollbackResponse=new RollBackResponse();
        rollbackResponse.setClientId(clientId);
        try {
            CommonValidator.ecClientIdCheck(clientId);
        } catch (ServiceException e) {
            rollbackResponse.getErrors().add(new Error(clientId,e.getMessage()));
            return rollbackResponse;
        }

        List<MigClient> migrationClients = migClientRepository.findByEcClientIdStatusNotRollback(clientId);

        if (migrationClients == null || migrationClients.isEmpty()) {
            log.info(Message.create().clientId(clientId).descr("No valid Migration entity to roll back "));
            rollbackResponse.getErrors().add(new Error("Client", "No valid Migration entity to roll back")) ;
            return rollbackResponse;

        }

        //As we are rolling back single client.
        MigClient migrationClient=migrationClients.get(0);
        rollbackResponse.setJobId(String.valueOf(migrationClient.getJobId()));

        try {
            validateClient(clientId, migrationClient);
            migrationClient.setComments(comments);
            rollbackClient(rollbackResponse, migrationClient);
            enableEcClient(clientId, rollbackResponse, skipEcClientRollback);
            rollbackPayments(clientId, rollbackResponse);
            stopPaymentService.rollback(clientId,migrationClient.getGwClientId(),rollbackResponse);
            alertsService.rollBackAlerts(clientId, migrationClient.getGwClientId(), rollbackResponse);
            nicknameService.rollback(clientId, rollbackResponse);
            userService.rollbackCardUserId(clientId, rollbackResponse);
            cardsService.rollbackCardProgram(clientId, rollbackResponse);
            userMapper.rollback(clientId);
            migBeneficiaryMapper.rollbackByEcClientId(clientId);
        } catch (ValidationException validationException) {
            log.error(Message.create().clientId(clientId).descr(validationException.getMessage()).toString());
            rollbackResponse.getErrors().add(new Error(clientId, validationException.getMessage()));
            enableEcClient(clientId, rollbackResponse, skipEcClientRollback);
        } catch (Exception e) {
            log.error(Message.create().clientId(clientId).descr(e.getMessage()).toString());
            processException(clientId, rollbackResponse, migrationClient, e);
            rollbackResponse.getErrors().add(new Error(clientId, e.getMessage()));
            return rollbackResponse;
        }
        return rollbackResponse;
    }

    private void enableEcClient(String clientId, RollBackResponse rollbackResponse, String skipEcClientRollback) {
        Message logMessage = Message.create().clientId(clientId);
        if ("TRUE".equalsIgnoreCase(skipEcClientRollback)) {
            log.info(logMessage.descr("Skipped Econnect enablement as requested " + skipEcClientRollback));
            rollbackResponse.addSuccess("**Econnect SKIPPED rolledback** " + skipEcClientRollback);
            return;
        }
        List<String> cliendIds = new ArrayList<>();
        cliendIds.add(clientId);
        try {
            String ecResponse = null;
            if (!enableECValidation) {
                log.warn(Message.create().descr("EC Validation Not Enabled").operation(ROLLBACK_INITIATED));
            } else {
                ecResponse = ecService.updateClientDetailsEc(cliendIds, "Y", "Y");

            }

            if (STATUS_SUCCESS.equalsIgnoreCase(ecResponse)) {
                log.info(logMessage.descr(ECONNECT_ENABLED));
                rollbackResponse.addSuccess(ECONNECT_ENABLED);
            } else {
                log.info(logMessage.descr(" " + ECONNECT_NOT_ENABLED + " due to " + ecResponse));
                rollbackResponse.addFailure(ECONNECT_NOT_ENABLED + " due to " + ecResponse);
            }
        } catch (ServiceException | JsonProcessingException e) {
            log.info(logMessage.descr(" Econnect enable exception " + e.getMessage()));
            rollbackResponse.addFailure(ECONNECT_NOT_ENABLED + e.getMessage());
        }
    }

        private RollBackResponse processException(String clientId, RollBackResponse rollbackResponse, MigClient migrationClient, Exception e) {
        Message logMessage=Message.create().clientId(clientId).descr("Exception occurred for Rollback for client due to "+ e.getMessage());
        if(migrationClient!=null){
            logMessage.jobId(migrationClient.getJobId());
        }
        log.error(logMessage);
        rollbackResponse.getErrors().add(new Error(clientId,  MigrationConstants.STATUS_FAILURE +" "+ e.getMessage()));
        return rollbackResponse;
    }



    private boolean rollbackClient(RollBackResponse rollbackResponse, MigClient migrationClient) throws ServiceException {
        DeleteClientResponse deleteClientResponse = clientService.inactiveAndDeleteClient(migrationClient.getGwClientId(), migrationClient.getComments());

        if (!MigrationConstants.STATUS_SUCCESS.equalsIgnoreCase(deleteClientResponse.getStatus())) {
            rollbackResponse.addFailure(GATEWAY_CLIENT);
            return false;
        } else {
            rollbackResponse.addSuccess(GATEWAY_CLIENT);
        }
        return true;
    }

    private void validateClient(String clientId, MigClient migrationClient) throws ServiceException  {
        Message message=Message.create().clientId(clientId);

        message.jobId(migrationClient.getJobId());

        if(jobInProgress(migrationClient.getJobId())){
            log.info(message.descr("The job of the client is still in progress, cannot rollback now. Try again later"));
            throw new ServiceException(message.toString());
        }

        if (StringUtils.isBlank(migrationClient.getGwClientId())) {
            migrationClient.setStatus(STATUS_ROLLED_BACK);
            migClientRepository.save(migrationClient);
            log.info(message.descr(MigrationConstants.NO_GATEWAY_CLIENT_AVAILABLE));
            throw new ValidationException(MigrationConstants.NO_GATEWAY_CLIENT_AVAILABLE);
        }

        int numEmailsSent = migUserRepository.welcomeEmailsSent(clientId);
        if (numEmailsSent>0) {
            String emailSentMessage = numEmailsSent+" welcome emails were already sent to users of this client " + clientId;
            log.warn(message.clientId(clientId).descr(emailSentMessage));
            throw new BadRequestException(MigrationErrorCodeEnum.MIGRATION_ROLLBACK_WELCOME_EMAIL_ALREADY_SENT, emailSentMessage);
        }
    }

    private boolean jobInProgress(Long jobId) {
        return migJobRepository.findByJobMigrationInProgress(jobId)!=null;
    }

    private boolean rollbackPayments(String clientId, RollBackResponse rollbackResponse) {

        try {
            // Internal Transfer (MIG_INT_TRANSFERS)
            List<TransactionEntity> internalTransfers = rollbackMapper.getTransfers(clientId, MigrationConstants.INTERNAL_TRANSFERS_TABLE_NAME);
            if (!internalTransfers.isEmpty()) {

                rollbackMapper.updateTransferStatus(internalTransfers.stream().map(TransactionEntity::getEC_TXN_ID).collect(Collectors.toList()),
                        STATUS_ROLLED_BACK, MigrationConstants.INTERNAL_TRANSFERS_TABLE_NAME);
                rollbackResponse.addSuccess("Internal transfers:"+internalTransfers.size());
            } else {
                rollbackResponse.addSuccess("No Internal transfers available for rollback");
            }


            // Wire Transfer
            List<TransactionEntity> wireTransfers = rollbackMapper.getTransfers(clientId, MigrationConstants.WIRE_TRANSFERS_TABLE_NAME);
            if (!wireTransfers.isEmpty()) {

                rollbackMapper.updateTransferStatus(wireTransfers.stream().map(TransactionEntity::getEC_TXN_ID).collect(Collectors.toList()),
                        STATUS_ROLLED_BACK, MigrationConstants.WIRE_TRANSFERS_TABLE_NAME);
                rollbackResponse.addSuccess("Wire transfer:"+wireTransfers.size());
            } else {
                rollbackResponse.addSuccess("No wire transfers available for rollback");
            }


            // Ipay Payments
            List<TransactionEntity> ipayPayments = rollbackMapper.getPayments(clientId);
            if (!ipayPayments.isEmpty()) {

                rollbackMapper.updatePayments(ipayPayments.stream().map(t -> Integer.parseInt(t.getPAYMENT_ID())).collect(Collectors.toList()),
                        STATUS_ROLLED_BACK);
                rollbackResponse.addSuccess("Ipay payments:"+ipayPayments.size());
            } else {
                rollbackResponse.addSuccess("No Ipay Payments available for rollback");
            }

        } catch (Exception e) {
            rollbackResponse.getErrors().add(new Error(clientId, "Rollback Payments Failed"));
            return false;
        }
        return true;
    }

}
