package com.svb.gateway.migration.user.api;

import com.opencsv.exceptions.CsvException;
import com.svb.gateway.migration.common.exception.ServiceException;
import com.svb.gateway.migration.user.model.ListOfClientsResponse;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;

@Api(value = "Notification", tags = "Notification Controller")
@RequestMapping("/v1/api/notification")
public interface NotificationApi {

    @ApiOperation(value = "Endpoint for Sending a notification to the users migrated in Gateway", nickname = "notification", notes = "Send Notification")
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Send Notification Successful "),
            @ApiResponse(code = 401, message = "Unauthorized"),
            @ApiResponse(code = 400, message = "Invalid Client Id "),
            @ApiResponse(code = 403, message = "Forbidden"),
            @ApiResponse(code = 500, message = "Service unavailable ")})
    @RequestMapping(value = "/email/{jobId}/{clientId}",
            produces = MediaType.ALL_VALUE,
            consumes = MediaType.ALL_VALUE,
            method = RequestMethod.POST)
    @ResponseStatus(HttpStatus.OK)
    @PreAuthorize("hasAuthority(@migrationServiceConfig.getAuthExecute())")
    ResponseEntity<?> sendNotification(@PathVariable Integer jobId, @PathVariable String clientId) throws ServiceException;

    @ApiOperation(value = "Endpoint for Sending Bulk notification to the users migrated in Gateway", nickname = "notification", notes = "Send Bulk Notification")
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Send Notification Successful "),
            @ApiResponse(code = 401, message = "Unauthorized"),
            @ApiResponse(code = 400, message = "Invalid Client Id "),
            @ApiResponse(code = 403, message = "Forbidden"),
            @ApiResponse(code = 500, message = "Service unavailable ")})
    @RequestMapping(value = "/email/bulk",
            produces = MediaType.ALL_VALUE,
            consumes = MediaType.ALL_VALUE,
            method = RequestMethod.POST)
    @ResponseStatus(HttpStatus.OK)
    @PreAuthorize("hasAuthority(@migrationServiceConfig.getAuthExecute())")
    ResponseEntity<?> sendBulkNotification(@RequestPart(value = "file", required = true) MultipartFile files) throws ServiceException, IOException, CsvException;


    @ApiOperation(value = "Endpoint for Sending Bulk notification to all clientusers migrated in Gateway", nickname = "notification", notes = "Trigger Bulk Notification")
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Send Notification Successful"),
            @ApiResponse(code = 401, message = "Unauthorized"),
            @ApiResponse(code = 400, message = "Inavalid Job Id"),
            @ApiResponse(code = 403, message = "Forbidden"),
            @ApiResponse(code = 500, message = "Service unavailable")})
    @RequestMapping(value = "/email/{jobId}",
            produces = MediaType.ALL_VALUE,
            consumes = MediaType.ALL_VALUE,
            method = RequestMethod.POST)
    @ResponseStatus(HttpStatus.OK)
    @PreAuthorize("hasAuthority(@migrationServiceConfig.getAuthExecute())")
    ResponseEntity<?> sendBulkNotificationByJobId(@PathVariable("jobId") Integer jobId) throws ServiceException, IOException, CsvException;

    @ApiOperation(value = "Endpoint for getting a list of successful clients in Gateway", nickname = "notification", notes = "Get list of clients")
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Fetch Client Successful "),
            @ApiResponse(code = 401, message = "Unauthorized"),
            @ApiResponse(code = 500, message = "Service unavailable ")})
    @RequestMapping(value = "/email/{jobId}/{status}",
            produces = MediaType.APPLICATION_JSON_VALUE,
            consumes = MediaType.ALL_VALUE,
            method = RequestMethod.GET)
    @ResponseStatus(HttpStatus.OK)
    @PreAuthorize("hasAuthority(@migrationServiceConfig.getAuthExecute())")
    ResponseEntity<ListOfClientsResponse> getListOfClients(@PathVariable Integer jobId, @PathVariable String status) throws ServiceException;
    }