package com.svb.gateway.migration.user.api;

import com.svb.gateway.migration.common.exception.ServiceException;
import com.svb.gateway.migration.user.model.AddUserResponse;
import com.svb.gateway.migration.user.model.CardUserResponse;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.concurrent.ExecutionException;

@Api(value = "api/User")
@RequestMapping("migration/api/user")
public interface UserApi {

    @ApiOperation(value = "Endpoint for Add user and primary user on Gateway", nickname = "addUser", notes = "Add Users")
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Add User is Successful "),
            @ApiResponse(code = 401, message = "Unauthorized"),
            @ApiResponse(code = 400, message = "Invalid User ID or Company Id "),
            @ApiResponse(code = 403, message = "Forbidden"),
            @ApiResponse(code = 500, message = "Service unavailable ")})
    @PostMapping(value = "/addUser",
            produces = {"application/json"},
            consumes = {"application/json"})
    @ResponseStatus(HttpStatus.OK)
    @PreAuthorize("hasAuthority(@migrationServiceConfig.getAuthExecute())")
    default ResponseEntity<AddUserResponse> addUser(@PathVariable Long jobId,
                                                    @PathVariable String migratingClientId) throws ServiceException, ExecutionException, InterruptedException {
        return new ResponseEntity<>(HttpStatus.NOT_IMPLEMENTED);
    }

    @ApiOperation(value = "Endpoint for card user update on Gateway", nickname = "updateCardUser", notes = "Update Card Users")
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Add Card User is Successful "),
            @ApiResponse(code = 401, message = "Unauthorized"),
            @ApiResponse(code = 400, message = "Invalid User ID or Company Id "),
            @ApiResponse(code = 403, message = "Forbidden"),
            @ApiResponse(code = 500, message = "Service unavailable ")})
    @ResponseStatus(HttpStatus.OK)
    @PreAuthorize("hasAuthority(@migrationServiceConfig.getAuthExecute())")
    @PostMapping(value = "/card/{jobId}/{ecClientId}", produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.ALL_VALUE)
    ResponseEntity<CardUserResponse> updateCards(@PathVariable Long jobId, @PathVariable String ecClientId) throws ServiceException;

}
