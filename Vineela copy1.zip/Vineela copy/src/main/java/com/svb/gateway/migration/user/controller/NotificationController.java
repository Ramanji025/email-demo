package com.svb.gateway.migration.user.controller;

import com.opencsv.exceptions.CsvException;
import com.svb.gateway.migration.client.entity.MigClient;
import com.svb.gateway.migration.client.repository.MigClientRepository;
import com.svb.gateway.migration.common.constants.MigrationConstants;
import com.svb.gateway.migration.common.exception.ServiceException;
import com.svb.gateway.migration.common.logging.Message;
import com.svb.gateway.migration.common.utility.CSVUtilities;
import com.svb.gateway.migration.common.utility.CommonValidator;
import com.svb.gateway.migration.user.api.NotificationApi;
import com.svb.gateway.migration.user.model.ListOfClientsResponse;
import com.svb.gateway.migration.user.service.NotificationService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.*;

@RestController
@Slf4j
public class NotificationController implements NotificationApi {

    @Autowired
    private NotificationService notificationService;
    @Autowired
    private MigClientRepository clientRepository;

    @Override
    public ResponseEntity<?> sendNotification(Integer jobId, String clientId) throws ServiceException {
        CommonValidator.ecClientIdCheck(clientId);
        if(Objects.isNull(jobId) || jobId == 0) {
            throw new ServiceException(HttpStatus.BAD_REQUEST.name(), "Invalid Job Id");
        }
        notificationService.sendEmailNotification(clientId, jobId);
        return ResponseEntity.accepted().body(MigrationConstants.EMAIL_REQUEST_ACCEPTED);
    }

    @Override
    @ResponseBody
    public ResponseEntity<?> sendBulkNotification(MultipartFile file) throws ServiceException, IOException, CsvException {

        var logMessage = Message.create().descr("send bulk notification").summary();
        List<String> migClientIds = CSVUtilities.parseSingleColumnCSV(file);
        List<MigClient> clientIds = notificationService.getAllClientsByStatus(migClientIds);
        clientIds.forEach(client -> {
            try {
                notificationService.sendEmailNotification(client.getEcClientId(), Integer.parseInt(client.getJobId().toString()));
            } catch (ServiceException e) {
                log.error(logMessage.jobId(client.getJobId()).clientId(client.getEcClientId()).descr(e.getMessage()).summary().toString());
            }
        });
        logMessage.descr("sending bulk email notification completed").summary();
        return ResponseEntity.accepted().body("Sending Bulk emails accepted");
    }

    @Override
    public ResponseEntity<?> sendBulkNotificationByJobId(Integer jobId) {
        int count = notificationService.sendEmailNotificationByJobId(jobId);
        return ResponseEntity.accepted().body("Sending Emails using jobId accepted. Clients Count - "+count);
    }

    @Override
    public ResponseEntity<ListOfClientsResponse> getListOfClients(Integer jobId, String status) throws ServiceException {

        if (StringUtils.isBlank(status)) {
            throw new ServiceException(HttpStatus.BAD_REQUEST.name(), "Invalid Status");
        }
        if(Objects.isNull(jobId) || jobId == 0) {
            throw new ServiceException(HttpStatus.BAD_REQUEST.name(), "Invalid Job Id");
        }

        return  new ResponseEntity<>( notificationService.getListOfClients(jobId, status), HttpStatus.OK);
    }
}
