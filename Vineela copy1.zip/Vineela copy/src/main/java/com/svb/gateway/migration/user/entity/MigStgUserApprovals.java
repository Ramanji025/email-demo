package com.svb.gateway.migration.user.entity;


import lombok.Data;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import javax.persistence.*;
import java.sql.Date;
import static com.svb.gateway.migration.common.constants.UserConstants.NO;
import static com.svb.gateway.migration.common.constants.UserConstants.YES;

@Setter
@Getter
@ToString
@Entity
@Table(name = "MIG_STG_USER_APPROVALS")
@Data
public class MigStgUserApprovals {

    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(name = "ID")
    private Integer id;

    @Column(name = "EC_USER_ID")
    private String ecUserId;

    @Column(name = "EC_CLIENT_ID")
    private String ecClientId;

    @Column(name = "IPAY_DUAL_AUTHENTICATION")
    private String iPayDualAuthentication;

    @Column(name = "IPAY_APPROVAL_REQUIRED")
    private String iPayApprovalRequired;

    @Column(name = "ACCOUNT_NUMBER")
    private String accountNumber;

    @Column(name = "EC_USER_ROLE")
    private String ecUserRole;

    @Column(name = "STOP_PAYMENTS")
    private String stopPayments;

    @Column(name = "INITIATE_FREEFORM_WIRE")
    private String initiateFreedomWire;

    @Column(name = "INITIATE_TEMPLATE_WIRE")
    private String initiateTemplateWire;

    @Column(name = "FREEFORM_WIRE_APPROVAL1")
    private String freeFormWireApproval1;

    @Column(name = "FREEFORM_WIRE_APPROVAL2")
    private String freeFormWireApproval2;

    @Column(name = "VIEW_WIRE_PAYMENT")
    private String viewWirePayment;

    @Column(name = "CREATE_MODIFY_TEMPLATE")
    private String createModifyTemplate;

    @Column(name = "APPROVE_TEMPLATE")
    private String approveTemplate;

    @Column(name = "TEMPLATE_WIRE_APPROVAL1")
    private String templateWireApproval1;

    @Column(name = "TEMPLATE_WIRE_APPROVAL2")
    private String templateWireApproval2;

    @Column(name = "JOB_ID")
    private Integer jobId;

    @Column(name = "REMARKS")
    private String remarks;

    @Column(name = "CREATED_BY")
    private String createdBy;

    @Column(name = "CREATED_TIMESTAMP")
    private Date createdTimestamp;

    @Column(name = "MODIFIED_TIMESTAMP")
    private Date modifiedTimestamp;

    public String getEcInitiateEntitlement(){
        return YES.equalsIgnoreCase(createModifyTemplate) ||
                YES.equalsIgnoreCase(stopPayments) ||
                YES.equalsIgnoreCase(initiateFreedomWire) ||
                YES.equalsIgnoreCase(initiateTemplateWire) ? YES:NO;
    }

    public String getEcViewEntitlement(){
        return YES.equalsIgnoreCase(viewWirePayment)?YES:NO;
    }

    public String getEcApproveEntitlement(){
        return YES.equalsIgnoreCase(freeFormWireApproval1)
                || YES.equalsIgnoreCase(freeFormWireApproval2)
                || YES.equalsIgnoreCase(templateWireApproval1)
                || YES.equalsIgnoreCase(templateWireApproval2)
                || YES.equalsIgnoreCase(approveTemplate)?YES:NO;
    }

    public String getIpayApproveEntitlement(){
        return YES.equalsIgnoreCase(iPayDualAuthentication) || YES.equalsIgnoreCase(iPayApprovalRequired)?YES:NO;
    }
}
