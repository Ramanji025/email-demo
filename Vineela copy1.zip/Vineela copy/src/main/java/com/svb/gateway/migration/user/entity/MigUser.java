package com.svb.gateway.migration.user.entity;

import com.svb.gateway.migration.common.processors.IRetry;
import lombok.*;

import javax.persistence.*;
import java.util.Date;

import static com.svb.gateway.migration.common.constants.UserConstants.NO;
import static com.svb.gateway.migration.common.constants.UserConstants.YES;

@AllArgsConstructor
@NoArgsConstructor
@ToString
@Setter
@Getter
@Entity
@Table(name = "MIG_USER")
public class MigUser implements IRetry {

    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(name = "MIGUSERID")
    private Integer migUserId;

    @Column(name = "JOBID")
    private Long jobId;

    @Column(name = "ECCLIENTID")
    private String ecClientId;

    @Column(name = "GWCLIENTID")
    private String gwClientId;

    @Column(name = "ECUSERLOGINID")
    private String ecUserLoginId;

    @Column(name = "GWUUID")
    private String gwUuid;

    @Column(name = "FIRSTNAME")
    private String firstName;

    @Column(name = "LASTNAME")
    private String lastName;

    @Column(name = "MOBILENUMBER")
    private String mobileNumber;

    @Column(name = "EMILID")
    private String emailId;

    @Column(name = "COMMENTS")
    private String comments;

    @Column(name = "STATUS")
    private String status;

    @Column(name = "UPDATEDBY")
    private String updateBy;

    @Column(name = "UPDATEDDATE")
    private Date updateDate;

    @Column(name = "CREATEDBY" , insertable = false)
    private String createBy;

    @Column(name = "CREATEDDATE" , insertable = false)
    private Date createDate;

    @Column(name = "EMAIL_FLAG")
    private String emailFlag;

    @Column(name = "CARD_HOLDER_TYPE")
    private String cardHolderType;

    @Column(name = "BDCSTATUS")
    private Integer bdcStatus;

    @Column(name = "RDMSTATUS")
    private Integer rdmStatus;

    @Column(name = "ISPRIMARYUSER")
    private Integer isPrimaryUser;

    @Column(name = "TYPE_OF_USER")
    private String typeOfUser;

    @Column(name = "ROLE")
    private String userRole;

    @Column(name = "USER_ACCESS")
    private String userAccess;

    @Column(name = "APPROVER")
    private String isApprover;

    @Column(name= "EC_CLIENT_ID_NUM")
    private String ecClientIdNum;

    @Column(name= "EC_USER_ID_NUM")
    private String ecUserIdNum;

    @Column(name = "USER_STATUS")
    private String userStatus;

    public String bdcStatusAsString(){
        return determineStatusString(bdcStatus);
    }

    public String rdmStatusAsString(){
        return determineStatusString(rdmStatus);
    }

    public static String determineStatusString(Integer status){
        if(status==null || 0==status){
            return NO;
        }else{
            return YES;
        }
    }
}
