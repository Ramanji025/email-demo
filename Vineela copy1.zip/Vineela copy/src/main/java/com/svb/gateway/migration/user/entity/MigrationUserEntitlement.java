package com.svb.gateway.migration.user.entity;

import com.svb.gateway.migration.common.constants.UserConstants;
import lombok.*;

import javax.persistence.*;
import java.sql.Timestamp;

import static com.svb.gateway.migration.common.constants.MigrationConstants.*;
import static com.svb.gateway.migration.common.constants.UserConstants.*;

@NoArgsConstructor
@ToString
@Setter
@Getter
@Entity
@Table(name = "MIG_INT_USER_ENTITLEMENTS")
public class MigrationUserEntitlement {

    public MigrationUserEntitlement(String userId){
        this.userId=userId;
    }
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(name = "ID")
    private Long id;

    @Column(name = "EC_USER_ID")
    private String userId;

    @Column(name = "JOB_ID")
    private Long jobId;

    @Column(name = "CLIENT_ID")
    private String clientId;

    @Column(name = "MODIFIED_TIMESTAMP")
    private Timestamp modifiedTimestamp;

    @Column(name = "CREATED_BY" , insertable = false)
    private String createdBy;

    @Column(name = "CREATED_TIMESTAMP" , insertable = false)
    private Timestamp createdTimestamp;

    @Column(name = "EC_APPROVE_ENTITLEMENT")
    private String eConnectApproveEntitlement;

    @Column(name = "EC_INITIATE_ENTITLEMENT")
    private String eConnectInitiateEntitlement;

    @Column(name = "EC_VIEW_ENTITLEMENTS")
    private String eConnectViewEntitlement;

    @Column(name = "IPAY_APPROVE_ENTITLEMENT")
    private String ipayApproveEntitlement;

    //"PRIMARY_ADMIN", "ADDITIONAL_ADMIN", "NORMAL_USER"
    @Column(name = "EC_USER_ROLE")
    private String eConnectUserRole;

    public String getGWUserAccess(){
        String userAccess=VIEW_ONLY;
        if(UserConstants.PRIMARY_ADMIN.equalsIgnoreCase(eConnectUserRole)){
            userAccess=FULL_ACCESS;
        }else if(viewEntitlement() && initiateEntitlement() && approveEConnectEntitlement() && approveIpayEntitlement()){
            userAccess= FULL_ACCESS;
        }else if(initiateEntitlement()){
            userAccess= TRANSACT;
        }
        return userAccess;
    }

    public String isGWApprover(){
        String approver=N_FLAG;
        if( approveEConnectEntitlement() || approveIpayEntitlement()){
            approver=Y_FLAG;
        }
        return approver;
    }

    public String getGWUserRole(){
        return FULL_ACCESS.equals(getGWUserAccess())?ADMIN:ROLE_USER;
    }

    private boolean approveEConnectEntitlement(){
        return YES.equalsIgnoreCase(eConnectApproveEntitlement);
    }

    private boolean approveIpayEntitlement(){
        return YES.equalsIgnoreCase(ipayApproveEntitlement);
    }

    private boolean initiateEntitlement(){
        return YES.equalsIgnoreCase(eConnectInitiateEntitlement);
    }

    private boolean viewEntitlement(){
        return YES.equalsIgnoreCase(eConnectInitiateEntitlement);
    }

    public MigrationUserEntitlement(Long jobId,String clientId,String userId){
        this.jobId=jobId;
        this.userId=userId;
        this.clientId=clientId;
        this.eConnectUserRole=ROLE_USER;
        this.eConnectViewEntitlement=YES;
        this.eConnectApproveEntitlement=NO;
        this.eConnectInitiateEntitlement=NO;
        this.ipayApproveEntitlement=NO;
    }
}
