package com.svb.gateway.migration.user.mapper;

import com.svb.gateway.migration.common.constants.MigrationConstants;
import com.svb.gateway.migration.user.entity.MigUser;
import org.apache.ibatis.annotations.*;
import org.springframework.stereotype.Repository;

import java.util.List;

@Mapper
@Repository
public interface UserMapper {

    @Insert(value = {
            "INSERT INTO", "MIG_USER", "(JOBID, ECCLIENTID, GWCLIENTID, ECUSERLOGINID,  GWUUID, FIRSTNAME, LASTNAME, MOBILENUMBER, EMILID, COMMENTS, STATUS, EMAIL_FLAG, CARD_HOLDER_TYPE, BDCSTATUS, ISPRIMARYUSER, TYPE_OF_USER)",
            "VALUES",
            "(#{jobId}, #{ecClientId}, #{gwClientId,jdbcType=VARCHAR}, #{ecUserLoginId},#{gwUuid,jdbcType=VARCHAR}, #{firstName}, #{lastName}, #{mobileNumber}, #{emailId}, #{comments}, #{status}, #{emailFlag}, #{cardHolderType}, #{bdcStatus}, #{isPrimaryUser}, #{typeOfUser})"
    })

    @Options(useGeneratedKeys = true, keyProperty = "migUserId", keyColumn = "MIGUSERID")
    Integer insertMigratingUser(MigUser migUser);

    @Update(value = "UPDATE GWDMG.MIG_USER SET EMAIL_FLAG = #{emailFlag},  UPDATEDBY='SVB.svc.migration', UPDATEDDATE=systimestamp WHERE MIGUSERID= #{migUserId}")
    void updateUserStatus(MigUser migUser);

    @Update(value = "UPDATE MIG_USER SET status='" + MigrationConstants.STATUS_ROLLED_BACK + "', UPDATEDBY='SVB.svc.migration', UPDATEDDATE=systimestamp WHERE ECCLIENTID=#{clientId} ")
    void rollback(@Param("clientId") String clientId);

    @Select(value = {"SELECT", "MIGUSERID,JOBID,ECCLIENTID,GWCLIENTID,GWUUID,ECUSERLOGINID,FIRSTNAME,LASTNAME,MOBILENUMBER,EMILID,COMMENTS,STATUS,ISPRIMARYUSER,TYPE_OF_USER,BDCSTATUS,CARD_HOLDER_TYPE, EMAIL_FLAG,UPDATEDDATE,UPDATEDBY", "FROM", "MIG_USER", "WHERE", " JOBID = #{jobId} AND  ECUSERLOGINID = #{ecUserLoginId} "})
    List<MigUser> findByJobIdAndEcUserLoginId(@Param("jobId") Long jobId, @Param("ecUserLoginId") String ecUserLoginId);

    @Update(value = "update MIG_USER set ECCLIENTID=#{ecClientId}, GWCLIENTID=#{gwClientId,jdbcType=VARCHAR}, " +
            " GWUUID=#{gwUuid,jdbcType=VARCHAR}, FIRSTNAME=#{firstName}, LASTNAME=#{lastName}, MOBILENUMBER=#{mobileNumber}, EMILID=#{emailId}, COMMENTS=#{comments}," +
            " STATUS =#{status}, UPDATEDBY ='SVB.svc.migration', UPDATEDDATE=systimestamp,  EMAIL_FLAG=#{emailFlag}, CARD_HOLDER_TYPE=#{cardHolderType}," +
            " BDCSTATUS=#{bdcStatus}, ISPRIMARYUSER=#{isPrimaryUser}, TYPE_OF_USER= #{typeOfUser} where JOBID=#{jobId} and ECUSERLOGINID=#{ecUserLoginId}")
    void updateUser(MigUser entity);
}
