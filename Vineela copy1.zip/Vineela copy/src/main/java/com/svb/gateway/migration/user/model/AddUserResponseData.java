package com.svb.gateway.migration.user.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.svb.gateway.migration.user.entity.MigUser;
import io.swagger.annotations.ApiModelProperty;

import javax.validation.constraints.NotNull;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class AddUserResponseData {

    @JsonProperty("GWClientId")
    private String gwClientId;

    @JsonProperty("ClientLoginId")
    private String clientLoginId;

    @JsonProperty("Status")
    private String status;

    @JsonProperty("GWPrimaryUserId")
    private String gwPrimaryUserId;

    @JsonProperty("AdditionalUsers")
    private List<ResponseUser> additionalUsers;

    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    public String getGwClientId() {
        return gwClientId;
    }

    public void setGwClientId(String gwClientId) {
        this.gwClientId = gwClientId;
    }

    public AddUserResponseData status (String status) {
        this.status = status;
        return this;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Map<String, Object> getAdditionalProperties() {
        return additionalProperties;
    }

    public void setAdditionalProperties(Map<String, Object> additionalProperties) {
        this.additionalProperties = additionalProperties;
    }

    public String getClientLoginId() {
        return clientLoginId;
    }

    public void setClientLoginId(String clientLoginId) {
        this.clientLoginId = clientLoginId;
    }

    public AddUserResponseData gwPrimaryUserId (String status) {
        this.status = status;
        return this;
    }

    @ApiModelProperty(required = true, value = ".")
    @NotNull
    public String getGwPrimaryUserId() {
        return gwPrimaryUserId;
    }

    public void setGwPrimaryUserId(String gwPrimaryUserId) {
        this.gwPrimaryUserId = gwPrimaryUserId;
    }

    public List<ResponseUser> getAdditionalUsers() {
        return additionalUsers;
    }

    public void setAdditionalUsers(List<ResponseUser> additionalUsers) {
        this.additionalUsers = additionalUsers;
    }
}

