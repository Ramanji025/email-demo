package com.svb.gateway.migration.user.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import lombok.Data;

import java.util.List;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "oldClientId",
        "oldUserId",
        "newClientId",
        "newUserId",
        "programs",
        "requestId"
})
@Data
public class CardUserRequest {

    @JsonProperty("oldClientId")
    private String oldClientId;

    @JsonProperty("oldUserId")
    private String oldUserId;

    @JsonProperty("newClientId")
    private String newClientId;

    @JsonProperty("newUserId")
    private String newUserId;

    @JsonProperty("programs")
    private List<String> programs;

    @JsonProperty("requestId")
    private String requestId;

}
