package com.svb.gateway.migration.user.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class CardUserResponse implements Serializable {

    private String requestID;
    private String migrationStatus;
    private String rollbackStatus;
}
