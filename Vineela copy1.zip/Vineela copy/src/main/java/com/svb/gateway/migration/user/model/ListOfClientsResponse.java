package com.svb.gateway.migration.user.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ListOfClientsResponse{

    public List<String> getEcClientIdList() {
        return ecClientIdList;
    }

    public void setEcClientIdList(List<String> ecClientIdList) {
        this.ecClientIdList = ecClientIdList;
    }

    private List<String> ecClientIdList;

}
