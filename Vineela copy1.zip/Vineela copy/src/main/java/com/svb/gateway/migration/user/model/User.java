package com.svb.gateway.migration.user.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.svb.gateway.migration.client.model.Partner;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "userLoginId",
        "userFname",
        "userLname",
        "salutation",
        "userEmail",
        "contactPhNumber",
        "userAccess",
        "ecUserId",
        "userRole",
        "userAccountService",
        "idStoreuserkey",
        "isApprover",
        "isPrimaryContact",
        "userService",
        "contactCountryCode",
        "contactLabel",
        "contactXtn",
        "signerFlag",
        "phoneType",
        "userStatus",
        "userLastLoginTime",
        "partners",
        "userOldStatus",
        "registeredCard",
        "ecClientIdNum",
        "ecUserIdNum"
})
public class User {

    @JsonProperty("userLoginId")
    private String userLoginId;
    @JsonProperty("userFname")
    private String userFname;
    @JsonProperty("userLname")
    private String userLname;
    @JsonProperty("salutation")
    private String salutation;
    @JsonProperty("userEmail")
    private String userEmail;
    @JsonProperty("contactPhNumber")
    private String primaryPhNumber;
    @JsonProperty("userAccess")
    private String userAccess;
    @JsonProperty("ecUserId")
    private String ecUserId;
    @JsonProperty("userRole")
    private String userRole;
    @JsonProperty("userAccountService")
    private List<UserAccountService> userAccountService = null;
    @JsonProperty("idStoreuserkey")
    private String idStoreuserkey;
    @JsonProperty("userService")
    private List<UserService> userService;
    @JsonProperty("contactLabel")
    private String contactLabel;
    @JsonProperty("contactCountryCode")
    private String contactCountryCode;
    @JsonProperty("contactXtn")
    private String contactExtension;
    @JsonProperty("signerFlag")
    private String signer;
    @JsonProperty("phoneType")
    private String phoneType;
    @JsonProperty("userstatus")
    private String userStatus;
    @JsonProperty("userLastLoginTime")
    private String userLastLoginTime;
    @JsonProperty("faxNumber")
    private String faxNumber;
    @JsonProperty("partners")
    private List<Partner> partners;
    @JsonProperty("userOldStatus")
    private String userOldStatus;
    @JsonProperty("cardRegistrationStatus")
    private String cardRegistrationStatus;
    @JsonProperty("migratedClient")
    private String migrationFlag;
    @JsonProperty("isPrimaryContact")
    private String isPrimaryContact;
    @JsonProperty("isApprover")
    private String isApprover;
    @JsonProperty("ecClientIdNum")
    private String ecClientIdNum;
    @JsonProperty("ecUserIdNum")
    private String ecUserIdNum;

    public String getUserLastLoginTime() {
        return userLastLoginTime;
    }

    public void setUserLastLoginTime(String userLastLoginTime) {
        this.userLastLoginTime = userLastLoginTime;
    }

    @JsonProperty("userLoginId")
    public String getUserLoginId() {
        return userLoginId;
    }

    @JsonProperty("userLoginId")
    public void setUserLoginId(String userLoginId) {
        this.userLoginId = userLoginId;
    }

    @JsonProperty("userFname")
    public String getUserFname() {
        return userFname;
    }

    @JsonProperty("userFname")
    public void setUserFname(String userFname) {
        this.userFname = userFname;
    }

    @JsonProperty("userLname")
    public String getUserLname() {
        return userLname;
    }

    @JsonProperty("userLname")
    public void setUserLname(String userLname) {
        this.userLname = userLname;
    }

    @JsonProperty("salutation")
    public String getSalutation() {
        return salutation;
    }

    @JsonProperty("salutation")
    public void setSalutation(String salutation) {
        this.salutation = salutation;
    }

    @JsonProperty("userEmail")
    public String getUserEmail() {
        return userEmail;
    }

    @JsonProperty("userEmail")
    public void setUserEmail(String userEmail) {
        this.userEmail = userEmail;
    }

    @JsonProperty("contactPhNumber")
    public String getPrimaryPhNumber() {
        return primaryPhNumber;
    }

    @JsonProperty("contactPhNumber")
    public void setPrimaryPhNumber(String primaryPhNumber) {
        this.primaryPhNumber = primaryPhNumber;
    }

    @JsonProperty("userAccess")
    public String getUserAccess() {
        return userAccess;
    }

    @JsonProperty("userAccess")
    public void setUserAccess(String userAccess) {
        this.userAccess = userAccess;
    }

    @JsonProperty("userRole")
    public String getUserRole() {
        return userRole;
    }

    @JsonProperty("userRole")
    public void setUserRole(String userRole) {
        this.userRole = userRole;
    }

    @JsonProperty("userAccountService")
    public List<UserAccountService> getUserAccountService() {
        return userAccountService;
    }

    @JsonProperty("userAccountService")
    public void setUserAccountService(List<UserAccountService> userAccountService) {
        this.userAccountService = userAccountService;
    }

    @JsonProperty("idStoreuserkey")
    public String getIdStoreuserkey() {
        return idStoreuserkey;
    }

    @JsonProperty("idStoreuserkey")
    public void setIdStoreuserkey(String idStoreuserkey) {
        this.idStoreuserkey = idStoreuserkey;
    }

    @JsonProperty("userService")
    public List<UserService> getUserService() {
        return userService;
    }

    @JsonProperty("userService")
    public void setUserService(List<UserService> userService) {
        this.userService = userService;
    }

    @JsonProperty("contactLabel")
    public String getContactLabel() {
        return contactLabel;
    }

    @JsonProperty("contactLabel")
    public void setContactLabel(String contactLabel) {
        this.contactLabel = contactLabel;
    }

    @JsonProperty("contactCountryCode")
    public String getContactCountryCode() {
        return contactCountryCode;
    }

    @JsonProperty("contactCountryCode")
    public void setContactCountryCode(String contactCountryCode) {
        this.contactCountryCode = contactCountryCode;
    }

    @JsonProperty("signerFlag")
    public String getSigner() {
        return signer;
    }

    @JsonProperty("signerFlag")
    public void setSigner(String signer) {
        this.signer = signer;
    }

    @JsonProperty("migratedClient")
    public String getMigrationFlag() {
        return migrationFlag;
    }

    @JsonProperty("migratedClient")
    public void setMigrationFlag(String migrationFlag) {
        this.migrationFlag = migrationFlag;
    }

    public String getPhoneType() {
        return phoneType;
    }

    public void setPhoneType(String phoneType) {
        this.phoneType = phoneType;
    }

    public String getUserStatus() {
        return userStatus;
    }

    public void setUserStatus(String userStatus) {
        this.userStatus = userStatus;
    }

    public String getContactExtension() {
        return contactExtension;
    }

    public void setContactExtension(String contactExtension) {
        this.contactExtension = contactExtension;
    }

    public String getFaxNumber() {
        return faxNumber;
    }

    public void setFaxNumber(String faxNumber) {
        this.faxNumber = faxNumber;
    }

    public List<Partner> getPartners() {
        return partners;
    }

    public void setPartners(List<Partner> partners) {
        this.partners = partners;
    }

    public String getUserOldStatus() {
        return userOldStatus;
    }

    public void setUserOldStatus(String userOldStatus) {
        this.userOldStatus = userOldStatus;
    }

    public String getCardRegistrationStatus() {
        return cardRegistrationStatus;
    }

    public void setCardRegistrationStatus(String cardRegistrationStatus) {
        this.cardRegistrationStatus = cardRegistrationStatus;
    }

    @JsonProperty("isPrimaryContact")
    public String getIsPrimaryContact() {
        return isPrimaryContact;
    }

    @JsonProperty("isPrimaryContact")
    public void setIsPrimaryContact(String isPrimaryContact) {
        this.isPrimaryContact = isPrimaryContact;
    }

    @JsonProperty("ecUserId")
    public String getEcUserId() {
        return ecUserId;
    }

    @JsonProperty("ecUserId")
    public void setEcUserId(String ecUserId) {
        this.ecUserId = ecUserId;
    }

    @JsonProperty("isApprover")
    public String getIsApprover() {
        return isApprover;
    }

    @JsonProperty("isApprover")
    public void setIsApprover(String isApprover) {
        this.isApprover = isApprover;
    }

    @JsonProperty("ecClientIdNum")
    public String getEcClientIdNum() {
        return ecClientIdNum;
    }

    @JsonProperty("ecClientIdNum")
    public void setEcClientIdNum(String ecClientIdNum) {
        this.ecClientIdNum = ecClientIdNum;
    }

    @JsonProperty("ecUserIdNum")
    public void setEcUserIdNum(String ecUserIdNum) {
        this.ecUserIdNum = ecUserIdNum;
    }

    @JsonProperty("ecUserIdNum")
    public String getEcUserIdNum() {
        return ecUserIdNum;
    }
}
