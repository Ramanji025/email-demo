package com.svb.gateway.migration.user.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "accountId",
        "accountsStatus",
        "accountName",
        "accountCurrency",
        "accountType",
        "userAccountServices"
})
public class UserAccount {

	@JsonProperty("accountId")
    private String accountId;
	@JsonProperty("accountStatus")
    private String accountStatus;
	@JsonProperty("accountName")
	private String accountName;
	@JsonProperty("accountCurrency")
	private String accountCurrency;
	@JsonProperty("accountType")
	private String accountType;
	@JsonProperty("userAccountServices")
    private List< UserAccountSvcTx > userAccountServices;

    public String getAccountId() {
        return accountId;
    }

    public void setAccountId(String accountId) {
        this.accountId = accountId;
    }

    public List< UserAccountSvcTx > getUserAccountServices() {
        return userAccountServices;
    }

    public void setUserAccountServices(List< UserAccountSvcTx > userServices) {
        this.userAccountServices = userServices;
    }

	public String getAccountStatus() {
		return accountStatus;
	}

	public void setAccountStatus(String accountStatus) {
		this.accountStatus = accountStatus;
	}

	public String getAccountName() {
		return accountName;
	}

	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}

	public String getAccountCurrency() {
		return accountCurrency;
	}

	public void setAccountCurrency(String accountCurrency) {
		this.accountCurrency = accountCurrency;
	}

	public String getAccountType() {
		return accountType;
	}

	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}

}
