package com.svb.gateway.migration.user.model;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class UserDetails {

    public UserDetails(String userAccess, String userRole, String isApprover){
        this.userAccess=userAccess;
        this.userRole=userRole;
        this.isApprover=isApprover;
    }
    private String userAccess;
    private String userRole;
    private String isApprover;
}
