package com.svb.gateway.migration.user.repository;

import com.svb.gateway.migration.user.entity.MigCardUserEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface MigCardUserRepository extends JpaRepository<MigCardUserEntity, Long> {

    @Query(value = "SELECT * FROM MIG_CARD_USER  WHERE EC_USER_LOGIN_ID = ?1 and lower(STATUS) = lower(?2) ", nativeQuery = true)
    MigCardUserEntity findByGwClientIdAndStatus(String ecUserLoginId, String status);

    @Query(value = "select * from MIG_CARD_USER where GW_CLIENT_ID =?1 and PROGRAM_ID =?2  and JOBID = ?3", nativeQuery = true)
    MigCardUserEntity findByOlbIdAndCardUserProgramAndJobId(String gwClientId, String programId, Long jobId);

    @Query(value = "select * from MIG_CARD_USER where EC_CLIENT_ID = ?1 and JOBID =?2 and STATUS in ?3", nativeQuery = true)
    List<MigCardUserEntity> findByEcClientIdAndJobIdAndStatus(String ecClientId, Long jobId, List<String> status);
}
