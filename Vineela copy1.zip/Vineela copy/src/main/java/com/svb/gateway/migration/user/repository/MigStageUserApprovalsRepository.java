package com.svb.gateway.migration.user.repository;

import com.svb.gateway.migration.user.entity.MigStgUserApprovals;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface MigStageUserApprovalsRepository extends JpaRepository<MigStgUserApprovals, String> {

    @Query(value = "SELECT * FROM MIG_STG_USER_APPROVALS WHERE EC_CLIENT_ID =?1 and JOB_ID = ?2", nativeQuery = true)
    List<MigStgUserApprovals> findByEcClientIdAndJobId(String ecClientId, Long jobId);
}
