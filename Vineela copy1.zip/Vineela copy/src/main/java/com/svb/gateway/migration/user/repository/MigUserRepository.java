package com.svb.gateway.migration.user.repository;

import com.svb.gateway.migration.user.entity.MigUser;
import com.svb.gateway.migration.user.model.UserNotification;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface MigUserRepository extends JpaRepository<MigUser, String> {

    @Query(value = "select mc.ecclientid as ecClientId, mu.gwuuid as gwUid, mu.status as userStatus, " +
            "mc.status as clientStatus from mig_user mu inner join mig_client mc " +
            "on mc.ecclientid = mu.ecclientid " +
            "and mc.jobid = mu.jobid where mc.ecclientid=?1 and mc.jobid=?2", nativeQuery = true)
    List<UserNotification> getMigratedUsers(final String cliendId, final Integer jobId);

    List<MigUser> findByJobId(Long jobId);

    @Query(value = "select * from mig_user where jobId =?1 and ecClientId =?2 and status in ?3 and isPrimaryUser =?4 ", nativeQuery = true)
    List<MigUser> findByJobIdAndAndEcClientIdAndStatus(Long jobId, String ecClientId, List<String> status, Boolean isPrimaryUser);

    @Query(value = "SELECT * FROM mig_user  WHERE JOBID = ?1 and status = ?2 ", nativeQuery = true)
    List<MigUser> findByJobIdandStatus(Long jobId, String status);

    @Query(value = "SELECT * FROM MIG_USER WHERE ecClientId =?1 and JOBID = ?2", nativeQuery = true)
    List<MigUser> findByEcClientIdAndJobId(String ecClientId, Long jobId);

    @Query(value = "select * from mig_user where ecclientid=?1 and lower(status)='success' and isPrimaryUser=1 and gwuuid is not null", nativeQuery = true)
    MigUser getMigratedPrimaryUser(final String clientId);

    @Query(value = "select * from mig_user where ecuserloginid=?1 and ecclientid=?2 and jobid=?3 order by updateddate desc", nativeQuery = true)
    List<MigUser> getMigratedUsers(final String ecUserLoginId, final String ecClientId, final String jobId);

    @Query(value = "select mc.ecclientid as ecClientId, mu.gwuuid as gwUid, mu.migUserId as migUserId, mc.primaryCifUbs as primaryCifUbs, mu.gwClientId as gwClientId, mu.status as userStatus, mc.status as clientStatus" +
            " from mig_user mu inner join mig_stg_user msu on mu.ecclientid = msu.olb_client_id " +
            "and mu.jobid = msu.job_id and mu.ecuserloginid = msu.user_login_id inner join mig_client mc " +
            "on mc.ecclientid = mu.ecclientid and mc.jobid = mu.jobid " +
            "where mu.status = 'SUCCESS' and mu.ecclientid = ?1 and mu.jobid = ?2 and mu.EMAIL_FLAG !='Y' and msu.status = 1", nativeQuery = true)
    List<UserNotification> findByJobIdActive(String ecClientId, Integer jobId);

    @Query(value = "select * from mig_user where ecuserloginid=?1 and jobid=?2", nativeQuery = true)
    MigUser findByEcUserLoginIdAndJobId(String ecUserLoginId, Integer jobId);

    @Query(value = "select count(*) from mig_user u where u.ecclientid=?1 and u.email_flag='Y'", nativeQuery = true)
    int welcomeEmailsSent(String ecClintId);

}
