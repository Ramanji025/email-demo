package com.svb.gateway.migration.user.repository;

import com.svb.gateway.migration.user.entity.MigrationUserEntitlement;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface MigrationUserEntitlementRepository extends JpaRepository<MigrationUserEntitlement, String> {
    @Query(value = "SELECT * FROM MIG_INT_USER_ENTITLEMENTS WHERE CLIENT_ID =?1 and JOB_ID = ?2", nativeQuery = true)
    List<MigrationUserEntitlement> findByEcClientIdAndJobId(String ecClientId, Long jobId);
}
