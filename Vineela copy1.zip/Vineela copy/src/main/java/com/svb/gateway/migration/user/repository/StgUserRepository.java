package com.svb.gateway.migration.user.repository;

import com.svb.gateway.migration.user.entity.StgUser;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface StgUserRepository extends JpaRepository<StgUser, Integer> {

    @Query(value = "select msu.USER_ACCESS, msu.EC_USER_ID_NUM, msu.CREATED_DT, msu.STATUS, msu.ISPRIMARYCONTACT, msu.LAST_NM, " +
            "msu.FIRST_NM, msu.EMAIL, msu.EC_CLIENT_ID_NUM, msu.PRIMARY_USER, msu.REMARKS, " +
            "msu.LAST_LOGGEDIN_DATE, msu.JOB_ID, msu.TYPE_OF_USER, msu.USER_ROLE, msu.USER_LOGIN_ID, msu.OLB_CLIENT_ID, " +
            "msu.CREATED_BY, msupn.country_code as COUNTRY_CODE, msupn.PHONE_NUM as CNT_PH, query_type " +
            "FROM ( SELECT user_login_id,olb_client_id,user_id,phone_name,phone_num,extension,\n" +
            "          country_code,created_by,job_id,created_dt,query_type,\n" +
            "          RANK() OVER(PARTITION BY user_id ORDER BY query_type) query_type_rank "+
            "from MIG_STG_USER_PHONE_NUMBERS) msupn " +
            "inner join mig_stg_user msu on msu.ec_user_id_num = msupn.user_id AND msupn.query_type_rank = 1 where msu.olb_client_id =?1 and msu.PRIMARY_USER =?2", nativeQuery = true)
    List<StgUser> findByOlbClientId(String olbClientId, String isPrimaryUser);
}
