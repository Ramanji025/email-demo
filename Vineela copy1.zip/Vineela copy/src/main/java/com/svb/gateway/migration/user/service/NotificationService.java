package com.svb.gateway.migration.user.service;

import com.svb.gateway.migration.client.entity.MigClient;
import com.svb.gateway.migration.client.repository.MigClientRepository;
import com.svb.gateway.migration.client.service.ClientService;
import com.svb.gateway.migration.common.constants.MigrationConstants;
import com.svb.gateway.migration.common.exception.ServiceException;
import com.svb.gateway.migration.common.logging.Message;
import com.svb.gateway.migration.common.model.EntityRecordCount;
import com.svb.gateway.migration.common.utility.CacheManagerUtility;
import com.svb.gateway.migration.common.utility.ClientStatusEnum;
import com.svb.gateway.migration.common.utility.EntityLogUtility;
import com.svb.gateway.migration.user.entity.MigUser;
import com.svb.gateway.migration.user.mapper.UserMapper;
import com.svb.gateway.migration.user.model.ListOfClientsResponse;
import com.svb.gateway.migration.user.model.UserNotification;
import com.svb.gateway.migration.user.repository.MigUserRepository;
import lombok.extern.log4j.Log4j2;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.sql.Timestamp;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import static com.svb.gateway.migration.common.constants.MigrationConstants.*;
import static com.svb.gateway.migration.common.constants.UserConstants.Y_FLAG;

@Service
@EnableAsync
@Log4j2
public class NotificationService {

    public static final Integer ACCEPTED = 204;

    @Value("${header.service.token}")
    String token;
    @Autowired
    private MigUserRepository migUserRepository;
    @Autowired
    private UserMapper userMapper;
    @Autowired
    private RestTemplate restTemplate;
    @Value("${mig.createuser.url}")
    private String notificationUrl;
    @Autowired
    private CacheManagerUtility cacheManagerUtility;
    @Autowired
    private MigClientRepository migClientRepository;
    @Autowired
    private ClientService clientService;
    @Value("${mig.corelation.id}")
    private String correlationId;
    @Autowired
    private EntityLogUtility entityLogUtility;
    @Value("${mig.user.principal}")
    private String userInfoUserId;

    @Async
    public void sendEmailNotification(final String clientId, final Integer jobId) throws ServiceException {

        Message logMessage = Message.create().jobId(jobId.longValue()).clientId(clientId);
        EntityRecordCount entityRecordCount = new EntityRecordCount();
        int countSuccess = 0;
        int countFailure = 0;
        Timestamp startTime = new Timestamp(new Date().getTime());
        List<UserNotification> userNotification = migUserRepository.findByJobIdActive(clientId, jobId);
        boolean flag = false;
        flag = userNotificationDataCheckFlag(userNotification, flag);

        if (flag) {
            log.info(logMessage.descr("Sending Welcome Email Initiated as all the users are migrated successfully"));
            for (UserNotification migUser : userNotification) {
                try {
                    entityRecordCount.setECCLIENT_ID(migUser.getEcClientId());
                    entityRecordCount.setGWCLIENT_ID(migUser.getGwClientId());
                    entityRecordCount.setCIF_NUMBER(migUser.getPrimaryCifUbs());
                    if (StringUtils.isBlank(migUser.getGwUid())) {
                            throw new ServiceException("GWUID is null");
                    }
                    String url = notificationUrl + SLASH + migUser.getGwUid() + SLASH + NOTIFICATION + "?" + OPERATION + "=" + "TRIGGER_EMAIL";
                    logMessage.url(url).gwClientId(migUser.getGwClientId()).userId(migUser.getMigUserId().toString());
                    HttpHeaders headers = new HttpHeaders();
                    headers.add(MigrationConstants.AUTHORIZATION_HEADER_NAME, cacheManagerUtility.getOauthToken());
                    HttpEntity<String> requestEntity = new HttpEntity<>(null, headers);
                    ResponseEntity<?> response = restTemplate.exchange(url, HttpMethod.POST, requestEntity, Object.class);
                    MigUser migUserEntity = new MigUser();
                    migUserEntity.setEmailFlag(Y_FLAG);
                    migUserEntity.setMigUserId(migUser.getMigUserId());
                    userMapper.updateUserStatus(migUserEntity);

                    if (response.getStatusCodeValue() == ACCEPTED) {
                        countSuccess++;
                    } else {
                        countFailure++;
                    }
                    log.info(logMessage.summary().descr("For user " + migUser.getGwUid() + " welcome mail status " + response.getStatusCodeValue()));
                } catch (Exception e) {
                    countFailure++;
                    log.error(logMessage.descr("Exception while sending notification " + e.getMessage()));
                }
            }

            Date closingTime = Calendar.getInstance().getTime();
            long duration = (closingTime.getTime() - startTime.getTime()) / 1000;
            entityRecordCount.setMIG_ENTITY_ID("");
            entityRecordCount.setENTITY_NAME(MigrationConstants.EMAIL_NOTIFICATION);
            entityRecordCount.setJOB_ID(jobId.toString());
            entityRecordCount.setREADCOUNT(userNotification.size());
            entityRecordCount.setWRITECOUNT(countSuccess);
            entityRecordCount.setSKIPCOUNT(countFailure);
            entityRecordCount.setSTART_TIME(new Timestamp(startTime.getTime()));
            entityRecordCount.setEND_TIME(new Timestamp(closingTime.getTime()));
            entityRecordCount.setTOTAL_STEP_TIME(duration);
            entityLogUtility.saveEntityCountAndTimeLog(entityRecordCount);
        } else {
            Date closingTime = Calendar.getInstance().getTime();
            long duration = (closingTime.getTime() - startTime.getTime()) / 1000;
            entityRecordCount.setMIG_ENTITY_ID("");
            entityRecordCount.setENTITY_NAME(MigrationConstants.EMAIL_NOTIFICATION);
            entityRecordCount.setCIF_NUMBER("");
            entityRecordCount.setECCLIENT_ID(clientId);
            entityRecordCount.setGWCLIENT_ID("");
            entityRecordCount.setJOB_ID(jobId.toString());
            entityRecordCount.setREADCOUNT(MigrationConstants.COUNT_ZERO);
            entityRecordCount.setWRITECOUNT(MigrationConstants.COUNT_ZERO);
            entityRecordCount.setSKIPCOUNT(MigrationConstants.COUNT_ZERO);
            entityRecordCount.setSTART_TIME(new Timestamp(startTime.getTime()));
            entityRecordCount.setEND_TIME(new Timestamp(closingTime.getTime()));
            entityRecordCount.setTOTAL_STEP_TIME(duration);
            entityLogUtility.saveEntityCountAndTimeLog(entityRecordCount);
            log.warn(logMessage.descr("Sending Welcome Email Ignored, All the users are not migrated"));
        }
    }

    private boolean userNotificationDataCheckFlag(List<UserNotification> userNotification, boolean flag) {
        if (!userNotification.isEmpty()) {
            flag = userNotification.stream().allMatch(un -> MigrationConstants.STATUS_SUCCESS.equalsIgnoreCase(un.getUserStatus())
                    && MigrationConstants.STATUS_SUCCESS.equalsIgnoreCase(un.getClientStatus()));
        }
        return flag;
    }

    public List<MigClient> getAllClientsByStatus(List<String> ecClientIds) {

        return clientService.getMigClientsByClientIds(ecClientIds);
    }

    public int sendEmailNotificationByJobId(Integer jobId) {
        Message logMessage = Message.create().jobId(jobId.longValue());
        List<MigClient> migClients = clientService.getMigClientsByJobId(jobId);

        migClients.forEach(migClient -> {
            try {
                sendEmailNotification(migClient.getEcClientId(), jobId);
            } catch (ServiceException e) {
                log.error(logMessage.jobId(migClient.getJobId()).clientId(migClient.getEcClientId()).descr(e.getMessage()).summary().toString());
            }
        });
        return migClients.size();
    }


    public ListOfClientsResponse getListOfClients(final Integer jobId, final String status) {

        Message logMessage = Message.create().jobId(jobId.longValue());
        ListOfClientsResponse listOfClientsResponse = new ListOfClientsResponse();

        try {
            if (ClientStatusEnum.SUCCESS.name().equalsIgnoreCase(status)) {
                List<String> migClientList = migClientRepository.findByJobIdAndStatus(Long.valueOf(jobId), status);

                listOfClientsResponse.setEcClientIdList(migClientList);
            } else {
                List<String> migClientFailList = migClientRepository.findByJobIdAndStatusFalse(Long.valueOf(jobId), status);

                listOfClientsResponse.setEcClientIdList(migClientFailList);
            }
            return listOfClientsResponse;

        } catch (Exception e) {
            log.error(logMessage.descr("Exception while sending notification " + e.getMessage()));
        }
        return null;
    }
}
