package com.svb.gateway.migration.user.service;

import com.svb.gateway.migration.client.repository.ClientRepository;
import com.svb.gateway.migration.client.repository.MigClientRepository;
import com.svb.gateway.migration.common.exception.ServiceException;
import com.svb.gateway.migration.common.logging.Message;
import com.svb.gateway.migration.common.repository.MigEntityRepository;
import com.svb.gateway.migration.user.entity.MigStgUserApprovals;
import com.svb.gateway.migration.user.entity.MigUser;
import com.svb.gateway.migration.user.entity.MigrationUserEntitlement;
import com.svb.gateway.migration.user.repository.MigCardUserRepository;
import com.svb.gateway.migration.user.repository.MigStageUserApprovalsRepository;
import com.svb.gateway.migration.user.repository.MigUserRepository;
import com.svb.gateway.migration.user.repository.MigrationUserEntitlementRepository;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import static com.svb.gateway.migration.common.constants.UserConstants.YES;

@Log4j2
@Service
public class UserApprovalService {

    @Autowired
    ClientRepository clientRepository;

    @Autowired
    MigStageUserApprovalsRepository migStageUserApprovalsRepository;

    @Autowired
    MigClientRepository migClientRepository;

    @Autowired
    MigUserRepository migUserRepository;

    @Autowired
    private MigEntityRepository migEntityRepository;

    @Autowired
    private MigCardUserRepository migCardUserRepository;

    @Autowired
    private MigrationUserEntitlementRepository migrationUserEntitlementRepository;

    public void save(MigUser entity) {
        migUserRepository.save(entity);
    }

    //Returns map of UserId and Entitlement required for approval request
    @Transactional
    public Map<String, MigrationUserEntitlement> userEntitlements(Long jobId, String ecClientId) throws ServiceException {
        Message logMessage = Message.create().jobId(jobId).clientId(ecClientId).srcId("UserApprovals").descr("process user entititlements ").operation("userEntitlements").summary();

        Map<String, MigrationUserEntitlement> userEntitlementMap=new HashMap<>();

        List<MigStgUserApprovals> userStageApprovals=migStageUserApprovalsRepository.findByEcClientIdAndJobId(ecClientId, jobId);
        if(userStageApprovals==null || userStageApprovals.isEmpty()){
            log.warn(logMessage.descr("No userStageApprovals exist in the dataase, returning empty userEntitlement map"));
            return userEntitlementMap;
        }
        log.info(logMessage.descr("# of userStageApprovals "+userStageApprovals.size()));

        List<MigrationUserEntitlement> entitlements=migrationUserEntitlementRepository.findByEcClientIdAndJobId(ecClientId, jobId);
        if(entitlements!=null && !entitlements.isEmpty()){
            log.info(logMessage.descr("Delete previous entitlements "+entitlements.size()));
            migrationUserEntitlementRepository.deleteAll(entitlements);
        }

        userStageApprovals.stream().filter(Objects::nonNull).forEach(user->process(user, userEntitlementMap));
        if(!userEntitlementMap.isEmpty()){
            log.info(logMessage.descr("Save entitlements for "+userEntitlementMap.size() +" Users "));
            migrationUserEntitlementRepository.saveAll(userEntitlementMap.values());
        }
        log.info(logMessage.descr("# of user entitlements "+userEntitlementMap.size()).summary());

        return userEntitlementMap;
    }

    private void process(MigStgUserApprovals stgUserApprovals, Map<String, MigrationUserEntitlement> userEntitlementMap){
        MigrationUserEntitlement migrationUserEntitlement=
                userEntitlementMap.getOrDefault(stgUserApprovals.getEcUserId(), new MigrationUserEntitlement(stgUserApprovals.getEcUserId()));

        migrationUserEntitlement.setClientId(stgUserApprovals.getEcClientId());
        migrationUserEntitlement.setEConnectApproveEntitlement(YES.equalsIgnoreCase(stgUserApprovals.getEcApproveEntitlement())?YES:stgUserApprovals.getEcApproveEntitlement());
        migrationUserEntitlement.setEConnectInitiateEntitlement(YES.equalsIgnoreCase(stgUserApprovals.getEcInitiateEntitlement())?YES:stgUserApprovals.getEcInitiateEntitlement());
        migrationUserEntitlement.setEConnectViewEntitlement(YES.equalsIgnoreCase(stgUserApprovals.getEcViewEntitlement())?YES:stgUserApprovals.getEcViewEntitlement());
        migrationUserEntitlement.setIpayApproveEntitlement(YES.equalsIgnoreCase(stgUserApprovals.getIpayApproveEntitlement())?YES:stgUserApprovals.getIpayApproveEntitlement());
        migrationUserEntitlement.setEConnectUserRole(stgUserApprovals.getEcUserRole());
        migrationUserEntitlement.setJobId(Long.valueOf(stgUserApprovals.getJobId()));
        migrationUserEntitlement.setEConnectUserRole(stgUserApprovals.getEcUserRole());
        userEntitlementMap.put(stgUserApprovals.getEcUserId(),migrationUserEntitlement);
    }
}
