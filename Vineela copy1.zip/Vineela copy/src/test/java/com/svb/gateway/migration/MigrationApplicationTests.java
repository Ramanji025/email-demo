package com.svb.gateway.migration;

import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpHeaders;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestBuilders;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.util.Base64Utils;

import java.security.Principal;

import static com.svb.gateway.migration.TestUtil.*;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestBuilders.formLogin;
import static org.springframework.security.test.web.servlet.response.SecurityMockMvcResultMatchers.unauthenticated;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@AutoConfigureMockMvc
class MigrationApplicationTests {

	@Autowired
	private MockMvc mockMvc;

	@Test
	@WithMockUser(username = TEST_USER_USER3, password = TEST_USER1_VALID_PASSWORD, roles = TEST_USER1_ROLE_VIEW)
	void contextLoads() throws Exception {
		//assertThat(controller.index(principal)).isNotNull();
	}

	@Test
	@WithMockUser(username = TEST_USER_USER1, password = TEST_USER1_VALID_PASSWORD, roles = TEST_USER1_ROLE_EXECUTE)
	void basicAuth() throws Exception {
		this.mockMvc
				.perform(get("/v1/api/job").header("Authorization","Basic Y3JtdXNlcjQ6QWNjZXNzMTIz")
				.param("jobId", "1"))
				.andExpect(status().isOk());
	}

	@Test
	@WithMockUser(username = TEST_USER_USER1, password = TEST_USER1_VALID_PASSWORD, roles = TEST_USER1_ROLE_EXECUTE)
	void withMockUser() throws Exception {
		this.mockMvc.perform(get("/v1/api/job")
				.header("Authorization","Basic Y3JtdXNlcjQ6QWNjZXNzMTIz")
				.param("jobId", "1"))
				.andExpect(status().isOk());
	}

	@Test
	void loginWithInvalidUserThenUnauthenticated() throws Exception {
		SecurityMockMvcRequestBuilders.FormLoginRequestBuilder login = formLogin()
				.user(TEST_USER_USER1)
				.password(TEST_USER1_INVALID_PASSWORD);

		mockMvc.perform(login).andExpect(unauthenticated());
	}

	@Test
	@WithMockUser(username = TEST_USER_USER1, password = TEST_USER1_VALID_PASSWORD, authorities = TEST_USER1_ROLE_EXECUTE)
	void withMockUserTest() throws Exception {
		this.mockMvc.perform(get("/v1/api/job")
				.header("Authorization","Basic Y3JtdXNlcjQ6QWNjZXNzMTIz")
				.param("jobId", "1"))
				.andExpect(status().isOk());
	}

}
