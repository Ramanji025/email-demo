package com.svb.gateway.migration.alerts.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.svb.gateway.migration.alerts.model.AlertsResponse;
import com.svb.gateway.migration.alerts.service.AlertsService;
import com.svb.gateway.migration.client.entity.MigClient;
import com.svb.gateway.migration.client.model.MigClientDTO;
import com.svb.gateway.migration.common.exception.ServiceException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentMatchers;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.test.web.servlet.MockMvc;

import static junit.framework.TestCase.assertEquals;
import static org.mockito.Mockito.doThrow;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@AutoConfigureMockMvc
class AlertsControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    @InjectMocks
    AlertsController alertsController;

    @MockBean
    AlertsService alertsService;

    AlertsResponse alertsResponse=new AlertsResponse();
    MigClientDTO migClientDTO=new MigClientDTO();

    public static String clientId="acc1234";
    public static Long jobId=Long.valueOf("123");

    @BeforeEach
    public void setup() throws Exception {
        alertsController = new AlertsController(alertsService);
        migClientDTO.setEcClientId(clientId);
    }

    @Test
    public void testRegisterAlerts() throws Exception {

        Mockito.when(alertsService.registerAlerts(ArgumentMatchers.anyLong(),ArgumentMatchers.any())).
                thenReturn(alertsResponse);

        this.mockMvc.perform(post("/api/alerts/{jobId}","123")
                .contentType(MediaType.APPLICATION_JSON_VALUE)
                .content(objectMapper.writeValueAsString(migClientDTO))
                .header("Authorization","Basic Y3JtdXNlcjI6QWNjZXNzMTIz"))
                .andExpect(status().isOk());
    }

    @Test
    public void testRegisterAlertsWithServiceException() throws Exception {

        doThrow(new ServiceException("Internal Server Error")).when(alertsService).registerAlerts(ArgumentMatchers.anyLong(),ArgumentMatchers.any());

        ResponseEntity<?> re = alertsController.registerAlerts(jobId,migClientDTO);

        assertEquals(HttpStatus.BAD_REQUEST, re.getStatusCode());
    }
}
