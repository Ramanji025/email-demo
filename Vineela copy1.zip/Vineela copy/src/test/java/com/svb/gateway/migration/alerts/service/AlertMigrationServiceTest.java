package com.svb.gateway.migration.alerts.service;

import com.svb.gateway.migration.alerts.entity.Alerts;
import com.svb.gateway.migration.alerts.entity.AlertsIPDTForAULTEntity;
import com.svb.gateway.migration.alerts.entity.MigRefAlertMapping;
import com.svb.gateway.migration.alerts.entity.MigrationAlerts;
import com.svb.gateway.migration.alerts.model.MigAlertUser;
import com.svb.gateway.migration.alerts.repository.MigAlertUserRepository;
import com.svb.gateway.migration.cards.entity.MigCardProgram;
import com.svb.gateway.migration.cards.repository.MigCardProgramRepository;
import com.svb.gateway.migration.common.constants.MigrationConstants;
import com.svb.gateway.migration.common.exception.ServiceException;
import com.svb.gateway.migration.common.service.RetryService;
import com.svb.gateway.migration.common.utility.CacheManagerUtility;
import lombok.extern.slf4j.Slf4j;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.test.context.junit.jupiter.SpringExtension;


import java.util.ArrayList;
import java.util.Collection;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.fail;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.when;

@Slf4j
@SpringBootTest
@ExtendWith(SpringExtension.class)
public class AlertMigrationServiceTest {

    @Mock
    private MigAlertUserRepository migAlertUserRepository;

    @Mock
    private MigCardProgramRepository migCardProgramRepository;

    @Mock
    private CacheManagerUtility cacheManagerUtility;

    @Mock
    private RetryService retryService;


    @InjectMocks
    @Spy
    AlertMigrationService alertMigrationService;

    Alerts alerts=new Alerts();
    MigAlertUser migrationUser;
    MigCardProgram migCardProgram=new MigCardProgram();
    MigRefAlertMapping migRefAlertMapping =new MigRefAlertMapping();
    Object objectResponse=new Object();

    @BeforeEach
    void setUp() {
         migrationUser= new MigAlertUser() {
            @Override
            public String getEcClientId() {
                return "data1234";
            }

            @Override
            public String getEcUserLoginId() {
                return "user123456";
            }

            @Override
            public String getGwUid() {
                return "27DGH3434WDK78ED78";
            }

            @Override
            public String getGwClientId() {
                return "GWADDR1234";
            }

            @Override
            public String getPrimaryCifUbs() {
                return "2000023423";
            }

            @Override
            public String getUserStatus() {
                return "SUCCESS";
            }

            @Override
            public String getClientStatus() {
                return "SUCCESS";
            }
        };

        migCardProgram.setCif("1234567");

        migRefAlertMapping.setEcAlertTypeId(11);
        migRefAlertMapping.setGwAlertId("SVB_ABCD");
        migRefAlertMapping.setGwAlertType("DEFAULT");

        alerts.setAlertStatus("ACTIVE");
        alerts.setAlertTypeId(11);
        alerts.setAlertTypeName("CAM_");
        alerts.setAlertsClientConfigId(12345);
        alerts.setEcAlertType("SIGNUP");
        alerts.setEcClientId("data1234");
        alerts.setEcAlertAccountId("12345678");
        alerts.setEcAlertDeliveryType(3);
        objectResponse="{status:SUCCESS}";
    }

    @Test
    void insert_throws_ServiceException() {
        try {
            MigrationAlerts migrationAlerts=alertMigrationService.insert(alerts, migRefAlertMapping);
            assertEquals(MigrationConstants.STATUS_FAILURE,migrationAlerts.getStatus());
        } catch (ServiceException serviceException) {

        }
    }

    @Test
    void insert_throws_ServiceExceptionForCardProgram() {
        try {
            when(migAlertUserRepository.getMigratedAlertUser(anyString(),anyString())).thenReturn(migrationUser);
            MigrationAlerts migrationAlerts=alertMigrationService.insert(alerts, migRefAlertMapping);
            assertEquals(MigrationConstants.STATUS_FAILURE,migrationAlerts.getStatus());
        } catch (ServiceException serviceException) {

        }
    }

    @Test
    void insert_CardsAlertFailure() {
        try {
            when(migAlertUserRepository.getMigratedAlertUser(any(),any())).thenReturn(migrationUser);
            when(migCardProgramRepository.findByOlbIdAndCardProgram(any(),any(),any(),any())).thenReturn(migCardProgram);
            ResponseEntity<Object> alertsResponseEntity= new ResponseEntity(objectResponse, HttpStatus.BAD_REQUEST);
            doReturn(alertsResponseEntity).when(retryService).exchange(anyString(),any(HttpMethod.class),any(HttpEntity.class),any());
            MigrationAlerts migrationAlerts=alertMigrationService.insert(alerts, migRefAlertMapping);
        } catch (ServiceException e) {
           fail();
        }
    }

    @Test
    void insert_CardsAlert() {
        try {
            when(migAlertUserRepository.getMigratedAlertUser(any(),any())).thenReturn(migrationUser);
            when(migCardProgramRepository.findByOlbIdAndCardProgram(any(),any(),any(),any())).thenReturn(migCardProgram);
            ResponseEntity<Object> alertsResponseEntity= new ResponseEntity(objectResponse, HttpStatus.OK);
            doReturn(alertsResponseEntity).when(retryService).exchange(anyString(),any(HttpMethod.class),any(HttpEntity.class),any());
            MigrationAlerts migrationAlerts=alertMigrationService.insert(alerts, migRefAlertMapping);
        } catch (ServiceException e) {
            fail();
        }
    }

    @Test
    void insert_NoCardProgramLinked() {
        try {
            when(migAlertUserRepository.getMigratedAlertUser(any(),any())).thenReturn(migrationUser);
            when(migCardProgramRepository.findByOlbIdAndCardProgram(any(),any(),any(),any())).thenReturn(null);
            MigrationAlerts migrationAlerts=alertMigrationService.insert(alerts, migRefAlertMapping);
        } catch (ServiceException e) {
            fail();
        }
    }

}
