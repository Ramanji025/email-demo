package com.svb.gateway.migration.beneficiaries.service;

import static com.svb.gateway.migration.beneficiaries.entity.StgToTargetBeneEntity.PAYEE_TYPE.*;

import com.svb.gateway.migration.beneficiaries.entity.MigBeneficiary;
import com.svb.gateway.migration.beneficiaries.entity.StgToTargetBeneEntity;
import com.svb.gateway.migration.beneficiaries.mapper.BeneficiaryMapper;
import com.svb.gateway.migration.beneficiaries.mapper.MigBeneficiaryMapper;
import com.svb.gateway.migration.beneficiaries.mapper.SelectConditions;
import com.svb.gateway.migration.beneficiaries.model.*;
import com.svb.gateway.migration.beneficiaries.repository.BeneficiaryRepository;
import com.svb.gateway.migration.beneficiaries.repository.MigBeneficiaryRepository;
import com.svb.gateway.migration.client.entity.MigClient;
import com.svb.gateway.migration.client.repository.MigClientRepository;
import com.svb.gateway.migration.common.exception.ServiceException;
import com.svb.gateway.migration.common.model.OauthResponse;
import com.svb.gateway.migration.common.repository.GatewayOAuthRepository;
import com.svb.gateway.migration.common.service.RetryService;
import com.svb.gateway.migration.common.utility.CacheManagerUtility;
import com.svb.gateway.migration.common.utility.EntityLogUtility;
import com.svb.gateway.migration.user.entity.MigUser;
import com.svb.gateway.migration.user.repository.MigUserRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.*;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.web.client.RestTemplate;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import static junit.framework.TestCase.assertTrue;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@SpringBootTest
@ExtendWith(SpringExtension.class)
public class BeneficiariesServiceTest {

    public static String clientId;
    public static String companyId;
    public static String migratingClientId;
    public static String userType;
    String migUserPrincipal = "4AB6C07A32B542269EF80BC4D5F5509C";

    @Mock
    BeneficiaryValidationUtility beneficiaryValidationUtility;

    @Mock
    OauthResponse oauthResponse;

    @Mock
    BeneficiaryMapper beneficiaryMapper;

    @Mock
    MigClientRepository migClientRepository;

    @Mock
    MigUserRepository migUserRepository;

    @Mock
    GatewayOAuthRepository gatewayOAuthRepository;

    @Mock
    BeneficiaryRepository beneficiaryRepository;

    @Mock
    MigBeneficiaryRepository migBeneficiaryRepository;

    @Mock
    MigBeneficiaryMapper migBeneficiaryMapper;

    @Mock
    CacheManagerUtility cacheManagerUtility;

    @Mock
    NamedParameterJdbcTemplate jdbcTemplate;

    @Mock
    EntityLogUtility entityLogUtility;


    @InjectMocks
    @Spy
    ACHPayeeManager achPayeeManager;

    @Value("https://gateway-billpay-dev2.ose.uat.svbank.com/billpay/billers")
    String fetchBillerNetworkUrl;

    @InjectMocks
    @Spy
    ACHLargePayeeManager achLargePayeeManager;

    @Mock
    RestTemplate restTemplate;

    @Mock
    ResponseEntity<LargeBillerInformationResponse> largeBillerInformationResponseEntity;

    @InjectMocks
    @Spy
    CheckPayeeManager checkPayeeManager;

    @InjectMocks
    @Spy
    TemplatePayeeManager templatePayeeManager;

    @InjectMocks
    @Spy
    WirePayeeManager wirePayeeManager;

    @InjectMocks
    @Spy
    BeneficiariesService beneficiariesService;

    private Long jobId = 1L;

    @BeforeAll
    public static void setUpBeforeAll() {
        clientId = "abcd1234";
        migratingClientId = "addr9768";
        companyId = "SVB";
        userType = "VTUSER";
    }

    @BeforeEach
    public void setUpBeforeEachTest() {
        beneficiariesService.migUserPrincipal = migUserPrincipal;
        beneficiariesService.beneParallelThreads = 4;
        templatePayeeManager.beneficiaryValidationUtility = beneficiaryValidationUtility;//why isn't this injected?
        templatePayeeManager.migBeneficiaryMapper = migBeneficiaryMapper;//why isn't this injected?

        wirePayeeManager.beneficiaryValidationUtility = beneficiaryValidationUtility;//why isn't this injected?

        beneficiariesService.templatePayeeManager = templatePayeeManager;
        beneficiariesService.pastPayeeManager = wirePayeeManager;
        beneficiariesService.futurePayeeManager = wirePayeeManager;
        beneficiariesService.checkPayeeManager = checkPayeeManager;
        beneficiariesService.achPayeeManager = achPayeeManager;
        achPayeeManager.beneficiaryValidationUtility = beneficiaryValidationUtility;//why isn't this injected?

        templatePayeeManager.beneficiaryMapper = beneficiaryMapper;//why isn't this injected?
        wirePayeeManager.beneficiaryMapper = beneficiaryMapper;
        checkPayeeManager.beneficiaryMapper = beneficiaryMapper;
        achPayeeManager.beneficiaryMapper = beneficiaryMapper;
        achLargePayeeManager.beneficiaryMapper = beneficiaryMapper;
        beneficiariesService.achLargePayeeManager = achLargePayeeManager;
        MigUser primaryUserMigrated = new MigUser();
        primaryUserMigrated.setGwClientId("GWaddr1234");
        primaryUserMigrated.setGwUuid("b01eb56652f046328b933ecdf4ba0374");
        doReturn(primaryUserMigrated).when(migUserRepository).getMigratedPrimaryUser(anyString());

    }
    private StgToTargetBeneEntity getDefaultStgToTargetBeneEntity() {
        StgToTargetBeneEntity stgBeneficiary = new StgToTargetBeneEntity();
        stgBeneficiary.setBENEFICIARY_NAME("Jack");
        stgBeneficiary.setBENEFICIARY_ACCOUNT("1234578");
        stgBeneficiary.setBENEFICIARY_ADDRESS_1("180 Market St");
        stgBeneficiary.setBENEFICIARY_BANK_IDENTIFIER("ab123SX");
        stgBeneficiary.setWIRE_TRANSACTION_ID(22);
        stgBeneficiary.setIPAYEE_BENE_ID(234);
        stgBeneficiary.setTEMPLATE_ID(1234);
        stgBeneficiary.setCURRENCY_CODE("USD");
        stgBeneficiary.setELECTRONIC_INDICATOR("Y");
        stgBeneficiary.setJOB_ID(jobId);

        stgBeneficiary.setEC_CLIENT_ID("abcd1234");
        return stgBeneficiary;
    }

    @Test
    void testSetBankDetailsMatch(){
        StgToTargetBeneEntity stgBeneficiary = getDefaultStgToTargetBeneEntity();
        stgBeneficiary.setBENEFICIARY_BANK_CITY("city2");
        MigClient migClient = new MigClient();
        migClient.setEcClientId("ola1234");
        migClient.setGwClientId("GWaddr1234");
        migClient.setJobId(Long.valueOf(1));
        migClient.setUpdatedBy("migUser");
        EntityWrapper entityWrapper = new EntityWrapper(stgBeneficiary);;
        BankBranchResponse bankBranchResponse = new BankBranchResponse();
        BankBranchResponseData data1 = getBankBranchResponseData(1);
        BankBranchResponseData data2 = getBankBranchResponseData(2);
        BankBranchResponseData data3 = getBankBranchResponseData(3);
        List list = new ArrayList();
        list.add(data1);
        list.add(data2);
        list.add(data3);
        bankBranchResponse.setData(list);
        BankDetails bankDetails = templatePayeeManager.setBankDetails(entityWrapper, bankBranchResponse);
        assertEquals(data2.getBankRefNo(), bankDetails.getBankRefNum());
        assertEquals(data2.getBranchAddress().getCountry().getCmCode(), bankDetails.getCountry());
        assertEquals(data2.getNetwork().getCmCode(), bankDetails.getNetworkType());
    }

    @Test
    void testSetBankDetailsNoMatchPickFirst(){
        StgToTargetBeneEntity stgBeneficiary = getDefaultStgToTargetBeneEntity();
        stgBeneficiary.setBENEFICIARY_BANK_CITY("cityNoMatch");
        MigClient migClient = new MigClient();
        migClient.setEcClientId("ola1234");
        migClient.setGwClientId("GWaddr1234");
        migClient.setJobId(Long.valueOf(1));
        migClient.setUpdatedBy("migUser");
        EntityWrapper entityWrapper = new EntityWrapper(stgBeneficiary);;
        BankBranchResponse bankBranchResponse = new BankBranchResponse();
        BankBranchResponseData data1 = getBankBranchResponseData(1);
        BankBranchResponseData data2 = getBankBranchResponseData(2);
        BankBranchResponseData data3 = getBankBranchResponseData(3);
        List list = new ArrayList();
        list.add(data1);
        list.add(data2);
        list.add(data3);
        bankBranchResponse.setData(list);
        BankDetails bankDetails = templatePayeeManager.setBankDetails(entityWrapper, bankBranchResponse);
        assertEquals(data1.getBankRefNo(), bankDetails.getBankRefNum());
        assertEquals(data1.getBranchAddress().getCountry().getCmCode(), bankDetails.getCountry());
        assertEquals(data1.getNetwork().getCmCode(), bankDetails.getNetworkType());
    }

    @Test
    void testSetBankDetailsNobankBranchResponse(){
        StgToTargetBeneEntity stgBeneficiary = getDefaultStgToTargetBeneEntity();
        stgBeneficiary.setBENEFICIARY_BANK_CITY("cityNoMatch");
        MigClient migClient = new MigClient();
        migClient.setEcClientId("ola1234");
        migClient.setGwClientId("GWaddr1234");
        migClient.setJobId(Long.valueOf(1));
        migClient.setUpdatedBy("migUser");
        EntityWrapper entityWrapper = new EntityWrapper(stgBeneficiary);;
        BankBranchResponse bankBranchResponse = new BankBranchResponse();
        bankBranchResponse.setValidated(false);
        BankDetails bankDetails = templatePayeeManager.setBankDetails(entityWrapper, bankBranchResponse);
        assertNull(bankDetails.getBranchName());
    }

    private BankBranchResponseData getBankBranchResponseData(int seq) {
        BankBranchResponseData data = new BankBranchResponseData();
        data.setBranchName("branchName"+seq);
        data.setBankClearingCode("clearingCode"+seq);
        data.setBankName("bankName"+seq);
        data.setBankRefNo("bankRefNo"+seq);
        BranchAddress address = new BranchAddress();
        address.setAddress("address"+seq);
        Country country = new Country();
        country.setCmCode("cmCode"+seq);
        country.setCodeDescription("codeDescription"+seq);
        country.setCodeType("codeType"+seq);
        address.setCountry(country);
        address.setCity("city"+seq);
        State state = new State();
        state.setStateCode("CA");
        state.setStateDescription("state descr"+seq);
        state.setCountryCode("US");
        address.setState(state);
        address.setZipCode("95000");
        data.setBranchAddress(address);
        Network network = new Network();
        network.setCodeType("netwCodeTYPE"+seq);
        network.setCmCode("netwCm"+seq);
        network.setCodeDescription("netwCodeDescr"+seq);
        data.setNetwork(network);
        data.setRoutingCodeAlt("RoutingCodeAlt"+seq);
        return data;
    }

    @Test
    void addBeneficiaries_ACHLargePayeeManager() {
        StgToTargetBeneEntity stgBeneficiary = new StgToTargetBeneEntity();
        stgBeneficiary.setBENEFICIARY_ACCOUNT("1234");
        stgBeneficiary.setBENEFICIARY_NAME("name");
        stgBeneficiary.setPAYEE_ZIP_CODE("95000");
        MigClient migClient = new MigClient();
        migClient.setGwClientId("abcd1234");
        AccountDetails accountDetails = new AccountDetails();

        ResponseEntity<LargeBillerResponse> largeBillerResponseEntity = Mockito.mock(ResponseEntity.class);

        // 1st call
        doReturn(HttpStatus.OK).when(largeBillerResponseEntity).getStatusCode();
        LargeBillerResponse largeBillerResponse = Mockito.mock(LargeBillerResponse.class);
        doReturn(largeBillerResponse).when(largeBillerResponseEntity).getBody();
        List<LargeBillerResponseData> largeBillerResponseDataList = new ArrayList<LargeBillerResponseData>();
        LargeBillerResponseData largeBillerResponseData = new LargeBillerResponseData();
        largeBillerResponseData.setNetworkId("netwId");
        largeBillerResponseDataList.add(largeBillerResponseData);
        doReturn(largeBillerResponseDataList).when(largeBillerResponse).getData();
        RetryService retryService = Mockito.mock(RetryService.class);
        achLargePayeeManager.setRetryService(retryService);
        doReturn(largeBillerResponseEntity).when(retryService).exchange(eq("https://serviceurl?olbClientId=abcd1234&addressZip=95000&searchString=name"), any(HttpMethod.class), any(HttpEntity.class), ArgumentMatchers.<ParameterizedTypeReference<LargeBillerResponse>>any());


        // 2nd call
        ResponseEntity<LargeBillerInformationResponse> largeBillerInformationResponseEntity = Mockito.mock(ResponseEntity.class);
        doReturn(HttpStatus.OK).when(largeBillerInformationResponseEntity).getStatusCode();
        LargeBillerInformationResponse largeBillerInformationResponse = Mockito.mock(LargeBillerInformationResponse.class);
        doReturn(largeBillerInformationResponse).when(largeBillerInformationResponseEntity).getBody();
        List<LargeBillerInformationResponseData> largeBillerInformationResponseDataList = new ArrayList<LargeBillerInformationResponseData>();
        LargeBillerInformationResponseData largeBillerInformationResponseData = new LargeBillerInformationResponseData();
        largeBillerInformationResponseDataList.add(largeBillerInformationResponseData);
        doReturn(largeBillerInformationResponseDataList).when(largeBillerInformationResponse).getData();
        doReturn(largeBillerInformationResponseEntity).when(retryService).exchange(eq("https://serviceurl/netwId/addresses?olbClientId=abcd1234&addressZip=95000&searchString=name"), any(HttpMethod.class), any(HttpEntity.class), ArgumentMatchers.<ParameterizedTypeReference<LargeBillerInformationResponse>>any());

        achLargePayeeManager.fetchBillerNetworkUrl = "https://serviceurl";
        migClient.setEcClientId(migratingClientId);
        List<PaymentDetail> payments = achLargePayeeManager.getPaymentDetails(new EntityWrapper(stgBeneficiary), migClient, accountDetails, null);
        assertEquals(1, payments.size());
        assertEquals("1234", payments.get(0).getCustomerAccountNumber());
        assertEquals("ACH", payments.get(0).getPaymentMethod());
        assertEquals("Y", payments.get(0).getIsLargeBiller());
    }

    @Test
    void addBeneficiaries_ACHLargePayeeManagerFailure1() {
        StgToTargetBeneEntity stgBeneficiary = new StgToTargetBeneEntity();
        stgBeneficiary.setBENEFICIARY_ACCOUNT("1234");
        stgBeneficiary.setBENEFICIARY_NAME("name");
        stgBeneficiary.setPAYEE_ZIP_CODE("95000");
        MigClient migClient = new MigClient();
        migClient.setGwClientId("abcd1234");
        migClient.setEcClientId(migratingClientId);
        AccountDetails accountDetails = new AccountDetails();

        ResponseEntity<LargeBillerResponse> largeBillerResponseEntity = Mockito.mock(ResponseEntity.class);

        // 1st call
        doReturn(HttpStatus.SERVICE_UNAVAILABLE).when(largeBillerResponseEntity).getStatusCode();
        LargeBillerResponse largeBillerResponse = Mockito.mock(LargeBillerResponse.class);
        doReturn(largeBillerResponse).when(largeBillerResponseEntity).getBody();
        List<LargeBillerResponseData> largeBillerResponseDataList = new ArrayList<LargeBillerResponseData>();
        LargeBillerResponseData largeBillerResponseData = new LargeBillerResponseData();
        largeBillerResponseData.setNetworkId("netwId");
        largeBillerResponseDataList.add(largeBillerResponseData);
        doReturn(largeBillerResponseDataList).when(largeBillerResponse).getData();
        RetryService retryService = Mockito.mock(RetryService.class);
        achLargePayeeManager.setRetryService(retryService);
        doReturn(largeBillerResponseEntity).when(retryService).exchange(eq("https://serviceurl?olbClientId=abcd1234&addressZip=95000&searchString=name"), any(HttpMethod.class), ArgumentMatchers.isA(HttpEntity.class), any());


        // 2nd call
        ResponseEntity<LargeBillerInformationResponse> largeBillerInformationResponseEntity = Mockito.mock(ResponseEntity.class);
        doReturn(HttpStatus.OK).when(largeBillerInformationResponseEntity).getStatusCode();
        LargeBillerInformationResponse largeBillerInformationResponse = Mockito.mock(LargeBillerInformationResponse.class);
        doReturn(largeBillerInformationResponse).when(largeBillerInformationResponseEntity).getBody();
        List<LargeBillerInformationResponseData> largeBillerInformationResponseDataList = new ArrayList<LargeBillerInformationResponseData>();
        LargeBillerInformationResponseData largeBillerInformationResponseData = new LargeBillerInformationResponseData();
        largeBillerInformationResponseDataList.add(largeBillerInformationResponseData);
        doReturn(largeBillerInformationResponseDataList).when(largeBillerInformationResponse).getData();
        doReturn(largeBillerInformationResponseEntity).when(retryService).exchange(eq("https://serviceurl/netwId/addresses?olbClientId=abcd1234&addressZip=95000&searchString=name"), any(HttpMethod.class), any(HttpEntity.class), any());
        achLargePayeeManager.fetchBillerNetworkUrl = "https://serviceurl";
        EntityWrapper entityWrapper = new EntityWrapper(stgBeneficiary);
        List<PaymentDetail> payments = achLargePayeeManager.getPaymentDetails(entityWrapper, migClient, accountDetails, null);

        assertEquals("fethcing large biller error code 503 SERVICE_UNAVAILABLE", entityWrapper.unexpectedErrorList.get(0).getDescription());

    }

    @Test
    void addBeneficiaries_ACHLargePayeeManagerFailure2() {
        StgToTargetBeneEntity stgBeneficiary = new StgToTargetBeneEntity();
        stgBeneficiary.setBENEFICIARY_ACCOUNT("1234");
        stgBeneficiary.setBENEFICIARY_NAME("name");
        stgBeneficiary.setPAYEE_ZIP_CODE("95000");
        MigClient migClient = new MigClient();
        migClient.setGwClientId("abcd1234");
        AccountDetails accountDetails = new AccountDetails();

        ResponseEntity<LargeBillerResponse> largeBillerResponseEntity = Mockito.mock(ResponseEntity.class);

        // 1st call
        doReturn(HttpStatus.OK).when(largeBillerResponseEntity).getStatusCode();
        LargeBillerResponse largeBillerResponse = Mockito.mock(LargeBillerResponse.class);
        doReturn(largeBillerResponse).when(largeBillerResponseEntity).getBody();
        List<LargeBillerResponseData> largeBillerResponseDataList = new ArrayList<LargeBillerResponseData>();
        LargeBillerResponseData largeBillerResponseData = new LargeBillerResponseData();
        largeBillerResponseData.setNetworkId("netwId");
        largeBillerResponseDataList.add(largeBillerResponseData);
        doReturn(largeBillerResponseDataList).when(largeBillerResponse).getData();
        RetryService retryService = Mockito.mock(RetryService.class);
        achLargePayeeManager.setRetryService(retryService);
        doReturn(largeBillerResponseEntity).when(retryService).exchange(eq("https://serviceurl?olbClientId=abcd1234&addressZip=95000&searchString=name"), any(HttpMethod.class), any(HttpEntity.class), any());


        // 2nd call
        ResponseEntity<LargeBillerInformationResponse> largeBillerInformationResponseEntity = Mockito.mock(ResponseEntity.class);
        doReturn(HttpStatus.SERVICE_UNAVAILABLE).when(largeBillerInformationResponseEntity).getStatusCode();
        LargeBillerInformationResponse largeBillerInformationResponse = Mockito.mock(LargeBillerInformationResponse.class);
        doReturn(largeBillerInformationResponse).when(largeBillerInformationResponseEntity).getBody();
        List<LargeBillerInformationResponseData> largeBillerInformationResponseDataList = new ArrayList<LargeBillerInformationResponseData>();
        LargeBillerInformationResponseData largeBillerInformationResponseData = new LargeBillerInformationResponseData();
        // largeBillerInformationResponse.getData().get(0).getAddressId()
        largeBillerInformationResponseDataList.add(largeBillerInformationResponseData);
        doReturn(largeBillerInformationResponseDataList).when(largeBillerInformationResponse).getData();
        doReturn(largeBillerInformationResponseEntity).when(retryService).exchange(eq("https://serviceurl/netwId/addresses?olbClientId=abcd1234&addressZip=95000&searchString=name"), any(HttpMethod.class), any(HttpEntity.class), any());
        achLargePayeeManager.fetchBillerNetworkUrl = "https://serviceurl";
        EntityWrapper entityWrapper = new EntityWrapper(stgBeneficiary);
        migClient.setEcClientId(migratingClientId);
        List<PaymentDetail> payments = achLargePayeeManager.getPaymentDetails(entityWrapper, migClient, accountDetails, null);
        assertTrue(entityWrapper.hasUnexpectedErrors());
        assertEquals("fethcing information for large biller error code 503 SERVICE_UNAVAILABLE", entityWrapper.getUnexpectedErrorList().get(0).getDescription());
    }

    @Test
    void addBeneficiaries_benfClient_noPrimaryUserMigratedCheck() {
        MigClient migClient = new MigClient();
        migClient.setEcClientId("medi4798");
        migClient.setGwClientId("GWaddr1234");
        migClient.setPrimaryCifCbs(Long.valueOf("123456"));
        migClient.setJobId(123L);
        when(migClientRepository.findByEcClientIdSuccess(anyString())).thenReturn(migClient);
        when(migUserRepository.getMigratedPrimaryUser(anyString())).thenReturn(null);
        MigBeneResponse response = beneficiariesService.addBeneficiaries(1L, migClient, TEMPLATE);
        String expectedMessage = "benfClientId has no primary user";
        String actualMessage = response.getMessage();

        assertTrue(actualMessage.contains(expectedMessage));
    }

    @Test
    void addBeneficiaries_benfClient_noStgBenfDataEmptyList() throws Exception {
        MigClient migClient = new MigClient();
        migClient.setEcClientId("medi4798");
        migClient.setGwClientId("GWaddr1234");
        migClient.setJobId(Long.valueOf("1234"));
        migClient.setPrimaryCifUbs(Integer.valueOf("12312312"));
        MigUser migUser = new MigUser();
        migUser.setGwClientId("GWaddr1234");
        migUser.setGwUuid("b01eb56652f046328b933ecdf4ba0374");

        when(migClientRepository.findByEcClientIdSuccess(anyString())).thenReturn(migClient);
        when(migUserRepository.getMigratedPrimaryUser(anyString())).thenReturn(migUser);
        List<StgToTargetBeneEntity> stgToTargetBeneEntities = new ArrayList<>();
        when(beneficiaryMapper.findByOlbClientIdTemplates(anyString())).thenReturn(stgToTargetBeneEntities);
        MigBeneResponse serviceResponse = beneficiariesService.addBeneficiaries(1L, migClient, TEMPLATE);
        String expectedMessage = "No Benes present for provided client Id";
        String actualMessage = serviceResponse.getMessage();

        assertTrue(actualMessage.contains(expectedMessage));
    }

    @Test
    void addBeneficiaries_benfClient_noStgBenfDataEmptyListPastFreeForm() throws Exception {
        MigClient migClient = new MigClient();
        migClient.setEcClientId("medi4798");
        migClient.setGwClientId("GWaddr1234");
        migClient.setJobId(Long.valueOf("1234"));
        migClient.setPrimaryCifUbs(Integer.valueOf("12312312"));
        MigUser migUser = new MigUser();
        migUser.setGwClientId("GWaddr1234");
        migUser.setGwUuid("b01eb56652f046328b933ecdf4ba0374");

        when(migClientRepository.findByEcClientIdSuccess(anyString())).thenReturn(migClient);
        when(migUserRepository.getMigratedPrimaryUser(anyString())).thenReturn(migUser);
        List<StgToTargetBeneEntity> stgToTargetBeneEntities = new ArrayList<>();
        when(beneficiaryMapper.findByOlbClientIdPastFreeForm(anyString())).thenReturn(stgToTargetBeneEntities);
        MigBeneResponse serviceResponse = beneficiariesService.addBeneficiaries(1L, migClient, PAST);

        String expectedMessage = "No Benes present for provided client Id";
        String actualMessage = serviceResponse.getMessage();

        assertTrue(actualMessage.contains(expectedMessage));
    }

    @Test
    void addBeneficiaries_benfClient_noStgBenfDataEmptyListFutureFreeForm() throws Exception {
        MigClient migClient = new MigClient();
        migClient.setEcClientId("medi4798");
        migClient.setGwClientId("GWaddr1234");
        migClient.setJobId(Long.valueOf("1234"));
        migClient.setPrimaryCifUbs(Integer.valueOf("12312312"));
        MigUser migUser = new MigUser();
        migUser.setGwClientId("GWaddr1234");
        migUser.setGwUuid("b01eb56652f046328b933ecdf4ba0374");

        when(migClientRepository.findByEcClientIdSuccess(anyString())).thenReturn(migClient);
        when(migUserRepository.getMigratedPrimaryUser(anyString())).thenReturn(migUser);
        List<StgToTargetBeneEntity> stgToTargetBeneEntities = new ArrayList<>();
        when(beneficiaryMapper.findByOlbClientIdFutureFreeForm(anyString())).thenReturn(stgToTargetBeneEntities);
        MigBeneResponse serviceResponse = beneficiariesService.addBeneficiaries(1L, migClient, FUTURE);
        String expectedMessage = "No Benes present for provided client Id";
        String actualMessage = serviceResponse.getMessage();

        assertTrue(actualMessage.contains(expectedMessage));
    }

    @Test
    void addBeneficiaries_benfClient_noStgBenfDataEmptyListIpayCheck() throws Exception {
        MigClient migClient = new MigClient();
        migClient.setEcClientId("medi4798");
        migClient.setGwClientId("GWaddr1234");
        migClient.setJobId(Long.valueOf("1234"));
        migClient.setPrimaryCifUbs(Integer.valueOf("12312312"));
        MigUser migUser = new MigUser();
        migUser.setGwClientId("GWaddr1234");
        migUser.setGwUuid("b01eb56652f046328b933ecdf4ba0374");

        when(migClientRepository.findByEcClientIdSuccess(anyString())).thenReturn(migClient);
        when(migUserRepository.getMigratedPrimaryUser(anyString())).thenReturn(migUser);
        List<StgToTargetBeneEntity> stgToTargetBeneEntities = new ArrayList<>();
        when(beneficiaryMapper.findByOlbClientIdIpayPayees(any())).thenReturn(stgToTargetBeneEntities);
        MigBeneResponse serviceResponse = beneficiariesService.addBeneficiaries(1L, migClient, CHECK);
        String expectedMessage = "No Benes present for provided client Id";
        String actualMessage = serviceResponse.getMessage();

        assertTrue(actualMessage.contains(expectedMessage));
    }

    @Test
    void addBeneficiaries_benfClient_noStgBenfDataEmptyListIpayACH() throws Exception {
        MigClient migClient = new MigClient();
        migClient.setEcClientId("medi4798");
        migClient.setGwClientId("GWaddr1234");
        migClient.setJobId(Long.valueOf("1234"));
        migClient.setPrimaryCifUbs(Integer.valueOf("12312312"));
        MigUser migUser = new MigUser();
        migUser.setGwClientId("GWaddr1234");
        migUser.setGwUuid("b01eb56652f046328b933ecdf4ba0374");

        when(migClientRepository.findByEcClientIdSuccess(anyString())).thenReturn(migClient);
        when(migUserRepository.getMigratedPrimaryUser(anyString())).thenReturn(migUser);
        List<StgToTargetBeneEntity> stgToTargetBeneEntities = new ArrayList<>();
        when(beneficiaryMapper.findByOlbClientIdFutureFreeForm(anyString())).thenReturn(stgToTargetBeneEntities);
        MigBeneResponse serviceResponse = beneficiariesService.addBeneficiaries(1L, migClient, ACH);
        String expectedMessage = "No Benes present for provided client Id";
        String actualMessage = serviceResponse.getMessage();

        assertTrue(actualMessage.contains(expectedMessage));
    }

    @Test
    void addBeneficiaries_benfClient_noStgBenfDataEmptyListNoTypeMatch() throws Exception {
        MigClient migClient = new MigClient();
        migClient.setEcClientId("medi4798");
        migClient.setGwClientId("GWaddr1234");
        migClient.setJobId(Long.valueOf("1234"));
        migClient.setPrimaryCifUbs(Integer.valueOf("12312312"));
        MigUser migUser = new MigUser();
        migUser.setGwClientId("GWaddr1234");
        migUser.setGwUuid("b01eb56652f046328b933ecdf4ba0374");

        when(migClientRepository.findByEcClientIdSuccess(anyString())).thenReturn(migClient);
        when(migUserRepository.getMigratedPrimaryUser(anyString())).thenReturn(migUser);
        List<StgToTargetBeneEntity> stgToTargetBeneEntities = new ArrayList<>();
        when(beneficiaryMapper.findByOlbClientIdFutureFreeForm(anyString())).thenReturn(stgToTargetBeneEntities);
        MigBeneResponse serviceResponse = beneficiariesService.addBeneficiaries(1L, migClient, ACH_LARGE);
        String expectedMessage = "No Benes present for provided client Id";
        String actualMessage = serviceResponse.getMessage();

        assertTrue(actualMessage.contains(expectedMessage));
    }

    @Test
    void addBeneficiaries_benfClient_noStgBenfData() throws Exception {
        MigClient migClient = new MigClient();
        migClient.setEcClientId("medi4798");
        migClient.setGwClientId("GWaddr1234");
        migClient.setJobId(Long.valueOf("1234"));
        migClient.setPrimaryCifUbs(Integer.valueOf("12312312"));
        MigUser migUser = new MigUser();
        migUser.setGwClientId("GWaddr1234");
        migUser.setGwUuid("b01eb56652f046328b933ecdf4ba0374");

        when(migClientRepository.findByEcClientIdSuccess(anyString())).thenReturn(migClient);
        when(migUserRepository.getMigratedPrimaryUser(anyString())).thenReturn(migUser);
        when(beneficiaryRepository.findByOlbClientIdTemplates(anyString())).thenReturn(null);
        MigBeneResponse serviceResponse = beneficiariesService.addBeneficiaries(1L, migClient, TEMPLATE);
        String expectedMessage = "No Benes present for provided client Id";
        String actualMessage = serviceResponse.getMessage();

        assertTrue(actualMessage.contains(expectedMessage));
    }

    @Test
    void addBeneficiaries_successwithAlreadyMigratedTemplate() throws Exception {

        MigClient migClient = new MigClient();
        migClient.setEcClientId("medi4798");
        migClient.setGwClientId("GWaddr1234");
        migClient.setPrimaryCifUbs(Integer.valueOf("12312312"));
        migClient.setJobId(Long.valueOf("123"));

        MigUser migUser = new MigUser();
        migUser.setGwClientId("GWaddr1234");
        migUser.setGwUuid("b01eb56652f046328b933ecdf4ba0374");


        List<StgToTargetBeneEntity> stgToTargetBeneEntities = new ArrayList<>();
        StgToTargetBeneEntity stgToTargetBeneEntity = new StgToTargetBeneEntity();
        stgToTargetBeneEntity.setOLB_CLIENT_ID("medi4798");
        stgToTargetBeneEntity.setTEMPLATE_ID(1234);
        stgToTargetBeneEntity.setBENEFICIARY_ACCOUNT("12345678");
        stgToTargetBeneEntities.add(stgToTargetBeneEntity);

        MigBeneficiary migBeneficiary = new MigBeneficiary();
        migBeneficiary.setStatus("Success");

        List<MigBeneficiary> migratedRecords = new ArrayList<>();
        migratedRecords.add(migBeneficiary);

        MigBeneResponse migBeneResponseSample = new MigBeneResponse();
        migBeneResponseSample.setGwClientId("GWaddr1234");
        migBeneResponseSample.setNoOfSuccessRecords(0);
        migBeneResponseSample.setNoOfFailedRecords(0);
        migBeneResponseSample.setNoOfAlreadyMigratedRecords(1);

        ResultRecords resultRecords = new ResultRecords();
        resultRecords.setComments("Created during previous Job executions. Job Id: null");
        resultRecords.setTemplateId(1234);
        resultRecords.setStatus("Already migrated");
        List<ResultRecords> rr = new ArrayList<>();
        rr.add(resultRecords);
        migBeneResponseSample.setResultRecords(rr);

        when(jdbcTemplate.update(anyString(), any(Map.class))).thenReturn(0);
        when(migClientRepository.findByEcClientIdSuccess(anyString())).thenReturn(migClient);
        when(migUserRepository.getMigratedPrimaryUser(anyString())).thenReturn(migUser);
        when(beneficiaryMapper.findByOlbClientIdTemplates(anyString())).thenReturn(stgToTargetBeneEntities);
        oauthResponse = new OauthResponse();
        oauthResponse.setAccess_token("e2561beef23920c18902ada758a1118de96be728add38b1a04acb2d911845352");
        when(gatewayOAuthRepository.getUserAccessToken(userType)).thenReturn(oauthResponse);
        when(migBeneficiaryRepository.findByTemplateIdMigratedOrIgnored(anyLong(), Mockito.anyInt())).thenReturn(migratedRecords);
        MigBeneResponse migBeneResponse = beneficiariesService.addBeneficiaries(1L, migClient, TEMPLATE);

        assertTrue(1 == migBeneResponse.getNoOfAlreadyMigratedRecords());

    }

    @Test
    void addBeneficiaries_successwithStgDuplicateCheck() throws Exception {

        MigClient migClient = new MigClient();
        migClient.setEcClientId("medi4798");
        migClient.setGwClientId("GWaddr1234");
        migClient.setPrimaryCifUbs(Integer.valueOf("12312312"));
        migClient.setJobId(Long.valueOf("123"));

        MigUser migUser = new MigUser();
        migUser.setGwClientId("GWaddr1234");
        migUser.setGwUuid("b01eb56652f046328b933ecdf4ba0374");

        List<StgToTargetBeneEntity> stgToTargetBeneEntities = new ArrayList<>();
        StgToTargetBeneEntity stgToTargetBeneEntity = new StgToTargetBeneEntity();
        stgToTargetBeneEntity.setOLB_CLIENT_ID("medi4798");
        stgToTargetBeneEntity.setTEMPLATE_ID(1234);
        stgToTargetBeneEntity.setBENEFICIARY_ACCOUNT("12345678");
        stgToTargetBeneEntity.setELECTRONIC_INDICATOR("Y");
        stgToTargetBeneEntities.add(stgToTargetBeneEntity);
        stgToTargetBeneEntities.add(stgToTargetBeneEntity);


        MigBeneficiary migBeneficiary = new MigBeneficiary();
        migBeneficiary.setStatus("Success");

        List<MigBeneficiary> migratedRecords = new ArrayList<>();
        migratedRecords.add(migBeneficiary);

        MigBeneResponse migBeneResponseSample = new MigBeneResponse();
        migBeneResponseSample.setGwClientId("GWaddr1234");
        migBeneResponseSample.setNoOfSuccessRecords(0);
        migBeneResponseSample.setNoOfFailedRecords(0);
        migBeneResponseSample.setNoOfAlreadyMigratedRecords(1);

        ResultRecords resultRecords = new ResultRecords();
        resultRecords.setComments("Created during previous Job executions. Job Id: null");
        resultRecords.setTemplateId(1234);
        resultRecords.setStatus("Already migrated");
        List<ResultRecords> rr = new ArrayList<>();
        rr.add(resultRecords);
        migBeneResponseSample.setResultRecords(rr);

        when(jdbcTemplate.update(anyString(), any(Map.class))).thenReturn(0);
        when(migClientRepository.findByEcClientIdSuccess(anyString())).thenReturn(migClient);
        when(migUserRepository.getMigratedPrimaryUser(anyString())).thenReturn(migUser);
        when(beneficiaryMapper.findByOlbClientIdTemplates(anyString())).thenReturn(stgToTargetBeneEntities);
        oauthResponse = new OauthResponse();
        oauthResponse.setAccess_token("e2561beef23920c18902ada758a1118de96be728add38b1a04acb2d911845352");
        when(gatewayOAuthRepository.getUserAccessToken(userType)).thenReturn(oauthResponse);
        when(migBeneficiaryRepository.findByTemplateIdMigratedOrIgnored(anyLong(), anyInt())).thenReturn(migratedRecords);
        beneficiariesService.migUserPrincipal = migUserPrincipal;
        MigBeneResponse migBeneResponse = beneficiariesService.addBeneficiaries(1L, migClient, TEMPLATE);

        assertEquals(2, migBeneResponse.getNoOfAlreadyMigratedRecords());

    }

    @Test
    void addBeneficiaries_successwithStgDuplicateCheckForFutureBene() throws Exception {

        MigClient migClient = new MigClient();
        migClient.setEcClientId("medi4798");
        migClient.setGwClientId("GWaddr1234");
        migClient.setPrimaryCifUbs(Integer.valueOf("12312312"));
        migClient.setJobId(Long.valueOf("123"));

        MigUser migUser = new MigUser();
        migUser.setGwClientId("GWaddr1234");
        migUser.setGwUuid("b01eb56652f046328b933ecdf4ba0374");

        List<StgToTargetBeneEntity> stgToTargetBeneEntities = new ArrayList<>();
        StgToTargetBeneEntity stgToTargetBeneEntity = new StgToTargetBeneEntity();
        stgToTargetBeneEntity.setOLB_CLIENT_ID("medi4798");
        stgToTargetBeneEntity.setWIRE_TRANSACTION_ID(1234);
        stgToTargetBeneEntity.setBENEFICIARY_ACCOUNT("12345678");
        stgToTargetBeneEntity.setELECTRONIC_INDICATOR("Y");
        stgToTargetBeneEntities.add(stgToTargetBeneEntity);
        stgToTargetBeneEntities.add(stgToTargetBeneEntity);


        MigBeneficiary migBeneficiary = new MigBeneficiary();
        migBeneficiary.setStatus("Success");

        List<MigBeneficiary> migratedRecords = new ArrayList<>();
        migratedRecords.add(migBeneficiary);

        MigBeneResponse migBeneResponseSample = new MigBeneResponse();
        migBeneResponseSample.setGwClientId("GWaddr1234");
        migBeneResponseSample.setNoOfSuccessRecords(0);
        migBeneResponseSample.setNoOfFailedRecords(0);
        migBeneResponseSample.setNoOfAlreadyMigratedRecords(1);

        ResultRecords resultRecords = new ResultRecords();
        resultRecords.setComments("Created during previous Job executions. Job Id: null");
        resultRecords.setTemplateId(1234);
        resultRecords.setStatus("Already migrated");
        List<ResultRecords> rr = new ArrayList<>();
        rr.add(resultRecords);
        migBeneResponseSample.setResultRecords(rr);

        when(jdbcTemplate.update(anyString(), any(Map.class))).thenReturn(0);
        when(migClientRepository.findByEcClientIdSuccess(anyString())).thenReturn(migClient);
        when(migUserRepository.getMigratedPrimaryUser(anyString())).thenReturn(migUser);
        when(beneficiaryMapper.findByOlbClientIdFutureFreeForm(anyString())).thenReturn(stgToTargetBeneEntities);
        oauthResponse = new OauthResponse();
        oauthResponse.setAccess_token("e2561beef23920c18902ada758a1118de96be728add38b1a04acb2d911845352");
        when(gatewayOAuthRepository.getUserAccessToken(userType)).thenReturn(oauthResponse);
        when(migBeneficiaryRepository.findByWireTxnIdMigratedOrIgnored(anyLong(), Mockito.anyInt())).thenReturn(migratedRecords);
        MigBeneResponse migBeneResponse = beneficiariesService.addBeneficiaries(1L, migClient, FUTURE);

        assertEquals(2, migBeneResponse.getNoOfAlreadyMigratedRecords());

    }

    @Test
    void addBeneficiaries_successwithStgDuplicateCheckForIpayBene() throws Exception {

        MigClient migClient = new MigClient();
        migClient.setEcClientId("medi4798");
        migClient.setGwClientId("GWaddr1234");
        migClient.setPrimaryCifUbs(Integer.valueOf("12312312"));
        migClient.setJobId(Long.valueOf("123"));

        MigUser migUser = new MigUser();
        migUser.setGwClientId("GWaddr1234");
        migUser.setGwUuid("b01eb56652f046328b933ecdf4ba0374");

        List<StgToTargetBeneEntity> stgToTargetBeneEntities = new ArrayList<>();
        StgToTargetBeneEntity stgToTargetBeneEntity = new StgToTargetBeneEntity();
        stgToTargetBeneEntity.setOLB_CLIENT_ID("medi4798");
        stgToTargetBeneEntity.setIPAYEE_BENE_ID(1234);
        stgToTargetBeneEntity.setBENEFICIARY_ACCOUNT("12345678");
        stgToTargetBeneEntity.setELECTRONIC_INDICATOR("N");
        stgToTargetBeneEntities.add(stgToTargetBeneEntity);
        stgToTargetBeneEntities.add(stgToTargetBeneEntity);


        MigBeneficiary migBeneficiary = new MigBeneficiary();
        migBeneficiary.setStatus("Success");

        List<MigBeneficiary> migratedRecords = new ArrayList<>();
        migratedRecords.add(migBeneficiary);

        MigBeneResponse migBeneResponseSample = new MigBeneResponse();
        migBeneResponseSample.setGwClientId("GWaddr1234");
        migBeneResponseSample.setNoOfSuccessRecords(0);
        migBeneResponseSample.setNoOfFailedRecords(0);
        migBeneResponseSample.setNoOfAlreadyMigratedRecords(1);

        ResultRecords resultRecords = new ResultRecords();
        resultRecords.setComments("Created during previous Job executions. Job Id: null");
        resultRecords.setIPayBeneId(1234);
        resultRecords.setStatus("Already migrated");
        List<ResultRecords> rr = new ArrayList<>();
        rr.add(resultRecords);
        migBeneResponseSample.setResultRecords(rr);

        when(jdbcTemplate.update(anyString(), any(Map.class))).thenReturn(0);
        when(migClientRepository.findByEcClientIdSuccess(anyString())).thenReturn(migClient);
        //when(beneficiaryMapper.findByOlbClientIdIpayPayeesForCHK(Mockito.anyString())).thenReturn(stgToTargetBeneEntities);
        when(beneficiaryMapper.findByOlbClientIdIpayPayees(any(SelectConditions.class))).thenReturn(stgToTargetBeneEntities);
        //findByOlbClientIdIpayPayees
        oauthResponse = new OauthResponse();
        oauthResponse.setAccess_token("e2561beef23920c18902ada758a1118de96be728add38b1a04acb2d911845352");
        when(gatewayOAuthRepository.getUserAccessToken(userType)).thenReturn(oauthResponse);
        when(migBeneficiaryRepository.findByIpayBeneIDMigratedOrIgnored(anyLong(), Mockito.anyInt())).thenReturn(migratedRecords);
        MigBeneResponse migBeneResponse = beneficiariesService.addBeneficiaries(1L, migClient, CHECK);

        assertEquals(2, migBeneResponse.getNoOfAlreadyMigratedRecords());

    }

    @Test
    void addBeneficiaries_success() throws Exception {

        MigClient migClient = new MigClient();
        migClient.setEcClientId("medi4798");
        migClient.setGwClientId("GWaddr1234");
        migClient.setPrimaryCifUbs(Integer.valueOf("12312312"));
        migClient.setJobId(Long.valueOf("123"));

        MigUser migUser = new MigUser();
        migUser.setGwClientId("GWaddr1234");
        migUser.setGwUuid("b01eb56652f046328b933ecdf4ba0374");

        List<StgToTargetBeneEntity> stgToTargetBeneEntities = new ArrayList<>();
        StgToTargetBeneEntity stgToTargetBeneEntity = getDefaultStgToTargetBeneEntity();
        stgToTargetBeneEntities.add(stgToTargetBeneEntity);

        MigBeneficiary migBeneficiary = new MigBeneficiary();
        migBeneficiary.setStatus("Success");

        List<MigBeneficiary> migratedRecords = new ArrayList<>();


        AddBeneficiaryResponse addBeneficiaryResponse = new AddBeneficiaryResponse();
        AddBeneficiaryResponseData addBeneficiaryResponseData = new AddBeneficiaryResponseData();
        Status status = new Status();

        status.setCodeDescription("Success");
        addBeneficiaryResponseData.setStatus(status);

        List<ResponsePaymentDetail> paymentDetails = new ArrayList<>();
        ResponsePaymentDetail responsePaymentDetail = new ResponsePaymentDetail();
        responsePaymentDetail.setCounterpartyId("1234");
        responsePaymentDetail.setPayeeListId("5678");
        paymentDetails.add(responsePaymentDetail);

        addBeneficiaryResponseData.setPaymentDetails(paymentDetails);
        addBeneficiaryResponse.setData(addBeneficiaryResponseData);

        when(jdbcTemplate.update(anyString(), any(Map.class))).thenReturn(0);
        when(migClientRepository.findByEcClientIdSuccess(anyString())).thenReturn(migClient);
        when(beneficiaryMapper.findByOlbClientIdTemplates(anyString())).thenReturn(stgToTargetBeneEntities);
        oauthResponse = new OauthResponse();
        oauthResponse.setAccess_token("e2561beef23920c18902ada758a1118de96be728add38b1a04acb2d911845352");
        when(gatewayOAuthRepository.getUserAccessToken(userType)).thenReturn(oauthResponse);
        when(migBeneficiaryRepository.findByTemplateIdMigratedOrIgnored(anyLong(), Mockito.anyInt())).thenReturn(migratedRecords);
        beneficiariesService.migUserPrincipal = migUserPrincipal;
        EntityWrapper entityWrapper = new EntityWrapper(stgToTargetBeneEntity);
        entityWrapper.gatewayMigrationResponse = addBeneficiaryResponse;
        doReturn(getBankBranchResponse("IT")).when(beneficiaryValidationUtility).validateBankBranchAndFetchList(any());
        doReturn(getIbanCountryRulesResponse("X")).when(beneficiaryValidationUtility).validateIbanCountrySpecificRulesAndValidation(any(), any(), anyLong(), anyString());
        doReturn(entityWrapper).when(templatePayeeManager).migrateBeneficiaryToGateway(any(EntityWrapper.class), any(ProcessingContext.class));

        MigBeneResponse migBeneResponse = beneficiariesService.addBeneficiaries(1L, migClient, TEMPLATE);

        assertTrue(1 == migBeneResponse.getNoOfSuccessRecords());

    }

    private IbanCountryRulesResponse getIbanCountryRulesResponse(String ibanRequired) {
        IbanCountryRulesResponse ibanCountryRulesResponse = new IbanCountryRulesResponse();
        ibanCountryRulesResponse.setValidated(true);
        IbanCountryRulesResponseData data = new IbanCountryRulesResponseData();
        BeneIbanAccountRule account = new BeneIbanAccountRule();
        account.setIbanRequired(ibanRequired);
        data.setBeneficaryAccount(account);
        ibanCountryRulesResponse.setData(data);
        return ibanCountryRulesResponse;
    }

    private BankBranchResponse getBankBranchResponse(String cm) {
        BankBranchResponse bankBranchResponse = new BankBranchResponse();
        if(cm == "IT") {

            bankBranchResponse.setValidated(true);
            BankBranchResponseData branchData = new BankBranchResponseData();
            BranchAddress address = new BranchAddress();
            Country country = new Country();
            country.setCmCode(cm);
            address.setCountry(country);
            branchData.setBranchAddress(address);
            List branchDataList = new ArrayList();
            branchDataList.add(branchData);
            bankBranchResponse.setData(branchDataList);
            return bankBranchResponse;
        }
        else{

            bankBranchResponse.setValidated(true);
            BankBranchResponseData branchData = new BankBranchResponseData();
            BranchAddress address = new BranchAddress();
            Country country = new Country();
            country.setCmCode(cm);
            address.setCountry(country);
            address.setCity("SANTACLARA");
            branchData.setBranchAddress(address);
            List branchDataList = new ArrayList();
            branchDataList.add(branchData);
            branchDataList.add(branchData);
            bankBranchResponse.setData(branchDataList);

            return bankBranchResponse;
        }
    }

    @Test
    void addBeneficiariesOfPastTxns_success() throws Exception {

        MigClient migClient = new MigClient();
        migClient.setEcClientId("medi4798");
        migClient.setGwClientId("GWaddr1234");
        migClient.setPrimaryCifUbs(Integer.valueOf("12312312"));
        migClient.setJobId(jobId);

        List<StgToTargetBeneEntity> stgToTargetBeneEntities = new ArrayList<>();
        StgToTargetBeneEntity stgToTargetBeneEntity = new StgToTargetBeneEntity();
        stgToTargetBeneEntity.setOLB_CLIENT_ID("medi4798");
        stgToTargetBeneEntity.setWIRE_TRANSACTION_ID(1234);
        stgToTargetBeneEntity.setBENEFICIARY_ACCOUNT("12345678");
        stgToTargetBeneEntity.setELECTRONIC_INDICATOR("Y");
        stgToTargetBeneEntity.setJOB_ID(jobId);
        stgToTargetBeneEntities.add(stgToTargetBeneEntity);

        MigBeneficiary migBeneficiary = new MigBeneficiary();
        migBeneficiary.setStatus("Success");

        List<MigBeneficiary> migratedRecords = new ArrayList<>();


        AddBeneficiaryResponse addBeneficiaryResponse = new AddBeneficiaryResponse();
        AddBeneficiaryResponseData addBeneficiaryResponseData = new AddBeneficiaryResponseData();
        Status status = new Status();

        status.setCodeDescription("Success");
        addBeneficiaryResponseData.setStatus(status);

        List<ResponsePaymentDetail> paymentDetails = new ArrayList<>();
        ResponsePaymentDetail responsePaymentDetail = new ResponsePaymentDetail();
        responsePaymentDetail.setCounterpartyId("1234");
        responsePaymentDetail.setPayeeListId("5678");
        paymentDetails.add(responsePaymentDetail);
        addBeneficiaryResponseData.setPaymentDetails(paymentDetails);
        addBeneficiaryResponse.setData(addBeneficiaryResponseData);


        when(migClientRepository.findByEcClientIdSuccess(anyString())).thenReturn(migClient);
//        when(migUserRepository.getMigratedPrimaryUser(Mockito.anyString())).thenReturn(migUser);
        when(jdbcTemplate.update(anyString(), any(Map.class))).thenReturn(0);
        when(beneficiaryMapper.findByOlbClientIdPastFreeForm(anyString())).thenReturn(stgToTargetBeneEntities);
        oauthResponse = new OauthResponse();
        oauthResponse.setAccess_token("e2561beef23920c18902ada758a1118de96be728add38b1a04acb2d911845352");
        when(gatewayOAuthRepository.getUserAccessToken(userType)).thenReturn(oauthResponse);
        when(migBeneficiaryRepository.findByTemplateIdMigratedOrIgnored(anyLong(), Mockito.anyInt())).thenReturn(migratedRecords);
        beneficiariesService.migUserPrincipal = migUserPrincipal;
        EntityWrapper entityWrapper = new EntityWrapper(stgToTargetBeneEntity);
        entityWrapper.gatewayMigrationResponse = addBeneficiaryResponse;
        doReturn(getBankBranchResponse("IT")).when(beneficiaryValidationUtility).validateBankBranchAndFetchList(any());
        doReturn(getIbanCountryRulesResponse("X")).when(beneficiaryValidationUtility).validateIbanCountrySpecificRulesAndValidation(any(), any(), anyLong(), anyString());
        doReturn(entityWrapper).when(wirePayeeManager).migrateBeneficiaryToGateway(any(EntityWrapper.class), any(ProcessingContext.class));

        MigBeneResponse migBeneResponse = beneficiariesService.addBeneficiaries(1L, migClient, PAST);

        assertTrue(1 == migBeneResponse.getNoOfSuccessRecords());

    }

    @Test
    void addBeneficiaries_failedAtOch() throws Exception {

        MigClient migClient = new MigClient();
        migClient.setEcClientId("medi4798");
        migClient.setGwClientId("GWaddr1234");
        migClient.setPrimaryCifUbs(Integer.valueOf("12312312"));
        migClient.setJobId(Long.valueOf("123"));

        MigUser migUser = new MigUser();
        migUser.setGwClientId("GWaddr1234");
        migUser.setGwUuid("b01eb56652f046328b933ecdf4ba0374");

        List<StgToTargetBeneEntity> stgToTargetBeneEntities = new ArrayList<>();
        StgToTargetBeneEntity stgToTargetBeneEntity = new StgToTargetBeneEntity();
        stgToTargetBeneEntity.setOLB_CLIENT_ID("medi4798");
        stgToTargetBeneEntity.setWIRE_TRANSACTION_ID(1234);
        stgToTargetBeneEntity.setBENEFICIARY_ACCOUNT("12345678");
        stgToTargetBeneEntity.setELECTRONIC_INDICATOR("Y");
        stgToTargetBeneEntity.setJOB_ID(jobId);
        stgToTargetBeneEntities.add(stgToTargetBeneEntity);

        MigBeneficiary migBeneficiary = new MigBeneficiary();
        migBeneficiary.setStatus("Success");

        List<MigBeneficiary> migratedRecords = new ArrayList<>();

        AddBeneficiaryResponse addBeneficiaryResponse = new AddBeneficiaryResponse();

        when(jdbcTemplate.update(anyString(), any(Map.class))).thenReturn(0);
        when(migClientRepository.findByEcClientIdSuccess(anyString())).thenReturn(migClient);
        when(migUserRepository.getMigratedPrimaryUser(anyString())).thenReturn(migUser);
        when(beneficiaryMapper.findByOlbClientIdFutureFreeForm(anyString())).thenReturn(stgToTargetBeneEntities);
        oauthResponse = new OauthResponse();
        oauthResponse.setAccess_token("e2561beef23920c18902ada758a1118de96be728add38b1a04acb2d911845352");
        when(gatewayOAuthRepository.getUserAccessToken(userType)).thenReturn(oauthResponse);
        when(migBeneficiaryRepository.findByWireTxnIdMigratedOrIgnored(anyLong(), Mockito.anyInt())).thenReturn(migratedRecords);
        beneficiariesService.migUserPrincipal = migUserPrincipal;
        EntityWrapper entityWrapper = new EntityWrapper(stgToTargetBeneEntity);
        entityWrapper.addUnexpectedError("source", "Error");
        entityWrapper.gatewayMigrationResponse = addBeneficiaryResponse;
        doReturn(getBankBranchResponse("IT")).when(beneficiaryValidationUtility).validateBankBranchAndFetchList(any());
        doReturn(getIbanCountryRulesResponse("X")).when(beneficiaryValidationUtility).validateIbanCountrySpecificRulesAndValidation(any(), any(), anyLong(), anyString());
        doReturn(entityWrapper).when(wirePayeeManager).migrateBeneficiaryToGateway(any(EntityWrapper.class), any(ProcessingContext.class));

        MigBeneResponse migBeneResponse = beneficiariesService.addBeneficiaries(1L, migClient, FUTURE);

        assertTrue(1 == migBeneResponse.getNoOfFailedRecords());

    }

    @Test
    void addBeneficiaries_failedAtOchOfPastTxns() throws Exception {

        MigClient migClient = new MigClient();
        migClient.setEcClientId("medi4798");
        migClient.setGwClientId("GWaddr1234");
        migClient.setPrimaryCifUbs(Integer.valueOf("12312312"));
        migClient.setJobId(jobId);

        List<StgToTargetBeneEntity> stgToTargetBeneEntities = new ArrayList<>();
        StgToTargetBeneEntity stgToTargetBeneEntity = new StgToTargetBeneEntity();
        stgToTargetBeneEntity.setOLB_CLIENT_ID("medi4798");
        stgToTargetBeneEntity.setTEMPLATE_ID(1234);
        stgToTargetBeneEntity.setBENEFICIARY_ACCOUNT("12345678");
        stgToTargetBeneEntity.setELECTRONIC_INDICATOR("Y");
        stgToTargetBeneEntity.setJOB_ID(jobId);
        stgToTargetBeneEntities.add(stgToTargetBeneEntity);

        MigBeneficiary migBeneficiary = new MigBeneficiary();
        migBeneficiary.setStatus("Success");

        List<MigBeneficiary> migratedRecords = new ArrayList<>();

        AddBeneficiaryResponse addBeneficiaryResponse = new AddBeneficiaryResponse();

        when(jdbcTemplate.update(anyString(), any(Map.class))).thenReturn(0);
        when(migClientRepository.findByEcClientIdSuccess(anyString())).thenReturn(migClient);
//        when(migUserRepository.getMigratedPrimaryUser(Mockito.anyString())).thenReturn(migUser);
        when(beneficiaryMapper.findByOlbClientIdTemplates(anyString())).thenReturn(stgToTargetBeneEntities);
        oauthResponse = new OauthResponse();
        oauthResponse.setAccess_token("e2561beef23920c18902ada758a1118de96be728add38b1a04acb2d911845352");
        when(gatewayOAuthRepository.getUserAccessToken(userType)).thenReturn(oauthResponse);
        when(migBeneficiaryRepository.findByWireTxnIdMigratedOrIgnored(anyLong(), Mockito.anyInt())).thenReturn(migratedRecords);
        beneficiariesService.migUserPrincipal = migUserPrincipal;
        EntityWrapper entityWrapper = new EntityWrapper(stgToTargetBeneEntity);
        entityWrapper.addUnexpectedError("source", "Error");
        entityWrapper.gatewayMigrationResponse = addBeneficiaryResponse;
        doReturn(getBankBranchResponse("IT")).when(beneficiaryValidationUtility).validateBankBranchAndFetchList(any());
        doReturn(getIbanCountryRulesResponse("X")).when(beneficiaryValidationUtility).validateIbanCountrySpecificRulesAndValidation(any(), any(), anyLong(), anyString());
        doReturn(entityWrapper).when(templatePayeeManager).migrateBeneficiaryToGateway(any(EntityWrapper.class), any(ProcessingContext.class));

        MigBeneResponse migBeneResponse = beneficiariesService.addBeneficiaries(1L, migClient, TEMPLATE);

        assertTrue(1 == migBeneResponse.getNoOfFailedRecords());

    }
@Test
    void setBankRefNum_test() throws Exception{

        MigClient migClient = new MigClient();
        migClient.setEcClientId("medi4798");
        migClient.setGwClientId("GWaddr1234");
        migClient.setPrimaryCifUbs(Integer.valueOf("12312312"));
        migClient.setJobId(Long.valueOf("123"));

        MigUser migUser = new MigUser();
        migUser.setGwClientId("GWaddr1234");
        migUser.setGwUuid("b01eb56652f046328b933ecdf4ba0374");

        List<StgToTargetBeneEntity> stgToTargetBeneEntities = new ArrayList<>();
        StgToTargetBeneEntity stgToTargetBeneEntity = new StgToTargetBeneEntity();
        stgToTargetBeneEntity.setOLB_CLIENT_ID("medi4798");
        stgToTargetBeneEntity.setWIRE_TRANSACTION_ID(1234);
        stgToTargetBeneEntity.setBENEFICIARY_ACCOUNT("12345678");
        stgToTargetBeneEntity.setELECTRONIC_INDICATOR("Y");
        stgToTargetBeneEntity.setJOB_ID(jobId);
        stgToTargetBeneEntity.setBENEFICIARY_BANK_CITY("SANTACLARA");
        stgToTargetBeneEntities.add(stgToTargetBeneEntity);


        MigBeneficiary migBeneficiary = new MigBeneficiary();
        migBeneficiary.setStatus("Success");

        List<MigBeneficiary> migratedRecords = new ArrayList<>();

        AddBeneficiaryResponse addBeneficiaryResponse = new AddBeneficiaryResponse();

        when(jdbcTemplate.update(anyString(), any(Map.class))).thenReturn(0);
        when(migClientRepository.findByEcClientIdSuccess(anyString())).thenReturn(migClient);
        when(migUserRepository.getMigratedPrimaryUser(anyString())).thenReturn(migUser);
        when(beneficiaryMapper.findByOlbClientIdFutureFreeForm(anyString())).thenReturn(stgToTargetBeneEntities);
        oauthResponse = new OauthResponse();
        oauthResponse.setAccess_token("e2561beef23920c18902ada758a1118de96be728add38b1a04acb2d911845352");
        when(gatewayOAuthRepository.getUserAccessToken(userType)).thenReturn(oauthResponse);
        when(migBeneficiaryRepository.findByWireTxnIdMigratedOrIgnored(anyLong(), Mockito.anyInt())).thenReturn(migratedRecords);
        beneficiariesService.migUserPrincipal = migUserPrincipal;
        EntityWrapper entityWrapper = new EntityWrapper(stgToTargetBeneEntity);
        entityWrapper.addUnexpectedError("source", "Error");
        entityWrapper.gatewayMigrationResponse = addBeneficiaryResponse;
//        doReturn(stgToTargetBeneEntity).when(entityWrapper).getEntity();
        ReachabilityCheckResponse reachabilityCheckResponse=new ReachabilityCheckResponse();
        doReturn(stgToTargetBeneEntities).when(beneficiaryMapper).findByOlbClientIdFutureFreeForm(anyString());
        doReturn(reachabilityCheckResponse).when(beneficiaryValidationUtility).reachabilityCheck(any(),any());
        doReturn(getBankBranchResponse("IT1")).when(beneficiaryValidationUtility).validateBankBranchAndFetchList(any());
        doReturn(getIbanCountryRulesResponse("X")).when(beneficiaryValidationUtility).validateIbanCountrySpecificRulesAndValidation(any(), any(), anyLong(), anyString());
        doReturn(entityWrapper).when(wirePayeeManager).migrateBeneficiaryToGateway(any(EntityWrapper.class), any(ProcessingContext.class));

        MigBeneResponse migBeneResponse = beneficiariesService.addBeneficiaries(1L, migClient, FUTURE);

        assertTrue(1 == migBeneResponse.getNoOfFailedRecords());

    }

    @Test
    void test_ACHLargePayee() {
        MigClient migClient = new MigClient();
        migClient.setEcClientId("medi4798");
        migClient.setGwClientId("GWaddr1234");
        migClient.setPrimaryCifUbs(Integer.valueOf("12312312"));
        migClient.setJobId(Long.valueOf("123"));
        migClient.setPrimaryCifUbs(Integer.valueOf("12312312"));
        MigUser migUser = new MigUser();
        migUser.setGwClientId("GWaddr1234");
        migUser.setGwUuid("b01eb56652f046328b933ecdf4ba0374");

        when(migClientRepository.findByEcClientIdSuccess(anyString())).thenReturn(migClient);
        when(migUserRepository.getMigratedPrimaryUser(anyString())).thenReturn(migUser);

        List<StgToTargetBeneEntity> stgToTargetBeneEntities = new ArrayList<>();
        StgToTargetBeneEntity stgToTargetBeneEntity = new StgToTargetBeneEntity();
        stgToTargetBeneEntity.setOLB_CLIENT_ID("medi4798");
        stgToTargetBeneEntity.setWIRE_TRANSACTION_ID(1234);
        stgToTargetBeneEntity.setBENEFICIARY_ACCOUNT("12345678");
        stgToTargetBeneEntity.setELECTRONIC_INDICATOR("Y");
        stgToTargetBeneEntity.setJOB_ID(jobId);
        stgToTargetBeneEntity.setBENEFICIARY_BANK_CITY("SANTACLARA");
        stgToTargetBeneEntity.setIPAYEE_BENE_ID(12345);
        stgToTargetBeneEntities.add(stgToTargetBeneEntity);

        ResultRecords rr=new ResultRecords();
        rr.setBeneId("123");
        rr.setIPayBeneId(123);
        rr.setStatus("Success");
        rr.setTemplateId(1234);
        rr.setWireTxnId(123456);
        doReturn(rr).when(beneficiariesService).setResultRecords(any(),any());
        doReturn(stgToTargetBeneEntities).when(beneficiaryMapper).findByOlbClientIdIpayPayees(any());
       MigBeneResponse serviceResponse = beneficiariesService.addBeneficiaries(1L, migClient, ACH_LARGE);
}
}