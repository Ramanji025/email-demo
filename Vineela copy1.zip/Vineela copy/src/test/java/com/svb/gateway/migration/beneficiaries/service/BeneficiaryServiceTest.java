package com.svb.gateway.migration.beneficiaries.service;

import static com.svb.gateway.migration.beneficiaries.entity.StgToTargetBeneEntity.PAYEE_TYPE.*;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.svb.gateway.migration.beneficiaries.entity.*;
import com.svb.gateway.migration.beneficiaries.mapper.BankMapper;
import com.svb.gateway.migration.beneficiaries.mapper.MigBeneficiaryMapper;
import com.svb.gateway.migration.beneficiaries.model.*;
import com.svb.gateway.migration.beneficiaries.repository.MigBeneficiaryRepository;
import com.svb.gateway.migration.client.entity.MigClient;
import com.svb.gateway.migration.common.exception.ServiceException;
import com.svb.gateway.migration.common.model.AddressResponse;
import com.svb.gateway.migration.common.service.RetryService;
import com.svb.gateway.migration.common.utility.AddressDoctor;
import com.svb.gateway.migration.common.utility.CacheManagerUtility;
import com.svb.gateway.migration.user.entity.MigUser;
import com.svb.gateway.migration.user.repository.MigUserRepository;
import org.codehaus.jettison.json.JSONException;
import org.junit.Ignore;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.*;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.*;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.web.client.RestClientResponseException;
import org.springframework.web.client.RestTemplate;

import java.util.ArrayList;
import java.util.List;

import static junit.framework.TestCase.assertTrue;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.when;

@SpringBootTest
@ExtendWith(SpringExtension.class)
public class BeneficiaryServiceTest {

    @Mock
    MigBeneficiaryRepository migBeneficiaryRepository;

    @Mock
    BeneficiaryValidationUtility beneficiaryValidationUtility;

    @Mock
    BankMapper bankMapper;

    @Mock
    MigUserRepository migUserRepository;

    @Mock
    MigBeneficiaryMapper migBeneficiaryMapper;

    @Mock
    RestTemplate restTemplate;
    @Mock
    RetryService retryService;

    @Mock
    CacheManagerUtility cacheManagerUtility;
    @Mock
    AddressDoctor addressDoctor;

    @InjectMocks
    @Spy
    CheckPayeeManager checkPayeeManager;

    @InjectMocks
    @Spy
    TemplatePayeeManager templatePayeeManager;

    @InjectMocks
    @Spy
    ACHPayeeManager achPayeeManager;

    @InjectMocks
    @Spy
    WirePayeeManager pastPayeeManager;

    @InjectMocks
    @Spy
    WirePayeeManager futurePayeeManager;

    @InjectMocks
    @Spy
    BeneficiariesService beneficiariesService;

    @InjectMocks
    @Spy
    ACHLargePayeeManager achLargePayeeManager;

    String migUserPrincipal="4AB6C07A32B542269EF80BC4D5F5509C";
    MigUser primaryUserMigrated;
    Long jobId = 1L;
    MigClient migClient = null;

    @BeforeEach
    public void setUpBeforeEachTest(){
        beneficiariesService.beneParallelThreads = 4;
        beneficiariesService.migUserPrincipal=migUserPrincipal;
        beneficiariesService.templatePayeeManager = templatePayeeManager;
        templatePayeeManager.beneficiaryValidationUtility=beneficiaryValidationUtility;//why isn't this injected?
        templatePayeeManager.migBeneficiaryMapper = migBeneficiaryMapper;//why isn't this injected?
        templatePayeeManager.reportErrorUrl="http://reportErrorUrl";
        beneficiariesService.pastPayeeManager = pastPayeeManager;
        beneficiariesService.pastPayeeManager.type=PAST;
        beneficiariesService.futurePayeeManager = futurePayeeManager;
        beneficiariesService.futurePayeeManager.type = FUTURE;
        pastPayeeManager.beneficiaryValidationUtility=beneficiaryValidationUtility;
        futurePayeeManager.beneficiaryValidationUtility=beneficiaryValidationUtility;//why isn't this injected?
        pastPayeeManager.reportErrorUrl="http://reportErrorUrl";
        futurePayeeManager.reportErrorUrl="http://reportErrorUrl";
        beneficiariesService.checkPayeeManager = checkPayeeManager;
        beneficiariesService.achPayeeManager = achPayeeManager;
        achPayeeManager.beneficiaryValidationUtility=beneficiaryValidationUtility;//why isn't this injected?
        achPayeeManager.reportErrorUrl="http://reportErrorUrl";
        beneficiariesService.achLargePayeeManager = achLargePayeeManager;
        primaryUserMigrated = new MigUser();
        primaryUserMigrated.setGwClientId(migUserPrincipal);
        primaryUserMigrated.setGwUuid(migUserPrincipal);
        doReturn(primaryUserMigrated).when(migUserRepository).getMigratedPrimaryUser(Mockito.anyString());

        migClient = new MigClient();
        migClient.setEcClientId("ola1234");
        migClient.setGwClientId("GWaddr1234");
        migClient.setJobId(Long.valueOf(1));
        migClient.setUpdatedBy("migUser");
    }


    private EntityWrapper processEntity(EntityWrapper entityWrapper, ProcessingContext processingContext) {
        IBeneficiaryManager beneManager = beneficiariesService.getBeneficiaryManager(processingContext.getPayeeType());
        entityWrapper = beneManager.prepareRequest(entityWrapper, processingContext);
        entityWrapper = beneManager.migrateBeneficiaryToGateway(entityWrapper, processingContext);
        entityWrapper = beneManager.updateBeneficiaryDBRecord(entityWrapper, processingContext);
        return entityWrapper;
    }

    private void setupSuccessfulErrorReporting(){

        // succesful error reporting
        ResponseEntity<ErrorQueueResponse> errorQueueResponseEntity = Mockito.mock(ResponseEntity.class);
        ErrorQueueResponse errorQueueResponse = new ErrorQueueResponse();
        errorQueueResponse.setMessage("message");
        errorQueueResponse.setStatus("SUCCESS");
        errorQueueResponse.setMigrationJobId(1L);
        when(errorQueueResponseEntity.getBody()).thenReturn(errorQueueResponse);
        doReturn(errorQueueResponseEntity).when(retryService).exchange(anyString(), any(HttpMethod.class), any(HttpEntity.class), any());
    }

    private void setupLargeBillerResponseEntityError(){
        // http error
        ResponseEntity<LargeBillerResponse> errorQueueResponseEntity = Mockito.mock(ResponseEntity.class);
        when(errorQueueResponseEntity.getStatusCode()).thenReturn(HttpStatus.BAD_GATEWAY);
        LargeBillerResponse largeBillerResponse = new LargeBillerResponse();
        List<LargeBillerResponseData> list = new ArrayList<>();
        LargeBillerResponseData largeBillerResponseData = new LargeBillerResponseData();
        largeBillerResponseData.setNetworkId("456");
        list.add(largeBillerResponseData);
        largeBillerResponse.setData(list);
        when(errorQueueResponseEntity.getBody()).thenReturn(largeBillerResponse);
        doReturn(errorQueueResponseEntity).when(retryService).exchange(anyString(), any(HttpMethod.class), any(HttpEntity.class), any());
    }

    private void setupOCHMissingPaymentsDataError(){
        // no bank details data
        ResponseEntity<BeneficiaryInfo> responseEntity = Mockito.mock(ResponseEntity.class);
        BeneficiaryInfo beneInfo = new BeneficiaryInfo();
        beneInfo.setGroupId("grpId");
        Status st = new Status();
        st.setCmCode("SUC");
        st.setCodeDescription("SUCCESS");
        st.setCodeType("codetype");
        beneInfo.setStatus(st);
        List<ResponsePaymentDetail> paymentDetails = new ArrayList<>();
        ResponsePaymentDetail pDet = new ResponsePaymentDetail();
        pDet.setCounterpartyId("234");
        pDet.setPayeeListId("567");
        paymentDetails.add(pDet);
        beneInfo.setPaymentDetails(null);
        beneInfo.setCounterpartyName("CounterpartyName");
        when(responseEntity.getBody()).thenReturn(beneInfo);
        doReturn(responseEntity).when(retryService).exchange(anyString(), any(HttpMethod.class), any(HttpEntity.class), any());
    }

    private void setupOCHBadGatewayError(){
        // OCH GATEWAY ERROR
        ResponseEntity<BeneficiaryInfo> responseEntity = Mockito.mock(ResponseEntity.class);
        when(responseEntity.getStatusCode()).thenReturn(HttpStatus.BAD_GATEWAY);
        BeneficiaryInfo beneInfo = new BeneficiaryInfo();
        beneInfo.setGroupId("grpId");
        Status st = new Status();
        st.setCmCode("SUC");
        st.setCodeDescription("SUCCESS");
        st.setCodeType("codetype");
        beneInfo.setStatus(st);
        List<ResponsePaymentDetail> paymentDetails = new ArrayList<>();
        ResponsePaymentDetail pDet = new ResponsePaymentDetail();
        pDet.setCounterpartyId("234");
        pDet.setPayeeListId("567");
        paymentDetails.add(pDet);
        beneInfo.setPaymentDetails(null);
        beneInfo.setCounterpartyName("CounterpartyName");
        when(responseEntity.getBody()).thenReturn(beneInfo);
        doReturn(responseEntity).when(retryService).exchange(anyString(), any(HttpMethod.class), any(HttpEntity.class), any());
    }

    private void setupOCHBadRequestError(){
        // OCH GATEWAY ERROR
        ResponseEntity<BeneficiaryInfo> responseEntity = Mockito.mock(ResponseEntity.class);
        when(responseEntity.getStatusCode()).thenReturn(HttpStatus.BAD_REQUEST);
        BeneficiaryInfo beneInfo = new BeneficiaryInfo();
        beneInfo.setGroupId("grpId");
        Status st = new Status();
        st.setCmCode("SUC");
        st.setCodeDescription("SUCCESS");
        st.setCodeType("codetype");
        beneInfo.setStatus(st);
        List<ResponsePaymentDetail> paymentDetails = new ArrayList<>();
        ResponsePaymentDetail pDet = new ResponsePaymentDetail();
        pDet.setCounterpartyId("234");
        pDet.setPayeeListId("567");
        paymentDetails.add(pDet);
        beneInfo.setPaymentDetails(null);
        beneInfo.setCounterpartyName("CounterpartyName");
        when(responseEntity.getBody()).thenReturn(beneInfo);
        doReturn(responseEntity).when(retryService).exchange(anyString(), any(HttpMethod.class), any(HttpEntity.class), any());
    }

    private void setupSuccessfulMigration(){
        // successful migrations
        ResponseEntity<BeneficiaryInfo> responseEntity = Mockito.mock(ResponseEntity.class);
        BeneficiaryInfo beneInfo = new BeneficiaryInfo();
        beneInfo.setGroupId("grpId");
        Status st = new Status();
        st.setCmCode("SUC");
        st.setCodeDescription("SUCCESS");
        st.setCodeType("codetype");
        beneInfo.setStatus(st);
        List<ResponsePaymentDetail> paymentDetails = new ArrayList<>();
        ResponsePaymentDetail pDet = new ResponsePaymentDetail();
        pDet.setCounterpartyId("234");
        pDet.setPayeeListId("567");
        paymentDetails.add(pDet);
        beneInfo.setPaymentDetails(paymentDetails);
        beneInfo.setCounterpartyName("CounterpartyName");
        when(responseEntity.getBody()).thenReturn(beneInfo);
        doReturn(responseEntity).when(retryService).exchange(anyString(), any(HttpMethod.class), any(HttpEntity.class), any());

    }


    private StgToTargetBeneEntity getDefaultStgToTargetBeneEntity() {
        StgToTargetBeneEntity stgBeneficiary = new StgToTargetBeneEntity();
        stgBeneficiary.setBENEFICIARY_NAME("Jack");
        stgBeneficiary.setBENEFICIARY_ACCOUNT("1234578");
        stgBeneficiary.setBENEFICIARY_ADDRESS_1("180 Market St");
        stgBeneficiary.setBENEFICIARY_BANK_IDENTIFIER("ab123SX");
        stgBeneficiary.setWIRE_TRANSACTION_ID(22);
        stgBeneficiary.setIPAYEE_BENE_ID(234);
        stgBeneficiary.setTEMPLATE_ID(1234);
        stgBeneficiary.setCURRENCY_CODE("USD");
        stgBeneficiary.setELECTRONIC_INDICATOR("Y");
        stgBeneficiary.setJOB_ID(jobId);

        stgBeneficiary.setOLB_CLIENT_ID("abcd1234");
        return stgBeneficiary;
    }

    private StgToTargetBeneEntity getDefaultStgToTargetBeneEntityRegex() {
        StgToTargetBeneEntity stgBeneficiary = new StgToTargetBeneEntity();
        stgBeneficiary.setBENEFICIARY_NAME("Jack*");
        stgBeneficiary.setBENEFICIARY_ACCOUNT("1234578*");
        stgBeneficiary.setBENEFICIARY_ADDRESS_1("180 Market St");
        stgBeneficiary.setBENEFICIARY_BANK_IDENTIFIER("ab123SX");
        stgBeneficiary.setWIRE_TRANSACTION_ID(22);
        stgBeneficiary.setIPAYEE_BENE_ID(234);
        stgBeneficiary.setTEMPLATE_ID(1234);
        stgBeneficiary.setCURRENCY_CODE("USD");
        stgBeneficiary.setELECTRONIC_INDICATOR("Y");
        stgBeneficiary.setJOB_ID(jobId);

        stgBeneficiary.setOLB_CLIENT_ID("abcd1234");
        return stgBeneficiary;
    }


    private void setupAddressDoctorResponse(){

        AddressResponse addressResponse = new AddressResponse();
        addressResponse.setValidationscore("c4");
        addressResponse.setCleansedaddrln1("");addressResponse.setCleansedaddrln2("");addressResponse.setCleansedaddrln3("");addressResponse.setCleansedcitynm("");addressResponse.setCleansedzipcd("");addressResponse.setCleansedstatecd("CA");
        doReturn(addressResponse).when(addressDoctor).validateAddress(ArgumentMatchers.anyString(), ArgumentMatchers.anyString(), any());
    }

    private void setupInvalidLengthAddressDoctorResponse(){

        AddressResponse addressResponse = new AddressResponse();
        addressResponse.setValidationscore("v4");
        addressResponse.setCleansedaddrln1("Street1Street1Street1Street1Street1");addressResponse.setCleansedaddrln2("Street1Street1Street1Street1Street1");addressResponse.setCleansedaddrln3("Street1Street1Street1Street1Street1");addressResponse.setCleansedcitynm("City1City1City1City1City1City1");addressResponse.setCleansedzipcd("123456789011");addressResponse.setCleansedstatecd("CAT");addressResponse.setCleansedcntrycd("US");
        doReturn(addressResponse).when(addressDoctor).validateAddress(ArgumentMatchers.anyString(), ArgumentMatchers.anyString(), any());
    }

    private void setupInvalidLengthNonUSAddressDoctorResponse(){

        AddressResponse addressResponse = new AddressResponse();
        addressResponse.setValidationscore("c4");
        addressResponse.setCleansedaddrln1("Street1Street1Street1Street1Street1");addressResponse.setCleansedaddrln2("Street1Street1Street1Street1Street1");addressResponse.setCleansedaddrln3("Street1Street1Street1Street1Street1");addressResponse.setCleansedcitynm("City1City1City1City1City1City1City1City1City1City1");addressResponse.setCleansedzipcd("123456789011");addressResponse.setCleansedstatecd("CATCATCATCATCATCATCAT");addressResponse.setCleansedcntrycd("GB");
        doReturn(addressResponse).when(addressDoctor).validateAddress(ArgumentMatchers.anyString(), ArgumentMatchers.anyString(), any());
    }

    @Test
    public void addBene_OCHCallFailure() throws JSONException, ServiceException, JsonProcessingException {
        setupOCHBadGatewayError();
        StgToTargetBeneEntity stgBeneficiary = getDefaultStgToTargetBeneEntity();
        MigClient migClient = new MigClient();
        migClient.setEcClientId("ola1234");
        migClient.setGwClientId("GWaddr1234");
        migClient.setJobId(jobId);
        migClient.setUpdatedBy("migUser");


        List<BankEntity> bankEntities = new ArrayList<>();
        BankEntity bankEntity = new BankEntity();
        bankEntity.setNETWORK_TYPE("BIC");
        bankEntity.setCITY("Santa Clara");
        bankEntity.setBANK_REF_NO("12345");
        bankEntity.setCOUNTRY_CODE("UK");
        bankEntities.add(bankEntity);

        doReturn(bankEntities).when(bankMapper).getBankBranchInfoWithOutNetworkReach(Mockito.anyString());
        EntityWrapper entityWrapper = new EntityWrapper(stgBeneficiary);
        MigBeneficiary migBeneficiary= new MigBeneficiary();
        migBeneficiary.setStatus("Failure");
        doReturn(1).when(migBeneficiaryMapper).insertMigratedBene(migBeneficiary);

        doReturn(templatePayeeManager).when(beneficiariesService).getBeneficiaryManager(Mockito.any(StgToTargetBeneEntity.PAYEE_TYPE.class));
        //doReturn(entityWrapper).when(templatePayeeManager).migrateBeneficiaryToGateway(Mockito.any(EntityWrapper.class),Mockito.any(ProcessingContext.class));
        ProcessingContext processingContext = new ProcessingContext( 1L, templatePayeeManager,  "http://serviceurl",  migClient,  primaryUserMigrated, TEMPLATE);

        entityWrapper = processEntity(entityWrapper, processingContext);
        ResultRecords resultRecords = beneficiariesService.setResultRecords(entityWrapper, processingContext);
        assertEquals("FAILURE", entityWrapper.getStatus());
        assertTrue(entityWrapper.hasUnexpectedErrors());
    }


    @Test //ok
    public void addBene_OCHCallFailureWithBankDetailsNull() throws JSONException, ServiceException, JsonProcessingException {
        setupSuccessfulErrorReporting();
        StgToTargetBeneEntity stgBeneficiary = getDefaultStgToTargetBeneEntity();
        stgBeneficiary.setBENEFICIARY_BANK_IDENTIFIER("ABCD12345");
        MigClient migClient = new MigClient();
        migClient.setEcClientId("ola1234");
        migClient.setGwClientId("GWaddr1234");
        migClient.setJobId(jobId);
        migClient.setUpdatedBy("migUser");

        AddBeneficiaryResponse addBeneficiaryOCHResponse = new AddBeneficiaryResponse();
        addBeneficiaryOCHResponse.setData(null);

        EntityWrapper entityWrapper = new EntityWrapper(stgBeneficiary);
        entityWrapper.gatewayMigrationResponse = addBeneficiaryOCHResponse;
        doReturn(null).when(beneficiaryValidationUtility).validateBankBranchAndFetchList(any());
        Mockito.doCallRealMethod().when(beneficiaryValidationUtility).removeSpecialChars(any());
        Mockito.doCallRealMethod().when(beneficiaryValidationUtility).removeSwift(any());

        MigBeneficiary migBeneficiary= new MigBeneficiary();
        migBeneficiary.setStatus("Failure");
        doReturn(1).when(migBeneficiaryMapper).insertMigratedBene(migBeneficiary);

        doReturn(templatePayeeManager).when(beneficiariesService).getBeneficiaryManager(Mockito.any(StgToTargetBeneEntity.PAYEE_TYPE.class));

        ProcessingContext processingContext = new ProcessingContext(1L,  templatePayeeManager,  "http://serviceurl",  migClient,  primaryUserMigrated, TEMPLATE);

        entityWrapper = processEntity(entityWrapper, processingContext);
        ResultRecords resultRecords = beneficiariesService.setResultRecords(entityWrapper, processingContext);

        assertEquals("SUCCESS", resultRecords.getStatus());
        assertEquals("SUCCESS", entityWrapper.getStatus());
        assertTrue(entityWrapper.hasValidationErrors());

    }

    @Test
    public void addBene_OCHCallFailureWithBankDetailsEmpty() throws JSONException, ServiceException, JsonProcessingException {
        setupOCHMissingPaymentsDataError();
        StgToTargetBeneEntity stgBeneficiary = getDefaultStgToTargetBeneEntity();
        MigClient migClient = new MigClient();
        migClient.setEcClientId("ola1234");
        migClient.setGwClientId("GWaddr1234");
        migClient.setJobId(Long.valueOf(1));
        migClient.setUpdatedBy("migUser");

        AddBeneficiaryResponse addBeneficiaryOCHResponse = new AddBeneficiaryResponse();
        addBeneficiaryOCHResponse.setData(null);

        BankBranchResponse bankBranchResponse = new BankBranchResponse();
        List<BankBranchResponseData> bankBranchResponseDataList = new ArrayList<>();
        BankBranchResponseData bankBranchResponseData = new BankBranchResponseData();
        Network network = new Network();
        network.setCmCode("ABA");
        BranchAddress branchAddress = new BranchAddress();
        branchAddress.setCity("Las Vegas");
        Country country = new Country();
        country.setCmCode("US");
        branchAddress.setCountry(country);
        bankBranchResponseData.setNetwork(network);
        bankBranchResponseData.setBranchAddress(branchAddress);
        BankBranchResponseData bankBranchResponseData1 = new BankBranchResponseData();
        Network network1 = new Network();
        network1.setCmCode("ABA");
        BranchAddress branchAddress1 = new BranchAddress();
        branchAddress1.setCity("Santa Ana");
        Country country1 = new Country();
        country1.setCmCode("US");
        branchAddress1.setCountry(country1);
        bankBranchResponseData1.setNetwork(network1);
        bankBranchResponseData1.setBranchAddress(branchAddress1);
        bankBranchResponseDataList.add(bankBranchResponseData);
        bankBranchResponseDataList.add(bankBranchResponseData1);
        bankBranchResponse.setData(bankBranchResponseDataList);
        bankBranchResponse.setValidated(true);
        AddressResponse addressResponse = new AddressResponse();
        addressResponse.setValidationscore("c4");

        ReachabilityCheckResponse reachabilityCheckResponse = new ReachabilityCheckResponse();
        reachabilityCheckResponse.setValidated(true);
        ReachabilityCheckResponseData reachabilityCheckResponseData = new ReachabilityCheckResponseData();
        reachabilityCheckResponseData.setRoutingCode("12312312");
        List<ClearingSystemDetail> clearingSystemDetails = new ArrayList<>();
        ClearingSystemDetail clearingSystemDetail = new ClearingSystemDetail();
        clearingSystemDetail.setClearingSystem("Fedwire");
        clearingSystemDetails.add(clearingSystemDetail);
        reachabilityCheckResponseData.setClearingSystemDetails(clearingSystemDetails);
        reachabilityCheckResponse.setData(reachabilityCheckResponseData);

        doReturn(addressResponse).when(addressDoctor).validateAddress(ArgumentMatchers.anyString(), ArgumentMatchers.anyString(),  any());
        doReturn(bankBranchResponse).when(beneficiaryValidationUtility).validateBankBranchAndFetchList(any());
        Mockito.doCallRealMethod().when(beneficiaryValidationUtility).removeSpecialChars(any());
        Mockito.doCallRealMethod().when(beneficiaryValidationUtility).removeSwift(any());
        doReturn(reachabilityCheckResponse).when(beneficiaryValidationUtility).reachabilityCheck(any(),anyString());

        MigBeneficiary migBeneficiary= new MigBeneficiary();
        migBeneficiary.setStatus("Failure");
        doReturn(1).when(migBeneficiaryMapper).insertMigratedBene(migBeneficiary);
        EntityWrapper entityWrapper = new EntityWrapper(stgBeneficiary);
        entityWrapper.gatewayMigrationResponse = addBeneficiaryOCHResponse;
        doReturn(templatePayeeManager).when(beneficiariesService).getBeneficiaryManager(Mockito.any(StgToTargetBeneEntity.PAYEE_TYPE.class));

        ProcessingContext processingContext = new ProcessingContext( 1L, templatePayeeManager,  "http://serviceurl",  migClient,  primaryUserMigrated, TEMPLATE);
        entityWrapper = processEntity(entityWrapper, processingContext);
        ResultRecords resultRecords = beneficiariesService.setResultRecords(entityWrapper, processingContext);
        assertEquals("FAILURE", entityWrapper.getStatus());
        assertTrue(entityWrapper.hasUnexpectedErrors());
    }

    @Test
    public void addBene_FailureWithAddressDoctorNotSupportedCountry() throws JSONException, ServiceException, JsonProcessingException {
        setupOCHMissingPaymentsDataError();
        StgToTargetBeneEntity stgBeneficiary = getDefaultStgToTargetBeneEntity();
        MigClient migClient = new MigClient();
        migClient.setEcClientId("ola1234");
        migClient.setGwClientId("GWaddr1234");
        migClient.setJobId(Long.valueOf(1));
        migClient.setUpdatedBy("migUser");

        AddBeneficiaryResponse addBeneficiaryOCHResponse = new AddBeneficiaryResponse();
        addBeneficiaryOCHResponse.setData(null);

        BankBranchResponse bankBranchResponse = new BankBranchResponse();
        List<BankBranchResponseData> bankBranchResponseDataList = new ArrayList<>();
        BankBranchResponseData bankBranchResponseData = new BankBranchResponseData();
        Network network = new Network();
        network.setCmCode("ABA");
        BranchAddress branchAddress = new BranchAddress();
        branchAddress.setCity("Las Vegas");
        Country country = new Country();
        country.setCmCode("IN");
        branchAddress.setCountry(country);
        bankBranchResponseData.setNetwork(network);
        bankBranchResponseData.setBranchAddress(branchAddress);
        BankBranchResponseData bankBranchResponseData1 = new BankBranchResponseData();
        Network network1 = new Network();
        network1.setCmCode("ABA");
        BranchAddress branchAddress1 = new BranchAddress();
        branchAddress1.setCity("Santa Ana");
        Country country1 = new Country();
        country1.setCmCode("IN");
        branchAddress1.setCountry(country1);
        bankBranchResponseData1.setNetwork(network1);
        bankBranchResponseData1.setBranchAddress(branchAddress1);
        bankBranchResponseDataList.add(bankBranchResponseData);
        bankBranchResponseDataList.add(bankBranchResponseData1);
        bankBranchResponse.setData(bankBranchResponseDataList);
        bankBranchResponse.setValidated(true);
        AddressResponse addressResponse = new AddressResponse();
        addressResponse.setValidationdesc("Country not supported by Address doctor");

        ReachabilityCheckResponse reachabilityCheckResponse = new ReachabilityCheckResponse();
        reachabilityCheckResponse.setValidated(true);
        ReachabilityCheckResponseData reachabilityCheckResponseData = new ReachabilityCheckResponseData();
        reachabilityCheckResponseData.setRoutingCode("12312312");
        List<ClearingSystemDetail> clearingSystemDetails = new ArrayList<>();
        ClearingSystemDetail clearingSystemDetail = new ClearingSystemDetail();
        clearingSystemDetail.setClearingSystem("Fedwire");
        clearingSystemDetails.add(clearingSystemDetail);
        reachabilityCheckResponseData.setClearingSystemDetails(clearingSystemDetails);
        reachabilityCheckResponse.setData(reachabilityCheckResponseData);

        doReturn(addressResponse).when(addressDoctor).validateAddress(ArgumentMatchers.anyString(), ArgumentMatchers.anyString(),  any());
        doReturn(bankBranchResponse).when(beneficiaryValidationUtility).validateBankBranchAndFetchList(any());
        Mockito.doCallRealMethod().when(beneficiaryValidationUtility).removeSpecialChars(any());
        Mockito.doCallRealMethod().when(beneficiaryValidationUtility).removeSwift(any());
        doReturn(reachabilityCheckResponse).when(beneficiaryValidationUtility).reachabilityCheck(any(),anyString());

        MigBeneficiary migBeneficiary= new MigBeneficiary();
        migBeneficiary.setStatus("Failure");
        doReturn(1).when(migBeneficiaryMapper).insertMigratedBene(migBeneficiary);
        EntityWrapper entityWrapper = new EntityWrapper(stgBeneficiary);
        entityWrapper.gatewayMigrationResponse = addBeneficiaryOCHResponse;
        doReturn(templatePayeeManager).when(beneficiariesService).getBeneficiaryManager(Mockito.any(StgToTargetBeneEntity.PAYEE_TYPE.class));

        ProcessingContext processingContext = new ProcessingContext( 1L, templatePayeeManager,  "http://serviceurl",  migClient,  primaryUserMigrated, TEMPLATE);
        entityWrapper = processEntity(entityWrapper, processingContext);
        ResultRecords resultRecords = beneficiariesService.setResultRecords(entityWrapper, processingContext);
        assertTrue(entityWrapper.hasUnexpectedErrors());
        assertEquals(1,entityWrapper.getValidationErrorList().size());
    }

    @Test // check what this should test because currently it is successful
    public void addBene_OCHCallFailureWithBankDetailsEmptyForSourceWireTxn() throws JSONException, ServiceException, JsonProcessingException {
        setupSuccessfulMigration();
        StgToTargetBeneEntity stgBeneficiary = getDefaultStgToTargetBeneEntity();
        stgBeneficiary.setBENEFICIARY_BANK_IDENTIFIER("123456789");
        MigClient migClient = new MigClient();
        migClient.setEcClientId("ola1234");
        migClient.setGwClientId("GWaddr1234");
        migClient.setJobId(Long.valueOf(1));
        migClient.setUpdatedBy("migUser");

        AddBeneficiaryResponse addBeneficiaryOCHResponse = new AddBeneficiaryResponse();
        addBeneficiaryOCHResponse.setData(null);

        BankBranchResponse bankBranchResponse = new BankBranchResponse();
        List<BankBranchResponseData> bankBranchResponseDataList = new ArrayList<>();
        BankBranchResponseData bankBranchResponseData = new BankBranchResponseData();
        Network network = new Network();
        network.setCmCode("ABA");
        BranchAddress branchAddress = new BranchAddress();
        branchAddress.setCity("Las Vegas");
        Country country = new Country();
        country.setCmCode("US");
        branchAddress.setCountry(country);
        bankBranchResponseData.setNetwork(network);
        bankBranchResponseData.setBranchAddress(branchAddress);
        BankBranchResponseData bankBranchResponseData1 = new BankBranchResponseData();
        Network network1 = new Network();
        network1.setCmCode("ABA");
        BranchAddress branchAddress1 = new BranchAddress();
        branchAddress1.setCity("Santa Ana");
        Country country1 = new Country();
        country1.setCmCode("US");
        branchAddress1.setCountry(country1);
        bankBranchResponseData1.setNetwork(network1);
        bankBranchResponseData1.setBranchAddress(branchAddress1);
        bankBranchResponseDataList.add(bankBranchResponseData);
        bankBranchResponseDataList.add(bankBranchResponseData1);
        bankBranchResponse.setData(bankBranchResponseDataList);
        bankBranchResponse.setValidated(true);
        setupAddressDoctorResponse();

        ReachabilityCheckResponse reachabilityCheckResponse = new ReachabilityCheckResponse();
        reachabilityCheckResponse.setValidated(true);
        ReachabilityCheckResponseData reachabilityCheckResponseData = new ReachabilityCheckResponseData();
        reachabilityCheckResponseData.setRoutingCode("12312312");
        List<ClearingSystemDetail> clearingSystemDetails = new ArrayList<>();
        ClearingSystemDetail clearingSystemDetail = new ClearingSystemDetail();
        clearingSystemDetail.setClearingSystem("Fedwire");
        clearingSystemDetails.add(clearingSystemDetail);
        reachabilityCheckResponseData.setClearingSystemDetails(clearingSystemDetails);
        reachabilityCheckResponse.setData(reachabilityCheckResponseData);

        doReturn(bankBranchResponse).when(beneficiaryValidationUtility).validateBankBranchAndFetchList(any());
        Mockito.doCallRealMethod().when(beneficiaryValidationUtility).removeSpecialChars(any());
        Mockito.doCallRealMethod().when(beneficiaryValidationUtility).removeSwift(any());

        MigBeneficiary migBeneficiary= new MigBeneficiary();
        migBeneficiary.setStatus("Failure");
        doReturn(1).when(migBeneficiaryMapper).insertMigratedBene(migBeneficiary);
        EntityWrapper entityWrapper = new EntityWrapper(stgBeneficiary);
        entityWrapper.gatewayMigrationResponse = addBeneficiaryOCHResponse;
        doReturn(futurePayeeManager).when(beneficiariesService).getBeneficiaryManager(Mockito.any(StgToTargetBeneEntity.PAYEE_TYPE.class));

        doReturn(reachabilityCheckResponse).when(beneficiaryValidationUtility).reachabilityCheck(any(),anyString());
        ProcessingContext processingContext = new ProcessingContext( 1L, futurePayeeManager,  "http://serviceurl",  migClient,  primaryUserMigrated, FUTURE);

        entityWrapper = processEntity(entityWrapper, processingContext);
        ResultRecords resultRecords = beneficiariesService.setResultRecords(entityWrapper, processingContext);
        assertEquals("SUCCESS", entityWrapper.getStatus());
        assertFalse(entityWrapper.hasValidationErrors());
    }

    @Test
    public void addBene_OCHCallSuccess() throws JSONException, ServiceException, JsonProcessingException {
        setupSuccessfulMigration();
        StgToTargetBeneEntity stgBeneficiary = getDefaultStgToTargetBeneEntity();
        stgBeneficiary.setBENEFICIARY_BANK_IDENTIFIER("123456789");
        MigClient migClient = new MigClient();
        migClient.setEcClientId("ola1234");
        migClient.setGwClientId("GWaddr1234");
        migClient.setJobId(Long.valueOf(1));
        migClient.setUpdatedBy("migUser");

        AddBeneficiaryResponse addBeneficiaryOCHResponse = new AddBeneficiaryResponse();
        AddBeneficiaryResponseData addBeneficiaryResponseData = new AddBeneficiaryResponseData();
        addBeneficiaryResponseData.setGroupId("1234");
        Status status=new Status();
        status.setCodeDescription("Success");
        addBeneficiaryResponseData.setStatus(status);

        List<ResponsePaymentDetail> paymentDetails = new ArrayList<>();
        ResponsePaymentDetail responsePaymentDetail = new ResponsePaymentDetail();
        responsePaymentDetail.setCounterpartyId("1234");
        responsePaymentDetail.setPayeeListId("567");
        paymentDetails.add(responsePaymentDetail);
        addBeneficiaryResponseData.setPaymentDetails(paymentDetails);
        addBeneficiaryOCHResponse.setData(addBeneficiaryResponseData);

        BankBranchResponse bankBranchResponse = new BankBranchResponse();
        List<BankBranchResponseData> bankBranchResponseDataList = new ArrayList<>();
        BankBranchResponseData bankBranchResponseData = new BankBranchResponseData();
        Network network = new Network();
        network.setCmCode("ABA");
        BranchAddress branchAddress = new BranchAddress();
        branchAddress.setCity("Santa Clara");
        Country country = new Country();
        country.setCmCode("US");
        branchAddress.setCountry(country);
        bankBranchResponseData.setNetwork(network);
        bankBranchResponseData.setBranchAddress(branchAddress);
        bankBranchResponseDataList.add(bankBranchResponseData);
        bankBranchResponseDataList.add(bankBranchResponseData);
        bankBranchResponse.setData(bankBranchResponseDataList);
        bankBranchResponse.setValidated(true);


        ReachabilityCheckResponse reachabilityCheckResponse = new ReachabilityCheckResponse();
        reachabilityCheckResponse.setValidated(true);
        ReachabilityCheckResponseData reachabilityCheckResponseData = new ReachabilityCheckResponseData();
        reachabilityCheckResponseData.setRoutingCode("12312312");
        List<ClearingSystemDetail> clearingSystemDetails = new ArrayList<>();
        ClearingSystemDetail clearingSystemDetail = new ClearingSystemDetail();
        clearingSystemDetail.setClearingSystem("Fedwire");
        clearingSystemDetails.add(clearingSystemDetail);
        reachabilityCheckResponseData.setClearingSystemDetails(clearingSystemDetails);
        reachabilityCheckResponse.setData(reachabilityCheckResponseData);

        setupAddressDoctorResponse();

        doReturn(bankBranchResponse).when(beneficiaryValidationUtility).validateBankBranchAndFetchList(any());
        Mockito.doCallRealMethod().when(beneficiaryValidationUtility).removeSpecialChars(any());
        Mockito.doCallRealMethod().when(beneficiaryValidationUtility).removeSwift(any());

        doReturn(reachabilityCheckResponse).when(beneficiaryValidationUtility).reachabilityCheck(any(),anyString());

        MigBeneficiary migBeneficiary= new MigBeneficiary();
        migBeneficiary.setStatus("Success");
        doReturn(1).when(migBeneficiaryMapper).insertMigratedBene(migBeneficiary);
        EntityWrapper entityWrapper = new EntityWrapper(stgBeneficiary);
        entityWrapper.gatewayMigrationResponse = addBeneficiaryOCHResponse;
        doReturn(templatePayeeManager).when(beneficiariesService).getBeneficiaryManager(Mockito.any(StgToTargetBeneEntity.PAYEE_TYPE.class));

        ProcessingContext processingContext = new ProcessingContext( 1L, templatePayeeManager,  "http://serviceurl",  migClient,  primaryUserMigrated, TEMPLATE);

        entityWrapper = processEntity(entityWrapper, processingContext);
        ResultRecords resultRecords = beneficiariesService.setResultRecords(entityWrapper, processingContext);
        assertEquals("SUCCESS", entityWrapper.getStatus());
        assertFalse(entityWrapper.hasValidationErrors());
    }

    @Test
    public void addBene_OCHCallSuccessForCheckPayee() throws JSONException, ServiceException, JsonProcessingException {
        setupSuccessfulMigration();
        StgToTargetBeneEntity stgBeneficiary = getDefaultStgToTargetBeneEntity();
        getInvalidLengthStgToTargetBeneEntity(stgBeneficiary);
        MigClient migClient = new MigClient();
        migClient.setEcClientId("ola1234");
        migClient.setGwClientId("GWaddr1234");
        migClient.setJobId(Long.valueOf(1));
        migClient.setUpdatedBy("migUser");

        AddBeneficiaryResponse addBeneficiaryOCHResponse = new AddBeneficiaryResponse();
        AddBeneficiaryResponseData addBeneficiaryResponseData = new AddBeneficiaryResponseData();
        addBeneficiaryResponseData.setGroupId("1234");
        Status status=new Status();
        status.setCodeDescription("Success");
        addBeneficiaryResponseData.setStatus(status);

        List<ResponsePaymentDetail> paymentDetails = new ArrayList<>();
        ResponsePaymentDetail responsePaymentDetail = new ResponsePaymentDetail();
        responsePaymentDetail.setCounterpartyId("1234");
        responsePaymentDetail.setPayeeListId("567");
        paymentDetails.add(responsePaymentDetail);
        addBeneficiaryResponseData.setPaymentDetails(paymentDetails);
        addBeneficiaryOCHResponse.setData(addBeneficiaryResponseData);

        BankBranchResponse bankBranchResponse = new BankBranchResponse();
        List<BankBranchResponseData> bankBranchResponseDataList = new ArrayList<>();
        BankBranchResponseData bankBranchResponseData = new BankBranchResponseData();
        Network network = new Network();
        network.setCmCode("ABA");
        BranchAddress branchAddress = new BranchAddress();
        branchAddress.setCity("Santa Clara");
        Country country = new Country();
        country.setCmCode("US");
        branchAddress.setCountry(country);
        bankBranchResponseData.setNetwork(network);
        bankBranchResponseData.setBranchAddress(branchAddress);
        bankBranchResponseDataList.add(bankBranchResponseData);
        bankBranchResponseDataList.add(bankBranchResponseData);
        bankBranchResponse.setData(bankBranchResponseDataList);
        bankBranchResponse.setValidated(true);


        ReachabilityCheckResponse reachabilityCheckResponse = new ReachabilityCheckResponse();
        reachabilityCheckResponse.setValidated(true);
        ReachabilityCheckResponseData reachabilityCheckResponseData = new ReachabilityCheckResponseData();
        reachabilityCheckResponseData.setRoutingCode("12312312");
        List<ClearingSystemDetail> clearingSystemDetails = new ArrayList<>();
        ClearingSystemDetail clearingSystemDetail = new ClearingSystemDetail();
        clearingSystemDetail.setClearingSystem("Fedwire");
        clearingSystemDetails.add(clearingSystemDetail);
        reachabilityCheckResponseData.setClearingSystemDetails(clearingSystemDetails);
        reachabilityCheckResponse.setData(reachabilityCheckResponseData);

        setupInvalidLengthAddressDoctorResponse();

        doReturn(bankBranchResponse).when(beneficiaryValidationUtility).validateBankBranchAndFetchList(any());
        Mockito.doCallRealMethod().when(beneficiaryValidationUtility).removeSpecialChars(any());
        Mockito.doCallRealMethod().when(beneficiaryValidationUtility).removeSwift(any());

        doReturn(reachabilityCheckResponse).when(beneficiaryValidationUtility).reachabilityCheck(any(),anyString());

        MigBeneficiary migBeneficiary= new MigBeneficiary();
        migBeneficiary.setStatus("Success");
        doReturn(1).when(migBeneficiaryMapper).insertMigratedBene(migBeneficiary);
        EntityWrapper entityWrapper = new EntityWrapper(stgBeneficiary);
        entityWrapper.gatewayMigrationResponse = addBeneficiaryOCHResponse;
        doReturn(checkPayeeManager).when(beneficiariesService).getBeneficiaryManager(Mockito.any(StgToTargetBeneEntity.PAYEE_TYPE.class));

        ProcessingContext processingContext = new ProcessingContext( 1L, checkPayeeManager,  "http://serviceurl",  migClient,  primaryUserMigrated, CHECK);

        entityWrapper = processEntity(entityWrapper, processingContext);
        beneficiariesService.setResultRecords(entityWrapper, processingContext);

        assertTrue(entityWrapper.hasValidationErrors());
    }


    @Test
    public void addBene_OCHCallSuccessForSourceWireTxn() throws JSONException, ServiceException, JsonProcessingException {
        setupSuccessfulErrorReporting();
        StgToTargetBeneEntity stgBeneficiary = getDefaultStgToTargetBeneEntity();
        MigClient migClient = new MigClient();
        migClient.setEcClientId("ola1234");
        migClient.setGwClientId("GWaddr1234");
        migClient.setJobId(Long.valueOf(1));
        migClient.setUpdatedBy("migUser");

        AddBeneficiaryResponse addBeneficiaryOCHResponse = new AddBeneficiaryResponse();
        AddBeneficiaryResponseData addBeneficiaryResponseData = new AddBeneficiaryResponseData();
        addBeneficiaryResponseData.setGroupId("1234");
        Status status=new Status();
        status.setCodeDescription("Success");
        addBeneficiaryResponseData.setStatus(status);

        List<ResponsePaymentDetail> paymentDetails = new ArrayList<>();
        ResponsePaymentDetail responsePaymentDetail = new ResponsePaymentDetail();
        responsePaymentDetail.setCounterpartyId("1234");
        responsePaymentDetail.setPayeeListId("567");
        paymentDetails.add(responsePaymentDetail);
        addBeneficiaryResponseData.setPaymentDetails(paymentDetails);
        addBeneficiaryOCHResponse.setData(addBeneficiaryResponseData);

        BankBranchResponse bankBranchResponse = new BankBranchResponse();
        List<BankBranchResponseData> bankBranchResponseDataList = new ArrayList<>();
        BankBranchResponseData bankBranchResponseData = new BankBranchResponseData();
        Network network = new Network();
        network.setCmCode("ABA");
        BranchAddress branchAddress = new BranchAddress();
        branchAddress.setCity("Santa Clara");
        Country country = new Country();
        country.setCmCode("US");
        branchAddress.setCountry(country);
        bankBranchResponseData.setNetwork(network);
        bankBranchResponseData.setBranchAddress(branchAddress);
        bankBranchResponseDataList.add(bankBranchResponseData);
        bankBranchResponseDataList.add(bankBranchResponseData);
        bankBranchResponse.setData(bankBranchResponseDataList);
        bankBranchResponse.setValidated(true);
        AddressResponse addressResponse = new AddressResponse();
        addressResponse.setValidationscore("c4");

        ReachabilityCheckResponse reachabilityCheckResponse = new ReachabilityCheckResponse();
        reachabilityCheckResponse.setValidated(true);
        ReachabilityCheckResponseData reachabilityCheckResponseData = new ReachabilityCheckResponseData();
        reachabilityCheckResponseData.setRoutingCode("12312312");
        List<ClearingSystemDetail> clearingSystemDetails = new ArrayList<>();
        ClearingSystemDetail clearingSystemDetail = new ClearingSystemDetail();
        clearingSystemDetail.setClearingSystem("Fedwire");
        clearingSystemDetails.add(clearingSystemDetail);
        reachabilityCheckResponseData.setClearingSystemDetails(clearingSystemDetails);
        reachabilityCheckResponse.setData(reachabilityCheckResponseData);

        doReturn(addressResponse).when(addressDoctor).validateAddress(ArgumentMatchers.anyString(), ArgumentMatchers.anyString(),  any());

        doReturn(bankBranchResponse).when(beneficiaryValidationUtility).validateBankBranchAndFetchList(any());
        Mockito.doCallRealMethod().when(beneficiaryValidationUtility).removeSpecialChars(any());
        Mockito.doCallRealMethod().when(beneficiaryValidationUtility).removeSwift(any());

        doReturn(reachabilityCheckResponse).when(beneficiaryValidationUtility).reachabilityCheck(any(),anyString());

        MigBeneficiary migBeneficiary= new MigBeneficiary();
        migBeneficiary.setStatus("Success");
        doReturn(1).when(migBeneficiaryMapper).insertMigratedBene(migBeneficiary);
        EntityWrapper entityWrapper = new EntityWrapper(stgBeneficiary);
        entityWrapper.gatewayMigrationResponse = addBeneficiaryOCHResponse;
        doReturn(pastPayeeManager).when(beneficiariesService).getBeneficiaryManager(Mockito.any(StgToTargetBeneEntity.PAYEE_TYPE.class));

        ProcessingContext processingContext = new ProcessingContext( 1L, pastPayeeManager,  "http://serviceurl",  migClient,  primaryUserMigrated,  PAST);

        entityWrapper = processEntity(entityWrapper, processingContext);
        ResultRecords resultRecords = beneficiariesService.setResultRecords(entityWrapper, processingContext);

        assertFalse(entityWrapper.hasValidationErrors());
    }

    @Test
    public void addBene_ReachabilityValidationFailed() throws JSONException, ServiceException, JsonProcessingException {
        setupSuccessfulErrorReporting();
        StgToTargetBeneEntity stgBeneficiary = getDefaultStgToTargetBeneEntity();
        getInvalidLengthStgToTargetBeneEntity(stgBeneficiary);
        setupInvalidLengthAddressDoctorResponse();
        MigClient migClient = new MigClient();
        migClient.setEcClientId("ola1234");
        migClient.setGwClientId("GWaddr1234");
        migClient.setJobId(jobId);
        migClient.setUpdatedBy("migUser");

        AddBeneficiaryResponse addBeneficiaryOCHResponse = new AddBeneficiaryResponse();
        addBeneficiaryOCHResponse.setData(null);

        BankBranchResponse bankBranchResponse = new BankBranchResponse();
        List<BankBranchResponseData> bankBranchResponseDataList = new ArrayList<>();
        BankBranchResponseData bankBranchResponseData = new BankBranchResponseData();
        Network network = new Network();
        network.setCmCode("ABA");
        BranchAddress branchAddress = new BranchAddress();
        branchAddress.setCity("Santa Ana");
        Country country = new Country();
        country.setCmCode("US");
        branchAddress.setCountry(country);
        bankBranchResponseData.setNetwork(network);
        bankBranchResponseData.setBranchAddress(branchAddress);
        bankBranchResponseDataList.add(bankBranchResponseData);
        bankBranchResponseDataList.add(bankBranchResponseData);
        bankBranchResponse.setData(bankBranchResponseDataList);
        bankBranchResponse.setValidated(true);

        IbanCountryRulesResponse ibanCountryRulesResponse = new IbanCountryRulesResponse();
        ibanCountryRulesResponse.setValidated(false);

        doReturn(bankBranchResponse).when(beneficiaryValidationUtility).validateBankBranchAndFetchList(any());
        Mockito.doCallRealMethod().when(beneficiaryValidationUtility).removeSpecialChars(any());
        Mockito.doCallRealMethod().when(beneficiaryValidationUtility).removeSwift(any());

        doReturn(ibanCountryRulesResponse).when(beneficiaryValidationUtility).validateIbanCountrySpecificRulesAndValidation(any(),any(),anyLong(),anyString());

        doReturn(null).when(beneficiaryValidationUtility).reachabilityCheck(any(),anyString());

        MigBeneficiary migBeneficiary= new MigBeneficiary();
        migBeneficiary.setStatus("Failure");
        doReturn(1).when(migBeneficiaryMapper).insertMigratedBene(migBeneficiary);
        EntityWrapper entityWrapper = new EntityWrapper(stgBeneficiary);
        entityWrapper.gatewayMigrationResponse = addBeneficiaryOCHResponse;
        doReturn(futurePayeeManager).when(beneficiariesService).getBeneficiaryManager(Mockito.any(StgToTargetBeneEntity.PAYEE_TYPE.class));


        ProcessingContext processingContext = new ProcessingContext( 1L, futurePayeeManager,  "http://serviceurl",  migClient,  primaryUserMigrated, TEMPLATE);

        entityWrapper = processEntity(entityWrapper, processingContext);
        ResultRecords resultRecords = beneficiariesService.setResultRecords(entityWrapper, processingContext);

        assertTrue(entityWrapper.hasValidationErrors());
    }

    private void getInvalidLengthStgToTargetBeneEntity(StgToTargetBeneEntity stgBeneficiary) {
        stgBeneficiary.setBENEFICIARY_NAME("MigrationMigrationMigrationMigrationMigrationMigrationMigrationMigration");
        stgBeneficiary.setTEMPLATE_CODE("MigrationMigrationMigrationMigrationMigration");
        stgBeneficiary.setBENEFICIARY_NICKNAME("MigrationMigrationMigrationMigrationMigration");
        stgBeneficiary.setBENEFICIARY_ACCOUNT("12345612345612345612345612345612345612345612345612312312");
        stgBeneficiary.setBENEFICIARY_BANK_IDENTIFIER("123451231231232");
    }

    @Test
    public void addBene_IbanValidationFailed() throws JSONException, ServiceException, JsonProcessingException {
        setupSuccessfulErrorReporting();
        StgToTargetBeneEntity stgBeneficiary = getDefaultStgToTargetBeneEntity();
        int wireTransactionId = 5678;
        stgBeneficiary.setWIRE_TRANSACTION_ID(wireTransactionId);

        MigClient migClient = new MigClient();
        migClient.setEcClientId("ola1234");
        migClient.setGwClientId("GWaddr1234");
        migClient.setJobId(jobId);
        migClient.setUpdatedBy("migUser");

        AddBeneficiaryResponse addBeneficiaryOCHResponse = new AddBeneficiaryResponse();
        addBeneficiaryOCHResponse.setData(null);

        setupInvalidLengthNonUSAddressDoctorResponse();

        BankBranchResponse bankBranchResponse = new BankBranchResponse();
        List<BankBranchResponseData> bankBranchResponseDataList = new ArrayList<>();
        BankBranchResponseData bankBranchResponseData = new BankBranchResponseData();
        Network network = new Network();
        network.setCmCode("BIC");
        BranchAddress branchAddress = new BranchAddress();
        branchAddress.setCity("London");
        Country country = new Country();
        country.setCmCode("GB");
        branchAddress.setCountry(country);
        bankBranchResponseData.setNetwork(network);
        bankBranchResponseData.setBranchAddress(branchAddress);
        bankBranchResponseDataList.add(bankBranchResponseData);
        bankBranchResponseDataList.add(bankBranchResponseData);
        bankBranchResponse.setData(bankBranchResponseDataList);
        bankBranchResponse.setValidated(true);

        IbanCountryRulesResponse ibanCountryRulesResponse = new IbanCountryRulesResponse();
        ibanCountryRulesResponse.setValidated(false);

        doReturn(bankBranchResponse).when(beneficiaryValidationUtility).validateBankBranchAndFetchList(any());
        Mockito.doCallRealMethod().when(beneficiaryValidationUtility).removeSpecialChars(any());
        Mockito.doCallRealMethod().when(beneficiaryValidationUtility).removeSwift(any());

        MigBeneficiary migBeneficiary= new MigBeneficiary();
        migBeneficiary.setStatus("Failure");
        doReturn(1).when(migBeneficiaryMapper).insertMigratedBene(migBeneficiary);
        EntityWrapper entityWrapper = new EntityWrapper(stgBeneficiary);
        entityWrapper.gatewayMigrationResponse = addBeneficiaryOCHResponse;
        doReturn(ibanCountryRulesResponse).when(beneficiaryValidationUtility).validateIbanCountrySpecificRulesAndValidation(any(),any(),anyLong(),anyString());
        doReturn(templatePayeeManager).when(beneficiariesService).getBeneficiaryManager(Mockito.any(StgToTargetBeneEntity.PAYEE_TYPE.class));

        ProcessingContext processingContext = new ProcessingContext( 1L, templatePayeeManager,  "http://serviceurl",  migClient,  primaryUserMigrated, TEMPLATE);

        entityWrapper = processEntity(entityWrapper, processingContext);
        ResultRecords resultRecords = beneficiariesService.setResultRecords(entityWrapper, processingContext);
        assertEquals("Successfully reported data errors to Gateway", resultRecords.getComments());
        assertEquals("SUCCESS", resultRecords.getStatus());
        assertEquals("SUCCESS", entityWrapper.getStatus());
        assertTrue(entityWrapper.hasValidationErrors());
    }

    @Test
    public void addBene_IbanValidationSuccess() throws JSONException, ServiceException, JsonProcessingException {
        setupSuccessfulErrorReporting();
        StgToTargetBeneEntity stgBeneficiary = getDefaultStgToTargetBeneEntity();
        stgBeneficiary.setBENEFICIARY_ACCOUNT("GV12312376");
        int wireTransactionId = 5678;
        stgBeneficiary.setWIRE_TRANSACTION_ID(wireTransactionId);

        MigClient migClient = new MigClient();
        migClient.setEcClientId("ola1234");
        migClient.setGwClientId("GWaddr1234");
        migClient.setJobId(jobId);
        migClient.setUpdatedBy("migUser");

        AddBeneficiaryResponse addBeneficiaryOCHResponse = new AddBeneficiaryResponse();
        addBeneficiaryOCHResponse.setData(null);

        BankBranchResponse bankBranchResponse = new BankBranchResponse();
        List<BankBranchResponseData> bankBranchResponseDataList = new ArrayList<>();
        BankBranchResponseData bankBranchResponseData = new BankBranchResponseData();
        Network network = new Network();
        network.setCmCode("BIC");
        BranchAddress branchAddress = new BranchAddress();
        branchAddress.setCity("London");
        Country country = new Country();
        country.setCmCode("GB");
        branchAddress.setCountry(country);
        bankBranchResponseData.setNetwork(network);
        bankBranchResponseData.setBranchAddress(branchAddress);
        bankBranchResponseDataList.add(bankBranchResponseData);
        bankBranchResponseDataList.add(bankBranchResponseData);
        bankBranchResponse.setData(bankBranchResponseDataList);
        bankBranchResponse.setValidated(true);

        IbanCountryRulesResponse ibanCountryRulesResponse = new IbanCountryRulesResponse();
        ibanCountryRulesResponse.setValidated(true);
        IbanCountryRulesResponseData ibanCountryRulesResponseData= new IbanCountryRulesResponseData();
        BeneIbanAccountRule beneIbanAccountRule= new BeneIbanAccountRule();
        IbanFormatRule ibanFormatRule=new IbanFormatRule();
        ibanFormatRule.setIbanISOCountryCode("GB");
        beneIbanAccountRule.setIbanRequired("O");
        beneIbanAccountRule.setAccountNumberRegex("^[A-Za-z]{4}[A-Za-z0-9]{7}$");
        beneIbanAccountRule.setIban(ibanFormatRule);
        ibanCountryRulesResponseData.setBeneficaryAccount(beneIbanAccountRule);
        ibanCountryRulesResponse.setData(ibanCountryRulesResponseData);

        AddressResponse addressResponse = new AddressResponse();
        doReturn(addressResponse).when(addressDoctor).validateAddress(ArgumentMatchers.anyString(), ArgumentMatchers.anyString(), any());


        doReturn(bankBranchResponse).when(beneficiaryValidationUtility).validateBankBranchAndFetchList(any());
        Mockito.doCallRealMethod().when(beneficiaryValidationUtility).removeSpecialChars(any());
        Mockito.doCallRealMethod().when(beneficiaryValidationUtility).removeSwift(any());

        MigBeneficiary migBeneficiary= new MigBeneficiary();
        migBeneficiary.setStatus("Failure");
        doReturn(1).when(migBeneficiaryMapper).insertMigratedBene(migBeneficiary);
        EntityWrapper entityWrapper = new EntityWrapper(stgBeneficiary);
        entityWrapper.gatewayMigrationResponse = addBeneficiaryOCHResponse;
        doReturn(ibanCountryRulesResponse).when(beneficiaryValidationUtility).validateIbanCountrySpecificRulesAndValidation(any(),any(),anyLong(),anyString());
        doReturn(templatePayeeManager).when(beneficiariesService).getBeneficiaryManager(Mockito.any(StgToTargetBeneEntity.PAYEE_TYPE.class));

        ProcessingContext processingContext = new ProcessingContext( 1L, templatePayeeManager,  "http://serviceurl",  migClient,  primaryUserMigrated, TEMPLATE);

        entityWrapper = processEntity(entityWrapper, processingContext);
        ResultRecords resultRecords = beneficiariesService.setResultRecords(entityWrapper, processingContext);
        assertEquals("Successfully reported data errors to Gateway", resultRecords.getComments());
        assertEquals("SUCCESS", resultRecords.getStatus());
        assertEquals("SUCCESS", entityWrapper.getStatus());
        assertTrue(entityWrapper.hasValidationErrors());
    }

    @Test
    public void addBene_IbanValidationSuccessRegex() throws JSONException, ServiceException, JsonProcessingException {
        setupSuccessfulErrorReporting();
        StgToTargetBeneEntity stgBeneficiary = getDefaultStgToTargetBeneEntityRegex();
        stgBeneficiary.setBENEFICIARY_ACCOUNT("GV12312376");
        int wireTransactionId = 5678;
        stgBeneficiary.setWIRE_TRANSACTION_ID(wireTransactionId);

        MigClient migClient = new MigClient();
        migClient.setEcClientId("ola1234");
        migClient.setGwClientId("GWaddr1234");
        migClient.setJobId(jobId);
        migClient.setUpdatedBy("migUser");

        AddBeneficiaryResponse addBeneficiaryOCHResponse = new AddBeneficiaryResponse();
        addBeneficiaryOCHResponse.setData(null);

        BankBranchResponse bankBranchResponse = new BankBranchResponse();
        List<BankBranchResponseData> bankBranchResponseDataList = new ArrayList<>();
        BankBranchResponseData bankBranchResponseData = new BankBranchResponseData();
        Network network = new Network();
        network.setCmCode("BIC");
        BranchAddress branchAddress = new BranchAddress();
        branchAddress.setCity("London");
        Country country = new Country();
        country.setCmCode("GB");
        branchAddress.setCountry(country);
        bankBranchResponseData.setNetwork(network);
        bankBranchResponseData.setBranchAddress(branchAddress);
        bankBranchResponseDataList.add(bankBranchResponseData);
        bankBranchResponseDataList.add(bankBranchResponseData);
        bankBranchResponse.setData(bankBranchResponseDataList);
        bankBranchResponse.setValidated(true);

        IbanCountryRulesResponse ibanCountryRulesResponse = new IbanCountryRulesResponse();
        ibanCountryRulesResponse.setValidated(true);
        IbanCountryRulesResponseData ibanCountryRulesResponseData= new IbanCountryRulesResponseData();
        BeneIbanAccountRule beneIbanAccountRule= new BeneIbanAccountRule();
        IbanFormatRule ibanFormatRule=new IbanFormatRule();
        ibanFormatRule.setIbanISOCountryCode("GB");
        beneIbanAccountRule.setIbanRequired("O");
        beneIbanAccountRule.setAccountNumberRegex("^[A-Za-z]{4}[A-Za-z0-9]{7}$");
        beneIbanAccountRule.setIban(ibanFormatRule);
        ibanCountryRulesResponseData.setBeneficaryAccount(beneIbanAccountRule);
        ibanCountryRulesResponse.setData(ibanCountryRulesResponseData);

        AddressResponse addressResponse = new AddressResponse();
        doReturn(addressResponse).when(addressDoctor).validateAddress(ArgumentMatchers.anyString(), ArgumentMatchers.anyString(), any());


        doReturn(bankBranchResponse).when(beneficiaryValidationUtility).validateBankBranchAndFetchList(any());
        Mockito.doCallRealMethod().when(beneficiaryValidationUtility).removeSpecialChars(any());
        Mockito.doCallRealMethod().when(beneficiaryValidationUtility).removeSwift(any());

        MigBeneficiary migBeneficiary= new MigBeneficiary();
        migBeneficiary.setStatus("Failure");
        doReturn(1).when(migBeneficiaryMapper).insertMigratedBene(migBeneficiary);
        EntityWrapper entityWrapper = new EntityWrapper(stgBeneficiary);
        entityWrapper.gatewayMigrationResponse = addBeneficiaryOCHResponse;
        doReturn(ibanCountryRulesResponse).when(beneficiaryValidationUtility).validateIbanCountrySpecificRulesAndValidation(any(),any(),anyLong(),anyString());
        doReturn(templatePayeeManager).when(beneficiariesService).getBeneficiaryManager(Mockito.any(StgToTargetBeneEntity.PAYEE_TYPE.class));

        ProcessingContext processingContext = new ProcessingContext( 1L, templatePayeeManager,  "http://serviceurl",  migClient,  primaryUserMigrated, TEMPLATE);

        entityWrapper = processEntity(entityWrapper, processingContext);
        ResultRecords resultRecords = beneficiariesService.setResultRecords(entityWrapper, processingContext);
        assertEquals("Successfully reported data errors to Gateway", resultRecords.getComments());
        assertEquals("SUCCESS", resultRecords.getStatus());
        assertEquals("SUCCESS", entityWrapper.getStatus());
        assertTrue(entityWrapper.hasValidationErrors());
    }

    @Test
    public void addBene_LargeBillerInformationNotFetchedWithAddressDoctorSuccess() throws JSONException, ServiceException, JsonProcessingException {
        setupSuccessfulMigration();
        StgToTargetBeneEntity stgBeneficiary = getDefaultStgToTargetBeneEntity();
        MigClient migClient = new MigClient();
        migClient.setEcClientId("ola1234");
        migClient.setGwClientId("GWaddr1234");
        migClient.setJobId(jobId);
        migClient.setUpdatedBy("migUser");

        AddBeneficiaryResponse addBeneficiaryOCHResponse = new AddBeneficiaryResponse();
        addBeneficiaryOCHResponse.setData(null);

        BankBranchResponse bankBranchResponse = new BankBranchResponse();
        List<BankBranchResponseData> bankBranchResponseDataList = new ArrayList<>();
        BankBranchResponseData bankBranchResponseData = new BankBranchResponseData();
        Network network = new Network();
        network.setCmCode("ABA");
        BranchAddress branchAddress = new BranchAddress();
        branchAddress.setCity("Santa Ana");
        Country country = new Country();
        country.setCmCode("US");
        branchAddress.setCountry(country);
        bankBranchResponseData.setNetwork(network);
        bankBranchResponseData.setBranchAddress(branchAddress);
        bankBranchResponseDataList.add(bankBranchResponseData);
        bankBranchResponseDataList.add(bankBranchResponseData);
        bankBranchResponse.setData(bankBranchResponseDataList);
        bankBranchResponse.setValidated(true);

        doReturn(bankBranchResponse).when(beneficiaryValidationUtility).validateBankBranchAndFetchList(any());
        Mockito.doCallRealMethod().when(beneficiaryValidationUtility).removeSpecialChars(any());
        Mockito.doCallRealMethod().when(beneficiaryValidationUtility).removeSwift(any());

        doReturn(null).when(beneficiaryValidationUtility).reachabilityCheck(any(),anyString());

        setupAddressDoctorResponse();

        setupLargeBillerResponseEntityError();

        MigBeneficiary migBeneficiary= new MigBeneficiary();
        migBeneficiary.setStatus("SUCCESS");
        doReturn(1).when(migBeneficiaryMapper).insertMigratedBene(migBeneficiary);
        EntityWrapper entityWrapper = new EntityWrapper(stgBeneficiary);
        entityWrapper.gatewayMigrationResponse = addBeneficiaryOCHResponse;
        doReturn(achLargePayeeManager).when(beneficiariesService).getBeneficiaryManager(Mockito.any(StgToTargetBeneEntity.PAYEE_TYPE.class));
        //doReturn(entityWrapper).when(achLargePayeeManager).migrateBeneficiaryToGateway(Mockito.any(EntityWrapper.class),Mockito.any(ProcessingContext.class));
        ProcessingContext processingContext = new ProcessingContext( 1L, achLargePayeeManager,  "http://serviceurl",  migClient,  primaryUserMigrated, ACH_LARGE);

        entityWrapper = processEntity(entityWrapper, processingContext);
        ResultRecords resultRecords = beneficiariesService.setResultRecords(entityWrapper, processingContext);
        assertEquals("FAILURE", entityWrapper.getStatus());
        assertTrue(entityWrapper.hasUnexpectedErrors());
    }

    @Test
    public void addBene_ACHPayeeSuccess() throws JSONException, ServiceException, JsonProcessingException {
        setupSuccessfulMigration();
        StgToTargetBeneEntity stgBeneficiary = getDefaultStgToTargetBeneEntity();
        stgBeneficiary.setBENEFICIARY_BANK_IDENTIFIER("123456789");
        MigClient migClient = new MigClient();
        migClient.setEcClientId("ola1234");
        migClient.setGwClientId("GWaddr1234");
        migClient.setJobId(Long.valueOf(1));
        migClient.setUpdatedBy("migUser");

        AddBeneficiaryResponse addBeneficiaryOCHResponse = new AddBeneficiaryResponse();
        addBeneficiaryOCHResponse.setData(null);

        BankBranchResponse bankBranchResponse = new BankBranchResponse();
        List<BankBranchResponseData> bankBranchResponseDataList = new ArrayList<>();
        BankBranchResponseData bankBranchResponseData = new BankBranchResponseData();
        Network network = new Network();
        network.setCmCode("ABA");
        BranchAddress branchAddress = new BranchAddress();
        branchAddress.setCity("Santa Ana");
        Country country = new Country();
        country.setCmCode("US");
        branchAddress.setCountry(country);
        bankBranchResponseData.setNetwork(network);
        bankBranchResponseData.setBranchAddress(branchAddress);
        bankBranchResponseDataList.add(bankBranchResponseData);
        bankBranchResponseDataList.add(bankBranchResponseData);
        bankBranchResponse.setData(bankBranchResponseDataList);
        bankBranchResponse.setValidated(true);

        doReturn(bankBranchResponse).when(beneficiaryValidationUtility).validateBankBranchAndFetchList(any());
        Mockito.doCallRealMethod().when(beneficiaryValidationUtility).removeSpecialChars(any());
        Mockito.doCallRealMethod().when(beneficiaryValidationUtility).removeSwift(any());

        ReachabilityCheckResponse reachabilityCheckResponse = new ReachabilityCheckResponse();
        reachabilityCheckResponse.setValidated(true);
        ReachabilityCheckResponseData reachabilityCheckResponseData = new ReachabilityCheckResponseData();
        reachabilityCheckResponseData.setRoutingCode("12312312");
        List<ClearingSystemDetail> clearingSystemDetails = new ArrayList<>();
        ClearingSystemDetail clearingSystemDetail = new ClearingSystemDetail();
        clearingSystemDetail.setClearingSystem("Fedwire");
        clearingSystemDetails.add(clearingSystemDetail);
        reachabilityCheckResponseData.setClearingSystemDetails(clearingSystemDetails);
        reachabilityCheckResponse.setData(reachabilityCheckResponseData);

        doReturn(reachabilityCheckResponse).when(beneficiaryValidationUtility).reachabilityCheck(any(),anyString());

        MigBeneficiary migBeneficiary= new MigBeneficiary();
        migBeneficiary.setStatus("Success");
        doReturn(1).when(migBeneficiaryMapper).insertMigratedBene(migBeneficiary);
        EntityWrapper entityWrapper = new EntityWrapper(stgBeneficiary);
        entityWrapper.gatewayMigrationResponse = addBeneficiaryOCHResponse;
        doReturn(achPayeeManager).when(beneficiariesService).getBeneficiaryManager(Mockito.any(StgToTargetBeneEntity.PAYEE_TYPE.class));
        //doReturn(entityWrapper).when(achPayeeManager).migrateBeneficiaryToGateway(Mockito.any(EntityWrapper.class),Mockito.any(ProcessingContext.class));
        ProcessingContext processingContext = new ProcessingContext( 1L, achPayeeManager,  "http://serviceurl",  migClient,  primaryUserMigrated, ACH);

        entityWrapper = processEntity(entityWrapper, processingContext);
        ResultRecords resultRecords = beneficiariesService.setResultRecords(entityWrapper, processingContext);
        assertEquals("SUCCESS", entityWrapper.getStatus());
        assertFalse(entityWrapper.hasValidationErrors());
    }

    @Test
    public void addBene_IbanMandatoryValidationSuccess() throws JSONException, ServiceException, JsonProcessingException {
        setupSuccessfulMigration();
        StgToTargetBeneEntity stgBeneficiary = getDefaultStgToTargetBeneEntity();
        stgBeneficiary.setBENEFICIARY_BANK_IDENTIFIER("ABCD1234XYZ");

        MigClient migClient = new MigClient();
        migClient.setEcClientId("ola1234");
        migClient.setGwClientId("GWaddr1234");
        migClient.setJobId(Long.valueOf(1));
        migClient.setUpdatedBy("migUser");

        AddBeneficiaryResponse addBeneficiaryOCHResponse = new AddBeneficiaryResponse();
        addBeneficiaryOCHResponse.setData(null);

        BankBranchResponse bankBranchResponse = new BankBranchResponse();
        List<BankBranchResponseData> bankBranchResponseDataList = new ArrayList<>();
        BankBranchResponseData bankBranchResponseData = new BankBranchResponseData();
        Network network = new Network();
        network.setCmCode("BIC");
        BranchAddress branchAddress = new BranchAddress();
        branchAddress.setCity("London");
        Country country = new Country();
        country.setCmCode("GB");
        branchAddress.setCountry(country);
        bankBranchResponseData.setNetwork(network);
        bankBranchResponseData.setBranchAddress(branchAddress);
        bankBranchResponseDataList.add(bankBranchResponseData);
        bankBranchResponseDataList.add(bankBranchResponseData);
        bankBranchResponse.setData(bankBranchResponseDataList);
        bankBranchResponse.setValidated(true);

        setupAddressDoctorResponse();

        IbanCountryRulesResponse ibanCountryRulesResponse = new IbanCountryRulesResponse();
        ibanCountryRulesResponse.setValidated(true);
        IbanCountryRulesResponseData ibanCountryRulesResponseData = new IbanCountryRulesResponseData();
        BeneIbanAccountRule beneIbanAccountRule = new BeneIbanAccountRule();
        beneIbanAccountRule.setIbanRequired("M");
        ibanCountryRulesResponseData.setBeneficaryAccount(beneIbanAccountRule);
        ibanCountryRulesResponse.setData(ibanCountryRulesResponseData);

        doReturn(bankBranchResponse).when(beneficiaryValidationUtility).validateBankBranchAndFetchList(any());
        Mockito.doCallRealMethod().when(beneficiaryValidationUtility).removeSpecialChars(any());
        Mockito.doCallRealMethod().when(beneficiaryValidationUtility).removeSwift(any());

        doReturn(ibanCountryRulesResponse).when(beneficiaryValidationUtility).validateIbanCountrySpecificRulesAndValidation(any(),any(),anyLong(),anyString());

        MigBeneficiary migBeneficiary= new MigBeneficiary();
        migBeneficiary.setStatus("Success");
        doReturn(1).when(migBeneficiaryMapper).insertMigratedBene(migBeneficiary);
        EntityWrapper entityWrapper = new EntityWrapper(stgBeneficiary);
        entityWrapper.gatewayMigrationResponse = addBeneficiaryOCHResponse;
        doReturn(templatePayeeManager).when(beneficiariesService).getBeneficiaryManager(Mockito.any(StgToTargetBeneEntity.PAYEE_TYPE.class));

        ProcessingContext processingContext = new ProcessingContext( 1L, templatePayeeManager,  "http://serviceurl",  migClient,  primaryUserMigrated, TEMPLATE);

        entityWrapper = processEntity(entityWrapper, processingContext);
        ResultRecords resultRecords = beneficiariesService.setResultRecords(entityWrapper, processingContext);
        assertEquals("SUCCESS", entityWrapper.getStatus());
        assertFalse(entityWrapper.hasValidationErrors());
    }

    private StgToTargetBeneEntity getDefaultStgBeneficiary(StgToTargetBeneEntity stgBeneficiary) {
        return stgBeneficiary;
    }

    @Test
    public void addBene_IbanOptionalValidationSuccess() throws JSONException, ServiceException, JsonProcessingException {
        setupSuccessfulMigration();
        StgToTargetBeneEntity stgBeneficiary = getDefaultStgToTargetBeneEntity();
        stgBeneficiary.setBENEFICIARY_BANK_IDENTIFIER("ABCD1234");

        MigClient migClient = new MigClient();
        migClient.setEcClientId("ola1234");
        migClient.setGwClientId("GWaddr1234");
        migClient.setJobId(Long.valueOf(1));
        migClient.setUpdatedBy("migUser");

        AddBeneficiaryResponse addBeneficiaryOCHResponse = new AddBeneficiaryResponse();
        addBeneficiaryOCHResponse.setData(null);

        BankBranchResponse bankBranchResponse = new BankBranchResponse();
        List<BankBranchResponseData> bankBranchResponseDataList = new ArrayList<>();
        BankBranchResponseData bankBranchResponseData = new BankBranchResponseData();
        Network network = new Network();
        network.setCmCode("BIC");
        BranchAddress branchAddress = new BranchAddress();
        branchAddress.setCity("London");
        Country country = new Country();
        country.setCmCode("GB");
        branchAddress.setCountry(country);
        bankBranchResponseData.setNetwork(network);
        bankBranchResponseData.setBranchAddress(branchAddress);
        bankBranchResponseDataList.add(bankBranchResponseData);
        bankBranchResponseDataList.add(bankBranchResponseData);
        bankBranchResponse.setData(bankBranchResponseDataList);
        bankBranchResponse.setValidated(true);

        setupAddressDoctorResponse();

        IbanCountryRulesResponse ibanCountryRulesResponse = new IbanCountryRulesResponse();
        ibanCountryRulesResponse.setValidated(true);
        IbanCountryRulesResponseData ibanCountryRulesResponseData = new IbanCountryRulesResponseData();
        BeneIbanAccountRule beneIbanAccountRule = new BeneIbanAccountRule();
        beneIbanAccountRule.setIbanRequired("O");
        IbanFormatRule ibanFormatRule = new IbanFormatRule();
        ibanFormatRule.setIbanISOCountryCode("GB");
        beneIbanAccountRule.setIban(ibanFormatRule);
        ibanCountryRulesResponseData.setBeneficaryAccount(beneIbanAccountRule);
        ibanCountryRulesResponse.setData(ibanCountryRulesResponseData);

        doReturn(bankBranchResponse).when(beneficiaryValidationUtility).validateBankBranchAndFetchList(any());
        Mockito.doCallRealMethod().when(beneficiaryValidationUtility).removeSpecialChars(any());
        Mockito.doCallRealMethod().when(beneficiaryValidationUtility).removeSwift(any());

        doReturn(ibanCountryRulesResponse).when(beneficiaryValidationUtility).validateIbanCountrySpecificRulesAndValidation(any(),any(),anyLong(),anyString());

        MigBeneficiary migBeneficiary= new MigBeneficiary();
        migBeneficiary.setStatus("Success");
        doReturn(1).when(migBeneficiaryMapper).insertMigratedBene(migBeneficiary);
        EntityWrapper entityWrapper = new EntityWrapper(stgBeneficiary);
        entityWrapper.gatewayMigrationResponse = addBeneficiaryOCHResponse;
        doReturn(templatePayeeManager).when(beneficiariesService).getBeneficiaryManager(Mockito.any(StgToTargetBeneEntity.PAYEE_TYPE.class));
        //doReturn(entityWrapper).when(templatePayeeManager).migrateBeneficiaryToGateway(Mockito.any(EntityWrapper.class),Mockito.any(ProcessingContext.class));
        ProcessingContext processingContext = new ProcessingContext( 1L, templatePayeeManager,  "http://serviceurl",  migClient,  primaryUserMigrated, TEMPLATE);

        entityWrapper = processEntity(entityWrapper, processingContext);
        ResultRecords resultRecords = beneficiariesService.setResultRecords(entityWrapper, processingContext);
        assertEquals("SUCCESS", entityWrapper.getStatus());
        assertFalse(entityWrapper.hasValidationErrors());
    }

    @Test
    public void addBene_IbanOptionalNotGivenAndProceed() throws JSONException, ServiceException, JsonProcessingException {
        setupSuccessfulMigration();
        StgToTargetBeneEntity stgBeneficiary = getDefaultStgToTargetBeneEntity();
        int templateId = 1234;
        stgBeneficiary.setTEMPLATE_ID(templateId);
        stgBeneficiary.setBENEFICIARY_BANK_IDENTIFIER("AC123456XXX");

        MigClient migClient = new MigClient();
        migClient.setEcClientId("ola1234");
        migClient.setGwClientId("GWaddr1234");
        migClient.setJobId(Long.valueOf(1));
        migClient.setUpdatedBy("migUser");

        AddBeneficiaryResponse addBeneficiaryOCHResponse = new AddBeneficiaryResponse();
        addBeneficiaryOCHResponse.setData(null);

        BankBranchResponse bankBranchResponse = new BankBranchResponse();
        List<BankBranchResponseData> bankBranchResponseDataList = new ArrayList<>();
        BankBranchResponseData bankBranchResponseData = new BankBranchResponseData();
        Network network = new Network();
        network.setCmCode("BIC");
        BranchAddress branchAddress = new BranchAddress();
        branchAddress.setCity("London");
        Country country = new Country();
        country.setCmCode("GB");
        branchAddress.setCountry(country);
        bankBranchResponseData.setNetwork(network);
        bankBranchResponseData.setBranchAddress(branchAddress);
        bankBranchResponseDataList.add(bankBranchResponseData);
        bankBranchResponseDataList.add(bankBranchResponseData);
        bankBranchResponse.setData(bankBranchResponseDataList);
        bankBranchResponse.setValidated(true);

        setupAddressDoctorResponse();

        IbanCountryRulesResponse ibanCountryRulesResponse = new IbanCountryRulesResponse();
        ibanCountryRulesResponse.setValidated(true);
        IbanCountryRulesResponseData ibanCountryRulesResponseData = new IbanCountryRulesResponseData();
        BeneIbanAccountRule beneIbanAccountRule = new BeneIbanAccountRule();
        beneIbanAccountRule.setIbanRequired("O");
        IbanFormatRule ibanFormatRule = new IbanFormatRule();
        ibanFormatRule.setIbanISOCountryCode("GB");
        beneIbanAccountRule.setIban(ibanFormatRule);
        ibanCountryRulesResponseData.setBeneficaryAccount(beneIbanAccountRule);
        ibanCountryRulesResponse.setData(ibanCountryRulesResponseData);

        doReturn(bankBranchResponse).when(beneficiaryValidationUtility).validateBankBranchAndFetchList(any());
        Mockito.doCallRealMethod().when(beneficiaryValidationUtility).removeSpecialChars(any());
        Mockito.doCallRealMethod().when(beneficiaryValidationUtility).removeSwift(any());

        MigBeneficiary migBeneficiary= new MigBeneficiary();
        migBeneficiary.setStatus("Failure");
        doReturn(1).when(migBeneficiaryMapper).insertMigratedBene(migBeneficiary);

        doReturn(ibanCountryRulesResponse).when(beneficiaryValidationUtility).validateIbanCountrySpecificRulesAndValidation(any(),any(),anyLong(),anyString());
        EntityWrapper entityWrapper = new EntityWrapper(stgBeneficiary);
        entityWrapper.gatewayMigrationResponse = addBeneficiaryOCHResponse;
        doReturn(templatePayeeManager).when(beneficiariesService).getBeneficiaryManager(Mockito.any(StgToTargetBeneEntity.PAYEE_TYPE.class));

        ProcessingContext processingContext = new ProcessingContext( 1L, templatePayeeManager,  "http://serviceurl",  migClient,  primaryUserMigrated, TEMPLATE);

        entityWrapper = processEntity(entityWrapper, processingContext);
        ResultRecords resultRecords = beneficiariesService.setResultRecords(entityWrapper, processingContext);
        assertEquals("SUCCESS", entityWrapper.getStatus());
        assertTrue(entityWrapper.hasMigrationResponse());
        assertFalse(entityWrapper.hasUnexpectedErrors());
        assertFalse(entityWrapper.hasValidationErrors());
        assertEquals(templateId, resultRecords.getTemplateId());
        assertEquals("Successfully Migrated to Gateway", resultRecords.getComments());
        assertEquals("SUCCESS", resultRecords.getStatus());
    }

    @Test
    public void addBene_IbanNAAndProceed() throws JSONException, ServiceException, JsonProcessingException {
        setupSuccessfulMigration();
        StgToTargetBeneEntity stgBeneficiary = getDefaultStgToTargetBeneEntity();
        stgBeneficiary.setBENEFICIARY_BANK_IDENTIFIER("ABCD1234");
        MigClient migClient = new MigClient();
        migClient.setEcClientId("ola1234");
        migClient.setGwClientId("GWaddr1234");
        migClient.setJobId(Long.valueOf(1));
        migClient.setUpdatedBy("migUser");

        AddBeneficiaryResponse addBeneficiaryOCHResponse = new AddBeneficiaryResponse();
        addBeneficiaryOCHResponse.setData(null);

        BankBranchResponse bankBranchResponse = new BankBranchResponse();
        List<BankBranchResponseData> bankBranchResponseDataList = new ArrayList<>();
        BankBranchResponseData bankBranchResponseData = new BankBranchResponseData();
        Network network = new Network();
        network.setCmCode("BIC");
        BranchAddress branchAddress = new BranchAddress();
        branchAddress.setCity("London");
        Country country = new Country();
        country.setCmCode("GB");
        branchAddress.setCountry(country);
        bankBranchResponseData.setNetwork(network);
        bankBranchResponseData.setBranchAddress(branchAddress);
        bankBranchResponseDataList.add(bankBranchResponseData);
        bankBranchResponseDataList.add(bankBranchResponseData);
        bankBranchResponse.setData(bankBranchResponseDataList);
        bankBranchResponse.setValidated(true);

        setupAddressDoctorResponse();

        IbanCountryRulesResponse ibanCountryRulesResponse = new IbanCountryRulesResponse();
        ibanCountryRulesResponse.setValidated(true);
        IbanCountryRulesResponseData ibanCountryRulesResponseData = new IbanCountryRulesResponseData();
        BeneIbanAccountRule beneIbanAccountRule = new BeneIbanAccountRule();
        beneIbanAccountRule.setIbanRequired("NA");
        ibanCountryRulesResponseData.setBeneficaryAccount(beneIbanAccountRule);
        ibanCountryRulesResponse.setData(ibanCountryRulesResponseData);

        doReturn(bankBranchResponse).when(beneficiaryValidationUtility).validateBankBranchAndFetchList(any());
        Mockito.doCallRealMethod().when(beneficiaryValidationUtility).removeSpecialChars(any());
        Mockito.doCallRealMethod().when(beneficiaryValidationUtility).removeSwift(any());

        doReturn(ibanCountryRulesResponse).when(beneficiaryValidationUtility).validateIbanCountrySpecificRulesAndValidation(any(),any(),anyLong(),anyString());

        MigBeneficiary migBeneficiary= new MigBeneficiary();
        migBeneficiary.setStatus("Success");
        doReturn(1).when(migBeneficiaryMapper).insertMigratedBene(migBeneficiary);
        EntityWrapper entityWrapper = new EntityWrapper(stgBeneficiary);
        entityWrapper.gatewayMigrationResponse = addBeneficiaryOCHResponse;
        doReturn(templatePayeeManager).when(beneficiariesService).getBeneficiaryManager(Mockito.any(StgToTargetBeneEntity.PAYEE_TYPE.class));

        ProcessingContext processingContext = new ProcessingContext( 1L, templatePayeeManager,  "http://serviceurl",  migClient,  primaryUserMigrated, TEMPLATE);

        entityWrapper = processEntity(entityWrapper, processingContext);
        ResultRecords resultRecords = beneficiariesService.setResultRecords(entityWrapper, processingContext);
        assertEquals("SUCCESS", entityWrapper.getStatus());
        assertFalse(entityWrapper.hasValidationErrors());
    }

    @Test
    public void addBene_IbanNAAndProceedInvalidLength() throws JSONException, ServiceException, JsonProcessingException {
        setupSuccessfulMigration();
        StgToTargetBeneEntity stgBeneficiary = getDefaultStgToTargetBeneEntity();
        getInvalidLengthStgToTargetBeneEntity(stgBeneficiary);
        MigClient migClient = new MigClient();
        migClient.setEcClientId("ola1234");
        migClient.setGwClientId("GWaddr1234");
        migClient.setJobId(Long.valueOf(1));
        migClient.setUpdatedBy("migUser");

        AddBeneficiaryResponse addBeneficiaryOCHResponse = new AddBeneficiaryResponse();
        addBeneficiaryOCHResponse.setData(null);

        BankBranchResponse bankBranchResponse = new BankBranchResponse();
        List<BankBranchResponseData> bankBranchResponseDataList = new ArrayList<>();
        BankBranchResponseData bankBranchResponseData = new BankBranchResponseData();
        Network network = new Network();
        network.setCmCode("BIC");
        BranchAddress branchAddress = new BranchAddress();
        branchAddress.setCity("London");
        Country country = new Country();
        country.setCmCode("GB");
        branchAddress.setCountry(country);
        bankBranchResponseData.setNetwork(network);
        bankBranchResponseData.setBranchAddress(branchAddress);
        bankBranchResponseDataList.add(bankBranchResponseData);
        bankBranchResponseDataList.add(bankBranchResponseData);
        bankBranchResponse.setData(bankBranchResponseDataList);
        bankBranchResponse.setValidated(true);

        setupInvalidLengthNonUSAddressDoctorResponse();

        IbanCountryRulesResponse ibanCountryRulesResponse = new IbanCountryRulesResponse();
        ibanCountryRulesResponse.setValidated(true);
        IbanCountryRulesResponseData ibanCountryRulesResponseData = new IbanCountryRulesResponseData();
        BeneIbanAccountRule beneIbanAccountRule = new BeneIbanAccountRule();
        beneIbanAccountRule.setIbanRequired("NA");
        beneIbanAccountRule.setAccountNumberRegex("^\\\\d{3,12}$");
        ibanCountryRulesResponseData.setBeneficaryAccount(beneIbanAccountRule);
        ibanCountryRulesResponse.setData(ibanCountryRulesResponseData);

        doReturn(bankBranchResponse).when(beneficiaryValidationUtility).validateBankBranchAndFetchList(any());
        Mockito.doCallRealMethod().when(beneficiaryValidationUtility).removeSpecialChars(any());
        Mockito.doCallRealMethod().when(beneficiaryValidationUtility).removeSwift(any());

        doReturn(ibanCountryRulesResponse).when(beneficiaryValidationUtility).validateIbanCountrySpecificRulesAndValidation(any(),any(),anyLong(),anyString());

        MigBeneficiary migBeneficiary= new MigBeneficiary();
        migBeneficiary.setStatus("Success");
        doReturn(1).when(migBeneficiaryMapper).insertMigratedBene(migBeneficiary);
        EntityWrapper entityWrapper = new EntityWrapper(stgBeneficiary);
        entityWrapper.gatewayMigrationResponse = addBeneficiaryOCHResponse;
        doReturn(templatePayeeManager).when(beneficiariesService).getBeneficiaryManager(Mockito.any(StgToTargetBeneEntity.PAYEE_TYPE.class));

        ProcessingContext processingContext = new ProcessingContext( 1L, templatePayeeManager,  "http://serviceurl",  migClient,  primaryUserMigrated, TEMPLATE);

        entityWrapper = processEntity(entityWrapper, processingContext);
        ResultRecords resultRecords = beneficiariesService.setResultRecords(entityWrapper, processingContext);
        assertEquals("FAILURE", entityWrapper.getStatus());
        assertTrue(entityWrapper.hasValidationErrors());
        assertTrue(entityWrapper.getValidationErrorList().get(0).getCode().equalsIgnoreCase("ERR1004"));
    }


    @Ignore // handling errors differently
    public void addBene_ExceptionAfterOchCall() throws JSONException, ServiceException, JsonProcessingException, Exception {

        StgToTargetBeneEntity stgBeneficiary = getDefaultStgToTargetBeneEntity();

        MigClient migClient = new MigClient();
        migClient.setEcClientId("ola1234");
        migClient.setGwClientId("GWaddr1234");
        migClient.setJobId(Long.valueOf(1));
        migClient.setUpdatedBy("migUser");

        AddBeneficiaryResponse addBeneficiaryOCHResponse = new AddBeneficiaryResponse();
        AddBeneficiaryResponseData addBeneficiaryResponseData = new AddBeneficiaryResponseData();
        addBeneficiaryResponseData.setGroupId("1234");
        Status status=new Status();
        status.setCodeDescription("Success");
        addBeneficiaryResponseData.setStatus(status);

        addBeneficiaryOCHResponse.setData(addBeneficiaryResponseData);


        BankBranchResponse bankBranchResponse = new BankBranchResponse();
        List<BankBranchResponseData> bankBranchResponseDataList = new ArrayList<>();
        BankBranchResponseData bankBranchResponseData = new BankBranchResponseData();
        Network network = new Network();
        network.setCmCode("ABA");
        BranchAddress branchAddress = new BranchAddress();
        branchAddress.setCity("Los Angeles");
        Country country = new Country();
        country.setCmCode("US");
        branchAddress.setCountry(country);
        bankBranchResponseData.setNetwork(network);
        bankBranchResponseData.setBranchAddress(branchAddress);
        bankBranchResponseDataList.add(bankBranchResponseData);
        bankBranchResponse.setData(bankBranchResponseDataList);
        bankBranchResponse.setValidated(true);

        AddressResponse response = new AddressResponse();
        response.setValidationscore("c4");
        doReturn(response).when(addressDoctor).validateAddress(ArgumentMatchers.anyString(), ArgumentMatchers.anyString(),  any());

        ReachabilityCheckResponse reachabilityCheckResponse = new ReachabilityCheckResponse();
        reachabilityCheckResponse.setValidated(true);
        ReachabilityCheckResponseData reachabilityCheckResponseData = new ReachabilityCheckResponseData();
        reachabilityCheckResponseData.setRoutingCode("12312312");
        List<ClearingSystemDetail> clearingSystemDetails = new ArrayList<>();
        ClearingSystemDetail clearingSystemDetail = new ClearingSystemDetail();
        clearingSystemDetail.setClearingSystem("Fedwire");
        clearingSystemDetails.add(clearingSystemDetail);
        reachabilityCheckResponseData.setClearingSystemDetails(clearingSystemDetails);
        reachabilityCheckResponse.setData(reachabilityCheckResponseData);

        doReturn(bankBranchResponse).when(beneficiaryValidationUtility).validateBankBranchAndFetchList(any());
        Mockito.doCallRealMethod().when(beneficiaryValidationUtility).removeSpecialChars(any());
        Mockito.doCallRealMethod().when(beneficiaryValidationUtility).removeSwift(any());

        doReturn(reachabilityCheckResponse).when(beneficiaryValidationUtility).reachabilityCheck(any(),anyString());

        doReturn(templatePayeeManager).when(beneficiariesService).getBeneficiaryManager(Mockito.any(StgToTargetBeneEntity.PAYEE_TYPE.class));
        //doReturn(addBeneficiaryOCHResponse).when(templatePayeeManager).invokeOCHServiceAddBeneficiary(Mockito.any(AddBeneficiaryRequest.class),Mockito.anyString());
        doReturn(null).when(templatePayeeManager).prepareRequest(Mockito.any(EntityWrapper.class), Mockito.any(ProcessingContext.class)/*, Mockito.any(MigClient.class), Mockito.anyString(), Mockito.any(StgToTargetBeneEntity.PAYEE_TYPE.class)*/);

        //restTemplate.exchange(serviceUrl, HttpMethod.POST, requestEntity, BeneficiaryInfo.class);
        Mockito.when(retryService.exchange(Mockito.anyString(), any(HttpMethod.class), any(HttpEntity.class), any() )).thenThrow(new NullPointerException("Beneficiary Creation failed."));
        ProcessingContext processingContext = new ProcessingContext( 1L, templatePayeeManager,  "http://serviceurl",  migClient,  primaryUserMigrated, TEMPLATE);


        IBeneficiaryManager beneManager = beneficiariesService.getBeneficiaryManager(TEMPLATE);
        EntityWrapper entityWrapper = beneManager.prepareRequest(new EntityWrapper(stgBeneficiary), processingContext);
        entityWrapper = beneManager.migrateBeneficiaryToGateway(entityWrapper, processingContext);
        entityWrapper =  beneManager.updateBeneficiaryDBRecord(entityWrapper, processingContext);

        String expectedMessage = "Beneficiary Creation failed.";
        String actualMessage = entityWrapper.getValidationErrorList().get(0).getDescription();
        assertTrue(entityWrapper.hasUnexpectedErrors());
        assertTrue(actualMessage.contains(expectedMessage));
    }

    @Ignore // handling errors differently
    public void addBene_ExceptionAfterOchCallForSourceWireTxn() throws JSONException, ServiceException, JsonProcessingException, Exception {

        StgToTargetBeneEntity stgBeneficiary = getDefaultStgToTargetBeneEntity();



        AddBeneficiaryResponse addBeneficiaryOCHResponse = new AddBeneficiaryResponse();
        AddBeneficiaryResponseData addBeneficiaryResponseData = new AddBeneficiaryResponseData();
        addBeneficiaryResponseData.setGroupId("1234");
        Status status=new Status();
        status.setCodeDescription("Success");
        addBeneficiaryResponseData.setStatus(status);

        addBeneficiaryOCHResponse.setData(addBeneficiaryResponseData);


        BankBranchResponse bankBranchResponse = new BankBranchResponse();
        List<BankBranchResponseData> bankBranchResponseDataList = new ArrayList<>();
        BankBranchResponseData bankBranchResponseData = new BankBranchResponseData();
        Network network = new Network();
        network.setCmCode("ABA");
        BranchAddress branchAddress = new BranchAddress();
        branchAddress.setCity("Los Angeles");
        Country country = new Country();
        country.setCmCode("US");
        branchAddress.setCountry(country);
        bankBranchResponseData.setNetwork(network);
        bankBranchResponseData.setBranchAddress(branchAddress);
        bankBranchResponseDataList.add(bankBranchResponseData);
        bankBranchResponse.setData(bankBranchResponseDataList);
        bankBranchResponse.setValidated(true);



        ReachabilityCheckResponse reachabilityCheckResponse = new ReachabilityCheckResponse();
        reachabilityCheckResponse.setValidated(true);
        ReachabilityCheckResponseData reachabilityCheckResponseData = new ReachabilityCheckResponseData();
        reachabilityCheckResponseData.setRoutingCode("12312312");
        List<ClearingSystemDetail> clearingSystemDetails = new ArrayList<>();
        ClearingSystemDetail clearingSystemDetail = new ClearingSystemDetail();
        clearingSystemDetail.setClearingSystem("Fedwire");
        clearingSystemDetails.add(clearingSystemDetail);
        reachabilityCheckResponseData.setClearingSystemDetails(clearingSystemDetails);
        reachabilityCheckResponse.setData(reachabilityCheckResponseData);

        doReturn(bankBranchResponse).when(beneficiaryValidationUtility).validateBankBranchAndFetchList(any());
        Mockito.doCallRealMethod().when(beneficiaryValidationUtility).removeSpecialChars(any());
        Mockito.doCallRealMethod().when(beneficiaryValidationUtility).removeSwift(any());

        doReturn(reachabilityCheckResponse).when(beneficiaryValidationUtility).reachabilityCheck(any(),anyString());

        doReturn(futurePayeeManager).when(beneficiariesService).getBeneficiaryManager(Mockito.any(StgToTargetBeneEntity.PAYEE_TYPE.class));
        doReturn(addBeneficiaryOCHResponse).when(futurePayeeManager).migrateBeneficiaryToGateway(Mockito.any(EntityWrapper.class),Mockito.any(ProcessingContext.class));
        ProcessingContext processingContext = new ProcessingContext( 1L, futurePayeeManager,  "http://serviceurl",  migClient,  primaryUserMigrated, FUTURE);

        IBeneficiaryManager beneManager = beneficiariesService.getBeneficiaryManager(FUTURE);
        EntityWrapper entityWrapper = beneManager.prepareRequest(new EntityWrapper(stgBeneficiary), processingContext);

        AddressResponse response = new AddressResponse();
        response.setValidationscore("c4");
        doReturn(response).when(addressDoctor).validateAddress(ArgumentMatchers.anyString(), ArgumentMatchers.anyString(), entityWrapper);

        entityWrapper = processEntity(entityWrapper, processingContext);
        ResultRecords resultRecords = beneficiariesService.setResultRecords(entityWrapper, processingContext);
        assertEquals("SUCCESS", entityWrapper.getStatus());
        assertFalse(entityWrapper.hasValidationErrors());

        String expectedMessage = "Beneficiary Creation failed.";
        String actualMessage = entityWrapper.getUnexpectedErrorList().get(0).getDescription();

        assertTrue(entityWrapper.hasUnexpectedErrors());
        assertTrue(actualMessage.contains(expectedMessage));
    }


    @Test
    public void createBeneOCHServiceExceptionNoContext() throws Exception {
        setupOCHBadRequestError();
        StgToTargetBeneEntity stgBeneficiary = getDefaultStgToTargetBeneEntity();
        MigClient migClient = new MigClient();
        migClient.setEcClientId("ola1234");
        migClient.setGwClientId("GWaddr1234");
        migClient.setJobId(jobId);
        migClient.setUpdatedBy("migUser");


        List<BankEntity> bankEntities = new ArrayList<>();
        BankEntity bankEntity = new BankEntity();
        bankEntity.setNETWORK_TYPE("BIC");
        bankEntity.setCITY("Santa Clara");
        bankEntity.setBANK_REF_NO("12345");
        bankEntity.setCOUNTRY_CODE("UK");
        bankEntities.add(bankEntity);

        doReturn(bankEntities).when(bankMapper).getBankBranchInfoWithOutNetworkReach(Mockito.anyString());
        EntityWrapper entityWrapper = new EntityWrapper(stgBeneficiary);
        MigBeneficiary migBeneficiary= new MigBeneficiary();
        migBeneficiary.setStatus("Failure");
        doReturn(1).when(migBeneficiaryMapper).insertMigratedBene(migBeneficiary);

        doReturn(templatePayeeManager).when(beneficiariesService).getBeneficiaryManager(Mockito.any(StgToTargetBeneEntity.PAYEE_TYPE.class));
        //doReturn(entityWrapper).when(templatePayeeManager).migrateBeneficiaryToGateway(Mockito.any(EntityWrapper.class),Mockito.any(ProcessingContext.class));
        ProcessingContext processingContext = new ProcessingContext( 1L, templatePayeeManager,  "http://serviceurl",  migClient,  primaryUserMigrated, TEMPLATE);

        entityWrapper = processEntity(entityWrapper, processingContext);
        ResultRecords resultRecords = beneficiariesService.setResultRecords(entityWrapper, processingContext);
        assertEquals("FAILURE", entityWrapper.getStatus());
        assertTrue(entityWrapper.hasUnexpectedErrors());
    }

    @Test
    public void createBeneOCHServiceGenericException() throws Exception {
        AddBeneficiaryRequest addBeneficiaryRequest=new AddBeneficiaryRequest();
        String serviceUrl="";
        String oAuth="";
        BeneficiaryInfo beneficiaryInfoData=new BeneficiaryInfo();

        ResponseEntity<BeneficiaryInfo> beneficiaryInfo = new ResponseEntity(beneficiaryInfoData, HttpStatus.OK);
        List<ResponsePaymentDetail> paymentDetails=new ArrayList<>();
        ResponsePaymentDetail responsePaymentDetail = new ResponsePaymentDetail();
        responsePaymentDetail.setCounterpartyId("1234");
        responsePaymentDetail.setPayeeListId("567");
        paymentDetails.add(responsePaymentDetail);
        beneficiaryInfo.getBody().setPaymentDetails(paymentDetails);
        StgToTargetBeneEntity stgBeneficiary = getDefaultStgToTargetBeneEntity();
        EntityWrapper entityWrapper = new EntityWrapper(stgBeneficiary);
        entityWrapper.setGatewayMigrationRequest(addBeneficiaryRequest);
        when(cacheManagerUtility.getOauthToken()).thenReturn("xyz");
        doReturn(null).when(retryService).exchange(Mockito.anyString(), Mockito.any(HttpMethod.class), Mockito.any(HttpEntity.class), any());
        ProcessingContext processingContext = new ProcessingContext( 1L, templatePayeeManager,  "http://serviceurl",  migClient,  primaryUserMigrated, TEMPLATE);
        // entityWrapper = templatePayeeManager.migrateBeneficiaryToGateway(entityWrapper,processingContext);
        entityWrapper = processEntity(entityWrapper, processingContext);
        ResultRecords resultRecords = beneficiariesService.setResultRecords(entityWrapper, processingContext);
        assertEquals("FAILURE", entityWrapper.getStatus());

        assertTrue(entityWrapper.hasUnexpectedErrors());
    }

    @Test
    public void addBene_IpayDataNAorNULL_Ignore() throws JSONException, ServiceException, JsonProcessingException {
        StgToTargetBeneEntity stgBeneficiary = getDefaultStgToTargetBeneEntity();
        stgBeneficiary.setBENEFICIARY_ACCOUNT("NA");
        stgBeneficiary.setBENEFICIARY_BANK_IDENTIFIER(null);
        MigClient migClient = new MigClient();
        migClient.setEcClientId("ola1234");
        migClient.setGwClientId("GWaddr1234");
        migClient.setJobId(jobId);
        migClient.setUpdatedBy("migUser");
        EntityWrapper entityWrapper = new EntityWrapper(stgBeneficiary);
        doReturn(achLargePayeeManager).when(beneficiariesService).getBeneficiaryManager(Mockito.any(StgToTargetBeneEntity.PAYEE_TYPE.class));
        ProcessingContext processingContext = new ProcessingContext( 1L, achLargePayeeManager,  "http://serviceurl",  migClient,  primaryUserMigrated, ACH_LARGE);

        entityWrapper = processEntity(entityWrapper, processingContext);
        assertEquals("IGNORE", entityWrapper.getStatus());
        assertTrue(entityWrapper.hasValidationErrors());
    }

}
