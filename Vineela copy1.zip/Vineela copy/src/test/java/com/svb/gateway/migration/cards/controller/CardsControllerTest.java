package com.svb.gateway.migration.cards.controller;

import com.svb.gateway.migration.cards.model.CardProgramInformationResponse;
import com.svb.gateway.migration.cards.service.CardsService;
import com.svb.gateway.migration.client.service.ClientService;
import com.svb.gateway.migration.common.exception.InvalidInputException;
import com.svb.gateway.migration.common.exception.ServiceException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.web.servlet.MockMvc;

import static junit.framework.TestCase.assertEquals;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;

@SpringBootTest
@AutoConfigureMockMvc
public class CardsControllerTest {

    @InjectMocks
    CardsController cardsController;
    @MockBean
    private CardsService cardsService;
    @MockBean
    private ClientService clientService;
    @Autowired
    private MockMvc mockMvc;

    @BeforeEach
    public void setup() throws Exception {
        cardsController = new CardsController(cardsService, clientService);
    }

    @Test
    public void null_resp1() throws Exception {

        doReturn(null).when(cardsService).addCardProgramToClient(Mockito.anyLong(), Mockito.any());

        ResponseEntity<?> re = cardsController.addCardProgram(1234L, "GWdr5414");

        assertEquals(HttpStatus.NOT_FOUND, re.getStatusCode());

    }

    @Test
    public void invalidInput() throws Exception {

        doThrow(new InvalidInputException("Invalid Input")).when(cardsService).addCardProgramToClient(Mockito.anyLong(), Mockito.any());

        ResponseEntity<?> re = cardsController.addCardProgram(1234L, "GWar5414");

        assertEquals(HttpStatus.BAD_REQUEST, re.getStatusCode());

    }

    @Test
    public void Error_Not_Modified() throws Exception {
        doThrow(new ServiceException("Internal Server Error")).when(cardsService).addCardProgramToClient(Mockito.anyLong(), Mockito.any());

        ResponseEntity<?> re = cardsController.addCardProgram(1234L, "GWar5414");

        assertEquals(HttpStatus.NOT_MODIFIED, re.getStatusCode());
    }

    @Test
    public void resp1() throws Exception {
        CardProgramInformationResponse cardProgramInformation = new CardProgramInformationResponse();
        doReturn(cardProgramInformation).when(cardsService).addCardProgramToClient(Mockito.anyLong(), Mockito.any());

        ResponseEntity<?> re = cardsController.addCardProgram(1234L, "GWar5414");

        assertEquals(HttpStatus.OK, re.getStatusCode());
    }

}
