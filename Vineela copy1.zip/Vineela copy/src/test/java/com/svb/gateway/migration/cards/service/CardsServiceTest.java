package com.svb.gateway.migration.cards.service;

import com.svb.gateway.migration.cards.entity.MigCardProgram;
import com.svb.gateway.migration.cards.entity.MigStgCardProgram;
import com.svb.gateway.migration.cards.model.CardProgramInformation;
import com.svb.gateway.migration.cards.model.CardProgramInformationResponse;
import com.svb.gateway.migration.cards.repository.CardProgramRepository;
import com.svb.gateway.migration.cards.repository.MigCardProgramRepository;
import com.svb.gateway.migration.cards.repository.MigStgClientRepository;
import com.svb.gateway.migration.client.entity.MigClient;
import com.svb.gateway.migration.client.entity.StgClient;
import com.svb.gateway.migration.client.repository.MigClientRepository;
import com.svb.gateway.migration.common.exception.ServiceException;
import com.svb.gateway.migration.common.service.RetryService;
import com.svb.gateway.migration.payments.entity.MigrationEntity;
import com.svb.gateway.migration.payments.repository.MigrationEntityRepository;
import com.svb.gateway.migration.rollback.model.RollBackResponse;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.*;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.*;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static com.svb.gateway.migration.common.constants.MigrationConstants.STATUS_FAILURE;
import static com.svb.gateway.migration.common.constants.MigrationConstants.STATUS_SUCCESS;
import static junit.framework.TestCase.assertEquals;
import static junit.framework.TestCase.assertTrue;
import static org.mockito.Mockito.*;


@SpringBootTest
@ExtendWith(SpringExtension.class)
public class CardsServiceTest {

    public static String cifs;
    @InjectMocks
    @Spy
    CardsService cardsService;
    @Mock
    RetryService retryService;
    @Value(value = "${mig.cardsPost.url}")
    String cardsPostUrl;

    @Mock
    MigClientRepository migClientRepository;

    @Mock
    MigCardProgramRepository migCardProgramRepository;

    @Mock
    MigStgClientRepository migStgClientRepository;

    @Mock
    CardProgramRepository cardProgramRepository;

    @Mock
    MigrationEntityRepository migrationEntityRepository;

    @BeforeAll
    public static void setUp() {
        cifs = "200034567";
    }

    @Test
    public void AddCardProgramSuccess() throws ServiceException {

        MigClient migClient = new MigClient();
        migClient.setEcClientId("addr7550");
        migClient.setPrimaryCifUbs(2);
        migClient.setJobId(2l);
        when(migClientRepository.findByEcClientIdAndJobId(Mockito.anyString(), Mockito.anyLong())).thenReturn(migClient);

        StgClient stgClient = new StgClient();
        stgClient.setClientName("clientName");
        when(migStgClientRepository.findByOlbClientId(anyLong(), Mockito.anyString())).thenReturn(stgClient);

        List<MigStgCardProgram> migStgCardProgramList = new ArrayList<>();
        MigStgCardProgram migStgCardProgram = new MigStgCardProgram();
        migStgCardProgram.setPrincipalId("8000");
        migStgCardProgramList.add(migStgCardProgram);

        doReturn(migStgCardProgramList).when(cardProgramRepository).findByOlbId(anyLong(), Mockito.anyString());

        CardProgramInformation cardProgramInformation = new CardProgramInformation();
        cardProgramInformation.setStatus("1");

        ResponseEntity<CardProgramInformation> cardProgramInformationResponseEntity = new ResponseEntity<>(cardProgramInformation, HttpStatus.OK);

        doReturn(cardProgramInformationResponseEntity).when(retryService).exchange(Mockito.anyString(), any(HttpMethod.class), any(HttpEntity.class), any());

        MigCardProgram migCardProgram = new MigCardProgram();
        doReturn(migCardProgram).when(migCardProgramRepository).save(Mockito.any());

        MigrationEntity migrationEntity = new MigrationEntity();
        doReturn(migrationEntity).when(migrationEntityRepository).save(Mockito.any());

        CardProgramInformationResponse cardProgramInformationResponse = cardsService.addCardProgramToClient(124L, migClient);

        assertEquals(1, cardProgramInformationResponse.getCardProgramInformationList().size());

    }

    @Test
    public void AddCardProgramNoRetry() throws ServiceException {

        MigClient migClient = new MigClient();
        migClient.setEcClientId("addr7550");
        migClient.setPrimaryCifUbs(2);
        migClient.setJobId(2l);
        migClient.setGwClientId("Gw123423");
        when(migClientRepository.findByEcClientIdAndJobId(Mockito.anyString(), Mockito.anyLong())).thenReturn(migClient);

        StgClient stgClient = new StgClient();
        stgClient.setClientName("clientName");
        when(migStgClientRepository.findByOlbClientId(anyLong(), Mockito.anyString())).thenReturn(stgClient);

        List<MigStgCardProgram> migStgCardProgramList = new ArrayList<>();
        MigStgCardProgram migStgCardProgram = new MigStgCardProgram();
        migStgCardProgram.setPrincipalId("8000");
        migStgCardProgram.setCompanyId("programId");
        migStgCardProgramList.add(migStgCardProgram);

        doReturn(migStgCardProgramList).when(cardProgramRepository).findByOlbId(anyLong(), Mockito.anyString());

        // make it NOT retry because earlier success
        List<MigCardProgram> existingMigCardPrograms = new ArrayList<>();
        MigCardProgram existingMigCardProgram = new MigCardProgram();
        existingMigCardProgram.setStatus(STATUS_SUCCESS);
        existingMigCardProgram.setProgramId("programId");
        existingMigCardPrograms.add(existingMigCardProgram);
        doReturn(existingMigCardPrograms).when(migCardProgramRepository).findByOlbId(anyString());

        CardProgramInformation cardProgramInformation = new CardProgramInformation();
        cardProgramInformation.setStatus("1");

        ResponseEntity<CardProgramInformation> cardProgramInformationResponseEntity = new ResponseEntity<>(cardProgramInformation, HttpStatus.OK);

        doReturn(cardProgramInformationResponseEntity).when(retryService).exchange(Mockito.anyString(), any(HttpMethod.class), any(HttpEntity.class), any());

        MigCardProgram migCardProgram = new MigCardProgram();
        doReturn(migCardProgram).when(migCardProgramRepository).save(Mockito.any());

        MigrationEntity migrationEntity = new MigrationEntity();
        doReturn(migrationEntity).when(migrationEntityRepository).save(Mockito.any());

        CardProgramInformationResponse cardProgramInformationResponse = cardsService.addCardProgramToClient(124L, migClient);

        assertEquals(true, cardProgramInformationResponse.getCardProgramInformationList().isEmpty());

    }

    @Test
    public void AddCardProgramRetry() throws ServiceException {

        MigClient migClient = new MigClient();
        migClient.setEcClientId("addr7550");
        migClient.setPrimaryCifUbs(2);
        migClient.setJobId(2l);
        migClient.setGwClientId("Gw123423");
        when(migClientRepository.findByEcClientIdAndJobId(Mockito.anyString(), Mockito.anyLong())).thenReturn(migClient);

        StgClient stgClient = new StgClient();
        stgClient.setClientName("clientName");
        when(migStgClientRepository.findByOlbClientId(anyLong(), Mockito.anyString())).thenReturn(stgClient);

        List<MigStgCardProgram> migStgCardProgramList = new ArrayList<>();
        MigStgCardProgram migStgCardProgram = new MigStgCardProgram();
        migStgCardProgram.setPrincipalId("8000");
        migStgCardProgram.setCompanyId("programId");
        migStgCardProgramList.add(migStgCardProgram);

        doReturn(migStgCardProgramList).when(cardProgramRepository).findByOlbId(anyLong(), Mockito.anyString());

        // make it retry
        List<MigCardProgram> existingMigCardPrograms = new ArrayList<>();
        MigCardProgram existingMigCardProgram = new MigCardProgram();
        existingMigCardProgram.setStatus(STATUS_FAILURE);
        existingMigCardProgram.setProgramId("programId");
        existingMigCardPrograms.add(existingMigCardProgram);
        doReturn(existingMigCardPrograms).when(migCardProgramRepository).findByOlbId(anyString());

        CardProgramInformation cardProgramInformation = new CardProgramInformation();
        cardProgramInformation.setStatus("1");

        ResponseEntity<CardProgramInformation> cardProgramInformationResponseEntity = new ResponseEntity<>(cardProgramInformation, HttpStatus.OK);

        doReturn(cardProgramInformationResponseEntity).when(retryService).exchange(Mockito.anyString(), any(HttpMethod.class), any(HttpEntity.class), any());

        MigCardProgram migCardProgram = new MigCardProgram();
        doReturn(migCardProgram).when(migCardProgramRepository).save(Mockito.any());

        MigrationEntity migrationEntity = new MigrationEntity();
        doReturn(migrationEntity).when(migrationEntityRepository).save(Mockito.any());

        CardProgramInformationResponse cardProgramInformationResponse = cardsService.addCardProgramToClient(124L, migClient);

        assertEquals(1, cardProgramInformationResponse.getCardProgramInformationList().size());

    }

    @Test
    public void AddCardProgramRetryFailure() throws ServiceException {

        MigClient migClient = new MigClient();
        migClient.setEcClientId("addr7550");
        migClient.setPrimaryCifUbs(2);
        migClient.setJobId(2l);
        migClient.setGwClientId("Gw123423");
        when(migClientRepository.findByEcClientIdAndJobId(Mockito.anyString(), Mockito.anyLong())).thenReturn(migClient);

        StgClient stgClient = new StgClient();
        stgClient.setClientName("clientName");
        when(migStgClientRepository.findByOlbClientId(anyLong(), Mockito.anyString())).thenReturn(stgClient);

        List<MigStgCardProgram> migStgCardProgramList = new ArrayList<>();
        MigStgCardProgram migStgCardProgram = new MigStgCardProgram();
        migStgCardProgram.setPrincipalId("8000");
        migStgCardProgram.setCompanyId("programId");
        migStgCardProgramList.add(migStgCardProgram);

        doReturn(migStgCardProgramList).when(cardProgramRepository).findByOlbId(anyLong(), Mockito.anyString());

        // make it retry
        List<MigCardProgram> existingMigCardPrograms = new ArrayList<>();
        MigCardProgram existingMigCardProgram = new MigCardProgram();
        existingMigCardProgram.setStatus(STATUS_FAILURE);
        existingMigCardProgram.setProgramId("programId");
        existingMigCardPrograms.add(existingMigCardProgram);
        doReturn(existingMigCardPrograms).when(migCardProgramRepository).findByOlbId(anyString());

        CardProgramInformation cardProgramInformation = new CardProgramInformation();
        cardProgramInformation.setStatus("0");

        ResponseEntity<CardProgramInformation> cardProgramInformationResponseEntity = new ResponseEntity<>(cardProgramInformation, HttpStatus.OK);

        doReturn(cardProgramInformationResponseEntity).when(retryService).exchange(Mockito.anyString(), any(HttpMethod.class), any(HttpEntity.class), any());

        MigCardProgram migCardProgram = new MigCardProgram();
        doReturn(migCardProgram).when(migCardProgramRepository).save(Mockito.any());

        MigrationEntity migrationEntity = new MigrationEntity();
        doReturn(migrationEntity).when(migrationEntityRepository).save(Mockito.any());

        CardProgramInformationResponse cardProgramInformationResponse = cardsService.addCardProgramToClient(124L, migClient);

        assertEquals(1, cardProgramInformationResponse.getCardProgramInformationList().size());

    }

    @Test
    public void AddCardProgram_migClient_null() throws ServiceException {
        MigClient migClient = new MigClient();
        migClient.setPrimaryCifUbs(2);
        migClient.setJobId(2l);
        when(migClientRepository.findByEcClientIdAndJobId(Mockito.anyString(), Mockito.anyLong())).thenReturn(migClient);

        CardProgramInformationResponse cardProgramInformationResponse = cardsService.addCardProgramToClient(124L, migClient);

        assertTrue(cardProgramInformationResponse.getCardProgramInformationList().isEmpty());

    }

    @Test
    public void AddCardProgram_migClient_ecclient_null() throws ServiceException {

        when(migClientRepository.findByEcClientIdAndJobId(Mockito.anyString(), Mockito.anyLong())).thenReturn(null);
        MigClient migClient = new MigClient();
        CardProgramInformationResponse cardProgramInformationResponse = cardsService.addCardProgramToClient(124L, migClient);

        assertTrue(cardProgramInformationResponse.getCardProgramInformationList().isEmpty());

    }

    @Test
    void cardProgramRollback() {
        MigCardProgram migCardProgram = new MigCardProgram();
        migCardProgram.setStatus("Test");
        List<MigCardProgram> migCardPrograms = Arrays.asList(migCardProgram);
        when(migCardProgramRepository.findAllByEcClientIdAndStatus(
                ArgumentMatchers.anyString(), ArgumentMatchers.anyString()))
                .thenReturn(migCardPrograms);
        cardsService.rollbackCardProgram("clientId", new RollBackResponse());
        verify(migCardProgramRepository, times(1)).findAllByEcClientIdAndStatus(
                ArgumentMatchers.anyString(), ArgumentMatchers.anyString());
    }


    @Test
    public void AddCardProgramResponseNull() throws ServiceException {

        MigClient migClient = new MigClient();
        migClient.setEcClientId("addr7550");
        migClient.setPrimaryCifUbs(2);
        migClient.setJobId(2l);
        when(migClientRepository.findByEcClientIdAndJobId(Mockito.anyString(), Mockito.anyLong())).thenReturn(migClient);

        StgClient stgClient = new StgClient();
        when(migStgClientRepository.findByOlbClientId(anyLong(), Mockito.anyString())).thenReturn(stgClient);

        List<MigStgCardProgram> migStgCardProgramList = new ArrayList<>();
        MigStgCardProgram migStgCardProgram = new MigStgCardProgram();
        migStgCardProgram.setPrincipalId("8000");
        migStgCardProgram.setCif("abc");
        migStgCardProgram.setAgentId("abc");
        migStgCardProgramList.add(migStgCardProgram);

        doReturn(migStgCardProgramList).when(cardProgramRepository).findByOlbId(anyLong(), Mockito.anyString());

        CardProgramInformation cardProgramInformation = new CardProgramInformation();

        ResponseEntity<CardProgramInformation> cardProgramInformationResponseEntity = new ResponseEntity<>(cardProgramInformation, HttpStatus.OK);

        doReturn(null).when(retryService).exchange(Mockito.anyString(), any(HttpMethod.class), any(HttpEntity.class), any());

        MigCardProgram migCardProgram = new MigCardProgram();
        migCardProgram.setPrn("8080");
        migCardProgram.setProgramType("abc");
        migCardProgram.setAgent("abc");
        migCardProgram.setBillingType("abc");
        migCardProgram.setCif("abc");
        doReturn(migCardProgram).when(migCardProgramRepository).save(Mockito.any());

        MigrationEntity migrationEntity = new MigrationEntity();
        doReturn(migrationEntity).when(migrationEntityRepository).save(Mockito.any());

        CardProgramInformationResponse cardProgramInformationResponse = cardsService.addCardProgramToClient(124L, migClient);

        assertTrue(cardProgramInformationResponse.getCardProgramInformationList().isEmpty());

    }

}
