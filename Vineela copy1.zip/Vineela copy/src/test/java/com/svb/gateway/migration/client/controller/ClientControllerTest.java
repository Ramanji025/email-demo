package com.svb.gateway.migration.client.controller;

import com.svb.gateway.migration.client.model.EnrollClientResponse;
import com.svb.gateway.migration.client.model.DeleteClientResponse;
import com.svb.gateway.migration.client.service.ClientService;
import com.svb.gateway.migration.common.constants.MigrationConstants;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentMatchers;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@AutoConfigureMockMvc
public class ClientControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private ClientService clientService;

    @BeforeEach
    public void setup() throws Exception {
        EnrollClientResponse enrollClientResponse = new EnrollClientResponse();
        Mockito.when(clientService.enrollClient(ArgumentMatchers.anyString(), ArgumentMatchers.anyString(),
                ArgumentMatchers.any())).
                thenReturn(enrollClientResponse);
    }

    @Test
    public void testEnrollClient() throws Exception {

        this.mockMvc.perform(post("/api/clients/enrollClient/{jobId}/{companyId}/{clientId}", "123", "SVB", "GWaddr9768")
                .contentType(MediaType.APPLICATION_JSON_VALUE)
                .header("Authorization", "Basic Y3JtdXNlcjI6QWNjZXNzMTIz"))
                .andExpect(status().isOk());
    }

    @Test
    public void deleteClient() throws Exception {
        DeleteClientResponse deleteClientResponse = new DeleteClientResponse();
        deleteClientResponse.setStatus(MigrationConstants.STATUS_SUCCESS);
        Mockito.when(clientService.inactiveAndDeleteClient(ArgumentMatchers.anyString(), ArgumentMatchers.any())).thenReturn(deleteClientResponse);
        this.mockMvc.perform(delete("/api/clients/deleteClient/{olbClientId}", "GWaddr9768")
                .contentType(MediaType.APPLICATION_JSON_VALUE)
                .header("Authorization", "Basic Y3JtdXNlcjI6QWNjZXNzMTIz"))
                .andExpect(status().isOk());
    }

    @Test
    public void deleteClientFalse() throws Exception {
        DeleteClientResponse deleteClientResponse = new DeleteClientResponse();
        deleteClientResponse.setStatus(MigrationConstants.STATUS_FAILURE);
        Mockito.when(clientService.inactiveAndDeleteClient(ArgumentMatchers.anyString(), ArgumentMatchers.anyString())).thenReturn(deleteClientResponse);
        this.mockMvc.perform(delete("/api/clients/deleteClient/{olbClientId}", "ench6060")
                .contentType(MediaType.APPLICATION_JSON_VALUE)
                .header("Authorization", "Basic Y3JtdXNlcjI6QWNjZXNzMTIz"))
                .andExpect(status().isNotFound());
    }
}
