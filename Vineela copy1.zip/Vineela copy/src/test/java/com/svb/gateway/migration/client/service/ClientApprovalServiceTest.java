package com.svb.gateway.migration.client.service;

import com.svb.gateway.migration.client.entity.StgClient;
import com.svb.gateway.migration.client.entity.StgClientApprovalSettings;
import com.svb.gateway.migration.client.repository.IntClientApprovalRepository;
import com.svb.gateway.migration.common.logging.Message;
import org.junit.Assert;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.Spy;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.util.ArrayList;
import java.util.List;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doReturn;

@SpringBootTest
@ExtendWith(SpringExtension.class)
public class ClientApprovalServiceTest {

    @Mock
    IntClientApprovalRepository intClientApprovalRepository;

    @InjectMocks
    @Spy
    ClientApprovalService clientApprovalService;



    @Test
    public void testClientApproval_2(){
        List<StgClientApprovalSettings> stgClientApprovalSettingsList=getSingleAccountClientApprovalSettings();
        StgClient stgClient=getStgClient();
        doReturn(null).when(intClientApprovalRepository).findClientApprovalByJobIdAndAndEcClientId(any(),any());
        doReturn(null).when(intClientApprovalRepository).save(Mockito.any());
        Message logMessage=Message.create().clientId("data1234");
        int approverCount=clientApprovalService.getApproverCount(stgClientApprovalSettingsList,stgClient,logMessage);

        Assert.assertEquals(2, approverCount);
    }

    @Test
    public void testClientApproval_1(){
        StgClient stgClient=getStgClient();
        List<StgClientApprovalSettings> stgClientApprovalSettingsList=getSingleAccountClientApprovalSettings();
        stgClientApprovalSettingsList.get(0).setTemplateApproveLvl2Required(0);
        stgClientApprovalSettingsList.get(0).setTmplWireApprove2Required(0);
        stgClientApprovalSettingsList.get(0).setWireApproveLvl2Required(0);
        stgClientApprovalSettingsList.get(0).setIpayDualAuthentication("NO");
        doReturn(null).when(intClientApprovalRepository).findClientApprovalByJobIdAndAndEcClientId(any(),any());
        doReturn(null).when(intClientApprovalRepository).save(Mockito.any());
        Message logMessage=Message.create().clientId("data1234");
        int approverCount=clientApprovalService.getApproverCount(stgClientApprovalSettingsList,stgClient,logMessage);

        Assert.assertEquals(1, approverCount);
    }

    @Test
    public void testClientApproval_0(){
        StgClient stgClient=getStgClient();
        List<StgClientApprovalSettings> stgClientApprovalSettingsList=new ArrayList<>();
        StgClientApprovalSettings stgClientApprovalSettings=new StgClientApprovalSettings();
        stgClientApprovalSettings.setAccountNumber("123456789");
        stgClientApprovalSettings.setIpayDualAuthentication("NO");
        stgClientApprovalSettings.setIpayApprovalRequired("N");
        stgClientApprovalSettingsList.add(stgClientApprovalSettings);
        doReturn(null).when(intClientApprovalRepository).findClientApprovalByJobIdAndAndEcClientId(any(),any());
        doReturn(null).when(intClientApprovalRepository).save(Mockito.any());
        Message logMessage=Message.create().clientId("data1234");
        int approverCount=clientApprovalService.getApproverCount(stgClientApprovalSettingsList,stgClient,logMessage);

        Assert.assertEquals(0, approverCount);

    }

    @Test
    public void testClientApprovalMultiRecord_2(){
        List<StgClientApprovalSettings> stgClientApprovalSettingsList=getMultiAccountClientApprovalSettings();
        StgClient stgClient=getStgClient();
        doReturn(null).when(intClientApprovalRepository).findClientApprovalByJobIdAndAndEcClientId(any(),any());
        doReturn(null).when(intClientApprovalRepository).save(Mockito.any());
        Message logMessage=Message.create().clientId("data1234");
        int approverCount=clientApprovalService.getApproverCount(stgClientApprovalSettingsList,stgClient,logMessage);

        Assert.assertEquals(2, approverCount);
    }

    private List<StgClientApprovalSettings> getSingleAccountClientApprovalSettings(){
        List<StgClientApprovalSettings> stgClientApprovalSettingsList=new ArrayList<>();
        StgClientApprovalSettings stgClientApprovalSettings=getStgClientApprovalSetting();
        stgClientApprovalSettingsList.add(stgClientApprovalSettings);

        return stgClientApprovalSettingsList;
    }

    private List<StgClientApprovalSettings> getMultiAccountClientApprovalSettings(){
        List<StgClientApprovalSettings> stgClientApprovalSettingsList=new ArrayList<>();
        StgClientApprovalSettings stgClientApprovalSettings2=getStgClientApprovalSetting();
        StgClientApprovalSettings stgClientApprovalSettings1=getStgClientApprovalSetting();
        stgClientApprovalSettings1.setTemplateApproveLvl2Required(0);
        stgClientApprovalSettings1.setTmplWireApprove2Required(0);
        stgClientApprovalSettings1.setWireApproveLvl2Required(0);
        stgClientApprovalSettings1.setIpayDualAuthentication("NO");
        stgClientApprovalSettingsList.add(stgClientApprovalSettings1);
        stgClientApprovalSettingsList.add(stgClientApprovalSettings2);

        return stgClientApprovalSettingsList;
    }

    private StgClientApprovalSettings getStgClientApprovalSetting(){
        StgClientApprovalSettings stgClientApprovalSettings=new StgClientApprovalSettings();
        stgClientApprovalSettings.setEcClientId("data1234");
        stgClientApprovalSettings.setAccountNumber("123456789");
        stgClientApprovalSettings.setJobId("123");
        stgClientApprovalSettings.setIpayApprovalRequired("Y");
        stgClientApprovalSettings.setIpayDualAuthentication("YES");
        stgClientApprovalSettings.setTemplateApproveLvl1Required(1);
        stgClientApprovalSettings.setTemplateApproveLvl2Required(1);
        stgClientApprovalSettings.setWireApproveLvl1Required(1);
        stgClientApprovalSettings.setWireApproveLvl2Required(1);
        stgClientApprovalSettings.setTmplWireApprove1Required(1);
        stgClientApprovalSettings.setTmplWireApprove2Required(1);
        return stgClientApprovalSettings;
    }

    private StgClient getStgClient(){
        StgClient stgClient=new StgClient();
        stgClient.setJobId("123");
        stgClient.setOlbClinetId("data1234");
        return stgClient;
    }
}
