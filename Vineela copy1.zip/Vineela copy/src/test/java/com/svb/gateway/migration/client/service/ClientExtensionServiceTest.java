package com.svb.gateway.migration.client.service;

import com.svb.gateway.migration.client.model.CompanyIdRequest;
import com.svb.gateway.migration.client.model.CompanyIdResponse;
import com.svb.gateway.migration.common.constants.MigrationConstants;
import com.svb.gateway.migration.common.exception.ServiceException;
import com.svb.gateway.migration.common.service.RetryService;
import com.svb.gateway.migration.common.utility.CacheManagerUtility;
import lombok.extern.slf4j.Slf4j;
import org.junit.Assert;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.Spy;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.*;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@SpringBootTest
@ExtendWith(SpringExtension.class)
@Slf4j
public class ClientExtensionServiceTest {


    public static String oAuth;

    @Mock
    CacheManagerUtility cacheManagerUtility;
    @Mock
    RetryService retryService;

    @Value(value = "${mig.companyId.url}")
    String companyIdUrl;

    @InjectMocks
    @Spy
    ClientExtensionService clientExtensionService;

    @Test
    public void test_deleteClient_1() throws Exception {
        doReturn("oAUth").when(cacheManagerUtility).getOauthToken();
        ResponseEntity<Object> clientResponse = new ResponseEntity<>(HttpStatus.OK);
        doReturn(clientResponse).when(retryService).exchange(Mockito.anyString(), any(HttpMethod.class), any(HttpEntity.class), any());
        clientExtensionService.deleteClient("GWclnt1234");
    }

    @Test
    public void test_inactiveClient() throws Exception {
        doReturn("oAUth").when(cacheManagerUtility).getOauthToken();
        ResponseEntity<Object> clientResponse = new ResponseEntity<>(HttpStatus.OK);
        doReturn(clientResponse).when(retryService).exchange(Mockito.anyString(), any(HttpMethod.class), any(HttpEntity.class), any());
        clientExtensionService.inActiveClient("GWclnt1234", "I");
    }

    @Test
    public void test_ClientBdc() throws Exception {
        doReturn("oAUth").when(cacheManagerUtility).getOauthToken();
        doReturn(null).when(retryService).exchange(Mockito.anyString(), any(HttpMethod.class), any(HttpEntity.class), any());
        Exception exception = assertThrows(ServiceException.class, () -> {
            clientExtensionService.getPartnerClient("GWclnt1234");
        });
    }

    @Test
    public void test_UserBdc() throws Exception {
        doReturn("oAUth").when(cacheManagerUtility).getOauthToken();
        doReturn(null).when(retryService).exchange(Mockito.anyString(), any(HttpMethod.class), any(), any());
        Exception exception = assertThrows(ServiceException.class, () -> {
            clientExtensionService.getPartnerUsers("GWclnt1234");
        });
    }

    @Test
    public void test_ClientRegistrationBdc() throws Exception {
        doReturn("oAUth").when(cacheManagerUtility).getOauthToken();
        ResponseEntity<Object> clientResponse = new ResponseEntity<>(HttpStatus.OK);

        when(retryService.exchange(Mockito.anyString(), any(HttpMethod.class), any(), any())).thenReturn(clientResponse);
        boolean isRegistered = clientExtensionService.registerClientPartner("GWclnt1234");
        Assert.assertEquals(true, isRegistered);
    }

    @Test
    public void test_UserRegistrationBdc() throws Exception {
        doReturn("oAUth").when(cacheManagerUtility).getOauthToken();
        ResponseEntity<Object> clientResponse = new ResponseEntity<>(HttpStatus.OK);

        when(retryService.exchange(Mockito.anyString(), any(HttpMethod.class), any(), any())).thenReturn(clientResponse);
        clientExtensionService.registerPrimaryUserPartner("GWclnt1234", "28475ee236a44db58f880b79335990ea");
    }

    @Test
    public void testCompanyIdSuccess() {

        CompanyIdRequest companyIdRequest = new CompanyIdRequest();
        companyIdRequest.setCompanyName("abcd");
        CompanyIdResponse companyIdResponse = new CompanyIdResponse();
        companyIdResponse.setCompanyId("abcd");
        try {
            doReturn("oAUth").when(cacheManagerUtility).getOauthToken();
        } catch (ServiceException e) {
            log.info(e.getErrorMessage());
        }

        try {
            HttpHeaders headers = new HttpHeaders();
            headers.add(MigrationConstants.AUTHORIZATION_HEADER_NAME, oAuth);
            headers.add(MigrationConstants.CONTENT_TYPE, MigrationConstants.APPLICATION_HEADER_JSON);
            HttpEntity<CompanyIdRequest> requestEntity = new HttpEntity<>(companyIdRequest, headers);

            clientExtensionService.companyIdUrl = "companyIdTest";
            ResponseEntity<Object> companyIdResponseEntity = new ResponseEntity<>(companyIdResponse, HttpStatus.OK);

            when(retryService.exchange(Mockito.anyString(), any(HttpMethod.class), any(), any())).thenReturn(companyIdResponseEntity);

            clientExtensionService.generateCompanyId(companyIdRequest);
        } catch (ServiceException e) {
            log.info(e.getErrorMessage());
        }
        Assertions.assertNotNull(companyIdResponse);
        assertEquals("abcd",companyIdResponse.getCompanyId());
    }
}
