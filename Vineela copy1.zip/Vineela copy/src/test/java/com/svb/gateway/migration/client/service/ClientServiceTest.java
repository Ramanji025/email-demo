package com.svb.gateway.migration.client.service;

import com.svb.gateway.migration.client.entity.MigClient;
import com.svb.gateway.migration.client.entity.StgClient;
import com.svb.gateway.migration.client.entity.StgClientApprovalSettings;
import com.svb.gateway.migration.client.model.*;
import com.svb.gateway.migration.client.repository.ClientApprovalRepository;
import com.svb.gateway.migration.client.repository.ClientRepository;
import com.svb.gateway.migration.client.repository.IntClientApprovalRepository;
import com.svb.gateway.migration.client.repository.MigClientRepository;
import com.svb.gateway.migration.common.constants.MigrationConstants;
import com.svb.gateway.migration.common.constants.UserConstants;
import com.svb.gateway.migration.common.exception.ServiceException;
import com.svb.gateway.migration.common.logging.Message;
import com.svb.gateway.migration.common.model.EntityRecordCount;
import com.svb.gateway.migration.common.model.Error;
import com.svb.gateway.migration.common.utility.CacheManagerUtility;
import com.svb.gateway.migration.common.utility.EntityLogUtility;
import com.svb.gateway.migration.job.mapper.ClientMapper;
import com.svb.gateway.migration.user.entity.MigUser;
import com.svb.gateway.migration.user.entity.StgUser;
import com.svb.gateway.migration.user.mapper.UserMapper;
import com.svb.gateway.migration.user.repository.MigUserRepository;
import com.svb.gateway.migration.user.repository.StgUserRepository;
import org.junit.Assert;
import org.junit.Ignore;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.*;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.*;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import static com.svb.gateway.migration.common.constants.MigrationConstants.*;
import static com.svb.gateway.migration.common.constants.UserConstants.NO;
import static com.svb.gateway.migration.common.constants.UserConstants.YES;
import static junit.framework.TestCase.assertEquals;
import static junit.framework.TestCase.assertTrue;
import static org.junit.Assert.*;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.*;
import static org.mockito.Mockito.verify;

@SpringBootTest
@ExtendWith(SpringExtension.class)
public class ClientServiceTest {

    public static String clientId;
    public static String oAuth;
    public static String companyId;
    @Mock
    CacheManagerUtility cacheManagerUtility;
    String migCorelationId = "migCorelationId";
    Integer migStartupBankingBundle = 15;

    @Mock
    StgClient stgClient;

    @Mock
    ClientRepository clientRepository;

    @Mock
    ClientApprovalRepository clientApprovalRepository;

    @Mock
    MigClientRepository migClientRepository;

    @Mock
    MigUserRepository migUserRepository;

    @Mock
    EntityLogUtility entityLogUtility;
    @Mock
    StgUserRepository stgUserRepository;
    @Mock
    Cifs cifsInfo;
    @Mock
    EnrollClientResponse clientEnrolled;
    @Mock
    RestTemplate restTemplate;
    @Mock
    EnrollClientRequest request;
    @Mock
    List<com.svb.gateway.migration.user.entity.StgUser> users;
    @Mock
    ClientMapper clientMapper;
    @Mock
    UserMapper userMapper;
    @Mock
    IntClientApprovalRepository intClientApprovalRepository;
    @Mock
    ClientApprovalService clientApprovalService;

    @Mock
    ClientExtensionService clientExtensionService;

    @Mock
    PartnerService partnerService;

    @InjectMocks
    @Spy
    ClientService clientService;

    @BeforeAll
    public static void setUp() {
        clientId = "addr9768";
        companyId = "SVB";
    }

    @BeforeEach
    public void before() {
        stgClient.setPrimaryCifUbs("1234");
        stgClient.setPrimaryCifCbs("1234");
        List<StgClientApprovalSettings> stgClientApprovalSettings = new ArrayList<>();
        doReturn(stgClientApprovalSettings).when(clientApprovalRepository).findByJobIdAndEcClientId(any(), any());
        doNothing().when(clientMapper).updateClient(ArgumentMatchers.any());
        when(clientRepository.findByOlbClinetId(ArgumentMatchers.any())).thenReturn(stgClient);
        doReturn("1234").when(stgClient).getPrimaryCifCbs();
        doReturn("1234").when(stgClient).getPrimaryCifUbs();
        // doReturn(clientEntity).when(clientMapper).getClient(ArgumentMatchers.any(), ArgumentMatchers.any());
    }

    @Test
    public void getMigClient(){
        MigClient mg = new MigClient();
        mg.setStatus(MigrationConstants.STATUS_SUCCESS);
        when(migClientRepository.findByEcClientIdAndJobId(ArgumentMatchers.any(), ArgumentMatchers.any())).thenReturn(mg);
        clientService.getMigClient(clientId, 1l);
    }

    @Test
    public void enrollClient_alreadySuccessfullyMigrated() throws Exception {
        MigClient mg = new MigClient();
        mg.setStatus(MigrationConstants.STATUS_SUCCESS);
        when(migClientRepository.findByEcClientIdAndJobId(ArgumentMatchers.any(), ArgumentMatchers.any())).thenReturn(mg);
        EnrollClientResponse actClientEnrolled = clientService.enrollClient(companyId, clientId, 1L);
        assertEquals("SUCCESS", actClientEnrolled.getData().getStatus());
    }

    @Test
    public void enrollClient_alreadyMigratedAndIgnored() throws Exception {
        MigClient mg = new MigClient();
        mg.setGwClientId("GWa1234");
        mg.setStatus(MigrationConstants.STATUS_IGNORE);
        mg.setCompanyId(companyId);
        when(migClientRepository.findByEcClientIdAndJobId(ArgumentMatchers.any(), ArgumentMatchers.any())).thenReturn(mg);
        // doReturn(clientEntity).when(clientMapper).getClient(ArgumentMatchers.any(), ArgumentMatchers.any());
        EnrollClientResponse actClientEnrolled = clientService.enrollClient(companyId, clientId, 1L);
        assertEquals("IGNORE", actClientEnrolled.getData().getStatus());
    }


    @Test
    public void phoneNumber_Null() throws Exception {
        when(clientRepository.findByOlbClinetId(clientId)).thenReturn(stgClient);
        doReturn("123").when(stgClient).getJobId();
        clientService.lastLoginMonthThreshold= 18;
        StgUser u = new StgUser();
        u.setPrimaryUser(true);
        u.setStatus("1");
        u.setCountryCode("1");
        u.setOlbClientId(clientId);
        u.setUserLoginId("123");
        u.setLastLoginDate(LocalDate.now());
        List<StgUser> users = new ArrayList<>();
        users.add(u);

        Mockito.when(stgUserRepository.findByOlbClientId(ArgumentMatchers.anyString(), ArgumentMatchers.anyString())).thenReturn(Collections.singletonList(u));

        when(stgUserRepository.findByOlbClientId(clientId, "Y")).thenReturn(users);
        oAuth = "e2561beef23920c18902ada758a1118de96be728add38b1a04acb2d911845352";
        when(cacheManagerUtility.getOauthToken()).thenReturn(oAuth);
        when(stgClient.getPrimaryCifUbs()).thenReturn("200030009");
        try{
        EnrollClientResponse response = clientService.enrollClient(companyId, clientId, 1L);
        }catch (IllegalArgumentException e){
            assertEquals("PhoneNumber must not be null", e.getMessage());
        }
    }

    @Test
    public void countryCode_Null() throws Exception {
        when(clientRepository.findByOlbClinetId(clientId)).thenReturn(stgClient);
        doReturn("123").when(stgClient).getJobId();
        clientService.lastLoginMonthThreshold= 18;
        StgUser u = new StgUser();
        u.setPrimaryUser(true);
        u.setStatus("1");
        u.setCntPh("1234");
        u.setOlbClientId(clientId);
        u.setUserLoginId("123");
        u.setLastLoginDate(LocalDate.now());
        List<StgUser> users = new ArrayList<>();
        users.add(u);

        Mockito.when(stgUserRepository.findByOlbClientId(ArgumentMatchers.anyString(), ArgumentMatchers.anyString())).thenReturn(Collections.singletonList(u));

        when(stgUserRepository.findByOlbClientId(clientId, "Y")).thenReturn(users);
        oAuth = "e2561beef23920c18902ada758a1118de96be728add38b1a04acb2d911845352";
        when(cacheManagerUtility.getOauthToken()).thenReturn(oAuth);
        when(stgClient.getPrimaryCifUbs()).thenReturn("200030009");
        try{
            EnrollClientResponse response = clientService.enrollClient(companyId, clientId, 1L);
        }catch (IllegalArgumentException e){
            assertEquals("CountryCode must not be null", e.getMessage());
        }
    }

    @Test
    public void enrollClient_success() throws Exception {
        when(clientRepository.findByOlbClinetId(clientId)).thenReturn(stgClient);
        doReturn("123").when(stgClient).getJobId();
        clientService.lastLoginMonthThreshold= 18;
        StgUser u = new StgUser();
        u.setPrimaryUser(true);
        u.setStatus("1");
        u.setCountryCode("1");
        u.setCntPh("987");
        u.setOlbClientId(clientId);
        u.setUserLoginId("123");
        u.setLastLoginDate(LocalDate.now());
        List<StgUser> users = new ArrayList<>();
        users.add(u);

        Mockito.when(stgUserRepository.findByOlbClientId(ArgumentMatchers.anyString(), ArgumentMatchers.anyString())).thenReturn(Collections.singletonList(u));

        when(stgUserRepository.findByOlbClientId(clientId, "Y")).thenReturn(users);
        oAuth = "e2561beef23920c18902ada758a1118de96be728add38b1a04acb2d911845352";
        when(cacheManagerUtility.getOauthToken()).thenReturn(oAuth);
        when(stgClient.getPrimaryCifUbs()).thenReturn("200030009");

        Cifs cifListRequest = new Cifs();
        Cif cif = new Cif();
        cif.setCifNumber(stgClient.getPrimaryCifUbs());

        List<Cif> cifs = new ArrayList<>();
        List<AccountServices> cifaccounts = new ArrayList<>();
        AccountServices as = new AccountServices();
        List<SvbService> accServ = new ArrayList<>();
        SvbService ss = new SvbService();


        List<ServiceTransaction> serviceTxns = new ArrayList<>();
        ServiceTransaction sTxn = new ServiceTransaction();
        sTxn.setSvcTxnId("svcTxnId");
        serviceTxns.add(sTxn);
        ss.setServiceTxn(serviceTxns);
        accServ.add(ss);
        as.setAccServ(accServ);
        as.setAccStat("Y");
        as.setAccountNum("accNum");
        cifaccounts.add(as);
        cif.setCifAccounts(cifaccounts);
        cifs.add(cif);
        cifListRequest.setCifData(cifs);
        doReturn(cifListRequest).when(clientService).getCifAccountInfo(any(), any(), any(), any() );

        Bundles bundles = new Bundles();
        List<Bundle> digitalBundles = new ArrayList<>();
        Bundle b = new Bundle();
        List<BundleServices> services = new ArrayList<>();
        BundleServices bs = new BundleServices();
        SvbService service = new SvbService();
        List<ServiceTransaction> serviceTxn = new ArrayList<>();
        service.setServiceId("sId");
        service.setServiceName("sName");
        ServiceTransaction st = new ServiceTransaction();
        st.setAcctSpecificTxn("Y");
        st.setOperation("Credit");
        st.setSvcTxnId("svcTxnId");

        serviceTxn.add(st);

        service.setServiceTxn(serviceTxn);
        bs.setService(service);
        services.add(bs);
        b.setServices(services);
        b.setDigitalBundleId(15);
        digitalBundles.add(b);
        bundles.setDigitalBundles(digitalBundles);
        doReturn(bundles).when(clientService).getBundles(any(), any(), any());

        List<AccountServices> cifAccounts = new ArrayList<>();
        AccountServices accountServices = new AccountServices();
        accountServices.setAccCcy("accCcy");
        accountServices.setAccName("Analysis Checking");
        accountServices.setAccountNum("1234567890");
        accountServices.setAccountTyp("CC");
        accountServices.setAccStat("stat");
        accountServices.setAccountTyp("Deposit Account");
        accountServices.setProdCode("prodCode");
        accountServices.setAccServ(accServ);
        cifAccounts.add(accountServices);

        List<Cif> cifData = new ArrayList<>();
        Cif c = new Cif();
        c.setUbsCifNum("200030009");
        c.setCbsCifNum("200030009");
        c.setCifAccounts(cifAccounts);
        cifData.add(c);
        when(cifsInfo.getCifData()).thenReturn(cifData);
        cifListRequest.setCifData(cifData);

        clientService.migStartupBankingBundle = 15;

        EnrollClientResponse clientEnrolled = new EnrollClientResponse();
        EnrollClientResponseData data = new EnrollClientResponseData();
        data.setGwPrimaryUserId("pUserId");
        data.setGwClientId("geClientId");
        data.setStatus("success");
        clientEnrolled.setData(data);
        EnrollClientRequest request1 = new EnrollClientRequest();
        request1.setClientCifs(Collections.singletonList(cif));

        List<StgClientApprovalSettings> stgClientApprovalSettingsList=getClientApprovalsettings();
        doReturn(stgClientApprovalSettingsList).when(clientApprovalRepository).findByJobIdAndEcClientId(anyString(),anyString());
        doReturn(1).when(clientApprovalService).getApproverCount(any(),any(),any());

        doReturn(clientEnrolled).when(clientService).createClient(any(), any(),any(), any());

        doNothing().when(entityLogUtility).saveEntityCountAndTimeLog(Mockito.any());
        doReturn(1).when(userMapper).insertMigratingUser(Mockito.any(MigUser.class));
        //doNothing().when(clientMapper).updateClient(Mockito.any(MigClient.class));
        EnrollClientResponse actClientEnrolled = clientService.enrollClient(companyId, clientId, 1L);

        assertEquals(clientEnrolled, actClientEnrolled);

    }

    @Test
    public void enrollClient_fail() throws Exception {
        when(clientRepository.findByOlbClinetId(clientId)).thenReturn(stgClient);
        doReturn("123").when(stgClient).getJobId();
        clientService.lastLoginMonthThreshold = 18;
        StgUser u = new StgUser();
        u.setPrimaryUser(true);
        u.setStatus("1");
        u.setCountryCode("1");
        u.setLastLoginDate(LocalDate.now());
        u.setOlbClientId(clientId);
        u.setUserLoginId("123");
        u.setCntPh("987");
        List<StgUser> users = new ArrayList<>();
        users.add(u);

        Mockito.when(stgUserRepository.findByOlbClientId(ArgumentMatchers.anyString(), ArgumentMatchers.anyString())).thenReturn(Collections.singletonList(u));

        when(stgUserRepository.findByOlbClientId(clientId, "Y")).thenReturn(users);
        oAuth = "e2561beef23920c18902ada758a1118de96be728add38b1a04acb2d911845352";
        when(cacheManagerUtility.getOauthToken()).thenReturn(oAuth);
        when(stgClient.getPrimaryCifUbs()).thenReturn("200030009");

        Cifs cifListRequest = new Cifs();
        Cif cif = new Cif();
        cif.setCifNumber(stgClient.getPrimaryCifUbs());

        List<Cif> cifs = new ArrayList<>();
        List<AccountServices> cifaccounts = new ArrayList<>();
        AccountServices as = new AccountServices();
        List<SvbService> accServ = new ArrayList<>();
        SvbService ss = new SvbService();


        List<ServiceTransaction> serviceTxns = new ArrayList<>();
        ServiceTransaction sTxn = new ServiceTransaction();
        sTxn.setSvcTxnId("svcTxnId");
        serviceTxns.add(sTxn);
        ss.setServiceTxn(serviceTxns);
        accServ.add(ss);
        as.setAccServ(accServ);
        as.setAccStat("Y");
        as.setAccountTyp("Deposit Account");
        as.setAccountNum("accNum");
        cifaccounts.add(as);
        cif.setCifAccounts(cifaccounts);
        cifs.add(cif);
        cifListRequest.setCifData(cifs);
        doReturn(cifListRequest).when(clientService).getCifAccountInfo(any(), any(), any(), any());

        Bundles bundles = new Bundles();
        List<Bundle> digitalBundles = new ArrayList<>();
        Bundle b = new Bundle();
        List<BundleServices> services = new ArrayList<>();
        BundleServices bs = new BundleServices();
        SvbService service = new SvbService();
        List<ServiceTransaction> serviceTxn = new ArrayList<>();
        service.setServiceId("sId");
        service.setServiceName("sName");
        ServiceTransaction st = new ServiceTransaction();
        st.setAcctSpecificTxn("Y");
        st.setOperation("Credit");
        st.setSvcTxnId("svcTxnId");

        serviceTxn.add(st);

        service.setServiceTxn(serviceTxn);
        bs.setService(service);
        services.add(bs);
        b.setServices(services);
        b.setDigitalBundleId(15);
        digitalBundles.add(b);
        bundles.setDigitalBundles(digitalBundles);
        doReturn(bundles).when(clientService).getBundles(any(), any(), any());

        List<AccountServices> cifAccounts = new ArrayList<>();
        AccountServices accountServices = new AccountServices();
        accountServices.setAccCcy("accCcy");
        accountServices.setAccName("Analysis Checking");
        accountServices.setAccountNum("1234567890");
        accountServices.setAccountTyp("CC");
        accountServices.setAccStat("stat");
        accountServices.setAccountTyp("Deposit Account");
        accountServices.setProdCode("prodCode");
        accountServices.setAccServ(accServ);
        cifAccounts.add(accountServices);

        List<Cif> cifData = new ArrayList<>();
        Cif c = new Cif();
        c.setUbsCifNum("200030009");
        c.setCbsCifNum("200030009");
        c.setCifAccounts(cifAccounts);
        cifData.add(c);
        when(cifsInfo.getCifData()).thenReturn(cifData);
        cifListRequest.setCifData(cifData);
        doReturn(null).when(intClientApprovalRepository).save(Mockito.any());

        clientService.migStartupBankingBundle = 15;

        EnrollClientResponse clientEnrolled = new EnrollClientResponse();
        EnrollClientResponseData data = new EnrollClientResponseData();
        data.setGwPrimaryUserId("pUserId");
        data.setGwClientId("geClientId");
        Error e = new Error("0000", UserConstants.ADD_USER_FAILED);
        clientEnrolled.setErrors(List.of(e));
        data.setStatus(MigrationConstants.STATUS_FAILURE);
        clientEnrolled.setData(data);

        doReturn(clientEnrolled).when(clientService).createClient(any(), any(),any(), any());

        doNothing().when(entityLogUtility).saveEntityCountAndTimeLog(Mockito.any());
        doReturn(1).when(userMapper).insertMigratingUser(Mockito.any(MigUser.class));
        doReturn(null).when(migClientRepository).findByEcClientIdAndJobId(Mockito.anyString(),Mockito.any());
        doReturn(null).when(migClientRepository).save(Mockito.any());

        EnrollClientResponse actClientEnrolled = clientService.enrollClient(companyId, clientId, 1L);

        assertEquals(clientEnrolled, actClientEnrolled);

        System.out.println("client updated successfully");

    }

    @Test
    public void enrollClient_fail_1() throws Exception {
        when(clientRepository.findByOlbClinetId(clientId)).thenReturn(stgClient);
        doReturn("123").when(stgClient).getJobId();
        clientService.lastLoginMonthThreshold = 18;
        StgUser u = new StgUser();
        u.setPrimaryUser(true);
        u.setStatus("1");
        u.setCountryCode("1");
        u.setLastLoginDate(LocalDate.now());
        u.setOlbClientId(clientId);
        u.setUserLoginId("123");
        u.setCntPh("987");
        List<StgUser> users = new ArrayList<>();
        users.add(u);

        Mockito.when(stgUserRepository.findByOlbClientId(ArgumentMatchers.anyString(), ArgumentMatchers.anyString())).thenReturn(Collections.singletonList(u));

        when(stgUserRepository.findByOlbClientId(clientId, "Y")).thenReturn(users);
        oAuth = "e2561beef23920c18902ada758a1118de96be728add38b1a04acb2d911845352";
        when(cacheManagerUtility.getOauthToken()).thenReturn(oAuth);
        when(stgClient.getPrimaryCifUbs()).thenReturn("200030009");

        Cifs cifListRequest = new Cifs();
        Cif cif = new Cif();
        cif.setCifNumber(stgClient.getPrimaryCifUbs());

        List<Cif> cifs = new ArrayList<>();
        List<AccountServices> cifaccounts = new ArrayList<>();
        AccountServices as = new AccountServices();
        List<SvbService> accServ = new ArrayList<>();
        SvbService ss = new SvbService();


        List<ServiceTransaction> serviceTxns = new ArrayList<>();
        ServiceTransaction sTxn = new ServiceTransaction();
        sTxn.setSvcTxnId("svcTxnId");
        serviceTxns.add(sTxn);
        ss.setServiceTxn(serviceTxns);
        accServ.add(ss);
        as.setAccServ(accServ);
        as.setAccStat("Y");
        as.setAccountTyp("Deposit Account");
        as.setAccountNum("accNum");
        cifaccounts.add(as);
        AccountServices as2 = new AccountServices();
        List<SvbService> accServ2 = new ArrayList<>();
        SvbService ss2 = new SvbService();


        List<ServiceTransaction> serviceTxns2 = new ArrayList<>();
        ServiceTransaction sTxn2 = new ServiceTransaction();
        sTxn2.setSvcTxnId("svcTxnId");
        serviceTxns2.add(sTxn2);
        ss2.setServiceTxn(serviceTxns2);
        accServ2.add(ss2);
        as2.setAccServ(accServ2);
        as2.setAccStat("Y");
        as2.setAccountTyp("Deposit Account");
        as2.setAccountNum("accNum");
        cifaccounts.add(as2);
        cif.setCifAccounts(cifaccounts);
        cifs.add(cif);

        cifListRequest.setCifData(cifs);
        doReturn(cifListRequest).when(clientService).getCifAccountInfo(any(), any(), any(), any());

        Bundles bundles = new Bundles();
        List<Bundle> digitalBundles = new ArrayList<>();
        Bundle b = new Bundle();
        List<BundleServices> services = new ArrayList<>();
        BundleServices bs = new BundleServices();
        SvbService service = new SvbService();
        List<ServiceTransaction> serviceTxn = new ArrayList<>();
        service.setServiceId("sId");
        service.setServiceName("sName");
        ServiceTransaction st = new ServiceTransaction();
        st.setAcctSpecificTxn("Y");
        st.setOperation("Credit");
        st.setSvcTxnId("svcTxnId");

        serviceTxn.add(st);

        service.setServiceTxn(serviceTxn);
        bs.setService(service);
        services.add(bs);
        b.setServices(services);
        b.setDigitalBundleId(15);
        digitalBundles.add(b);
        bundles.setDigitalBundles(digitalBundles);
        doReturn(bundles).when(clientService).getBundles(any(), any(), any());

        List<AccountServices> cifAccounts = new ArrayList<>();
        AccountServices accountService = new AccountServices();
        accountService.setAccCcy("accCcy");
        accountService.setAccName("Analysis Checking");
        accountService.setAccountNum("1234567890");
        accountService.setAccountTyp("CC");
        accountService.setAccStat("stat");
        accountService.setAccountTyp("Deposit Account");
        accountService.setProdCode("prodCode");
        accountService.setAccServ(accServ);
        cifAccounts.add(accountService);
        AccountServices accountServices = new AccountServices();
        accountServices.setAccCcy("accCcy");
        accountServices.setAccName("Analysis Checking");
        accountServices.setAccountNum("1234567890");
        accountServices.setAccountTyp("CC");
        accountServices.setAccStat("stat");
        accountServices.setAccountTyp("Deposit Account");
        accountServices.setProdCode("prodCode");
        accountServices.setAccServ(accServ);
        cifAccounts.add(accountServices);

        List<Cif> cifData = new ArrayList<>();
        Cif c = new Cif();
        c.setUbsCifNum("200030009");
        c.setCbsCifNum("200030009");
        c.setCifAccounts(cifAccounts);
        cifData.add(c);
        when(cifsInfo.getCifData()).thenReturn(cifData);
        cifListRequest.setCifData(cifData);
        doReturn(null).when(intClientApprovalRepository).save(Mockito.any());

        clientService.migStartupBankingBundle = 15;

        EnrollClientResponse clientEnrolled = new EnrollClientResponse();
        EnrollClientResponseData data = new EnrollClientResponseData();
        data.setGwPrimaryUserId("pUserId");
        data.setGwClientId("geClientId");
        Error e = new Error("0000", UserConstants.ADD_USER_FAILED);
        clientEnrolled.setErrors(List.of(e));
        data.setStatus(MigrationConstants.STATUS_FAILURE);
        clientEnrolled.setData(data);

        doReturn(clientEnrolled).when(clientService).createClient(any(), any(),any(), any());

        doNothing().when(entityLogUtility).saveEntityCountAndTimeLog(Mockito.any());
        doReturn(1).when(userMapper).insertMigratingUser(Mockito.any(MigUser.class));
        doReturn(null).when(migClientRepository).findByEcClientIdAndJobId(Mockito.anyString(),Mockito.any());
        doReturn(null).when(migClientRepository).save(Mockito.any());

        EnrollClientResponse actClientEnrolled = clientService.enrollClient(companyId, clientId, 1L);

        assertEquals(clientEnrolled, actClientEnrolled);

        System.out.println("client updated successfully");

    }

    @Test
    public void enrollClient_fail_2() throws Exception {
        when(clientRepository.findByOlbClinetId(clientId)).thenReturn(stgClient);
        doReturn("123").when(stgClient).getJobId();
        clientService.lastLoginMonthThreshold = 18;
        StgUser u = new StgUser();
        u.setPrimaryUser(true);
        u.setStatus("1");
        u.setCountryCode("1");
        u.setLastLoginDate(LocalDate.now());
        u.setOlbClientId(clientId);
        u.setUserLoginId("123");
        u.setCntPh("987");
        List<StgUser> users = new ArrayList<>();
        users.add(u);

        Mockito.when(stgUserRepository.findByOlbClientId(ArgumentMatchers.anyString(), ArgumentMatchers.anyString())).thenReturn(Collections.singletonList(u));

        when(stgUserRepository.findByOlbClientId(clientId, "Y")).thenReturn(users);
        oAuth = "e2561beef23920c18902ada758a1118de96be728add38b1a04acb2d911845352";
        when(cacheManagerUtility.getOauthToken()).thenReturn(oAuth);
        when(stgClient.getPrimaryCifUbs()).thenReturn("200030009");

        Cifs cifListRequest = new Cifs();
        Cif cif = new Cif();
        cif.setCifNumber(stgClient.getPrimaryCifUbs());

        List<Cif> cifs = new ArrayList<>();
        List<AccountServices> cifaccounts = new ArrayList<>();
        AccountServices as = new AccountServices();
        List<SvbService> accServ = new ArrayList<>();
        SvbService ss = new SvbService();


        List<ServiceTransaction> serviceTxns = new ArrayList<>();
        ServiceTransaction sTxn = new ServiceTransaction();
        sTxn.setSvcTxnId("svcTxnId");
        serviceTxns.add(sTxn);
        ss.setServiceTxn(serviceTxns);
        accServ.add(ss);
        as.setAccServ(accServ);
        as.setAccStat("Y");
        as.setAccountTyp("Deposit Account");
        as.setAccountNum("accNum");
        cifaccounts.add(as);
        cif.setCifAccounts(cifaccounts);
        cifs.add(cif);
        cifListRequest.setCifData(cifs);
        doReturn(cifListRequest).when(clientService).getCifAccountInfo(any(), any(), any(), any());

        Bundles bundles = new Bundles();
        List<Bundle> digitalBundles = new ArrayList<>();
        Bundle b = new Bundle();
        List<BundleServices> services = new ArrayList<>();
        BundleServices bs = new BundleServices();
        SvbService service = new SvbService();
        List<ServiceTransaction> serviceTxn = new ArrayList<>();
        service.setServiceId("sId");
        service.setServiceName("sName");
        ServiceTransaction st = new ServiceTransaction();
        st.setAcctSpecificTxn("Y");
        st.setOperation("Credit");
        st.setSvcTxnId("svcTxnId");

        serviceTxn.add(st);

        service.setServiceTxn(serviceTxn);
        bs.setService(service);
        services.add(bs);
        b.setServices(services);
        b.setDigitalBundleId(15);
        digitalBundles.add(b);
        bundles.setDigitalBundles(digitalBundles);
        doReturn(bundles).when(clientService).getBundles(any(), any(), any());

        List<AccountServices> cifAccounts = new ArrayList<>();
        AccountServices accountServices = new AccountServices();
        accountServices.setAccCcy("accCcy");
        accountServices.setAccName("Analysis Checking");
        accountServices.setAccountNum("1234567890");
        accountServices.setAccountTyp("CC");
        accountServices.setAccStat("stat");
        accountServices.setAccountTyp("Deposit Account");
        accountServices.setProdCode("prodCode");
        accountServices.setAccServ(accServ);
        cifAccounts.add(accountServices);

        List<Cif> cifData = new ArrayList<>();
        Cif c = new Cif();
        c.setUbsCifNum("200030009");
        c.setCbsCifNum("200030009");
        c.setCifAccounts(cifAccounts);
        cifData.add(c);
        when(cifsInfo.getCifData()).thenReturn(cifData);
        cifListRequest.setCifData(cifData);
        doReturn(null).when(intClientApprovalRepository).save(Mockito.any());

        clientService.migStartupBankingBundle = 15;

        EnrollClientResponse clientEnrolled = new EnrollClientResponse();
        EnrollClientResponseData data = new EnrollClientResponseData();
        data.setGwPrimaryUserId("pUserId");
        data.setGwClientId("geClientId");
        Error e = new Error("0000", UserConstants.ADD_USER_FAILED);
        clientEnrolled.setErrors(List.of(e));
        data.setStatus(MigrationConstants.STATUS_FAILURE);
        clientEnrolled.setData(data);

        doReturn(clientEnrolled).when(clientService).createClient(any(), any(),any(), any());

        doNothing().when(entityLogUtility).saveEntityCountAndTimeLog(Mockito.any());
        doReturn(1).when(userMapper).insertMigratingUser(Mockito.any(MigUser.class));

        MigClient mg = new MigClient();
        mg.setGwClientId("geClientId");
        mg.setCompanyId("home9500");
        mg.setStatus("success");
        mg.setEcClientId("home9522");
        doReturn(mg).when(migClientRepository).findByEcClientIdAndJobId(Mockito.anyString(),Mockito.any());
        doReturn(null).when(migClientRepository).save(Mockito.any());

        EnrollClientResponse actClientEnrolled = clientService.enrollClient(companyId, clientId, 1L);

        assertEquals("SUCCESS", actClientEnrolled.getData().getStatus());

        System.out.println("client updated successfully");

    }

    @Test
    public void enrollClient_fail_3() throws Exception {
        when(clientRepository.findByOlbClinetId(clientId)).thenReturn(stgClient);
        doReturn("123").when(stgClient).getJobId();
        clientService.lastLoginMonthThreshold = 18;
        StgUser u = new StgUser();
        u.setPrimaryUser(true);
        u.setStatus("1");
        u.setCountryCode("1");
        u.setLastLoginDate(LocalDate.now());
        u.setOlbClientId(clientId);
        u.setUserLoginId("123");
        u.setCntPh("987");
        List<StgUser> users = new ArrayList<>();
        users.add(u);

        Mockito.when(stgUserRepository.findByOlbClientId(ArgumentMatchers.anyString(), ArgumentMatchers.anyString())).thenReturn(Collections.singletonList(u));

        when(stgUserRepository.findByOlbClientId(clientId, "Y")).thenReturn(users);
        oAuth = "e2561beef23920c18902ada758a1118de96be728add38b1a04acb2d911845352";
        when(cacheManagerUtility.getOauthToken()).thenReturn(oAuth);
        when(stgClient.getPrimaryCifUbs()).thenReturn("200030009");

        Cifs cifListRequest = new Cifs();
        Cif cif = new Cif();
        cif.setCifNumber(stgClient.getPrimaryCifUbs());

        List<Cif> cifs = new ArrayList<>();
        List<AccountServices> cifaccounts = new ArrayList<>();
        AccountServices as = new AccountServices();
        List<SvbService> accServ = new ArrayList<>();
        SvbService ss = new SvbService();


        List<ServiceTransaction> serviceTxns = new ArrayList<>();
        ServiceTransaction sTxn = new ServiceTransaction();
        sTxn.setSvcTxnId("svcTxnId");
        serviceTxns.add(sTxn);
        ss.setServiceTxn(serviceTxns);
        accServ.add(ss);
        as.setAccServ(accServ);
        as.setAccStat("Y");
        as.setAccountTyp("Deposit Account");
        as.setAccountNum("accNum");
        cifaccounts.add(as);
        AccountServices as2 = new AccountServices();
        List<SvbService> accServ2 = new ArrayList<>();
        SvbService ss2 = new SvbService();


        List<ServiceTransaction> serviceTxns2 = new ArrayList<>();
        ServiceTransaction sTxn2 = new ServiceTransaction();
        sTxn2.setSvcTxnId("svcTxnId");
        serviceTxns2.add(sTxn2);
        ss2.setServiceTxn(serviceTxns2);
        accServ2.add(ss2);
        as2.setAccServ(accServ2);
        as2.setAccStat("Y");
        as2.setAccountTyp("Deposit Account");
        as2.setAccountNum("accNum");
        cifaccounts.add(as2);
        cif.setCifAccounts(cifaccounts);
        cifs.add(cif);

        cifListRequest.setCifData(cifs);
        doReturn(cifListRequest).when(clientService).getCifAccountInfo(any(), any(), any(), any());

        Bundles bundles = new Bundles();
        List<Bundle> digitalBundles = new ArrayList<>();
        Bundle b = new Bundle();
        List<BundleServices> services = new ArrayList<>();
        BundleServices bs = new BundleServices();
        SvbService service = new SvbService();
        List<ServiceTransaction> serviceTxn = new ArrayList<>();
        service.setServiceId("sId");
        service.setServiceName("sName");
        ServiceTransaction st = new ServiceTransaction();
        st.setAcctSpecificTxn("Y");
        st.setOperation("Credit");
        st.setSvcTxnId("svcTxnId");

        serviceTxn.add(st);

        service.setServiceTxn(serviceTxn);
        bs.setService(service);
        services.add(bs);
        b.setServices(services);
        b.setDigitalBundleId(15);
        digitalBundles.add(b);
        bundles.setDigitalBundles(digitalBundles);
        doReturn(bundles).when(clientService).getBundles(any(), any(), any());

        List<AccountServices> cifAccounts = new ArrayList<>();
        AccountServices accountService = new AccountServices();
        accountService.setAccCcy("accCcy");
        accountService.setAccName("Analysis Checking");
        accountService.setAccountNum("1234567890");
        accountService.setAccountTyp("CC");
        accountService.setAccStat("stat");
        accountService.setAccountTyp("Deposit Account");
        accountService.setProdCode("prodCode");
        accountService.setAccServ(accServ);
        cifAccounts.add(accountService);
        AccountServices accountServices = new AccountServices();
        accountServices.setAccCcy("accCcy");
        accountServices.setAccName("Analysis Checking");
        accountServices.setAccountNum("1234567890");
        accountServices.setAccountTyp("CC");
        accountServices.setAccStat("Open");
        accountServices.setAccountTyp("Deposit Account");
        accountServices.setProdCode("011");
        accountServices.setAccServ(accServ);
        cifAccounts.add(accountServices);

        List<Cif> cifData = new ArrayList<>();
        Cif c = new Cif();
        c.setUbsCifNum("200030009");
        c.setCbsCifNum("200030009");
        c.setCifAccounts(cifAccounts);
        cifData.add(c);
        when(cifsInfo.getCifData()).thenReturn(cifData);
        cifListRequest.setCifData(cifData);
        doReturn(null).when(intClientApprovalRepository).save(Mockito.any());

        clientService.migStartupBankingBundle = 15;

        EnrollClientResponse clientEnrolled = new EnrollClientResponse();
        EnrollClientResponseData data = new EnrollClientResponseData();
        data.setGwPrimaryUserId("pUserId");
        data.setGwClientId("geClientId");
        Error e = new Error("0000", UserConstants.ADD_USER_FAILED);
        clientEnrolled.setErrors(List.of(e));
        data.setStatus(MigrationConstants.STATUS_FAILURE);
        clientEnrolled.setData(data);

        doReturn(clientEnrolled).when(clientService).createClient(any(), any(),any(), any());

        doNothing().when(entityLogUtility).saveEntityCountAndTimeLog(Mockito.any());
        doReturn(1).when(userMapper).insertMigratingUser(Mockito.any(MigUser.class));
        doReturn(null).when(migClientRepository).findByEcClientIdAndJobId(Mockito.anyString(),Mockito.any());
        doReturn(null).when(migClientRepository).save(Mockito.any());

        EnrollClientResponse actClientEnrolled = clientService.enrollClient(companyId, clientId, 1L);

        assertEquals(clientEnrolled, actClientEnrolled);

        System.out.println("client updated successfully");

    }

    @Test
    public void enrollClient_acc_error() throws Exception {
        when(clientRepository.findByOlbClinetId(clientId)).thenReturn(stgClient);
        doReturn("123").when(stgClient).getJobId();
        clientService.lastLoginMonthThreshold = 18;
        StgUser u = new StgUser();
        u.setPrimaryUser(true);
        u.setStatus("1");
        u.setCountryCode("1");
        u.setLastLoginDate(LocalDate.now());
        u.setOlbClientId(clientId);
        u.setUserLoginId("123");
        u.setCntPh("987");
        List<StgUser> users = new ArrayList<>();
        users.add(u);

        Mockito.when(stgUserRepository.findByOlbClientId(ArgumentMatchers.anyString(), ArgumentMatchers.anyString())).thenReturn(Collections.singletonList(u));

        when(stgUserRepository.findByOlbClientId(clientId, "Y")).thenReturn(users);
        oAuth = "e2561beef23920c18902ada758a1118de96be728add38b1a04acb2d911845352";
        when(cacheManagerUtility.getOauthToken()).thenReturn(oAuth);
        when(stgClient.getPrimaryCifUbs()).thenReturn("200030009");

        Cifs cifListRequest = new Cifs();
        Cif cif = new Cif();
        cif.setCifNumber(stgClient.getPrimaryCifUbs());

        List<Cif> cifs = new ArrayList<>();
        List<AccountServices> cifaccounts = new ArrayList<>();
        AccountServices as = new AccountServices();
        List<SvbService> accServ = new ArrayList<>();
        SvbService ss = new SvbService();


        List<ServiceTransaction> serviceTxns = new ArrayList<>();
        ServiceTransaction sTxn = new ServiceTransaction();
        sTxn.setSvcTxnId("svcTxnId");
        serviceTxns.add(sTxn);
        ss.setServiceTxn(serviceTxns);
        accServ.add(ss);
        as.setAccServ(accServ);
        as.setAccountNum("accNum");
        cifaccounts.add(as);
        cif.setCifAccounts(cifaccounts);
        cifs.add(cif);
        cifListRequest.setCifData(cifs);
        doReturn(cifListRequest).when(clientService).getCifAccountInfo(any(), any(), any(), any());

        Bundles bundles = new Bundles();
        List<Bundle> digitalBundles = new ArrayList<>();
        Bundle b = new Bundle();
        List<BundleServices> services = new ArrayList<>();
        BundleServices bs = new BundleServices();
        SvbService service = new SvbService();
        List<ServiceTransaction> serviceTxn = new ArrayList<>();
        service.setServiceId("sId");
        service.setServiceName("sName");
        ServiceTransaction st = new ServiceTransaction();
        st.setAcctSpecificTxn("Y");
        st.setOperation("Credit");
        st.setSvcTxnId("svcTxnId");

        serviceTxn.add(st);

        service.setServiceTxn(serviceTxn);
        bs.setService(service);
        services.add(bs);
        b.setServices(services);
        b.setDigitalBundleId(15);
        digitalBundles.add(b);
        bundles.setDigitalBundles(digitalBundles);
        doReturn(bundles).when(clientService).getBundles(any(), any(), any());

        List<AccountServices> cifAccounts = new ArrayList<>();
        AccountServices accountServices = new AccountServices();
        accountServices.setAccCcy("accCcy");
        accountServices.setAccName("accName");
        accountServices.setAccountNum("1234567890");
        accountServices.setAccountTyp("CC");
        //accountServices.setAccStat("stat");
        accountServices.setAccountTyp("Deposit Account");
        accountServices.setProdCode("prodCode");
        accountServices.setAccServ(accServ);
        cifAccounts.add(accountServices);

        List<Cif> cifData = new ArrayList<>();
        Cif c = new Cif();
        c.setUbsCifNum("200030009");
        c.setCifAccounts(cifAccounts);
        cifData.add(c);
        when(cifsInfo.getCifData()).thenReturn(cifData);
        cifListRequest.setCifData(cifData);

        clientService.migStartupBankingBundle = 15;
        doReturn(clientEnrolled).when(clientService).createClient(any(), any(),any(), any());

        doNothing().when(entityLogUtility).saveEntityCountAndTimeLog(Mockito.any());

        EnrollClientResponse resp = clientService.enrollClient(companyId, clientId, 1L);

        String expectedMessage = "cifData.getAccStat is null";
        String actualMessage = resp.getErrors().get(0).getDescription();
        assertEquals(expectedMessage, actualMessage);
    }

    @Test
    public void enrollClientCifsNull() throws Exception {
        when(clientRepository.findByOlbClinetId(clientId)).thenReturn(stgClient);
        doReturn("123").when(stgClient).getJobId();
        clientService.lastLoginMonthThreshold = 18;
        StgUser u = new StgUser();
        u.setPrimaryUser(true);
        u.setStatus("1");
        u.setCountryCode("1");
        u.setLastLoginDate(LocalDate.now());
        u.setOlbClientId(clientId);
        u.setUserLoginId("123");
        u.setCntPh("987");
        List<StgUser> users = new ArrayList<>();
        users.add(u);

        Mockito.when(stgUserRepository.findByOlbClientId(ArgumentMatchers.anyString(), ArgumentMatchers.anyString())).thenReturn(Collections.singletonList(u));

        when(stgUserRepository.findByOlbClientId(clientId, "Y")).thenReturn(users);
        oAuth = "e2561beef23920c18902ada758a1118de96be728add38b1a04acb2d911845352";
        when(cacheManagerUtility.getOauthToken()).thenReturn(oAuth);
        when(stgClient.getPrimaryCifUbs()).thenReturn("200030009");

        doReturn(null).when(clientService).getCifAccountInfo(any(), any(), any(), any());

        Bundles bundles = new Bundles();
        List<Bundle> digitalBundles = new ArrayList<>();
        Bundle b = new Bundle();
        List<BundleServices> services = new ArrayList<>();
        BundleServices bs = new BundleServices();
        SvbService service = new SvbService();
        List<ServiceTransaction> serviceTxn = new ArrayList<>();
        service.setServiceId("sId");
        service.setServiceName("sName");
        ServiceTransaction st = new ServiceTransaction();
        st.setAcctSpecificTxn("Y");
        st.setOperation("Credit");
        st.setSvcTxnId("svcTxnId");

        serviceTxn.add(st);

        service.setServiceTxn(serviceTxn);
        bs.setService(service);
        services.add(bs);
        b.setServices(services);
        b.setDigitalBundleId(15);
        digitalBundles.add(b);
        bundles.setDigitalBundles(digitalBundles);
        doReturn(bundles).when(clientService).getBundles(any(), any(), any());

        List<AccountServices> cifAccounts = new ArrayList<>();
        AccountServices accountServices = new AccountServices();
        accountServices.setAccCcy("accCcy");
        accountServices.setAccName("accName");
        accountServices.setAccountNum("1234567890");
        accountServices.setAccountTyp("CC");
        //accountServices.setAccStat("stat");
        accountServices.setAccountTyp("Deposit Account");
        accountServices.setProdCode("prodCode");
        //accountServices.setAccServ(accServ);
        cifAccounts.add(accountServices);

        List<Cif> cifData = new ArrayList<>();
        Cif c = new Cif();
        c.setUbsCifNum("200030009");
        c.setCifAccounts(cifAccounts);
        cifData.add(c);
        when(cifsInfo.getCifData()).thenReturn(cifData);

        clientService.migStartupBankingBundle = 15;
        doReturn(clientEnrolled).when(clientService).createClient(any(), any(),any(), any());

        doNothing().when(entityLogUtility).saveEntityCountAndTimeLog(Mockito.any());

        EnrollClientResponse resp = clientService.enrollClient(companyId, clientId, 1L);
        assertEquals("cifsInfo is null", resp.getErrors().get(0).getDescription());

        ArgumentCaptor<MigClient> argumentCaptorMigClient = ArgumentCaptor.forClass(MigClient.class);
        verify(migClientRepository, times(2)).save(argumentCaptorMigClient.capture());
        List<MigClient> capturedArgumentMigClientList = argumentCaptorMigClient.<MigClient>getAllValues();
        assertTrue(1L==capturedArgumentMigClientList.get(1).getJobId());
        assertEquals(STATUS_FAILURE, capturedArgumentMigClientList.get(1).getStatus());

        ArgumentCaptor<EntityRecordCount> argumentCaptor = ArgumentCaptor.forClass(EntityRecordCount.class);
        verify(entityLogUtility).saveEntityCountAndTimeLog(argumentCaptor.capture());
        EntityRecordCount capturedArgument = argumentCaptor.<EntityRecordCount>getValue();
        assertEquals("1", capturedArgument.getJOB_ID());
        assertEquals(1, capturedArgument.getREADCOUNT());
        assertEquals(0, capturedArgument.getWRITECOUNT());
        assertEquals(1, capturedArgument.getSKIPCOUNT());
        assertEquals(clientId, capturedArgument.getECCLIENT_ID());
        assertEquals("ClientCreation", capturedArgument.getENTITY_NAME());
    }

    @Ignore
    public void enrollClient_success_2() throws Exception {
        stgClient.setJobId("123");
        when(clientRepository.findByOlbClinetId(clientId)).thenReturn(stgClient);
        doReturn("123").when(stgClient).getJobId();
        StgUser u = new StgUser();
        u.setPrimaryUser(true);
        u.setLastLoginDate( LocalDate.now());
        List<StgUser> users = new ArrayList<>();
        users.add(u);
        clientService.lastLoginMonthThreshold = 18;

        when(stgUserRepository.findByOlbClientId(Matchers.any(), Mockito.anyString())).thenReturn(users);
        oAuth="e2561beef23920c18902ada758a1118de96be728add38b1a04acb2d911845352";
        when(cacheManagerUtility.getOauthToken()).thenReturn(oAuth);
        when(stgClient.getPrimaryCifUbs()).thenReturn("200030009");

        Cifs cifListRequest = new Cifs();
        Cif cif = new Cif();
        cif.setCifNumber(stgClient.getPrimaryCifUbs());

        List<Cif> cifs = new ArrayList<>();
        List<AccountServices> cifaccounts = new ArrayList<>();
        AccountServices as = new AccountServices();
        List<SvbService> accServ = new ArrayList<>();
        SvbService ss = new SvbService();

        List<ServiceTransaction> serviceTxns = new ArrayList<>();
        ServiceTransaction sTxn = new ServiceTransaction();
        sTxn.setSvcTxnId("svcTxnId");
        serviceTxns.add(sTxn);
        ss.setServiceTxn(serviceTxns);
        accServ.add(ss);
        as.setAccServ(accServ);
        as.setAccountNum("accNum");
        cifs.add(cif);
        cifListRequest.setCifData(cifs);
        doReturn(cifListRequest).when(clientService).getCifAccountInfo(any(), any(), any(), any());

        Bundles bundles = new Bundles();
        List<Bundle> digitalBundles = new ArrayList<>();
        Bundle b = new Bundle();
        List<BundleServices> services = new ArrayList<>();
        BundleServices bs = new BundleServices();
        SvbService service = new SvbService();
        List<ServiceTransaction> serviceTxn = new ArrayList<>();
        service.setServiceId("sId");
        service.setServiceName("sName");
        ServiceTransaction st = new ServiceTransaction();
        st.setAcctSpecificTxn("N");
        st.setOperation("Credit");
        st.setSvcTxnId("svcTxnId");
        ServiceTransaction st1 = new ServiceTransaction();
        st1.setAcctSpecificTxn("N");
        st1.setOperation("Credit");
        st1.setSvcTxnId("svcTxnId1");
        ServiceTransaction st2 = new ServiceTransaction();
        st1.setAcctSpecificTxn("N");
        st2.setOperation("Credit");
        st2.setSvcTxnId("svcTxnId2");

        serviceTxn.add(st);
        serviceTxn.add(st1);
        serviceTxn.add(st2);

        service.setServiceTxn(serviceTxn);
        bs.setService(service);
        services.add(bs);
        b.setServices(services);
        b.setDigitalBundleId(15);
        digitalBundles.add(b);
        bundles.setDigitalBundles(digitalBundles);
        doReturn(bundles).when(clientService).getBundles(any(), any(), any());

        List<AccountServices> cifAccounts = new ArrayList<>();
        AccountServices accountServices = new AccountServices();
        accountServices.setAccCcy("accCcy");
        accountServices.setAccName("accName");
        accountServices.setAccountNum("1234567890");
        accountServices.setAccountTyp("CC");
        accountServices.setAccStat("stat");
        accountServices.setAccountTyp("Deposit Account");
        accountServices.setProdCode("prodCode");
        accountServices.setAccServ(accServ);
        cifAccounts.add(accountServices);

        List<Cif> cifData = new ArrayList<>();
        Cif c = new Cif();
        c.setUbsCifNum("200030009");
        c.setCbsCifNum("2000300009");
        c.setCifAccounts(cifAccounts);
        cifData.add(c);
        when(cifsInfo.getCifData()).thenReturn(cifData);
        cifListRequest.setCifData(cifData);

        EnrollClientResponse clientEnrolled = new EnrollClientResponse();
        EnrollClientResponseData data = new EnrollClientResponseData();
        data.setGwPrimaryUserId("pUserId");
        data.setGwClientId("geClientId");
        data.setStatus("success");
        clientEnrolled.setData(data);

        //doNothing().when(clientService).save(Mockito.any(MigClient.class));

        clientService.migStartupBankingBundle = 15;
        doReturn(clientEnrolled).when(clientService).createClient(any(), any(),any(), any());

        MigClient mg = new MigClient();
        mg.setGwClientId("geClientId");
        mg.setCompanyId("home9500");
        mg.setStatus("success");
        mg.setEcClientId("home9522");
        doReturn(mg).when(migClientRepository).findByEcClientIdAndJobId(Mockito.anyString(),Mockito.any());
        doReturn(mg).when(migClientRepository).save(Mockito.any());

        EnrollClientResponse actClientEnrolled = clientService.enrollClient(companyId, clientId, 1L);

        assertEquals(clientEnrolled, actClientEnrolled);

    }

    @Test
    public void enrollClient_user_empty() throws Exception {
        when(clientRepository.findByOlbClinetId(clientId)).thenReturn(stgClient);

        StgUser u = new StgUser();
        u.setPrimaryUser(true);
        List<StgUser> users = new ArrayList<>();
        //users.add(u);

        when(stgUserRepository.findByOlbClientId(clientId, "Y")).thenReturn(users);
        oAuth = "e2561beef23920c18902ada758a1118de96be728add38b1a04acb2d911845352";
        when(cacheManagerUtility.getOauthToken()).thenReturn(oAuth);
        when(stgClient.getPrimaryCifUbs()).thenReturn("200030009");

        Cifs cifListRequest = new Cifs();
        Cif cif = new Cif();
        cif.setCifNumber(stgClient.getPrimaryCifUbs());

        List<Cif> cifs = new ArrayList<>();
        List<AccountServices> cifaccounts = new ArrayList<>();
        AccountServices as = new AccountServices();
        List<SvbService> accServ = new ArrayList<>();
        SvbService ss = new SvbService();

        List<ServiceTransaction> serviceTxns = new ArrayList<>();
        ServiceTransaction sTxn = new ServiceTransaction();
        sTxn.setSvcTxnId("svcTxnId");
        serviceTxns.add(sTxn);
        ss.setServiceTxn(serviceTxns);
        accServ.add(ss);
        as.setAccServ(accServ);
        as.setAccountNum("accNum");
        cifs.add(cif);
        cifListRequest.setCifData(cifs);
        doReturn(cifListRequest).when(clientService).getCifAccountInfo(any(), any(), any(), any());

        Bundles bundles = new Bundles();
        List<Bundle> digitalBundles = new ArrayList<>();
        Bundle b = new Bundle();
        List<BundleServices> services = new ArrayList<>();
        BundleServices bs = new BundleServices();
        SvbService service = new SvbService();
        List<ServiceTransaction> serviceTxn = new ArrayList<>();
        service.setServiceId("sId");
        service.setServiceName("sName");
        ServiceTransaction st = new ServiceTransaction();
        st.setAcctSpecificTxn("Y");
        st.setOperation("Credit");
        st.setSvcTxnId("svcTxnId");

        serviceTxn.add(st);

        service.setServiceTxn(serviceTxn);
        bs.setService(service);
        services.add(bs);
        b.setServices(services);
        b.setDigitalBundleId(15);
        digitalBundles.add(b);
        bundles.setDigitalBundles(digitalBundles);
        doReturn(bundles).when(clientService).getBundles(any(), any(), any());

        List<AccountServices> cifAccounts = new ArrayList<>();
        AccountServices accountServices = new AccountServices();
        accountServices.setAccCcy("accCcy");
        accountServices.setAccName("accName");
        accountServices.setAccountNum("1234567890");
        accountServices.setAccountTyp("CC");
        accountServices.setAccStat("stat");
        accountServices.setAccountTyp("Deposit Account");
        accountServices.setProdCode("prodCode");
        accountServices.setAccServ(accServ);
        cifAccounts.add(accountServices);

        List<Cif> cifData = new ArrayList<>();
        Cif c = new Cif();
        c.setUbsCifNum("200030009");
        c.setCifAccounts(cifAccounts);
        cifData.add(c);
        when(cifsInfo.getCifData()).thenReturn(cifData);
        cifListRequest.setCifData(cifData);

        clientService.migStartupBankingBundle = 15;
        doReturn(clientEnrolled).when(clientService).createClient(any(), any(), any(), any());

        EnrollClientResponse resp = clientService.enrollClient(companyId, clientId, 1L);

        String expectedMessage = "Users are not present";
        String actualMessage = resp.getErrors().get(0).getDescription();
        assertEquals(expectedMessage, actualMessage);

    }

    @Test
    public void enrollClient_oAuth_null() throws Exception {
        when(clientRepository.findByOlbClinetId(clientId)).thenReturn(stgClient);

        clientService.lastLoginMonthThreshold= 18;
        StgUser u = new StgUser();
        u.setPrimaryUser(true);
        u.setStatus("1");
        u.setCountryCode("1");
        u.setCntPh("987");
        u.setOlbClientId(clientId);
        u.setUserLoginId("123");
        u.setLastLoginDate(LocalDate.now());
        List<StgUser> users = new ArrayList<>();
        users.add(u);

        Mockito.when(stgUserRepository.findByOlbClientId(ArgumentMatchers.anyString(), ArgumentMatchers.anyString())).thenReturn(Collections.singletonList(u));

        when(stgUserRepository.findByOlbClientId(clientId, "Y")).thenReturn(users);
        oAuth = null;
        when(cacheManagerUtility.getOauthToken()).thenReturn(oAuth);
        when(stgClient.getPrimaryCifUbs()).thenReturn("200030009");

        Cifs cifListRequest = new Cifs();
        Cif cif = new Cif();
        cif.setCifNumber(stgClient.getPrimaryCifUbs());

        List<Cif> cifs = new ArrayList<>();
        List<AccountServices> cifaccounts = new ArrayList<>();
        AccountServices as = new AccountServices();
        List<SvbService> accServ = new ArrayList<>();
        SvbService ss = new SvbService();

        List<ServiceTransaction> serviceTxns = new ArrayList<>();
        ServiceTransaction sTxn = new ServiceTransaction();
        sTxn.setSvcTxnId("svcTxnId");
        serviceTxns.add(sTxn);
        ss.setServiceTxn(serviceTxns);
        accServ.add(ss);
        as.setAccServ(accServ);
        as.setAccountNum("accNum");
        cifs.add(cif);
        cifListRequest.setCifData(cifs);
        doReturn(cifListRequest).when(clientService).getCifAccountInfo(any(), any(), any(), any());

        Bundles bundles = new Bundles();
        List<Bundle> digitalBundles = new ArrayList<>();
        Bundle b = new Bundle();
        List<BundleServices> services = new ArrayList<>();
        BundleServices bs = new BundleServices();
        SvbService service = new SvbService();
        List<ServiceTransaction> serviceTxn = new ArrayList<>();
        service.setServiceId("sId");
        service.setServiceName("sName");
        ServiceTransaction st = new ServiceTransaction();
        st.setAcctSpecificTxn("Y");
        st.setOperation("Credit");
        st.setSvcTxnId("svcTxnId");

        serviceTxn.add(st);

        service.setServiceTxn(serviceTxn);
        bs.setService(service);
        services.add(bs);
        b.setServices(services);
        b.setDigitalBundleId(15);
        digitalBundles.add(b);
        bundles.setDigitalBundles(digitalBundles);
        doReturn(bundles).when(clientService).getBundles(any(), any(), any());

        List<AccountServices> cifAccounts = new ArrayList<>();
        AccountServices accountServices = new AccountServices();
        accountServices.setAccCcy("accCcy");
        accountServices.setAccName("accName");
        accountServices.setAccountNum("1234567890");
        accountServices.setAccountTyp("CC");
        accountServices.setAccStat("stat");
        accountServices.setAccountTyp("Deposit Account");
        accountServices.setProdCode("prodCode");
        accountServices.setAccServ(accServ);
        cifAccounts.add(accountServices);

        List<Cif> cifData = new ArrayList<>();
        Cif c = new Cif();
        c.setUbsCifNum("200030009");
        c.setCifAccounts(cifAccounts);
        cifData.add(c);
        when(cifsInfo.getCifData()).thenReturn(cifData);
        cifListRequest.setCifData(cifData);

        clientService.migStartupBankingBundle = 15;
        doReturn(clientEnrolled).when(clientService).createClient(any(), any(), any(), any());

        EnrollClientResponse resp = clientService.enrollClient(companyId, clientId, 1L);

        String expectedMessage = "unable to retrieve Oauth";
        String actualMessage = resp.getErrors().get(0).getDescription();
        assertEquals(expectedMessage, actualMessage);

    }

    @Test
    public void enrollClient_cifInfo_null() throws Exception {
        when(clientRepository.findByOlbClinetId(Matchers.any())).thenReturn(stgClient);

        clientService.lastLoginMonthThreshold= 18;
        StgUser u = new StgUser();
        u.setPrimaryUser(true);
        u.setStatus("1");
        u.setCountryCode("1");
        u.setCntPh("987");
        u.setOlbClientId(clientId);
        u.setUserLoginId("123");
        u.setLastLoginDate(LocalDate.now());
        List<StgUser> users = new ArrayList<>();
        users.add(u);

        Mockito.when(stgUserRepository.findByOlbClientId(ArgumentMatchers.anyString(), ArgumentMatchers.anyString())).thenReturn(Collections.singletonList(u));


        when(stgUserRepository.findByOlbClientId(Matchers.any(), Mockito.anyString())).thenReturn(users);
        oAuth = "e2561beef23920c18902ada758a1118de96be728add38b1a04acb2d911845352";
        when(cacheManagerUtility.getOauthToken()).thenReturn(oAuth);
        when(stgClient.getPrimaryCifUbs()).thenReturn("200030009");

        Cifs cifListRequest = new Cifs();
        Cif cif = new Cif();
        cif.setCifNumber(stgClient.getPrimaryCifUbs());

        List<Cif> cifs = new ArrayList<>();
        List<AccountServices> cifaccounts = new ArrayList<>();
        AccountServices as = new AccountServices();
        List<SvbService> accServ = new ArrayList<>();
        SvbService ss = new SvbService();

        List<ServiceTransaction> serviceTxns = new ArrayList<>();
        ServiceTransaction sTxn = new ServiceTransaction();
        sTxn.setSvcTxnId("svcTxnId");
        serviceTxns.add(sTxn);
        ss.setServiceTxn(serviceTxns);
        accServ.add(ss);
        as.setAccServ(accServ);
        as.setAccountNum("accNum");
        cifs.add(cif);
        cifListRequest.setCifData(cifs);
        doReturn(null).when(clientService).getCifAccountInfo(any(), any(), any(), any());

        Bundles bundles = new Bundles();
        List<Bundle> digitalBundles = new ArrayList<>();
        Bundle b = new Bundle();
        List<BundleServices> services = new ArrayList<>();
        BundleServices bs = new BundleServices();
        SvbService service = new SvbService();
        List<ServiceTransaction> serviceTxn = new ArrayList<>();
        service.setServiceId("sId");
        service.setServiceName("sName");
        ServiceTransaction st = new ServiceTransaction();
        st.setAcctSpecificTxn("Y");
        st.setOperation("Credit");
        st.setSvcTxnId("svcTxnId");

        serviceTxn.add(st);

        service.setServiceTxn(serviceTxn);
        bs.setService(service);
        services.add(bs);
        b.setServices(services);
        b.setDigitalBundleId(15);
        digitalBundles.add(b);
        bundles.setDigitalBundles(digitalBundles);
        doReturn(bundles).when(clientService).getBundles(any(), any(), any());

        List<AccountServices> cifAccounts = new ArrayList<>();
        AccountServices accountServices = new AccountServices();
        accountServices.setAccCcy("accCcy");
        accountServices.setAccName("accName");
        accountServices.setAccountNum("1234567890");
        accountServices.setAccountTyp("CC");
        accountServices.setAccStat("stat");
        accountServices.setAccountTyp("Deposit Account");
        accountServices.setProdCode("prodCode");
        accountServices.setAccServ(accServ);
        cifAccounts.add(accountServices);

        List<Cif> cifData = new ArrayList<>();
        Cif c = new Cif();
        c.setUbsCifNum("200030009");
        c.setCifAccounts(cifAccounts);
        cifData.add(c);
        when(cifsInfo.getCifData()).thenReturn(cifData);
        cifListRequest.setCifData(cifData);

        clientService.migStartupBankingBundle = 15;
        doReturn(clientEnrolled).when(clientService).createClient(any(), any(), any(), any());

        doNothing().when(entityLogUtility).saveEntityCountAndTimeLog(Mockito.any());

        EnrollClientResponse resp = clientService.enrollClient(companyId, clientId, 1L);

        String expectedMessage = "cifsInfo is null";
        String actualMessage = resp.getErrors().get(0).getDescription();
        assertEquals(expectedMessage, actualMessage);
    }

    @Test
    public void enrollClient_error_user() throws Exception {
        when(clientRepository.findByOlbClinetId(clientId)).thenReturn(stgClient);
        List<com.svb.gateway.migration.user.entity.StgUser> users1 = new ArrayList<>();
        StgUser u = new StgUser();
        u.setPrimaryUser(false);
        users1.add(u);

        when(stgUserRepository.findByOlbClientId(clientId, "Y")).thenReturn(users1);
        oAuth = "e2561beef23920c18902ada758a1118de96be728add38b1a04acb2d911845352";
        when(cacheManagerUtility.getOauthToken()).thenReturn(oAuth);
        when(stgClient.getPrimaryCifUbs()).thenReturn("200030009");

        Cifs cifListRequest = new Cifs();
        Cif cif = new Cif();
        cif.setCifNumber(stgClient.getPrimaryCifUbs());
        List<Cif> cifs = new ArrayList<>();
        cifs.add(cif);
        cifListRequest.setCifData(cifs);
        doReturn(cifsInfo).when(clientService).getCifAccountInfo(any(), any(), any(), any());

        Bundles bundles = new Bundles();
        List<Bundle> digitalBundles = new ArrayList<>();
        Bundle b = new Bundle();
        List<BundleServices> services = new ArrayList<>();
        BundleServices bs = new BundleServices();
        SvbService service = new SvbService();
        List<ServiceTransaction> serviceTxn = new ArrayList<>();
        service.setServiceId("sId");
        service.setServiceName("sName");
        ServiceTransaction st = new ServiceTransaction();
        st.setAcctSpecificTxn("Y");
        serviceTxn.add(st);

        service.setServiceTxn(serviceTxn);
        bs.setService(service);
        services.add(bs);
        b.setServices(services);
        b.setDigitalBundleId(15);
        digitalBundles.add(b);
        bundles.setDigitalBundles(digitalBundles);
        doReturn(bundles).when(clientService).getBundles(any(), any(), any());

        List<AccountServices> cifAccounts = new ArrayList<>();
        AccountServices accountServices = new AccountServices();
        accountServices.setAccCcy("accCcy");
        accountServices.setAccName("accName");
        accountServices.setAccountNum("1234567890");
        accountServices.setAccountTyp("CC");
        accountServices.setAccStat("stat");
        accountServices.setAccountTyp("Deposit Account");
        accountServices.setProdCode("prodCode");
        List<SvbService> accServ = new ArrayList<>();
        SvbService svbService = new SvbService();
        svbService.setServiceName("sName");
        accServ.add(svbService);
        accountServices.setAccServ(accServ);
        cifAccounts.add(accountServices);

        List<Cif> cifData = new ArrayList<>();
        Cif c = new Cif();
        c.setUbsCifNum("200030009");
        c.setCifAccounts(cifAccounts);
        cifData.add(c);
        when(cifsInfo.getCifData()).thenReturn(cifData);
        cifListRequest.setCifData(cifData);

        clientService.migStartupBankingBundle = 15;
        try {
            EnrollClientResponse resp = clientService.enrollClient(companyId, clientId, 1L);
        }
        catch (ServiceException ex){
            assertEquals("Primary User not available",ex.getMessage());
        }

        //String expectedMessage = "Primary User not available";
        //String actualMessage = resp.getErrors().get(0).getDescription();
        //assertEquals(expectedMessage, actualMessage);

    }

    @Test
    public void clientIdnull() throws Exception {

        EnrollClientResponse resp = clientService.enrollClient(companyId, null, 1L);

        String expectedMessage = "ecClient id null has Invalid Format";
        String actualMessage = resp.getErrors().get(0).getDescription();
        assertEquals(expectedMessage, actualMessage);
    }

    @Test
    public void companyIdFormatSuccess() throws Exception {
        when(clientRepository.findByOlbClinetId(clientId)).thenReturn(stgClient);
        doReturn("123").when(stgClient).getJobId();
        clientService.lastLoginMonthThreshold= 18;
        StgUser u = new StgUser();
        u.setPrimaryUser(true);
        u.setStatus("1");
        u.setCountryCode("1");
        u.setCntPh("987");
        u.setOlbClientId(clientId);
        u.setUserLoginId("123");
        u.setLastLoginDate(LocalDate.now());
        List<StgUser> users = new ArrayList<>();
        users.add(u);
        oAuth = "e2561beef23920c18902ada758a1118de96be728add38b1a04acb2d911845352";
        when(cacheManagerUtility.getOauthToken()).thenReturn(oAuth);
        when(stgClient.getPrimaryCifUbs()).thenReturn("200030009");

        Cifs cifListRequest = new Cifs();
        Cif cif = new Cif();
        cif.setCifNumber(stgClient.getPrimaryCifUbs());

        List<Cif> cifs = new ArrayList<>();
        List<AccountServices> cifaccounts = new ArrayList<>();
        AccountServices as = new AccountServices();
        List<SvbService> accServ = new ArrayList<>();
        SvbService ss = new SvbService();

        List<ServiceTransaction> serviceTxns = new ArrayList<>();
        ServiceTransaction sTxn = new ServiceTransaction();
        sTxn.setSvcTxnId("svcTxnId");
        serviceTxns.add(sTxn);
        ss.setServiceTxn(serviceTxns);
        accServ.add(ss);
        as.setAccServ(accServ);
        as.setAccountNum("accNum");
        cifs.add(cif);
        cifListRequest.setCifData(cifs);
        doReturn(cifListRequest).when(clientService).getCifAccountInfo(any(), any(), any(), any());

        Bundles bundles = new Bundles();
        List<Bundle> digitalBundles = new ArrayList<>();
        Bundle b = new Bundle();
        List<BundleServices> services = new ArrayList<>();
        BundleServices bs = new BundleServices();
        SvbService service = new SvbService();
        List<ServiceTransaction> serviceTxn = new ArrayList<>();
        service.setServiceId("sId");
        service.setServiceName("sName");
        ServiceTransaction st = new ServiceTransaction();
        st.setAcctSpecificTxn("Y");
        st.setOperation("Credit");
        st.setSvcTxnId("svcTxnId");

        serviceTxn.add(st);

        service.setServiceTxn(serviceTxn);
        bs.setService(service);
        services.add(bs);
        b.setServices(services);
        b.setDigitalBundleId(15);
        digitalBundles.add(b);
        bundles.setDigitalBundles(digitalBundles);
        doReturn(bundles).when(clientService).getBundles(any(), any(), any());

        List<AccountServices> cifAccounts = new ArrayList<>();
        AccountServices accountServices = new AccountServices();
        accountServices.setAccCcy("accCcy");
        accountServices.setAccName("accName");
        accountServices.setAccountNum("1234567890");
        accountServices.setAccountTyp("CC");
        accountServices.setAccStat("stat");
        accountServices.setAccountTyp("Deposit Account");
        accountServices.setProdCode("prodCode");
        accountServices.setAccServ(accServ);
        cifAccounts.add(accountServices);

        List<Cif> cifData = new ArrayList<>();
        Cif c = new Cif();
        c.setUbsCifNum("200030009");
        c.setCifAccounts(cifAccounts);
        cifData.add(c);
        when(cifsInfo.getCifData()).thenReturn(cifData);
        cifListRequest.setCifData(cifData);

        clientService.migStartupBankingBundle = 15;
        doReturn(clientEnrolled).when(clientService).createClient(any(), any(), any(), any());

        EnrollClientResponse resp = clientService.enrollClient(companyId, "123456", 1L);

        String expectedMessage = "ecClient id 123456 has Invalid Format";
        String actualMessage = resp.getErrors().get(0).getDescription();
        assertEquals(expectedMessage, actualMessage);

    }

    @Test
    public void companyIdNull() throws Exception {

        EnrollClientResponse resp = clientService.enrollClient(null, clientId, 1L);

        String expectedMessage = "Company id not passed";
        String actualMessage = resp.getErrors().get(0).getDescription();
        assertEquals(expectedMessage, actualMessage);
    }

    @Test
    public void enrollClient_error_bundle() throws Exception {
        oAuth = "e2561beef23920c18902ada758a1118de96be728add38b1a04acb2d911845352";
        when(cacheManagerUtility.getOauthToken()).thenReturn(oAuth);
        when(stgClient.getPrimaryCifUbs()).thenReturn("200030009");

        when(clientRepository.findByOlbClinetId(clientId)).thenReturn(stgClient);
        doReturn("123").when(stgClient).getJobId();
        clientService.lastLoginMonthThreshold= 18;
        StgUser u = new StgUser();
        u.setPrimaryUser(true);
        u.setStatus("1");
        u.setCountryCode("1");
        u.setCntPh("987");
        u.setOlbClientId(clientId);
        u.setUserLoginId("123");
        u.setLastLoginDate(LocalDate.now());
        List<StgUser> users = new ArrayList<>();
        users.add(u);

        when(stgUserRepository.findByOlbClientId(clientId, "Y")).thenReturn(Collections.singletonList(u));

        Cifs cifListRequest = new Cifs();
        Cif cif = new Cif();
        cif.setCifNumber(stgClient.getPrimaryCifUbs());
        List<Cif> cifs = new ArrayList<>();
        cifs.add(cif);
        cifListRequest.setCifData(cifs);
        doReturn(cifsInfo).when(clientService).getCifAccountInfo(any(), any(), any(), any());

        Bundles bundles = new Bundles();
        List<Bundle> digitalBundles = new ArrayList<>();
        Bundle b = new Bundle();
        b.setDigitalBundleId(16);
        digitalBundles.add(b);
        bundles.setDigitalBundles(digitalBundles);
        doReturn(bundles).when(clientService).getBundles(any(), any(), any());

        List<Cif> cifData = new ArrayList<>();
        Cif c = new Cif();
        c.setUbsCifNum("200030009");
        cifData.add(c);
        when(cifsInfo.getCifData()).thenReturn(cifData);
        cifListRequest.setCifData(cifData);

        clientService.migStartupBankingBundle = 15;

        EnrollClientResponse resp = clientService.enrollClient(companyId, clientId, 1L);

        String expectedMessage = "Startup Banking Bundle - 15 does not exist!";
        String actualMessage = resp.getErrors().get(0).getDescription();
        assertEquals(expectedMessage, actualMessage);
    }

    @Test
    public void enrollClient_error_cifData() throws Exception {

        when(clientRepository.findByOlbClinetId(clientId)).thenReturn(stgClient);
        doReturn("123").when(stgClient).getJobId();
        clientService.lastLoginMonthThreshold= 18;
        StgUser u = new StgUser();
        u.setPrimaryUser(true);
        u.setStatus("1");
        u.setCountryCode("1");
        u.setCntPh("987");
        u.setOlbClientId(clientId);
        u.setUserLoginId("123");
        u.setLastLoginDate(LocalDate.now());
        List<StgUser> users = new ArrayList<>();
        users.add(u);

        Mockito.when(stgUserRepository.findByOlbClientId(ArgumentMatchers.anyString(), ArgumentMatchers.anyString())).thenReturn(Collections.singletonList(u));

        when(stgUserRepository.findByOlbClientId(clientId, "Y")).thenReturn(users);

        Mockito.when(stgUserRepository.findByOlbClientId(ArgumentMatchers.anyString(), ArgumentMatchers.anyString())).thenReturn(Collections.singletonList(u));


        when(stgUserRepository.findByOlbClientId(clientId, "Y")).thenReturn(users);
        oAuth = "e2561beef23920c18902ada758a1118de96be728add38b1a04acb2d911845352";
        when(cacheManagerUtility.getOauthToken()).thenReturn(oAuth);
        when(stgClient.getPrimaryCifUbs()).thenReturn("200030009");

        List<Cif> cifData = new ArrayList<>();
        Cif c = new Cif();
        c.setUbsCifNum("2000030009");
        cifData.add(c);
        when(cifsInfo.getCifData()).thenReturn(cifData);
        doReturn(cifsInfo).when(clientService).getCifAccountInfo(any(), any(), any(), any());

        EnrollClientResponse resp = clientService.enrollClient(companyId, clientId, 1L);

        String expectedMessage = "Cif not available";
        String actualMessage = resp.getErrors().get(0).getDescription();
        assertEquals(expectedMessage, actualMessage);

    }

    @Test
    public void createClient_error() throws Exception {

        ClientInfo ci = new ClientInfo();
        Cif cif = new Cif();
        cif.setUbsCifNum("2345");
        ci.setClientCifs(Collections.singletonList(cif));
        ResponseEntity<ClientInfo> clientInfo = new ResponseEntity<>(ci, HttpStatus.ACCEPTED);

        HttpHeaders headers = new HttpHeaders();
        headers.add(MigrationConstants.AUTHORIZATION_HEADER_NAME, oAuth);
        headers.add(MigrationConstants.CONTENT_TYPE, MigrationConstants.APPLICATION_HEADER_JSON);

        HttpEntity<EnrollClientRequest> requestEntity = new HttpEntity<>(request, headers);

        doThrow(new RestClientException("Test Exception")).when(restTemplate).exchange(Mockito.anyString(), Mockito.any(HttpMethod.class), Mockito.any(HttpEntity.class), eq(ClientInfo.class));
        EnrollClientRequest request1 = new EnrollClientRequest();
        request1.setClientCifs(Collections.singletonList(cif));
        clientService.migEnrollClientUrl = "migEnrollClientUrlTest";
        clientService.createClient(request1, oAuth, "test", 100L);
    }

    @Test
    public void createClient_pUser_null() throws Exception {

        ClientInfo ci = new ClientInfo();
        com.svb.gateway.migration.client.model.Client c = new com.svb.gateway.migration.client.model.Client();
        c.setOlbId("olbId");
        List<com.svb.gateway.migration.user.model.User> userDetails = new ArrayList<>();
        com.svb.gateway.migration.user.model.User u = new com.svb.gateway.migration.user.model.User();
        u.setIdStoreuserkey(null);
        userDetails.add(u);
        Cif cif = new Cif();
        cif.setUbsCifNum("45896");
        ci.setClientCifs(Collections.singletonList(cif));
        ci.setUserDetails(userDetails);
        ci.setClientData(c);
        ResponseEntity<ClientInfo> clientInfo = new ResponseEntity<>(ci, HttpStatus.ACCEPTED);
        request.setClientCifs(Collections.singletonList(cif));
        HttpHeaders headers = new HttpHeaders();
        headers.add(MigrationConstants.AUTHORIZATION_HEADER_NAME, oAuth);
        headers.add(MigrationConstants.CONTENT_TYPE, MigrationConstants.APPLICATION_HEADER_JSON);

        HttpEntity<EnrollClientRequest> requestEntity = new HttpEntity<>(request, headers);

        doReturn(clientInfo).when(restTemplate).exchange(Mockito.anyString(), Mockito.any(HttpMethod.class), Mockito.any(HttpEntity.class), eq(ClientInfo.class));

        clientService.migEnrollClientUrl = "migEnrollClientUrlTest";
        EnrollClientRequest request1 = new EnrollClientRequest();
        request1.setClientCifs(Collections.singletonList(cif));
        EnrollClientResponse enrollClientResponse = clientService.createClient(request1, oAuth, "test", 100L);
        assertEquals(STATUS_FAILURE, enrollClientResponse.getData().getStatus());
    }

    @Test
    public void createClient_success() throws Exception {

        ClientInfo ci = new ClientInfo();
        com.svb.gateway.migration.client.model.Client c = new com.svb.gateway.migration.client.model.Client();
        c.setOlbId("olbId");
        List<com.svb.gateway.migration.user.model.User> userDetails = new ArrayList<>();
        com.svb.gateway.migration.user.model.User u = new com.svb.gateway.migration.user.model.User();
        u.setIdStoreuserkey("idStoreuserkey");
        userDetails.add(u);
        Cif cif = new Cif();
        cif.setUbsCifNum("45896");
        ci.setClientCifs(Collections.singletonList(cif));
        ci.setUserDetails(userDetails);
        ci.setClientData(c);
        ResponseEntity<ClientInfo> clientInfo = new ResponseEntity<>(ci, HttpStatus.ACCEPTED);
        request.setClientCifs(Collections.singletonList(cif));
        HttpHeaders headers = new HttpHeaders();
        headers.add(MigrationConstants.AUTHORIZATION_HEADER_NAME, oAuth);
        headers.add(MigrationConstants.CONTENT_TYPE, MigrationConstants.APPLICATION_HEADER_JSON);

        HttpEntity<EnrollClientRequest> requestEntity = new HttpEntity<>(request, headers);

        doReturn(clientInfo).when(restTemplate).exchange(Mockito.anyString(), Mockito.any(HttpMethod.class), Mockito.any(HttpEntity.class), eq(ClientInfo.class));

        clientService.migEnrollClientUrl = "migEnrollClientUrlTest";
        EnrollClientRequest request1 = new EnrollClientRequest();
        request1.setClientCifs(Collections.singletonList(cif));
        EnrollClientResponse enrollClientResponse = clientService.createClient(request1, oAuth, "test", 100L);
        assertEquals(MigrationConstants.STATUS_SUCCESS, enrollClientResponse.getData().getStatus());
    }

    @Test
    public void createClient_body_null() throws Exception {

        ClientInfo ci = new ClientInfo();
        Cif cif = new Cif();
        cif.setUbsCifNum("2345");
        ci.setClientCifs(Collections.singletonList(cif));
        ResponseEntity<ClientInfo> clientInfo = new ResponseEntity<>(null, HttpStatus.ACCEPTED);

        HttpHeaders headers = new HttpHeaders();
        headers.add(MigrationConstants.AUTHORIZATION_HEADER_NAME, oAuth);
        headers.add(MigrationConstants.CONTENT_TYPE, MigrationConstants.APPLICATION_HEADER_JSON);

        HttpEntity<EnrollClientRequest> requestEntity = new HttpEntity<>(request, headers);

        doReturn(clientInfo).when(restTemplate).exchange(Mockito.anyString(), Mockito.any(HttpMethod.class), Mockito.any(HttpEntity.class), eq(ClientInfo.class));
        EnrollClientRequest request1 = new EnrollClientRequest();
        request1.setClientCifs(Collections.singletonList(cif));
        clientService.migEnrollClientUrl = "migEnrollClientUrlTest";
        clientService.createClient(request1, oAuth, "Test", 100L);
    }

    @Test
    public void createClient_data_null() throws Exception {

        ClientInfo ci = new ClientInfo();
        Cif cif = new Cif();
        cif.setUbsCifNum("45896");
        ci.setClientCifs(Collections.singletonList(cif));
        ResponseEntity<ClientInfo> clientInfo = new ResponseEntity<>(ci, HttpStatus.ACCEPTED);

        HttpHeaders headers = new HttpHeaders();
        headers.add(MigrationConstants.AUTHORIZATION_HEADER_NAME, oAuth);
        headers.add(MigrationConstants.CONTENT_TYPE, MigrationConstants.APPLICATION_HEADER_JSON);

        HttpEntity<EnrollClientRequest> requestEntity = new HttpEntity<>(request, headers);

        doReturn(clientInfo).when(restTemplate).exchange(Mockito.anyString(), Mockito.any(HttpMethod.class), Mockito.any(HttpEntity.class), eq(ClientInfo.class));
        EnrollClientRequest request1 = new EnrollClientRequest();
        request1.setClientCifs(Collections.singletonList(cif));
        clientService.migEnrollClientUrl = "migEnrollClientUrlTest";
        clientService.createClient(request1, oAuth, "test", 100L);
    }

    @Test
    public void createClient_user_null() throws Exception {

        ClientInfo ci = new ClientInfo();
        com.svb.gateway.migration.client.model.Client c = new com.svb.gateway.migration.client.model.Client();
        ci.setClientData(c);
        Cif cif = new Cif();
        cif.setUbsCifNum("45896");
        ci.setClientCifs(Collections.singletonList(cif));
        ResponseEntity<ClientInfo> clientInfo = new ResponseEntity<>(ci, HttpStatus.ACCEPTED);

        HttpHeaders headers = new HttpHeaders();
        headers.add(MigrationConstants.AUTHORIZATION_HEADER_NAME, oAuth);
        headers.add(MigrationConstants.CONTENT_TYPE, MigrationConstants.APPLICATION_HEADER_JSON);

        HttpEntity<EnrollClientRequest> requestEntity = new HttpEntity<>(request, headers);

        doReturn(clientInfo).when(restTemplate).exchange(Mockito.anyString(), Mockito.any(HttpMethod.class), Mockito.any(HttpEntity.class), eq(ClientInfo.class));
        EnrollClientRequest request1 = new EnrollClientRequest();
        request1.setClientCifs(Collections.singletonList(cif));
        clientService.migEnrollClientUrl = "migEnrollClientUrlTest";
        clientService.createClient(request1, oAuth, "test", 100L);
    }

    @Test
    public void getCifAccountInfo() throws Exception {

        HttpHeaders headers = new HttpHeaders();
        headers.add(MigrationConstants.AUTHORIZATION_HEADER_NAME, oAuth);
        headers.add(MigrationConstants.CONTENT_TYPE, MigrationConstants.APPLICATION_HEADER_JSON);

        Cifs cifListRequest = new Cifs();
        Cif cif = new Cif();
        cif.setUbsCifNum("565");
        cifListRequest.setCifData(Collections.singletonList(cif));
        HttpEntity<Cifs> requestEntity = new HttpEntity<>(cifListRequest, headers);

        Cif c = new Cif();
        c.setUbsCifNum("200030009");
        ResponseEntity<Cifs> response2 = new ResponseEntity<>(cifListRequest, HttpStatus.ACCEPTED);

        doReturn(response2).when(restTemplate).exchange(Mockito.anyString(), Mockito.any(HttpMethod.class), Mockito.any(HttpEntity.class), eq(Cifs.class));
        clientService.migrationFetchCifAccountUrl = "migrationFetchCifAccountUrlTest";
        Cifs cifs = clientService.getCifAccountInfo(cifListRequest, oAuth, "test", 100l);
        assertNotNull(cifs);
    }

    @Test
    public void getCifAccountInfo_null_data() throws Exception {

        HttpHeaders headers = new HttpHeaders();
        headers.add(MigrationConstants.AUTHORIZATION_HEADER_NAME, oAuth);
        headers.add(MigrationConstants.CONTENT_TYPE, MigrationConstants.APPLICATION_HEADER_JSON);

        Cifs cifListRequest = new Cifs();
        Cif cif = new Cif();
        cif.setUbsCifNum("45896");
        cifListRequest.setCifData(Collections.singletonList(cif));
        HttpEntity<Cifs> requestEntity = new HttpEntity<>(cifListRequest, headers);

        Cif c = new Cif();
        c.setUbsCifNum("200030009");
        ResponseEntity<Cifs> response2 = new ResponseEntity<>(null, HttpStatus.ACCEPTED);

        doReturn(response2).when(restTemplate).exchange(Mockito.anyString(), Mockito.any(HttpMethod.class), Mockito.any(HttpEntity.class), eq(Cifs.class));
        clientService.migrationFetchCifAccountUrl = "migrationFetchCifAccountUrlTest";
        Cifs cifs = clientService.getCifAccountInfo(cifListRequest, oAuth, "test", 100L);
        assertNull(cifs);
    }

    @Test
    public void getCifAccountInfo_resp_null() throws Exception {

        HttpHeaders headers = new HttpHeaders();
        headers.add(MigrationConstants.AUTHORIZATION_HEADER_NAME, oAuth);
        headers.add(MigrationConstants.CONTENT_TYPE, MigrationConstants.APPLICATION_HEADER_JSON);

        Cifs cifListRequest = new Cifs();
        Cif cif = new Cif();
        cif.setUbsCifNum("2345");
        cifListRequest.setCifData(Collections.singletonList(cif));

        HttpEntity<Cifs> requestEntity = new HttpEntity<>(cifListRequest, headers);

        doReturn(null).when(restTemplate).exchange(Mockito.anyString(), Mockito.any(HttpMethod.class), Mockito.any(HttpEntity.class), eq(Cifs.class));
        clientService.migrationFetchCifAccountUrl = "migrationFetchCifAccountUrlTest";
        try{
            Cifs cifs = clientService.getCifAccountInfo(cifListRequest, oAuth, "test", 200L);
        }
        catch (ServiceException ex){
           assertEquals("ClientService.getCifAccountInfo failed - null",ex.getMessage());
        }
    }

    @Test
    public void getCifAccountInfo_error() throws Exception {

        HttpHeaders headers = new HttpHeaders();
        headers.add(MigrationConstants.AUTHORIZATION_HEADER_NAME, oAuth);
        headers.add(MigrationConstants.CONTENT_TYPE, MigrationConstants.APPLICATION_HEADER_JSON);

        Cifs cifListRequest = new Cifs();
        Cif cif = new Cif();
        cif.setUbsCifNum("2345");
        cifListRequest.setCifData(Collections.singletonList(cif));
        HttpEntity<Cifs> requestEntity = new HttpEntity<>(cifListRequest, headers);

        doThrow(new RestClientException("Test Exception")).when(restTemplate).exchange(Mockito.anyString(), Mockito.any(HttpMethod.class), Mockito.any(HttpEntity.class), eq(Cifs.class));
        clientService.migrationFetchCifAccountUrl = "migrationFetchCifAccountUrlTest";
        try{
          Cifs cifs = clientService.getCifAccountInfo(cifListRequest, oAuth, "test", 200L);
        }
        catch (ServiceException ex){
            assertEquals("ClientService.getCifAccountInfo failed - Test Exception",ex.getMessage());
        }
    }

    @Test
    public void getBundles_success() throws Exception {

        HttpHeaders headers = new HttpHeaders();

        headers.add(MigrationConstants.AUTHORIZATION_HEADER_NAME, oAuth);

        HttpEntity<Bundles> requestEntity = new HttpEntity<>(headers);

        Bundles bundles = new Bundles();

        ResponseEntity<Bundles> response2 = new ResponseEntity<>(bundles, HttpStatus.ACCEPTED);

        doReturn(response2).when(restTemplate).exchange(Mockito.anyString(), Mockito.any(HttpMethod.class), Mockito.any(HttpEntity.class), eq(Bundles.class));

        clientService.migrationFetchBundlesUrl = "migrationFetchBundlesUrl";

        Bundles b = clientService.getBundles(oAuth, "test", 100L);
        assertEquals(bundles, b);

    }

    @Test
    public void getBundles_data_null() throws Exception {

        HttpHeaders headers = new HttpHeaders();

        headers.add(MigrationConstants.AUTHORIZATION_HEADER_NAME, oAuth);

        HttpEntity<Bundles> requestEntity = new HttpEntity<>(headers);

        Bundles bundles = new Bundles();

        ResponseEntity<Bundles> response2 = new ResponseEntity<>(null, HttpStatus.ACCEPTED);

        doReturn(response2).when(restTemplate).exchange(Mockito.anyString(), Mockito.any(HttpMethod.class), Mockito.any(HttpEntity.class), eq(Bundles.class));

        clientService.migrationFetchBundlesUrl = "migrationFetchBundlesUrl";

        Bundles b = clientService.getBundles(oAuth, "test", 100l);
        assertNull(b);

    }

    @Test
    public void getBundles_error() throws Exception {

        HttpHeaders headers = new HttpHeaders();

        headers.add(MigrationConstants.AUTHORIZATION_HEADER_NAME, oAuth);

        HttpEntity<Bundles> requestEntity = new HttpEntity<>(headers);

        Bundles bundles = new Bundles();

        ResponseEntity<Bundles> response2 = new ResponseEntity<>(bundles, HttpStatus.ACCEPTED);

        doThrow(new RestClientException("Test Exception")).when(restTemplate).exchange(Mockito.anyString(), Mockito.any(HttpMethod.class), Mockito.any(HttpEntity.class), eq(Bundles.class));

        clientService.migrationFetchBundlesUrl = "migrationFetchBundlesUrl";

        Bundles b = clientService.getBundles(oAuth, "test", 100l);
        assertNull(b);

    }

    @Test
    public void getBundles_null() throws Exception {

        HttpHeaders headers = new HttpHeaders();

        headers.add(MigrationConstants.AUTHORIZATION_HEADER_NAME, oAuth);

        HttpEntity<Bundles> requestEntity = new HttpEntity<>(headers);

        doReturn(null).when(restTemplate).exchange(Mockito.anyString(), Mockito.any(HttpMethod.class), Mockito.any(HttpEntity.class), eq(Bundles.class));

        clientService.migrationFetchBundlesUrl = "migrationFetchBundlesUrl";

        assertNull(clientService.getBundles(oAuth, "test", 100l));
    }

    @Test
    public void test_inactiveAndDeleteClient() {
        doReturn(null).when(migClientRepository).findByGwClientIdAndStatus(Mockito.anyString(),Mockito.anyString());
        Exception exception = assertThrows(ServiceException.class, () -> {
            clientService.inactiveAndDeleteClient("GWclnt1234", "test");
        });
    }

    @Test
    public void test_inactiveAndDeleteClient_InActiveClientResponse404() throws Exception {
        MigClient mg = new MigClient();
        doReturn(mg).when(migClientRepository).findByGwClientIdAndStatus(Mockito.anyString(),Mockito.anyString());
        doReturn(mg).when(migClientRepository).save(Mockito.any());
        InActiveClientResponse inActiveClientResponse = new InActiveClientResponse();
        inActiveClientResponse.setStatusCode(404);
        doReturn(inActiveClientResponse).when(clientExtensionService).inActiveClient(Mockito.anyString(),Mockito.anyString());

        DeleteClientResponse deleteClientResponse = clientService.inactiveAndDeleteClient("GWclnt1234", "test");
        assertEquals(deleteClientResponse.getStatus(),MigrationConstants.STATUS_FAILURE);

    }

    @Test
    public void test_inactiveAndDeleteClient_InActiveClientResponse204() throws Exception {
        MigClient mg = new MigClient();
        doReturn(mg).when(migClientRepository).findByGwClientIdAndStatus(Mockito.anyString(),Mockito.anyString());
        doReturn(mg).when(migClientRepository).save(Mockito.any());
        InActiveClientResponse inActiveClientResponse = new InActiveClientResponse();
        inActiveClientResponse.setStatusCode(204);
        doReturn(inActiveClientResponse).when(clientExtensionService).inActiveClient(Mockito.anyString(),Mockito.anyString());
        doNothing().when(clientExtensionService).deleteClient(Mockito.anyString());

        DeleteClientResponse deleteClientResponse = clientService.inactiveAndDeleteClient("GWclnt1234", "test");

        Assertions.assertEquals(MigrationConstants.STATUS_SUCCESS,deleteClientResponse.getStatus());

    }

    @Test
    public void test_inactiveAndDeleteClientDeleteClient400Exception() throws Exception {
        MigClient mg = new MigClient();
        doReturn(mg).when(migClientRepository).findByGwClientIdAndStatus(Mockito.anyString(),Mockito.anyString());
        doReturn(mg).when(migClientRepository).save(Mockito.any());
        InActiveClientResponse inActiveClientResponse = new InActiveClientResponse();
        inActiveClientResponse.setStatusCode(204);
        doReturn(inActiveClientResponse).when(clientExtensionService).inActiveClient(Mockito.anyString(),Mockito.anyString());
        doThrow(new ServiceException("400")).when(clientExtensionService).deleteClient(Mockito.anyString());

        DeleteClientResponse deleteClientResponse = clientService.inactiveAndDeleteClient("GWclnt1234", "test");

        Assertions.assertEquals(MigrationConstants.STATUS_SUCCESS,deleteClientResponse.getStatus());

    }

    @Test
    public void test_inactiveAndDeleteClientInActiveClient400Status() throws Exception {
        MigClient mg = new MigClient();
        doReturn(mg).when(migClientRepository).findByGwClientIdAndStatus(Mockito.anyString(),Mockito.anyString());
        doReturn(mg).when(migClientRepository).save(Mockito.any());
        doThrow(new ServiceException("400 Bad Request")).when(clientExtensionService).inActiveClient(Mockito.anyString(),Mockito.anyString());
        doThrow(new ServiceException("400")).when(clientExtensionService).deleteClient(Mockito.anyString());
        DeleteClientResponse deleteClientResponse = clientService.inactiveAndDeleteClient("GWclnt1234", "test");
        Assertions.assertEquals(MigrationConstants.STATUS_SUCCESS,deleteClientResponse.getStatus());
    }

    @Test
    public void test_inactiveAndDeleteClientInactiveClient500Status() throws Exception {
        MigClient mg = new MigClient();
        doReturn(mg).when(migClientRepository).findByGwClientIdAndStatus(Mockito.anyString(),Mockito.anyString());
        doReturn(mg).when(migClientRepository).save(Mockito.any());
        doThrow(new ServiceException("500")).when(clientExtensionService).inActiveClient(Mockito.anyString(),Mockito.anyString());
        doThrow(new ServiceException("400")).when(clientExtensionService).deleteClient(Mockito.anyString());
        DeleteClientResponse deleteClientResponse = clientService.inactiveAndDeleteClient("GWclnt1234", "test");
        Assertions.assertEquals(STATUS_FAILURE,deleteClientResponse.getStatus());
    }

    @Test
    public void test_inactiveAndDeleteClientDeleteClientWithNullClientId() throws Exception {
        MigClient mg = new MigClient();
        doReturn(mg).when(migClientRepository).findByGwClientIdAndStatus(Mockito.anyString(),Mockito.anyString());
        doReturn(mg).when(migClientRepository).save(Mockito.any());
        InActiveClientResponse inActiveClientResponse = new InActiveClientResponse();
        inActiveClientResponse.setStatusCode(204);
        doReturn(inActiveClientResponse).when(clientExtensionService).inActiveClient(Mockito.anyString(),Mockito.anyString());
        doThrow(new ServiceException("400")).when(clientExtensionService).deleteClient(Mockito.anyString());
        Assertions.assertThrows(ServiceException.class, () -> {
            DeleteClientResponse deleteClientResponse = clientService.inactiveAndDeleteClient(null, "test");
        });
    }

    @Test
    public void test_inactiveAndDeleteClientDeleteClient503Status() throws Exception {
        MigClient mg = new MigClient();
        doReturn(mg).when(migClientRepository).findByGwClientIdAndStatus(Mockito.anyString(),Mockito.anyString());
        doReturn(mg).when(migClientRepository).save(Mockito.any());
        InActiveClientResponse inActiveClientResponse = new InActiveClientResponse();
        inActiveClientResponse.setStatusCode(204);
        doReturn(inActiveClientResponse).when(clientExtensionService).inActiveClient(Mockito.anyString(),Mockito.anyString());
        doThrow(new ServiceException("503")).when(clientExtensionService).deleteClient(Mockito.anyString());
        DeleteClientResponse deleteClientResponse = clientService.inactiveAndDeleteClient("GWclnt1234", "test");
        Assertions.assertEquals(STATUS_SUCCESS,deleteClientResponse.getStatus());
    }

    @Test
    public void test_inactiveAndDeleteClient_DeleteClientCallReturn404Exception() throws Exception {
        MigClient mg = new MigClient();
        doReturn(mg).when(migClientRepository).findByGwClientIdAndStatus(Mockito.anyString(),Mockito.anyString());
        doReturn(mg).when(migClientRepository).save(Mockito.any());
        InActiveClientResponse inActiveClientResponse = new InActiveClientResponse();
        inActiveClientResponse.setStatusCode(204);
        doReturn(inActiveClientResponse).when(clientExtensionService).inActiveClient(Mockito.anyString(),Mockito.anyString());
        doThrow(new ServiceException("404")).when(clientExtensionService).deleteClient(Mockito.anyString());
        Assertions.assertThrows(ServiceException.class, ()->{
            DeleteClientResponse deleteClientResponse = clientService.inactiveAndDeleteClient("GWclnt1234", "test");
        });
    }



    @Test
    public void test_processPartnerRegistrationStatus_null() throws ServiceException, InterruptedException {
        MigClient mg = new MigClient();
        mg.setGwClientId("GWa1234");
        MigUser migUser=new MigUser();
        migUser.setGwUuid("1234");
        migUser.setComments(UserConstants.PRIMARY_USER_SUCCESS);
        migUser.setIsPrimaryUser(1);
        List<MigUser> migratedUsers=new ArrayList<>();

        when(migClientRepository.findByEcClientIdSuccess(any())).thenReturn(null);

        boolean isRegistered=partnerService.processPartnerRegistrationStatus("ecclientid", 100L);
        Assert.assertEquals(false, isRegistered);
    }

    @Test
    public void test_processPartnerRegistrationStatus_null_2() {
        MigClient mg = new MigClient();
        mg.setGwClientId("GWa1234");
        MigUser migUser=new MigUser();
        migUser.setGwUuid("1234");
        migUser.setComments(UserConstants.PRIMARY_USER_SUCCESS);
        migUser.setIsPrimaryUser(1);
        List<MigUser> migratedUsers=new ArrayList<>();

        try {
            migratedUsers.add(migUser);
            when(migUserRepository.getMigratedPrimaryUser(any())).thenReturn(migUser);
            when(clientExtensionService.getPartnerClient(any())).thenReturn(null);
            when(clientExtensionService.registerClientPartner(any())).thenReturn(true);
            when(clientExtensionService.registerPrimaryUserPartner(any(), any())).thenReturn(true);
            when(clientExtensionService.getPartnerUsers(any())).thenReturn(getBdcUser());
            when(migClientRepository.findByEcClientIdSuccess(any())).thenReturn(mg);
            when(migUserRepository.findByJobId(any())).thenReturn(migratedUsers);

            boolean isRegistered=partnerService.processPartnerRegistrationStatus("ecclientid", 100L);
            Assert.assertEquals(false, isRegistered);
        }catch (ServiceException | InterruptedException se){
            fail();
        }
    }

    @Test
    public void test_processPartnerRegistrationStatus_WhenNOTRegistered() {
        MigClient mg = new MigClient();
        mg.setGwClientId("GWa1234");

        MigUser migUser=new MigUser();
        migUser.setGwUuid("1234");

        try {
            when(migUserRepository.getMigratedPrimaryUser(any())).thenReturn(migUser);
            when(clientExtensionService.getPartnerClient(any())).thenReturn(new PartnerClient());
            when(clientExtensionService.registerClientPartner(any())).thenReturn(true);
            when(clientExtensionService.registerPrimaryUserPartner(any(), any())).thenReturn(true);
            when(clientExtensionService.getPartnerUsers(any())).thenReturn(getBdcUser());
            when(migClientRepository.findByEcClientIdSuccess(any())).thenReturn(mg);

            boolean isRegistered=partnerService.processPartnerRegistrationStatus("ecclientId", 100L);
            Assert.assertEquals(false, isRegistered);
        }catch (ServiceException | InterruptedException se){
            fail();
        }
    }


    private PartnerUser getBdcUser() {

        List<Partners> partnerList=new ArrayList<>();
        Partners partner=new Partners();
        partner.setPartnerName(BDC_NAME);
        PartnerTasks partnerTasks=new PartnerTasks();
        partnerTasks.setPartnerTaskName("Bill.com User Enrollment");
        partnerTasks.setPartnerTaskStatus("completed");
        List<PartnerTasks> partnerTaskList=new ArrayList<>();
        partnerTaskList.add(partnerTasks);

        partner.setPartnerTasks(partnerTaskList);

        partnerList.add(partner);

        Users user=new Users();
        user.setIdStoreuserkey("1234");
        user.setPartners(partnerList);

        PartnerUser partnerUser =new PartnerUser();
        List<Users> list=new ArrayList<>();
        list.add(user);
        partnerUser.setUsers(list);
        return partnerUser;
    }

    private PartnerClient getBdcClient() {
        ClientPartners clientPartners=new ClientPartners();
        clientPartners.setPartnerName(BDC_NAME);
        clientPartners.setPartnerStatus(MigrationConstants.PARTNER_COMPLETED_STATUS);
        List<ClientPartners> partners=new ArrayList<>();
        partners.add(clientPartners);

        PartnerClient partnerClient =new PartnerClient();
        partnerClient.setClientPartners(partners);
        return partnerClient;
    }

    @Test
    public void getCientsByJobId() {
        List<MigClient> list = Collections.emptyList();
        when(migClientRepository.getAllByJobIdAndStatus(anyLong())).thenReturn(list);
        Assertions.assertNotNull(clientService.getMigClientsByJobId(1256));
    }

    @Test
    public void getCientsByClientIds() {
        List<MigClient> list = Collections.emptyList();
        when(migClientRepository.getAllByEcClientIdInAndStatus(any())).thenReturn(list);
        Assertions.assertNotNull(clientService.getMigClientsByClientIds(Collections.emptyList()));
    }

    private List<StgClientApprovalSettings> getClientApprovalsettings(){
        List<StgClientApprovalSettings> stgClientApprovalSettingsList=new ArrayList<>();
        StgClientApprovalSettings stgClientApprovalSettings=new StgClientApprovalSettings();
        stgClientApprovalSettings.setEcClientId("data1234");
        stgClientApprovalSettings.setAccountNumber("123456789");
        stgClientApprovalSettings.setJobId("123");
        stgClientApprovalSettings.setIpayApprovalRequired("Y");
        stgClientApprovalSettings.setIpayDualAuthentication("YES");
        stgClientApprovalSettings.setTemplateApproveLvl1Required(1);
        stgClientApprovalSettings.setTemplateApproveLvl2Required(1);
        stgClientApprovalSettings.setWireApproveLvl1Required(1);
        stgClientApprovalSettings.setWireApproveLvl2Required(1);
        stgClientApprovalSettings.setTmplWireApprove1Required(1);
        stgClientApprovalSettings.setTmplWireApprove2Required(1);
        stgClientApprovalSettingsList.add(stgClientApprovalSettings);

        return stgClientApprovalSettingsList;
    }

    @Test
    public void updateRollbackFailure() {
        clientService.updateRollbackFailure(null, Message.create(), new MigClient());
    }

    @Test
    public void updateRollbackFailureNotNull() {
        clientService.updateRollbackFailure("test", Message.create(), new MigClient());
    }

    @Test
    public void testStatusString_Returns_YES(){
        MigClient client=new MigClient();
        client.setBdcStatus(1);
        client.setRdmStatus(1);

        Assert.assertEquals(YES, client.bdcStatusAsString());
        Assert.assertEquals(YES, client.rdmStatusAsString());
    }

    @Test
    public void testStatusString_Returns_NO(){
        MigClient client=new MigClient();
        client.setBdcStatus(0);
        client.setRdmStatus(0);

        Assert.assertEquals(NO, client.bdcStatusAsString());
        Assert.assertEquals(NO, client.rdmStatusAsString());
    }
}

