package com.svb.gateway.migration.client.service;

import com.svb.gateway.migration.client.entity.MigClient;
import com.svb.gateway.migration.client.model.*;
import com.svb.gateway.migration.client.repository.MigClientRepository;
import com.svb.gateway.migration.common.constants.MigrationConstants;
import com.svb.gateway.migration.common.constants.UserConstants;
import com.svb.gateway.migration.common.exception.ServiceException;
import com.svb.gateway.migration.user.entity.MigUser;
import com.svb.gateway.migration.user.repository.MigUserRepository;

import org.junit.Assert;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.util.ArrayList;
import java.util.List;

import static com.svb.gateway.migration.common.constants.MigrationConstants.BDC_NAME;
import static com.svb.gateway.migration.common.constants.MigrationConstants.RDM_NAME;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@SpringBootTest
@ExtendWith(SpringExtension.class)
class PartnerServiceTest {

    @Mock
    MigClientRepository migClientRepository;

    @Mock
    MigUserRepository migUserRepository;


    @Mock
    ClientExtensionService clientExtensionService;


    @InjectMocks
    @Spy
    PartnerService partnerService;

    @Test
    public void name() {

    }

    @Test
    public void test_When_BDC_RDM_is_valid() {
        MigClient mg = new MigClient();
        mg.setGwClientId("GWa1234");
        MigUser migUser=new MigUser();
        migUser.setGwUuid("1234");
        migUser.setComments(UserConstants.PRIMARY_USER_SUCCESS);
        migUser.setIsPrimaryUser(1);
        List<MigUser> migratedUsers=new ArrayList<>();

        try {
            migratedUsers.add(migUser);
            when(migUserRepository.getMigratedPrimaryUser(any())).thenReturn(migUser);
            when(clientExtensionService.getPartnerClient(any())).thenReturn(getPartnerClient());
            when(clientExtensionService.registerClientPartner(any())).thenReturn(true);
            when(clientExtensionService.registerPrimaryUserPartner(any(), any())).thenReturn(true);
            when(clientExtensionService.getPartnerUsers(any())).thenReturn(getPartnerUser());
            when(migClientRepository.findByEcClientIdSuccess(any())).thenReturn(mg);
            when(migUserRepository.findByJobId(any())).thenReturn(migratedUsers);

            boolean isRegistered=partnerService.processPartnerRegistrationStatus("ecclientid", 100L);
            Assert.assertEquals(true, isRegistered);
        }catch (ServiceException | InterruptedException se){
            fail();
        }
    }

    @Test
    public void test_When_Client_notRegistered_firstTime() {
        MigClient mg = new MigClient();
        mg.setGwClientId("GWa1234");
        MigUser migUser=new MigUser();
        migUser.setGwUuid("1234");
        migUser.setComments(UserConstants.PRIMARY_USER_SUCCESS);
        migUser.setIsPrimaryUser(1);
        List<MigUser> migratedUsers=new ArrayList<>();

        try {
            migratedUsers.add(migUser);
            when(migUserRepository.getMigratedPrimaryUser(any())).thenReturn(migUser);
            when(clientExtensionService.getPartnerClient(any())).thenReturn(getPartnerClient());
            when(clientExtensionService.registerClientPartner(any())).thenReturn(false).thenReturn(true);

            when(clientExtensionService.registerPrimaryUserPartner(any(), any())).thenReturn(false).thenReturn(true);
            when(clientExtensionService.getPartnerUsers(any())).thenReturn(getPartnerUser());
            when(migClientRepository.findByEcClientIdSuccess(any())).thenReturn(mg);
            when(migUserRepository.findByJobId(any())).thenReturn(migratedUsers);

            boolean isRegistered=partnerService.processPartnerRegistrationStatus("ecclientid", 100L);
            Assert.assertEquals(true, isRegistered);
        }catch (ServiceException | InterruptedException se){
            fail();
        }
    }

    @Test
    public void test_when_migclient_is_null() throws ServiceException, InterruptedException {
        try {
            MigClient mg = new MigClient();
            when(migClientRepository.findByEcClientIdSuccess(any())).thenReturn(mg);
            boolean isRegistered = partnerService.processPartnerRegistrationStatus("ecclientid", 100L);
            Assert.assertFalse(isRegistered);
        }catch (ServiceException | InterruptedException se){
            fail();
        }
    }

    @Test
    public void test_When_BDC_RDM_is_invalid() {
        MigClient mg = new MigClient();
        mg.setGwClientId("GWa1234");
        MigUser migUser=new MigUser();
        migUser.setGwUuid("1234");
        migUser.setComments(UserConstants.PRIMARY_USER_SUCCESS);
        migUser.setIsPrimaryUser(1);
        List<MigUser> migratedUsers=new ArrayList<>();

        try {
            migratedUsers.add(migUser);
            when(migUserRepository.getMigratedPrimaryUser(any())).thenReturn(migUser);
            when(clientExtensionService.getPartnerClient(any())).thenReturn(getPartnerClient());
            when(clientExtensionService.registerClientPartner(any())).thenReturn(true);
            when(clientExtensionService.registerPrimaryUserPartner(any(), any())).thenReturn(true);
            when(clientExtensionService.getPartnerUsers(any())).thenReturn(getBdcUserOnly());
            when(migClientRepository.findByEcClientIdSuccess(any())).thenReturn(mg);
            when(migUserRepository.findByJobId(any())).thenReturn(migratedUsers);

            boolean isRegistered=partnerService.processPartnerRegistrationStatus("ecclientid", 100L);
            Assert.assertFalse( isRegistered);
        }catch (ServiceException | InterruptedException se){
            fail();
        }
    }

    private PartnerUser getBdcUserOnly() {
        List<Partners> partnerList=new ArrayList<>();
        Partners bdcPartner=new Partners();
        bdcPartner.setPartnerName(BDC_NAME);
        PartnerTasks partnerTasks=new PartnerTasks();
        partnerTasks.setPartnerTaskName("Bill.com User Enrollment");
        partnerTasks.setPartnerTaskStatus("completed");
        List<PartnerTasks> partnerTaskList=new ArrayList<>();
        partnerTaskList.add(partnerTasks);

        bdcPartner.setPartnerTasks(partnerTaskList);

        partnerList.add(bdcPartner);

        Users bdcUser=new Users();
        bdcUser.setIdStoreuserkey("1234");
        bdcUser.setPartners(partnerList);


        PartnerUser partnerUser =new PartnerUser();
        List<Users> list=new ArrayList<>();
        list.add(bdcUser);
        partnerUser.setUsers(list);
        return partnerUser;
    }

    private PartnerUser getPartnerUser() {
        List<Partners> partnerList=new ArrayList<>();
        Partners bdcPartner=new Partners();
        bdcPartner.setPartnerName(BDC_NAME);
        PartnerTasks partnerTasks=new PartnerTasks();
        partnerTasks.setPartnerTaskName("Bill.com User Enrollment");
        partnerTasks.setPartnerTaskStatus("completed");
        List<PartnerTasks> partnerTaskList=new ArrayList<>();
        partnerTaskList.add(partnerTasks);

        bdcPartner.setPartnerTasks(partnerTaskList);

        partnerList.add(bdcPartner);

        Partners rdmPartner=new Partners();
        rdmPartner.setPartnerName(RDM_NAME);
        PartnerTasks rdmPartnerTasks=new PartnerTasks();
        rdmPartnerTasks.setPartnerTaskName("RDM Deluxe");
        rdmPartnerTasks.setPartnerTaskStatus("completed");
        List<PartnerTasks> rdmPartnerTaskList=new ArrayList<>();
        rdmPartnerTaskList.add(rdmPartnerTasks);

        rdmPartner.setPartnerTasks(rdmPartnerTaskList);

        partnerList.add(bdcPartner);
        partnerList.add(rdmPartner);

        Users bdcUser=new Users();
        bdcUser.setIdStoreuserkey("1234");
        bdcUser.setPartners(partnerList);

        Users rdmUser=new Users();
        rdmUser.setIdStoreuserkey("5678");
        rdmUser.setPartners(partnerList);

        PartnerUser partnerUser =new PartnerUser();
        List<Users> list=new ArrayList<>();
        list.add(bdcUser);
        list.add(rdmUser);
        partnerUser.setUsers(list);
        return partnerUser;
    }

    private PartnerClient getPartnerClient() {
        ClientPartners bdcPartners=new ClientPartners();
        bdcPartners.setPartnerName(BDC_NAME);
        bdcPartners.setPartnerStatus(MigrationConstants.PARTNER_COMPLETED_STATUS);

        ClientPartners rdmPartners=new ClientPartners();
        rdmPartners.setPartnerName(RDM_NAME);
        rdmPartners.setPartnerStatus(MigrationConstants.PARTNER_COMPLETED_STATUS);

        List<ClientPartners> partners=new ArrayList<>();
        partners.add(bdcPartners);
        partners.add(rdmPartners);

        PartnerClient partnerClient =new PartnerClient();
        partnerClient.setClientPartners(partners);
        return partnerClient;
    }

}
