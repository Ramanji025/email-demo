package com.svb.gateway.migration.common;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class DataProvider {

    public static final String DATA_TRANSACTION = "{\n" +
            "  \"maskedAccNum\": null,\n" +
            "  \"batchNum\": null,\n" +
            "  \"id\": null,\n" +
            "  \"applNum\": 20,\n" +
            "  \"applNumCode\": \"CAA\",\n" +
            "  \"accountInfoSourceId\": 1,\n" +
            "  \"accountInfoSourceDesc\": \"SVB DDA\",\n" +
            "  \"accountTitle\": \"Analysis Checking\",\n" +
            "  \"prodType\": 11,\n" +
            "  \"prodTypeDesc\": \"Analysis Checking\",\n" +
            "  \"businessUnit\": \"SB0\",\n" +
            "  \"bankId\": \"SVB\",\n" +
            "  \"currency\": \"USD\",\n" +
            "  \"runNumber\": \"0\",\n" +
            "  \"runningBalance\": 0,\n" +
            "  \"runningBalanceStr\": \"0.0\",\n" +
            "  \"transStatusCode\": \"POS\",\n" +
            "  \"transStatusDescription\": \"POSTED\",\n" +
            "  \"sortCode\": \"0\",\n" +
            "  \"rvslFlag\": \" \",\n" +
            "  \"timeOfDay\": null,\n" +
            "  \"tranDetails\": null,\n" +
            "  \"accountId\": \"3302285274\",\n" +
            "  \"transactionDate\": \"2019-01-30 08:00:00\",\n" +
            "  \"transactionDate_TS\": 1548835200000,\n" +
            "  \"transactionId\": 228,\n" +
            "  \"amountCode\": \"05\",\n" +
            "  \"amtCodeDescription\": \"DEBIT\",\n" +
            "  \"transactionAmount\": 2869.78,\n" +
            "  \"transactionAmountStr\": \"2869.78\",\n" +
            "  \"transactionRemarks\": null,\n" +
            "  \"transactionRemarks_UI\": null,\n" +
            "  \"instrumentId\": \"0\",\n" +
            "  \"instrumentIdNum\": 0,\n" +
            "  \"transactionTypeCode\": 58,\n" +
            "  \"transactionTypeDesc\": \"ACH DEBIT           \",\n" +
            "  \"bankReferenceNumber\": \"2280\",\n" +
            "  \"balanceOfPosting\": null,\n" +
            "  \"transactionGrp\": \"ACH\",\n" +
            "  \"tranQuarter\": \"2019-1\"\n" +
            "}";
    public static final String DATA_TRANSACTION2 = "{\n" +
            "  \"maskedAccNum\": null,\n" +
            "  \"batchNum\": null,\n" +
            "  \"id\": null,\n" +
            "  \"applNum\": 20,\n" +
            "  \"applNumCode\": \"CAA\",\n" +
            "  \"accountInfoSourceId\": 1,\n" +
            "  \"accountInfoSourceDesc\": \"SVB DDA\",\n" +
            "  \"accountTitle\": \"Analysis Checking\",\n" +
            "  \"prodType\": 11,\n" +
            "  \"prodTypeDesc\": \"Analysis Checking\",\n" +
            "  \"businessUnit\": \"SB0\",\n" +
            "  \"bankId\": \"SVB\",\n" +
            "  \"currency\": \"USD\",\n" +
            "  \"runNumber\": \"0\",\n" +
            "  \"runningBalance\": 0,\n" +
            "  \"runningBalanceStr\": \"0.0\",\n" +
            "  \"transStatusCode\": \"POS\",\n" +
            "  \"transStatusDescription\": \"POSTED\",\n" +
            "  \"sortCode\": \"0\",\n" +
            "  \"rvslFlag\": \" \",\n" +
            "  \"timeOfDay\": null,\n" +
            "  \"tranDetails\": {\"1458\":\"55.25\",\"1458\":\"55.25\",\"1458\":\"55.25\",\"1458\":\"55.25\",\"1458\":\"55.25\"},\n" +
            "  \"accountId\": \"154\",\n" +
            "  \"transactionDate\": \"2019-01-30 08:00:00\",\n" +
            "  \"transactionDate_TS\": 1548835200000,\n" +
            "  \"transactionId\": 228,\n" +
            "  \"amountCode\": \"05\",\n" +
            "  \"amtCodeDescription\": \"DEBIT\",\n" +
            "  \"transactionAmount\": 2869.78,\n" +
            "  \"transactionAmountStr\": \"2869.78\",\n" +
            "  \"transactionRemarks\": null,\n" +
            "  \"transactionRemarks_UI\": null,\n" +
            "  \"instrumentId\": \"0\",\n" +
            "  \"instrumentIdNum\": 0,\n" +
            "  \"transactionTypeCode\": 58,\n" +
            "  \"transactionTypeDesc\": \"ACH DEBIT           \",\n" +
            "  \"bankReferenceNumber\": \"2280\",\n" +
            "  \"balanceOfPosting\": null,\n" +
            "  \"transactionGrp\": \"ACH\",\n" +
            "  \"tranQuarter\": \"2019-1\"\n" +
            "}";

    public static <T> Object getGenericObject(final String data, Class<T> type) throws JsonProcessingException {
        ObjectMapper mapper = new ObjectMapper();
        return mapper.readValue(data, type);
    }


}
