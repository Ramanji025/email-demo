package com.svb.gateway.migration.common.logging;

import com.svb.gateway.migration.common.exception.ServiceException;
import com.svb.gateway.migration.common.utility.MigrationErrorCodeEnum;
import lombok.extern.log4j.Log4j2;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.io.IOException;

import static com.svb.gateway.migration.common.constants.MigrationConstants.STATUS_SUCCESS;
import static junit.framework.TestCase.assertEquals;
import static junit.framework.TestCase.assertTrue;
import static com.svb.gateway.migration.common.logging.Message.*;

@Log4j2
@SpringBootTest
@ExtendWith(SpringExtension.class)
public class LoggingTest {

    @Test
    public void testSampleMessage()  {
        String message = Message.create().descr("TESTING LOGGING").targetId("asdfasdfas").jobId(123L).jobType(JobType.load).srcType(SourceType.eConnect).entityName(Entity.beneficiary).srcId("0001").operation("load").clientId("abcd1234").status(STATUS_SUCCESS).toString();
        assertEquals("op=load descr=[TESTING LOGGING] jobType=load jobId=123 clientId=abcd1234 name=beneficiary srcType=eConnect srcId=0001 targetId=asdfasdfas status=SUCCESS", message);
    }

    @Test
    public void testSampleMessageWithDuplicates()  {
        String message = Message.create().descr("TESTING LOGGING").targetId("asdfasdfas").targetId("asdfasdfas").jobId(456L).jobId(123L).operation("bene").clientId("abcd1234").status(STATUS_SUCCESS).toString();
        assertEquals("op=bene descr=[TESTING LOGGING] jobId=123 clientId=abcd1234 targetId=asdfasdfas status=SUCCESS", message);
    }

    @Test
    public void testSampleMessageIsReordered()  {
        String message = Message.create().targetId("asdfasdfas").targetId("asdfasdfas").jobId(456L).operation("bene").clientId("abcd1234").jobId(123L).status(STATUS_SUCCESS).descr("TESTING LOGGING").toString();
        assertEquals("op=bene descr=[TESTING LOGGING] jobId=123 clientId=abcd1234 targetId=asdfasdfas status=SUCCESS", message);
    }

    @Test
    public void testSummary()  {
        Message message = Message.create().summary().descr("TESTING LOGGING").targetId("asdfasdfas").jobId(123L).jobType(JobType.load).srcType(SourceType.eConnect).entityName(Entity.beneficiary).srcId("0001").operation("load").clientId("abcd1234").status(STATUS_SUCCESS);
        String firstTime = message.toString();
        assertEquals("op=load descr=[TESTING LOGGING] jobType=load jobId=123 clientId=abcd1234 name=beneficiary srcType=eConnect srcId=0001 targetId=asdfasdfas status=SUCCESS summary", firstTime);
        String secondTime = message.toString();
        assertEquals("op=load descr=[TESTING LOGGING] jobType=load jobId=123 clientId=abcd1234 name=beneficiary srcType=eConnect srcId=0001 targetId=asdfasdfas status=SUCCESS", secondTime);
    }

    @Test
    public void testNull()  {
        String message = Message.create().descr(null).toString();
        assertEquals("descr=null", message);
    }

    @Test
    public void testExceptionToString()  {
        try{
            try {
                throw new IOException("connection issue");
            }
            catch(IOException e){
                throw new ServiceException(MigrationErrorCodeEnum.MIGRATION_UNEXPECTED_ERROR, e);
            }
        }
        catch(ServiceException s){
            assertTrue(s.getMessage().contains("java.io.IOException: connection issue"));
        }
    }

    @Test
    public void testLog() {
        log.info(Message.create().descr("TESTING LOGGING").targetId("asdfasdfas").jobId(123L).jobType(JobType.load).srcType(SourceType.eConnect).entityName(Entity.beneficiary).srcId("0001").operation("load").clientId("abcd1234").status(STATUS_SUCCESS));
    }
}

