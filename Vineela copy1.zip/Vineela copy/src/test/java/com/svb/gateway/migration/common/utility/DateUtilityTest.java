package com.svb.gateway.migration.common.utility;

import org.junit.Assert;
import org.junit.jupiter.api.Test;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.Date;

import static org.junit.jupiter.api.Assertions.*;

class DateUtilityTest {

    @Test
    void getRecurringByEndDateAndFrequency_Weeks_ReturnAsExpected() {
        LocalDate endDate =LocalDate.now().plusWeeks(4);
        int result= DateUtility.getRecurringByEndDateAndFrequency(LocalDate.now(),endDate, 'W');
        Assert.assertEquals(4, result);
    }

    @Test
    void getRecurringByEndDateAndFrequency_BiWeekly_ReturnAsExpected() {
        LocalDate endDate =LocalDate.now().plusMonths(6);
        int result= DateUtility.getRecurringByEndDateAndFrequency(LocalDate.now(),endDate, 'B');
        Assert.assertTrue(result >= 12);
    }

    @Test
    void getRecurringByEndDateAndFrequency_Quarterly_ReturnAsExpected() {
        LocalDate endDate =LocalDate.now().plusMonths(6);
        int result= DateUtility.getRecurringByEndDateAndFrequency(LocalDate.now().plusDays(-1),endDate, 'Q');
        Assert.assertEquals(2, result);
    }

    @Test
    void getRecurringByEndDateAndFrequency_Month_ReturnAsExpected() {
        LocalDate endDate =LocalDate.now().plusMonths(14);
        int result= DateUtility.getRecurringByEndDateAndFrequency(LocalDate.now(),endDate, 'M');
        Assert.assertEquals(14, result);
    }

    @Test
    void getRecurringByEndDateAndFrequency_BiMonth_ReturnAsExpected() {
        LocalDate endDate =LocalDate.now().plusMonths(6);
        int result= DateUtility.getRecurringByEndDateAndFrequency(LocalDate.now().plusDays(-1),endDate, 'T');
        Assert.assertEquals(3, result);
    }

    @Test
    void getTransferOCHDateFormat_whenPDT() throws ParseException{
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        Date endDate = sdf.parse("2021-10-01 00:00:00.0");
        String formattedDate= DateUtility.getTranDateInOchFormat(endDate);
        Assert.assertEquals("2021-10-01T07:00:00",formattedDate);
    }

    @Test
    void getTransferOCHDateFormat_whenPST()throws ParseException {

        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        Date endDate = sdf.parse("2021-12-01 00:00:00.0");
        String formattedDate= DateUtility.getTranDateInOchFormat(endDate);
        Assert.assertEquals("2021-12-01T08:00:00",formattedDate);
    }
}
