package com.svb.gateway.migration.ec2stage.dao;

import com.svb.gateway.migration.common.exception.ServiceException;
import com.svb.gateway.migration.ec2stage.model.ClientDetail;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.doReturn;

@SpringBootTest
@ExtendWith(SpringExtension.class)
class ECDaoTest {

    @Mock
    JdbcTemplate eConnectJdbcTemplate;

    @Test
    public void test_getECMigrationStatus() {
        List<String> clientIds = new ArrayList<String>(Arrays.asList("acb12345", "def45678"));

        ClientDetail clientDetail = new ClientDetail();
        clientDetail.setMigrationStatus(2);
        clientDetail.setClientLoginName("acb12345");
        List<ClientDetail> clientDetails = new ArrayList<>();
        clientDetails.add(clientDetail);

        doReturn(clientDetails).when(eConnectJdbcTemplate).query(anyString(), any(ECDao.ClientDetailsRowMapper.class));

        assertEquals(1, clientDetails.size());
    }
}