package com.svb.gateway.migration.ec2stage.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.svb.gateway.migration.common.exception.ServiceException;
import com.svb.gateway.migration.ec2stage.dao.ECDao;
import com.svb.gateway.migration.ec2stage.model.ClientDetail;
import com.svb.gateway.migration.rollback.model.RollBackResponse;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.Spy;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.client.RestTemplate;

import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doReturn;

@SpringBootTest
@ExtendWith(SpringExtension.class)
class ECServiceTest {

    @Mock
    RestTemplate restTemplate;

    @InjectMocks
    @Spy
    ECService ecService;

    @Mock
    ECDao ecDao;

    public static final String ERROR_IN_UPDATING_THE_CLIENT_STATUS_IN_E_C = "Error in updating the client status in eC";

    @Value("${ec.updateStatus.url}")
    String ecClientUrl;

    @Test
    public void test_eCUpdateStatusAPI() throws ServiceException, JsonProcessingException {
        List<String> clientIds = new ArrayList<String>(Arrays.asList("acb12345", "def45678"));
        Map<String, Object> response = new HashMap<>();
        Map<String, Object> data = new HashMap<>();
        data.put("statusCode", 17000);
        data.put("statusMessage", "Status updated successfully for 1 client(s)");
        response.put("data", data);
        ResponseEntity<Object> responseObject = new ResponseEntity<>(response, HttpStatus.OK);

        doReturn(responseObject).when(restTemplate).exchange(Mockito.anyString(), Mockito.any(HttpMethod.class), Mockito.any(HttpEntity.class), eq(Object.class));
        ecService.updateClientDetailsEc(clientIds, "N", "N");
        assertTrue(true);
    }

    @Test
    public void test_eCUpdateStatusAPI_error() throws ServiceException, JsonProcessingException {
        List<String> clientIds = new ArrayList<String>(Arrays.asList("acb12345", "def45678"));
        Map<String, Object> response = new HashMap<>();
        response.put("messages", new HashMap<>());
        ResponseEntity<Object> responseObject = new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);

        doReturn(responseObject).when(restTemplate).exchange(Mockito.anyString(), Mockito.any(HttpMethod.class), Mockito.any(HttpEntity.class), eq(Object.class));

            String ecResponse=ecService.updateClientDetailsEc(clientIds,  "N", "N");
            assertEquals(ecResponse, ERROR_IN_UPDATING_THE_CLIENT_STATUS_IN_E_C);

    }

    @Test
    public void test_eCECStatusValidation_no_clients() {
        List<String> clientIds = new ArrayList<String>(Arrays.asList("acb12345", "def45678"));
        doReturn(new ArrayList<>()).when(ecDao).getECMigrationStatus(anyList());
        List<String> clientLoginNames = ecService.validateECMigrationStatus(clientIds);
        assertEquals(0, clientLoginNames.size());
    }

    @BeforeEach
    public void before() {
        ReflectionTestUtils.setField(ecService, "ecClientUrl", "test");
        ReflectionTestUtils.setField(ecService, "enableECValidation", true);
    }
}