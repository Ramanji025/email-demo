package com.svb.gateway.migration.healthcheck.controller;

import com.svb.gateway.migration.healthcheck.model.HealthCheckResponse;
import com.svb.gateway.migration.healthcheck.service.HealthCheckService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@AutoConfigureMockMvc
public class HealthCheckControllerTest {

    @Autowired
    private MockMvc mockMvc;


    @MockBean
    private HealthCheckService healthCheckService;

    private HealthCheckResponse healthCheckResponse=new HealthCheckResponse();

    @BeforeEach
    public void setup() throws Exception {
        Mockito.when(healthCheckService.preValidate()).
                thenReturn(healthCheckResponse);
    }

    @Test
    public void health_resp() throws Exception {
        this.mockMvc.perform(get("/v1/api/health")
                .contentType(MediaType.APPLICATION_JSON_VALUE)
                .header("Authorization","Basic Y3JtdXNlcjI6QWNjZXNzMTIz"))
                .andExpect(status().isOk());
    }
}
