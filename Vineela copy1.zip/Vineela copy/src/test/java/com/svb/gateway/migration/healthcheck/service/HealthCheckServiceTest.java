package com.svb.gateway.migration.healthcheck.service;

import com.svb.gateway.migration.beneficiaries.model.BankBranchResponse;
import com.svb.gateway.migration.beneficiaries.model.IbanCountryRulesResponse;
import com.svb.gateway.migration.beneficiaries.service.BeneficiaryValidationUtility;
import com.svb.gateway.migration.client.model.Bundle;
import com.svb.gateway.migration.client.model.Bundles;
import com.svb.gateway.migration.client.service.ClientService;
import com.svb.gateway.migration.common.exception.ServiceException;
import com.svb.gateway.migration.common.model.AddressResponse;
import com.svb.gateway.migration.common.utility.AddressDoctor;
import com.svb.gateway.migration.common.utility.CacheManagerUtility;
import com.svb.gateway.migration.healthcheck.model.HealthCheckResponse;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.util.ArrayList;
import java.util.List;

import static junit.framework.TestCase.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.doThrow;

@Slf4j
@SpringBootTest
@ExtendWith(SpringExtension.class)
public class HealthCheckServiceTest {

    @InjectMocks
    @Spy
    HealthCheckService healthCheckService;

    @Mock
    private BeneficiaryValidationUtility beneficiaryValidationUtility;

    @Mock
    private ClientService clientService;

    @Mock
    private AddressDoctor addressDoctor;

    @Mock
    private CacheManagerUtility cacheManagerUtility;

    String oAuth="";
    BankBranchResponse bankBranchResponse=new BankBranchResponse();
    Bundles bundles=new Bundles();
    Bundle bundle=new Bundle();
    List<Bundle> bundleList=new ArrayList<>();
    AddressResponse addressResponse=new AddressResponse();
    IbanCountryRulesResponse ibanCountryRulesResponse=new IbanCountryRulesResponse();

    @BeforeEach
    void setUpSuccessResponse(){
        oAuth="efb1f6da513f7a927faf52cf14c0306a667f0f513b62c1b344cbb572233223b3";
        bankBranchResponse.setValidated(true);
        bundle.setDigitalBundleId(9001);
        bundleList.add(bundle);
        bundles.setDigitalBundles(bundleList);
        addressResponse.setValidationscore("c4");
        ibanCountryRulesResponse.setValidated(true);
    }

    @Test
    void healthCheckSuccess() throws ServiceException {

        doReturn(oAuth).when(cacheManagerUtility).getOauthToken();
        doReturn(bankBranchResponse).when(beneficiaryValidationUtility).validateBankBranchAndFetchList(any());
        doReturn(addressResponse).when(addressDoctor).validateAddress(any(),any(),any());
        doReturn(bundles).when(clientService).getBundles(any(),any(),any());
        doReturn(ibanCountryRulesResponse).when(beneficiaryValidationUtility).validateIbanCountrySpecificRulesAndValidation(any(),any(),any(),any());
        HealthCheckResponse healthCheckResponse=healthCheckService.preValidate();
        assertTrue(healthCheckResponse.getStatus().equalsIgnoreCase("SUCCESS"));
    }

    @Test
    void healthCheckException() throws ServiceException {

        doThrow(new ServiceException("Service unavailable")).when(cacheManagerUtility).getOauthToken();
        HealthCheckResponse healthCheckResponse=healthCheckService.preValidate();
        assertTrue(healthCheckResponse.getStatus().equalsIgnoreCase("FAILURE"));
    }


    @Test
    void healthCheckFailure_addressDoctor() throws ServiceException {

        doReturn(oAuth).when(cacheManagerUtility).getOauthToken();
        doReturn(bankBranchResponse).when(beneficiaryValidationUtility).validateBankBranchAndFetchList(any());
        doReturn(null).when(addressDoctor).validateAddress(any(),any(),any());
        doReturn(bundles).when(clientService).getBundles(any(),any(),any());
        doReturn(ibanCountryRulesResponse).when(beneficiaryValidationUtility).validateIbanCountrySpecificRulesAndValidation(any(),any(),any(),any());
        HealthCheckResponse healthCheckResponse=healthCheckService.preValidate();
        assertTrue(healthCheckResponse.getStatus().equalsIgnoreCase("FAILURE"));
    }

    @Test
    void healthCheckFailure_addressDoctorFailure() throws ServiceException {
        addressResponse.setValidationscore(null);
        addressResponse.setValidationdesc("Error during validation");
        doReturn(oAuth).when(cacheManagerUtility).getOauthToken();
        doReturn(bankBranchResponse).when(beneficiaryValidationUtility).validateBankBranchAndFetchList(any());
        doReturn(addressResponse).when(addressDoctor).validateAddress(any(),any(),any());
        doReturn(bundles).when(clientService).getBundles(any(),any(),any());
        doReturn(ibanCountryRulesResponse).when(beneficiaryValidationUtility).validateIbanCountrySpecificRulesAndValidation(any(),any(),any(),any());
        HealthCheckResponse healthCheckResponse=healthCheckService.preValidate();
        assertTrue(healthCheckResponse.getStatus().equalsIgnoreCase("FAILURE"));
    }

    @Test
    void healthCheckFailure_adminExt() throws ServiceException {

        doReturn(oAuth).when(cacheManagerUtility).getOauthToken();
        doReturn(bankBranchResponse).when(beneficiaryValidationUtility).validateBankBranchAndFetchList(any());
        doReturn(addressResponse).when(addressDoctor).validateAddress(any(),any(),any());
        doReturn(null).when(clientService).getBundles(any(),any(),any());
        doReturn(ibanCountryRulesResponse).when(beneficiaryValidationUtility).validateIbanCountrySpecificRulesAndValidation(any(),any(),any(),any());
        HealthCheckResponse healthCheckResponse=healthCheckService.preValidate();
        assertTrue(healthCheckResponse.getStatus().equalsIgnoreCase("FAILURE"));
    }

    @Test
    void healthCheckFailure_iBan() throws ServiceException {
        ibanCountryRulesResponse.setValidated(false);
        doReturn(oAuth).when(cacheManagerUtility).getOauthToken();
        doReturn(bankBranchResponse).when(beneficiaryValidationUtility).validateBankBranchAndFetchList(any());
        doReturn(addressResponse).when(addressDoctor).validateAddress(any(),any(),any());
        doReturn(bundles).when(clientService).getBundles(any(),any(),any());
        doReturn(ibanCountryRulesResponse).when(beneficiaryValidationUtility).validateIbanCountrySpecificRulesAndValidation(any(),any(),any(),any());
        HealthCheckResponse healthCheckResponse=healthCheckService.preValidate();
        assertTrue(healthCheckResponse.getStatus().equalsIgnoreCase("FAILURE"));
    }

    @Test
    void healthCheckFailure_bankBranch() throws ServiceException {
        bankBranchResponse.setValidated(false);
        doReturn(oAuth).when(cacheManagerUtility).getOauthToken();
        doReturn(bankBranchResponse).when(beneficiaryValidationUtility).validateBankBranchAndFetchList(any());
        doReturn(addressResponse).when(addressDoctor).validateAddress(any(),any(),any());
        doReturn(bundles).when(clientService).getBundles(any(),any(),any());
        doReturn(ibanCountryRulesResponse).when(beneficiaryValidationUtility).validateIbanCountrySpecificRulesAndValidation(any(),any(),any(),any());
        HealthCheckResponse healthCheckResponse=healthCheckService.preValidate();
        assertTrue(healthCheckResponse.getStatus().equalsIgnoreCase("FAILURE"));
    }
}
