package com.svb.gateway.migration.ipay.processor;

import com.svb.gateway.migration.common.DataProvider;
import com.svb.gateway.migration.ipay.batch.dto.IPayPayees;
import com.svb.gateway.migration.ipay.batch.processors.IPayPayeeProcessor;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import static org.junit.jupiter.api.Assertions.assertNotNull;

@SpringBootTest
@ExtendWith(SpringExtension.class)
public class IPayPayeesProcessorTest {

    private IPayPayeeProcessor payPayeeProcessor;

    static String data = "{\"subscriberId\":3696054,\"payeeRelationshipNumber\":\"32\",\"beneNickname\":\"**** Systems\"," +
            "\"beneAccount\":\"95400017188\",\"beneName\":\"**** SYSTEMS\",\"beneAddress1\":\" P.O. Box 363  Tunnel Hill\",\"beneAddress2\":\" Georgia\"," +
            "\"beneAddress3\":\"30755\",\"payeeCity\":null,\"payeeState\":null,\"payeeZipCode\":null,\"payeePhoneNum\":\"****08838\"," +
            "\"merchantCategory\":\"Individual\",\"merchantAccountType\":\"Checking\",\"electronicIndicator\":\"Y\"," +
            "\"createdBy\":\"MIGRATION_BANKUSER\",\"ecClientId\":\"acci4777\",\"beneBankIdentifier\":\"4058840\",\"jobId\":1611712575065}";
    static String data2 = "{\"subscriberId\":3696054,\"payeeRelationshipNumber\":\"32\",\"beneNickname\":\"**** Systems\"," +
            "\"beneAccount\":\"95400017188\",\"beneName\":\"****SYSTEMS\",\"beneAddress1\":\" P.O. Box 363  Tunnel Hill\",\"beneAddress2\":\" Georgia\"," +
            "\"beneAddress3\":null,\"payeeCity\":null,\"payeeState\":null,\"payeeZipCode\":\"30755\",\"payeePhoneNum\":\"****08838\"," +
            "\"merchantCategory\":\"Individual\",\"merchantAccountType\":\"Checking\",\"electronicIndicator\":\"Y\"," +
            "\"createdBy\":\"MIGRATION_BANKUSER\",\"ecClientId\":\"acci4778\",\"beneBankIdentifier\":\"4058840\",\"jobId\":1611712575065}";
    static String data3 = "{\"subscriberId\":3696054,\"payeeRelationshipNumber\":\"32\",\"beneNickname\":\"**** Systems\"," +
            "\"beneAccount\":\"95400017188\",\"beneName\":\"****SYSTEMS\",\"beneAddress1\":\" P.O. Box 363  Tunnel Hill\",\"beneAddress2\":\" Georgia\"," +
            "\"beneAddress3\":null,\"payeeCity\":\"Los Angel\",\"payeeState\":\"Arizona\",\"payeeZipCode\":\"30755\",\"payeePhoneNum\":\"****08838\"," +
            "\"merchantCategory\":\"Individual\",\"merchantAccountType\":\"Checking\",\"electronicIndicator\":\"Y\"," +
            "\"createdBy\":\"MIGRATION_BANKUSER\",\"ecClientId\":\"acci4778\",\"beneBankIdentifier\":\"4058840\",\"jobId\":1611712575065}";

    @BeforeEach
    public void beforeEach() {

        payPayeeProcessor = new IPayPayeeProcessor();
    }

    @Test
    public  void testProcessWithCreditTrnType()  throws Exception{

        IPayPayees dataProcessor = (IPayPayees) DataProvider.getGenericObject(data, IPayPayees.class);
        IPayPayees payees  = payPayeeProcessor.process(dataProcessor);
        assertNotNull(payees);
    }

    @Test
    public  void testProcessWithCreditTrnType2()  throws Exception{

        IPayPayees dataProcessor = (IPayPayees) DataProvider.getGenericObject(data2, IPayPayees.class);
        IPayPayees payees  = payPayeeProcessor.process(dataProcessor);
        assertNotNull(payees);
    }

    @Test
    public  void testProcessWithCityState()  throws Exception{

        IPayPayees dataProcessor = (IPayPayees) DataProvider.getGenericObject(data3, IPayPayees.class);
        IPayPayees payees  = payPayeeProcessor.process(dataProcessor);
        assertNotNull(payees);
    }


}
