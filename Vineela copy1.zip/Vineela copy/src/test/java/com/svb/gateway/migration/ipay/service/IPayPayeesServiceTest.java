package com.svb.gateway.migration.ipay.service;

import com.svb.gateway.migration.common.utility.MigrationQueries;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentMatchers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.batch.core.BatchStatus;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobParametersInvalidException;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.batch.core.repository.JobExecutionAlreadyRunningException;
import org.springframework.batch.core.repository.JobInstanceAlreadyCompleteException;
import org.springframework.batch.core.repository.JobRestartException;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.jdbc.core.JdbcTemplate;

import java.util.Date;

import static com.svb.gateway.migration.common.utility.MigrationQueries.TRUNCATE_I_PAY_SRC_TABLEQUERIES;
import static org.mockito.Mockito.*;

@SpringBootTest
@RunWith(MockitoJUnitRunner.class)
public class IPayPayeesServiceTest {

    @InjectMocks
    private IPayPayeesServiceImpl payPayeesService;
    @Mock
    private JobLauncher jobLauncher;

    @Mock
    private JdbcTemplate jdbcTemplate;

    @BeforeEach
    public void beforeTest() throws JobParametersInvalidException, JobExecutionAlreadyRunningException, JobRestartException, JobInstanceAlreadyCompleteException {
        Long jobid = new Date().getTime();
        JobExecution jobExecution =  new JobExecution(jobid);
        jobExecution.setStatus(BatchStatus.COMPLETED);
        Mockito.when(jobLauncher.run(ArgumentMatchers.any(), ArgumentMatchers.any())).thenReturn(jobExecution);
    }

    @Test
    public void launchJobIPay2Stage() throws Exception {
        Assertions.assertNotNull(payPayeesService
                .ipay2stageJobLauncher("TEST", 789L));
    }

    @Test
    public void cleanupSrcTables() throws Exception {
         payPayeesService
                .truncateIPaySrcTables();
         verify(jdbcTemplate, times(1)).batchUpdate(TRUNCATE_I_PAY_SRC_TABLEQUERIES);
    }

    @Test
    public void cleanupSrcTablesException() throws Exception {

        doThrow(new IllegalArgumentException()).when(jdbcTemplate).batchUpdate(String.valueOf(ArgumentMatchers.anyList()));
        payPayeesService
                .truncateIPaySrcTables();
        verify(jdbcTemplate, times(0)).batchUpdate(ArgumentMatchers.anyString());
    }
}
