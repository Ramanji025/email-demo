 package com.svb.gateway.migration.job.service;

import com.svb.gateway.migration.client.entity.StgClient;
import com.svb.gateway.migration.client.model.CompanyIdResponse;
import com.svb.gateway.migration.client.repository.ClientRepository;
import com.svb.gateway.migration.client.service.ClientExtensionService;
import com.svb.gateway.migration.common.exception.ServiceException;
import com.svb.gateway.migration.common.service.RetryService;
import com.svb.gateway.migration.common.utility.JobStatusEnum;
import com.svb.gateway.migration.ipay.service.IPayPayeesService;
import com.svb.gateway.migration.client.entity.MigClient;
import com.svb.gateway.migration.job.entity.JobEntity;
import com.svb.gateway.migration.job.mapper.ClientMapper;
import com.svb.gateway.migration.job.mapper.JobMapper;
import com.svb.gateway.migration.job.model.CreateJobResponse;
import com.svb.gateway.migration.job.model.CreateJobResponseData;
import com.svb.gateway.migration.client.repository.MigClientRepository;
import com.svb.gateway.migration.job.model.JobResponse;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.runner.RunWith;
import org.mockito.*;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.client.RestTemplate;
import java.time.OffsetDateTime;
import java.util.*;
import static com.svb.gateway.migration.common.utility.MigrationTypeEnum.CLIENT_MIGRATION;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;

@SpringBootTest
@ExtendWith(SpringExtension.class)
class JobServiceTest {
    @Mock
    private RetryService retryService;
    @Mock
    private RestTemplate restTemplate;
    @Mock
    private JobMapper jobMapper;
    @Mock
    private MigClientRepository clientRepository;
    @Mock
    private ClientRepository stgClientRepository;

    private List<MigClient> clientEntities;
    @Mock
    private ClientMapper clientMapper;
    @Mock
    private IPayPayeesService iPayPayeesService;
    @InjectMocks
    @Spy
    private JobService jobService;
    @BeforeEach
    public void before() {
        Mockito.when(jobMapper.insertJob(ArgumentMatchers.any())).thenReturn(1);
        Mockito.when(clientRepository.saveAll(ArgumentMatchers.anyCollection())).thenReturn(Collections.EMPTY_LIST);
        doNothing().when(clientMapper).InsertMigratingClients(ArgumentMatchers.anyList());
        clientEntities = new ArrayList<>();
        MigClient entity = new MigClient();
        entity.setEcClientId("mig23498");
        clientEntities.add(entity);
    }

    @Test
    void testGenerateRandomClientId() throws ServiceException {
        String companyId = "12345678";
        StgClient stgClient = new StgClient();
        stgClient.setClientName("abcd");

    }

    @Test
    void testGetCompanyIdNoExistingCompanyIds() throws ServiceException {
        ResponseEntity<String> response = new ResponseEntity<>("true", HttpStatus.ACCEPTED);
        doReturn(response).when(retryService).exchange(Mockito.anyString(),
                Mockito.any(HttpMethod.class), Mockito.any(HttpEntity.class),Mockito.any(ParameterizedTypeReference.class));
    }

    @Test
    void testGetCompanyIdExistingCompanyIdsOneRetry() throws ServiceException {
        ResponseEntity<String> response = new ResponseEntity<>("true", HttpStatus.ACCEPTED);
        doReturn(response).when(retryService).exchange(eq(jobService.companyIdCheckUrl +"abcd1234"),
                Mockito.any(HttpMethod.class), Mockito.any(HttpEntity.class),Mockito.any(ParameterizedTypeReference.class));

        MigClient entity = new MigClient();
        entity.setEcClientId("mig23498");

    }


    @Test
    void testValidClients() {
        ResponseEntity<CreateJobResponse> response = new ResponseEntity<>(new CreateJobResponse(), HttpStatus.ACCEPTED);
        doReturn(response).when(restTemplate).exchange(Mockito.anyString(),
                Mockito.any(HttpMethod.class), Mockito.any(HttpEntity.class),eq(CreateJobResponse.class));
        jobService.migStageUrl = "TestUrl";
        jobService.createJob(clientEntities);
    }

    @Test
    void testValidClients_2() {
        ResponseEntity<CreateJobResponse> response = new ResponseEntity<>(new CreateJobResponse(), HttpStatus.ACCEPTED);
        doReturn(response).when(restTemplate).exchange(Mockito.anyString(),
                Mockito.any(HttpMethod.class), Mockito.any(HttpEntity.class),eq(CreateJobResponse.class));
        jobService.migStageUrl = "TestUrl";
        JobEntity je = new JobEntity();
        je.setJobId(123L);
        jobService.createClients(clientEntities,"", je, "N", "N");
    }

    @Test
    void testValidClients400() {
        ResponseEntity<CreateJobResponse> response = new ResponseEntity<>(null, HttpStatus.UNAUTHORIZED);
        doReturn(response).when(restTemplate).exchange(Mockito.anyString(),
                Mockito.any(HttpMethod.class), Mockito.any(HttpEntity.class),eq(CreateJobResponse.class));
        jobService.migStageUrl = "TestUrl";
        jobService.createJob(clientEntities);
    }

    @Test
    void testValidClients500() {
        CreateJobResponse request = new CreateJobResponse(new CreateJobResponseData()
                .status(JobStatusEnum.EXTRACTION_INPROCESS.toString()));
        ResponseEntity<CreateJobResponse> response = new ResponseEntity<>(request, HttpStatus.INTERNAL_SERVER_ERROR);
        doReturn(response).when(restTemplate).exchange(Mockito.anyString(),
                Mockito.any(HttpMethod.class), Mockito.any(HttpEntity.class),eq(CreateJobResponse.class));
        jobService.migStageUrl = "TestUrl";
        jobService.createJob(clientEntities);
    }

    @Test
    void testValidClientsThrowException() {
        doThrow(new NullPointerException()).when(restTemplate).exchange(Mockito.anyString(),
                Mockito.any(HttpMethod.class), Mockito.any(HttpEntity.class),eq(CreateJobResponse.class));
        jobService.migStageUrl = "TestUrl";
        jobService.createJob(clientEntities);
    }

    @Test
    void testValidClientsThrowException_2() {
        doThrow(new NullPointerException()).when(restTemplate).exchange(Mockito.anyString(),
                Mockito.any(HttpMethod.class), Mockito.any(HttpEntity.class),eq(CreateJobResponse.class));
        jobService.migStageUrl = "TestUrl";
        JobEntity je = new JobEntity();
        je.setJobId(123L);
        jobService.createClients(clientEntities,"", je, "N", "N");
    }

    @Test
    void testGetJobId() {
        JobEntity job=new JobEntity();
        job.setUpdatedBy("MIGRATION");
        job.setJobId(0000);
        job.setType(CLIENT_MIGRATION);
        job.setStatus(JobStatusEnum.LOAD_COMPLETED);
        job.setCandidateCount(1);
        job.setLoadTime(1L);
        job.setExtractionTime(1L);
        job.setStartTime(OffsetDateTime.now());
        job.setEndTime(OffsetDateTime.now());
        job.setUpdatedDate(OffsetDateTime.now());
        doReturn(job).when(jobMapper).readMigrationJob(any());
        jobService.getJobById(0000);

    }

    @Test
    void createJobTestWithValidFile() throws Exception {

        MockMultipartFile csvFile = new MockMultipartFile("test.csv", "test.csv", "text/csv",
                (
                        "konk1806").getBytes());
        when(clientRepository.findClientEntities(Mockito.anySet(),  Mockito.anyString()))
                .thenReturn(0L);
        StgClient stg = new StgClient();
        stg.setClientName("xyz");
        when(stgClientRepository.findByOlbClinetId(anyString())).thenReturn(stg);
        jobService.parseCSVFile(csvFile);
    }
    @Test
    void createJobTestWithInvalidEcId() {

        MockMultipartFile csvFile = new MockMultipartFile("test.csv", "test.csv", "text/csv",
                ("EC_CLIENT_ID\n").getBytes());
        when(clientRepository.findClientEntities(Mockito.anySet(), Mockito.anyString()))
                .thenReturn(0L);
        Assertions.assertThrows(ServiceException.class, () ->{jobService.parseCSVFile(csvFile);});
    }

    @Test
    void createJobTestWithEmptyValues() {

        MockMultipartFile csvFile = new MockMultipartFile("test.csv", "test.csv", "text/csv",
                (
                        " ").getBytes());
        when(clientRepository.findClientEntities(Mockito.anySet(), Mockito.anyString()))
                .thenReturn(0L);
        Assertions.assertThrows(ServiceException.class, () ->{jobService.parseCSVFile(csvFile);});
    }

    @Test
    void createJobTestWithEmptyFile() {

        MockMultipartFile csvFile = new MockMultipartFile("test.csv", "test.csv", "text/csv",
                (
                        "").getBytes());
        when(clientRepository.findClientEntities(Mockito.anySet(), Mockito.anyString()))
                .thenReturn(0L);
        Assertions.assertThrows(ServiceException.class, () ->{jobService.parseCSVFile(csvFile);});
    }

    @Test
    void createJobTestWithInvalidFileFormat() {

        MockMultipartFile csvFile = new MockMultipartFile("test.txt", "test.txt", "text/csv",
                (
                        "konk1806").getBytes());
        when(clientRepository.findClientEntities(Mockito.anySet(), Mockito.anyString()))
                .thenReturn(0L);
        Assertions.assertThrows(ServiceException.class, () ->{jobService.parseCSVFile(csvFile);});
    }

    @Test
    void createJobTestWithDuplicateValues() throws ServiceException {

        MockMultipartFile csvFile = new MockMultipartFile("test.csv", "test.csv", "text/csv",
                (
                        "konk1806\n" +
                                "konk1806").getBytes());
        when(clientRepository.findClientEntities(Mockito.anySet(), Mockito.anyString()))
                .thenReturn(0L);

        String companyId = "abcd1234";
        StgClient stgClient = new StgClient();

        StgClient stg = new StgClient();
        stg.setClientName("xyz");
        when(stgClientRepository.findByOlbClinetId(anyString())).thenReturn(stg);
        //when(jobService.getCompanyId(anyString())).thenReturn(companyId);
        Assertions.assertThrows(ServiceException.class, () ->{jobService.parseCSVFile(csvFile);});
    }

    @Test
    void createJobTestWithExistingValues() {

        MockMultipartFile csvFile = new MockMultipartFile("test.csv", "test.csv", "text/csv",
                (
                        "konk1806").getBytes());
        MigClient cl = new MigClient();
        cl.setEcClientId("konk1806"); cl.setCompanyId("KONKLAB");
        List<MigClient> existing = Collections.singletonList(cl);
        when(clientRepository.findClientsNotRollback(Mockito.anySet(), Mockito.anyString()))
                .thenReturn(existing);
        Assertions.assertThrows(ServiceException.class, () ->{jobService.parseCSVFile(csvFile);});
    }

    @Test
    void createJobTestWithInvalidLength() {

        MockMultipartFile csvFile = new MockMultipartFile("test.csv", "test.csv", "text/csv",
                (
                        "konk18").getBytes());
        MigClient cl = new MigClient();
        cl.setEcClientId("konk1806"); cl.setCompanyId("KONKLAB");
        when(clientRepository.findClientEntities(Mockito.anySet(), Mockito.anyString()))
                .thenReturn(1L);
        Assertions.assertThrows(ServiceException.class, () ->{jobService.parseCSVFile(csvFile);});
    }

    @Test
    void stopGetJobId() throws ServiceException{
        JobEntity job=new JobEntity();
        job.setUpdatedBy("MIGRATION");
        job.setJobId(0000);
        job.setType(CLIENT_MIGRATION);
        job.setStatus(JobStatusEnum.LOAD_INPROGRESS);
        job.setCandidateCount(1);
        job.setLoadTime(1L);
        job.setExtractionTime(1L);
        job.setStartTime(OffsetDateTime.now());
        job.setEndTime(OffsetDateTime.now());
        job.setUpdatedDate(OffsetDateTime.now());
        doReturn(job).when(jobMapper).readMigrationJob(any());
        JobResponse resp = jobService.stopJobById(0000);
        assertEquals(0L, (long)resp.getData().getJobId());
        assertEquals("STOPPED", resp.getData().getStatus());
        assertEquals("CLIENT_MIGRATION", resp.getData().getJobType());
        assertEquals("MIGRATION", resp.getData().getUpdatedBy());
    }

}
