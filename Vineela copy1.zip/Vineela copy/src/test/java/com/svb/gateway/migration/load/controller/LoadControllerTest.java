package com.svb.gateway.migration.load.controller;

import com.svb.gateway.migration.client.entity.MigClient;
import com.svb.gateway.migration.common.utility.JobStatusEnum;
import com.svb.gateway.migration.job.controller.JobController;
import com.svb.gateway.migration.job.entity.MigJob;
import com.svb.gateway.migration.job.model.ClientEntityList;
import com.svb.gateway.migration.job.model.CreateJobResponse;
import com.svb.gateway.migration.job.repository.MigJobRepository;
import com.svb.gateway.migration.job.service.LoadService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.security.test.context.support.WithMockUser;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import static com.svb.gateway.migration.TestUtil.*;

@SpringBootTest
@AutoConfigureMockMvc
@EnableAsync
@WithMockUser(username = TEST_USER_USER3, password = TEST_USER1_VALID_PASSWORD, authorities = TEST_USER1_ROLE_EXECUTE)
public class LoadControllerTest {

    @Autowired
    private JobController loadController;

    @MockBean
    private LoadService loadService;
    @MockBean
    private MigJobRepository migJobRepository;

    @BeforeEach
    public void setup() throws Exception {

    }

    @Test
    public void testLoadService2() throws Exception {
        MigJob job = new MigJob();
        job.setStatus(JobStatusEnum.LOAD_COMPLETED.name());
        job.setJobId(123L);
        MigClient client = Mockito.mock(MigClient.class);
        ClientEntityList clientEntityList = new ClientEntityList();
        List<MigClient> clients = new ArrayList<>();
        clients.add(client);
        Mockito.when(loadService.validateAndPersistLoadRequest(Mockito.any(), Mockito.any())).thenReturn(Map.of(job, clients));
        Mockito.doNothing().when(loadService).startLoad(Mockito.any());

        ResponseEntity<CreateJobResponse> re = loadController.loadStart(123L, clientEntityList);
    }

    @Test
    public void testLoadService_null() throws Exception {
        Mockito.when(loadService.validateAndPersistLoadRequest(Mockito.any(), Mockito.anyList())).thenReturn(null);
        MigJob job = new MigJob();
        job.setStatus("Test");
        Mockito.when(migJobRepository.findByJobIdStatsExtractionProgress(123L)).thenReturn(job);
        ClientEntityList clientEntityList = new ClientEntityList();
        loadController.loadStart(123L, clientEntityList);
    }

}
