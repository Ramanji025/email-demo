package com.svb.gateway.migration.load.service;

import com.svb.gateway.migration.alerts.service.AlertsService;
import com.svb.gateway.migration.beneficiaries.service.BeneficiariesService;
import com.svb.gateway.migration.cards.service.CardsService;
import com.svb.gateway.migration.client.entity.MigClient;
import com.svb.gateway.migration.client.entity.StgClient;
import com.svb.gateway.migration.client.model.CompanyIdResponse;
import com.svb.gateway.migration.client.model.EnrollClientResponse;
import com.svb.gateway.migration.client.model.EnrollClientResponseData;
import com.svb.gateway.migration.client.repository.ClientRepository;
import com.svb.gateway.migration.client.repository.MigClientRepository;
import com.svb.gateway.migration.client.service.ClientExtensionService;
import com.svb.gateway.migration.client.service.ClientService;
import com.svb.gateway.migration.client.service.PartnerService;
import com.svb.gateway.migration.common.exception.ServiceException;
import com.svb.gateway.migration.common.service.RetryService;
import com.svb.gateway.migration.common.utility.JobStatusEnum;
import com.svb.gateway.migration.ec2stage.service.ECService;
import com.svb.gateway.migration.healthcheck.model.HealthCheckResponse;
import com.svb.gateway.migration.healthcheck.service.HealthCheckService;
import com.svb.gateway.migration.job.entity.JobEntity;
import com.svb.gateway.migration.job.entity.MigJob;
import com.svb.gateway.migration.job.mapper.JobMapper;
import com.svb.gateway.migration.job.repository.MigJobRepository;
import com.svb.gateway.migration.job.service.LoadService;
import com.svb.gateway.migration.nickname.service.NicknameService;
import com.svb.gateway.migration.payments.service.IpayPaymentService;
import com.svb.gateway.migration.payments.service.EconnectService;
import com.svb.gateway.migration.user.service.UserService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.Spy;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.util.Assert;

import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.svb.gateway.migration.common.constants.MigrationConstants.STATUS_FAILURE;
import static com.svb.gateway.migration.common.constants.MigrationConstants.STATUS_SUCCESS;
import static junit.framework.TestCase.assertTrue;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@SpringBootTest
@AutoConfigureMockMvc
public class LoadServiceTest {

    @MockBean
    MigJobRepository migJobRepository;

    @MockBean
    MigClientRepository migClientRepository;

    @MockBean
    ClientService clientService;

    @MockBean
    UserService userService;

    @MockBean
    CardsService cardsService;

    @MockBean
    BeneficiariesService beneficiariesService;

    @MockBean
    EconnectService econnectService;

    @MockBean
    NicknameService nicknameService;

    @MockBean
    AlertsService alertsService;

    @MockBean
    IpayPaymentService ipayPaymentService;

    @MockBean
    ECService ecService;

    @MockBean
    JobMapper jobMapper;

    //@InjectMocks
    @Autowired
    @Spy
    LoadService loadService;

    @MockBean
    private RetryService retryService;

    @MockBean
    ClientRepository stgClientRepository;

    @MockBean
    PartnerService partnerService;

    @MockBean
    HealthCheckService healthCheckService;

    @MockBean
    ClientExtensionService clientExtensionService;

    @Value("${mig.bdc.reRegister.sleepInterval}")
    int sleepInterval;

    @BeforeEach
    public void init(){
        JobEntity jobEntity = new JobEntity();
        jobEntity.setStatus(JobStatusEnum.EXTRACTION_COMPLETED);
        when(jobMapper.readMigrationJob(any())).thenReturn(jobEntity);
        loadService.healthCheckRequired=false;
        ReflectionTestUtils.setField(loadService, "companyIdLengthMax", 10);
        ReflectionTestUtils.setField(loadService, "companyIdLengthMin", 3);
        ResponseEntity<String> response = new ResponseEntity<>("true", HttpStatus.ACCEPTED);
        doReturn(response).when(retryService).exchange(anyString(),
                Mockito.any(HttpMethod.class), Mockito.any(HttpEntity.class),Mockito.any(ParameterizedTypeReference.class));
        String companyId = "12345678";
        String ecClientID = "ABCD1234";

    }

    @Test
    public void processJobSuccess() throws Exception {

        Long jobId = 123L;
        MigJob je = new MigJob();
        je.setStatus(JobStatusEnum.LOAD_COMPLETED.name());
        doReturn(je).when(migJobRepository).findByJobId(any());
        doReturn(je).when(migJobRepository).findByJobIdValue(any());
        doReturn(je).when(migJobRepository).findByJobIdProgress(any());
        doReturn(je).when(migJobRepository).saveAndFlush(any());

        List<String> clients= new ArrayList<>();
        List<MigClient> jobClients = new ArrayList<>();
        MigClient migClient=new MigClient();
        migClient.setEcClientId("abcd1234");
        jobClients.add(migClient);
        doReturn(jobClients).when(migClientRepository).findByJobId(any());
        doReturn(null).when(migClientRepository).findByEcClientIdandJobIdStatus(anyString(), anyLong(), anyString());

        List<EnrollClientResponse> lecr = new ArrayList<>();

        Map ilr = loadService.validateAndPersistLoadRequest(jobId, clients);

        assertNotNull(ilr);

    }

    @Test
    public void processJobError_jobId() throws Exception {

        List<String> clients = new ArrayList<>();

        Exception exception = assertThrows(ServiceException.class, () -> {
            loadService.validateAndPersistLoadRequest(null, clients);
        });

        String expectedMessage = "jobId must not be null";
        String actualMessage = exception.getMessage();

        assertTrue(actualMessage.contains(expectedMessage));

    }

    @Test
    public void processJobSuccess_jobNull() throws Exception {

        Long jobId = 123L;

        doReturn(null).when(migJobRepository).findByJobId(any());
        doReturn(null).when(migJobRepository).findByJobIdProgress(any());
        List<String> clients = new ArrayList<>();

        Exception exception = assertThrows(ServiceException.class, () -> {
            loadService.validateAndPersistLoadRequest(jobId, clients);
        });
    }

    @Test
    public void processJobSuccess_clientFilter() throws Exception {
        Long jobId = 123L;
        MigJob je = new MigJob();
        je.setStatus(JobStatusEnum.LOAD_COMPLETED.name());
        doReturn(je).when(migJobRepository).findByJobIdValue(any());
        doReturn(je).when(migJobRepository).findByJobId(any());
        List<String> clients = new ArrayList<>();

        clients.add("addr1234");
        List<MigClient> migClients = new ArrayList<>();
        MigClient migClient = new MigClient();
        migClient.setEcClientId("addr1234");
        migClients.add(migClient);
        doReturn(migClients).when(migClientRepository).findByJobId(any());

        doReturn(null).when(migJobRepository).saveAndFlush(any());
        Map ilr = loadService.validateAndPersistLoadRequest(jobId, clients);
        assertNotNull(ilr);
    }

    @Test
    void test_startLoad_EC_update_fail() throws Exception{
        Map<MigJob, List<MigClient>> jobClients =new HashMap<>();
        MigJob migJob=new MigJob();

        migJob.setUpdatedBy("MIGRATION");
        migJob.setJobId(1L);

        migJob.setCandidateCount(1);
        migJob.setLoadTime(1L);
        migJob.setExtractionTime(1L);
        migJob.setStartTime(OffsetDateTime.now());
        migJob.setEndTime(OffsetDateTime.now());
        migJob.setUpdatedDate(OffsetDateTime.now());

        MigClient migClient=new MigClient();
        MigClient migClient1=new MigClient();
        List<MigClient> migClientList = new ArrayList<>();
        migClient.setBdcStatus(0);
        migClient.setClientName("CLIENT1");
        migClient.setEcClientId("TEST1234");
        migClient.setJobId(1L);
        migClient.setStatus("Success");
        migClient1.setStatus("Success");
        migClient1.setJobId(1L);
        migClient1.setEcClientId("TEST1235");
        migClient1.setClientName("CLIENT2");
        migClient1.setBdcStatus(0);
        migClientList.add(migClient);
        migClientList.add(migClient1);
        jobClients=Map.of(migJob,migClientList);

        EnrollClientResponse enrollClientResponse=new EnrollClientResponse();
        EnrollClientResponseData enrollClientResponseData=new EnrollClientResponseData();
        enrollClientResponseData.setAdditionalProperty("Success","Success");
        enrollClientResponseData.setGwClientId("GWAddr1234");
        enrollClientResponseData.setStatus("SUCCESS");
        enrollClientResponseData.setGwPrimaryUserId("testUserId");
        enrollClientResponse.setData(enrollClientResponseData);
        doReturn(enrollClientResponse).when(clientService).enrollClient(any(),any());
        doReturn(null).when(cardsService).addCardProgramToClient(any(),any());
        doReturn(null).when(userService).createUsers(any(),any());
        doReturn(null).when(userService).updateCardUserId(any(),any());
        doReturn(null).when(beneficiariesService).addBeneficiaries(any(),any(),any());
        doReturn(null).when(econnectService).internalTransfer(any(),any());
        doReturn(null).when(econnectService).wireTransfer(any(),any());
        doReturn(null).when(nicknameService).migrateAccountNickname(any(),any());
        doReturn(null).when(alertsService).registerAlerts(any(),any());
        doReturn(true).when(partnerService).processPartnerRegistrationStatus(any(),any());
        doReturn(null).when(ipayPaymentService).createPayments(any(),any());
        doThrow(new ServiceException("Errored")).when(ecService).updateClientDetailsEc(anyList(), any(), any());
        loadService.startLoad(jobClients);
    }

    @Test
    public void test_startLoad() throws Exception {

        MigJob job = new MigJob();
        job.setJobId(123L);
        job.setStatus("Completed");
        List<MigClient> migClients = new ArrayList<>();
        MigClient migClient = new MigClient();
        migClient.setEcClientId("addr1234");
        migClient.setCompanyId("cmpnyId");
        migClients.add(migClient);

        doReturn(job).when(migJobRepository).save(any());
        EnrollClientResponse enrollClientResponse = new EnrollClientResponse();
        EnrollClientResponseData data = new EnrollClientResponseData();

        data.setStatus(STATUS_SUCCESS);
        enrollClientResponse.setData(data);

        doReturn(enrollClientResponse).when(clientService).enrollClient(anyString(), anyString(), anyLong());
        doThrow(new ServiceException("Errored")).when(userService).createUsers(anyLong(), any());
        doThrow(new ServiceException("Errored")).when(userService).updateCardUserId(anyLong(), anyString());
        doThrow(new ServiceException("Errored")).when(cardsService).addCardProgramToClient(anyLong(), any());
        doReturn(null).when(beneficiariesService).addBeneficiaries(anyLong(), any(), any());
        doThrow(new ServiceException("Errored")).when(econnectService).wireTransfer(anyLong(), any());
        doThrow(new ServiceException("Errored")).when(econnectService).internalTransfer(anyLong(), any());
        doThrow(new ServiceException("Errored")).when(ipayPaymentService).createPayments(anyLong(), any());

        loadService.startLoad(Map.of(job, migClients));
    }

    @Test
    public void test_startLoad_exe() throws Exception {
        MigJob job = new MigJob();
        job.setJobId(123L);
        job.setStatus("Completed");
        List<MigClient> migClients = new ArrayList<>();
        MigClient migClient = new MigClient();
        migClient.setEcClientId("addr1234");
        migClient.setCompanyId("cmpnyId");
        migClients.add(migClient);

        doReturn(job).when(migJobRepository).save(any());
        EnrollClientResponse enrollClientResponse = new EnrollClientResponse();
        EnrollClientResponseData data = new EnrollClientResponseData();
        data.setStatus(STATUS_SUCCESS);
        enrollClientResponse.setData(data);
        doReturn(enrollClientResponse).when(clientService).enrollClient(anyString(), anyString(), anyLong());
        doThrow(new ServiceException("Errored")).when(userService).createUsers(anyLong(), any());
        doThrow(new ServiceException("Errored")).when(userService).updateCardUserId(anyLong(), anyString());
        doThrow(new ServiceException("Errored")).when(cardsService).addCardProgramToClient(anyLong(), any());
        doThrow(new ServiceException("Errored")).when(econnectService).wireTransfer(anyLong(), any());
        doThrow(new ServiceException("Errored")).when(econnectService).internalTransfer(anyLong(), any());
        doThrow(new ServiceException("Errored")).when(ipayPaymentService).createPayments(anyLong(), any());

        loadService.startLoad(Map.of(job, migClients));
    }

    @Test
    public void test_startLoad_exe2() throws Exception {

        MigJob job = new MigJob();
        job.setJobId(123L);
        job.setStatus("Completed");
        List<MigClient> migClients = new ArrayList<>();
        MigClient migClient = new MigClient();
        migClient.setEcClientId("addr1234");
        migClient.setCompanyId("cmpnyId");
        migClients.add(migClient);

        doReturn(job).when(migJobRepository).save(any());
        EnrollClientResponse enrollClientResponse = new EnrollClientResponse();
        EnrollClientResponseData data = new EnrollClientResponseData();

        data.setStatus(STATUS_SUCCESS);
        enrollClientResponse.setData(data);
        doReturn(enrollClientResponse).when(clientService).enrollClient(anyString(), anyString(), anyLong());
        doReturn(null).when(userService).createUsers(anyLong(), any());
        doReturn(null).when(userService).updateCardUserId(anyLong(), anyString());
        doReturn(null).when(cardsService).addCardProgramToClient(anyLong(), any());
        doReturn(null).when(beneficiariesService).addBeneficiaries(anyLong(), any(), any());
        doReturn(null).when(econnectService).wireTransfer(anyLong(), any());
        doReturn(null).when(econnectService).internalTransfer(anyLong(), any());
        doReturn(null).when(ipayPaymentService).createPayments(anyLong(), any());

        loadService.startLoad(Map.of(job, migClients));

    }

    @Test
    public void test_startLoad_exe3() throws Exception {
        MigJob job = new MigJob();
        job.setJobId(123L);
        job.setStatus("Completed");
        List<MigClient> migClients = new ArrayList<>();
        MigClient migClient = new MigClient();
        migClient.setEcClientId("addr1234");
        migClient.setCompanyId("cmpnyId");
        migClients.add(migClient);

        doReturn(job).when(migJobRepository).save(any());

        doThrow(new ServiceException("Errored")).when(clientService).enrollClient(anyString(), anyString(), anyLong());

        loadService.startLoad(Map.of(job, migClients));

        loadService.startLoad(Map.of(job, migClients));
    }

    @Test
    void test_startLoad_Success() throws Exception{
        Map<MigJob, List<MigClient>> jobClients =new HashMap<>();
        MigJob migJob=new MigJob();

        migJob.setUpdatedBy("MIGRATION");
        migJob.setJobId(1L);

        migJob.setCandidateCount(1);
        migJob.setLoadTime(1L);
        migJob.setExtractionTime(1L);
        migJob.setStartTime(OffsetDateTime.now());
        migJob.setEndTime(OffsetDateTime.now());
        migJob.setUpdatedDate(OffsetDateTime.now());

        MigClient migClient=new MigClient();
        MigClient migClient1=new MigClient();
        List<MigClient> migClientList = new ArrayList<>();
        migClient.setBdcStatus(0);
        migClient.setClientName("CLIENT1");
        migClient.setEcClientId("TEST1234");
        migClient.setJobId(1L);
        migClient.setStatus("Success");
        migClient1.setStatus("Success");
        migClient1.setJobId(1L);
        migClient1.setEcClientId("TEST1235");
        migClient1.setClientName("CLIENT2");
        migClient1.setBdcStatus(0);
        migClientList.add(migClient);
        migClientList.add(migClient1);
        jobClients=Map.of(migJob,migClientList);

        EnrollClientResponse enrollClientResponse=new EnrollClientResponse();
        EnrollClientResponseData enrollClientResponseData=new EnrollClientResponseData();
        enrollClientResponseData.setAdditionalProperty("Success","Success");
        enrollClientResponseData.setGwClientId("GWAddr1234");
        enrollClientResponseData.setStatus("SUCCESS");
        enrollClientResponseData.setGwPrimaryUserId("testUserId");
        enrollClientResponse.setData(enrollClientResponseData);
        doReturn(enrollClientResponse).when(clientService).enrollClient(any(),any());
        doReturn(null).when(cardsService).addCardProgramToClient(any(),any());
        doReturn(null).when(userService).createUsers(any(),any());
        doReturn(null).when(userService).updateCardUserId(any(),any());
        doReturn(null).when(beneficiariesService).addBeneficiaries(any(),any(),any());
        doReturn(null).when(econnectService).internalTransfer(any(),any());
        doReturn(null).when(econnectService).wireTransfer(any(),any());
        doReturn(null).when(nicknameService).migrateAccountNickname(any(),any());
        doReturn(null).when(alertsService).registerAlerts(any(),any());
        doReturn(true).when(partnerService).processPartnerRegistrationStatus(any(),any());
        doReturn(null).when(ipayPaymentService).createPayments(any(),any());
        doReturn("SUCCESS").when(ecService).updateClientDetailsEc(anyList(),  any(), any());
        doReturn(migJob).when(migJobRepository).save(any());
                loadService.startLoad(jobClients);
    }

    @Test
    void test_startLoad_fail1() throws Exception{
        Map<MigJob, List<MigClient>> jobClients =new HashMap<>();
        MigJob migJob=new MigJob();

        migJob.setUpdatedBy("MIGRATION");
        migJob.setJobId(1L);

        migJob.setCandidateCount(1);
        migJob.setLoadTime(1L);
        migJob.setExtractionTime(1L);
        migJob.setStartTime(OffsetDateTime.now());
        migJob.setEndTime(OffsetDateTime.now());
        migJob.setUpdatedDate(OffsetDateTime.now());

        MigClient migClient=new MigClient();
        MigClient migClient1=new MigClient();
        List<MigClient> migClientList = new ArrayList<>();
        migClient.setBdcStatus(0);
        migClient.setClientName("CLIENT1");
        migClient.setEcClientId("TEST1234");
        migClient.setJobId(1L);
        migClient.setStatus("Success");
        migClient1.setStatus("Success");
        migClient1.setJobId(1L);
        migClient1.setEcClientId("TEST1235");
        migClient1.setClientName("CLIENT2");
        migClient1.setBdcStatus(0);
        migClientList.add(migClient);
        migClientList.add(migClient1);
        jobClients=Map.of(migJob,migClientList);

        EnrollClientResponse enrollClientResponse=new EnrollClientResponse();
        EnrollClientResponseData enrollClientResponseData=new EnrollClientResponseData();
        enrollClientResponseData.setAdditionalProperty("Success","Success");
        enrollClientResponseData.setGwClientId("GWAddr1234");
        enrollClientResponseData.setStatus("SUCCESS");
        enrollClientResponseData.setGwPrimaryUserId("testUserId");
        enrollClientResponse.setData(enrollClientResponseData);
        doReturn(enrollClientResponse).when(clientService).enrollClient(any(),any());
        doThrow(new ServiceException("Errored")).when(cardsService).addCardProgramToClient(any(),any());
        doThrow(new ServiceException("Errored")).when(userService).createUsers(anyLong(), any());
        doThrow(new ServiceException("Errored")).when(userService).updateCardUserId(anyLong(), anyString());

        doThrow(new ServiceException("Errored")).when(econnectService).wireTransfer(anyLong(), any());
        doThrow(new ServiceException("Errored")).when(econnectService).internalTransfer(anyLong(), any());
        doThrow(new ServiceException("Errored")).when(ipayPaymentService).createPayments(anyLong(), any());

        doThrow(new ServiceException("Errored")).when(nicknameService).migrateAccountNickname(any(),any());
        doThrow(new ServiceException("Errored")).when(alertsService).registerAlerts(any(),any());
        doReturn(true).when(partnerService).processPartnerRegistrationStatus(any(),any());

        doReturn(migJob).when(migJobRepository).save(any());

            loadService.startLoad(jobClients);

    }

    @Test
    void testHealthCheck_returnTrue() throws ServiceException{
        loadService.healthCheckRequired=true;
        MigJob migJob=new MigJob();
        migJob.setJobId(1L);
        HealthCheckResponse healthCheckResponse=new HealthCheckResponse();
        healthCheckResponse.setStatus(STATUS_SUCCESS);
        doReturn(healthCheckResponse).when(healthCheckService).preValidate();
        boolean status=loadService.isHealthCheckOk(migJob);
        assertTrue(status);
    }

    @Test
    void testHealthCheck_returnFalse() throws ServiceException{
        loadService.healthCheckRequired=false;
        MigJob migJob=new MigJob();
        migJob.setJobId(1L);
        HealthCheckResponse healthCheckResponse=new HealthCheckResponse();
        healthCheckResponse.setStatus(STATUS_FAILURE);
        doReturn(healthCheckResponse).when(healthCheckService).preValidate();
        boolean status=loadService.isHealthCheckOk(migJob);
        assertTrue(status);
    }

    @Test
    public void test_Pause_Processing() throws InterruptedException {
        MigJob job=new MigJob();
        job.setJobId(123L);

        MigClient client=new MigClient();
        client.setEcClientId("abcd1234");
        Long start=System.currentTimeMillis();
        Long delay=2000L;
        Thread.sleep(delay);
        loadService.pauseProcessing(start, job, client);
        Long end=System.currentTimeMillis();
        Assert.isTrue((end-start-delay)<sleepInterval, "Sleep time correct");
    }

    @Test
    void testGenerateRandomClientId() throws ServiceException {
        ResponseEntity<String> response = new ResponseEntity<>("true", HttpStatus.ACCEPTED);
        doReturn(response).when(retryService).exchange(Mockito.anyString(),
                Mockito.any(HttpMethod.class), Mockito.any(HttpEntity.class),Mockito.any(ParameterizedTypeReference.class));
        String companyId = "abcd1234";
        StgClient stgClient = new StgClient();
        stgClient.setClientName("abcd");
        String ecClientId = "abcd1234";

        when(stgClientRepository.findByOlbClinetId(ecClientId)).thenReturn(stgClient);
        CompanyIdResponse companyIdResponse = new CompanyIdResponse();
        companyIdResponse.setCompanyId("abcd1234");
        Mockito.when(clientExtensionService.generateCompanyId(any())).thenReturn(companyIdResponse);
        String result = loadService.getCompanyId("abcd1234");

        assertEquals(companyId, result);
    }

}
