package com.svb.gateway.migration.nickname.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.svb.gateway.migration.client.entity.MigClient;
import com.svb.gateway.migration.client.model.MigClientDTO;
import com.svb.gateway.migration.common.exception.ServiceException;
import com.svb.gateway.migration.nickname.model.NicknameResponse;
import com.svb.gateway.migration.nickname.model.NicknameResponseData;
import com.svb.gateway.migration.nickname.service.NicknameService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentMatchers;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.test.web.servlet.MockMvc;

import static junit.framework.TestCase.assertEquals;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doThrow;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@AutoConfigureMockMvc
class NicknameControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    @InjectMocks
    NicknameController nicknameController;

    @MockBean
    NicknameService nicknameService;

    NicknameResponse nicknameResponse=new NicknameResponse();

    public static String clientId="acc1234";

    MigClientDTO migClientDTO=new MigClientDTO();

    public static Long jobId=Long.valueOf("1234");

    @BeforeEach
    public void setup() throws Exception {
        nicknameController = new NicknameController(nicknameService);
        migClientDTO.setEcClientId(clientId);
        nicknameResponse.setMessage("Success");
    }

    @Test
    public void testMigrateAccountNickname() throws Exception {

        Mockito.when(nicknameService.migrateAccountNickname(ArgumentMatchers.anyLong(),ArgumentMatchers.any())).
                thenReturn(nicknameResponse);

        this.mockMvc.perform(post("/api/nickname/{jobId}","1234")
                .contentType(MediaType.APPLICATION_JSON_VALUE)
                .content(objectMapper.writeValueAsString(migClientDTO))
                .header("Authorization","Basic Y3JtdXNlcjI6QWNjZXNzMTIz"))
                .andExpect(status().isOk());
    }

    @Test
    public void testMigrateNicknameWithServiceException() throws Exception {

        doThrow(new ServiceException("Internal Server Error")).when(nicknameService).migrateAccountNickname(ArgumentMatchers.anyLong(),ArgumentMatchers.any());

        ResponseEntity<?> re = nicknameController.migrateAccountNicknames(jobId,migClientDTO);

        assertEquals(HttpStatus.BAD_REQUEST, re.getStatusCode());
    }
}
