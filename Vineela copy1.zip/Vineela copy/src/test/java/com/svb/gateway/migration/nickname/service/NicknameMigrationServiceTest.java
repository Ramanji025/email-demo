package com.svb.gateway.migration.nickname.service;

import com.svb.gateway.migration.client.entity.MigClient;
import com.svb.gateway.migration.common.constants.MigrationConstants;
import com.svb.gateway.migration.common.exception.ServiceException;
import com.svb.gateway.migration.nickname.entity.AccountMasterExtensionEntity;
import com.svb.gateway.migration.nickname.entity.MigrationNickname;
import com.svb.gateway.migration.nickname.entity.Nicknames;
import com.svb.gateway.migration.nickname.mapper.NicknameToACMXMapper;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.test.context.junit.jupiter.SpringExtension;


import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.fail;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@Slf4j
@SpringBootTest
@ExtendWith(SpringExtension.class)
class NicknameMigrationServiceTest {


    @InjectMocks
    @Spy
    NicknameMigrationService nicknameMigrationService;

    @Mock
    private NicknameToACMXMapper nicknameToACMXMapper;

    Nicknames nickname=new Nicknames();
    MigClient migClient=new MigClient();


    @BeforeEach
    void setUp() {

        migClient.setEcClientId("nick1234");
        migClient.setGwClientId("GWname1234");
        migClient.setStatus("SUCCESS");

        nickname.setAccTitle("Acc NickName");
        nickname.setAccountNumber("12345678");
        nickname.setOlbClientId("nick1234");
        nickname.setJobId("1234");
    }

    @Test
    void insert_throws_ServiceException() {
        try {
            MigrationNickname migrationNickname=nicknameMigrationService.insert(nickname,migClient);
            assertEquals(MigrationConstants.STATUS_FAILURE,migrationNickname.getStatus());
        } catch (ServiceException serviceException) {
            fail();
        }
    }

    @Test
    void insert_AccountNickname() {
        try {
            nicknameMigrationService.bankUserUuid="asda123132asdasd";
            MigrationNickname migrationNickname=nicknameMigrationService.insert(nickname,migClient);
        } catch (ServiceException e) {
           fail();
        }
    }

    @Test
    void insert_AccountNicknameUniqueConstraintAtTarget() {
        try {
            nicknameMigrationService.bankUserUuid="asda123132asdasd";
            migClient.setPrimaryCifUbs(1234545);
            when(nicknameToACMXMapper.insertAccountNicknamesInOCH(any(AccountMasterExtensionEntity.class))).thenThrow(DuplicateKeyException.class);
            MigrationNickname migrationNickname=nicknameMigrationService.insert(nickname,migClient);
        } catch (ServiceException e) {
            fail();
        }
    }

}
