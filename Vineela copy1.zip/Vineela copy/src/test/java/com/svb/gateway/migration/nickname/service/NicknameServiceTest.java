package com.svb.gateway.migration.nickname.service;

import com.svb.gateway.migration.client.entity.MigClient;
import com.svb.gateway.migration.client.repository.MigClientRepository;
import com.svb.gateway.migration.common.exception.ServiceException;
import com.svb.gateway.migration.common.utility.EntityLogUtility;
import com.svb.gateway.migration.nickname.entity.MigratedNicknamesEntity;
import com.svb.gateway.migration.nickname.entity.MigrationNickname;
import com.svb.gateway.migration.nickname.entity.Nicknames;
import com.svb.gateway.migration.nickname.mapper.MigrationNicknameMapper;
import com.svb.gateway.migration.nickname.model.NicknameResponse;
import com.svb.gateway.migration.nickname.repository.NickNameRepository;
import com.svb.gateway.migration.nickname.repository.StgAccountNicknameRepository;
import com.svb.gateway.migration.rollback.model.RollBackResponse;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentMatchers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.fail;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;

@Slf4j
@SpringBootTest
@ExtendWith(SpringExtension.class)
class NicknameServiceTest {

    @Mock
    private NicknameMigrationService nicknameMigrationService;

    @Mock
    private MigrationNicknameMapper migrationNicknameMapper;

    @Mock
    private StgAccountNicknameRepository stgAccountNicknameRepository;

    @Mock
    private MigClientRepository migClientRepository;

    @Mock
    EntityLogUtility entityLogUtility;

    @InjectMocks
    @Spy
    NicknameService nicknameService;
    @Mock
    NickNameRepository nickNameRepository;

    public String clientId="data1234";
    public String getClientId="GWname1234";
    public Long jobId=Long.valueOf("123");
    public String status="SUCCESS";

    Nicknames nickname = new Nicknames();
    MigClient migClient = new MigClient();
    MigratedNicknamesEntity successNickname=new MigratedNicknamesEntity();
    MigrationNickname successMigrationNickname=new MigrationNickname();

    @Test
    void migrateNicknames()  {
        try {
            List<Nicknames> nicknamesList=new ArrayList<>();
            nickname.setAccountNumber("34535345");
            nicknamesList.add(nickname);
            migClient.setGwClientId(getClientId);
            migClient.setEcClientId(clientId);
            successNickname.setStatus("SUCCESS");
            successNickname.setAccount_Nickname("Analysis Checking");
            when(stgAccountNicknameRepository.findByEcClientId(clientId)).thenReturn(nicknamesList);
            when(migrationNicknameMapper.checkIfMigratedIgnoredOrRolledBack(anyLong(),anyString(),anyString())).thenReturn(successNickname);
            when(nicknameMigrationService.insert(any(Nicknames.class),any(MigClient.class))).thenReturn(successMigrationNickname);
            NicknameResponse response=nicknameService.migrateAccountNickname(jobId,migClient);
            assertNotNull(response);
        } catch (ServiceException e) {
            fail();
        }
    }

    @Test
    void migrateNicknames_ThrowsServiceException_WhenNicknamesNull()  {
        try {
            List<Nicknames> nicknamesList=new ArrayList<>();
            successNickname.setStatus("SUCCESS");
            migClient.setGwClientId(getClientId);
            migClient.setEcClientId(clientId);
            successNickname.setAccount_Nickname("Analysis Checking");
            when(stgAccountNicknameRepository.findByEcClientId(clientId)).thenReturn(nicknamesList);
            when(migrationNicknameMapper.checkIfMigratedIgnoredOrRolledBack(anyLong(),anyString(),anyString())).thenReturn(successNickname);
            when(nicknameMigrationService.insert(any(Nicknames.class),any(MigClient.class))).thenReturn(successMigrationNickname);
            NicknameResponse response=nicknameService.migrateAccountNickname(jobId,migClient);
            assertNotNull(response.getAdditionalProperties().get("No account nicknames to migrate"));
        } catch (ServiceException e) {
            fail();
        }
    }

    @Test
    void migrateNicknames_reRunJob()  {
        try {
            List<Nicknames> nicknamesList=new ArrayList<>();
            nickname.setAccountNumber("34535345");
            nickname.setAccTitle("DDA Savings 1");
            nicknamesList.add(nickname);
            successNickname.setStatus("FAILURE");
            migClient.setGwClientId(getClientId);
            migClient.setEcClientId(clientId);
            successNickname.setAccount_Nickname("Analysis Checking");
            successMigrationNickname.setStatus("FAILURE");
            when(stgAccountNicknameRepository.findByEcClientId(clientId)).thenReturn(nicknamesList);
            when(migrationNicknameMapper.checkIfMigratedIgnoredOrRolledBack(anyLong(),anyString(),anyString())).thenReturn(successNickname);
            when(nickNameRepository.findByGwClientIdAndAccountNumberAndJobIdAndCifNumber(anyString(),anyString(),anyLong(),anyString())).thenReturn(successMigrationNickname);
            when(nicknameMigrationService.insert(any(Nicknames.class),any(MigClient.class))).thenReturn(successMigrationNickname);
            NicknameResponse response=nicknameService.migrateAccountNickname(jobId,migClient);
            assertNotNull(response);
        } catch (ServiceException e) {
            fail();
        }
    }

    @Test
    void migrateNicknames_reRunWithIgnore()  {
        try {
            List<Nicknames> nicknamesList=new ArrayList<>();
            nickname.setAccountNumber("34535345");
            nickname.setAccTitle("DDA Savings 1");
            nicknamesList.add(nickname);
            successNickname.setStatus("IGNORE");
            migClient.setGwClientId(getClientId);
            migClient.setEcClientId(clientId);
            successNickname.setAccount_Nickname("Analysis Checking");
            successMigrationNickname.setStatus("FAILURE");
            when(stgAccountNicknameRepository.findByEcClientId(clientId)).thenReturn(nicknamesList);
            when(migrationNicknameMapper.checkIfMigratedIgnoredOrRolledBack(anyLong(),anyString(),anyString())).thenReturn(successNickname);
            when(nickNameRepository.findByGwClientIdAndAccountNumberAndJobIdAndCifNumber(anyString(),anyString(),anyLong(),anyString())).thenReturn(successMigrationNickname);
            when(nicknameMigrationService.insert(any(Nicknames.class),any(MigClient.class))).thenReturn(successMigrationNickname);
            NicknameResponse response=nicknameService.migrateAccountNickname(jobId,migClient);
            assertNotNull(response);
        } catch (ServiceException e) {
            fail();
        }
    }

    @Test
    void process() {
        try {
            List<Nicknames> nicknamesList=new ArrayList<>();
            nickname.setAccTitle("Analysis Checking");
            nickname.setAccountNumber("34535345");
            nicknamesList.add(nickname);
            successNickname.setStatus("SUCCESS");
            migClient.setGwClientId(getClientId);
            migClient.setEcClientId(clientId);

            when(stgAccountNicknameRepository.findByEcClientId(clientId)).thenReturn(nicknamesList);
            when(migrationNicknameMapper.checkIfMigratedIgnoredOrRolledBack(anyLong(),anyString(),anyString())).thenReturn(null);
            when(nicknameMigrationService.insert(any(Nicknames.class),any(MigClient.class))).thenReturn(successMigrationNickname);
            nicknameService.process(migClient,jobId);
        } catch (ServiceException e) {
            fail();
        }
    }

    @Test
    void processIgnoreNicknameWithSpclChar() {
        try {
            List<Nicknames> nicknamesList=new ArrayList<>();
            nickname.setAccTitle("Analysis-Checking");
            nickname.setAccountNumber("34535345");
            nicknamesList.add(nickname);
            successNickname.setStatus("SUCCESS");
            migClient.setGwClientId(getClientId);
            migClient.setEcClientId(clientId);

            when(stgAccountNicknameRepository.findByEcClientId(clientId)).thenReturn(nicknamesList);
            when(migrationNicknameMapper.checkIfMigratedIgnoredOrRolledBack(anyLong(),anyString(),anyString())).thenReturn(null);
            when(nicknameMigrationService.insert(any(Nicknames.class),any(MigClient.class))).thenReturn(successMigrationNickname);
            nicknameService.process(migClient,jobId);
        } catch (ServiceException e) {
            fail();
        }
    }

    @Test
    void processIgnoreAccountWithNoNickname() {
        try {
            List<Nicknames> nicknamesList=new ArrayList<>();
            nickname.setAccountNumber("34535345");
            nicknamesList.add(nickname);
            successNickname.setStatus("SUCCESS");
            migClient.setGwClientId(getClientId);
            migClient.setEcClientId(clientId);

            when(stgAccountNicknameRepository.findByEcClientId(clientId)).thenReturn(nicknamesList);
            when(migrationNicknameMapper.checkIfMigratedIgnoredOrRolledBack(anyLong(),anyString(),anyString())).thenReturn(null);
            when(nicknameMigrationService.insert(any(Nicknames.class),any(MigClient.class))).thenReturn(successMigrationNickname);
            nicknameService.process(migClient,jobId);
        } catch (ServiceException e) {
            fail();
        }
    }

    @Test
    void processSuccess() {
        try {
            List<Nicknames> nicknamesList=new ArrayList<>();
            nickname.setAccTitle("Analysis Checking");
            nickname.setAccountNumber("34535345");
            nicknamesList.add(nickname);
            successMigrationNickname.setStatus("SUCCESS");
            migClient.setGwClientId(getClientId);
            migClient.setEcClientId(clientId);

            when(stgAccountNicknameRepository.findByEcClientId(clientId)).thenReturn(nicknamesList);
            when(migrationNicknameMapper.checkIfMigratedIgnoredOrRolledBack(anyLong(),anyString(),anyString())).thenReturn(null);
            when(nicknameMigrationService.insert(any(Nicknames.class),any(MigClient.class))).thenReturn(successMigrationNickname);
            nicknameService.process(migClient,jobId);
        } catch (ServiceException e) {
            fail();
        }
    }

    @Test
    void processSuccessWithJobId() {
        try {
            List<Nicknames> nicknamesList=new ArrayList<>();
            nickname.setAccTitle("Analysis Checking");
            nickname.setAccountNumber("34535345");
            nicknamesList.add(nickname);
            successMigrationNickname.setStatus("SUCCESS");
            successMigrationNickname.setJobId(Long.valueOf("123"));
            migClient.setGwClientId(getClientId);
            migClient.setEcClientId(clientId);

            when(stgAccountNicknameRepository.findByEcClientId(clientId)).thenReturn(nicknamesList);
            when(migrationNicknameMapper.checkIfMigratedIgnoredOrRolledBack(anyLong(),anyString(),anyString())).thenReturn(null);
            when(nicknameMigrationService.insert(any(Nicknames.class),any(MigClient.class))).thenReturn(successMigrationNickname);
            nicknameService.process(migClient,jobId);
        } catch (ServiceException e) {
            fail();
        }
    }

    @Test
    void processWithServiceException(){
        try {
            List<Nicknames> nicknamesList=new ArrayList<>();
            nickname.setAccTitle("Analysis Checking");
            nickname.setAccountNumber("34535345");
            nicknamesList.add(nickname);
            successNickname.setStatus("SUCCESS");
            migClient.setEcClientId(clientId);
            when(stgAccountNicknameRepository.findByEcClientId(clientId)).thenReturn(nicknamesList);
            when(migrationNicknameMapper.checkIfMigratedIgnoredOrRolledBack(anyLong(),anyString(),anyString())).thenReturn(null);
            doThrow(new ServiceException("Internal Server Error")).when(nicknameMigrationService).insert(any(Nicknames.class),any(MigClient.class));
            nicknameService.process(migClient,jobId);
        } catch (ServiceException e) {
            fail();
        }
    }

    @Test
    void nickNameRollback() {
        MigrationNickname migrationNickname = new MigrationNickname();
        migrationNickname.setStatus("Test");
        List<MigrationNickname> migrationNicknames = Arrays.asList(migrationNickname);
        when(nickNameRepository.
                findAllByEcClientIdAndStatus(ArgumentMatchers.anyString(), ArgumentMatchers.anyString()))
                .thenReturn(migrationNicknames);
        nicknameService.rollback(clientId, new RollBackResponse());
    }

    @Test
    void nickNameRollbackException() {
        MigrationNickname migrationNickname = new MigrationNickname();
        migrationNickname.setStatus("Test");
        List<MigrationNickname> migrationNicknames = Arrays.asList(migrationNickname);
        doThrow(new IllegalArgumentException("Internal Server Error")).when(nickNameRepository).saveAll(migrationNicknames);
        when(nickNameRepository.
                findAllByEcClientIdAndStatus(ArgumentMatchers.anyString(), ArgumentMatchers.anyString()))
                .thenReturn(migrationNicknames);
        nicknameService.rollback(clientId, new RollBackResponse());
    }
}
