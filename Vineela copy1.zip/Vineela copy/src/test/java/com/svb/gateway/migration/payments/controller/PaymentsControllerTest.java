package com.svb.gateway.migration.payments.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.svb.gateway.migration.client.model.MigClientDTO;
import com.svb.gateway.migration.payments.model.PaymentResponse;
import com.svb.gateway.migration.payments.service.IpayPaymentService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentMatchers;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@AutoConfigureMockMvc
class PaymentsControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    IpayPaymentService ipayPaymentService;

    @Autowired
    private ObjectMapper objectMapper;

    PaymentResponse paymentResponse=new PaymentResponse();

    public static String clientId="acc1234";
    MigClientDTO migClientDTO=new MigClientDTO();

    @BeforeEach
    public void setup() throws Exception {
        migClientDTO.setEcClientId("migr1234");
        migClientDTO.setGwClientId("GWaddr1234");
        Mockito.when(ipayPaymentService.createPayments(anyLong(), any())).
                thenReturn(paymentResponse);
    }

    @Test
    public void testIpayPaymentSuccess() throws Exception {

        this.mockMvc.perform(post("/api/payments/ipay/{jobId}","1")
                .contentType(MediaType.APPLICATION_JSON_VALUE)
                .content(objectMapper.writeValueAsString(migClientDTO))
                .header("Authorization","Basic Y3JtdXNlcjI6QWNjZXNzMTIz"))
                .andExpect(status().isOk());
    }

    @Test
    public void testIpayPaymentFailure() throws Exception {
        migClientDTO.setEcClientId(clientId);
        this.mockMvc.perform(post("/api/payments/ipay/{jobId}","1")
                .contentType(MediaType.APPLICATION_JSON_VALUE)
                .content(objectMapper.writeValueAsString(migClientDTO))
                .header("Authorization","Basic Y3JtdXNlcjI6QWNjZXNzMTIz"))
                .andExpect(status().is4xxClientError());
    }
}
