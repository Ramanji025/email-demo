package com.svb.gateway.migration.payments.mapper;

import com.svb.gateway.migration.common.utility.FrequencyPeriod;
import com.svb.gateway.migration.ipay.batch.util.IPayConstants;
import com.svb.gateway.migration.payments.entity.IpayStagingPayment;

import org.junit.jupiter.api.Test;

import static com.svb.gateway.migration.common.constants.MigrationConstants.STATUS_FAILURE;
import static com.svb.gateway.migration.common.constants.MigrationConstants.STATUS_IGNORE;
import static org.junit.jupiter.api.Assertions.assertEquals;


class MigrationIpayPaymentModelMapperTest {

    @Test
    void determineStatus_Returns_DefaultDuplicateStatus() {
        IpayStagingPayment ipayStagingPayment =new IpayStagingPayment();
        ipayStagingPayment.setPaymentFrequency(FrequencyPeriod.MONTHLY.getCode());
        String status=MigrationPaymentModelMapper.INSTANCE.determineStatus(ipayStagingPayment);
        assertEquals(STATUS_IGNORE, status);
    }

    @Test
    void determineStatus_Returns_InvalidFrequency_Failure() {
        IpayStagingPayment ipayStagingPayment =new IpayStagingPayment();

        ipayStagingPayment.setPaymentFrequency('A');
        String status=MigrationPaymentModelMapper.INSTANCE.determineStatus(ipayStagingPayment);
        assertEquals(STATUS_FAILURE, status);

        ipayStagingPayment.setPaymentFrequency('S');
        status=MigrationPaymentModelMapper.INSTANCE.determineStatus(ipayStagingPayment);
        assertEquals(STATUS_FAILURE, status);

        ipayStagingPayment.setPaymentFrequency('E');
        status=MigrationPaymentModelMapper.INSTANCE.determineStatus(ipayStagingPayment);
        assertEquals(STATUS_FAILURE, status);

        ipayStagingPayment.setPaymentFrequency('F');
        status=MigrationPaymentModelMapper.INSTANCE.determineStatus(ipayStagingPayment);
        assertEquals(STATUS_FAILURE, status);


    }

    @Test
    void determineStatus_Returns_DefaultFailureStatus() {
        IpayStagingPayment ipayStagingPayment =new IpayStagingPayment();
        ipayStagingPayment.setOverrideAmount("123");
        String status=MigrationPaymentModelMapper.INSTANCE.determineStatus(ipayStagingPayment);
        assertEquals(STATUS_FAILURE, status);

        ipayStagingPayment.setOverrideAmount(null);
        ipayStagingPayment.setSkippedPayment("1");
        status=MigrationPaymentModelMapper.INSTANCE.determineStatus(ipayStagingPayment);
        assertEquals(STATUS_FAILURE, status);

        ipayStagingPayment.setSkippedPayment("0");
        ipayStagingPayment.setOverrideSubsidaryBankId("ABC123");
        status=MigrationPaymentModelMapper.INSTANCE.determineStatus(ipayStagingPayment);
        assertEquals(STATUS_FAILURE, status);
    }

    @Test
    void addComments() {

        IpayStagingPayment ipayStagingPayment =new IpayStagingPayment();
        ipayStagingPayment.setOverrideAmount("123");
        String comments=MigrationPaymentModelMapper.INSTANCE.addComments(ipayStagingPayment);
        assertEquals(IPayConstants.OVERRIDE_AMOUNT, comments);

        ipayStagingPayment.setOverrideAmount(null);
        ipayStagingPayment.setSkippedPayment("1");
        comments=MigrationPaymentModelMapper.INSTANCE.addComments(ipayStagingPayment);
        assertEquals(IPayConstants.SKIPPED_PAYMENT, comments);

        ipayStagingPayment.setSkippedPayment("0");
        ipayStagingPayment.setOverrideSubsidaryBankId("ABC123");
        comments=MigrationPaymentModelMapper.INSTANCE.addComments(ipayStagingPayment);
        assertEquals(IPayConstants.OVERRIDE_SUBS_BANK_ID, comments);

        ipayStagingPayment.setOverrideSubsidaryBankId(null);
        ipayStagingPayment.setPaymentFrequency('A');
        comments=MigrationPaymentModelMapper.INSTANCE.addComments(ipayStagingPayment);
        assertEquals(IPayConstants.FREQUENCY_NOT_SUPPORTED + ipayStagingPayment.getPaymentFrequency(), comments);

    }
}
