package com.svb.gateway.migration.payments.service;

import com.svb.gateway.migration.beneficiaries.entity.MigBeneficiary;
import com.svb.gateway.migration.beneficiaries.entity.StgBeneficiary;
import com.svb.gateway.migration.beneficiaries.repository.BeneficiaryRepository;
import com.svb.gateway.migration.beneficiaries.repository.MigBeneficiaryRepository;
import com.svb.gateway.migration.client.entity.MigClient;
import com.svb.gateway.migration.common.exception.ServiceException;

import com.svb.gateway.migration.common.repository.CountryCodeRepository;
import com.svb.gateway.migration.common.utility.CacheManagerUtility;
import com.svb.gateway.migration.common.utility.CountryCodeCheckUtility;
import com.svb.gateway.migration.payments.entity.*;
import com.svb.gateway.migration.payments.mapper.*;
import com.svb.gateway.migration.payments.model.NickName;

import com.svb.gateway.migration.payments.model.OchPaymentResponse;
import com.svb.gateway.migration.payments.repository.*;
import com.svb.gateway.migration.payments.utils.PaymentsUtils;
import com.svb.gateway.migration.payments.entity.PAYMTransfers;
import com.svb.gateway.migration.payments.repository.PAYMRepository;
import lombok.extern.slf4j.Slf4j;

import org.junit.Assert;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.*;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.*;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.web.client.RestClientResponseException;
import org.springframework.web.client.RestTemplate;

import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.when;
import static org.mockito.Mockito.*;

@Slf4j
@SpringBootTest
@ExtendWith(SpringExtension.class)
class GatewayPaymentServiceTest {

    @InjectMocks
    @Spy
    GatewayPaymentService gatewayPaymentService;

    @Mock
    MigBeneficiaryRepository migBeneficiaryRepository;

    @Mock
    PAYMRepository paymRepository;

    @Mock
    RestTemplate restTemplate;

    @Mock
    CacheManagerUtility cacheManagerUtility;

    @Mock
    CountryCodeRepository countryCodeRepository;

    @Mock
    CountryCodeCheckUtility countryCodeCheckUtility;

    @Mock
    BeneficiaryRepository beneficiaryRepository;

    @Value("100765,42004,103479")
    private Set<String> recurrenceErrorCodeSet;

    MigClient migClient=new MigClient();
    MigBeneficiary beneficiary=new MigBeneficiary();
    StgBeneficiary stgBeneficiary=new StgBeneficiary();

    PAYMTransfers paymTransfers=new PAYMTransfers();
    OchPaymentResponse ochPaymentResponse=new OchPaymentResponse();
    OchPaymentResponse.CommonSection commonSection=new OchPaymentResponse.CommonSection();

    @BeforeEach
    void setUp() {
        migClient.setEcClientId("test0005");
        migClient.setGwClientId("GWaddr1234");
        migClient.setJobId(Long.valueOf("111"));
        paymTransfers.setBankIdentifier("ABC");
        paymTransfers.setPaymAcctId("bene");

        beneficiary.setBeneficiaryId("123");
        beneficiary.setGroupId("3453");
        commonSection.setRequestReferenceId(1234);
        ochPaymentResponse.setCommonSection(commonSection);
        gatewayPaymentService.recurrenceErrorCodeSet=recurrenceErrorCodeSet;
    }

    @Test
    void insert_throws_ServiceException() {
        try {
            IpayStagingPayment ipayStagingPayment=PaymentsUtils.createPayment();
            ipayStagingPayment.setPaymentDate(null);
            gatewayPaymentService.insertIpayPayment(PaymentsUtils.createPayment(), migClient);
        } catch (ServiceException e) {
        }
    }

    @Test
    void insert_IpayPaymentWithNoBene() {
        try {
            when(migBeneficiaryRepository.findByBeneSourceForIpayMigrated(anyLong(), any())).thenReturn(null);
            ResponseEntity<OchPaymentResponse> ochPaymentResponseResponseEntity = new ResponseEntity(ochPaymentResponse, HttpStatus.CREATED);
            doReturn(ochPaymentResponseResponseEntity).when(restTemplate).exchange(anyString(), any(HttpMethod.class), any(HttpEntity.class), eq(OchPaymentResponse.class));
            MigrationIpayPayment migrationIpayPayment = gatewayPaymentService.insertIpayPayment(PaymentsUtils.createPayment(), migClient);

        } catch (ServiceException e) {
            fail();
        }
    }

    @Test
    void insert_IpayPaymentWithBene() {
        try {
            when(migBeneficiaryRepository.findByBeneSourceForIpayMigrated(anyLong(), any())).thenReturn(beneficiary);
            ResponseEntity<OchPaymentResponse> ochPaymentResponseResponseEntity = new ResponseEntity(ochPaymentResponse, HttpStatus.CREATED);
            doReturn(ochPaymentResponseResponseEntity).when(restTemplate).exchange(anyString(), any(HttpMethod.class), any(HttpEntity.class), eq(OchPaymentResponse.class));
            MigrationIpayPayment migrationIpayPayment = gatewayPaymentService.insertIpayPayment(PaymentsUtils.createPayment(), migClient);

        } catch (ServiceException e) {
            fail();
        }
    }

    @Test
    void insert_TransferPayment() {
        try {
            when(migBeneficiaryRepository.findByBeneSourceForIpayMigrated(anyLong(), any())).thenReturn(beneficiary);
            when(cacheManagerUtility.getVTToken()).thenReturn("xyz");
            ResponseEntity<OchPaymentResponse> ochPaymentResponseResponseEntity = new ResponseEntity(ochPaymentResponse, HttpStatus.CREATED);
            doReturn(ochPaymentResponseResponseEntity).when(restTemplate).exchange(anyString(), any(HttpMethod.class), any(HttpEntity.class), eq(OchPaymentResponse.class));
            MigrationInternalTransfer migrationPayment= gatewayPaymentService.insertInternalTransfer(PaymentsUtils.createInternalTransfer(), migClient);
            assertEquals(migrationPayment.getGwReqId(),1234);
        } catch (ServiceException e) {
            e.printStackTrace();
            fail();
        }
    }

    @Test
    void transfer_throws_ServiceException() {
        try {
            InternalTransfer internalTransfer=PaymentsUtils.createInternalTransfer();
            internalTransfer.setTransferDate(null);
            gatewayPaymentService.insertInternalTransfer(PaymentsUtils.createInternalTransfer(), migClient);
        } catch (ServiceException e) {
        }
    }

    @Test
    void insert_TransferPaymentFailedOCH() {
        try {
            when(migBeneficiaryRepository.findByBeneSourceForIpayMigrated(anyLong(), any())).thenReturn(beneficiary);
            when(cacheManagerUtility.getVTToken()).thenReturn("xyz");
            ResponseEntity<OchPaymentResponse> ochPaymentResponseResponseEntity = new ResponseEntity(ochPaymentResponse, HttpStatus.BAD_REQUEST);
            doReturn(ochPaymentResponseResponseEntity).when(restTemplate).exchange(anyString(), any(HttpMethod.class), any(HttpEntity.class), eq(OchPaymentResponse.class));
            MigrationInternalTransfer migrationPayment= gatewayPaymentService.insertInternalTransfer(PaymentsUtils.createInternalTransfer(),migClient );
            assertNotEquals(migrationPayment.getGwReqId(),1234);
        } catch (ServiceException e) {
            e.printStackTrace();
            fail();
        }
    }

    @Test
    void insert_TransferPaymentFailedOchWithChannelContext() {
        try {
            when(migBeneficiaryRepository.findByBeneSourceForIpayMigrated(anyLong(), any())).thenReturn(beneficiary);
            when(cacheManagerUtility.getVTToken()).thenReturn("xyz");
            HttpHeaders headers=new HttpHeaders();
            String dataJson="[\"{\"status\\\":{\\\"message\\\":[{\\\"recordReference\\\":\\\"1\\\"\",\"\\\"message_TYPE\\\":\\\"BE\\\"\",\"\\\"nameSpaceInfo\\\":\\\"PROD\\\"\",\"\\\"messageDesc\\\":\\\"The transaction account entity type is not allowed for this transaction. Contact the bank administrator.\\\"\",\"\\\"messageAddlnInfo\\\":\\\"The initiator account entity type [T] is not allowed for this transaction having initiator type entity [INITIATE] and scenario [CHK] Entry Id : 1\\\"\",\"\\\"messageCode\\\":\\\"101553\\\"}]}}\"]";
            headers.add("ChannelContext",dataJson);
            doThrow(new RestClientResponseException("rest exception", 400, "BAD_REQUEST",headers, null, null))
                    .when(restTemplate).exchange(anyString(), any(HttpMethod.class), any(HttpEntity.class), eq(OchPaymentResponse.class));
            MigrationInternalTransfer migrationPayment= gatewayPaymentService.insertInternalTransfer(PaymentsUtils.createInternalTransfer(),migClient );
            assertNotEquals(migrationPayment.getGwReqId(),1234);
        } catch (ServiceException e) {
            e.printStackTrace();
            fail();
        }
    }

    @Test
    void insert_TransferPayment_nullUser()  {
        try {
            when(migBeneficiaryRepository.findByBeneSourceForIpayMigrated(anyLong(), any())).thenReturn(beneficiary);
            MigrationInternalTransfer migrationPayment = gatewayPaymentService.insertInternalTransfer(PaymentsUtils.createInternalTransfer(), migClient);
        } catch (ServiceException e) {
        }
    }
    @Test
    void wire_throws_ServiceException() {
        try {
            WireTransfer wireTransfer=PaymentsUtils.createWireTransfer();
            wireTransfer.setValueDate(null);
            gatewayPaymentService.insertWireAdhocPayment(1L, wireTransfer,migClient );
        } catch (ServiceException e) {
        }
    }

    @Test
    void insert_WireTransferPayment() {
        try {
            when(migBeneficiaryRepository.findByBeneSourceForIpayMigrated(anyLong(), any())).thenReturn(beneficiary);
            when(paymRepository.findByBnfId(any())).thenReturn(paymTransfers);
            when(migBeneficiaryRepository.findByTemplateIdandAndEcClientId(anyLong(), any(), any())).thenReturn(beneficiary);
            when(cacheManagerUtility.getVTToken()).thenReturn("xyz");
            ResponseEntity<OchPaymentResponse> ochPaymentResponseResponseEntity = new ResponseEntity(ochPaymentResponse, HttpStatus.CREATED);
            doReturn(ochPaymentResponseResponseEntity).when(restTemplate).exchange(anyString(), any(HttpMethod.class), any(HttpEntity.class), eq(OchPaymentResponse.class));
            when(countryCodeRepository.findAll()).thenReturn(PaymentsUtils.getCountryCodes());
            when(countryCodeCheckUtility.getCountryCodeMap()).thenReturn(PaymentsUtils.getCountryCodeMap());
            MigrationWireTransfer migrationPayment= gatewayPaymentService.insertWireAdhocPayment(1L, PaymentsUtils.createWireTransfer(), migClient);
            assertEquals(migrationPayment.getStatus(),"SUCCESS");

        } catch (ServiceException e) {
            e.printStackTrace();
            fail();
        }
    }

    @Mock
    MigrationWireTransfer migrationWireTransfer;

    @Mock
    ACMXRepository acmxRepository;
    @Mock
    NickName nickName;

    @Test
    void test_insertWireTransfer_pastDated() throws ServiceException {
        WireTransfer wireTransfer=new WireTransfer();
       wireTransfer= PaymentsUtils.createWireTransfer();

        wireTransfer.setEntryopId("user1541609");
        Calendar c = Calendar.getInstance();
        c.setTime(new Date());
        c.add(Calendar.DATE, -5);//setting past date
        Date dt = new Date();
        dt = c.getTime();

        wireTransfer.setValueDate(dt);
        when(migBeneficiaryRepository.findByTemplateIdandAndEcClientId(anyLong(), any(),any())).thenReturn(beneficiary);
        when(paymRepository.findByBnfId(any())).thenReturn(paymTransfers);
        when(acmxRepository.findByAccId(any(),any())).thenReturn(nickName);
        migrationWireTransfer= gatewayPaymentService.insertWireAdhocPayment(1L, wireTransfer,migClient );
        assertEquals(migrationWireTransfer.getStatus(),"FAILURE");

    }

    @Test
    void test_insertWireTransfer_nullBeneBankCountry() throws ServiceException {
        WireTransfer wireTransfer=new WireTransfer();
        wireTransfer= PaymentsUtils.createWireTransfer();
        wireTransfer.setBeneBankCountry(null);
        wireTransfer.setEntryopId("user1541609");
        Calendar c = Calendar.getInstance();
        c.setTime(new Date());
        c.add(Calendar.DATE, 5);//setting past date
        Date dt = new Date();
        dt = c.getTime();

        wireTransfer.setValueDate(dt);
        when(migBeneficiaryRepository.findByTemplateIdandAndEcClientId(anyLong(), any(),any())).thenReturn(beneficiary);
        when(paymRepository.findByBnfId(any())).thenReturn(paymTransfers);
        when(acmxRepository.findByAccId(any(),any())).thenReturn(nickName);
        migrationWireTransfer= gatewayPaymentService.insertWireAdhocPayment(1L, wireTransfer, migClient);
        assertEquals(migrationWireTransfer.getStatus(),"FAILURE");
    }

    @Test
    void test_insertWireTransferInvalidBankIdFormat() throws ServiceException {
        WireTransfer wireTransfer=new WireTransfer();
        wireTransfer= PaymentsUtils.createWireTransfer();
        wireTransfer.setBeneBankId("1559733");
        wireTransfer.setEntryopId("user1541609");
        Calendar c = Calendar.getInstance();
        c.setTime(new Date());
        c.add(Calendar.DATE, 5);//setting past date
        Date dt = new Date();
        dt = c.getTime();

        wireTransfer.setValueDate(dt);

        when(migBeneficiaryRepository.findByTemplateIdandAndEcClientId(anyLong(), any(),any())).thenReturn(beneficiary);
        when(paymRepository.findByBnfId(any())).thenReturn(paymTransfers);
        when(acmxRepository.findByAccId(any(),any())).thenReturn(nickName);
        migrationWireTransfer= gatewayPaymentService.insertWireAdhocPayment(1L, wireTransfer,migClient );
        assertEquals(migrationWireTransfer.getStatus(),"FAILURE");
    }

    @Test
    void test_rollbackPayments_Failure() throws ServiceException{

       gatewayPaymentService.rollback(null) ;
}
@Mock
OchMapper ochMapper;
    @Test
    void test_rollbackPayments_Success() throws ServiceException{
        List<Long> reqIds=new ArrayList<>();
        reqIds.add((long) 6001);

doNothing().when(ochMapper).deleteTransactionRequests(Mockito.anyList(),anyString());

        gatewayPaymentService.rollback(reqIds) ;
    }

    @Test
    void test_rollBackPayments_EmptyReqId() {
        List<Long> reqIds= new  ArrayList<>();

        Boolean result= gatewayPaymentService.rollback(reqIds);
        assertEquals(result, false);
    }


    @Test
    void test_nickName_Success() throws ServiceException {
        when(acmxRepository.findByAccId(anyString(),anyString())).thenReturn(nickName);
       String nickNames= gatewayPaymentService.mapNickName(anyString(),anyString());
       assertNotEquals(nickNames, null);
    }

    @Test
    void test_validateAndReturnBene_nonNumeric() throws ServiceException{

        WireTransfer wireTransfer=new WireTransfer();
        wireTransfer= PaymentsUtils.createWireTransfer();
        wireTransfer.setBeneBankCountry("India");
        wireTransfer.setEntryopId("user1541609");
        Calendar c = Calendar.getInstance();
        c.setTime(new Date());
        c.add(Calendar.DATE, 5);//setting past date
        Date dt = new Date();
        dt = c.getTime();

        wireTransfer.setValueDate(dt);
        MigBeneficiary beneNonNum=new MigBeneficiary();
        beneNonNum.setBeneficiaryId("TESTBENE");
        when(migBeneficiaryRepository.findByTemplateIdandAndEcClientId(anyLong(), any(),any())).thenReturn(beneNonNum);
        when(paymRepository.findByBnfId(any())).thenReturn(paymTransfers);
        when(acmxRepository.findByAccId(any(),any())).thenReturn(nickName);
        when(countryCodeRepository.findAll()).thenReturn(PaymentsUtils.getCountryCodes());
        when(countryCodeCheckUtility.getCountryCodeMap()).thenReturn(PaymentsUtils.getCountryCodeMap());

        migrationWireTransfer= gatewayPaymentService.insertWireAdhocPayment(1L, wireTransfer,migClient );
        assertEquals(migrationWireTransfer.getStatus(),"FAILURE");

    }

    @Test
    void test_validateAndDefaultNetworkAndTxnType() throws ServiceException{

        WireTransfer wireTransfer=new WireTransfer();
        wireTransfer= PaymentsUtils.createWireTransfer();
        wireTransfer.setEntryopId("user1541609");
        wireTransfer.setBeneBankId("123456789123");
        Calendar c = Calendar.getInstance();
        c.setTime(new Date());
        c.add(Calendar.DATE, 5);//setting past date
        Date dt = new Date();
        dt = c.getTime();

        wireTransfer.setValueDate(dt);
        MigBeneficiary beneNonNum=new MigBeneficiary();
        beneNonNum.setBeneficiaryId("TESTBENE");
        when(migBeneficiaryRepository.findByTemplateIdandAndEcClientId(anyLong(), any(),any())).thenReturn(beneNonNum);
        when(paymRepository.findByBnfId(any())).thenReturn(paymTransfers);
        when(acmxRepository.findByAccId(any(),any())).thenReturn(nickName);
        when(countryCodeRepository.findAll()).thenReturn(PaymentsUtils.getCountryCodes());
        when(countryCodeCheckUtility.getCountryCodeMap()).thenReturn(PaymentsUtils.getCountryCodeMap());

        migrationWireTransfer= gatewayPaymentService.insertWireAdhocPayment(1L, wireTransfer,migClient );
        assertEquals(migrationWireTransfer.getStatus(),"FAILURE");

    }

    @Test
    void test_validateAndReturnBene_null() throws ServiceException{

        WireTransfer wireTransfer=new WireTransfer();
        wireTransfer= PaymentsUtils.createWireTransfer();
        wireTransfer.setBeneBankId("ABCD1234");
        wireTransfer.setEntryopId("user1541609");
        wireTransfer.setTemplateId(1234);
        Calendar c = Calendar.getInstance();
        c.setTime(new Date());
        c.add(Calendar.DATE, 5);//setting past date
        Date dt = new Date();
        dt = c.getTime();

        wireTransfer.setValueDate(dt);

        stgBeneficiary.setTemplateId(1234);
        stgBeneficiary.setTemplateCode("My Template");

        when(migBeneficiaryRepository.findByBeneSourceForIpayMigrated(anyLong(), any())).thenReturn(beneficiary);
        when(paymRepository.findByBnfId(any())).thenReturn(paymTransfers);
        when(migBeneficiaryRepository.findByTemplateIdandAndEcClientId(anyLong(), any(), any())).thenReturn(beneficiary);
        when(cacheManagerUtility.getVTToken()).thenReturn("xyz");
        ResponseEntity<OchPaymentResponse> ochPaymentResponseResponseEntity = new ResponseEntity(ochPaymentResponse, HttpStatus.CREATED);
        doReturn(ochPaymentResponseResponseEntity).when(restTemplate).exchange(anyString(), any(HttpMethod.class), any(HttpEntity.class), eq(OchPaymentResponse.class));
        when(countryCodeRepository.findAll()).thenReturn(PaymentsUtils.getCountryCodes());
        when(countryCodeCheckUtility.getCountryCodeMap()).thenReturn(PaymentsUtils.getCountryCodeMap());
        when(beneficiaryRepository.findByOlbClientIdAndTemplateIdAndJobId(any(),any(),any())).thenReturn(stgBeneficiary);
        migrationWireTransfer= gatewayPaymentService.insertWireAdhocPayment(1L, wireTransfer,migClient );
        assertEquals(migrationWireTransfer.getStatus(),"SUCCESS");
    }

    @Test
    public void testErrorMessageReplacement(){
        String dataJson="[\"{\"status\\\":{\\\"message\\\":[{\\\"recordReference\\\":\\\"1\\\"\",\"\\\"message_TYPE\\\":\\\"BE\\\"\",\"\\\"nameSpaceInfo\\\":\\\"PROD\\\"\",\"\\\"messageDesc\\\":\\\"The transaction account entity type is not allowed for this transaction. Contact the bank administrator.\\\"\",\"\\\"messageAddlnInfo\\\":\\\"The initiator account entity type [T] is not allowed for this transaction having initiator type entity [INITIATE] and scenario [CHK] Entry Id : 1\\\"\",\"\\\"messageCode\\\":\\\"101553\\\"}]}}\"]";
        dataJson=dataJson.replaceAll("\\\"", "");
        System.out.println(dataJson);
    }

    @Test
    void test_insertWireTransfer_INTLType() throws ServiceException {
        WireTransfer wireTransfer=PaymentsUtils.createWireTransfer();
        wireTransfer.setPmtType("INTL");
        wireTransfer.setEntryopId("user1541609");

        when(migBeneficiaryRepository.findByTemplateIdandAndEcClientId(anyLong(), any(),any())).thenReturn(beneficiary);
        when(paymRepository.findByBnfId(any())).thenReturn(paymTransfers);
        when(acmxRepository.findByAccId(any(),any())).thenReturn(nickName);
        migrationWireTransfer= gatewayPaymentService.insertWireAdhocPayment(1L, wireTransfer,migClient );
        assertEquals(migrationWireTransfer.getStatus(),"FAILURE");

    }

    @Test
    void test_createOch_convert_Single_payment(){
        try {
            when(migBeneficiaryRepository.findByBeneSourceForIpayMigrated(anyLong(), any())).thenReturn(beneficiary);
            when(cacheManagerUtility.getVTToken()).thenReturn("xyz");
            HttpHeaders headers=new HttpHeaders();
            ResponseEntity<OchPaymentResponse> ochPaymentResponseResponseEntity = new ResponseEntity(ochPaymentResponse, HttpStatus.CREATED);

            String invalidRecurrenceDataJson="{\"status\":{\"message\":[{\"message_TYPE\":\"BE\",\"message_PARAM\":\"{\\\"TOT_NO_INST\\\":1}\",\"messageAddlnInfo\":\"Number of instanses can't be less than one\",\"messageDesc\":\"For the recurring payments, the number of payments must be more than one.\",\"messageCode\":\"42004\",\"nameSpaceInfo\":\"PROD\"}]}}";
            headers.add("ChannelContext",invalidRecurrenceDataJson);
            when(restTemplate.exchange(anyString(), any(HttpMethod.class), any(HttpEntity.class), eq(OchPaymentResponse.class)))
                    .thenThrow(new RestClientResponseException("rest exception", 400, "BAD_REQUEST",headers, null, null))
                    .thenReturn(ochPaymentResponseResponseEntity);
            MigrationInternalTransfer migrationPayment= gatewayPaymentService.insertInternalTransfer(PaymentsUtils.createInternalTransfer(),migClient );
            assertEquals("SUCCESS", migrationPayment.getStatus());

        } catch (ServiceException e) {
            e.printStackTrace();
            fail();
        }
    }

    @Test
    void test_contains(){
        String message="100765}]}}";

        Assert.assertTrue(recurrenceErrorCodeSet.contains(message.replaceAll("([^\\d]+)", "")));

    }



}
