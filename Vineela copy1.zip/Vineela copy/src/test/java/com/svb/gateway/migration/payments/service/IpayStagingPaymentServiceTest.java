package com.svb.gateway.migration.payments.service;

import com.svb.gateway.migration.client.entity.MigClient;
import com.svb.gateway.migration.common.exception.ServiceException;
import com.svb.gateway.migration.payments.entity.IpayStagingPayment;
import com.svb.gateway.migration.payments.entity.MigrationIpayPayment;
import com.svb.gateway.migration.payments.model.PaymentResponse;
import com.svb.gateway.migration.payments.repository.IpayPaymentsRepository;
import com.svb.gateway.migration.payments.repository.MigrationEntityRepository;
import com.svb.gateway.migration.payments.repository.MigrationPaymentsRepository;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.time.Instant;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.TimeZone;

import static com.svb.gateway.migration.common.constants.MigrationConstants.STATUS_FAILURE;
import static com.svb.gateway.migration.common.constants.MigrationConstants.STATUS_SUCCESS;
import static org.junit.Assert.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.when;

@Slf4j
@SpringBootTest
@ExtendWith(SpringExtension.class)
class IpayStagingPaymentServiceTest {

    @Mock
    private GatewayPaymentService gatewayPaymentService;

    @Mock
    private MigrationPaymentsRepository migrationPaymentsRepository;

    @Mock
    private IpayPaymentsRepository ipayPaymentsRepository;

    @Mock
    private MigrationEntityRepository migrationEntityRepository;

    @InjectMocks
    @Spy
    IpayPaymentService ipayPaymentService;

    public String clientId="test0005";

    MigClient migClient=new MigClient();

    IpayStagingPayment ipayStagingPayment =new IpayStagingPayment();

    MigrationIpayPayment successPayment=new MigrationIpayPayment();
    MigrationIpayPayment newPayment=new MigrationIpayPayment();
    MigrationIpayPayment failurePayment=new MigrationIpayPayment();
    List<MigrationIpayPayment> successMigrationIpayPaymentList =new ArrayList<>();


    @BeforeEach
    void setUp() {
        ipayStagingPayment.setPaymentId(1000);

        failurePayment.setStatus(STATUS_FAILURE);
        failurePayment.setPaymentId(1000);
        newPayment.setEcClientId(clientId);
        newPayment.setPaymentId(1000);

        migClient.setEcClientId(clientId);
        migClient.setJobId(Long.valueOf("1234"));


        successPayment.setStatus(STATUS_SUCCESS);
        successPayment.setPaymentId(1000);
        successPayment.setEcClientId(clientId);
        successMigrationIpayPaymentList.add(successPayment);


    }


    @Test
    void createPayments()  {
        try {
            List<IpayStagingPayment> ipayStagingPaymentList =new ArrayList<>();
            ipayStagingPaymentList.add(ipayStagingPayment);
            when(ipayPaymentsRepository.findByEcClientId(1L, clientId)).thenReturn(ipayStagingPaymentList);
            when(migrationPaymentsRepository.findByJobIdAndEcClientId(anyLong(),any())).thenReturn(successMigrationIpayPaymentList);
            when(gatewayPaymentService.insertIpayPayment(any(IpayStagingPayment.class),any() )).thenReturn(successPayment);
            PaymentResponse response= ipayPaymentService.createPayments(1L, migClient);

            assertNotNull(response);
        } catch (ServiceException e) {
            fail();
        }
    }

    @Test
    void createPayments_LogAdditionalMessage_WhenPaymentsNull()  {
        try {
            List<IpayStagingPayment> ipayStagingPaymentList =new ArrayList<>();
            when(ipayPaymentsRepository.findByEcClientId(1L, clientId)).thenReturn(ipayStagingPaymentList);

            when(migrationPaymentsRepository.findByJobIdAndEcClientId(anyLong(),any())).thenReturn(successMigrationIpayPaymentList);
            when(gatewayPaymentService.insertIpayPayment(any(IpayStagingPayment.class), any())).thenReturn(successPayment);
            PaymentResponse response= ipayPaymentService.createPayments(1L, migClient);
            assertEquals(1, response.getAdditionalProperties().size());
        } catch (ServiceException e) {
            fail(e.getMessage());
        }
    }

    @Test
    void createPayments_ThrowsServiceException_WhenMigrationPaymentNull()  {
        try {
            List<IpayStagingPayment> ipayStagingPaymentList =new ArrayList<>();
            ipayStagingPaymentList.add(ipayStagingPayment);

            when(ipayPaymentsRepository.findByEcClientId(1L, clientId)).thenReturn(ipayStagingPaymentList);
            when(migrationPaymentsRepository.findByJobIdAndEcClientId(anyLong(),any())).thenReturn(successMigrationIpayPaymentList);
            when(gatewayPaymentService.insertIpayPayment(any(IpayStagingPayment.class), any())).thenReturn(successPayment);
            PaymentResponse response= ipayPaymentService.createPayments(1L, migClient);
        } catch (ServiceException e) {
            fail();
        }
    }

    @Test
    void process() {
        try {
            List<IpayStagingPayment> ipayStagingPaymentList =new ArrayList<>();
            ipayStagingPaymentList.add(ipayStagingPayment);
            when(ipayPaymentsRepository.findByEcClientId(1L, clientId)).thenReturn(ipayStagingPaymentList);
            when(migrationPaymentsRepository.findByJobIdAndEcClientId(anyLong(),any())).thenReturn(null);
            when(gatewayPaymentService.insertIpayPayment(any(IpayStagingPayment.class),any() )).thenReturn(successPayment);
            PaymentResponse paymentResponse = ipayPaymentService.process(1L, migClient);
            assertEquals(1, (int)paymentResponse.getPaymentResponseData().getRecordCount().getSuccess());
            assertEquals(0, (int)paymentResponse.getPaymentResponseData().getRecordCount().getFailure());
            assertEquals(1, (int)paymentResponse.getPaymentResponseData().getRecordCount().getTotal());
            assertEquals(STATUS_SUCCESS, paymentResponse.getPaymentResponseData().getStatus());
        } catch (ServiceException e) {
            fail();
        }
    }

    @Test
    void processWithExisiting() {
        try {
            List<IpayStagingPayment> ipayStagingPaymentList =new ArrayList<>();
            ipayStagingPaymentList.add(ipayStagingPayment);
            when(ipayPaymentsRepository.findByEcClientId(1L, clientId)).thenReturn(ipayStagingPaymentList);
            when(migrationPaymentsRepository.findByJobIdAndEcClientId(anyLong(),any())).thenReturn(successMigrationIpayPaymentList);
            when(gatewayPaymentService.insertIpayPayment(any(IpayStagingPayment.class), any())).thenReturn(successPayment);
            PaymentResponse paymentResponse = ipayPaymentService.process(1L, migClient);
            assertEquals(0, (int)paymentResponse.getPaymentResponseData().getRecordCount().getSuccess());
            assertEquals(0, (int)paymentResponse.getPaymentResponseData().getRecordCount().getFailure());
            assertEquals(0, (int)paymentResponse.getPaymentResponseData().getRecordCount().getTotal());
            assertEquals(STATUS_SUCCESS, paymentResponse.getPaymentResponseData().getStatus());
        } catch (ServiceException e) {
            fail(e.getMessage());
        }
    }

    @Test
    void processReRun() {
        try {
            List<MigrationIpayPayment> newMigrationIpayPaymentList =new ArrayList<>();
            newMigrationIpayPaymentList.add(newPayment);

            List<IpayStagingPayment> ipayStagingPaymentList =new ArrayList<>();
            ipayStagingPaymentList.add(ipayStagingPayment);
            when(ipayPaymentsRepository.findByEcClientId(1L, clientId)).thenReturn(ipayStagingPaymentList);


            when(migrationPaymentsRepository.findByJobIdAndEcClientId(anyLong(),any())).thenReturn(newMigrationIpayPaymentList);
            when(gatewayPaymentService.insertIpayPayment(any(IpayStagingPayment.class),any() )).thenReturn(successPayment);
            PaymentResponse paymentResponse = ipayPaymentService.process(1L, migClient);
            assertEquals(1, (int)paymentResponse.getPaymentResponseData().getRecordCount().getSuccess());
            assertEquals(0, (int)paymentResponse.getPaymentResponseData().getRecordCount().getFailure());
            assertEquals(1, (int)paymentResponse.getPaymentResponseData().getRecordCount().getTotal());
            assertEquals(STATUS_SUCCESS, paymentResponse.getPaymentResponseData().getStatus());
        } catch (ServiceException e) {
            fail(e.getMessage());
        }
    }

    @Test
    void processInvalidPayment() {
        try {
            List<IpayStagingPayment> ipayStagingPaymentList =new ArrayList<>();
            ipayStagingPayment.setOverrideAmount("100");
            ipayStagingPaymentList.add(ipayStagingPayment);

            List<MigrationIpayPayment> migrationIpayPaymentList =new ArrayList<>();
            migrationIpayPaymentList.add(successPayment);

            when(ipayPaymentsRepository.findByEcClientId(1L, clientId)).thenReturn(ipayStagingPaymentList);
            when(migrationPaymentsRepository.findByJobIdAndEcClientId(anyLong(),any())).thenReturn(migrationIpayPaymentList);
            when(gatewayPaymentService.insertIpayPayment(any(IpayStagingPayment.class),any() )).thenReturn(successPayment);
            PaymentResponse paymentResponse = ipayPaymentService.process(1L, migClient);
            assertEquals(0, (int)paymentResponse.getPaymentResponseData().getRecordCount().getSuccess());
            assertEquals(1, (int)paymentResponse.getPaymentResponseData().getRecordCount().getFailure());
            assertEquals(1, (int)paymentResponse.getPaymentResponseData().getRecordCount().getTotal());
            assertEquals(STATUS_SUCCESS, paymentResponse.getPaymentResponseData().getStatus());
        } catch (ServiceException e) {
            fail(e.getMessage());
        }
    }

    @Test
    void processException() {
        try {
            List<IpayStagingPayment> ipayStagingPaymentList =new ArrayList<>();
            ipayStagingPaymentList.add(ipayStagingPayment);
            when(ipayPaymentsRepository.findByEcClientId(1L, clientId)).thenReturn(ipayStagingPaymentList);
            List<MigrationIpayPayment> payments=new ArrayList<>();
            payments.add(failurePayment);
            when(migrationPaymentsRepository.findByJobIdAndEcClientId(anyLong(),any())).thenReturn(payments);
            when(gatewayPaymentService.insertIpayPayment(any(IpayStagingPayment.class), any())).thenThrow(new ServiceException(""));
            PaymentResponse paymentResponse = ipayPaymentService.process(1L, migClient);
            assertEquals(0, (int)paymentResponse.getPaymentResponseData().getRecordCount().getSuccess());
            assertEquals(1, (int)paymentResponse.getPaymentResponseData().getRecordCount().getFailure());
            assertEquals(1, (int)paymentResponse.getPaymentResponseData().getRecordCount().getTotal());
            assertEquals(STATUS_SUCCESS, paymentResponse.getPaymentResponseData().getStatus());
        } catch (ServiceException e) {
            fail(e.getMessage());
        }
    }

    @Test
    void process_nullPayment() {
        try {
            List<IpayStagingPayment> ipayStagingPaymentList =new ArrayList<>();
            ipayStagingPaymentList.add(ipayStagingPayment);
            when(ipayPaymentsRepository.findByEcClientId(1L, clientId)).thenReturn(ipayStagingPaymentList);
            when(migrationPaymentsRepository.findByJobIdAndEcClientId(anyLong(),any())).thenReturn(null);
            when(gatewayPaymentService.insertIpayPayment(any(IpayStagingPayment.class), any() )).thenReturn(successPayment);
            ipayPaymentService.process(1L, migClient);
        } catch (ServiceException e) {
            fail();
        }
    }

    private static final String PST_TIME_ZONE="America/Los_Angeles";
    private static final String TIME_ZONE= TimeZone.getTimeZone(PST_TIME_ZONE).getDisplayName(Boolean.TRUE, 0);

    @Test
    public void getPSTTime(){
        log.info("TIME ZONE is {}",TIME_ZONE);
        log.info(ZonedDateTime.ofInstant(Instant.now(), ZoneId.of(PST_TIME_ZONE)).toString());
    }
}
