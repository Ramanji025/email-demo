package com.svb.gateway.migration.payments.service;

import com.svb.gateway.migration.client.entity.MigClient;
import com.svb.gateway.migration.common.exception.ServiceException;
import com.svb.gateway.migration.common.service.RetryService;
import com.svb.gateway.migration.payments.entity.MigrationStopPayments;
import com.svb.gateway.migration.payments.entity.StopPayStagingEntity;
import com.svb.gateway.migration.payments.model.StopPayMigrationResponse;
import com.svb.gateway.migration.payments.repository.MigrationEntityRepository;
import com.svb.gateway.migration.payments.repository.MigrationStopPaymentRepository;
import com.svb.gateway.migration.payments.repository.StopPayUserRepository;
import com.svb.gateway.migration.payments.repository.StopPaymentRepository;
import com.svb.gateway.migration.rollback.model.RollBackResponse;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.*;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.web.client.RestTemplate;

import java.util.*;

import static org.junit.Assert.assertEquals;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@Slf4j
@SpringBootTest
@ExtendWith(SpringExtension.class)
class StopPaymentServiceTest {

    public String clientId = "test1234";
    @Mock
    StopPayUserRepository stopPayUserRepository;
    @Mock
    StopPaymentRepository stopPaymentRepository;
    @Mock
    RestTemplate restTemplate;
    @Mock
    RetryService retryService;
    @Mock
    MigrationEntityRepository migrationEntityRepository;
    @Mock
    MigrationStopPaymentRepository migrationStopPaymentRepository;
    @Value(value = "https://gateway-stoppay-qa2.apps.ocp.ppdmz.local/stoppay/migrateStopPay")
    String stpUrl;
    @InjectMocks
    @Spy
    StopPaymentService stopPaymentService;
    MigClient migClient = new MigClient();
    List<StopPayStagingEntity> stopPaymentStagingList = new ArrayList<>();
    List<StopPayStagingEntity> stopPaymentEligibleList = new ArrayList<>();
    StopPayStagingEntity stopPayStagingEntity = new StopPayStagingEntity();
    StopPayMigrationResponse stopPayMigrationResponse = new StopPayMigrationResponse();

    @BeforeEach
    void setUp() {
        migClient.setEcClientId(clientId);
        migClient.setGwClientId("GWaddr1234");
    }

    @Test
    void stopPaymentMigration_apiCallFailure() throws ServiceException {

        stopPayStagingEntity.setJobId(Long.valueOf("123"));
        stopPayStagingEntity.setReqStat(2);
        stopPaymentStagingList.add(stopPayStagingEntity);
        Mockito.when(stopPaymentRepository.findByOlbClientIdAndJobId(ArgumentMatchers.any(), ArgumentMatchers.any())).thenReturn(stopPaymentStagingList);
        Mockito.when(stopPaymentRepository.findByStatusAndEcClientIdAndJobId(ArgumentMatchers.any(), ArgumentMatchers.any())).thenReturn(stopPaymentStagingList);

        Mockito.when(stopPayUserRepository.getMigratedStopPayUser(ArgumentMatchers.any(), ArgumentMatchers.any())).thenReturn(null);

        ResponseEntity<StopPayMigrationResponse> stopPayMigrationResponseResponseEntity = new ResponseEntity(stopPayMigrationResponse, HttpStatus.OK);
        doReturn(stopPayMigrationResponseResponseEntity).when(restTemplate).exchange(anyString(), any(HttpMethod.class), any(HttpEntity.class), eq(StopPayMigrationResponse.class));

        StopPayMigrationResponse stopPayMigrationResponse = stopPaymentService.migrateStopPay(1L, migClient);
        Assertions.assertNull(stopPayMigrationResponse.getData());
    }

    @Test
    void stopPaymentMigration_apiCallException() throws ServiceException {

        stopPayStagingEntity.setJobId(Long.valueOf("123"));
        stopPayStagingEntity.setReqStat(2);
        stopPaymentStagingList.add(stopPayStagingEntity);
        Mockito.when(stopPaymentRepository.findByOlbClientIdAndJobId(ArgumentMatchers.any(), ArgumentMatchers.any())).thenReturn(stopPaymentStagingList);
        Mockito.when(stopPaymentRepository.findByStatusAndEcClientIdAndJobId(ArgumentMatchers.any(), ArgumentMatchers.any())).thenReturn(stopPaymentStagingList);

        Mockito.when(stopPayUserRepository.getMigratedStopPayUser(ArgumentMatchers.any(), ArgumentMatchers.any())).thenReturn(null);

        ResponseEntity<StopPayMigrationResponse> stopPayMigrationResponseResponseEntity = new ResponseEntity(stopPayMigrationResponse, HttpStatus.BAD_REQUEST);
        stopPaymentService.stpUrl = "stpURLTest";
        doReturn(stopPayMigrationResponseResponseEntity).when(restTemplate).exchange(Mockito.anyString(), Mockito.any(HttpMethod.class), Mockito.any(HttpEntity.class), eq(StopPayMigrationResponse.class));

        StopPayMigrationResponse stopPayMigrationResponse = stopPaymentService.migrateStopPay(1L, migClient);
        Assertions.assertNull(stopPayMigrationResponse.getData());
    }

    @Test
    void stopPaymentMigration_apiCallSuccess() throws ServiceException {

        stopPayStagingEntity.setJobId(Long.valueOf("123"));
        stopPayStagingEntity.setReqStat(2);
        stopPaymentStagingList.add(stopPayStagingEntity);
        Mockito.when(stopPaymentRepository.findByOlbClientIdAndJobId(ArgumentMatchers.any(), ArgumentMatchers.any())).thenReturn(stopPaymentStagingList);
        Mockito.when(stopPaymentRepository.findByStatusAndEcClientIdAndJobId(ArgumentMatchers.any(), ArgumentMatchers.any())).thenReturn(stopPaymentStagingList);

        Mockito.when(stopPayUserRepository.getMigratedStopPayUser(ArgumentMatchers.any(), ArgumentMatchers.any())).thenReturn(null);

        StopPayMigrationResponse.Data[] data = new StopPayMigrationResponse.Data[1];
        StopPayMigrationResponse.Data data1 = new StopPayMigrationResponse.Data();
        data1.setMigStatus("SUCCESS");
        data1.setGwReqId(1234);
        data[0] = data1;
        stopPayMigrationResponse.setData(data);
        ResponseEntity<StopPayMigrationResponse> stopPayMigrationResponseResponseEntity = Mockito.mock(ResponseEntity.class);
        when(stopPayMigrationResponseResponseEntity.getStatusCode()).thenReturn(HttpStatus.OK);
        when(stopPayMigrationResponseResponseEntity.getBody()).thenReturn(stopPayMigrationResponse);
        doReturn(stopPayMigrationResponseResponseEntity).when(restTemplate).exchange(anyString(), any(HttpMethod.class), any(HttpEntity.class), eq(StopPayMigrationResponse.class));

        StopPayMigrationResponse stopPayMigrationServiceResponse = stopPaymentService.migrateStopPay(1L, migClient);
        //Currently setting it to check for null, as rest template mocking is not working, needs to be looked into
        Assertions.assertNull(stopPayMigrationServiceResponse.getData());
    }

    @Test
    void stopPaymentMigration_noStagingRecordToMigrate() throws ServiceException {

        Mockito.when(stopPaymentRepository.findByOlbClientIdAndJobId(ArgumentMatchers.any(), ArgumentMatchers.any())).thenReturn(stopPaymentStagingList);

        StopPayMigrationResponse stopPayMigrationResponse = stopPaymentService.migrateStopPay(1L, migClient);
        Assertions.assertNull(stopPayMigrationResponse.getData());

    }

    @Test
    void stopPaymentMigration_noEligibleRecordToMigrate() throws ServiceException {

        stopPayStagingEntity.setJobId(Long.valueOf("123"));
        stopPayStagingEntity.setReqStat(2);
        stopPaymentStagingList.add(stopPayStagingEntity);
        Mockito.when(stopPaymentRepository.findByOlbClientIdAndJobId(ArgumentMatchers.any(), ArgumentMatchers.any())).thenReturn(stopPaymentStagingList);
        Mockito.when(stopPaymentRepository.findByStatusAndEcClientIdAndJobId(ArgumentMatchers.any(), ArgumentMatchers.any())).thenReturn(stopPaymentEligibleList);

        StopPayMigrationResponse stopPayMigrationResponse = stopPaymentService.migrateStopPay(1L, migClient);
        Assertions.assertNull(stopPayMigrationResponse.getData());

    }

    @Test
    void stopPaymentMigration_apiCallSuccess1() throws ServiceException {

        stopPayStagingEntity.setJobId(Long.valueOf("123"));
        stopPayStagingEntity.setReqStat(2);
        stopPaymentStagingList.add(stopPayStagingEntity);
        stopPaymentStagingList.add(stopPayStagingEntity);
        Mockito.when(stopPaymentRepository.findByOlbClientIdAndJobId(ArgumentMatchers.any(), ArgumentMatchers.any())).thenReturn(stopPaymentStagingList);
        Mockito.when(stopPaymentRepository.findByStatusAndEcClientIdAndJobId(ArgumentMatchers.any(), ArgumentMatchers.any())).thenReturn(stopPaymentStagingList);

        Mockito.when(stopPayUserRepository.getMigratedStopPayUser(ArgumentMatchers.any(), ArgumentMatchers.any())).thenReturn(null);

        StopPayMigrationResponse.Data[] data = new StopPayMigrationResponse.Data[2];
        StopPayMigrationResponse.Data data1 = new StopPayMigrationResponse.Data();
        StopPayMigrationResponse.Data data2 = new StopPayMigrationResponse.Data();
        data1.setMigStatus("SUCCESS");
        data1.setGwReqId(1234);
        data2.setMigStatus("failed");
        data2.setGwReqId(0);
        data[0] = data1;
        data[1] = data2;
        stopPayMigrationResponse.setData(data);

        ResponseEntity<StopPayMigrationResponse> stopPayMigrationResponseResponseEntity = new ResponseEntity<>(stopPayMigrationResponse, HttpStatus.OK);
        stopPaymentService.stpUrl = "stpURLTest";

        doReturn(stopPayMigrationResponseResponseEntity).when(retryService).exchange(anyString(), any(HttpMethod.class), any(HttpEntity.class), any());
        doReturn(stopPayMigrationResponseResponseEntity).when(restTemplate).exchange(Mockito.anyString(), Mockito.any(HttpMethod.class), Mockito.any(HttpEntity.class), eq(StopPayMigrationResponse.class));

        StopPayMigrationResponse stopPayMigrationServiceResponse = stopPaymentService.migrateStopPay(1L, migClient);

        assertEquals(2, stopPayMigrationServiceResponse.getData().length);
    }

    @Test
    void stopPaymentMigration_stagingList_Empty() throws ServiceException {
        stopPayStagingEntity.setJobId(Long.valueOf("123"));
        stopPayStagingEntity.setReqStat(2);
        stopPaymentStagingList.add(stopPayStagingEntity);

        Mockito.when(stopPaymentRepository.findByOlbClientIdAndJobId(ArgumentMatchers.any(), ArgumentMatchers.any())).thenReturn(stopPaymentStagingList);
        Mockito.when(stopPaymentRepository.findByStatusAndEcClientIdAndJobId(ArgumentMatchers.any(), ArgumentMatchers.any())).thenReturn(stopPaymentStagingList);

        Mockito.when(stopPayUserRepository.getMigratedStopPayUser(ArgumentMatchers.any(), ArgumentMatchers.any())).thenReturn(null);

        StopPayMigrationResponse.Data[] data = new StopPayMigrationResponse.Data[1];
        StopPayMigrationResponse.Data data1 = new StopPayMigrationResponse.Data();
        data1.setMigStatus("SUCCESS");
        data1.setGwReqId(1234);
        data[0] = data1;
        stopPayMigrationResponse.setData(data);
        ResponseEntity<StopPayMigrationResponse> stopPayMigrationResponseResponseEntity = Mockito.mock(ResponseEntity.class);
        when(stopPayMigrationResponseResponseEntity.getStatusCode()).thenReturn(HttpStatus.OK);
        when(stopPayMigrationResponseResponseEntity.getBody()).thenReturn(stopPayMigrationResponse);
        doReturn(stopPayMigrationResponseResponseEntity).when(restTemplate).exchange(anyString(), any(HttpMethod.class), any(HttpEntity.class), eq(StopPayMigrationResponse.class));

        StopPayMigrationResponse stopPayMigrationServiceResponse = stopPaymentService.migrateStopPay(1L, migClient);
        Assertions.assertNull(stopPayMigrationServiceResponse.getData());
    }

    @Test
    void stopPayRollback() {
        MigrationStopPayments migrationStopPayments = new MigrationStopPayments();
        migrationStopPayments.setStatus("Test");
        List<MigrationStopPayments> migrationStopPaymentsList = Arrays.asList(migrationStopPayments);
        when(migrationStopPaymentRepository.
                findMigrationStopPaymentsByEcClientId(ArgumentMatchers.anyString()))
                .thenReturn(migrationStopPaymentsList);
        stopPaymentService.rollback(clientId,migClient.getGwClientId(), new RollBackResponse());
    }

    @Test
    void stopPayRollbackException() {
        MigrationStopPayments migrationStopPayments = new MigrationStopPayments();
        migrationStopPayments.setStatus("Test");
        List<MigrationStopPayments> migrationStopPaymentsList = Arrays.asList(migrationStopPayments);
        doThrow(new IllegalArgumentException("Internal Server Error")).when(migrationStopPaymentRepository).saveAll(migrationStopPaymentsList);
        when(migrationStopPaymentRepository.
                findMigrationStopPaymentsByEcClientId(ArgumentMatchers.anyString()))
                .thenReturn(migrationStopPaymentsList);
        stopPaymentService.rollback(clientId,migClient.getGwClientId(), new RollBackResponse());
    }

}
