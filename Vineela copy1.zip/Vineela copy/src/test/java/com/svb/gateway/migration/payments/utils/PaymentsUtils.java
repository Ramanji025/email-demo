package com.svb.gateway.migration.payments.utils;

import com.svb.gateway.migration.common.entity.CountryCodeEntity;
import com.svb.gateway.migration.payments.entity.InternalTransfer;
import com.svb.gateway.migration.payments.entity.IpayStagingPayment;
import com.svb.gateway.migration.payments.entity.TransactionEntity;
import com.svb.gateway.migration.payments.entity.WireTransfer;
import com.svb.gateway.migration.payments.model.RecurringType;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.*;

import static com.svb.gateway.migration.common.constants.MigrationConstants.STATUS_SUCCESS;

public class PaymentsUtils {

    private PaymentsUtils(){}
    public static IpayStagingPayment createPayment() {
        IpayStagingPayment ipayStagingPayment =new IpayStagingPayment();
        ipayStagingPayment.setEcClientId("test0005");
        ipayStagingPayment.setBeneficiaryId(1234);
        ipayStagingPayment.setJobId("1");
        ipayStagingPayment.setPayeeRelationshipNumber("PRN");
        ipayStagingPayment.setPaymentAmount(100d);
        ipayStagingPayment.setPaymentFrequency(null);
        ipayStagingPayment.setPaymentDate(LocalDate.now());
        ipayStagingPayment.setPaymentId(1234);
        ipayStagingPayment.setSubscriberAccountNumber("3300724935");
        ipayStagingPayment.setTargetBeneficiaryId(9999);
        ipayStagingPayment.setTransactionType("ACH");
        ipayStagingPayment.setRecurringType(RecurringType.NONE);

        return ipayStagingPayment;
    }

    public static InternalTransfer createInternalTransfer() {
        InternalTransfer internalTransfer=new InternalTransfer();
        internalTransfer.setJobId("123");
        internalTransfer.setFromAccountNumber("ABC");
        internalTransfer.setToAccountNumber("XYZ");
        internalTransfer.setRecurringType(RecurringType.ENDDATE);
        internalTransfer.setTransferAmount(100d);
        internalTransfer.setTrnId(550);
        internalTransfer.setFrequencyId(0);
        internalTransfer.setTransferDate(new Date());
        internalTransfer.setScheduleEndDate(new Date());
        return internalTransfer;
    }


    public static WireTransfer createWireTransfer() {
        WireTransfer wireTransfer=new WireTransfer();
        wireTransfer.setPmtType("DOM");
        wireTransfer.setJobId("123");
        wireTransfer.setFromAccountNumber("ABC");
        wireTransfer.setBnfAccountType("bnfAccountType");
        wireTransfer.setWireTxnId(550);
        wireTransfer.setBeneAccount("bene");
        wireTransfer.setCrncyCode("USD");
        wireTransfer.setDebitAmt(100d);
        wireTransfer.setBeneBankId("123456789");
        wireTransfer.setOlbClientId("test0005");
        wireTransfer.setValueDate(new Date(new Date().getTime() + 86400000));
        wireTransfer.setBeneBankCountry("United States of America");

        return wireTransfer;
    }

    public static TransactionEntity createTransactionEntity() {
        TransactionEntity transactionEntity=new TransactionEntity();
        transactionEntity.setEC_CLIENT_ID("EC_CLIENT");
        transactionEntity.setEC_TXN_ID(123);
        transactionEntity.setEC_USERLOGIN_ID("USER");
        transactionEntity.setGW_CLIENT_ID("GW_CLIENT");
        transactionEntity.setGW_REQ_ID(1l);
        transactionEntity.setJOBID("0");
        transactionEntity.setSTATUS(STATUS_SUCCESS);
        transactionEntity.setPAYMENT_ID("123");
        return transactionEntity;
    }

    public static List<CountryCodeEntity> getCountryCodes(){
        List<CountryCodeEntity> countryCodeEntityList=new ArrayList<>();
        CountryCodeEntity countryCodeEntity=new CountryCodeEntity();
        countryCodeEntity.setCountry("UNITED STATES OF AMERICA");
        countryCodeEntity.setIsoCode("US");
        countryCodeEntityList.add(countryCodeEntity);
        return countryCodeEntityList;
    }

    public static Map<String, String> getCountryCodeMap(){
        Map<String, String> countryCodeMap= new HashMap<>();
        countryCodeMap.put("UNITED STATES OF AMERICA", "US");
        countryCodeMap.put("UNITED KINGDOM", "GB");
        countryCodeMap.put("INDIA","IN");
        return countryCodeMap;
    }
}
