package com.svb.gateway.migration.report.controller;

import com.svb.gateway.migration.common.exception.ServiceException;
import com.svb.gateway.migration.report.service.ReportService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import org.mockito.Spy;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import static junit.framework.TestCase.assertEquals;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.doThrow;

@SpringBootTest
@AutoConfigureMockMvc
class ReportControllerTest {

    @InjectMocks
    @Spy
    ReportController reportController;

    @MockBean
    private ReportService reportService;

    @BeforeEach
    public void setup() throws Exception {
        reportController = new ReportController(reportService);
    }

    @Test
    void migrationExcelReport() throws Exception {

        byte[] byteArray = {1, 2};
        ByteArrayResource byteArrayResource = new ByteArrayResource(byteArray);
        doReturn(byteArrayResource).when(reportService).generateMigrationExcelReport(Mockito.anyLong(), Mockito.any());

        ResponseEntity<?> re = reportController.generateMigrationExcelReport(200l, "late9123");

        assertEquals(HttpStatus.OK, re.getStatusCode());
    }

    @Test
    void migrationExcelReportFail() throws Exception {

        doThrow(new ServiceException("Test Report Controller")).when(reportService).generateMigrationExcelReport(Mockito.anyLong(), Mockito.any());

        ResponseEntity<?> re = reportController.generateMigrationExcelReport(200l, "late9123");

        assertEquals(HttpStatus.NOT_FOUND, re.getStatusCode());
    }

}