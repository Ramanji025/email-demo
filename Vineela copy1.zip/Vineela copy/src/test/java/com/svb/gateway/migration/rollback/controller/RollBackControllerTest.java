package com.svb.gateway.migration.rollback.controller;

import com.svb.gateway.migration.rollback.model.RollBackResponse;
import com.svb.gateway.migration.rollback.model.RollBackResponseEntity;
import com.svb.gateway.migration.rollback.service.RollBackService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import java.util.ArrayList;
import java.util.List;

import static org.mockito.ArgumentMatchers.any;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;

import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@AutoConfigureMockMvc
public class RollBackControllerTest {

    @Autowired
    private MockMvc mockMvc;


    @MockBean
    private RollBackService rollBackService;

    private RollBackResponse rollbackResponse=new RollBackResponse();
    private RollBackResponseEntity rollBackResponseEntity=new RollBackResponseEntity();


    @BeforeEach
    public void setup() throws Exception {
        List<RollBackResponse> rollBackResponseList=new ArrayList<>();

        rollBackResponseEntity.setRollBackResponses(rollBackResponseList);
        Mockito.when(rollBackService.rollback(any(), any(), any())).
                thenReturn(rollBackResponseEntity);
    }

    @Test
    public void client_resp() throws Exception {
        this.mockMvc.perform(post("/v1/api/rollback")
                .contentType(MediaType.APPLICATION_JSON_VALUE).param("comments", "test")
                .content("abcd1234")
                .param("skipEcClientRollback","TRUE")
                .header("Authorization","Basic Y3JtdXNlcjI6QWNjZXNzMTIz"))
                .andExpect(status().isOk());
    }
}
