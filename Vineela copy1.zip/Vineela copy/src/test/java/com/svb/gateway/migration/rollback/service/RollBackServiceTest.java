package com.svb.gateway.migration.rollback.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.svb.gateway.migration.alerts.service.AlertsService;
import com.svb.gateway.migration.beneficiaries.mapper.MigBeneficiaryMapper;
import com.svb.gateway.migration.cards.service.CardsService;
import com.svb.gateway.migration.client.entity.MigClient;
import com.svb.gateway.migration.client.model.DeleteClientResponse;
import com.svb.gateway.migration.client.repository.MigClientRepository;
import com.svb.gateway.migration.client.service.ClientService;
import com.svb.gateway.migration.common.constants.MigrationConstants;
import com.svb.gateway.migration.common.exception.BadRequestException;
import com.svb.gateway.migration.common.exception.ServiceException;
import com.svb.gateway.migration.ec2stage.service.ECService;
import com.svb.gateway.migration.job.entity.MigJob;
import com.svb.gateway.migration.job.repository.MigJobRepository;
import com.svb.gateway.migration.nickname.service.NicknameService;
import com.svb.gateway.migration.payments.entity.TransactionEntity;
import com.svb.gateway.migration.payments.service.GatewayPaymentService;
import com.svb.gateway.migration.payments.service.StopPaymentService;
import com.svb.gateway.migration.payments.utils.PaymentsUtils;
import com.svb.gateway.migration.rollback.mapper.RollBackMapper;
import com.svb.gateway.migration.rollback.model.RollBackResponse;
import com.svb.gateway.migration.rollback.model.RollBackResponseEntity;
import com.svb.gateway.migration.user.mapper.UserMapper;
import com.svb.gateway.migration.user.model.CardUserResponse;
import com.svb.gateway.migration.user.repository.MigUserRepository;
import com.svb.gateway.migration.user.service.UserService;
import lombok.extern.slf4j.Slf4j;
import org.apache.ibatis.exceptions.IbatisException;
import org.junit.Assert;
import org.junit.Before;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.util.ArrayList;
import java.util.List;

import static com.svb.gateway.migration.rollback.service.RollBackService.ECONNECT_NOT_ENABLED;
import static com.svb.gateway.migration.rollback.service.RollBackService.GATEWAY_CLIENT;
import static org.junit.Assert.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.when;

@Slf4j
@SpringBootTest
@ExtendWith(SpringExtension.class)
public class RollBackServiceTest {



    @Mock
    MigClientRepository migClientRepository;

    @Mock
    MigUserRepository migUserRepository;

    @Mock
    MigJobRepository migJobRepository;

    @Mock
    RollBackMapper rollbackMapper;

    @Mock
    ClientService clientService;

    @Mock
    AlertsService alertsService;

    @Mock
    NicknameService nicknameService;

    @Mock
    CardsService cardsService;

    @Mock
    UserService userService;

    @Mock
    UserMapper userMapper;

    @Mock
    MigBeneficiaryMapper migBeneficiaryMapper;

    @Mock
    ECService ecService;

    @Mock
    StopPaymentService stopPaymentService;

    @Mock
    GatewayPaymentService gatewayPaymentService;

    @InjectMocks
    @Spy
    com.svb.gateway.migration.rollback.service.RollBackService rollBackService;

    private static final String ECONNECT_SUCCESS_MESSSAGE="Econnect Enabled";

    @Before
    void setup() {
        when(migUserRepository.welcomeEmailsSent(any())).thenReturn(0);
    }

    @Test
    void rollback_processes_Sucessfully() {
        try {
            String clientId = "ench6060";
            String[] clientIds=new String[]{clientId};
            Long jobId = 123L;
            MigClient migrationClient =new MigClient();
            migrationClient.setEcClientId("ench6060");
            migrationClient.setGwClientId("GWaddr7550");
            List<MigClient> migrationClients = new ArrayList<>();
            migrationClients.add(migrationClient);
            when(rollbackMapper.getTransfers(clientId,  MigrationConstants.INTERNAL_TRANSFERS_TABLE_NAME)).thenReturn(new ArrayList<TransactionEntity>());
            when(rollbackMapper.getTransfers(clientId,  MigrationConstants.WIRE_TRANSFERS_TABLE_NAME)).thenReturn(new ArrayList<TransactionEntity>());
            when(rollbackMapper.getPayments(clientId)).thenReturn(new ArrayList<TransactionEntity>());
            when(migClientRepository.findByEcClientIdStatusNotRollback(clientId)).thenReturn(migrationClients);
            when(userService.rollbackCardUserId(clientId, new RollBackResponse())).thenReturn(new CardUserResponse("123", "Success", "Success"));
            DeleteClientResponse deleteClientResponse = new DeleteClientResponse();
            deleteClientResponse.setStatus(MigrationConstants.STATUS_SUCCESS);
            when(clientService.inactiveAndDeleteClient(any(), any())).thenReturn(deleteClientResponse);
            when(ecService.updateClientDetailsEc(any(), any(), any())).thenReturn("SUCCESS");

            RollBackResponseEntity rollBackResponseEntity = rollBackService.rollback(clientIds, "test","FALSE");
           Assertions.assertNotNull(rollBackResponseEntity);
            Assert.assertTrue( rollBackResponseEntity.getRollBackResponses().get(0).getSuccess().contains(GATEWAY_CLIENT));
        }catch (ServiceException | JsonProcessingException se){
            Assert.fail("Not expected");
        }
    }

    @Test
    void rollback_Payments_successfully() {
        try {
            String clientId = "ench6060";
            Long jobId = 123L;
            MigClient migrationClient =new MigClient();
            migrationClient.setEcClientId("ench6060");
            migrationClient.setGwClientId("GWaddr7550");
            List<TransactionEntity> list=new ArrayList<TransactionEntity>();
            list.add(PaymentsUtils.createTransactionEntity());

            List<MigClient> migrationClients = new ArrayList<>();
            migrationClients.add(migrationClient);

            when(rollbackMapper.getTransfers(clientId, MigrationConstants.INTERNAL_TRANSFERS_TABLE_NAME)).thenReturn(list);
            when(rollbackMapper.getTransfers(clientId, MigrationConstants.WIRE_TRANSFERS_TABLE_NAME)).thenReturn(list);
            when(rollbackMapper.getPayments(clientId)).thenReturn(list);
            when(migClientRepository.findByEcClientIdStatusNotRollback(clientId)).thenReturn(migrationClients);
            when(gatewayPaymentService.rollback(any())).thenReturn(true);
            doNothing().when(rollbackMapper).updateTransferStatus(any(),any(),any());
            DeleteClientResponse deleteClientResponse = new DeleteClientResponse();
            deleteClientResponse.setStatus(MigrationConstants.STATUS_SUCCESS);
            when(clientService.inactiveAndDeleteClient(any(), any())).thenReturn(deleteClientResponse);
            String[] clientIds=new String[]{clientId};
            when(ecService.updateClientDetailsEc(any(), any(), any())).thenReturn("SUCCESS");
            RollBackResponseEntity rollbackResponse = rollBackService.rollback(clientIds, "test","FALSE");
            Assert.assertTrue( rollbackResponse.getRollBackResponses().get(0).getSuccess().contains(GATEWAY_CLIENT));
            Assertions.assertNotNull(rollbackResponse.getRollBackResponses());
        }catch (ServiceException | JsonProcessingException se){
            Assert.fail("Not expected");
        }
    }

    @Test
    void rollback_fails() {
        try {

            String clientId = "ench6060";
            String[] clientIds=new String[]{clientId};
            Long jobId = 123L;
            MigClient migrationClient =new MigClient();
            migrationClient.setEcClientId("ench6060");
            migrationClient.setGwClientId("GWaddr7550");

            when(migClientRepository.findByEcClientIdAndJobId(clientId, jobId)).thenReturn(migrationClient);
            when(rollbackMapper.getTransfers(clientId, MigrationConstants.INTERNAL_TRANSFERS_TABLE_NAME)).thenThrow(IbatisException.class);

            RollBackResponseEntity rollbackResponse = rollBackService.rollback(clientIds, "test","FALSE");
            when(ecService.updateClientDetailsEc(any(), any(), any())).thenReturn("SUCCESS");

            Assertions.assertNotNull(rollbackResponse.getRollBackResponses());
        }catch (ServiceException se){
            Assert.fail("Not expected");
        }
        catch (BadRequestException be) {
            assertEquals( "No valid Migration entity to roll back for :: ench6060", be.getMessage());
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
    }

    @Test
    void rollback_when_GWClient_is_null() {
        try {
            String clientId = "";
            Long jobId = 123L;
            MigClient migrationClient =new MigClient();
            String[] clientIds=new String[]{clientId};

            List<MigClient> migrationClients = new ArrayList<>();
            migrationClients.add(migrationClient);

            when(migClientRepository.findByEcClientIdStatusNotRollback(clientId)).thenReturn(migrationClients);
            when(ecService.updateClientDetailsEc(any(), any(), any())).thenReturn("SUCCESS");
            RollBackResponseEntity rollbackResponse=rollBackService.rollback(clientIds, "test","FALSE");

            Assert.assertTrue(rollbackResponse.getRollBackResponses().get(0).getErrors().size()>0);
        }catch (ServiceException | JsonProcessingException se){

        }
    }

    @Test
    void rollback_when_Migration_is_inprocess() {
        try {
            String clientId = "";
            Long jobId = 123L;
            MigClient migrationClient =new MigClient();

            List<MigClient> migrationClients = new ArrayList<>();
            migrationClients.add(migrationClient);
            String[] clientIds=new String[]{clientId};
            when(migJobRepository.findByJobIdProgress(any())).thenReturn(new MigJob());
            RollBackResponseEntity rollbackResponse=rollBackService.rollback(clientIds, "test", "FALSE");
            when(ecService.updateClientDetailsEc(any(), any(), any())).thenReturn("SUCCESS");

            Assert.assertTrue(rollbackResponse.getRollBackResponses().get(0).getErrors().size()>0);
        }catch (ServiceException | JsonProcessingException se){
            log.error("Exception is  expected"+se.getMessage());
        }
    }

    @Test
    void rollback_throws_Exception() {
        try {
            String clientId = "";
            Long jobId = 123L;
            String[] clientIds=new String[]{clientId};
            when(ecService.updateClientDetailsEc(any(), any(), any())).thenReturn("SUCCESS");

            RollBackResponseEntity rollbackResponse=rollBackService.rollback(clientIds, "test","FALSE");
            Assert.assertTrue(rollbackResponse.getRollBackResponses().get(0).getErrors().size()>0);
        }catch (ServiceException | JsonProcessingException se){
            log.error(" exception here"+se.getMessage());
        }
    }
    @Test
    void rollback_Validate() {
        try {
            String clientId = "ench6060";
            Long jobId = 123L;
            MigClient migrationClient =new MigClient();
            migrationClient.setEcClientId("ench6060");
            migrationClient.setGwClientId(null);
            List<TransactionEntity> list=new ArrayList<TransactionEntity>();
            list.add(PaymentsUtils.createTransactionEntity());
            String[] clientIds=new String[]{clientId};

            List<MigClient> migrationClients = new ArrayList<>();
            migrationClients.add(migrationClient);

            when(rollbackMapper.getTransfers(clientId, MigrationConstants.INTERNAL_TRANSFERS_TABLE_NAME)).thenReturn(list);
            when(rollbackMapper.getTransfers(clientId, MigrationConstants.WIRE_TRANSFERS_TABLE_NAME)).thenReturn(list);
            when(rollbackMapper.getPayments(clientId)).thenReturn(list);
            when(migClientRepository.findByEcClientIdStatusNotRollback(clientId)).thenReturn(migrationClients);
            when(gatewayPaymentService.rollback(any())).thenReturn(true);
            doNothing().when(rollbackMapper).updateTransferStatus(any(),any(),any());
            DeleteClientResponse deleteClientResponse = new DeleteClientResponse();
            deleteClientResponse.setStatus(MigrationConstants.STATUS_SUCCESS);
            when(clientService.inactiveAndDeleteClient(any(), any())).thenReturn(deleteClientResponse);
            when(migJobRepository.findByJobMigrationInProgress(any())).thenReturn(null);
            when(ecService.updateClientDetailsEc(any(), any(), any())).thenReturn("SUCCESS");
            RollBackResponseEntity rollbackResponse = rollBackService.rollback(clientIds, "test","FALSE");
            assertNotNull(rollbackResponse.getRollBackResponses());
            Assert.assertTrue( rollbackResponse.getRollBackResponses().get(0).getSuccess().size() ==0);
        }catch (ServiceException | JsonProcessingException se){
            Assert.fail("Not expected"+se.getMessage());
        }
    }

    @Test
    void rollback_not_accepted_because_welcome_email_was_sent() throws ServiceException {
        try {
            when(migUserRepository.welcomeEmailsSent(any())).thenReturn(1);
            String clientId = "ench6060";
            Long jobId = 123L;
            MigClient migrationClient =new MigClient();
            migrationClient.setEcClientId("ench6060");
            migrationClient.setGwClientId("GWaddr7550");
            String[] clientIds=new String[]{clientId};
            List<MigClient> migrationClients = new ArrayList<>();
            migrationClients.add(migrationClient);
            when(rollbackMapper.getTransfers(clientId,  MigrationConstants.INTERNAL_TRANSFERS_TABLE_NAME)).thenReturn(new ArrayList<TransactionEntity>());
            when(rollbackMapper.getTransfers(clientId,  MigrationConstants.WIRE_TRANSFERS_TABLE_NAME)).thenReturn(new ArrayList<TransactionEntity>());
            when(rollbackMapper.getPayments(clientId)).thenReturn(new ArrayList<TransactionEntity>());
            when(migClientRepository.findByEcClientIdStatusNotRollback(clientId)).thenReturn(migrationClients);
            when(userService.rollbackCardUserId(clientId, new RollBackResponse())).thenReturn(new CardUserResponse("123", "Success", "Success"));
            DeleteClientResponse deleteClientResponse = new DeleteClientResponse();
            deleteClientResponse.setStatus(MigrationConstants.STATUS_SUCCESS);
            when(clientService.inactiveAndDeleteClient(any(), any())).thenReturn(deleteClientResponse);

            RollBackResponseEntity rollbackResponse = rollBackService.rollback(clientIds, "test", "FALSE");

        }catch (BadRequestException se){
            assertEquals("1 welcome emails were already sent to users of this client ench6060", se.getMessage());
        }
    }

}
