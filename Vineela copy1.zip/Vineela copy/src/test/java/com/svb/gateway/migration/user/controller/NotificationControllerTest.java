package com.svb.gateway.migration.user.controller;

import com.svb.gateway.migration.client.entity.MigClient;
import com.svb.gateway.migration.client.repository.MigClientRepository;
import com.svb.gateway.migration.common.exception.ServiceException;
import com.svb.gateway.migration.user.model.ListOfClientsResponse;
import com.svb.gateway.migration.user.service.NotificationService;
import junit.framework.TestCase;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doReturn;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@AutoConfigureMockMvc
@ExtendWith(SpringExtension.class)
public class NotificationControllerTest {

    @Mock
    private NotificationService notificationService;
    @InjectMocks
    @Spy
    private NotificationController notificationController;
    @Mock
    private MigClientRepository clientRepository;
    @Autowired
    private MockMvc mockMvc;

    @BeforeEach
    public void setup() throws Exception {

        Mockito.doNothing().when(notificationService)
                .sendEmailNotification(ArgumentMatchers.anyString(), ArgumentMatchers.anyInt());
    }

    @Test
    public void testWelcomeEmail() throws Exception {
        mockMvc.perform(MockMvcRequestBuilders.multipart("/v1/api/notification/email/4569/clie1234")
                .header("Authorization", "Basic Y3JtdXNlcjI6QWNjZXNzMTIz")
                .characterEncoding("UTF-8"))
                .andExpect(status().isAccepted());
    }

    @Test
    public void testWelcomeEmailIf1() throws Exception {

        Exception ex = assertThrows(ServiceException.class
                , () -> notificationController.sendNotification(234, ""));
        assertEquals(ex.getMessage(), "ecClient id  has Invalid Format");

    }

    @Test
    public void testWelcomeEmailIf2() throws Exception {
        Exception ex = assertThrows(ServiceException.class
                , () -> notificationController.sendNotification(0, "vsv"));
        assertEquals(ex.getMessage(), "ecClient id vsv has Invalid Format");
    }

    @Test
    public void testWelcomeEmailIf2Null() throws Exception {
        Exception ex = assertThrows(ServiceException.class
                , () -> notificationController.sendNotification(null, "konk1806"));
        assertEquals(ex.getMessage(), "Invalid Job Id");
    }

    @Test
    public void testBulkEmail() throws Exception {


        MockMultipartFile csvFile = new MockMultipartFile("test.csv", "test.csv", "text/csv",
                ("konk1806\n").getBytes());

        MigClient client = new MigClient();
        client.setJobId(1256L);
        client.setEcClientId("konk1806");
        List<MigClient> migclients = new ArrayList<>();
        migclients.add(client);
        Mockito.when(notificationService.getAllClientsByStatus(any())).thenReturn(migclients);
        ResponseEntity res = notificationController.sendBulkNotification(csvFile);
        assertEquals(202, res.getStatusCodeValue());
    }

    @Test
    public void testBulkEmailSendException() throws Exception {
        MockMultipartFile csvFile = new MockMultipartFile("test.csv", "test.csv", "text/csv",
                ("konk1806\n" + "konk106").getBytes());
        MigClient client = new MigClient();
        client.setJobId(1256L);
        client.setEcClientId("konk1806");
        List<MigClient> migClientList = new ArrayList<>();
        migClientList.add(client);
        Mockito.when(notificationService.getAllClientsByStatus(any())).thenReturn(migClientList);
        Mockito.doThrow(ServiceException.class).when(notificationService)
                .sendEmailNotification(ArgumentMatchers.anyString(), ArgumentMatchers.anyInt());
        ResponseEntity res = notificationController.sendBulkNotification(csvFile);
        assertEquals(202, res.getStatusCodeValue());
    }

    @Test
    public void listOfClientSuccess() throws Exception {
        ListOfClientsResponse listOfClientsResponse = new ListOfClientsResponse();
        doReturn(listOfClientsResponse).when(notificationService).getListOfClients(Mockito.anyInt(), Mockito.any());

        ResponseEntity<?> re = notificationController.getListOfClients(1234, "SUCCESS");

        TestCase.assertEquals(HttpStatus.OK, re.getStatusCode());
    }

    @Test
    public void listOfClientFailure() throws Exception {
        Exception ex = assertThrows(ServiceException.class
                , () -> notificationController.getListOfClients(0, "SUC"));
        assertEquals(ex.getMessage(), "Invalid Job Id");
    }

    @Test
    public void testBulkEmailByJobId() throws Exception {

        Mockito.when(notificationService.sendEmailNotificationByJobId(any())).thenReturn(1);
        ResponseEntity res = notificationController.sendBulkNotificationByJobId(125);
        assertEquals(202, res.getStatusCodeValue());
    }
}

