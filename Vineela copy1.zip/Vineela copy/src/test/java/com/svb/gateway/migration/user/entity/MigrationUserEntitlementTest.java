package com.svb.gateway.migration.user.entity;

import lombok.extern.log4j.Log4j2;
import org.junit.Assert;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static com.svb.gateway.migration.common.constants.MigrationConstants.*;
import static com.svb.gateway.migration.common.constants.UserConstants.*;
import static org.junit.jupiter.api.Assertions.*;

@Log4j2
class MigrationUserEntitlementTest {


    @Test
    void test_getGWUserAccess_WhenAdmin() {
        MigrationUserEntitlement entitlement = getEntitlement();
        entitlement.setEConnectUserRole(PRIMARY_ADMIN);
        entitlement.setEConnectApproveEntitlement(YES);
        Assert.assertEquals(FULL_ACCESS,entitlement.getGWUserAccess());
        Assert.assertEquals(Y_FLAG,entitlement.isGWApprover());
        Assert.assertEquals( ADMIN,entitlement.getGWUserRole());

        log.info("test_getGWUserAccess_WhenAllYes :"+entitlement.getGWUserAccess());
    }

    @Test
    void test_getGWUserAccess_WhenAllYes() {
        MigrationUserEntitlement entitlement = getEntitlement();
        entitlement.setEConnectViewEntitlement(YES);
        entitlement.setEConnectInitiateEntitlement(YES);
        entitlement.setEConnectApproveEntitlement(YES);
        entitlement.setIpayApproveEntitlement(YES);
        Assert.assertEquals(FULL_ACCESS,entitlement.getGWUserAccess());
        Assert.assertEquals(Y_FLAG,entitlement.isGWApprover());
        Assert.assertEquals( ADMIN,entitlement.getGWUserRole());

        log.info("test_getGWUserAccess_WhenAllYes :"+entitlement.getGWUserAccess());
    }

    @Test
    void test_getGWUserAccess_WhenIpayisNo() {
        MigrationUserEntitlement entitlement = getEntitlement();
        entitlement.setEConnectViewEntitlement(YES);
        entitlement.setEConnectInitiateEntitlement(YES);
        entitlement.setEConnectApproveEntitlement(YES);
        entitlement.setIpayApproveEntitlement(NO);
        Assert.assertEquals(TRANSACT,entitlement.getGWUserAccess());
        Assert.assertEquals(Y_FLAG,entitlement.isGWApprover());
        Assert.assertEquals( ROLE_USER,entitlement.getGWUserRole());
        log.info("test_getGWUserAccess_WhenIpayisNo :"+entitlement.getGWUserAccess());
    }

    @Test
    void test_getGWUserAccess_WhenYES_YES_NO_NO() {
        MigrationUserEntitlement entitlement = getEntitlement();
        entitlement.setEConnectViewEntitlement(YES);
        entitlement.setEConnectInitiateEntitlement(YES);
        entitlement.setEConnectApproveEntitlement(NO);
        entitlement.setIpayApproveEntitlement(NO);
        Assert.assertEquals(TRANSACT,entitlement.getGWUserAccess());
        Assert.assertEquals(N_FLAG,entitlement.isGWApprover());
        Assert.assertEquals( ROLE_USER,entitlement.getGWUserRole());
        log.info("test_getGWUserAccess_WhenYES_YES_NO_NO :"+entitlement.getGWUserAccess());
    }

    @Test
    void test_getGWUserAccess_WhenYES_NO_NO_NO() {
        MigrationUserEntitlement entitlement = getEntitlement();
        entitlement.setEConnectViewEntitlement(YES);
        entitlement.setEConnectInitiateEntitlement(NO);
        entitlement.setEConnectApproveEntitlement(NO);
        entitlement.setIpayApproveEntitlement(NO);
        Assert.assertEquals(VIEW_ONLY,entitlement.getGWUserAccess());
        Assert.assertEquals(N_FLAG,entitlement.isGWApprover());
        Assert.assertEquals( ROLE_USER,entitlement.getGWUserRole());
        log.info("test_getGWUserAccess_WhenYES_NO_NO_NO :"+entitlement.getGWUserAccess());
    }

    @Test
    void test_getGWUserAccess_WhenYES_YES_NO_YES() {
        MigrationUserEntitlement entitlement = getEntitlement();
        entitlement.setEConnectViewEntitlement(YES);
        entitlement.setEConnectInitiateEntitlement(YES);
        entitlement.setEConnectApproveEntitlement(NO);
        entitlement.setIpayApproveEntitlement(YES);
        Assert.assertEquals(TRANSACT,entitlement.getGWUserAccess());
        Assert.assertEquals(Y_FLAG,entitlement.isGWApprover());
        Assert.assertEquals( ROLE_USER,entitlement.getGWUserRole());
        log.info("test_getGWUserAccess_WhenYES_YES_NO_NO :"+entitlement.getGWUserAccess());
    }

    private MigrationUserEntitlement getEntitlement() {
        MigrationUserEntitlement entitlement=new MigrationUserEntitlement();
        entitlement.setUserId("User1234");
        entitlement.setJobId(123L);
        entitlement.setClientId("user1234");
        entitlement.setId(1L);
        return entitlement;
    }
}
