package com.svb.gateway.migration.user.service;

import com.svb.gateway.migration.common.exception.ServiceException;
import com.svb.gateway.migration.user.entity.MigStgUserApprovals;
import com.svb.gateway.migration.user.entity.MigrationUserEntitlement;
import com.svb.gateway.migration.user.repository.MigStageUserApprovalsRepository;
import com.svb.gateway.migration.user.repository.MigrationUserEntitlementRepository;
import org.junit.Assert;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import static com.svb.gateway.migration.common.constants.UserConstants.NO;
import static com.svb.gateway.migration.common.constants.UserConstants.YES;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@SpringBootTest
@ExtendWith(SpringExtension.class)
class UserApprovalServiceTest {

    @Mock
    MigStageUserApprovalsRepository migStageUserApprovalsRepository;

    @Mock
    MigrationUserEntitlementRepository migrationUserEntitlementRepository;

    @InjectMocks
    @Spy
    UserApprovalService userApprovalService;

    private String userId="User1234";

    @BeforeEach
    void setUp() {
        List<MigrationUserEntitlement> entitlements=new ArrayList<>();
        when(migrationUserEntitlementRepository.findByEcClientIdAndJobId(any(), any())).thenReturn(entitlements);
    }

    @Test
    void approvalUsers_WhenUserStageApprovals_IsNull() {
        try {
            List<MigStgUserApprovals> userStageApprovals=null;
            when(migStageUserApprovalsRepository.findByEcClientIdAndJobId(any(), any())).thenReturn(userStageApprovals);
            Map<String, MigrationUserEntitlement> entitlementMap= userApprovalService.userEntitlements(123L, "abcd1234");
        } catch (ServiceException e) {
            Assert.fail();
        }
    }

    @Test
    void approvalUsers_WhenUserStageApprovals_IpayIsYes() {
        try {
            List<MigStgUserApprovals> userStageApprovals=getIpayApprovals();
            when(migStageUserApprovalsRepository.findByEcClientIdAndJobId(any(), any())).thenReturn(getIpayApprovals());
            Map<String, MigrationUserEntitlement> entitlementMap= userApprovalService.userEntitlements(123L, "abcd1234");
            Assert.assertNotNull(entitlementMap);
            Assert.assertEquals(YES, entitlementMap.get(userId).getIpayApproveEntitlement());
        } catch (ServiceException e) {
            Assert.fail();
        }
    }

    @Test
    void approvalUsers_WhenUserStageApprovals_IpayIsNo() {
        try {
            List<MigStgUserApprovals> userStageApprovals=getIpayNoApprovals();
            when(migStageUserApprovalsRepository.findByEcClientIdAndJobId(any(), any())).thenReturn(userStageApprovals);
            Map<String, MigrationUserEntitlement> entitlementMap= userApprovalService.userEntitlements(123L, "abcd1234");
            Assert.assertNotNull(entitlementMap);
            Assert.assertEquals(NO, entitlementMap.get(userId).getIpayApproveEntitlement());
        } catch (ServiceException e) {
            Assert.fail();
        }
    }

    @Test
    void approvalUsers_WhenUserStageApprovals_ForMultiple() {
        try {
            List<MigStgUserApprovals> userStageApprovals=getMultipleApprovals();
            when(migStageUserApprovalsRepository.findByEcClientIdAndJobId(any(), any())).thenReturn(userStageApprovals);
            Map<String, MigrationUserEntitlement> entitlementMap= userApprovalService.userEntitlements(123L, "abcd1234");
            Assert.assertNotNull(entitlementMap);
            Assert.assertEquals(YES, entitlementMap.get(userId).getEConnectViewEntitlement());
            Assert.assertEquals(YES, entitlementMap.get(userId).getEConnectInitiateEntitlement());
            Assert.assertEquals(NO, entitlementMap.get(userId).getEConnectApproveEntitlement());
            Assert.assertEquals(NO, entitlementMap.get(userId).getIpayApproveEntitlement());

        } catch (ServiceException e) {
            Assert.fail();
        }
    }

    private  List<MigStgUserApprovals> getIpayApprovals(){
        List<MigStgUserApprovals> migStgUserApprovals=new ArrayList<>();
        MigStgUserApprovals migStgUserApproval=getBasicApproval();
        migStgUserApproval.setIPayApprovalRequired(YES);
        migStgUserApproval.setIPayDualAuthentication(YES);
        migStgUserApprovals.add(migStgUserApproval);
        migStgUserApproval.setEcUserId(userId);
        return migStgUserApprovals;
    }

    private  List<MigStgUserApprovals> getIpayNoApprovals(){
        List<MigStgUserApprovals> migStgUserApprovals=new ArrayList<>();
        MigStgUserApprovals migStgUserApproval=getBasicApproval();
        migStgUserApproval.setIPayApprovalRequired(NO);
        migStgUserApproval.setIPayDualAuthentication(NO);
        migStgUserApprovals.add(migStgUserApproval);
        migStgUserApproval.setEcUserId(userId);
        return migStgUserApprovals;
    }

    private  List<MigStgUserApprovals> getMultipleApprovals(){
        List<MigStgUserApprovals> migStgUserApprovals=new ArrayList<>();
        MigStgUserApprovals firstStgUserApproval=getBasicApproval();
        firstStgUserApproval.setFreeFormWireApproval1(NO);
        firstStgUserApproval.setFreeFormWireApproval2(NO);
        firstStgUserApproval.setTemplateWireApproval1(NO);
        firstStgUserApproval.setApproveTemplate(NO);
        firstStgUserApproval.setIPayApprovalRequired(NO);
        firstStgUserApproval.setIPayDualAuthentication(NO);
        firstStgUserApproval.setCreateModifyTemplate(YES);
        firstStgUserApproval.setStopPayments(YES);
        firstStgUserApproval.setInitiateFreedomWire(YES);
        firstStgUserApproval.setInitiateTemplateWire(YES);
        firstStgUserApproval.setViewWirePayment(YES);
        firstStgUserApproval.setEcUserId(userId);
        migStgUserApprovals.add(firstStgUserApproval);

        MigStgUserApprovals secondStgUserApproval=getBasicApproval();
        secondStgUserApproval.setFreeFormWireApproval1(NO);
        secondStgUserApproval.setFreeFormWireApproval2(NO);
        secondStgUserApproval.setTemplateWireApproval1(NO);
        secondStgUserApproval.setApproveTemplate(NO);
        secondStgUserApproval.setIPayApprovalRequired(NO);
        secondStgUserApproval.setIPayDualAuthentication(NO);
        secondStgUserApproval.setCreateModifyTemplate(YES);
        secondStgUserApproval.setStopPayments(NO);
        secondStgUserApproval.setInitiateFreedomWire(YES);
        secondStgUserApproval.setInitiateTemplateWire(NO);
        secondStgUserApproval.setViewWirePayment(YES);
        secondStgUserApproval.setEcUserId(userId);
        migStgUserApprovals.add(secondStgUserApproval);


        return migStgUserApprovals;
    }

    private MigStgUserApprovals getBasicApproval(){
        MigStgUserApprovals migStgUserApproval=new MigStgUserApprovals();
        migStgUserApproval.setAccountNumber("1234567890");
        migStgUserApproval.setCreatedBy("SVB");
        migStgUserApproval.setJobId(123);
        return migStgUserApproval;
    }
}
