package com.svb.gateway.migration.user.service;


import com.svb.gateway.migration.client.entity.MigClient;
import com.svb.gateway.migration.client.entity.StgClient;
import com.svb.gateway.migration.client.model.Cifs;
import com.svb.gateway.migration.client.model.Client;
import com.svb.gateway.migration.client.model.ClientInfo;
import com.svb.gateway.migration.client.repository.ClientRepository;
import com.svb.gateway.migration.client.repository.MigClientRepository;
import com.svb.gateway.migration.common.constants.MigrationConstants;
import com.svb.gateway.migration.common.exception.ServiceException;
import com.svb.gateway.migration.common.logging.Message;
import com.svb.gateway.migration.common.model.Error;
import com.svb.gateway.migration.common.service.RetryService;
import com.svb.gateway.migration.common.utility.CacheManagerUtility;
import com.svb.gateway.migration.common.utility.EntityLogUtility;
import com.svb.gateway.migration.common.repository.MigEntityRepository;
import com.svb.gateway.migration.rollback.model.RollBackResponse;
import com.svb.gateway.migration.user.entity.MigCardUserEntity;
import com.svb.gateway.migration.user.entity.MigUser;
import com.svb.gateway.migration.user.entity.MigrationUserEntitlement;
import com.svb.gateway.migration.user.entity.StgUser;
import com.svb.gateway.migration.user.mapper.UserMapper;
import com.svb.gateway.migration.user.model.*;
import com.svb.gateway.migration.user.repository.MigCardUserRepository;
import com.svb.gateway.migration.user.repository.MigUserRepository;
import com.svb.gateway.migration.user.repository.StgUserRepository;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.*;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.*;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.util.Assert;
import org.springframework.web.client.RestClientException;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.svb.gateway.migration.common.constants.UserConstants.NO;
import static com.svb.gateway.migration.common.constants.UserConstants.YES;
import static junit.framework.TestCase.assertEquals;
import static junit.framework.TestCase.assertTrue;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@SpringBootTest
@ExtendWith(SpringExtension.class)
public class UserServiceTest {

    public static String clientId;
    public static String oAuth;
    public static String companyId;
    public static HttpEntity<Cifs> requestEntity;
    public static String migratingClientId;


    Integer migStartupBankingBundle = 15;
    @Mock
    StgClient stgClient;
    @Mock
    ClientRepository clientRepository;
    @Mock
    StgUserRepository stgUserRepository;
    @Mock
    RetryService retryService;
    @Mock
    AddUserRequest request;
    @Mock
    MigClientRepository migClientRepository;
    @Mock
    MigUserRepository migUserRepository;
    @Mock
    CacheManagerUtility cacheManagerUtility;
    @Mock
    UserMapper userMapper;
    @Mock
    EntityLogUtility entityLogUtility;
    @InjectMocks
    @Spy
    UserService userService;
    @Mock
    MigCardUserRepository migCardUserRepository;
    @Mock
    MigEntityRepository migEntityRepository;
    @Mock
    UserApprovalService userApprovalService;

    MigClient migClient = new MigClient();
    String migCorelationId = "migCorelationId";
    StgUser u = new StgUser();
    List<StgUser> users = new ArrayList<>();

    @BeforeAll
    public static void setUp() {
        clientId = "addr9768";
        migratingClientId = "addr9768";
        companyId = "SVB";
    }

    @BeforeEach
    public void setters() {
        migClient.setPrimaryCifUbs(200030009);
        migClient.setPrimaryCifCbs(200030009L);
        migClient.setEcClientId(migCorelationId);
        migClient.setGwClientId("GWaddr9768");
        migClient.setClientName("Client Name");
        migClient.setJobId(123l);

        u.setPrimaryUser(true);
        u.setStatus("0");
        u.setLastLoginDate(LocalDate.now());
        u.setJobId("1");
    }

    @Test
    public void save_success() throws Exception {
        doReturn(null).when(migUserRepository).save(Mockito.any(MigUser.class));

        MigUser mu = new MigUser();

        userService.save(mu);

    }

    @Test
    public void addUser_success_cardOnly() throws Exception {

        u.setUserAccess(MigrationConstants.CARD_HOLDER_ONLY_USER);
        u.setTypeOfUser(MigrationConstants.CARD_HOLDER_ONLY_USER);
        u.setCountryCode("1");
        u.setCntPh("987655");
        u.setOlbClientId("abcd1234");
        u.setUserLoginId("123");
        users.add(u);
        userService.lastLoginMonthThreshold = 18;
        when(stgUserRepository.findByOlbClientId(clientId, "N")).thenReturn(users);
        oAuth = "e2561beef23920c18902ada758a1118de96be728add38b1a04acb2d911845352";
        when(cacheManagerUtility.getOauthToken()).thenReturn(oAuth);

        when(migClientRepository.findByEcClientIdandJobIdStatus(Mockito.anyString(), Mockito.anyLong(), Mockito.anyString())).thenReturn(migClient);

        stgClient.setPrimaryCifUbs("200030009");

        when(clientRepository.findByOlbClinetId(Mockito.anyString())).thenReturn(stgClient);
        AddUserResponse userCreated = new AddUserResponse();
        AddUserResponseData data = new AddUserResponseData();
        data.setClientLoginId("clientLoginId");
        data.setGwClientId("addr9876");
        data.setStatus("Failed");
        data.setGwPrimaryUserId("gwuserId");
        userCreated.setData(data);
        doReturn(userCreated).when(userService).createUser(Mockito.any(AddUserRequest.class), Mockito.anyString());
        Map<String, MigrationUserEntitlement> entitlements=new HashMap<>();
        MigrationUserEntitlement entitlement=new MigrationUserEntitlement();
        entitlement.setEConnectUserRole(MigrationConstants.ROLE_USER);
        entitlement.setJobId(123L);
        entitlement.setIpayApproveEntitlement(YES);
        entitlement.setEConnectViewEntitlement(YES);
        entitlement.setEConnectInitiateEntitlement(YES);
        entitlement.setUserId("123");
        entitlements.put("123", entitlement);
        when(userApprovalService.userEntitlements(any(), any())).thenReturn(entitlements);

        doNothing().when(userService).save(Mockito.any(MigUser.class));
        migClient.setEcClientId(migratingClientId);
        AddUserResponse addUserResponse = userService.createUsers(1L, migClient);

        assertNotEquals(userCreated, addUserResponse);

    }

    @Test
    public void addUser_success_0() throws Exception {

        u.setUserAccess(MigrationConstants.FULL_ACCESS);
        u.setUserAccess(MigrationConstants.CARD_HOLDER_ONLY_USER);
        u.setTypeOfUser(MigrationConstants.CARD_HOLDER_ONLY_USER);
        u.setCountryCode("1");
        u.setCntPh("987655");
        u.setOlbClientId("abcd1234");
        u.setUserLoginId("123");

        users.add(u);
        userService.lastLoginMonthThreshold = 18;
        when(stgUserRepository.findByOlbClientId(clientId, "N")).thenReturn(users);
        oAuth = "e2561beef23920c18902ada758a1118de96be728add38b1a04acb2d911845352";
        when(cacheManagerUtility.getOauthToken()).thenReturn(oAuth);

        when(migClientRepository.findByEcClientIdandJobIdStatus(Mockito.anyString(), Mockito.anyLong(), Mockito.anyString())).thenReturn(migClient);

        MigUser migUser = new MigUser();
        migUser.setEcUserLoginId("abc");
        migUser.setJobId(123l);

        when(migUserRepository.findByEcUserLoginIdAndJobId(Mockito.anyString(), Mockito.any())).thenReturn(migUser);

        StgClient client = new StgClient();
        stgClient.setPrimaryCifUbs("200030009");

        when(clientRepository.findByOlbClinetId(Mockito.anyString())).thenReturn(stgClient);
        AddUserResponse userCreated = new AddUserResponse();
        AddUserResponseData data = new AddUserResponseData();
        data.setClientLoginId("clientLoginId");
        data.setGwClientId("addr9876");
        data.setStatus("Failed");
        data.setGwPrimaryUserId("gwuserId");
        userCreated.setData(data);

        doReturn(userCreated).when(userService).createUser(Mockito.any(AddUserRequest.class), Mockito.anyString());
        doNothing().when(userService).save(Mockito.any(MigUser.class));
        migClient.setEcClientId(migratingClientId);
        AddUserResponse addUserResponse = userService.createUsers(1L, migClient);

        assertNotEquals(userCreated, addUserResponse);

    }

    @Test
    public void addUser_oauth_null() throws Exception {

        users.add(u);

        when(stgUserRepository.findByOlbClientId(Mockito.anyString(), Mockito.anyString())).thenReturn(users);
        oAuth = null;
        when(cacheManagerUtility.getOauthToken()).thenReturn(oAuth);

        migClient.setEcClientId(migratingClientId);

        when(migClientRepository.findByEcClientIdSuccess(Mockito.anyString())).thenReturn(migClient);
        Exception exception = assertThrows(ServiceException.class, () -> {
            userService.createUsers(1L, migClient);
        });
        String expectedMessage = "unable to retrieve Oauth";
        String actualMessage = exception.getMessage();

        assertTrue(actualMessage.contains(expectedMessage));
    }


    @Test
    public void addUser_mig_user_error() throws Exception {

        u.setStatus("1");
        u.setUserLoginId("abc");
        u.setOlbClientId("abcd1234");
        u.setCountryCode("1");
        u.setCntPh("987");

        u.setUserAccess(MigrationConstants.FULL_ACCESS);

        users.add(u);
        userService.lastLoginMonthThreshold = 18;
        when(stgUserRepository.findByOlbClientId(clientId, "N")).thenReturn(users);
        oAuth = "e2561beef23920c18902ada758a1118de96be728add38b1a04acb2d911845352";
        when(cacheManagerUtility.getOauthToken()).thenReturn(oAuth);

        migClient.setComments("success");
        when(migClientRepository.findByEcClientIdandJobIdStatus(Mockito.anyString(), Mockito.anyLong(), Mockito.anyString())).thenReturn(migClient);

        StgClient client = new StgClient();
        stgClient.setPrimaryCifUbs("200030009");

        when(clientRepository.findByOlbClinetId(Mockito.anyString())).thenReturn(stgClient);
        AddUserResponse userCreated = new AddUserResponse();

        AddUserResponseData addUserResponseData = new AddUserResponseData();
        addUserResponseData.setStatus("Failed");
        Error e = new Error("0000", "Add User Failed");

        userCreated.setErrors(List.of(e));
        userCreated.setData(addUserResponseData);

        MigUser migUser = new MigUser();
        migUser.setEcUserLoginId("abc");
        migUser.setJobId(123l);

        when(migUserRepository.findByEcUserLoginIdAndJobId(Mockito.anyString(), Mockito.any())).thenReturn(migUser);

        doReturn(userCreated).when(userService).createUser(Mockito.any(AddUserRequest.class), Mockito.anyString());
        doNothing().when(userService).save(Mockito.any(MigUser.class));
        migClient.setEcClientId(migratingClientId);
        userService.createUsers(1L, migClient);

    }


    @Test
    public void addUser_mig_user_error_0() throws Exception {

        u.setLastLoginDate(null);
        u.setUserAccess(MigrationConstants.FULL_ACCESS);
        u.setUserLoginId("123");
        u.setOlbClientId("abcd1234");
        u.setCountryCode("1");
        u.setCntPh("987");

        users.add(u);

        when(stgUserRepository.findByOlbClientId(clientId, "N")).thenReturn(users);
        oAuth = "e2561beef23920c18902ada758a1118de96be728add38b1a04acb2d911845352";
        when(cacheManagerUtility.getOauthToken()).thenReturn(oAuth);

        migClient.setComments("success");
        when(migClientRepository.findByEcClientIdandJobIdStatus(Mockito.anyString(), Mockito.anyLong(), Mockito.anyString())).thenReturn(migClient);

        StgClient client = new StgClient();
        stgClient.setPrimaryCifUbs("200030009");

        when(clientRepository.findByOlbClinetId(Mockito.anyString())).thenReturn(stgClient);

        AddUserResponse userCreated = new AddUserResponse();

        AddUserResponseData addUserResponseData = new AddUserResponseData();
        addUserResponseData.setStatus("Failed");
        Error e = new Error("0000", "Add User Failed");

        userCreated.setErrors(List.of(e));
        userCreated.setData(addUserResponseData);

        MigUser migUser = new MigUser();
        migUser.setEcUserLoginId("abc");
        migUser.setJobId(123l);

        when(migUserRepository.findByEcUserLoginIdAndJobId(Mockito.anyString(), Mockito.any())).thenReturn(migUser);

        doReturn(userCreated).when(userService).createUser(Mockito.any(AddUserRequest.class), Mockito.anyString());
        doNothing().when(userService).save(Mockito.any(MigUser.class));
        migClient.setEcClientId(migratingClientId);
        userService.createUsers(1L, migClient);

    }


    @Test
    public void addUser_mig_user_error_2() throws Exception {
        u.setLastLoginDate(null);
        u.setStatus("2");
        u.setUserLoginId("abc");
        u.setOlbClientId("abcd1234");
        u.setCountryCode("1");
        u.setCntPh("987");
        u.setUserAccess(MigrationConstants.FULL_ACCESS);
        users.add(u);
        when(stgUserRepository.findByOlbClientId(clientId, "N")).thenReturn(users);
        oAuth = "e2561beef23920c18902ada758a1118de96be728add38b1a04acb2d911845352";
        when(cacheManagerUtility.getOauthToken()).thenReturn(oAuth);

        migClient.setComments("success");
        when(migClientRepository.findByEcClientIdandJobIdStatus(Mockito.anyString(), Mockito.anyLong(), Mockito.anyString())).thenReturn(migClient);
        StgClient client = new StgClient();
        stgClient.setPrimaryCifUbs("200030009");

        when(clientRepository.findByOlbClinetId(Mockito.anyString())).thenReturn(stgClient);
        AddUserResponse userCreated = new AddUserResponse();

        AddUserResponseData addUserResponseData = new AddUserResponseData();
        addUserResponseData.setStatus("Failed");
        Error e = new Error("0000", "Add User Failed");

        userCreated.setErrors(List.of(e));
        userCreated.setData(addUserResponseData);

        MigUser migUser = new MigUser();
        migUser.setEcUserLoginId("abc");
        migUser.setJobId(123l);

        when(migUserRepository.findByEcUserLoginIdAndJobId(Mockito.anyString(), Mockito.any())).thenReturn(migUser);

        doReturn(userCreated).when(userService).createUser(Mockito.any(AddUserRequest.class), Mockito.anyString());
        doNothing().when(userService).save(Mockito.any(MigUser.class));
        migClient.setEcClientId(migratingClientId);
        userService.createUsers(1L, migClient);

    }


    @Test
    public void addUser_mig_user_error_3() throws Exception {
        u.setLastLoginDate(null);
        u.setStatus("3");
        u.setUserLoginId("abc");
        u.setOlbClientId("abcd1234");
        u.setCountryCode("1");
        u.setCntPh("987");

        u.setUserAccess(MigrationConstants.FULL_ACCESS);

        users.add(u);

        when(stgUserRepository.findByOlbClientId(clientId, "N")).thenReturn(users);
        oAuth = "e2561beef23920c18902ada758a1118de96be728add38b1a04acb2d911845352";
        when(cacheManagerUtility.getOauthToken()).thenReturn(oAuth);

        migClient.setComments("success");
        when(migClientRepository.findByEcClientIdandJobIdStatus(Mockito.anyString(), Mockito.anyLong(), Mockito.anyString())).thenReturn(migClient);

        StgClient client = new StgClient();
        stgClient.setPrimaryCifUbs("200030009");

        when(clientRepository.findByOlbClinetId(Mockito.anyString())).thenReturn(stgClient);
        AddUserResponse userCreated = new AddUserResponse();

        AddUserResponseData addUserResponseData = new AddUserResponseData();
        addUserResponseData.setStatus("Failed");
        Error e = new Error("0000", "Add User Failed");

        userCreated.setErrors(List.of(e));
        userCreated.setData(addUserResponseData);

        MigUser migUser = new MigUser();
        migUser.setEcUserLoginId("abc");
        migUser.setJobId(123l);

        when(migUserRepository.findByEcUserLoginIdAndJobId(Mockito.anyString(), Mockito.any())).thenReturn(migUser);

        doReturn(userCreated).when(userService).createUser(Mockito.any(AddUserRequest.class), Mockito.anyString());
        doNothing().when(userService).save(Mockito.any(MigUser.class));
        migClient.setEcClientId(migratingClientId);
        userService.createUsers(1L, migClient);

    }

    @Test
    public void createUser_noUsers() {
        try {
            MigClient migClient = new MigClient();

            when(stgUserRepository.findByOlbClientId(anyString(), anyString())).thenReturn(null);
            userService.createUsers(1L, migClient);
        } catch (ServiceException e) {
            assertEquals("No additonal users to migrate", e.getErrorMessage());
        }
    }

    @Test
    public void createUser() throws Exception {
        Client clientData = new Client();
        clientData.setOlbId("olbId");
        clientData.setClientLoginId("123");
        List<User> userDetails = new ArrayList<>();
        User user = new User();
        user.setIdStoreuserkey("idstoreUserKey");
        userDetails.add(user);
        ClientInfo data = new ClientInfo();
        data.setClientData(clientData);
        data.setUserDetails(userDetails);
        ResponseEntity<ClientInfo> clientInfo = new ResponseEntity(data, HttpStatus.OK);

        doReturn(clientInfo).when(retryService).exchange(Mockito.anyString(), any(HttpMethod.class), any(HttpEntity.class), any());
        userService.migAddUserUrl = "migEnrollClientUrlTest";
        AddUserResponse addUserResponse = userService.createUser(request, oAuth);
        assertNotNull(addUserResponse.getData().getGwClientId());
    }

    @Test
    public void createUser_noRetry() throws Exception {

        u.setStatus("0");
        u.setOlbClientId("abcd1234");
        u.setUserLoginId("abcd");
        u.setCountryCode("1");
        u.setCntPh("987");

        u.setUserAccess(MigrationConstants.FULL_ACCESS);

        users.add(u);
        userService.lastLoginMonthThreshold = 18;
        when(stgUserRepository.findByOlbClientId(clientId, "N")).thenReturn(users);
        oAuth = "e2561beef23920c18902ada758a1118de96be728add38b1a04acb2d911845352";
        when(cacheManagerUtility.getOauthToken()).thenReturn(oAuth);

        when(migClientRepository.findByEcClientIdandJobIdStatus(Mockito.anyString(), Mockito.anyLong(), Mockito.anyString())).thenReturn(migClient);

        StgClient client = new StgClient();
        stgClient.setPrimaryCifUbs("200030009");

        when(clientRepository.findByOlbClinetId(Mockito.anyString())).thenReturn(stgClient);
        AddUserResponse userCreated = new AddUserResponse();
        AddUserResponseData data = new AddUserResponseData();
        data.setClientLoginId("clientLoginId");
        data.setGwClientId("addr9876");
        data.setStatus("Failed");
        data.setGwPrimaryUserId("gwuserId");
        userCreated.setData(data);

        List<MigUser> migUserList = new ArrayList<>();
        MigUser migUser = new MigUser();
        migUser.setStatus("SUCCESS");
        migUserList.add(migUser);

        when(migUserRepository.getMigratedUsers(any(), any(), any())).thenReturn(migUserList);
        doReturn(userCreated).when(userService).createUser(Mockito.any(AddUserRequest.class), Mockito.anyString());
        doNothing().when(userService).save(Mockito.any(MigUser.class));
        migClient.setEcClientId(migratingClientId);
        AddUserResponse addUserResponse = userService.createUsers(1L, migClient);

        assertNotEquals(userCreated, addUserResponse);

    }

    @Test
    public void createUser_null() throws Exception {

        ClientInfo data = new ClientInfo();
        ResponseEntity<ClientInfo> clientInfo = new ResponseEntity(data, HttpStatus.OK);

        doReturn(null).when(retryService).exchange(Mockito.anyString(), any(HttpMethod.class), any(HttpEntity.class), any());

        userService.migAddUserUrl = "migEnrollClientUrlTest";
        AddUserResponse addUserResponse = userService.createUser(request, oAuth);
        assertNotNull(addUserResponse.getData());
    }

    @Test
    public void createUser_data_null() throws Exception {

        ClientInfo data = new ClientInfo();
        ResponseEntity<ClientInfo> clientInfo = new ResponseEntity(null, HttpStatus.OK);

        doReturn(clientInfo).when(retryService).exchange(Mockito.anyString(), any(HttpMethod.class), any(HttpEntity.class), any());

        userService.migAddUserUrl = "migEnrollClientUrlTest";
        AddUserResponse addUserResponse = userService.createUser(request, oAuth);
        assertNotNull(addUserResponse.getData());
    }

    @Test
    public void createUser_olbid_null() throws Exception {
        Client clientData = new Client();

        ClientInfo data = new ClientInfo();
        data.setClientData(clientData);
        ResponseEntity<ClientInfo> clientInfo = new ResponseEntity(data, HttpStatus.OK);

        doReturn(clientInfo).when(retryService).exchange(Mockito.anyString(), any(HttpMethod.class), any(HttpEntity.class), any());

        userService.migAddUserUrl = "migEnrollClientUrlTest";
        AddUserResponse addUserResponse = userService.createUser(request, oAuth);
        assertNotNull(addUserResponse.getData());
    }

    @Test
    public void createUser_clientloginid__null() throws Exception {
        Client clientData = new Client();
        clientData.setOlbId("olbId");
        //clientData.setClientLoginId("123");
        List<User> userDetails = new ArrayList<>();
        User user = new User();
        user.setIdStoreuserkey("idstoreUserKey");
        userDetails.add(user);
        ClientInfo data = new ClientInfo();
        data.setClientData(clientData);
        data.setUserDetails(userDetails);
        ResponseEntity<ClientInfo> clientInfo = new ResponseEntity(data, HttpStatus.OK);

        doReturn(clientInfo).when(retryService).exchange(Mockito.anyString(), any(HttpMethod.class), any(HttpEntity.class), any());

        userService.migAddUserUrl = "migEnrollClientUrlTest";
        AddUserResponse addUserResponse = userService.createUser(request, oAuth);
        assertNotNull(addUserResponse.getData());
    }


    @Test
    public void createUser_Error() throws Exception {

        ClientInfo data = new ClientInfo();
        ResponseEntity<ClientInfo> clientInfo = new ResponseEntity(data, HttpStatus.OK);

        doThrow(new RestClientException("Test Exception")).when(retryService).exchange(Mockito.anyString(), any(HttpMethod.class), any(HttpEntity.class), any());

        userService.migAddUserUrl = "migEnrollClientUrlTest";
        AddUserResponse addUserResponse = userService.createUser(request, oAuth);

        assertNotNull(addUserResponse.getData());
    }

    @Test
    public void createCardUser() throws Exception {
        AddUserResponse addUserResponse = new AddUserResponse();
        AddUserResponseData addUserResponseData = new AddUserResponseData();
        ClientInfo body = new ClientInfo();

        ResponseEntity<ClientInfo> clientInfo = new ResponseEntity<>(body, HttpStatus.OK);
        doReturn(clientInfo).when(retryService).exchange(Mockito.anyString(), any(HttpMethod.class), any(HttpEntity.class), any());

        AddUserResponse addUserResponse1 = userService.createCardUser(request);

        assertNotNull(addUserResponse1.getData());
    }

    @Test
    public void createCardUser_fail() throws Exception {
        AddUserResponse addUserResponse = new AddUserResponse();
        AddUserResponseData addUserResponseData = new AddUserResponseData();
        ClientInfo body = new ClientInfo();

        ResponseEntity<ClientInfo> clientInfo = new ResponseEntity<>(body, HttpStatus.OK);
        doReturn(null).when(retryService).exchange(Mockito.anyString(), any(HttpMethod.class), any(HttpEntity.class), any());

        AddUserResponse addUserResponse1 = userService.createCardUser(request);

        assertNotNull(addUserResponse1.getData());
    }

    @Test
    public void createCardUser_exception() throws Exception {
        AddUserResponse addUserResponse = new AddUserResponse();
        AddUserResponseData addUserResponseData = new AddUserResponseData();
        ClientInfo body = new ClientInfo();

        ResponseEntity<ClientInfo> clientInfo = new ResponseEntity<>(body, HttpStatus.OK);
        doThrow(new RestClientException("Test Exception")).when(retryService).exchange(Mockito.anyString(), any(HttpMethod.class), any(HttpEntity.class), any());

        AddUserResponse addUserResponse1 = userService.createCardUser(request);

        assertNotNull(addUserResponse1.getData());
    }

    @Test
    public void test_updateUser() throws Exception {
        AddUserRequest request = new AddUserRequest();
        String oAuth = "oAuth";
        String status = "success";
        String userId = "12345566";

        doThrow(new RestClientException("Test Exception")).when(retryService).exchange(Mockito.anyString(), any(HttpMethod.class),
                any(HttpEntity.class), any());

        AddUserResponse addUserResponse = userService.updateUser(oAuth, status, userId);

        assertNotNull(addUserResponse.getData());

    }

    @Test
    public void test_updateUser_null() throws Exception {
        AddUserRequest request = new AddUserRequest();
        String oAuth = "oAuth";
        String status = "success";
        String userId = "12345566";

        ClientInfo body = new ClientInfo();

        ResponseEntity<ClientInfo> clientInfo = new ResponseEntity<>(body, HttpStatus.OK);
        doReturn(clientInfo).when(retryService).exchange(Mockito.anyString(), any(HttpMethod.class),
                any(HttpEntity.class), any());

        AddUserResponse addUserResponse = userService.updateUser(oAuth, status, userId);

        assertNotNull(addUserResponse.getData());

    }


    @Test
    public void test_updateUser_fail() throws Exception {
        AddUserRequest request = new AddUserRequest();
        String oAuth = "oAuth";
        String status = "success";
        String userId = "12345566";
        ClientInfo body = new ClientInfo();

        ResponseEntity<ClientInfo> clientInfo = new ResponseEntity<>(body, HttpStatus.OK);


        doReturn(null).when(retryService).exchange(Mockito.anyString(), any(HttpMethod.class),
                any(HttpEntity.class), any());

        AddUserResponse addUserResponse = userService.updateUser(oAuth, status, userId);

        assertNotNull(addUserResponse.getData());

    }


    @Test
    public void updateCardUser() throws ServiceException {
        List<CardUserMigrationData> clientData = new ArrayList<>();
        CardUserMigrationData data = new CardUserMigrationData() {
            @Override
            public String getEcClientId() {
                return "test";
            }

            @Override
            public String getGwUid() {
                return "test2";
            }

            @Override
            public String getGwClientId() {
                return "test3";
            }

            @Override
            public String getEcUserLoginId() {
                return "test4";
            }

            @Override
            public String getProgramId() {
                return "test5";
            }

            @Override
            public Integer getJobId() {
                return 123;
            }
        };
        clientData.add(data);
        Mockito.when(migClientRepository.getClientsByClientIdAndJob(ArgumentMatchers.anyString(), ArgumentMatchers.anyLong())).thenReturn(clientData);
        Mockito.when(migEntityRepository.save(ArgumentMatchers.any())).thenReturn(null);
        Mockito.when(cacheManagerUtility.getOauthToken()).thenReturn("test");
        CardUserResponse response = new CardUserResponse("test", "true", null);
        ResponseEntity<CardUserResponse> response2 = new ResponseEntity<CardUserResponse>(response, HttpStatus.OK);
        HttpEntity<CardUserRequest> httpEntity = new HttpEntity<>(new CardUserRequest(), new HttpHeaders());
        doReturn(response2).when(retryService).exchange(Mockito.anyString(), any(HttpMethod.class),
                any(HttpEntity.class), any());
        userService.updateCardUserId(23L, "test");
    }

    @Test
    public void updateCardUserNoCardUser() throws ServiceException {
        List<CardUserMigrationData> clientData = new ArrayList<>();
        Mockito.when(migClientRepository.getClientsByClientIdAndJob(ArgumentMatchers.anyString(), ArgumentMatchers.anyLong())).thenReturn(clientData);
        Mockito.when(migEntityRepository.save(ArgumentMatchers.any())).thenReturn(null);
        Mockito.when(cacheManagerUtility.getOauthToken()).thenReturn("test");
        CardUserResponse response = new CardUserResponse("test", "true", null);
        ResponseEntity<CardUserResponse> response2 = new ResponseEntity<CardUserResponse>(response, HttpStatus.OK);
        HttpEntity<CardUserRequest> httpEntity = new HttpEntity<>(new CardUserRequest(), new HttpHeaders());
        doReturn(response2).when(retryService).exchange(Mockito.anyString(), any(HttpMethod.class),
                any(HttpEntity.class), any());
        userService.updateCardUserId(23L, "test");
    }

    @Test
    public void rollbackCardUser() {
        List<CardUserMigrationData> clientData = new ArrayList<>();
        CardUserMigrationData data = new CardUserMigrationData() {
            @Override
            public String getEcClientId() {
                return "test";
            }

            @Override
            public String getGwUid() {
                return "test2";
            }

            @Override
            public String getGwClientId() {
                return "test3";
            }

            @Override
            public String getEcUserLoginId() {
                return "test4";
            }

            @Override
            public String getProgramId() {
                return "test5";
            }

            @Override
            public Integer getJobId() {
                return 123;
            }
        };
        clientData.add(data);
        Mockito.when(migClientRepository.getCardUsersDataForMigrationRollback(anyString())).thenReturn(clientData);
        MigCardUserEntity migCardUserEntity = new MigCardUserEntity();
        Mockito.when(migCardUserRepository.findByGwClientIdAndStatus(anyString(), anyString())).thenReturn(migCardUserEntity);
        CardUserResponse response = new CardUserResponse("test", "true", null);
        ResponseEntity<CardUserResponse> response2 = new ResponseEntity<CardUserResponse>(response, HttpStatus.OK);
        HttpEntity<CardUserRequest> httpEntity = new HttpEntity<>(new CardUserRequest(), new HttpHeaders());
        doReturn(response2).when(retryService).exchange(Mockito.anyString(), any(HttpMethod.class),
                any(HttpEntity.class), any());
        userService.rollbackCardUserId("test", new RollBackResponse());
    }

    @Test
    public void rollbackCardUser_null() {
        Mockito.when(migClientRepository.getClientsByClientIdAndJob(ArgumentMatchers.anyString(), ArgumentMatchers.anyLong())).thenReturn(null);
        CardUserResponse response = new CardUserResponse("test", "true", null);
        ResponseEntity<CardUserResponse> response2 = new ResponseEntity<CardUserResponse>(response, HttpStatus.OK);
        HttpEntity<CardUserRequest> httpEntity = new HttpEntity<>(new CardUserRequest(), new HttpHeaders());
        doReturn(response2).when(retryService).exchange(Mockito.anyString(), any(HttpMethod.class),
                any(HttpEntity.class), any());
        userService.rollbackCardUserId("test", new RollBackResponse());
    }

    @Test
    public void test_Pause_Processing(){
        Message message=Message.create().descr("Test sleep");
        Long start=System.currentTimeMillis();
        userService.pauseProcessing(message);
        Long end=System.currentTimeMillis();
        Assert.isTrue((end-start)>1L, "Sleep time correct");
    }

    @Test
    public void testStatusString_Returns_YES(){
        MigUser user=new MigUser();
        user.setBdcStatus(1);
        user.setRdmStatus(1);

        assertEquals(YES, user.bdcStatusAsString());
        assertEquals(YES, user.rdmStatusAsString());
    }

    @Test
    public void testStatusString_Returns_NO(){
        MigUser user=new MigUser();
        user.setBdcStatus(0);
        user.setRdmStatus(0);

        assertEquals(NO, user.bdcStatusAsString());
        assertEquals(NO, user.rdmStatusAsString());
    }
}
