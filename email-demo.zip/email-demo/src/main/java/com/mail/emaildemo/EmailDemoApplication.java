package com.mail.emaildemo;

import com.mail.emaildemo.model.Mail;
import com.mail.emaildemo.service.MailService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.util.HashMap;
import java.util.Map;

@SpringBootApplication
public class EmailDemoApplication implements CommandLineRunner {

	@Autowired
	private MailService mailService;

	public static void main(String[] args) {
		SpringApplication.run(EmailDemoApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {

		Mail mail = new Mail();
		mail.setMailFrom("javabycode@gmail.com");
		mail.setMailTo("rampathuri111@gmail.com");
		mail.setMailSubject("Spring Boot - Email with FreeMarker template");

		Map<String, Object> model = new HashMap<String, Object>();
		model.put("firstName", "David");
		model.put("lastName", "Pham");
		model.put("location", "Columbus");
		model.put("signature", "www.javabycode.com");
		mail.setModel(model);

		mailService.sendEmail(mail);
		System.out.println("Done!");
		System.exit(0);

	}
}
