package com.mail.emaildemo.config;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

/**
 * @author Ramanjaneyulu Pathuri on 29-11-2020
 */
@Component
@ConfigurationProperties(prefix = "email")
@Data
public class EmailProperties {

    private String host;
    private String port;
    private String username;
    private String password;
}
