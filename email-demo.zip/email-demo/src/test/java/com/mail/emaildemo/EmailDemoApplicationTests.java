package com.mail.emaildemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmailDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
